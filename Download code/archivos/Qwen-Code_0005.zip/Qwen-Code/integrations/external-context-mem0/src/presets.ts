/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

export const builtInPresets: ReadonlyMap<string, unknown> = new Map();
