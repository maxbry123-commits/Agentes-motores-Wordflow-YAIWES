#!/usr/bin/env node

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law_or_agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { spawn, execSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync, rmSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, '..');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf-8'));
const startupWarningsFile = join(
  tmpdir(),
  `qwen-code-warnings-${process.pid}-${randomUUID()}.txt`,
);

const env = {
  ...process.env,
  CLI_VERSION: pkg.version,
  DEV: 'true',
  QWEN_CODE_WARNINGS_FILE: startupWarningsFile,
  // The entry a `qwen …` subprocess should call to reach THIS build. This
  // launcher runs `node packages/cli` directly — no bin wrapper in the chain, so
  // nothing else publishes it, and a /review run from `npm start` would fall
  // back to whatever `qwen` PATH resolves to. Assignment, not `||=`, for the
  // same reason as scripts/dev.js: an inherited value is another session's CLI.
  QWEN_CODE_CLI: fileURLToPath(import.meta.url),
};

// check build status, write warnings to file for app to display if needed
execSync('node ./scripts/check-build-status.js', {
  stdio: 'inherit',
  cwd: root,
  env,
});

const nodeArgs = ['--expose-gc'];
let sandboxCommand = undefined;
try {
  sandboxCommand = execSync('node scripts/sandbox_command.js', {
    cwd: root,
  })
    .toString()
    .trim();
} catch {
  // ignore
}
// if debugging is enabled and sandboxing is disabled, use --inspect-brk flag
// note with sandboxing this flag is passed to the binary inside the sandbox
// inside sandbox SANDBOX should be set and sandbox_command.js should fail
if (process.env.DEBUG && !sandboxCommand) {
  if (process.env.SANDBOX) {
    const port = process.env.DEBUG_PORT || '9229';
    nodeArgs.push(`--inspect-brk=0.0.0.0:${port}`);
  } else {
    nodeArgs.push('--inspect-brk');
  }
}

nodeArgs.push(join(root, 'packages', 'cli'));
nodeArgs.push(...process.argv.slice(2));

if (process.env.DEBUG) {
  // If this is not set, the debugger will pause on the outer process rather
  // than the relaunched process making it harder to debug.
  env.QWEN_CODE_NO_RELAUNCH = 'true';
}
// Use process.cwd() to inherit the working directory from launch.json cwd setting
// This allows debugging from a specific directory (e.g., .todo)
const workingDir = process.env.QWEN_WORKING_DIR || process.cwd();
const child = spawn('node', nodeArgs, {
  stdio: 'inherit',
  env,
  cwd: workingDir,
});

child.on('close', (code, signal) => {
  try {
    rmSync(startupWarningsFile, { force: true });
  } catch {
    // The checker or startup warnings consumer may already have removed it.
  }

  // Same contract as scripts/dev.js: this launcher is a QWEN_CODE_CLI entry, and
  // a signal-killed child (`code === null`) must not exit 0 — `process.exit(null)`
  // coerces to success. Re-raise the signal; fall back to a non-zero exit.
  if (signal) {
    try {
      process.kill(process.pid, signal);
      return;
    } catch {
      process.exit(1);
    }
  }
  process.exit(code ?? 1);
});
