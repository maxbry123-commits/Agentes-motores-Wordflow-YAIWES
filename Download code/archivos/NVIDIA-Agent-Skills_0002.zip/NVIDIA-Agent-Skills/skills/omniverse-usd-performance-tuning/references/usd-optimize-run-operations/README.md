# usd-optimize-run-operations - Local Execution Policy and Upstream Handoff

This local reference preserves the digitaltwin workflow milestone. Scene
Optimizer mechanics for this step are owned by upstream `usd-optimize`.

- Public repository: [https://github.com/NVIDIA-Omniverse/usd-optimize/](https://github.com/NVIDIA-Omniverse/usd-optimize/)
- Package path: `.agents/skills/run-operations/SKILL.md`
- Upstream web URL: [https://github.com/NVIDIA-Omniverse/usd-optimize/blob/main/.agents/skills/run-operations/SKILL.md](https://github.com/NVIDIA-Omniverse/usd-optimize/blob/main/.agents/skills/run-operations/SKILL.md)

Resolve the upstream guide without cloning the source repo:

1. `$USD_OPTIMIZE_ROOT/.agents/skills/run-operations/SKILL.md`
2. `$USD_OPTIMIZE_ROOT/.agents/skills/run-operations/SKILL.md`

If no package root is available, download and extract the prebuilt Usd Optimize release package (current asset name + download: `references/upstreams/usd-optimize.md`) (direct
archive URLs are in `references/upstreams/usd-optimize.md`), or use the package
path/URL supplied by the user. If the user supplies an extracted
package root directly, resolve this same package path under that root. If
GitHub raw fetch is available, the web URL above is acceptable for docs-only
reads. Do not clone the source repo just to read upstream SO guidance.

## Local Responsibilities

- Run the session runtime gate from `setup-usd-performance-tuning/references/runtime-context-header.md` and consume `<output_path>/setup-preflight.json`.
- Cross-check every planned op key against `usdOptimize.operationsAvailable`; block with `blocked_missing_usd_optimize` or `blocked_missing_usd_optimize_operation` when required.
- Apply local output workspace policy and `runtime-artifact-token-budget.md`; keep logs on disk and read bounded summaries only.
- Apply destructive-operation approval gates via `references/operation-safety.md` before mutation.
- Keep digitaltwin evidence-to-config routing in `references/config-from-evidence.md`.
- Treat `references/invocation.md` as the only local source of truth for
  Python/API invocation shapes.
- For Phase 4b multi-target optimization, use `references/batch-mode.md` for target enumeration, adaptive concurrency, prototype-first ordering, hash-based output names, resource observations, status artifacts, and resume prompts.
- Preserve logical milestone name `usd-optimize-run-operations` and hand results to profile/compare/report phases.

## Pre-flight Checklist

Before executing the op chain, re-read and confirm:

- [ ] `references/operation-safety.md` — parameter prerequisites gate,
   confirmation prompt format, destructive-op approval policy.
- [ ] Every op key cross-checked against `setup-preflight.json`
   `usdOptimize.operationsAvailable`.
- [ ] Each destructive op looked up in `references/operations/operations.json`
   and its `parameter_prerequisites` read where the entry has one. Where it does
   not, the fallback in `operation-safety.md` §"Fallback: confirm-required ops
   with no `parameter_prerequisites` block" used to compose the confirmation.
- [ ] `references/units-and-tolerances.md` — conversion formula for any
   tolerance-based op.
- [ ] `references/invocation.md` for local invocation mechanics and upstream
  handoff.
- [ ] `references/batch-mode.md` for multi-target orchestration.
- [ ] `runtime-artifact-token-budget.md` §"Stderr Production Guard" — redirect
  subprocess stderr, cap at 50 MB, retain head/tail samples.
## Execution Handoff

Use `references/invocation.md` for supported Python/API invocation shapes,
optional helper wrappers, selected-runtime API probing, output saving, and
generic failure handling. Use this local file only for digitaltwin workflow
gating, batch orchestration policy, and reporting policy.
