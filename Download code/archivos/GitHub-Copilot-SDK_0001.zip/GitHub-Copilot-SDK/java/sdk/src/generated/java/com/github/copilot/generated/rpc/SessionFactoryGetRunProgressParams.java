/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

// AUTO-GENERATED FILE - DO NOT EDIT
// Generated from: api.schema.json

package com.github.copilot.generated.rpc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.github.copilot.CopilotExperimental;
import javax.annotation.processing.Generated;

/**
 * Parameters for paging factory progress.
 *
 * @apiNote This method is experimental and may change in a future version.
 * @since 1.0.0
 */
@CopilotExperimental
@javax.annotation.processing.Generated("copilot-sdk-codegen")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record SessionFactoryGetRunProgressParams(
    /** Target session identifier */
    @JsonProperty("sessionId") String sessionId,
    /** Factory run identifier. */
    @JsonProperty("runId") String runId,
    /** Optional phase identifier used to scope records and cursors. */
    @JsonProperty("phaseId") String phaseId,
    /** Exclusive forward cursor. */
    @JsonProperty("afterSeq") Long afterSeq,
    /** Exclusive backward cursor. */
    @JsonProperty("beforeSeq") Long beforeSeq,
    /** Maximum records to return. Defaults to 200 and is capped at 500. */
    @JsonProperty("limit") Long limit
) {
}
