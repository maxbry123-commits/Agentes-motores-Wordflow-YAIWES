/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

// AUTO-GENERATED FILE - DO NOT EDIT
// Generated from: api.schema.json

package com.github.copilot.generated.rpc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import javax.annotation.processing.Generated;

/**
 * Single content-exclusion rule supplied to `session.options.update`, with paths, match conditions, and source.
 *
 * @since 1.0.0
 */
@javax.annotation.processing.Generated("copilot-sdk-codegen")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record OptionsUpdateAdditionalContentExclusionPolicyRule(
    /** Path patterns covered by this rule. */
    @JsonProperty("paths") List<String> paths,
    /** Conditions of which at least one must match. */
    @JsonProperty("ifAnyMatch") List<String> ifAnyMatch,
    /** Conditions none of which may match. */
    @JsonProperty("ifNoneMatch") List<String> ifNoneMatch,
    /** Source descriptor for a `session.options.update` content-exclusion rule, with source name and type. */
    @JsonProperty("source") OptionsUpdateAdditionalContentExclusionPolicyRuleSource source
) {
}
