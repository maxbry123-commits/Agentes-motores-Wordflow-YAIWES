/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

// AUTO-GENERATED FILE - DO NOT EDIT
// Generated from: api.schema.json

package com.github.copilot.generated.rpc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.annotation.processing.Generated;

/**
 * Variant {@code unavailable} of {@link SessionLimitPredictionResult}.
 *
 * @since 1.0.0
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@javax.annotation.processing.Generated("copilot-sdk-codegen")
public final class SessionLimitPredictionResultUnavailable extends SessionLimitPredictionResult {

    @JsonProperty("kind")
    private final String kind = "unavailable";

    @Override
    public String getKind() { return kind; }

    /** Reason no prediction is available. */
    @JsonProperty("reason")
    private SessionLimitPredictionUnavailableReason reason;

    public SessionLimitPredictionUnavailableReason getReason() { return reason; }
    public void setReason(SessionLimitPredictionUnavailableReason reason) { this.reason = reason; }
}
