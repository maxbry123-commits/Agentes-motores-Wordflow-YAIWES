/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

// AUTO-GENERATED FILE - DO NOT EDIT
// Generated from: api.schema.json

package com.github.copilot.generated.rpc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.github.copilot.CopilotExperimental;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
 * The elicitation response (accept with form values, decline, or cancel)
 *
 * @apiNote This method is experimental and may change in a future version.
 * @since 1.0.0
 */
@CopilotExperimental
@javax.annotation.processing.Generated("copilot-sdk-codegen")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public record SessionUiElicitationResult(
    /** The user's response: accept (submitted), decline (rejected), or cancel (dismissed) */
    @JsonProperty("action") UIElicitationResponseAction action,
    /** The form values submitted by the user (present when action is 'accept') */
    @JsonProperty("content") Map<String, Object> content,
    /** MCP response metadata. */
    @JsonProperty("_meta") Map<String, Map<String, Object>> meta
) {
}
