/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

// AUTO-GENERATED FILE - DO NOT EDIT
// Generated from: api.schema.json

package com.github.copilot.generated.rpc;

import com.github.copilot.CopilotExperimental;
import java.util.concurrent.CompletableFuture;
import javax.annotation.processing.Generated;

/**
 * API methods for the {@code skills.config} namespace.
 *
 * @since 1.0.0
 */
@javax.annotation.processing.Generated("copilot-sdk-codegen")
public final class ServerSkillsConfigApi {

    private final RpcCaller caller;

    /** @param caller the RPC transport function */
    ServerSkillsConfigApi(RpcCaller caller) {
        this.caller = caller;
    }

    /**
     * Skill names to mark as disabled in global configuration, replacing any previous list.
     *
     * @apiNote This method is experimental and may change in a future version.
     * @since 1.0.0
     */
    @CopilotExperimental
    public CompletableFuture<Void> setDisabledSkills(SkillsConfigSetDisabledSkillsParams params) {
        return caller.invoke("skills.config.setDisabledSkills", params, Void.class);
    }

    /**
     * Adds or removes a single skill from the global disabled list, leaving every other entry untouched.
     *
     * @apiNote This method is experimental and may change in a future version.
     * @since 1.0.0
     */
    @CopilotExperimental
    public CompletableFuture<Void> setSkillDisabled(SkillsConfigSetSkillDisabledParams params) {
        return caller.invoke("skills.config.setSkillDisabled", params, Void.class);
    }

}
