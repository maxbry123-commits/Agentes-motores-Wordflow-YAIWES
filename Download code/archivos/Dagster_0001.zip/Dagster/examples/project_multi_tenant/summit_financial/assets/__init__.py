"""Tenant Beta asset modules."""
