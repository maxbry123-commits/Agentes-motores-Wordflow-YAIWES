"""Tenant Gamma asset modules."""
