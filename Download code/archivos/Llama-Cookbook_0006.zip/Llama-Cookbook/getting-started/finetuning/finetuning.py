# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed according to the terms of the Llama 3 Community License Agreement.

import fire
from llama_cookbook.finetuning import main

if __name__ == "__main__":
    fire.Fire(main)