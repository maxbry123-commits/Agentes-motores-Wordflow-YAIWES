"""GEPA re-optimization seeds from the module's CURRENT source (incl. manual edits).

When a user edits a flexed module (or re-runs GEPA on a previously-optimized one) and
optimizes again, GEPA must build on the current implementation rather than starting over.
``GEPA.compile`` constructs each flex submodule's seed candidate as ``flex.module_src`` (see
gepa.py), reading the live source. These LM-free tests lock in that the current/edited source
is what gets seeded. A MockInterpreter factory keeps them Deno-free — only ``module_src`` is read,
not executed.
"""

from __future__ import annotations

import dspy
from dspy.predict.flex.flex import Flex
from dspy.teleprompt.gepa.gepa_flex_utils import enumerate_flex_submodules
from tests.mock_interpreter import MockInterpreter

EDITED_MODULE = (
    "class EchoModule(dspy.Module):\n"
    "    def __init__(self):\n"
    "        super().__init__()\n"
    '        self.echo = dspy.Predict("q -> a")\n'
    "\n"
    "    def forward(self, q):\n"
    "        out = self.echo(q=q)\n"
    "        return dspy.Prediction(a=out.a.upper())"
)


class Echo(dspy.Signature):
    """Echo the question as the answer."""

    q: str = dspy.InputField()
    a: str = dspy.OutputField()


def test_gepa_discovers_edited_submodule_in_a_program() -> None:
    """A manual edit (or a prior GEPA run's output) is what gets seeded next time: mirror GEPA's
    discovery — enumerate_flex_submodules + the per-submodule seed value (flex.module_src)."""
    flex = Flex(Echo, interpreter_factory=lambda: MockInterpreter())
    flex._bind_code(EDITED_MODULE)  # an in-session tweak, or the result of a prior GEPA run

    class Program(dspy.Module):
        def __init__(self) -> None:
            super().__init__()
            self.classifier = flex

        def forward(self, **kwargs):
            return self.classifier(**kwargs)

    program = Program()
    submodules = enumerate_flex_submodules(program)
    assert submodules, "the flex submodule should be discoverable by GEPA"

    seed_candidate: dict[str, str] = {}
    for sub_path, sub in submodules.items():
        seed_candidate[sub_path] = sub.module_src  # the exact GEPA seed expression

    # Every seeded candidate carries the edit forward into the next GEPA run.
    assert seed_candidate
    assert all("out.a.upper()" in code for code in seed_candidate.values())
