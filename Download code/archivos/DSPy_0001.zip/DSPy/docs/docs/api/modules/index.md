# Modules

API reference for DSPy modules. Select a page below.

<!-- START_API_INDEX -->
- [BestOfN](BestOfN.md)
- [ChainOfThought](ChainOfThought.md)
- [CodeAct](CodeAct.md)
- [Flex](Flex.md)
- [Module](Module.md)
- [MultiChainComparison](MultiChainComparison.md)
- [Parallel](Parallel.md)
- [Predict](Predict.md)
- [ProgramOfThought](ProgramOfThought.md)
- [ReAct](ReAct.md)
- [ReActV2](ReActV2.md)
- [Refine](Refine.md)
- [RLM](RLM.md)
<!-- END_API_INDEX -->
