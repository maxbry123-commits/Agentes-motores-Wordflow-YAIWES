from __future__ import annotations

import inspect
import logging
from typing import Any

from gepa import EvaluationBatch

import dspy
from dspy.predict.flex import Flex
from dspy.predict.flex.ctx import _strip_code_fences
from dspy.predict.flex.primitives_doc import PRIMITIVES_CATALOG
from dspy.primitives import Prediction
from dspy.teleprompt import bootstrap_trace as bootstrap_trace_module
from dspy.teleprompt.bootstrap_trace import FailedPrediction
from dspy.utils.exceptions import LMError

logger = logging.getLogger(__name__)

def enumerate_flex_submodules(root) -> dict[str, Any]:
    """Map parameter path -> module for every code-optimizable (``dspy.Flex``) submodule."""
    return {name: sub for name, sub in root.named_parameters() if isinstance(sub, Flex)}


def flex_task_context(student_module) -> tuple[dict[str, str], dict[str, str]]:
    """Per flex submodule path, the ``(task_description, available_context)`` shown to the code
    proposer, keyed by the submodule's parameter path (its candidate key).
    """
    task_descriptions: dict[str, str] = {}
    context_blurbs: dict[str, str] = {}
    for path, sub in enumerate_flex_submodules(student_module).items():
        ctx = getattr(sub, "_flex_ctx", None)
        if ctx is not None and hasattr(ctx, "render_signature_spec"):
            task_descriptions[path] = ctx.render_signature_spec()
            context_blurbs[path] = ctx.render_context_blurb(sandboxed=True)
    return task_descriptions, context_blurbs


def _render_prediction(prediction: Any) -> Any:
    if isinstance(prediction, FailedPrediction):
        return f"FailedPrediction: {prediction.completion_text}"
    if isinstance(prediction, Prediction):
        try:
            return {k: str(v) for k, v in prediction.items()}
        except Exception:
            pass
    return str(prediction)


def _format_failures(records: list[dict[str, Any]]) -> str:
    if not records:
        return "(no failing examples available)"
    chunks: list[str] = []
    for i, rec in enumerate(records):
        chunks.append(
            f"=== Example {i} ===\n"
            f"Inputs:\n{rec.get('Inputs')!r}\n"
            f"Generated Outputs:\n{rec.get('Generated Outputs')!r}\n"
            f"Feedback:\n{rec.get('Feedback')}"
        )
    return "\n\n".join(chunks)


class CodeProposalSignature(dspy.Signature):
    """Revise the full source code of a dspy.Flex submodule.

    You receive the submodule's task description (its Signature), the available context (any tools
    and style notes), the catalog of allowed primitives, the module's current source, and a batch
    of failing examples with feedback. Produce a revised source that fixes the observed failures
    and follows the catalog.

    The source is ONE ``dspy.Module`` subclass with two coupled methods, and you MUST output the
    entire, internally-consistent class:
      1. ``def __init__(self):`` calling ``super().__init__()`` and assigning the predictors it
         needs. Pick the simplest primitive that fits each step: ``dspy.Predict("...")`` for a
         direct call (the common default), ``dspy.ChainOfThought("...")`` when explicit reasoning
         helps, and ``dspy.RLM`` / ``dspy.ReActV2`` when the step must call tools or explore a
         large/structured input. Assign no predictors at all if the task needs no LM.
      2. ``def forward(self, **inputs):`` that calls those predictors as ``self.<name>`` and
         returns ``dspy.Prediction(<output fields>=...)``.
    Because ``forward`` calls predictors by name, never rename a predictor in one place without
    updating the other.

    Tools are OPTIONAL — use them only when a step genuinely needs one; many good modules are just
    a ``dspy.Predict`` or two plus plain Python. When you do use tools, they come from two places.
    (1) Any listed in ``available_context`` are in scope by name — wire the useful ones into
    ``dspy.RLM(..., tools=[...])`` / ``dspy.ReActV2(..., tools=[...])`` or call them directly
    (reference them by the exact names; do not import or redefine them). If ``available_context``
    is '(no extra context)', no tools were provided — don't reference any.
    (2) AUTHOR your own: when a sub-step needs a capability the provided tools don't cover, define a
    documented helper nested inside ``forward`` and call it directly. Authored helpers live in this
    source, so they are optimized and persisted exactly like the rest of the code. They run in the
    sandbox and cannot be handed to a bridged sub-predictor, so only the provided tools may be wired
    into ``dspy.RLM``/``dspy.ReActV2`` via ``tools=[...]``.

    Optimize the predictors' INSTRUCTIONS, not just the code structure. Each predictor's
    natural-language instructions live in this source — construct a predictor over
    ``dspy.Signature("inputs -> outputs", "instructions")`` and refine those instructions from the
    failing examples and feedback (add a clear task definition, domain knowledge the model lacked,
    the required output format, and rules that prevent the observed errors). These predictors are
    inside a dspy.Flex module, so this source is the ONLY place their prompts get optimized. See the primitives
    catalog's "Writing and refining instructions" section for how. Fix instructions when a failure is about
    WHAT the model should do or know; change the structure when it is about HOW steps are wired.
    """

    task_description: str = dspy.InputField(
        desc="The submodule's Signature: name, objective, input and output fields."
    )
    available_context: str = dspy.InputField(
        desc="Tools (in scope by name) and style notes available to the module. May be "
        "'(no extra context)'."
    )
    primitives_catalog: str = dspy.InputField(
        desc="Catalog of allowed primitives and conventions the revised code must follow."
    )
    current_source: str = dspy.InputField(
        desc="The module's current full source: one dspy.Module subclass (its __init__ and forward)."
    )
    failures: str = dspy.InputField(
        desc="A batch of failing examples and feedback. Diagnose them and revise the module to fix them."
    )
    revised_source: str = dspy.OutputField(
        desc="The full revised module source: one `dspy.Module` subclass with `__init__` (predictors, "
        'including any refined `dspy.Signature(..., "instructions")`) and `forward`.'
    )


def propose_code(
    code_keys: list[str],
    candidate: dict[str, str],
    reflective_dataset: dict[str, list[dict[str, Any]]],
    task_descriptions: dict[str, str],
    context_blurbs: dict[str, str],
    reflection_lm,
) -> dict[str, str]:
    """Propose a revised ``module_src`` for each code component; keep the original on failure."""
    results: dict[str, str] = {}
    proposer = dspy.Predict(CodeProposalSignature)
    with dspy.context(lm=reflection_lm):
        for ckey in code_keys:
            try:
                out = proposer(
                    task_description=task_descriptions.get(ckey, ckey),
                    available_context=context_blurbs.get(ckey, "(no extra context)"),
                    primitives_catalog=PRIMITIVES_CATALOG,
                    current_source=candidate[ckey],
                    failures=_format_failures(reflective_dataset.get(ckey, [])),
                )
                results[ckey] = _strip_code_fences(out.revised_source)
            except LMError:
                raise
            except Exception as e:
                logger.warning("Code proposer failed on %s (%s); keeping original.", ckey, e)
                results[ckey] = candidate[ckey]
    return results


def rebind_flex_code(program, candidate: dict[str, str]) -> None:
    """Rebind ``module_src`` on each ``dspy.Flex`` submodule whose path is in the candidate.

    A candidate that does not parse raises here (``DspyAdapter.evaluate`` catches that and scores
    the batch as a failure); one that parses but breaks at runtime fails per example during
    evaluation, since the code first runs at ``forward``.
    """
    for path, flex in enumerate_flex_submodules(program).items():
        if path in candidate:
            flex._bind_code(candidate[path])


def code_reflective_records(eval_batch) -> list[dict[str, Any]]:
    """Module-level reflective records for a code component (whole-program I/O).

    Unlike instruction components (per-predictor traces), a flex submodule's code is reflected on
    using the whole program's inputs/outputs/feedback per example.
    """
    records: list[dict[str, Any]] = []
    for data in eval_batch.trajectories or []:
        example = data["example"]
        prediction = data["prediction"]
        raw_score = data.get("score")
        if hasattr(raw_score, "score"):
            feedback = raw_score.get("feedback") or ""
            score_val = raw_score["score"]
        else:
            feedback = ""
            score_val = raw_score
        records.append(
            {
                "Inputs": {k: str(v) for k, v in example.inputs().items()},
                "Generated Outputs": _render_prediction(prediction),
                "Feedback": feedback or f"This trajectory got a score of {score_val}.",
            }
        )
    return records


def _metric_scoring_kwargs(metric_fn, program_trace) -> dict[str, Any]:
    """Keyword args for the optional GEPA-contract params ``metric_fn`` declares."""
    try:
        declared = inspect.signature(metric_fn).parameters.keys()
    except (TypeError, ValueError):
        return {}
    values = {"trace": None, "pred_name": None, "pred_trace": None, "program_trace": program_trace}
    return {name: value for name, value in values.items() if name in declared}


def evaluate_with_trace(
    program,
    batch,
    *,
    metric_fn,
    num_threads,
    failure_score,
    callback_metadata,
    capture_traces,
) -> EvaluationBatch:
    """Trace-capturing evaluation used when a flex submodule is present.

    A metric that declares a ``program_trace`` parameter receives the execution trace at
    scoring time (e.g. to penalize LM calls and reward deterministic code); its ``trace``
    argument stays None, preserving the eval-mode semantics of non-Flex GEPA scoring.
    """
    trajs = bootstrap_trace_module.bootstrap_trace_data(
        program=program,
        dataset=batch,
        metric=None,  # capture traces only; we score with the trace just below
        num_threads=num_threads,
        raise_on_error=False,
        capture_failed_parses=True,
        capture_crashes=True,
        failure_score=failure_score,
        format_failure_score=failure_score,
        callback_metadata=callback_metadata,
    )
    outputs: list[Any] = [None] * len(batch)
    scores: list[float] = [failure_score] * len(batch)
    objective_scores: list[dict[str, float]] = [{} for _ in batch]
    for t in trajs:
        pred = t["prediction"]
        outputs[t["example_ind"]] = pred
        if isinstance(pred, FailedPrediction):
            result = failure_score
        else:
            try:
                result = metric_fn(t["example"], pred, **_metric_scoring_kwargs(metric_fn, t["trace"]))
            except Exception as e:
                logger.warning(
                    "Metric raised while scoring an example; scoring it at failure_score: %s: %s",
                    type(e).__name__,
                    e,
                )
                result = failure_score
        t["score"] = result  # make_reflective_dataset reads this for the (trace-aware) feedback
        if isinstance(result, Prediction):
            score = result.score
            objectives = dict(result.get("objective_scores") or {})
        else:
            score = result
            objectives = {}
        scores[t["example_ind"]] = failure_score if score is None else score
        objective_scores[t["example_ind"]] = objectives
    return EvaluationBatch(
        outputs=outputs,
        scores=scores,
        trajectories=trajs if capture_traces else None,
        objective_scores=objective_scores if any(objective_scores) else None,
    )
