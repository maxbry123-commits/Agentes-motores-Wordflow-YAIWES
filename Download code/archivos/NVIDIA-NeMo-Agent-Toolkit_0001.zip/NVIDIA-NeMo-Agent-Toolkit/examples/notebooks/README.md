<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Building an Agentic System using NeMo Agent Toolkit

Through this series of notebooks, we demonstrate how you can use the NVIDIA NeMo Agent Toolkit to build, connect, evaluate, profile, and deploy an agentic system.

We showcase the building blocks that make up the agentic system, including tools, agents, workflows, and observability.

1. [Hello World](hello_world.ipynb) - Installing NeMo Agent Toolkit and running a configuration-only workflow **[🟢 Beginner]**
2. [Getting Started](getting_started_with_nat.ipynb) - Getting started with the NeMo Agent Toolkit **[🟢 Beginner]**
3. [Bringing Your Own Agent](bringing_your_own_agent.ipynb) - Bringing your own agent to the NeMo Agent Toolkit **[🟢 Beginner]**
4. [Adding Tools and Agents](adding_tools_to_agents.ipynb) - Adding tools to your agentic workflow **[🟢 Beginner]**
5. [MCP Client and Servers Setup](mcp_setup_and_integration.ipynb) - Deploy and integrate MCP clients and servers with NeMo Agent Toolkit workflows **[🟢 Beginner]**
6. [Multi-Agent Orchestration](multi_agent_orchestration.ipynb) - Setting up a multi-agent orchestration workflow **[🟨 Intermediate]**
7. [Observability, Evaluation, and Profiling](observability_evaluation_and_profiling.ipynb) - Instrumenting with observability, evaluation and profiling tools **[🟨 Intermediate]**
8. [Optimizing Model Selection, Parameters, and Prompts](optimize_model_selection.ipynb) - Use the NeMo Agent Toolkit Optimizer to compare models, parameters, and prompt variations **[🛑 Advanced]**

We recommend opening these notebooks in a Jupyter Lab environment or Google Colab environment.

We also have a set of notebooks that are designed to be run in a Brev environment. See the [Brev Launchables](./launchables/README.md) for more details.

> **Note on telemetry:** these tutorial notebooks set `NAT_TELEMETRY_ENABLED=false` near the top of each cell sequence so example invocations don't appear in your NeMo Agent Toolkit CLI usage telemetry. Tutorial runs aren't useful analytics signal, and the explicit opt-out keeps notebooks safe even if the headless auto-detection ever regresses. If you're specifically testing the telemetry feature itself, override by exporting `NAT_TELEMETRY_ENABLED=true` before launching Jupyter — the cells use `os.environ.setdefault` so an explicit override wins.

## Google Colab

To open these notebooks in a Google Colab environment, you can click the following link: [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/NVIDIA/NeMo-Agent-Toolkit/)

## Jupyter Lab
If you want to run these notebooks locally, you can clone the repository and open the notebooks in a Jupyter Lab environment. To install the necessary dependencies, you can run the following command:

```bash
uv venv -p 3.13 --seed .venv
source .venv/bin/activate
uv pip install jupyterlab
```

Assuming you have cloned the repository and are in the root directory, you can open the notebooks in a Jupyter Lab environment by running the following command:

```bash
jupyter lab examples/notebooks
```
