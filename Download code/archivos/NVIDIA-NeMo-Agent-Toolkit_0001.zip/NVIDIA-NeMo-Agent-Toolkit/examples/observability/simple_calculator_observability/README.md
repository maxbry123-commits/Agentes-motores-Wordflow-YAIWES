<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Simple Calculator with Observability and Tracing

**Complexity:** 🟨 Intermediate

This example demonstrates how to implement **observability and tracing capabilities** using the NVIDIA NeMo Agent Toolkit. You'll learn to monitor, trace, and analyze your AI agent's behavior in real-time using the Simple Calculator workflow.

## Key Features

- **Multi-Platform Observability Integration:** Demonstrates integration with multiple observability platforms including Phoenix (local), Arize AX (hosted OTLP), MLflow (local), Langfuse, LangSmith, Weave, and Patronus for comprehensive monitoring options.
- **Distributed Tracing Implementation:** Shows how to track agent execution flow across components with detailed trace visualization including agent reasoning, tool calls, and LLM interactions.
- **Performance Monitoring:** Demonstrates capturing latency metrics, token usage, resource consumption, and error tracking for production-ready AI system monitoring.
- **Development and Production Patterns:** Provides examples for both local development tracing (Phoenix) and production monitoring setups with various enterprise observability platforms.
- **Comprehensive Telemetry Collection:** Shows automatic capture of agent thought processes, function invocations, model calls, error events, and custom metadata for complete workflow visibility.

## What You'll Learn

- **Distributed tracing**: Track agent execution flow across components
- **Performance monitoring**: Observe latency, token usage, and system metrics
- **Multi-platform integration**: Connect with popular observability tools
- **Real-time analysis**: Monitor agent behavior during execution
- **Production readiness**: Set up monitoring for deployed AI systems

## Prerequisites

Before starting this example, you need:

1. **Agent toolkit**: Ensure you have the Agent toolkit installed. If you have not already done so, follow the instructions in the [Install Guide](../../../docs/source/get-started/installation.md#install-from-source) to create the development environment and install NeMo Agent Toolkit.
2. **Base workflow**: This example builds upon the Getting Started [Simple Calculator](../../getting_started/simple_calculator/) example. Make sure you are familiar with the example before proceeding.
3. **Observability platform**: Access to at least one of the supported platforms (Phoenix, Arize AX, MLflow, Langfuse, LangSmith, Weave, or Patronus)

## Installation

Install this observability example:

```bash
uv pip install -e examples/observability/simple_calculator_observability
```

## Getting Started

### Phoenix Tracing

Phoenix provides local tracing capabilities perfect for development and testing.

1. Start the Phoenix server in a separate terminal, for this example we will use the `arizephoenix/phoenix` Docker image:

    ```bash
    docker run -it --rm -p 4317:4317 -p 6006:6006 arizephoenix/phoenix:13.22
    ```

2. Run the workflow with tracing enabled:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-phoenix.yml --input "What is 2 * 4?"
    ```

3. Open your browser to `http://localhost:6006` to explore traces in the Phoenix UI.

### Phoenix Tracing with Nested Tool Calls

This configuration demonstrates **parent-child span tracking** for nested tool calls. The `power_of_two` tool internally calls `calculator__multiply`, creating a hierarchy that you can filter in Phoenix.

1. Run the workflow with nested tool tracing:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-phoenix-nested.yml --input "What is 5 squared?"
    ```

2. In Phoenix UI (`http://localhost:6006`), you can filter spans by their parent:

    | Span Attribute | Value | Description |
    |----------------|-------|-------------|
    | `nat.function.parent_name` | `react_agent` | Shows only agent-selected tools |
    | `nat.function.parent_name` | `power_of_two` | Shows nested tool calls |

3. Expected span hierarchy:

    ```text
    react_agent (root)
    └── power_of_two (parent: react_agent)
        └── calculator__multiply (parent: power_of_two)
    ```

This is useful for filtering out internal tool calls when analyzing agent behavior, allowing you to focus on only the tools the agent directly selected.

### Arize AX (hosted OTLP)

Send traces to [Arize AX](https://arize.com/docs/ax/) using the `arize_ax` exporter (`nvidia-nat[opentelemetry]`). This example uses the same OTLP metadata as [Arize OTel](https://arize.com/docs/ax/integrations/opentelemetry/opentelemetry-arize-otel).

1. Set credentials (project name defaults to `simple_calculator` in `config-arize-ax.yml` if `ARIZE_PROJECT_NAME` is unset):

    ```bash
    export ARIZE_SPACE_ID="<your-space-id>"
    export ARIZE_API_KEY="<your-api-key>"
    export ARIZE_PROJECT_NAME="simple_calculator"
    ```

2. Run the workflow:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-arize-ax.yml --input "What is 2 * 4?"
    ```

3. Open the Arize project matching your project name to view traces. For **EU** residency, set `use_eu_region: true` under `arize_ax` in the config file.

### MLflow

Send traces to a local [MLflow](https://mlflow.org/docs/latest/tracing/) tracking server using the `mlflow` exporter (`nvidia-nat[opentelemetry]`). MLflow 3.6+ ingests OTLP spans at `<server>/v1/traces`, routed to an experiment via `x-mlflow-experiment-id`.

1. Start a DB-backed tracking server:

    ```bash
    mlflow server --backend-store-uri sqlite:///mlflow.db --host 127.0.0.1 --port 5000
    ```

2. Run the example:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-mlflow.yml --input "What is 2 * 4?"
    ```

3. Open the MLflow UI at `http://localhost:5000` and view the trace under the experiment's **Traces** tab. Override the target with `MLFLOW_OTLP_ENDPOINT` / `MLFLOW_EXPERIMENT_ID`.

### File-Based Tracing

For simple local development and debugging, you can export traces directly to a local file without requiring any external services.

1. Run the workflow with file-based tracing:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-otel-file.yml --input "What is 2 * 4?"
    ```

2. View the traces in the generated file:

    ```bash
    cat nat_simple_calculator_traces.jsonl
    ```

    The traces are stored in JSON Lines format, with each line representing a complete trace. This is useful for:
    - Quick debugging during development
    - Offline analysis of workflow execution
    - Integration with custom analysis tools
    - Archiving traces for later review

### Langfuse Integration

[Langfuse](https://langfuse.com/) provides production-ready monitoring and analytics.

1. Get your Langfuse credentials:

    Under your project settings, you can create your API key. Doing this will give you three credentials:
    - Secret Key
    - Public Key
    - Host

    Take note of these credentials as you will need them to run the workflow.

2. Set your Langfuse credentials:

    ```bash
    export LANGFUSE_PUBLIC_KEY=<your_key>
    export LANGFUSE_SECRET_KEY=<your_secret>
    export LANGFUSE_BASE_URL=<your_base_url>
    ```

3. Run the workflow:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-langfuse.yml --input "Calculate 15 + 23"
    ```

### LangSmith Integration

[LangSmith](https://smith.langchain.com/) offers comprehensive monitoring within the LangChain/LangGraph ecosystem.

0. Get your LangSmith API key and project name:

    **API Key**:

    Once logged in, you can navigate to the settings page, then click on "API Keys".

    You can create a new API key by clicking on the "Create API Key" button. Be sure to choose the "Personal Access Token" option. Choose a workspace name and a description. Then click on the "Create" button.

    Take note of the API key as you will need it to run the workflow.

1. Set your LangSmith credentials:

    ```bash
    export LANGSMITH_API_KEY=<your_api_key>
    ```

2. Run the workflow:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-langsmith.yml --input "Is 100 > 50?"
    ```

    This workflow is set to use the `default` LangSmith project. If you want to use a different project, you can either edit the config file or add the following flag to the above command: `--override general.telemetry.tracing.langsmith.project <your_project_name>`

    > [!NOTE]
    > This workflow happens to use LangChain, since that library has built-in support for LangSmith, if you run the above workflow with the `LANGSMITH_TRACING=true` environment variable set, will result in duplicate traces being sent to LangSmith.

### Weave Integration

[Weave](https://wandb.ai/site/weave/) provides detailed workflow tracking and visualization.

0. Get your Weights & Biases API key:

    Login to [Weights & Biases](https://wandb.ai/site/weave/) and navigate to the settings page.

    Under the "Account" section, you can find your API key. Click on the "Show" button to reveal the API key. Take note of this API key as you will need it to run the workflow.

1. Set your Weights & Biases API key:

    ```bash
    export WANDB_API_KEY=<your_api_key>
    ```

2. Run the workflow:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-weave.yml --input "What's the sum of 7 and 8?"
    ```

For detailed Weave setup instructions, refer to the [Fine-grained Tracing with Weave](../../../docs/source/run-workflows/observe/observe-workflow-with-weave.md) guide.

### AI Safety Monitoring with Patronus

[Patronus](https://patronus.ai/) enables AI safety monitoring and compliance tracking.

1. Get your Patronus API key:

    Login to [Patronus](https://patronus.ai/) and navigate to the settings page.

    Click on the "API Keys" section on the left sidebar. Then click on the "Create API Key" button. Choose a name and a description. Then click on the "Create" button.

    Take note of the API key as you will need it to run the workflow.

2. Set your Patronus API key:

    ```bash
    export PATRONUS_API_KEY=<your_api_key>
    ```

3. Run the workflow:

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-patronus.yml --input "Divide 144 by 12"
    ```

### Galileo Integration

Transmit traces to Galileo for workflow observability.

1. Sign up for Galileo and create project

    - Visit [https://app.galileo.ai/](https://app.galileo.ai/) to create your account or sign in.
    - Create a project named `simple_calculator` and use default log stream
    - Create your API key

2. Set your Galileo credentials:

    ```bash
    export GALILEO_API_KEY=<your_api_key>
    ```

3. Run the workflow

    ```bash
    nat run --config_file examples/observability/simple_calculator_observability/configs/config-galileo.yml --input "Is 100 > 50?"
    ```


## Configuration Files

The example includes multiple configuration files for different observability platforms:

| Configuration File | Platform | Best For |
|-------------------|----------|----------|
| `config-phoenix.yml` | Phoenix | Tracing with Phoenix |
| `config-phoenix-nested.yml` | Phoenix | Testing parent-child span tracking with nested tool calls |
| `config-arize-ax.yml` | Arize AX | Hosted OTLP tracing to Arize AX (requires `ARIZE_*` environment variables) |
| `config-mlflow.yml` | MLflow | Local OTLP tracing to an MLflow tracking server |
| `config-otel-file.yml` | File Export | Local file-based tracing for development and debugging |
| `config-langfuse.yml` | Langfuse | Langfuse monitoring and analytics |
| `config-langsmith.yml` | LangSmith | LangChain/LangGraph ecosystem integration |
| `config-weave.yml` | Weave | Workflow-focused tracking |
| `config-patronus.yml` | Patronus | AI safety and compliance monitoring |
| `config-galileo.yml` | Galileo | Galileo integration |

## What Gets Traced

The Agent toolkit captures comprehensive telemetry data including:

- **Agent reasoning**: ReAct agent thought processes and decision-making
- **Tool calls**: Function invocations, parameters, and responses
- **LLM interactions**: Model calls, token usage, and latency metrics
- **Error events**: Failures, exceptions, and recovery attempts
- **Custom metadata**: Request context, user information, and custom attributes

## Key Features Demonstrated

- **Trace visualization**: Complete execution paths and call hierarchies
- **Performance metrics**: Response times, token usage, and resource consumption
- **Error tracking**: Automated error detection and diagnostic information
- **Multi-platform support**: Flexibility to choose the right observability tool
- **Production monitoring**: Real-world deployment observability patterns
