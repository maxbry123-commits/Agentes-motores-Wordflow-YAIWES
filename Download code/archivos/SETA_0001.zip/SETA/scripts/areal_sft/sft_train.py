import os
import sys
from pathlib import Path

import torch.distributed as dist

# Make this script's directory importable so we can pull in the local
# seta_sft_dataset loader without needing to install it as a package.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from areal.api.alloc_mode import AllocationMode
from areal.api.cli_args import SFTConfig, load_expr_config
from areal.api.io_struct import FinetuneSpec, StepInfo
from areal.engine.sft.lm_engine import FSDPLMEngine
from areal.platforms import current_platform
from areal.utils import seeding, stats_tracker
from areal.utils.data import (
    broadcast_tensor_container,
    pad_sequences_to_tensors,
    tensor_container_to,
)
from areal.utils.dataloader import create_dataloader
from areal.utils.evaluator import Evaluator
from areal.utils.hf_utils import load_hf_tokenizer
from areal.utils.recover import RecoverHandler
from areal.utils.saver import Saver
from areal.utils.stats_logger import StatsLogger

# Local seta SFT dataset loader. Reads JSONL produced by
# seta_env.utils.sft_utils.build_sft_dataset and returns a HuggingFace
# Dataset with exactly two columns — input_ids and loss_mask — which is the
# row format AREAL's pad_sequences_to_tensors collator expects.
from seta_sft_dataset import get_seta_sft_dataset  # noqa: E402


def main(args):
    config, _ = load_expr_config(args, SFTConfig)

    rank = int(os.getenv("RANK"))

    seeding.set_random_seed(config.seed, f"trainer{rank}")
    allocation_mode = AllocationMode.from_str(config.allocation_mode)
    parallel_strategy = allocation_mode.train

    engine = FSDPLMEngine(config=config.model)
    engine.create_process_group(parallel_strategy=parallel_strategy)

    tokenizer = load_hf_tokenizer(config.tokenizer_path)

    # Create dataset and dataloaders.
    # Direct call to our custom loader (no AREAL dispatch indirection): it
    # reads our JSONL and returns a Dataset with (input_ids, loss_mask),
    # which is exactly what pad_sequences_to_tensors collates.
    train_dataset = get_seta_sft_dataset(
        path=config.train_dataset.path,
        split="train",
        tokenizer=tokenizer,
        max_length=config.train_dataset.max_length,
    )
    valid_dataset = get_seta_sft_dataset(
        path=config.valid_dataset.path,
        split="test",
        tokenizer=tokenizer,
        max_length=config.valid_dataset.max_length,
    )

    train_dataloader = create_dataloader(
        train_dataset,
        rank=engine.data_parallel_rank,
        world_size=engine.data_parallel_world_size,
        dataset_config=config.train_dataset,
        collate_fn=pad_sequences_to_tensors,
    )
    valid_dataloader = create_dataloader(
        valid_dataset,
        rank=engine.data_parallel_rank,
        world_size=engine.data_parallel_world_size,
        dataset_config=config.valid_dataset,
        collate_fn=pad_sequences_to_tensors,
    )

    # Initialize engine
    ft_spec = FinetuneSpec(
        total_train_epochs=config.total_train_epochs,
        dataset_size=len(train_dataloader) * config.train_dataset.batch_size,
        train_batch_size=config.train_dataset.batch_size,
    )
    engine.initialize(None, ft_spec)

    # Run training.
    saver = Saver(config.saver, ft_spec)
    stats_logger = StatsLogger(config, ft_spec)
    evaluator = Evaluator(config.evaluator, ft_spec)

    recover_handler = RecoverHandler(config.recover, ft_spec)
    recover_info = recover_handler.load(
        engine,
        saver,
        evaluator,
        stats_logger,
        train_dataloader,
    )
    start_step = (
        recover_info.last_step_info.next().global_step
        if recover_info is not None
        else 0
    )

    total_epochs = config.total_train_epochs

    global_step = 0
    for epoch in range(total_epochs):
        for step, data in enumerate(train_dataloader):
            if global_step < start_step:
                global_step += 1
                continue
            step_info = StepInfo(
                global_step=global_step,
                epoch=epoch,
                epoch_step=step,
                steps_per_epoch=len(train_dataloader),
            )

            with stats_tracker.record_timing("to_device"):
                # NOTE: data are identical across model+context parallel group
                data = tensor_container_to(data, current_platform.current_device())

            with stats_tracker.record_timing("bcast"):
                data = broadcast_tensor_container(
                    data,
                    src_rank=engine.current_data_parallel_head(),
                    group=engine.context_and_model_parallel_group,
                )

            with stats_tracker.record_timing("train_step"):
                engine.train_lm(data)
                engine.step_lr_scheduler()

            with stats_tracker.record_timing("save"):
                saver.save(engine, epoch, step, global_step, tokenizer=tokenizer)

            with stats_tracker.record_timing("checkpoint_for_recover"):
                recover_handler.dump(
                    engine,
                    step_info,
                    saver,
                    evaluator,
                    stats_logger,
                    train_dataloader,
                    tokenizer=tokenizer,
                )

            current_platform.synchronize()
            dist.barrier(group=engine.cpu_group)

            with stats_tracker.record_timing("eval"):
                # No need to log anything. Logging will be handled outside
                # via stats_tracker.export().
                def evaluate_fn():
                    for data in valid_dataloader:
                        data = tensor_container_to(
                            data, current_platform.current_device()
                        )
                        data = broadcast_tensor_container(
                            data,
                            src_rank=engine.current_data_parallel_head(),
                            group=engine.context_and_model_parallel_group,
                        )
                        engine.evaluate_lm(data)

                evaluator.evaluate(
                    evaluate_fn,
                    epoch,
                    step,
                    global_step,
                )

            current_platform.synchronize()
            dist.barrier(group=engine.cpu_group)

            stats_logger.commit(
                epoch,
                step,
                global_step,
                stats_tracker.export(reduce_group=engine.data_parallel_group),
            )
            global_step += 1

    stats_logger.close()
    engine.destroy()


if __name__ == "__main__":
    main(sys.argv[1:])
