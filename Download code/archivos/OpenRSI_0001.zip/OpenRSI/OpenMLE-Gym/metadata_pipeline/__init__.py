"""OpenMLE Gym metadata pipeline."""
