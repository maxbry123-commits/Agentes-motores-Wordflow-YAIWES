"""Metadata pipeline utilities."""
