#include "../node_context.h"
#include "../op_table.h"
#include "../utils.h"

#include <openvino/core/node_output.hpp>
#include <openvino/op/multiply.hpp>
#include <openvino/op/sigmoid.hpp>

namespace ov {
namespace frontend {
namespace ggml {
namespace op {

OutputVector translate_unary_silu(const NodeContext & context) {
    num_inputs_check(context, 1, 1);

    auto input = process_view_input_new(context, 0);
    auto sigmoid = std::make_shared<ov::op::v0::Sigmoid>(input);
    auto res = std::make_shared<ov::op::v1::Multiply>(input, sigmoid);

    return rename_outputs_with_suffix({res}, context.get_name());
}

}  // namespace op
}  // namespace ggml
}  // namespace frontend
}  // namespace ov
