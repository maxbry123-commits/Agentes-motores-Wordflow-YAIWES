/**
 * Comprehensive dictionary of all supported file types in llama-ui
 * Organized by category with TypeScript enums for better type safety
 */

// File type category enum
export enum FileTypeCategory {
	IMAGE = 'image',
	AUDIO = 'audio',
	VIDEO = 'video',
	PDF = 'pdf',
	TEXT = 'text'
}

/**
 * Special file types for internal use (not MIME types)
 */
export enum SpecialFileType {
	MCP_PROMPT = 'mcp-prompt'
}

// Specific file type enums for each category
export enum FileTypeImage {
	JPEG = 'jpeg',
	PNG = 'png',
	GIF = 'gif',
	WEBP = 'webp',
	SVG = 'svg',
	HEIC = 'heic',
	HEIF = 'heif'
}

export enum FileTypeAudio {
	MP3 = 'mp3',
	WAV = 'wav',
	WEBM = 'webm'
}

export enum FileTypeVideo {
	MP4 = 'mp4',
	OGG = 'ogg'
}

export enum FileTypePdf {
	PDF = 'pdf'
}

export enum FileTypeText {
	PLAIN_TEXT = 'plainText',
	MARKDOWN = 'md',
	ASCIIDOC = 'asciidoc',
	JAVASCRIPT = 'js',
	TYPESCRIPT = 'ts',
	JSX = 'jsx',
	TSX = 'tsx',
	CSS = 'css',
	HTML = 'html',
	JSON = 'json',
	XML = 'xml',
	YAML = 'yaml',
	CSV = 'csv',
	LOG = 'log',
	PYTHON = 'python',
	JAVA = 'java',
	CPP = 'cpp',
	PHP = 'php',
	RUBY = 'ruby',
	GO = 'go',
	RUST = 'rust',
	SHELL = 'shell',
	SQL = 'sql',
	R = 'r',
	SCALA = 'scala',
	KOTLIN = 'kotlin',
	SWIFT = 'swift',
	DART = 'dart',
	VUE = 'vue',
	SVELTE = 'svelte',
	LATEX = 'latex',
	BIBTEX = 'bibtex',
	CUDA = 'cuda',
	VULKAN = 'vulkan',
	HASKELL = 'haskell',
	CSHARP = 'csharp',
	PROPERTIES = 'properties'
}

// File extension enums
export enum FileExtensionImage {
	JPG = '.jpg',
	JPEG = '.jpeg',
	PNG = '.png',
	GIF = '.gif',
	WEBP = '.webp',
	SVG = '.svg',
	HEIC = '.heic',
	HEIF = '.heif'
}

export enum FileExtensionAudio {
	MP3 = '.mp3',
	WAV = '.wav'
}

export enum FileExtensionVideo {
	MP4 = '.mp4',
	OGG = '.ogg'
}

export enum FileExtensionPdf {
	PDF = '.pdf'
}

export enum FileExtensionText {
	TXT = '.txt',
	MD = '.md',
	ADOC = '.adoc',
	JS = '.js',
	TS = '.ts',
	JSX = '.jsx',
	TSX = '.tsx',
	CSS = '.css',
	HTML = '.html',
	HTM = '.htm',
	JSON = '.json',
	JSONL = '.jsonl',
	ZIP = '.zip',
	XML = '.xml',
	YAML = '.yaml',
	YML = '.yml',
	CSV = '.csv',
	LOG = '.log',
	PY = '.py',
	JAVA = '.java',
	CPP = '.cpp',
	C = '.c',
	H = '.h',
	PHP = '.php',
	RB = '.rb',
	GO = '.go',
	RS = '.rs',
	SH = '.sh',
	BAT = '.bat',
	SQL = '.sql',
	R = '.r',
	SCALA = '.scala',
	KT = '.kt',
	SWIFT = '.swift',
	DART = '.dart',
	VUE = '.vue',
	SVELTE = '.svelte',
	TEX = '.tex',
	BIB = '.bib',
	CU = '.cu',
	CUH = '.cuh',
	COMP = '.comp',
	HPP = '.hpp',
	HS = '.hs',
	PROPERTIES = '.properties',
	CS = '.cs'
}

// MIME type prefixes and includes for content detection
export enum MimeTypePrefix {
	IMAGE = 'image/',
	TEXT = 'text'
}

export enum MimeTypeIncludes {
	JSON = 'json',
	JAVASCRIPT = 'javascript',
	TYPESCRIPT = 'typescript'
}

// URI patterns for content detection
export enum UriPattern {
	DATABASE_KEYWORD = 'database',
	DATABASE_SCHEME = 'db://'
}

// MIME type enums
export enum MimeTypeApplication {
	JSON = 'application/json',
	PDF = 'application/pdf',
	OCTET_STREAM = 'application/octet-stream',
	ZIP = 'application/zip'
}

export enum MimeTypeAudio {
	MP3_MPEG = 'audio/mpeg',
	MP3 = 'audio/mp3',
	MP4 = 'audio/mp4',
	WAV = 'audio/wav',
	WAVE = 'audio/wave',
	X_WAV = 'audio/x-wav',
	X_WAVE = 'audio/x-wave',
	VND_WAVE = 'audio/vnd.wave',
	X_PN_WAV = 'audio/x-pn-wav',
	WEBM = 'audio/webm',
	WEBM_OPUS = 'audio/webm;codecs=opus'
}

export enum MimeTypeVideo {
	MP4 = 'video/mp4',
	OGG = 'video/ogg'
}

export enum MimeTypeImage {
	JPEG = 'image/jpeg',
	JPG = 'image/jpg',
	PNG = 'image/png',
	GIF = 'image/gif',
	WEBP = 'image/webp',
	SVG = 'image/svg+xml',
	ICO = 'image/x-icon',
	ICO_MICROSOFT = 'image/vnd.microsoft.icon',
	HEIC = 'image/heic',
	HEIF = 'image/heif'
}

export enum MimeTypeText {
	PLAIN = 'text/plain',
	MARKDOWN = 'text/markdown',
	ASCIIDOC = 'text/asciidoc',
	JAVASCRIPT = 'text/javascript',
	JAVASCRIPT_APP = 'application/javascript',
	TYPESCRIPT = 'text/typescript',
	JSX = 'text/jsx',
	TSX = 'text/tsx',
	CSS = 'text/css',
	HTML = 'text/html',
	JSON = 'application/json',
	JSONL = 'application/jsonl',
	XML_TEXT = 'text/xml',
	XML_APP = 'application/xml',
	YAML_TEXT = 'text/yaml',
	YAML_APP = 'application/yaml',
	CSV = 'text/csv',
	PYTHON = 'text/x-python',
	JAVA = 'text/x-java-source',
	CPP_HDR = 'text/x-c++hdr',
	CPP_SRC = 'text/x-c++src',
	CSHARP = 'text/x-csharp',
	HASKELL = 'text/x-haskell',
	C_SRC = 'text/x-csrc',
	C_HDR = 'text/x-chdr',
	PHP = 'text/x-php',
	RUBY = 'text/x-ruby',
	GO = 'text/x-go',
	RUST = 'text/x-rust',
	SHELL = 'text/x-shellscript',
	BAT = 'application/x-bat',
	SQL = 'text/x-sql',
	R = 'text/x-r',
	SCALA = 'text/x-scala',
	KOTLIN = 'text/x-kotlin',
	SWIFT = 'text/x-swift',
	DART = 'text/x-dart',
	VUE = 'text/x-vue',
	SVELTE = 'text/x-svelte',
	TEX = 'text/x-tex',
	TEX_APP = 'application/x-tex',
	LATEX = 'application/x-latex',
	BIBTEX = 'text/x-bibtex',
	CUDA = 'text/x-cuda',
	PROPERTIES = 'text/properties'
}
