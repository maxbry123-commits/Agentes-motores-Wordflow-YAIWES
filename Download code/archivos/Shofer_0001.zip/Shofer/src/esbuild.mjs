import * as esbuild from "esbuild"
import * as fs from "fs"
import * as path from "path"
import { fileURLToPath } from "url"
import process from "node:process"
import { execSync } from "node:child_process"
import * as console from "node:console"

import { copyPaths, copyWasms } from "@shofer/build"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

/**
 * Build flavor: `SHOFER_NO_BUNDLED_PLUGINS=1` (or `true`) produces an extension with
 * NO first-party bundled plugins — the packaging step skips both the `plugins/**` →
 * `dist/plugins` copy and each bundled plugin's UI build. For hosts/embedders that
 * supply their entire plugin set out-of-band (e.g. via the global scope
 * `~/.shofer/plugins`). The default build (marketplace) ships all bundled plugins.
 * The headless CLI/`serve` runtime consumes this same `src/dist` output
 * (getDefaultExtensionPath → `src/dist`; the CLI release copies `src/dist/*`
 * wholesale), so the flag governs that artifact too. The plugin SDK
 * (`dist/plugin-sdk`) still ships: global/project code plugins need it regardless.
 */
const NO_BUNDLED_PLUGINS = ["1", "true"].includes(process.env.SHOFER_NO_BUNDLED_PLUGINS ?? "")

/** Directory/file names never shipped into a packaged plugin (dev-only cruft). */
const PLUGIN_COPY_EXCLUDE_DIRS = new Set(["node_modules", "__tests__"])
const PLUGIN_COPY_EXCLUDE_FILES = new Set(["tsconfig.json", "vitest.config.ts", "build-ui.mjs"])
const PLUGIN_COPY_EXCLUDE_EXT = new Set([".tsx"]) // built .js ships; .tsx source doesn't.

/**
 * Pre-bundle `@shofer/types` into a self-contained ESM module the runtime plugin
 * loader can resolve. Code plugins import their SDK surface from `@shofer/types`
 * (`defineCustomTool`, `parametersSchema`/zod, `PLUGIN_API_VERSION`, types …) and the
 * loader **bundles** that in via esbuild. In dev the workspace `node_modules` resolves
 * it; the installed VSIX ships no resolvable `@shofer/types`, so we emit one here.
 *
 * `@shofer/types`'s own `dist/index.js` externalizes zod/@anthropic-ai/sdk/etc., so we
 * can't drop it as-is — we re-bundle with dependencies inlined (exactly what the main
 * extension bundle already does for the same package) into a single dependency-free
 * file. The loader's `nodePaths` (wired in ShoferProvider) points at the parent
 * `node_modules` so a bare `@shofer/types` import resolves here.
 */
async function buildPluginSdk(srcDir, distDir) {
	const typesEntry = path.join(srcDir, "..", "packages", "types", "dist", "index.js")
	const sdkPkgDir = path.join(distDir, "plugin-sdk", "node_modules", "@shofer", "types")
	fs.mkdirSync(sdkPkgDir, { recursive: true })
	await esbuild.build({
		entryPoints: [typesEntry],
		outfile: path.join(sdkPkgDir, "index.js"),
		format: "esm",
		platform: "node",
		target: "node18",
		bundle: true,
		// Inline every dependency (zod, @anthropic-ai/sdk, …) so the shipped module is
		// self-contained; node built-ins stay external automatically for platform:node.
		logLevel: "silent",
	})
	fs.writeFileSync(
		path.join(sdkPkgDir, "package.json"),
		JSON.stringify(
			{
				name: "@shofer/types",
				version: "0.0.0",
				type: "module",
				main: "index.js",
				module: "index.js",
				exports: { ".": "./index.js" },
			},
			null,
			2,
		),
	)
}

/**
 * Recursively copy the first-party plugins tree into the packaged output, skipping
 * dev-only cruft. Runtime needs each plugin's `plugin.json`, its `main` .ts sources
 * (the code loader transpiles them at load), built UI bundles (`ui/panel.js`), and
 * the skills/commands markdown — everything except {@link PLUGIN_COPY_EXCLUDE_DIRS}
 * / {@link PLUGIN_COPY_EXCLUDE_FILES} / {@link PLUGIN_COPY_EXCLUDE_EXT}.
 */
function copyBundledPlugins(srcRoot, dstRoot) {
	if (!fs.existsSync(srcRoot)) {
		console.warn(`[esbuild] No plugins dir to bundle at ${srcRoot} — skipping.`)
		return
	}
	let count = 0
	/**
	 * A plugin whose manifest `main` is a BUILT entry (`main.mjs`) does not ship its
	 * TypeScript: the built file already contains it, and copying the sources both bloats
	 * the VSIX and drops files into `dist/` that the extension's own tsconfig then tries
	 * to typecheck — with imports that only resolve inside the monorepo.
	 */
	const shipsBuiltEntry = (pluginRoot) => {
		try {
			const manifest = JSON.parse(fs.readFileSync(path.join(pluginRoot, "plugin.json"), "utf8"))
			return /\.(mjs|js)$/.test(String(manifest.main ?? ""))
		} catch {
			return false
		}
	}
	const walk = (src, dst, pluginRoot) => {
		fs.mkdirSync(dst, { recursive: true })
		for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
			if (entry.isDirectory()) {
				if (PLUGIN_COPY_EXCLUDE_DIRS.has(entry.name)) continue
				// One level below the plugins root, each directory IS a plugin root.
				const nextRoot = pluginRoot ?? path.join(src, entry.name)
				if (entry.name === "src" && pluginRoot && shipsBuiltEntry(pluginRoot)) continue
				walk(path.join(src, entry.name), path.join(dst, entry.name), nextRoot)
			} else if (entry.isFile()) {
				if (PLUGIN_COPY_EXCLUDE_FILES.has(entry.name)) continue
				if (PLUGIN_COPY_EXCLUDE_EXT.has(path.extname(entry.name))) continue
				fs.copyFileSync(path.join(src, entry.name), path.join(dst, entry.name))
				count++
			}
		}
	}
	walk(srcRoot, dstRoot, undefined)
	console.log(`[esbuild] Copied ${count} bundled-plugin files to ${dstRoot}`)
}

/**
 * Build each bundled plugin's webview UI bundle(s) from source before packaging, so a
 * plugin is one self-contained, always-current unit — its logic (`.ts`, transpiled at
 * runtime) and its UI (`.tsx` → `.js`, browser ESM with React externalized) are built
 * together on every `pnpm bundle`, never a stale hand-run artifact. A plugin opts in by
 * shipping a `build-ui.mjs` (run from its own dir); a UI build failure fails the whole
 * build (fail-closed) rather than silently shipping stale UI.
 */
function buildBundledPluginUis(pluginsRoot) {
	if (!fs.existsSync(pluginsRoot)) return
	for (const entry of fs.readdirSync(pluginsRoot, { withFileTypes: true })) {
		if (!entry.isDirectory()) continue
		const pluginDir = path.join(pluginsRoot, entry.name)
		if (!fs.existsSync(path.join(pluginDir, "build-ui.mjs"))) continue
		try {
			execSync("node build-ui.mjs", { cwd: pluginDir, stdio: "pipe" })
			console.log(`[esbuild] Built UI bundle(s) for plugin "${entry.name}"`)
		} catch (err) {
			console.error(`[esbuild] ERROR: failed to build UI for plugin "${entry.name}": ${err.message}`)
			process.exit(1)
		}
	}
}

async function main() {
	const name = "extension"
	const production = process.argv.includes("--production")
	const watch = process.argv.includes("--watch")
	const minify = production
	const sourcemap = !production // Only in dev/watch; production VSIX doesn't ship maps.

	/**
	 * @type {import('esbuild').BuildOptions}
	 */
	const buildOptions = {
		bundle: true,
		minify,
		sourcemap,
		logLevel: "silent",
		format: "cjs",
		sourcesContent: false,
		platform: "node",
	}

	const srcDir = __dirname
	const buildDir = __dirname
	const distDir = path.join(buildDir, "dist")

	if (fs.existsSync(distDir)) {
		console.log(`[${name}] Cleaning dist directory: ${distDir}`)
		fs.rmSync(distDir, { recursive: true, force: true })
	}

	/**
	 * @type {import('esbuild').Plugin[]}
	 */
	const plugins = [
		{
			name: "copyFiles",
			setup(build) {
				build.onEnd(() => {
					copyPaths(
						[
							["../README.md", "README.md"],
							["../CHANGELOG.md", "CHANGELOG.md"],
							["../LICENSE", "LICENSE"],
							["../.env", ".env", { optional: true }],
							["node_modules/vscode-material-icons/generated", "assets/vscode-material-icons"],
							["../webview-ui/audio", "webview-ui/audio"],
						],
						srcDir,
						buildDir,
					)
					// Copy the sandbox wrapper binary so it is available
					// alongside the extension bundle in dist/.  The binary is
					// a prebuilt Go artifact at src/sandbox/shofer-sandbox.
					// Build the sandbox wrapper from Go source (no prebuilt binary
					// committed to git).  Requires `go` on $PATH; fails the build
					// if compilation doesn't succeed so the packaging step never
					// ships an extension without the binary.
					const sandboxDir = path.join(srcDir, "sandbox")
					const sandboxSrc = path.join(sandboxDir, "main.go")
					const sandboxBin = path.join(sandboxDir, "shofer-sandbox")
					const sandboxDestDir = path.join(distDir, "sandbox")
					const sandboxDest = path.join(sandboxDestDir, "shofer-sandbox")

					try {
						execSync("go build -o shofer-sandbox .", {
							cwd: sandboxDir,
							env: { ...process.env, GOWORK: "off", CGO_ENABLED: "0" },
							stdio: "pipe",
						})
					} catch (err) {
						console.error(`[esbuild] ERROR: failed to build shofer-sandbox: ${err.message}`)
						process.exit(1)
					}

					if (!fs.existsSync(sandboxBin)) {
						console.error(`[esbuild] ERROR: shofer-sandbox not found after build at ${sandboxBin}`)
						process.exit(1)
					}

					fs.mkdirSync(sandboxDestDir, { recursive: true })
					fs.copyFileSync(sandboxBin, sandboxDest)
					fs.chmodSync(sandboxDest, 0o755)
					// Ship the esbuild-wasm CLI so the runtime loader can transpile
					// TypeScript at `<extensionPath>/dist/bin/esbuild` (the production
					// path in custom-tools/esbuild-runner.ts getEsbuildScriptPath). This
					// is what custom tools AND bundled code plugins (e.g. the live-memory
					// plugin, transpiled at activation) rely on — without it the loader
					// falls back to node_modules, which isn't resolvable from the bundled
					// CJS extension host. The wasm shim resolves `../esbuild.wasm` and
					// `../wasm_exec_node.js` relative to itself, and that in turn
					// `require("./wasm_exec")`, so the wasm blob and both Go loader
					// scripts must sit one level up, at the dist/ root.
					const esbuildWasmDir = path.join(srcDir, "node_modules", "esbuild-wasm")
					const esbuildBinDest = path.join(distDir, "bin")
					fs.mkdirSync(esbuildBinDest, { recursive: true })
					fs.copyFileSync(path.join(esbuildWasmDir, "bin", "esbuild"), path.join(esbuildBinDest, "esbuild"))
					fs.copyFileSync(path.join(esbuildWasmDir, "esbuild.wasm"), path.join(distDir, "esbuild.wasm"))
					fs.copyFileSync(
						path.join(esbuildWasmDir, "wasm_exec_node.js"),
						path.join(distDir, "wasm_exec_node.js"),
					)
					fs.copyFileSync(path.join(esbuildWasmDir, "wasm_exec.js"), path.join(distDir, "wasm_exec.js"))
					// Ship the first-party (bundled) plugins tree into dist/plugins so the
					// runtime resolves it at `<extensionPath>/dist/plugins` (design §7 —
					// bundled scope). Mirrors the tree-sitter-wasm copy above. The P2 code
					// loader transpiles each plugin's `main` (e.g. main.ts) at runtime, so the
					// .ts SOURCES must ship — we copy everything except dev-only cruft
					// (node_modules, __tests__, tsconfig/vitest/build scripts, .tsx sources
					// whose built .js is already present).
					//
					// Build each plugin's UI bundle(s) from source FIRST so logic + UI ship
					// together as one current unit (no stale hand-built .js).
					//
					// Under SHOFER_NO_BUNDLED_PLUGINS both steps are skipped: the runtime
					// tolerates the absent `dist/plugins` (discovery finds nothing there and
					// the built-in tier simply does not exist — the host's own scopes supply
					// every plugin, including modes).
					if (NO_BUNDLED_PLUGINS) {
						console.log(
							"[esbuild] SHOFER_NO_BUNDLED_PLUGINS set — skipping bundled plugins (no dist/plugins, no plugin UI builds)",
						)
					} else {
						buildBundledPluginUis(path.join(srcDir, "..", "plugins"))
						copyBundledPlugins(path.join(srcDir, "..", "plugins"), path.join(distDir, "plugins"))
					}
				})
			},
		},
		{
			name: "copyWasms",
			setup(build) {
				build.onEnd(() => copyWasms(srcDir, distDir))
			},
		},
		{
			name: "esbuild-problem-matcher",
			setup(build) {
				build.onStart(() => console.log("[esbuild-problem-matcher#onStart]"))
				build.onEnd((result) => {
					result.errors.forEach(({ text, location }) => {
						console.error(`✘ [ERROR] ${text}`)
						if (location && location.file) {
							console.error(`    ${location.file}:${location.line}:${location.column}:`)
						}
					})

					console.log("[esbuild-problem-matcher#onEnd]")
				})
			},
		},
	]

	/**
	 * @type {import('esbuild').BuildOptions}
	 */
	const extensionConfig = {
		...buildOptions,
		plugins,
		entryPoints: ["extension.ts"],
		outfile: "dist/extension.js",
		// Prepend the navigator shim so it runs before any bundled module evaluates
		// (neutralizes VS Code's throwing `navigator` proxy in the Node ext host;
		// see navigator-shim.js). Then define a CJS-safe `import.meta.url`: bundled ESM
		// deps (notably web-tree-sitter's Emscripten glue) call
		// `createRequire(import.meta.url)`, but `import.meta` is `{}` in CJS output, so
		// that becomes `createRequire(undefined)` and throws — breaking ALL tree-sitter
		// code indexing. Point it at the bundle's own file URL (dist/extension.js), which
		// also makes web-tree-sitter resolve `tree-sitter.wasm` from dist/ (where it ships).
		banner: {
			js:
				fs.readFileSync(path.join(__dirname, "navigator-shim.js"), "utf8") +
				"\nconst __shoferImportMetaUrl = require('url').pathToFileURL(__filename).href;\n",
		},
		define: {
			...buildOptions.define,
			"import.meta.url": "__shoferImportMetaUrl",
		},
		// global-agent must be external because it dynamically patches Node.js http/https modules
		// which breaks when bundled. It needs access to the actual Node.js module instances.
		// undici must be bundled because our VSIX is packaged with `--no-dependencies`.
		external: ["vscode", "esbuild", "global-agent"],
	}

	/**
	 * @type {import('esbuild').BuildOptions}
	 */
	// Phase 1 worker modules (server-worker, agent-worker, worker-extension-host)
	// are compiled by vitest/tsc for tests; they are NOT bundled into dist/ yet.
	// They will be added as entry points before Phase 2 spawns actual worker_threads
	// (see docs/multi_threaded.md §9 "esbuild entry points").
	const workerConfig = {
		...buildOptions,
		entryPoints: ["workers/countTokens.ts", "workers/exportJson.ts"],
		outdir: "dist/workers",
	}

	const [extensionCtx, workerCtx] = await Promise.all([
		esbuild.context(extensionConfig),
		esbuild.context(workerConfig),
	])

	if (watch) {
		await Promise.all([extensionCtx.watch(), workerCtx.watch()])
		await buildPluginSdk(srcDir, distDir)
	} else {
		await Promise.all([extensionCtx.rebuild(), workerCtx.rebuild()])
		// After the extension bundle exists, emit the self-contained @shofer/types SDK
		// so bundled/installed code plugins can resolve it at load time.
		await buildPluginSdk(srcDir, distDir)
		await Promise.all([extensionCtx.dispose(), workerCtx.dispose()])
	}
}

main().catch((e) => {
	console.error(e)
	process.exit(1)
})
