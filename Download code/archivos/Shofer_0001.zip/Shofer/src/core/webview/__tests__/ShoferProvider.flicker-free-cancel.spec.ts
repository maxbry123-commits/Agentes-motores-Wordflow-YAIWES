import { beforeEach, describe, expect, it, vi } from "vitest"
import * as vscode from "vscode"

// Break the transitive import chain through extension.ts,
// which pulls in ContextDropZoneProvider (extends vscode.TreeItem).
vi.mock("../../../extension", () => ({}))

import { ShoferProvider } from "../ShoferProvider"
import { Task } from "@shofer/core"
import { ContextProxy } from "../../config/ContextProxy"
import type { ProviderSettings, HistoryItem } from "@shofer/types"

// Mock dependencies
vi.mock("vscode", () => {
	const mockDisposable = { dispose: vi.fn() }
	return {
		TreeItem: class {
			constructor(_label?: string, _collapsibleState?: number) {}
		},
		TreeItemCollapsibleState: { None: 0, Collapsed: 1, Expanded: 2 },
		ThemeIcon: class {
			constructor(_id?: string) {}
		},
		workspace: {
			getConfiguration: vi.fn(() => ({
				get: vi.fn().mockReturnValue([]),
				update: vi.fn().mockResolvedValue(undefined),
			})),
			workspaceFolders: [],
			onDidChangeConfiguration: vi.fn(() => mockDisposable),
		},
		env: {
			uriScheme: "vscode",
			language: "en",
		},
		EventEmitter: vi.fn().mockImplementation(() => ({
			event: vi.fn(),
			fire: vi.fn(),
		})),
		Disposable: {
			from: vi.fn(),
		},
		window: {
			showErrorMessage: vi.fn(),
			createTextEditorDecorationType: vi.fn().mockReturnValue({
				dispose: vi.fn(),
			}),
			onDidChangeActiveTextEditor: vi.fn(() => mockDisposable),
		},
		commands: { registerCommand: () => mockDisposable, executeCommand: () => Promise.resolve() },
		languages: {
			createDiagnosticCollection: () => ({ set: vi.fn(), delete: vi.fn(), clear: vi.fn(), dispose: vi.fn() }),
		},
		Uri: {
			file: vi.fn().mockReturnValue({ toString: () => "file://test" }),
		},
		Range: class {
			constructor() {}
		},
		Position: class {
			constructor() {}
		},
		Selection: class {
			constructor() {}
		},
		ExtensionContext: class {},
		OutputChannel: class {},
		WebviewView: class {},
		ExtensionMode: { Production: 1, Development: 2, Test: 3 },
	}
})

vi.mock("../../config/ContextProxy", () => ({
	ContextProxy: {
		getInstance: vi.fn(() => ({
			onDidChange: vi.fn(() => ({ dispose: vi.fn() })),
			onDidRefreshOverlay: vi.fn(() => ({ dispose: vi.fn() })),
			onDidChangeScopeFiles: vi.fn(() => ({ dispose: vi.fn() })),
			getValue: vi.fn(),
			setValue: vi.fn(),
			getSecret: vi.fn(),
			storeSecret: vi.fn(),
			extensionUri: { fsPath: "/test" },
			globalStorageUri: { fsPath: "/test/storage" },
		})),
	},
}))
vi.mock("../../../services/mcp/McpServerManager", () => ({
	McpServerManager: {
		getInstance: vi.fn().mockResolvedValue({
			registerClient: vi.fn(),
		}),
		unregisterProvider: vi.fn(),
	},
}))
vi.mock("../../../integrations/workspace/WorkspaceTracker")
vi.mock("../../config/ProviderSettingsManager")
vi.mock("../../config/CustomModesManager")
// NOTE: Task moved into @shofer/core during the v3 carve-out. Both ShoferProvider (the
// SUT) and this test reference Task through the @shofer/core barrel, so the Task mock
// lives here (formerly vi.mock("../../task/Task")). The old relative path is dead.
vi.mock("@shofer/core", async (importOriginal) => ({
	...(await importOriginal<typeof import("@shofer/core")>()),
	Task: vi.fn().mockImplementation(() => ({
		api: undefined,
		abortTask: vi.fn(),
		handleWebviewAskResponse: vi.fn(),
		shoferMessages: [],
		apiConversationHistory: [],
		overwriteShoferMessages: vi.fn(),
		overwriteApiConversationHistory: vi.fn(),
		getTaskNumber: vi.fn().mockReturnValue(0),
		setTaskNumber: vi.fn(),
		setParentTask: vi.fn(),
		setRootTask: vi.fn(),
		taskId: "test-task-id",
		emit: vi.fn(),
		preloadShoferMessages: vi.fn().mockResolvedValue(undefined),
		messagesReady: Promise.resolve(),
		historyPreloaded: true,
		isHistoryPreloaded: true,
		on: vi.fn(),
		startFromHistory: vi.fn(),
	})),
	getWorkspacePath: vi.fn().mockReturnValue("/test/workspace"),
	// embeddingModels moved into @shofer/core (was `../../../shared/embeddingModels`).
	EMBEDDING_MODEL_PROFILES: [],
}))

// Mock TelemetryService
vi.mock("@shofer/telemetry", () => ({
	TelemetryService: {
		instance: {
			setProvider: vi.fn(),
			captureTaskCreated: vi.fn(),
		},
	},
}))

// Mock CloudService
vi.mock("@shofer/cloud", () => ({
	CloudService: {
		hasInstance: vi.fn().mockReturnValue(false),
		instance: {
			isAuthenticated: vi.fn().mockReturnValue(false),
		},
	},
	getShoferApiUrl: vi.fn().mockReturnValue("https://api.shofer-code.com"),
}))

describe("ShoferProvider flicker-free cancel", () => {
	let provider: ShoferProvider
	let mockContext: any
	let mockOutputChannel: any
	let mockTask1: any
	let mockTask2: any

	const mockApiConfig: ProviderSettings = {
		apiProvider: "anthropic",
		apiKey: "test-key",
	} as ProviderSettings

	beforeEach(() => {
		vi.clearAllMocks()

		// Setup mock extension context
		mockContext = {
			globalState: {
				get: vi.fn().mockReturnValue(undefined),
				update: vi.fn().mockResolvedValue(undefined),
				keys: vi.fn().mockReturnValue([]),
			},
			globalStorageUri: { fsPath: "/test/storage" },
			secrets: {
				get: vi.fn().mockResolvedValue(undefined),
				store: vi.fn().mockResolvedValue(undefined),
				delete: vi.fn().mockResolvedValue(undefined),
			},
			workspaceState: {
				get: vi.fn().mockReturnValue(undefined),
				update: vi.fn().mockResolvedValue(undefined),
				keys: vi.fn().mockReturnValue([]),
			},
			extensionUri: { fsPath: "/test/extension" },
		}

		// Setup mock output channel
		mockOutputChannel = {
			appendLine: vi.fn(),
			dispose: vi.fn(),
		}

		// Setup mock context proxy
		const mockContextProxy = {
			getValues: vi.fn().mockReturnValue({}),
			getValue: vi.fn().mockReturnValue(undefined),
			setValue: vi.fn().mockResolvedValue(undefined),
			getProviderSettings: vi.fn().mockReturnValue(mockApiConfig),
			attachProviderSettingsManager: vi.fn().mockResolvedValue(undefined),
			onDidChange: vi.fn(() => ({ dispose: vi.fn() })),
			onDidRefreshOverlay: vi.fn(() => ({ dispose: vi.fn() })),
			onDidChangeScopeFiles: vi.fn(() => ({ dispose: vi.fn() })),
			extensionUri: mockContext.extensionUri,
			globalStorageUri: mockContext.globalStorageUri,
		}

		// Create provider instance
		provider = new ShoferProvider(mockContext, mockOutputChannel, "sidebar", mockContextProxy as any)

		// Mock provider methods
		provider.getState = vi.fn().mockResolvedValue({
			apiConfiguration: mockApiConfig,
			mode: "code",
		})

		// Mock private method using any cast
		;(provider as any).updateGlobalState = vi.fn().mockResolvedValue(undefined)
		provider.activateProviderProfile = vi.fn().mockResolvedValue(undefined)
		provider.performPreparationTasks = vi.fn().mockResolvedValue(undefined)
		provider.getTaskWithId = vi.fn().mockImplementation((id) =>
			Promise.resolve({
				historyItem: {
					id,
					number: 1,
					ts: Date.now(),
					task: "test task",
					tokensIn: 100,
					tokensOut: 200,
					totalCost: 0.001,
					workspace: "/test/workspace",
				},
			}),
		)

		// Setup mock tasks
		mockTask1 = {
			taskId: "task-1",
			instanceId: "instance-1",
			emit: vi.fn(),
			abortTask: vi.fn().mockResolvedValue(undefined),
			abandoned: false,
			dispose: vi.fn(),
			on: vi.fn(),
			off: vi.fn(),
		}

		mockTask2 = {
			taskId: "task-1", // Same ID for rehydration scenario
			instanceId: "instance-2", // Different instance
			emit: vi.fn(),
			on: vi.fn(),
			off: vi.fn(),
			preloadShoferMessages: vi.fn().mockResolvedValue(undefined),
			shoferMessages: [],
			apiConversationHistory: [],
			messagesReady: Promise.resolve(),
			historyPreloaded: true,
			isHistoryPreloaded: true,
			startFromHistory: vi.fn(),
		}

		// Mock Task constructor
		vi.mocked(Task).mockImplementation(() => mockTask2 as any)
	})

	it("should not remove current task from stack when rehydrating same taskId", async () => {
		// Setup: Add a task to the stack first
		;(provider as any).shoferStack = [mockTask1]

		// Mock event listeners for cleanup
		;(provider as any).taskEventListeners = new WeakMap()
		const mockCleanupFunctions = [vi.fn(), vi.fn()]
		;(provider as any).taskEventListeners.set(mockTask1, mockCleanupFunctions)

		// Spy on removeShoferFromStack to verify it's NOT called
		const removeShoferFromStackSpy = vi.spyOn(provider, "removeShoferFromStack")

		// Create history item with same taskId as current task
		const historyItem: HistoryItem = {
			id: "task-1", // Same as mockTask1.taskId
			number: 1,
			task: "test task",
			ts: Date.now(),
			tokensIn: 100,
			tokensOut: 200,
			totalCost: 0.001,
			workspace: "/test/workspace",
		}

		// Act: Create task with history item (should rehydrate in-place)
		await provider.createTaskWithHistoryItem(historyItem)

		// Assert: removeShoferFromStack should NOT be called
		expect(removeShoferFromStackSpy).not.toHaveBeenCalled()

		// Verify the task was replaced in-place
		expect((provider as any).shoferStack).toHaveLength(1)
		expect((provider as any).shoferStack[0]).toBe(mockTask2)

		// Verify old event listeners were cleaned up
		expect(mockCleanupFunctions[0]).toHaveBeenCalled()
		expect(mockCleanupFunctions[1]).toHaveBeenCalled()

		// Verify new task received focus event
		expect(mockTask2.emit).toHaveBeenCalledWith("taskFocused")
	})

	it("should remove task from stack when creating different task", async () => {
		// Setup: Add a task to the stack first
		;(provider as any).shoferStack = [mockTask1]

		// Spy on removeShoferFromStack to verify it IS called
		const removeShoferFromStackSpy = vi.spyOn(provider, "removeShoferFromStack").mockResolvedValue(undefined)

		// Create history item with different taskId
		const historyItem: HistoryItem = {
			id: "task-2", // Different from mockTask1.taskId
			number: 2,
			task: "different task",
			ts: Date.now(),
			tokensIn: 150,
			tokensOut: 250,
			totalCost: 0.002,
			workspace: "/test/workspace",
		}

		// Act: Create task with different history item
		await provider.createTaskWithHistoryItem(historyItem)

		// Assert: removeShoferFromStack should be called
		expect(removeShoferFromStackSpy).toHaveBeenCalled()
	})

	it("should handle empty stack gracefully during rehydration attempt", async () => {
		// Setup: Empty stack
		;(provider as any).shoferStack = []

		// Spy on removeShoferFromStack
		const removeShoferFromStackSpy = vi.spyOn(provider, "removeShoferFromStack").mockResolvedValue(undefined)

		// Create history item
		const historyItem: HistoryItem = {
			id: "task-1",
			number: 1,
			task: "test task",
			ts: Date.now(),
			tokensIn: 100,
			tokensOut: 200,
			totalCost: 0.001,
			workspace: "/test/workspace",
		}

		// Act: Should not error and should call removeShoferFromStack
		await provider.createTaskWithHistoryItem(historyItem)

		// Assert: removeShoferFromStack should be called (no current task to rehydrate)
		expect(removeShoferFromStackSpy).toHaveBeenCalled()
	})

	it("should maintain task stack integrity during flicker-free replacement", async () => {
		// Setup: Stack with multiple tasks
		const mockParentTask = {
			taskId: "parent-task",
			instanceId: "parent-instance",
			emit: vi.fn(),
		}

		;(provider as any).shoferStack = [mockParentTask, mockTask1]
		;(provider as any).taskEventListeners = new WeakMap()
		;(provider as any).taskEventListeners.set(mockTask1, [vi.fn()])

		// Act: Rehydrate the current (top) task
		const historyItem: HistoryItem = {
			id: "task-1",
			number: 1,
			task: "test task",
			ts: Date.now(),
			tokensIn: 100,
			tokensOut: 200,
			totalCost: 0.001,
			workspace: "/test/workspace",
		}

		await provider.createTaskWithHistoryItem(historyItem)

		// Assert: Stack should maintain parent task and replace current task
		expect((provider as any).shoferStack).toHaveLength(2)
		expect((provider as any).shoferStack[0]).toBe(mockParentTask)
		expect((provider as any).shoferStack[1]).toBe(mockTask2)
	})
})
