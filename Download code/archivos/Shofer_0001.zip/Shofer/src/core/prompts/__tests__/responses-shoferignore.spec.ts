// npx vitest core/prompts/__tests__/responses-rooignore.spec.ts

import type { Mock } from "vitest"

import { formatResponse } from "@shofer/core"
import { ShoferIgnoreController, LOCK_TEXT_SYMBOL } from "@shofer/core"
import { promises as fsPromises } from "fs"
import * as fs from "fs/promises"
import path from "path"
import { toPosix } from "./utils"

// Mock dependencies
vi.mock("fs", async (importOriginal) => {
	const actual = await importOriginal<typeof import("fs")>()
	return { ...actual, promises: { ...actual.promises, access: vi.fn() } }
})
vi.mock("fs/promises")
vi.mock("vscode", () => {
	const mockDisposable = { dispose: vi.fn() }
	return {
		workspace: {
			createFileSystemWatcher: vi.fn(() => ({
				onDidCreate: vi.fn(() => mockDisposable),
				onDidChange: vi.fn(() => mockDisposable),
				onDidDelete: vi.fn(() => mockDisposable),
				dispose: vi.fn(),
			})),
		},
		RelativePattern: vi.fn(),
	}
})

describe("ShoferIgnore Response Formatting", () => {
	const TEST_CWD = "/test/path"
	let mockAccess: Mock<typeof fsPromises.access>
	let mockReadFile: Mock<typeof fs.readFile>

	beforeEach(() => {
		// Reset mocks
		vi.clearAllMocks()

		// Setup fs mocks
		mockAccess = fsPromises.access as Mock<typeof fsPromises.access>
		mockReadFile = fs.readFile as Mock<typeof fs.readFile>

		// Default mock implementations
		mockAccess.mockResolvedValue(undefined)
		mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets/**\n*.log")
	})

	describe("formatResponse.shoferIgnoreError", () => {
		/**
		 * Tests the error message format for ignored files
		 */
		it("should format error message for ignored files", () => {
			const errorMessage = formatResponse.shoferIgnoreError("secrets/api-keys.json")

			// Verify error message format (JSON)
			const parsed = JSON.parse(errorMessage) as any
			expect(parsed.status).toBe("error")
			expect(parsed.type).toBe("access_denied")
			expect(parsed.path).toBe("secrets/api-keys.json")
			expect(parsed.suggestion).toContain("continue without this file")
			expect(parsed.suggestion).toContain("update the shoferignore file")
		})

		/**
		 * Tests with different file paths
		 */
		it("should include the file path in the error message", () => {
			const paths = ["node_modules/package.json", ".git/HEAD", "secrets/credentials.env", "logs/app.log"]

			// Test each path
			for (const testPath of paths) {
				const errorMessage = formatResponse.shoferIgnoreError(testPath)
				const parsed = JSON.parse(errorMessage) as any
				expect(parsed.path).toBe(testPath)
			}
		})
	})

	describe("formatResponse.formatFilesList with ShoferIgnoreController", () => {
		/**
		 * Tests file listing with rooignore controller
		 */
		it("should format files list with lock symbols for ignored files", async () => {
			// Create controller
			const controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Mock validateAccess to control which files are ignored
			controller.validateAccess = vi.fn().mockImplementation((filePath: string) => {
				// Only allow files not matching these patterns
				return (
					!filePath.includes("node_modules") &&
					!filePath.includes(".git") &&
					!toPosix(filePath).includes("secrets/")
				)
			})

			// Files list with mixed allowed/ignored files
			const files = [
				"src/app.ts", // allowed
				"node_modules/package.json", // ignored
				"README.md", // allowed
				".git/HEAD", // ignored
				"secrets/keys.json", // ignored
			]

			// Format with controller
			const result = formatResponse.formatFilesList(TEST_CWD, files, false, controller as any, true)

			// Should contain each file
			expect(result).toContain("src/app.ts")
			expect(result).toContain("README.md")

			// Should contain lock symbols for ignored files - case insensitive check using regex
			expect(result).toMatch(new RegExp(`${LOCK_TEXT_SYMBOL}.*node_modules/package.json`, "i"))
			expect(result).toMatch(new RegExp(`${LOCK_TEXT_SYMBOL}.*\\.git/HEAD`, "i"))
			expect(result).toMatch(new RegExp(`${LOCK_TEXT_SYMBOL}.*secrets/keys.json`, "i"))

			// No lock symbols for allowed files
			expect(result).not.toContain(`${LOCK_TEXT_SYMBOL} src/app.ts`)
			expect(result).not.toContain(`${LOCK_TEXT_SYMBOL} README.md`)
		})

		/**
		 * Tests formatFilesList when showShoferIgnoredFiles is set to false
		 */
		it("should hide ignored files when showShoferIgnoredFiles is false", async () => {
			// Create controller
			const controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Mock validateAccess to control which files are ignored
			controller.validateAccess = vi.fn().mockImplementation((filePath: string) => {
				// Only allow files not matching these patterns
				return (
					!filePath.includes("node_modules") &&
					!filePath.includes(".git") &&
					!toPosix(filePath).includes("secrets/")
				)
			})

			// Files list with mixed allowed/ignored files
			const files = [
				"src/app.ts", // allowed
				"node_modules/package.json", // ignored
				"README.md", // allowed
				".git/HEAD", // ignored
				"secrets/keys.json", // ignored
			]

			// Format with controller and showShoferIgnoredFiles = false
			const result = formatResponse.formatFilesList(
				TEST_CWD,
				files,
				false,
				controller as any,
				false, // showShoferIgnoredFiles = false
			)

			// Should contain allowed files
			expect(result).toContain("src/app.ts")
			expect(result).toContain("README.md")

			// Should NOT contain ignored files (even with lock symbols)
			expect(result).not.toContain("node_modules/package.json")
			expect(result).not.toContain(".git/HEAD")
			expect(result).not.toContain("secrets/keys.json")

			// Double-check with regex to ensure no form of these filenames appears
			expect(result).not.toMatch(/node_modules\/package\.json/i)
			expect(result).not.toMatch(/\.git\/HEAD/i)
			expect(result).not.toMatch(/secrets\/keys\.json/i)
		})

		/**
		 * Tests formatFilesList handles truncation correctly with ShoferIgnoreController
		 */
		it("should handle truncation with ShoferIgnoreController", async () => {
			// Create controller
			const controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Format with controller and truncation flag
			const result = formatResponse.formatFilesList(
				TEST_CWD,
				["file1.txt", "file2.txt"],
				true, // didHitLimit = true
				controller as any,
				true,
			)

			// Should contain truncation message (case-insensitive check)
			expect(result).toContain("File list truncated")
			expect(result).toMatch(/use list_files on specific subdirectories/i)
		})

		/**
		 * Tests formatFilesList handles empty results
		 */
		it("should handle empty file list with ShoferIgnoreController", async () => {
			// Create controller
			const controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Format with empty files array
			const result = formatResponse.formatFilesList(TEST_CWD, [], false, controller as any, true)

			// Should show "No files found"
			expect(result).toBe("No files found.")
		})
	})

	describe("getInstructions", () => {
		/**
		 * Tests the instructions format
		 */
		it("should format shoferignore instructions for the LLM", async () => {
			// ShoferIgnoreController lives in @shofer/core (a built package), so its
			// internal fs access can't be mocked from here — use a real .shoferignore.
			const realFs = await vi.importActual<typeof import("fs")>("fs")
			const os = await vi.importActual<typeof import("os")>("os")
			const tmpDir = realFs.mkdtempSync(path.join(os.tmpdir(), "shoferignore-"))
			realFs.mkdirSync(path.join(tmpDir, ".shofer"))
			realFs.writeFileSync(path.join(tmpDir, ".shofer", "shoferignore"), "node_modules\n.git\nsecrets/**\n*.log")

			const controller = new ShoferIgnoreController(tmpDir)
			await controller.initialize()

			// Get instructions
			const instructions = controller.getInstructions()
			realFs.rmSync(tmpDir, { recursive: true, force: true })

			// Verify format and content
			expect(instructions).toContain("# .shoferignore")
			expect(instructions).toContain(LOCK_TEXT_SYMBOL)
			expect(instructions).toContain("node_modules")
			expect(instructions).toContain(".git")
			expect(instructions).toContain("secrets/**")
			expect(instructions).toContain("*.log")

			// Should explain what the lock symbol means
			expect(instructions).toContain("you'll notice a")
			expect(instructions).toContain("next to files that are blocked")
		})

		/**
		 * Tests null/undefined case
		 */
		it("should return undefined when no shoferignore exists", async () => {
			// Set up no shoferignore
			mockAccess.mockRejectedValue(new Error("ENOENT"))

			// Create controller without shoferignore
			const controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Should return undefined
			expect(controller.getInstructions()).toBeUndefined()
		})
	})
})
