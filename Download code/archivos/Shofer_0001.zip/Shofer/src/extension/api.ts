import { EventEmitter } from "events"
import fs from "fs/promises"
import * as path from "path"
import * as os from "os"

import * as vscode from "vscode"
import pWaitFor from "p-wait-for"

import {
	type ShoferExtensionApi,
	type ShoferSettings,
	type ShoferEvents,
	type ExtensionCreateTaskInput,
	type ProviderSettings,
	type ProviderSettingsEntry,
	type ServerEvent,
	type TaskEvent,
	type TaskSnapshot,
	type CreateTaskOptions,
	type TraceContext,
	type HistoryItem,
	type Envelope,
	type ShoferMessage,
	type TaskLike,
	type TokenUsage,
	ShoferEventName,
	TaskCommandName,
	isSecretStateKey,
	IpcOrigin,
	IpcMessageType,
} from "@shofer/types"
import { FORWARDED_EVENTS, findOutstandingAsk } from "@shofer/core"
import type { Task } from "@shofer/core"
import { IpcServer } from "@shofer/ipc"

import { Package } from "@shofer/core"
import { pluginRegistry } from "@shofer/core"
import { ShoferProvider } from "../core/webview/ShoferProvider"
import { resolveTaskCwd } from "../core/webview/resolveTaskCwd"
import { openShoferInNewTab } from "../activate/registerCommands"
import { getCommands } from "@shofer/core"
import { getModels } from "@shofer/core"
import { utilLog } from "@shofer/core"
import { getRecentLogs, getLogLevel, getLogKnownCategories } from "@shofer/core"
import { buildJsonTrace } from "../integrations/misc/export-json"
import { formatContentBlockToMarkdown, getTaskFileName } from "../integrations/misc/export-markdown"

export class API extends EventEmitter<ShoferEvents> implements ShoferExtensionApi {
	private readonly outputChannel: vscode.OutputChannel
	private readonly sidebarProvider: ShoferProvider
	private readonly context: vscode.ExtensionContext
	private readonly ipc?: IpcServer
	private readonly log: (...args: unknown[]) => void
	private logfile?: string

	constructor(
		outputChannel: vscode.OutputChannel,
		provider: ShoferProvider,
		socketPath?: string,
		enableLogging = false,
	) {
		super()

		this.outputChannel = outputChannel
		this.sidebarProvider = provider
		this.context = provider.context

		if (enableLogging) {
			this.log = (...args: unknown[]) => {
				this.outputChannelLog(...args)
				utilLog.info(args.map((a) => String(a)).join(" "))
			}

			this.logfile = path.join(os.tmpdir(), "shofer-code-messages.log")
		} else {
			this.log = () => {}
		}

		this.registerListeners(this.sidebarProvider)

		if (socketPath) {
			const ipc = (this.ipc = new IpcServer(socketPath, this.log))

			ipc.listen()
			this.log(`[API] ipc server started: socketPath=${socketPath}, pid=${process.pid}, ppid=${process.ppid}`)

			ipc.on(IpcMessageType.TaskCommand, async (clientId, command) => {
				const sendResponse = (eventName: ShoferEventName, payload: unknown[]) => {
					ipc.send(clientId, {
						type: IpcMessageType.TaskEvent,
						origin: IpcOrigin.Server,
						data: { eventName, payload } as TaskEvent,
					})
				}

				switch (command.commandName) {
					case TaskCommandName.StartNewTask:
						this.log(
							`[API] StartNewTask -> ${command.data.text}, ${JSON.stringify(command.data.configuration)}`,
						)
						await this.createTask({ ...command.data, prompt: command.data.text ?? "" })
						break
					case TaskCommandName.CancelTask: {
						this.log(`[API] CancelTask`)
						// The IPC command carries no task id — it means the current task.
						const target = this.currentTaskId()
						if (target) await this.cancelTask(target)
						break
					}
					case TaskCommandName.CloseTask:
						this.log(`[API] CloseTask`)
						await vscode.commands.executeCommand("workbench.action.files.saveFiles")
						await vscode.commands.executeCommand("workbench.action.closeWindow")
						break
					case TaskCommandName.ResumeTask:
						this.log(`[API] ResumeTask -> ${command.data}`)
						try {
							await this.resumeTask(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] ResumeTask failed for taskId ${command.data}: ${errorMessage}`)
							// Don't rethrow - we want to prevent IPC server crashes.
							// The error is logged for debugging purposes.
						}
						break
					case TaskCommandName.SendMessage: {
						this.log(`[API] SendMessage -> ${command.data.text}`)
						// The IPC command carries no task id, so it addresses the
						// current task — resolved here rather than in the API method,
						// which is task-addressed by contract.
						const target = this.currentTaskId()
						if (target) {
							await this.sendMessage(target, command.data.text ?? "", command.data.images)
						} else {
							this.log("[API] SendMessage dropped: no current task")
						}
						break
					}
					case TaskCommandName.GetCommands:
						try {
							const commands = await getCommands(this.sidebarProvider.cwd)

							sendResponse(ShoferEventName.CommandsResponse, [
								commands.map((cmd) => ({
									name: cmd.name,
									source: cmd.source,
									filePath: cmd.filePath,
									description: cmd.description,
									argumentHint: cmd.argumentHint,
								})),
							])
						} catch (error) {
							sendResponse(ShoferEventName.CommandsResponse, [[]])
						}

						break
					case TaskCommandName.GetModes:
						try {
							const modes = await this.sidebarProvider.getModes()
							sendResponse(ShoferEventName.ModesResponse, [modes])
						} catch (error) {
							sendResponse(ShoferEventName.ModesResponse, [[]])
						}

						break
					case TaskCommandName.GetModels:
						try {
							sendResponse(ShoferEventName.ModelsResponse, [{}])
						} catch (error) {
							sendResponse(ShoferEventName.ModelsResponse, [{}])
						}

						break
					case TaskCommandName.DeleteQueuedMessage:
						this.log(`[API] DeleteQueuedMessage -> ${command.data}`)
						try {
							this.deleteQueuedMessage(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] DeleteQueuedMessage failed for messageId ${command.data}: ${errorMessage}`)
						}
						break
					case TaskCommandName.ShowTaskWithId:
						this.log(`[API] ShowTaskWithId -> ${command.data.taskId}`)
						try {
							await this.showTaskWithId(command.data.taskId, {
								keepCurrentTask: command.data.keepCurrentTask,
							})
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] ShowTaskWithId failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.RenameTask:
						this.log(`[API] RenameTask -> ${command.data.taskId}`)
						try {
							await this.renameTask(command.data.taskId, command.data.name)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] RenameTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.ArchiveTask:
						this.log(`[API] ArchiveTask -> ${command.data}`)
						try {
							await this.archiveTask(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] ArchiveTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.UnarchiveTask:
						this.log(`[API] UnarchiveTask -> ${command.data}`)
						try {
							await this.unarchiveTask(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] UnarchiveTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.PinTask:
						this.log(`[API] PinTask -> ${command.data}`)
						try {
							await this.pinTask(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] PinTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.UnpinTask:
						this.log(`[API] UnpinTask -> ${command.data}`)
						try {
							await this.unpinTask(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] UnpinTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.DeleteTask:
						this.log(`[API] DeleteTask -> ${command.data.taskId}`)
						try {
							await this.deleteTask(command.data.taskId, command.data.cascadeSubtasks)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] DeleteTask failed: ${errorMessage}`)
						}
						break
					case TaskCommandName.GetTaskMarkdownExport:
						this.log(`[API] GetTaskMarkdownExport -> ${command.data}`)
						try {
							const markdown = await this.getTaskMarkdownExport(command.data)
							sendResponse(ShoferEventName.TaskCompleted, [
								command.data,
								{ inputTokens: 0, outputTokens: 0, cacheWriteTokens: 0, cacheReadTokens: 0 },
								{ totalTools: 0, toolsCount: {} },
								{ rating: "well", isSubtask: false, exportContent: markdown },
							])
						} catch (error) {
							this.log(
								`[API] GetTaskMarkdownExport failed: ${error instanceof Error ? error.message : String(error)}`,
							)
						}
						break
					case TaskCommandName.GetTaskJsonExport:
						this.log(`[API] GetTaskJsonExport -> ${command.data}`)
						try {
							const jsonExport = await this.getTaskJsonExport(command.data)
							sendResponse(ShoferEventName.TaskCompleted, [
								command.data,
								{ inputTokens: 0, outputTokens: 0, cacheWriteTokens: 0, cacheReadTokens: 0 },
								{ totalTools: 0, toolsCount: {} },
								{ rating: "well", isSubtask: false, exportContent: JSON.stringify(jsonExport) },
							])
						} catch (error) {
							this.log(
								`[API] GetTaskJsonExport failed: ${error instanceof Error ? error.message : String(error)}`,
							)
						}
						break
					case TaskCommandName.ExportConfiguration:
						this.log(`[API] ExportConfiguration`)
						try {
							const configJson = this.exportConfiguration()
							sendResponse(ShoferEventName.ModelsResponse, [{ config: configJson }])
						} catch (error) {
							this.log(
								`[API] ExportConfiguration failed: ${error instanceof Error ? error.message : String(error)}`,
							)
						}
						break
					case TaskCommandName.ImportConfiguration:
						this.log(`[API] ImportConfiguration`)
						try {
							await this.importConfiguration(command.data)
						} catch (error) {
							const errorMessage = error instanceof Error ? error.message : String(error)
							this.log(`[API] ImportConfiguration failed: ${errorMessage}`)
						}
						break
				}
			})
		}
	}

	public override emit<K extends keyof ShoferEvents>(
		eventName: K,
		...args: K extends keyof ShoferEvents ? ShoferEvents[K] : never
	) {
		const data = { eventName: eventName as ShoferEventName, payload: args } as TaskEvent
		this.ipc?.broadcast({ type: IpcMessageType.TaskEvent, origin: IpcOrigin.Server, data })
		return super.emit(eventName, ...args)
	}

	public async createTask({
		configuration,
		prompt,
		images,
		newTab,
		taskId,
		mode: initialMode,
		apiConfiguration,
		title,
		trace,
	}: ExtensionCreateTaskInput): Promise<{ taskId: string }> {
		const text = prompt
		// `configuration` is the host-only full-settings seed; `apiConfiguration` is
		// the base contract's provider slice. Both land in the same per-task seed,
		// with the explicit full settings winning where they overlap.
		const taskConfiguration = { ...(apiConfiguration ?? {}), ...(configuration ?? {}) } as ShoferSettings
		let provider: ShoferProvider

		if (newTab) {
			await vscode.commands.executeCommand("workbench.action.files.revert")
			await vscode.commands.executeCommand("workbench.action.closeAllEditors")

			provider = await openShoferInNewTab({ context: this.context, outputChannel: this.outputChannel })
			this.registerListeners(provider)
		} else {
			await vscode.commands.executeCommand(`${Package.name}.SidebarProvider.focus`)

			provider = this.sidebarProvider
		}

		// Make room for the new task WITHOUT destroying whatever the host is
		// already running. This entry point is how every non-webview caller
		// starts a task — including a controller driving a `shofer serve` node,
		// where many independent conversations share one provider — so the task
		// currently on the stack is somebody else's work, not a finished chat
		// this one supersedes. Aborting it (`removeShoferFromStack`) killed a
		// conversation mid-turn: the victim's controller saw a `taskAborted`
		// with reason `abandoned` and then silence, because the agent composing
		// its reply no longer existed. Backgrounding keeps it running and keeps
		// it addressable by id, which is what `sendMessage`/`resumeTask` need.
		provider.backgroundCurrentTask()
		await provider.postInitState()
		await provider.postMessageToWebview({ type: "action", action: "chatButtonClicked" })
		await provider.postMessageToWebview({ type: "invoke", invoke: "newChat", text, images })

		const options: CreateTaskOptions = {
			consecutiveMistakeLimit: Number.MAX_SAFE_INTEGER,
			// The stack was just cleared without aborting; `createTask`'s own
			// single-open-task enforcement must not re-abort what is left.
			keepCurrentTask: true,
			...(taskId ? { taskId } : {}),
			...(initialMode ? { initialMode } : {}),
			// A controller-supplied title LOCKS the name (same path as NewTaskTool's
			// `title`), which also drops `set_task_title` from the tool list.
			...(title ? { initialTitle: title } : {}),
			// W3C trace context of the request that asked for this task, carried so
			// `beforeTaskStart` observers can continue the caller's trace instead of
			// opening an unrelated one. Core never reads it.
			...(trace ? { trace } : {}),
		}

		// Where does this task run? The same question the chat input asks, asked here too:
		// this is the entry point every NON-webview caller comes through — the ShoferApi a
		// controller drives a headless executor with, the CLI, the public API — and a task
		// created that way deserves the same isolation as one typed into the sidebar. A
		// plugin that recognised the question and failed throws, aborting creation, rather
		// than quietly running the agent in the workspace.
		const cwd = await resolveTaskCwd(provider)

		const task = await provider.createTask(text, images, undefined, options, taskConfiguration, cwd)

		if (!task) {
			throw new Error("Failed to create task due to policy restrictions")
		}

		return { taskId: task.taskId }
	}

	public async resumeTask(taskId: string): Promise<void> {
		// A live instance needs no rehydration — and must not get one: when the
		// addressed task IS the current task, createTaskWithHistoryItem's
		// isRehydratingCurrentTask path skips the live-instance guard and rebuilds
		// the instance, aborting the live one (including any turn in flight). For
		// API callers "resume" means "make this task addressable", which a live
		// instance already is. managedTasks only holds backgrounded instances, so
		// also check the current (foreground) task by id.
		const currentTask = this.sidebarProvider.getCurrentTask()
		const live =
			this.sidebarProvider.taskManager.getManagedTaskInstance(taskId) ??
			(currentTask?.taskId === taskId ? currentTask : undefined)
		if (live && !live.abandoned && !live.abort) {
			return
		}

		await vscode.commands.executeCommand(`${Package.name}.SidebarProvider.focus`)
		await this.waitForWebviewLaunch(5_000)

		const { historyItem } = await this.sidebarProvider.getTaskWithId(taskId)
		// `keepCurrentTask` for the same reason `createTask` backgrounds rather
		// than aborts: resuming one conversation must not abandon another that
		// happens to be the host's current task.
		await this.sidebarProvider.createTaskWithHistoryItem(historyItem, { keepCurrentTask: true })

		if (this.sidebarProvider.viewLaunched) {
			await this.sidebarProvider.postMessageToWebview({ type: "action", action: "chatButtonClicked" })
		} else {
			this.log(
				`[API#resumeTask] webview not launched after resume for task ${taskId}; continuing in headless mode`,
			)
		}
	}

	public async isTaskInHistory(taskId: string): Promise<boolean> {
		try {
			await this.sidebarProvider.getTaskWithId(taskId)
			return true
		} catch {
			return false
		}
	}

	public getCurrentTaskStack() {
		return this.sidebarProvider.getCurrentTaskStack()
	}

	public async clearCurrentTask(_lastMessage?: string) {
		// Legacy finishSubTask removed; clear current by closing active task instance.
		await this.sidebarProvider.removeShoferFromStack()
		await this.sidebarProvider.postInitState()
	}

	public async cancelTask(taskId: string) {
		// Cancelling is task-ADDRESSED, like sendMessage. The provider's own
		// cancelTask() only knows the task it currently holds, which was enough
		// while a host ran one task at a time; it no longer is — starting or
		// resuming a task backgrounds the previous one rather than killing it, so
		// the conversation a user hits Stop on is routinely NOT the current one.
		// Ignoring that request would have been a silent no-op: the caller is told
		// the cancel succeeded and the agent keeps running.
		const current = this.sidebarProvider.getCurrentTask()
		if (!current || current.taskId === taskId) {
			await this.sidebarProvider.cancelTask()
			return
		}

		const background = this.sidebarProvider.taskManager.getManagedTaskInstance(taskId)
		if (!background || background.abort || background.abandoned) {
			this.log(`[API#cancelTask] no live instance for ${taskId}; nothing to cancel`)
			return
		}

		// Abort the background instance directly. `abortReason` is what makes this
		// read as a USER cancellation on the wire (`taskAborted` reason `user`)
		// rather than an eviction (`abandoned`) — the two mean different things to
		// a controller and must not be conflated. No rehydration follows, because
		// this task is not on the stack and has no view to restore.
		background.abortReason = "user_cancelled"
		background.cancelCurrentRequest()
		await background.abortTask()
	}

	public async sendMessage(taskId: string, message: string, images?: string[], trace?: TraceContext) {
		// Resolve the managed instance and hand the message straight to its
		// ask/message channel. This MUST NOT route through the webview: in the CLI
		// host the mock webview reports viewLaunched=true, and an
		// `invoke: sendMessage` posted to it is dropped (serve mode has no consumer
		// for invokes), silently losing every follow-up message. Addressing the task
		// also removes the current-task race — concurrent tasks on one host no
		// longer steal each other's messages.
		//
		// managedTasks only holds BACKGROUNDED instances (registerBackgroundTask);
		// the foreground task lives on the stack, so fall back to the current task
		// when — and only when — its id matches the addressed one.
		const current = this.sidebarProvider.getCurrentTask()
		const task =
			this.sidebarProvider.taskManager.getManagedTaskInstance(taskId) ??
			(current?.taskId === taskId ? current : undefined)

		// Warm: the instance is still running this conversation.
		if (task && !task.abandoned && !task.abort) {
			await task.submitUserMessage(message, images, undefined, undefined, trace)
			return
		}

		// Cold or FINISHED. A completed task has `abort === true` — both completion
		// shapes set it — so this is the ordinary "next turn of a conversation"
		// path, not an error, and the message must not be dropped.
		await this.resumeAndDeliver(taskId, message, images, trace)
	}

	/**
	 * Deliver a message to a task this host is no longer running: rehydrate from
	 * history, then make the message that conversation's next user turn.
	 *
	 * QUEUE BEFORE START — this is the whole point of the method, and the
	 * ordering is load-bearing rather than opportunistic. `resumeTaskFromHistory`
	 * takes a queued message AS the resumption and raises no ask at all, so the
	 * queue must be populated before it runs: hence `startTask: false` here and
	 * an explicit `startFromHistory()` after the message is in. Letting
	 * rehydration start itself and racing the message in afterwards is what
	 * published a resume ask on every follow-up turn — dispatched, declined by a
	 * headless node's ask handler, and only then answered by the drain, at the
	 * cost of a persist, a state broadcast, a `getState()` and a `pWaitFor` on
	 * the first hop of a live conversation.
	 *
	 * Resuming FIRST and sending after (which is what `ShoferApiAgent.sendMessage`
	 * used to do) loses the same race, one step earlier.
	 *
	 * This mirrors `ShoferProvider.resumePluginSession`, which reached the same
	 * conclusion for the plugin-agent entry point.
	 */
	private async resumeAndDeliver(
		taskId: string,
		message: string,
		images?: string[],
		trace?: TraceContext,
	): Promise<void> {
		let historyItem: HistoryItem
		try {
			;({ historyItem } = await this.sidebarProvider.getTaskWithId(taskId))
		} catch (error) {
			this.log(
				`[API#sendMessage] no live instance and no history for ${taskId}; message dropped: ` +
					`${error instanceof Error ? error.message : String(error)}`,
			)
			return
		}

		// `keepCurrentTask` for the same reason `createTask` backgrounds rather
		// than aborts: continuing one conversation must not abandon another.
		const task = await this.sidebarProvider.createTaskWithHistoryItem(historyItem, {
			keepCurrentTask: true,
			startTask: false,
			// The caller's trace, so the resumed run continues the story that asked
			// for it rather than starting one of its own. It reaches observers at
			// the queued-resumption `onUserMessage`, which is this path's only
			// announcement that the user spoke.
			trace,
		})
		task.messageQueueService.addMessage(message, images)
		task.startFromHistory()
	}

	/**
	 * Deliver an envelope into a task's mailbox (the AgentApi's `POST
	 * /api/v1/task/:id/mailbox` door).
	 *
	 * A thin pass-through to {@link ShoferProvider.deliverToTask}, which owns the
	 * live-instance-vs-rehydrate decision and the wake policy. Unlike
	 * {@link sendMessage}, a failure here THROWS rather than logging and
	 * returning: a mailbox delivery carries a receipt, and every caller of this
	 * door (an A2A ack, a Temporal `agentTaskMessageDelivered` signal) reports
	 * "in the box" on the strength of it. Swallowing the failure would make each
	 * of those acks a lie.
	 */
	public async deliverToMailbox(taskId: string, envelope: Envelope): Promise<void> {
		await this.sidebarProvider.deliverToTask(taskId, envelope)
	}

	/**
	 * The task a "current task" caller means — the top of the provider's task
	 * stack. The API surface itself is task-addressed; this exists only for the
	 * legacy entry points (the IPC command shape) that carry no task id.
	 */
	private currentTaskId(): string | undefined {
		return this.sidebarProvider.getCurrentTaskStack().at(-1)
	}

	public async respondToAsk(
		taskId: string,
		response: { askResponse: string; text?: string; images?: string[]; askId?: string; mode?: string },
	): Promise<void> {
		// Resolve the addressed task (a managed instance, else the current task) and
		// drive the answer through the same ask-response channel a webview button
		// takes. This is the executor side of the reverse ask channel: a controller
		// routes a remote task's approval back here over the transport.
		const addressed =
			this.sidebarProvider.taskManager.getManagedTaskInstance(taskId) ?? this.sidebarProvider.getCurrentTask()

		if (!addressed) {
			this.log(`[API#respondToAsk] no task for ${taskId}; ask response dropped`)
			return
		}

		// A CONVERSATION is addressed by its root task, but an ask can be raised by
		// any task in that conversation's tree, and a controller answers against the
		// root id it knows — the only one its question row holds. Follow the askId to
		// whichever live task is actually parked on it.
		const task = this.resolveAskTarget(addressed, response.askId)

		// A followup suggestion may carry a mode: switch this task to it before
		// resolving the answer, mirroring the webview (which calls switchToMode then
		// sends the messageResponse). Scoped to this task via handleModeSwitch's
		// sourceTask arg so it never retargets another task.
		if (response.mode) {
			await this.sidebarProvider.handleModeSwitch(response.mode, task)
		}

		task.handleWebviewAskResponse(
			response.askResponse as Parameters<typeof task.handleWebviewAskResponse>[0],
			response.text,
			response.images,
			response.askId,
		)
	}

	/**
	 * The task an ask answer belongs to: the addressed one unless a DESCENDANT of
	 * the same conversation is the one parked on `askId`.
	 *
	 * Without this an escalated question is unanswerable. The child raises the
	 * ask; the copy published on the root's stream carries the child's `askId`;
	 * the controller posts the answer to the conversation (the root) because that
	 * is the only id its durable question row holds. Handed to the root task, the
	 * askId matches nothing and `handleWebviewAskResponse` drops it as a stale
	 * answer — silently, which is exactly the failure mode this whole path exists
	 * to remove.
	 *
	 * Narrow by construction, so it can never redirect an ordinary answer: with no
	 * `askId` (or with the addressed task parked on it) the addressed task wins,
	 * and a candidate must both belong to the same conversation and be parked on
	 * that precise ask. The stack is searched top-down because the deepest live
	 * child is the one blocking the tree.
	 */
	private resolveAskTarget(addressed: Task, askId?: string): Task {
		if (!askId || addressed.isAwaitingAsk(askId)) return addressed

		const conversationOf = (task: Task) => task.rootTaskId ?? task.taskId
		const conversation = conversationOf(addressed)
		const candidates: Task[] = [
			...this.sidebarProvider.getTaskStackInstances().reverse(),
			...this.sidebarProvider.taskManager
				.getManagedTasks()
				.map((managed) => this.sidebarProvider.taskManager.getManagedTaskInstance(managed.id))
				.filter((task): task is Task => !!task),
		]

		for (const candidate of candidates) {
			if (candidate.taskId === addressed.taskId) continue
			if (conversationOf(candidate) !== conversation) continue
			if (!candidate.isAwaitingAsk(askId)) continue
			this.log(
				`[API#respondToAsk] ask ${askId} addressed at ${addressed.taskId} belongs to ${candidate.taskId}; routing there`,
			)
			return candidate
		}

		return addressed
	}

	/**
	 * The conversation and live counters for a task on THIS host — the executor side
	 * of a controller's attach backfill.
	 *
	 * Two sources, in order: a live instance (its in-memory `shoferMessages` and
	 * `getTokenUsage()` are the freshest, and include a partial message still being
	 * streamed), else the persisted `ui_messages.jsonl` plus the counters recorded on
	 * the history item. Reading from disk is what makes a task attachable after the
	 * executor restarted or the task was backgrounded — the transcript outlives the
	 * instance.
	 *
	 * Returns `undefined` only when this host has no record of the task at all.
	 */
	/**
	 * Assemble a task's snapshot from this host's own records: the conversation and
	 * counters from {@link getTaskConversation}, the title/lifecycle from the
	 * task-history entry, and the outstanding ask derived from the transcript tail.
	 *
	 * Deriving the ask from the transcript rather than reading it off a live task is
	 * deliberate: the same rule then holds for a running task and for one rehydrated
	 * from disk, and a client needs no second call to learn the task is blocked.
	 */
	public async getTaskSnapshot(taskId: string): Promise<TaskSnapshot | undefined> {
		const conversation = await this.getTaskConversation(taskId)
		if (!conversation) return undefined

		const item = this.getTaskHistoryItems().find((entry) => entry.id === taskId)
		return {
			taskId,
			summary: item?.task,
			createdAt: item?.ts,
			state: item?.taskState,
			messages: conversation.messages,
			outstandingAsk: findOutstandingAsk(conversation.messages),
			tokenUsage: conversation.tokenUsage,
		}
	}

	/**
	 * Subscribe to this host's agent event stream. Projects the typed
	 * {@link ShoferEvents} emitter onto the transport-agnostic {@link ServerEvent}
	 * shape, forwarding the {@link FORWARDED_EVENTS} set only — the events a client
	 * needs to render a task, not this host's whole internal chatter.
	 */
	public subscribe(listener: (event: ServerEvent) => void): () => void {
		const handlers = FORWARDED_EVENTS.map((name) => {
			const handler = (...args: unknown[]) => listener({ type: name, args })
			this.on(name as never, handler as never)
			return { name, handler }
		})
		return () => {
			for (const { name, handler } of handlers) {
				this.off(name as never, handler as never)
			}
		}
	}

	public async getTaskConversation(
		taskId: string,
	): Promise<{ messages: ShoferMessage[]; tokenUsage?: TokenUsage } | undefined> {
		const current = this.sidebarProvider.getCurrentTask()
		const live =
			this.sidebarProvider.taskManager.getManagedTaskInstance(taskId) ??
			(current?.taskId === taskId ? current : undefined)

		if (live) {
			return { messages: [...live.shoferMessages], tokenUsage: live.getTokenUsage() }
		}

		const historyItem = await this.sidebarProvider.taskHistoryStore.getOrLoad(taskId)
		if (!historyItem) return undefined

		const { readTaskMessages } = await import("@shofer/core")
		const globalStoragePath = this.sidebarProvider.contextProxy.globalStorageUri.fsPath
		let messages: ShoferMessage[] = []
		try {
			messages = await readTaskMessages({ taskId, globalStoragePath })
		} catch (error) {
			// A corrupt/missing transcript degrades to "nothing said yet" rather than
			// failing the whole attach: the lifecycle and counters are still useful.
			this.log(
				`[API#getTaskConversation] could not read messages for ${taskId}: ${
					error instanceof Error ? error.message : String(error)
				}`,
			)
		}
		return {
			messages,
			tokenUsage: {
				totalTokensIn: historyItem.tokensIn ?? 0,
				totalTokensOut: historyItem.tokensOut ?? 0,
				totalCacheWrites: historyItem.cacheWrites,
				totalCacheReads: historyItem.cacheReads,
				totalCost: historyItem.totalCost ?? 0,
				// Only a live instance knows its context occupancy; a rehydrated
				// transcript reports none rather than a fabricated number.
				contextTokens: 0,
			},
		}
	}

	// ─── Reverse data channel ─────────────────────────────────────────
	// Executor side: resolve the managed task by id and drive the SAME in-process
	// changed-files service (or plugin) a local task uses, so a controller can
	// render/operate a remote task's state over the control plane.

	/** Resolve a managed Task instance by id (else the current task) for L3 ops. */
	private resolveTaskForL3(taskId: string, op: string) {
		const task =
			this.sidebarProvider.taskManager.getManagedTaskInstance(taskId) ?? this.sidebarProvider.getCurrentTask()
		if (!task) this.log(`[API#${op}] no task for ${taskId}`)
		return task
	}

	/**
	 * Generic plugin RPC (`ShoferPlugin.handleRequest`) for a task on THIS host — how a
	 * controller reaches a plugin-owned feature whose per-task state lives on the
	 * executor that runs the task.
	 *
	 * Errors propagate rather than degrading to an empty result (unlike the data methods
	 * above): the caller is waiting on an answer, and "the plugin isn't enabled here" is
	 * something it must be able to tell apart from "there is nothing to show".
	 */
	public async pluginRequest(taskId: string, plugin: string, method: string, params?: unknown): Promise<unknown> {
		const task = this.resolveTaskForL3(taskId, "pluginRequest")
		return pluginRegistry.request(plugin, method, params, {
			taskId: task?.taskId ?? taskId,
			cwd: task?.cwd,
		})
	}

	public deleteQueuedMessage(messageId: string) {
		const currentTask = this.sidebarProvider.getCurrentTask()

		if (!currentTask) {
			this.log(`[API#deleteQueuedMessage] no current task; ignoring delete for messageId ${messageId}`)
			return
		}

		currentTask.messageQueueService.removeMessage(messageId)
	}

	public isReady() {
		return this.sidebarProvider.viewLaunched
	}

	private async waitForWebviewLaunch(timeoutMs: number): Promise<boolean> {
		try {
			await pWaitFor(() => this.sidebarProvider.viewLaunched, {
				timeout: timeoutMs,
				interval: 50,
			})

			return true
		} catch {
			this.log(`[API#waitForWebviewLaunch] webview did not launch within ${timeoutMs}ms`)
			return false
		}
	}

	private registerListeners(provider: ShoferProvider) {
		provider.on(ShoferEventName.TaskCreated, (task) => {
			// Task Lifecycle

			task.on(ShoferEventName.TaskStarted, async () => {
				this.emit(ShoferEventName.TaskStarted, task.taskId)
				await this.fileLog(`[${new Date().toISOString()}] taskStarted -> ${task.taskId}\n`)
			})

			task.on(ShoferEventName.TaskCompleted, async (_, tokenUsage, toolUsage, info) => {
				this.emit(ShoferEventName.TaskCompleted, task.taskId, tokenUsage, toolUsage, {
					rating: info.rating,
					isSubtask: info.isSubtask,
				})

				await this.fileLog(
					`[${new Date().toISOString()}] taskCompleted -> ${task.taskId} | ${JSON.stringify(tokenUsage, null, 2)} | ${JSON.stringify(toolUsage, null, 2)}\n`,
				)
			})

			task.on(ShoferEventName.TaskAborted, (info) => {
				this.emit(ShoferEventName.TaskAborted, task.taskId, info)
			})

			task.on(ShoferEventName.TaskFocused, () => {
				this.emit(ShoferEventName.TaskFocused, task.taskId)
			})

			task.on(ShoferEventName.TaskUnfocused, () => {
				this.emit(ShoferEventName.TaskUnfocused, task.taskId)
			})

			task.on(ShoferEventName.TaskActive, () => {
				this.emit(ShoferEventName.TaskActive, task.taskId)
			})

			task.on(ShoferEventName.TaskInteractive, () => {
				this.emit(ShoferEventName.TaskInteractive, task.taskId)
			})

			task.on(ShoferEventName.TaskResumable, () => {
				this.emit(ShoferEventName.TaskResumable, task.taskId)
			})

			task.on(ShoferEventName.TaskIdle, () => {
				this.emit(ShoferEventName.TaskIdle, task.taskId)
			})

			// Subtask Lifecycle

			task.on(ShoferEventName.TaskPaused, () => {
				this.emit(ShoferEventName.TaskPaused, task.taskId)
			})

			task.on(ShoferEventName.TaskUnpaused, () => {
				this.emit(ShoferEventName.TaskUnpaused, task.taskId)
			})

			task.on(ShoferEventName.TaskSpawned, (childTaskId) => {
				this.emit(ShoferEventName.TaskSpawned, task.taskId, childTaskId)
			})

			task.on(ShoferEventName.TaskDelegated as any, (childTaskId: string) => {
				;(this.emit as any)(ShoferEventName.TaskDelegated, task.taskId, childTaskId)
			})

			task.on(ShoferEventName.TaskDelegationResumed as any, (childTaskId: string) => {
				;(this.emit as any)(ShoferEventName.TaskDelegationResumed, task.taskId, childTaskId)
			})

			// Task Execution

			task.on(ShoferEventName.Message, async (message) => {
				this.emit(ShoferEventName.Message, { taskId: task.taskId, ...message })

				if (message.message.partial !== true) {
					await this.fileLog(`[${new Date().toISOString()}] ${JSON.stringify(message.message, null, 2)}\n`)
				}
			})

			task.on(ShoferEventName.TaskTitleChanged, (taskId, title) => {
				this.emit(ShoferEventName.TaskTitleChanged, taskId, title)
			})

			task.on(ShoferEventName.TaskModeSwitched, (taskId, mode) => {
				this.emit(ShoferEventName.TaskModeSwitched, taskId, mode)
			})

			task.on(ShoferEventName.TaskAskResponded, () => {
				this.emit(ShoferEventName.TaskAskResponded, task.taskId)
			})

			task.on(ShoferEventName.QueuedMessagesUpdated, (taskId, messages) => {
				this.emit(ShoferEventName.QueuedMessagesUpdated, taskId, messages)
			})

			// Task Analytics

			task.on(ShoferEventName.TaskToolFailed, (taskId, tool, error) => {
				this.emit(ShoferEventName.TaskToolFailed, taskId, tool, error)
			})

			task.on(ShoferEventName.TaskTokenUsageUpdated, (_, tokenUsage, toolUsage) => {
				this.emit(ShoferEventName.TaskTokenUsageUpdated, task.taskId, tokenUsage, toolUsage)
			})

			// Let's go!

			this.emit(ShoferEventName.TaskCreated, task.taskId)
		})
	}

	// Logging

	private outputChannelLog(...args: unknown[]) {
		for (const arg of args) {
			if (arg === null) {
				this.outputChannel.appendLine("null")
			} else if (arg === undefined) {
				this.outputChannel.appendLine("undefined")
			} else if (typeof arg === "string") {
				this.outputChannel.appendLine(arg)
			} else if (arg instanceof Error) {
				this.outputChannel.appendLine(`Error: ${arg.message}\n${arg.stack || ""}`)
			} else {
				try {
					this.outputChannel.appendLine(
						JSON.stringify(
							arg,
							(key, value) => {
								if (typeof value === "bigint") return `BigInt(${value})`
								if (typeof value === "function") return `Function: ${value.name || "anonymous"}`
								if (typeof value === "symbol") return value.toString()
								return value
							},
							2,
						),
					)
				} catch (error) {
					this.outputChannel.appendLine(`[Non-serializable object: ${Object.prototype.toString.call(arg)}]`)
				}
			}
		}
	}

	private async fileLog(message: string) {
		if (!this.logfile) {
			return
		}

		try {
			await fs.appendFile(this.logfile, message, "utf8")
		} catch (_) {
			this.logfile = undefined
		}
	}

	// Global Settings Management

	public getConfiguration(): ShoferSettings {
		return Object.fromEntries(
			Object.entries(this.sidebarProvider.getValues()).filter(([key]) => !isSecretStateKey(key)),
		)
	}

	public async setConfiguration(values: ShoferSettings) {
		await this.sidebarProvider.contextProxy.setValues(values)
		await this.sidebarProvider.providerSettingsManager.saveConfig(values.currentApiConfigName || "default", values)
		await this.sidebarProvider.postInitState()
	}

	// Provider Profile Management

	public getProfiles(): string[] {
		return this.sidebarProvider.getProviderProfileEntries().map(({ name }) => name)
	}

	public getProfileEntry(name: string): ProviderSettingsEntry | undefined {
		return this.sidebarProvider.getProviderProfileEntry(name)
	}

	public async createProfile(name: string, profile?: ProviderSettings, activate: boolean = true) {
		const entry = this.getProfileEntry(name)

		if (entry) {
			throw new Error(`Profile with name "${name}" already exists`)
		}

		// upsertProviderProfile saves the config + refreshes live settings when activate=true,
		// but no longer sets currentApiConfigName (that is now the sole responsibility of
		// activateProviderProfile / setDefaultApiConfiguration). When activate is requested,
		// follow up with an explicit activation so the profile becomes the global default.
		// Pass activate=false — upsertProviderProfile just saves; activateProviderProfile
		// below handles the single live refresh + global default set when activate=true.
		const id = await this.sidebarProvider.upsertProviderProfile(name, profile ?? {}, false)

		if (!id) {
			throw new Error(`Failed to create profile with name "${name}"`)
		}

		if (activate) {
			await this.sidebarProvider.activateProviderProfile({ name })
		}

		return id
	}

	public async updateProfile(
		name: string,
		profile: ProviderSettings,
		activate: boolean = true,
	): Promise<string | undefined> {
		const entry = this.getProfileEntry(name)

		if (!entry) {
			throw new Error(`Profile with name "${name}" does not exist`)
		}

		// upsertProviderProfile saves the config + refreshes live settings when activate=true,
		// but no longer sets currentApiConfigName. Activate explicitly when requested.
		// Pass activate=false — upsertProviderProfile just saves; activateProviderProfile
		// below handles the single live refresh + global default set when activate=true.
		const id = await this.sidebarProvider.upsertProviderProfile(name, profile, false)

		if (!id) {
			throw new Error(`Failed to update profile with name "${name}"`)
		}

		if (activate) {
			await this.sidebarProvider.activateProviderProfile({ name })
		}

		return id
	}

	public async upsertProfile(
		name: string,
		profile: ProviderSettings,
		activate: boolean = true,
	): Promise<string | undefined> {
		// upsertProviderProfile saves the config + refreshes live settings when activate=true,
		// but no longer sets currentApiConfigName. Activate explicitly when requested.
		// Pass activate=false — upsertProviderProfile just saves; activateProviderProfile
		// below handles the single live refresh + global default set when activate=true.
		const id = await this.sidebarProvider.upsertProviderProfile(name, profile, false)

		if (!id) {
			throw new Error(`Failed to upsert profile with name "${name}"`)
		}

		if (activate) {
			await this.sidebarProvider.activateProviderProfile({ name })
		}

		return id
	}

	public async deleteProfile(name: string): Promise<void> {
		const entry = this.getProfileEntry(name)

		if (!entry) {
			throw new Error(`Profile with name "${name}" does not exist`)
		}

		await this.sidebarProvider.deleteProviderProfile(entry)
	}

	public getActiveProfile(): string | undefined {
		return this.getConfiguration().currentApiConfigName
	}

	public async setActiveProfile(name: string): Promise<string | undefined> {
		const entry = this.getProfileEntry(name)

		if (!entry) {
			throw new Error(`Profile with name "${name}" does not exist`)
		}

		await this.sidebarProvider.activateProviderProfile({ name })
		return this.getActiveProfile()
	}

	// ─── Task History & Management (TaskSelector parity) ───────────

	public getTaskHistoryItems(): HistoryItem[] {
		return this.sidebarProvider.taskHistoryStore.getAll()
	}

	public async showTaskWithId(taskId: string, options?: { keepCurrentTask?: boolean }): Promise<void> {
		await this.sidebarProvider.showTaskWithId(taskId, options)
	}

	public async renameTask(taskId: string, name: string): Promise<void> {
		const { historyItem } = await this.sidebarProvider.getTaskWithId(taskId)
		if (!historyItem) {
			throw new Error(`Task not found: ${taskId}`)
		}
		await this.sidebarProvider.updateTaskHistory({ ...historyItem, name })
		this.sidebarProvider.renameManagedTask(taskId, name)
	}

	public async archiveTask(taskId: string): Promise<void> {
		await this.sidebarProvider.archiveManagedTask(taskId)
	}

	public async unarchiveTask(taskId: string): Promise<void> {
		await this.sidebarProvider.unarchiveManagedTask(taskId)
	}

	public async pinTask(taskId: string): Promise<void> {
		await this.sidebarProvider.pinManagedTask(taskId)
	}

	public async unpinTask(taskId: string): Promise<void> {
		await this.sidebarProvider.unpinManagedTask(taskId)
	}

	public async deleteTask(taskId: string, cascadeSubtasks: boolean = true): Promise<void> {
		await this.sidebarProvider.deleteTaskWithId(taskId, cascadeSubtasks)
	}

	// ─── Task Export (data-returning variants) ──────────────────────

	public async getTaskMarkdownExport(taskId: string): Promise<string> {
		const { historyItem, apiConversationHistory } = await this.sidebarProvider.getTaskWithId(taskId)

		return apiConversationHistory
			.map((message) => {
				const role = message.role === "user" ? "**User:**" : "**Assistant:**"
				const content = Array.isArray(message.content)
					? message.content.map((block) => formatContentBlockToMarkdown(block as any)).join("\n")
					: message.content
				return `${role}\n\n${content}\n\n`
			})
			.join("---\n\n")
	}

	public async getTaskJsonExport(taskId: string): Promise<Record<string, unknown>> {
		const { historyItem, apiConversationHistory } = await this.sidebarProvider.getTaskWithId(taskId)

		// Read ui_messages for per-request metadata via the JSONL reader.
		let uiMessages: Array<{ type: string; say?: string; ts: number; text?: string }> = []
		try {
			const { readTaskMessages } = await import("@shofer/core")
			const globalStoragePath = this.sidebarProvider.contextProxy.globalStorageUri.fsPath
			uiMessages = (await readTaskMessages({ taskId, globalStoragePath })) as typeof uiMessages
		} catch {
			// Fall through with empty uiMessages — the trace will lack per-call metadata.
		}

		const trace = buildJsonTrace(
			taskId,
			historyItem.task || historyItem.ts?.toString() || "",
			historyItem.mode,
			historyItem.ts ? new Date(historyItem.ts).toISOString() : new Date().toISOString(),
			apiConversationHistory,
			uiMessages,
			{ title: historyItem.name },
		)

		return trace as unknown as Record<string, unknown>
	}

	// ─── Logging ────────────────────────────────────────────────────

	public getOutputLogs(maxLines: number = 2000): string {
		return getRecentLogs(maxLines)
	}

	// ─── Configuration Import/Export ─────────────────────────────────

	public exportConfiguration(): string {
		const config = this.getConfiguration()
		return JSON.stringify(config, null, 2)
	}

	public async importConfiguration(json: string): Promise<void> {
		let parsed: ShoferSettings
		try {
			parsed = JSON.parse(json) as ShoferSettings
		} catch (err) {
			throw new Error(`Invalid configuration JSON: ${err instanceof Error ? err.message : String(err)}`)
		}
		await this.setConfiguration(parsed)
	}
}
