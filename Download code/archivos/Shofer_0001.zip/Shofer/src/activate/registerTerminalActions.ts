import * as vscode from "vscode"
import { getHost } from "@shofer/types"

import { TerminalActionId, TerminalActionPromptType } from "@shofer/types"

import { getTerminalCommand } from "@shofer/core"
import { ShoferProvider } from "../core/webview/ShoferProvider"
import { Terminal } from "../integrations/terminal/Terminal"
import { t } from "@shofer/core"

export const registerTerminalActions = (context: vscode.ExtensionContext) => {
	registerTerminalAction(context, "terminalAddToContext", "TERMINAL_ADD_TO_CONTEXT")
	registerTerminalAction(context, "terminalFixCommand", "TERMINAL_FIX")
	registerTerminalAction(context, "terminalExplainCommand", "TERMINAL_EXPLAIN")
}

const registerTerminalAction = (
	context: vscode.ExtensionContext,
	command: TerminalActionId,
	promptType: TerminalActionPromptType,
) => {
	context.subscriptions.push(
		vscode.commands.registerCommand(getTerminalCommand(command), async (args: any) => {
			let content = args?.selection

			if (!content || content === "") {
				content = await Terminal.getTerminalContents(promptType === "TERMINAL_ADD_TO_CONTEXT" ? -1 : 1)
			}

			if (!content) {
				getHost().notifier.warn(t("common:warnings.no_terminal_content"))
				return
			}

			await ShoferProvider.handleTerminalAction(command, promptType, {
				terminalContent: content,
			})
		}),
	)
}
