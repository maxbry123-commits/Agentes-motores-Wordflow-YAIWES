/**
 * Interface for vector database clients
 */
export type PointStruct = {
	id: string
	vector: number[]
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	payload: Record<string, any>
}

/**
 * Metadata stored alongside indexed vectors (a special point with type: "metadata").
 * Used by the git-aware narrowing layer (Phase 2) to diff only changed files.
 */
export interface IndexingMetadata {
	indexing_complete: boolean
	started_at?: number
	completed_at?: number
	/** HEAD commit sha at the last successful Indexed transition. */
	lastIndexedCommit?: string
	/** Epoch ms of the last successful Indexed transition. */
	lastIndexedAt?: number
	/** Submodule path → HEAD commit sha at the last Indexed transition. */
	submoduleCommits?: Record<string, string>
}

export interface IVectorStore {
	/**
	 * Initializes the vector store
	 * @returns Promise resolving to boolean indicating if a new collection was created
	 */
	initialize(): Promise<boolean>

	/**
	 * Upserts points into the vector store
	 * @param points Array of points to upsert
	 */
	upsertPoints(points: PointStruct[]): Promise<void>

	/**
	 * Searches for similar vectors
	 * @param queryVector Vector to search for
	 * @param directoryPrefix Optional directory prefix to filter results
	 * @param minScore Optional minimum score threshold
	 * @param maxResults Optional maximum number of results to return
	 * @returns Promise resolving to search results
	 */
	search(
		queryVector: number[],
		directoryPrefix?: string,
		minScore?: number,
		maxResults?: number,
	): Promise<VectorStoreSearchResult[]>

	/**
	 * Deletes points by file path
	 * @param filePath Path of the file to delete points for
	 */
	deletePointsByFilePath(filePath: string): Promise<void>

	/**
	 * Deletes points by multiple file paths
	 * @param filePaths Array of file paths to delete points for
	 */
	deletePointsByMultipleFilePaths(filePaths: string[]): Promise<void>

	/**
	 * Clears all points from the collection
	 */
	clearCollection(): Promise<void>

	/**
	 * Deletes the entire collection.
	 */
	deleteCollection(): Promise<void>

	/**
	 * Checks if the collection exists
	 * @returns Promise resolving to boolean indicating if the collection exists
	 */
	collectionExists(): Promise<boolean>

	/**
	 * Checks if the collection exists and has indexed points
	 * @returns Promise resolving to boolean indicating if the collection exists and has points
	 */
	hasIndexedData(): Promise<boolean>

	/**
	 * Marks the indexing process as complete by storing metadata.
	 * @param commit Optional current HEAD commit sha for git-aware narrowing.
	 * @param submoduleCommits Optional submodule path → HEAD commit map.
	 */
	markIndexingComplete(commit?: string, submoduleCommits?: Record<string, string>): Promise<void>

	/**
	 * Marks the indexing process as incomplete by storing metadata.
	 */
	markIndexingIncomplete(): Promise<void>

	/**
	 * Deletes specific points by their Qdrant point IDs.
	 * @param pointIds Array of point ID strings to delete
	 */
	deletePointsByIds(pointIds: string[]): Promise<void>

	/**
	 * Returns the indexing metadata point, or undefined if none exists.
	 */
	getMetadata(): Promise<IndexingMetadata | undefined>
}

export interface VectorStoreSearchResult {
	id: string | number
	score: number
	payload?: Payload | null
}

export interface Payload {
	filePath: string
	codeChunk: string
	startLine: number
	endLine: number
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	[key: string]: any
}
