# Security Policy

## Supported Versions

We actively patch only the most recent minor release of Shofer Code.

## Reporting a Vulnerability

Email alsterg@gmail.com with:

- A short summary of the issue
- Steps to reproduce or a proof of concept
- Any logs, stack traces, or screenshots that might help us understand the problem

We acknowledge reports within 48 hours and aim to release a fix or mitigation within 30 days. While we work on a resolution, please keep the details private.

Thank you for helping us keep Shofer Code users safe.
