# Repo Growth Launch

## Trigger

A new public repository needs to be useful, discoverable, and launch-ready.

## Goal

README, topics, demo, contribution path, launch copy, and telemetry checklist.

## Agent brief

```text
You are executing the "Repo Growth Launch" workflow.

Context:
- Repo/system: [name and path]
- User goal: [goal]
- Allowed scope: [files, commands, services]
- Forbidden scope: [secrets, production, unrelated files, destructive actions]

Required output:
- Actions taken
- Evidence collected
- Files changed
- Verification commands and results
- Blockers or stop conditions
```

## Steps

1. Restate the goal, scope, and non-goals in one paragraph.
2. Gather only the context needed for this workflow.
3. Identify the riskiest assumption and test it early.
4. Execute in small increments.
5. Record evidence as you go.
6. Run the verification checklist before any success claim.
7. Leave a handoff note with exact next steps.

## Verification checklist

- [ ] Scope boundaries are explicit.
- [ ] Assumptions are labeled.
- [ ] Evidence is from tools, files, commands, screenshots, or cited sources.
- [ ] No secrets are printed or requested.
- [ ] The final status distinguishes verified facts from recommendations.

## Failure modes

- Treating a confident model answer as evidence.
- Expanding scope because the agent found adjacent problems.
- Reporting "done" before running the verification command.
- Losing track of files changed by parallel or delegated workers.

## Human gate

No fake stars, paid engagement, spam, or deceptive automation.

## Related templates

- [Agent brief](../templates/agent-brief.md)
- [PR review](../templates/pr-review.md)
- [Release checklist](../templates/release-checklist.md)
