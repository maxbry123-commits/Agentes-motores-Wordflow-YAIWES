"""
Tests for daemon platform detection and dispatch.

Tests that _detect_platform returns the correct backend for different platforms.
"""

import pytest
from unittest.mock import patch, MagicMock

from praisonai_bot.daemon import _detect_platform, install_daemon, uninstall_daemon, get_daemon_status


def test_detect_platform_linux():
    """Test platform detection on Linux."""
    with patch('platform.system', return_value='Linux'):
        assert _detect_platform() == 'systemd'


def test_detect_platform_macos():
    """Test platform detection on macOS."""
    with patch('platform.system', return_value='Darwin'):
        assert _detect_platform() == 'launchd'


def test_detect_platform_windows():
    """Test platform detection on Windows."""
    with patch('platform.system', return_value='Windows'):
        assert _detect_platform() == 'windows'


def test_detect_platform_unknown():
    """Test platform detection on unknown OS."""
    with patch('platform.system', return_value='FreeBSD'):
        assert _detect_platform() == 'unknown'


@patch('praisonai_bot.daemon._detect_platform', return_value='systemd')
@patch('praisonai_bot.daemon.systemd.install')
def test_install_daemon_routes_to_systemd(mock_systemd_install, mock_detect):
    """Test that install_daemon routes to systemd on Linux."""
    mock_systemd_install.return_value = {"ok": True, "message": "Installed"}
    
    result = install_daemon(config_path="test.yaml")
    
    mock_systemd_install.assert_called_once_with(config_path="test.yaml")
    assert result["ok"] is True


@patch('praisonai_bot.daemon._detect_platform', return_value='launchd')
@patch('praisonai_bot.daemon.launchd.install')
def test_install_daemon_routes_to_launchd(mock_launchd_install, mock_detect):
    """Test that install_daemon routes to launchd on macOS."""
    mock_launchd_install.return_value = {"ok": True, "message": "Installed"}
    
    result = install_daemon(config_path="test.yaml")
    
    mock_launchd_install.assert_called_once_with(config_path="test.yaml")
    assert result["ok"] is True


@patch('praisonai_bot.daemon._detect_platform', return_value='windows')
@patch('praisonai_bot.daemon.windows.install')
def test_install_daemon_routes_to_windows(mock_windows_install, mock_detect):
    """Test that install_daemon routes to windows backend."""
    mock_windows_install.return_value = {"ok": True, "message": "Installed"}
    
    result = install_daemon(config_path="test.yaml")
    
    mock_windows_install.assert_called_once_with(config_path="test.yaml")
    assert result["ok"] is True


@patch('praisonai_bot.daemon._detect_platform', return_value='unknown')
def test_install_daemon_unsupported_platform(mock_detect):
    """Test that install_daemon handles unsupported platforms."""
    result = install_daemon(config_path="test.yaml")
    
    assert result["ok"] is False
    assert "Unsupported platform" in result["error"]


@patch('praisonai_bot.daemon._detect_platform', return_value='systemd')
@patch('praisonai_bot.daemon.systemd.get_status')
def test_get_daemon_status_routes_to_systemd(mock_systemd_status, mock_detect):
    """Test that get_daemon_status routes to systemd on Linux."""
    mock_systemd_status.return_value = {"installed": True, "running": True}
    
    result = get_daemon_status()
    
    mock_systemd_status.assert_called_once()
    assert result["installed"] is True


@patch('praisonai_bot.daemon.windows.subprocess.run')
def test_windows_scheduled_task_command_is_well_formed(mock_run):
    """Test Windows scheduled task command format is valid.

    The task action (/TR) points at the generated ``.cmd`` wrapper rather than
    an inline ``<python> ... --config ...`` command so that paths containing
    spaces (e.g. ``C:\\Program Files``) aren't broken by nested quoting. The
    wrapper itself owns the ``--config`` invocation and the exit-78 mapping.
    """
    mock_run.return_value = MagicMock(stdout="ok")

    from praisonai_bot.daemon.windows import (
        _create_scheduled_task,
        _startup_script_path,
        _generate_startup_script,
    )
    result = _create_scheduled_task(config_path="bot.yaml")

    assert result["ok"] is True
    cmd = mock_run.call_args.args[0]
    assert "/SD" not in cmd
    assert "/TR" in cmd
    tr_value = cmd[cmd.index("/TR") + 1]

    assert _startup_script_path() in tr_value
    assert tr_value.endswith(".cmd") or tr_value.endswith('.cmd"')
    assert "&" not in tr_value
    assert "%ERRORLEVEL%" not in tr_value

    wrapper = _generate_startup_script("bot.yaml")
    assert "--config" in wrapper
