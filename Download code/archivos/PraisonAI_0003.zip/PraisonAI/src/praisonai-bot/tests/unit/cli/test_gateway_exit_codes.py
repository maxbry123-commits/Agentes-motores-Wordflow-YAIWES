"""CLI integration tests for the gateway restart-intent exit codes (#2437).

The pure classifier is covered in praisonai-agents; these tests assert the
wrapper ``GatewayHandler.start`` returns the correct *supervisor-facing* exit
code for the integration paths reviewers flagged:

* a missing / malformed / schema-invalid ``gateway.yaml`` must be FATAL (78),
  never restartable (75), so a misconfig does not crash-loop;
* a broken ``--agents`` file must be FATAL (78), not a silent success (0) that
  starts an empty gateway looking healthy to a supervisor.
"""

import pytest

from praisonai_bot.cli.features.gateway import GatewayHandler
from praisonaiagents.gateway import (
    GATEWAY_FATAL_CONFIG_EXIT_CODE,
    GATEWAY_OK_EXIT_CODE,
    GATEWAY_RESTART_EXIT_CODE,
)


def test_missing_gateway_yaml_is_fatal(tmp_path):
    handler = GatewayHandler()
    missing = tmp_path / "does_not_exist.yaml"
    code = handler.start(config_file=str(missing))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_empty_gateway_yaml_is_fatal(tmp_path):
    handler = GatewayHandler()
    cfg = tmp_path / "gateway.yaml"
    cfg.write_text("")  # empty -> load_gateway_config raises ValueError
    code = handler.start(config_file=str(cfg))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_schema_invalid_gateway_yaml_is_fatal(tmp_path):
    handler = GatewayHandler()
    cfg = tmp_path / "gateway.yaml"
    # Valid YAML mapping but missing the required agents/channels sections.
    cfg.write_text("gateway:\n  host: 127.0.0.1\n")
    code = handler.start(config_file=str(cfg))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_missing_agents_file_is_fatal(tmp_path):
    handler = GatewayHandler()
    missing = tmp_path / "agents.yaml"
    code = handler.start(agent_file=str(missing))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_agents_file_without_agents_section_is_fatal(tmp_path):
    handler = GatewayHandler()
    agents = tmp_path / "agents.yaml"
    agents.write_text("not_agents: []\n")
    code = handler.start(agent_file=str(agents))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_agents_file_with_non_mapping_entry_is_fatal(tmp_path):
    # A truthy 'agents' list with a non-mapping item (e.g. ["bad"]) used to
    # raise AttributeError on .get(), routing through classify_exit_reason to
    # the restart code (75) and crash-looping forever. It must be FATAL (78).
    handler = GatewayHandler()
    agents = tmp_path / "agents.yaml"
    agents.write_text("agents:\n  - bad\n")
    code = handler.start(agent_file=str(agents))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_agents_section_not_a_list_is_fatal(tmp_path):
    handler = GatewayHandler()
    agents = tmp_path / "agents.yaml"
    agents.write_text("agents:\n  name: bad\n")
    code = handler.start(agent_file=str(agents))
    assert code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_load_agents_raises_fatal_config_error(tmp_path):
    from praisonai_bot.cli.features.gateway import FatalConfigError

    handler = GatewayHandler()
    missing = tmp_path / "nope.yaml"
    with pytest.raises(FatalConfigError):
        handler._load_agents_from_file(str(missing))


def test_exit_codes_are_distinct():
    # The whole point of #2437: a misconfig must not look like a transient blip.
    assert GATEWAY_OK_EXIT_CODE == 0
    assert GATEWAY_FATAL_CONFIG_EXIT_CODE != GATEWAY_RESTART_EXIT_CODE


def test_serve_gateway_command_propagates_fatal_exit_code(monkeypatch):
    # Greptile P1: `praisonai serve gateway` discarded start()'s int return, so
    # a fatal-config (78) start exited the Typer command with 0 — a misconfig
    # looked like a healthy gateway to a supervisor. The command must propagate.
    import typer

    from praisonai.cli.commands import serve as serve_cmd

    def fake_start(self, *, host, port, agent_file=None):
        return GATEWAY_FATAL_CONFIG_EXIT_CODE

    monkeypatch.setattr(
        "praisonai.cli.features.gateway.GatewayHandler.start", fake_start
    )

    with pytest.raises(typer.Exit) as excinfo:
        serve_cmd.serve_gateway(
            host="127.0.0.1", port=8765, agents_file="/missing.yaml"
        )
    assert excinfo.value.exit_code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_serve_gateway_command_clean_shutdown_exits_zero(monkeypatch):
    import typer

    from praisonai.cli.commands import serve as serve_cmd

    def fake_start(self, *, host, port, agent_file=None):
        return GATEWAY_OK_EXIT_CODE

    monkeypatch.setattr(
        "praisonai.cli.features.gateway.GatewayHandler.start", fake_start
    )

    with pytest.raises(typer.Exit) as excinfo:
        serve_cmd.serve_gateway(host="127.0.0.1", port=8765, agents_file=None)
    assert excinfo.value.exit_code == GATEWAY_OK_EXIT_CODE


def test_bot_gateway_start_command_propagates_fatal_exit_code(monkeypatch):
    # #3160: the installed daemons run `python -m praisonai_bot gateway start`,
    # which routes through the standalone `praisonai_bot` Typer command. That
    # command discarded start()'s int return, so a fatal-config (78) start
    # exited the process with 0 — the generated units' RestartPreventExitStatus
    # / Restart=on-failure / KeepAlive.SuccessfulExit directives never saw the
    # real code. The command must surface it via typer.Exit.
    import typer

    from praisonai_bot.cli.commands import gateway as bot_gateway_cmd

    def fake_start(self, **kwargs):
        return GATEWAY_FATAL_CONFIG_EXIT_CODE

    monkeypatch.setattr(
        "praisonai_bot.cli.features.gateway.GatewayHandler.start", fake_start
    )

    with pytest.raises(typer.Exit) as excinfo:
        bot_gateway_cmd.gateway_start(
            host="127.0.0.1", port=8765, agents="/missing.yaml",
            config=None, preflight=False, openai_api=False, mcp=False,
        )
    assert excinfo.value.exit_code == GATEWAY_FATAL_CONFIG_EXIT_CODE


def test_bot_gateway_start_command_clean_shutdown_exits_zero(monkeypatch, tmp_path):
    import typer

    from praisonai_bot.cli.commands import gateway as bot_gateway_cmd

    # Pass an explicit channel-less config so this test asserts ONLY exit-code
    # propagation. With config=None it would auto-discover a ``./gateway.yaml``
    # and run the verify-turn pre-flight (a real agent turn) before the patched
    # start(); a channels-less config skips every pre-flight and reaches it
    # deterministically, in any cwd, without a live LLM call (#4042/#4070).
    cfg = tmp_path / "gateway.yaml"
    cfg.write_text("agents:\n  personal:\n    instructions: hi\n    model: gpt-4o-mini\n")
    monkeypatch.chdir(tmp_path)

    def fake_start(self, **kwargs):
        return GATEWAY_OK_EXIT_CODE

    monkeypatch.setattr(
        "praisonai_bot.cli.features.gateway.GatewayHandler.start", fake_start
    )

    with pytest.raises(typer.Exit) as excinfo:
        bot_gateway_cmd.gateway_start(
            host="127.0.0.1", port=8765, agents=None,
            config=str(cfg), preflight=False, openai_api=False, mcp=False,
        )
    assert excinfo.value.exit_code == GATEWAY_OK_EXIT_CODE
