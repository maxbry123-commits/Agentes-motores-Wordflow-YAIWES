"""
Test that Telegram gateway polling path enforces security checks.

This test verifies the fix for issue #1747 where gateway Telegram polling
bypassed allowed_users, pairing, and group policy enforcement.

The fix introduces a shared security pipeline `process_inbound_telegram_message()`
used by both standalone and gateway paths to ensure identical security enforcement.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from praisonaiagents.bots import BotConfig, BotUser
from praisonai_bot.bots.telegram import TelegramBot, process_inbound_telegram_message
from praisonai_bot.bots._unknown_user import UnknownUserHandler


def create_mock_telegram_update(user_id: str = "12345", chat_id: str = "-100123456789", text: str = "test message", chat_type: str = "group"):
    """Create a mock Telegram Update for testing."""
    update = MagicMock()
    
    # Mock message
    update.message = MagicMock()
    update.message.text = text
    update.message.voice = None
    update.message.audio = None
    update.message.date.timestamp.return_value = 1234567890.0
    update.message.message_id = 123
    update.message.message_thread_id = None
    
    # Mock user
    update.message.from_user = MagicMock()
    update.message.from_user.id = int(user_id)
    update.message.from_user.username = f"user_{user_id}"
    update.message.from_user.first_name = f"User {user_id}"
    update.message.from_user.is_bot = False
    
    # Mock chat
    update.message.chat = MagicMock()
    update.message.chat.id = int(chat_id)
    update.message.chat.type = chat_type
    update.message.chat.title = "Test Group" if chat_type == "group" else None
    update.message.chat.username = f"chat_{chat_id}"
    
    return update


def create_test_bot(
    allowed_users=None,
    allowed_channels=None,
    group_policy="mention_only",
    unknown_user_policy="deny",
) -> TelegramBot:
    """Create a TelegramBot for testing with specified security config."""
    config = BotConfig(
        token="test_token",
        allowed_users=allowed_users or [],
        allowed_channels=allowed_channels or [],
        group_policy=group_policy,
        unknown_user_policy=unknown_user_policy,
    )
    
    bot = TelegramBot(token="test_token", config=config)
    
    # Mock required attributes
    bot._bot_user = BotUser(
        user_id="123456789",
        username="test_bot",
        display_name="Test Bot",
        is_bot=True,
    )
    
    # Mock the fire_message_received method and other required attributes.
    # It now returns an inbound gate decision dict (drop/content).
    bot.fire_message_received = MagicMock(return_value={"drop": False, "content": ""})
    bot._started_at = 1234567890.0
    bot._agent = MagicMock()
    bot._command_handlers = {}
    bot._session = MagicMock()
    
    return bot


@pytest.mark.asyncio
async def test_user_allowlist_enforcement():
    """Test that user allowlist is enforced in the security pipeline."""
    
    # Bot with restricted user allowlist
    bot = create_test_bot(allowed_users=["42"])
    
    # Message from allowed user
    allowed_update = create_mock_telegram_update(user_id="42", text="hello", chat_type="private")
    allowed_message = await process_inbound_telegram_message(allowed_update, bot)
    assert allowed_message is not None, "Message from allowed user should pass"
    assert allowed_message.sender.user_id == "42"
    
    # Message from disallowed user
    disallowed_update = create_mock_telegram_update(user_id="99", text="hello", chat_type="private")
    disallowed_message = await process_inbound_telegram_message(disallowed_update, bot)
    assert disallowed_message is None, "Message from disallowed user should be blocked"

    # Group message from allowed user should still pass allowlist checks
    allowed_group_update = create_mock_telegram_update(user_id="42", text="@test_bot hello", chat_type="group")
    allowed_group_message = await process_inbound_telegram_message(allowed_group_update, bot)
    assert allowed_group_message is not None, "Allowlisted users should pass in group chats too"


@pytest.mark.asyncio
async def test_channel_allowlist_enforcement():
    """Test that channel allowlist is enforced in the security pipeline."""
    
    # Bot with restricted channel allowlist
    bot = create_test_bot(
        allowed_channels=["-100123456789"],
        unknown_user_policy="allow",
    )
    
    # Message from allowed channel
    allowed_update = create_mock_telegram_update(chat_id="-100123456789", text="@test_bot hello", chat_type="supergroup")
    allowed_message = await process_inbound_telegram_message(allowed_update, bot)
    assert allowed_message is not None, "Message from allowed channel should pass"
    assert allowed_message.channel.channel_id == "-100123456789"
    
    # Message from disallowed channel
    disallowed_update = create_mock_telegram_update(chat_id="-100999999999", text="@test_bot hello", chat_type="supergroup")
    disallowed_message = await process_inbound_telegram_message(disallowed_update, bot)
    assert disallowed_message is None, "Message from disallowed channel should be blocked"


@pytest.mark.asyncio
async def test_group_policy_mention_enforcement():
    """Test that group mention policy is enforced in the security pipeline."""
    
    # Bot with mention_only group policy
    bot = create_test_bot(group_policy="mention_only", unknown_user_policy="allow")
    bot._bot_user.username = "Test_Bot"
    
    # Group message with bot mention - should pass
    mention_update = create_mock_telegram_update(
        chat_type="group", 
        text="@test_bot please help"
    )
    mention_message = await process_inbound_telegram_message(mention_update, bot)
    assert mention_message is not None, "Group message with mention should pass"
    
    # Group message without mention - should be blocked
    no_mention_update = create_mock_telegram_update(
        chat_type="group", 
        text="hello everyone"
    )
    no_mention_message = await process_inbound_telegram_message(no_mention_update, bot)
    assert no_mention_message is None, "Group message without mention should be blocked"
    
    # Commands should always pass regardless of mention
    command_update = create_mock_telegram_update(
        chat_type="group", 
        text="/help"
    )
    command_message = await process_inbound_telegram_message(command_update, bot)
    assert command_message is not None, "Commands should always pass in groups"


@pytest.mark.asyncio
async def test_group_policy_observe_records_passive_context():
    """Issue #3380: ``observe`` records unmentioned group messages as context.

    Under ``observe`` an unmentioned group message must NOT trigger a run
    (returns None) but must be recorded to the session as passive context so
    the bot has memory when it is next addressed. A mention still runs.
    """
    bot = create_test_bot(group_policy="observe", unknown_user_policy="allow")
    bot._bot_user.username = "Test_Bot"

    # Unmentioned group message: dropped from dispatch but recorded passively.
    no_mention_update = create_mock_telegram_update(
        chat_type="group", text="we just decided to ship on Friday"
    )
    no_mention_message = await process_inbound_telegram_message(no_mention_update, bot)
    assert no_mention_message is None, "observe must not trigger a run on no mention"
    assert bot._session.record_passive.called, (
        "observe must record unmentioned group messages as passive context"
    )
    args, kwargs = bot._session.record_passive.call_args
    assert "we just decided to ship on Friday" in (args[1] if len(args) > 1 else kwargs.get("content", ""))
    # Issue #3380: the passive entry must carry the same routing an addressed
    # turn uses so that with session_scope="per_chat" it lands on the shared
    # group key the next mentioned run reads from (Greptile P1 / CodeRabbit).
    assert kwargs.get("chat_id") == "-100123456789", (
        "passive recording must thread chat_id so per_chat sessions see it"
    )

    # A mention still passes through to a real run.
    bot._session.record_passive.reset_mock()
    mention_update = create_mock_telegram_update(
        chat_type="group", text="@test_bot summarise what we just decided"
    )
    mention_message = await process_inbound_telegram_message(mention_update, bot)
    assert mention_message is not None, "observe must still run when the bot is mentioned"
    assert not bot._session.record_passive.called, (
        "a mentioned message runs; it is not recorded as passive-only context"
    )


@pytest.mark.asyncio
async def test_record_passive_per_chat_key_visible_to_addressed_turn():
    """Issue #3380 (Greptile P1 / CodeRabbit): passive context must use the
    per_chat group key, not the sender's per_user key.

    With ``session_scope="per_chat"`` an addressed turn reads the shared
    ``(platform, account, chat_id, thread_id)`` key. A passive record threaded
    with the same routing must persist under that identical key so the bot sees
    the preceding conversation when next mentioned — and must NOT leak into the
    sender's separate per_user history.
    """
    from praisonai_bot.bots._session import BotSessionManager

    mgr = BotSessionManager(platform="telegram", session_scope="per_chat")
    route = {"account": "default", "chat_id": "-100999", "thread_id": ""}

    ok = mgr.record_passive("sender42", "we ship on Friday", sender="Ann", **route)
    assert ok is True

    # The addressed turn resolves this shared group key.
    group_key = mgr._storage_key("sender42", **route)
    history = mgr._load_history("sender42", **route)
    assert any(
        e.get("passive") and "we ship on Friday" in e.get("content", "")
        for e in history
    ), "passive entry must be visible under the shared per_chat group key"

    # It must NOT have leaked into the sender's separate per_user history.
    per_user_key = mgr._storage_key("sender42")
    assert per_user_key != group_key, "per_chat key must differ from per_user key"
    assert not mgr._histories.get(per_user_key), (
        "passive entry must not leak into the sender's per_user history"
    )


@pytest.mark.asyncio
async def test_dm_messages_bypass_group_policies():
    """Test that DM messages bypass group-specific policies."""
    
    # Bot with mention_only group policy
    bot = create_test_bot(group_policy="mention_only", unknown_user_policy="allow")
    
    # DM message without mention - should pass
    dm_update = create_mock_telegram_update(
        chat_type="private", 
        text="hello bot"
    )
    dm_message = await process_inbound_telegram_message(dm_update, bot)
    assert dm_message is not None, "DM messages should bypass group mention requirements"


@pytest.mark.asyncio
async def test_group_policy_command_only_enforcement():
    """Test that command_only only allows commands in groups."""
    bot = create_test_bot(group_policy="command_only", unknown_user_policy="allow")

    message_update = create_mock_telegram_update(chat_type="group", text="hello everyone")
    message = await process_inbound_telegram_message(message_update, bot)
    assert message is None, "Non-command group messages should be blocked in command_only mode"

    command_update = create_mock_telegram_update(chat_type="group", text="/help")
    command_message = await process_inbound_telegram_message(command_update, bot)
    assert command_message is not None, "Commands should pass in command_only mode"


@pytest.mark.asyncio
@patch.object(UnknownUserHandler, 'handle')
async def test_pairing_system_integration(mock_unknown_handler):
    """Test that pairing system is properly integrated."""
    
    # Mock the UnknownUserHandler to simulate pairing rejection
    mock_unknown_handler.return_value = False  # User not approved
    
    # Bot with explicit allowlist that does not include unknown user
    bot = create_test_bot(allowed_users=["42"])
    
    # Message from unknown user
    unknown_update = create_mock_telegram_update(user_id="12345", text="hello")
    unknown_message = await process_inbound_telegram_message(unknown_update, bot)
    
    # Should be blocked by pairing system
    assert unknown_message is None, "Unknown user should be blocked by pairing system"
    
    # Verify UnknownUserHandler.handle was called
    mock_unknown_handler.assert_called_once()


@pytest.mark.asyncio
async def test_empty_allowlists_respect_unknown_user_policy():
    """Empty allowlists must still honour unknown_user_policy (default deny)."""
    bot = create_test_bot(
        allowed_users=[],
        allowed_channels=[],
        unknown_user_policy="deny",
    )

    update = create_mock_telegram_update(
        user_id="99999", chat_id="-999999999", text="hello", chat_type="private"
    )
    message = await process_inbound_telegram_message(update, bot)
    assert message is None, "Default deny policy should block unknown users"


@pytest.mark.asyncio
async def test_empty_allowlists_allow_when_policy_is_allow():
    """Explicit allow policy should permit unknown users without an allowlist."""
    config = BotConfig(
        token="test_token",
        allowed_users=[],
        allowed_channels=[],
        unknown_user_policy="allow",
    )
    bot = TelegramBot(token="test_token", config=config)
    bot._bot_user = BotUser(
        user_id="123456789",
        username="test_bot",
        display_name="Test Bot",
        is_bot=True,
    )
    bot.fire_message_received = MagicMock(return_value={"drop": False, "content": ""})
    bot._started_at = 1234567890.0
    bot._agent = MagicMock()
    bot._command_handlers = {}
    bot._session = MagicMock()

    update = create_mock_telegram_update(
        user_id="99999", chat_id="-999999999", text="hello", chat_type="private"
    )
    message = await process_inbound_telegram_message(update, bot)
    assert message is not None, "Allow policy should permit unknown users"


@pytest.mark.asyncio
async def test_audio_message_transcription():
    """Test that audio messages are properly transcribed in the security pipeline."""
    
    bot = create_test_bot(unknown_user_policy="allow")
    
    # Mock the transcribe_audio method
    bot._transcribe_audio = AsyncMock(return_value="[Voice message]: transcribed text")
    
    # Create update with voice message
    update = create_mock_telegram_update(text=None, chat_type="private")
    update.message.text = None
    update.message.voice = MagicMock()  # Simulate voice message
    
    message = await process_inbound_telegram_message(update, bot)
    
    assert message is not None, "Voice message should be processed"
    assert message.content == "[Voice message]: transcribed text"
    bot._transcribe_audio.assert_called_once()


@pytest.mark.asyncio
async def test_voice_message_not_dropped_when_transcription_unavailable():
    """Issue #2721: a voice note must reach the agent even when STT is off.

    When ``_transcribe_audio`` returns ``None`` (STT disabled or failure), the
    pipeline should fall back to a visible placeholder rather than silently
    dropping the message.
    """
    from praisonai_bot.bots._stt import DEFAULT_VOICE_PLACEHOLDER

    bot = create_test_bot(unknown_user_policy="allow")

    # Simulate STT disabled / transcription failure.
    bot._transcribe_audio = AsyncMock(return_value=None)

    update = create_mock_telegram_update(text=None, chat_type="private")
    update.message.text = None
    update.message.voice = MagicMock()

    message = await process_inbound_telegram_message(update, bot)

    assert message is not None, "Voice message must not be silently dropped"
    assert message.content == DEFAULT_VOICE_PLACEHOLDER
    bot._transcribe_audio.assert_called_once()


def test_security_pipeline_exists():
    """Basic smoke test to ensure the security pipeline function exists and is importable."""
    from praisonai_bot.bots.telegram import process_inbound_telegram_message
    assert callable(process_inbound_telegram_message), "Security pipeline function should be callable"


@pytest.mark.asyncio
@patch.object(UnknownUserHandler, 'handle')
async def test_command_handlers_respect_user_allowlist(mock_unknown_handler):
    """Built-in commands must pass the same security pipeline as text messages."""
    mock_unknown_handler.return_value = False

    bot = create_test_bot(allowed_users=["42"])
    
    # Mock the reply_text method to track if command handlers were called
    reply_mock = AsyncMock()
    
    # Test that disallowed users are blocked by command handlers
    for command in ("help", "status", "new"):
        update = create_mock_telegram_update(
            user_id="99",
            text=f"/{command}",
            chat_type="private",
        )
        update.message.reply_text = reply_mock
        reply_mock.reset_mock()
        
        # Get the registered handler for this command from the bot's handlers
        # We need to simulate how the telegram bot framework would call the handler
        if command == "help":
            from praisonai_bot.bots.telegram import TelegramBot
            # Create a handler like the bot does
            async def test_handle_help(update, context):
                if not update.message:
                    return
                if not await process_inbound_telegram_message(update, bot):
                    return
                await update.message.reply_text(bot._format_help())
            await test_handle_help(update, None)
        elif command == "status":
            async def test_handle_status(update, context):
                if not update.message:
                    return
                if not await process_inbound_telegram_message(update, bot):
                    return
                await update.message.reply_text(bot._format_status())
            await test_handle_status(update, None)
        elif command == "new":
            async def test_handle_new(update, context):
                if not update.message:
                    return
                message = await process_inbound_telegram_message(update, bot)
                if not message:
                    return
                user_id = message.sender.user_id if message.sender else "unknown"
                bot._session.reset(user_id)
                await update.message.reply_text("Session reset. Starting fresh conversation.")
            # Mock session reset
            bot._session = MagicMock()
            bot._session.reset = MagicMock()
            await test_handle_new(update, None)
        
        # Assert the command handler did not reply (because security blocked it)
        reply_mock.assert_not_called(), f"/{command} from disallowed user should not reply"

    # Test that allowed users can use commands
    allowed_update = create_mock_telegram_update(
        user_id="42",
        text="/help",
        chat_type="private",
    )
    allowed_update.message.reply_text = reply_mock
    reply_mock.reset_mock()
    
    async def test_handle_help_allowed(update, context):
        if not update.message:
            return
        if not await process_inbound_telegram_message(update, bot):
            return
        await update.message.reply_text(bot._format_help())
    
    await test_handle_help_allowed(allowed_update, None)
    reply_mock.assert_called_once(), "Commands from allowed users should reply"


@pytest.mark.asyncio
async def test_shared_pipeline_consistency():
    """Test that the shared pipeline provides consistent results."""
    
    # Create identical bot configs
    bot1 = create_test_bot(allowed_users=["42"], group_policy="mention_only", unknown_user_policy="allow")
    bot2 = create_test_bot(allowed_users=["42"], group_policy="mention_only", unknown_user_policy="allow")
    
    # Same message update
    update = create_mock_telegram_update(user_id="42", text="@test_bot hello")
    
    # Both should produce identical results
    message1 = await process_inbound_telegram_message(update, bot1)
    message2 = await process_inbound_telegram_message(update, bot2)
    
    assert message1 is not None and message2 is not None
    assert message1.content == message2.content
    assert message1.sender.user_id == message2.sender.user_id