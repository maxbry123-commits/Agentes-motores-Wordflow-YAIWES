"""
BotOS — multi-platform bot orchestrator.

Manages multiple Bot instances across different messaging platforms
with a single unified lifecycle.

Hierarchy::

    BotOS  (multi-platform orchestrator)  ← this class
    └── Bot  (single platform)
        └── Agent / AgentTeam / AgentFlow  (AI brain)

Usage::

    from praisonai_bot.bots import BotOS, Bot
    from praisonaiagents import Agent

    agent = Agent(name="assistant", instructions="Be helpful")

    # Approach 1: Explicit bots
    botos = BotOS(bots=[
        Bot("telegram", agent=agent),
        Bot("discord", agent=agent),
    ])
    await botos.start()

    # Approach 2: Shortcut — same agent, multiple platforms
    botos = BotOS(agent=agent, platforms=["telegram", "discord"])
    await botos.start()

    # Approach 3: Build incrementally
    botos = BotOS()
    botos.add_bot(Bot("telegram", agent=agent))
    botos.add_bot(Bot("slack", agent=agent, app_token="xapp-..."))
    await botos.start()
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from praisonaiagents import Agent

from praisonaiagents.bots.protocols import HealthReason, HealthResult, evaluate_channel_health
from ..gateway.supervisor import ChannelSupervisor
from ..gateway.health_monitor import ChannelHealthMonitor, HealthMonitorConfig
from .bot import Bot
from .delivery import DeliveryRouter, SessionSource

logger = logging.getLogger(__name__)


def _coerce_drain_timeout(value: Optional[Any]) -> Optional[float]:
    """Coerce a drain-timeout config value to a finite float (or None).

    YAML/env-substituted values (#2375) can reach the shutdown path as
    quoted strings (e.g. ``"30"``); coercing here keeps later numeric
    comparisons (``> 0``) safe. ``None`` passes through (disabled).
    """
    if value is None:
        return None
    try:
        timeout = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"drain_timeout must be a number, got {value!r}")
    import math

    if not math.isfinite(timeout) or timeout < 0:
        raise ValueError(f"drain_timeout must be a finite value >= 0, got {value!r}")
    return timeout


class BotOS:
    """Multi-platform bot orchestrator.

    Starts and stops all registered Bot instances concurrently.
    Satisfies ``BotOSProtocol`` from the core SDK.

    Args:
        bots: Pre-built Bot instances.
        agent: Shared agent for auto-created bots (used with *platforms*).
        platforms: List of platform names; creates a Bot per platform
            using the shared *agent*.
        config: Optional BotOSConfig.
        reliability: Named reliability posture (Issue #2531) composing the
            existing lifecycle knobs in one switch:

            * ``"production"`` — graceful drain (15s) + inbound admission with a
              CPU-scaled ceiling and a bounded fair wait queue.
            * ``"default"`` / ``None`` — a sane small drain window (5s) so a
              restart doesn't cut in-flight turns; no admission ceiling.
            * ``"off"`` — today's immediate-teardown, no-backpressure behaviour.

            Explicit ``drain_timeout`` / ``max_concurrent_runs`` /
            ``admission_policy`` always override the preset. Durable inbound
            journaling stays on by default at the session level regardless.
    """

    def __init__(
        self,
        bots: Optional[List[Bot]] = None,
        agent: Optional[Any] = None,
        platforms: Optional[List[str]] = None,
        config: Optional[Any] = None,
        identity_resolver: Optional[Any] = None,
        health_monitor: Optional[HealthMonitorConfig] = None,
        enable_supervision: bool = True,
        idle_policy: Optional[Any] = None,
        drain_timeout: Optional[float] = None,
        max_concurrent_runs: int = 0,
        queue_depth: int = 0,
        overflow_policy: str = "reject",
        admission_policy: Optional[Any] = None,
        max_rss_mb: float = 0.0,
        reliability: Optional[str] = None,
    ):
        self._bots: Dict[str, Bot] = {}
        self._is_running = False
        self._config = config

        # Issue #2531: a single, discoverable reliability posture that composes
        # the already-existing lifecycle knobs (graceful drain + inbound
        # admission) so the happy path is production-grade in one switch. The
        # preset only fills in fields the caller left unset — explicit
        # ``drain_timeout=`` / ``max_concurrent_runs=`` / ``admission_policy=``
        # always win. ``reliability="off"`` preserves today's immediate-
        # teardown, no-backpressure behaviour.
        from ._reliability import resolve_reliability

        self._reliability = reliability
        _resolved = resolve_reliability(
            reliability,
            drain_timeout=drain_timeout,
            max_concurrent_runs=max_concurrent_runs,
            queue_depth=queue_depth,
            overflow_policy=overflow_policy,
            admission_policy=admission_policy,
        )
        drain_timeout = _resolved.drain_timeout
        max_concurrent_runs = _resolved.max_concurrent_runs
        queue_depth = _resolved.queue_depth
        overflow_policy = _resolved.overflow_policy
        # Per-conversation outbound ordering resolved from the reliability
        # preset (``strict`` under ``production``). Exposed so adapters that set
        # up durable delivery can forward it to their ``OutboundQueue`` and the
        # production posture actually enforces per-lane FIFO instead of silently
        # staying best-effort.
        self._outbound_ordering: str = _resolved.outbound_ordering

        # Issue #2375: graceful drain on shutdown. A sane default window is now
        # applied via the reliability preset (Issue #2531) so a restart does not
        # cut in-flight turns; ``reliability="off"`` restores the immediate-
        # cancel behaviour.
        self._drain_timeout: Optional[float] = _coerce_drain_timeout(drain_timeout)
        # Whether ingress should keep dispatching new turns. Flipped to
        # False at the start of a drain so current turns finish but no
        # new ones begin.
        self._accepting: bool = True
        self._is_draining: bool = False
        # Issue #2332: opt-in idle-dormancy / scale-to-zero. Default off —
        # when None the gateway behaves exactly as before (always-on).
        self._idle_policy = idle_policy
        self._last_inbound_ts: float = time.time()
        self._running_turns: int = 0
        self._is_dormant: bool = False
        # Issue #2454: opt-in gateway-wide inbound admission control. Default
        # off — when ``max_concurrent_runs <= 0`` and no ``admission_policy`` is
        # given, the gate is None and every inbound turn dispatches immediately
        # (legacy behaviour). When configured, a single shared ``AdmissionGate``
        # bounds the aggregate number of concurrent agent runs across all
        # users/channels, with a bounded fair wait queue and a declared
        # overflow policy, and is wired into every bot's session manager so
        # enforcement happens in the run-dispatch path itself.
        from ._admission import build_admission_gate, build_memory_pressure_policy

        # Issue #3445: opt-in memory-aware admission. When a hard RSS ceiling is
        # configured the gate queues under soft pressure (90% of the ceiling by
        # default) and sheds under hard pressure before the OOM killer fires.
        # Default off (``max_rss_mb <= 0``) preserves legacy behaviour.
        self._admission_gate = build_admission_gate(
            max_concurrent_runs=max_concurrent_runs,
            queue_depth=queue_depth,
            overflow_policy=overflow_policy,
            policy=admission_policy,
            resource_policy=build_memory_pressure_policy(max_rss_mb),
        )
        self._on_quiesce = None  # optional callable(): host-suspend driver
        # W1: shared identity resolver applied to every managed bot —
        # gives cross-platform unified-user sessions out of the box.
        self._identity_resolver = identity_resolver
        # Issue #3232: a single per-turn ``LockMap`` shared across every managed
        # bot's session manager. Because each ``BotSessionManager`` keys its lock
        # on the *resolved* session id (unified user id under an identity
        # resolver), sharing one map means two adapters that resolve to the same
        # unified session hold the *same* lock and their turns run serially — no
        # interleaved read-modify-write on one persisted transcript. Wired only
        # when a resolver is configured (the sole case where distinct adapters
        # unify to one session), so single-adapter behaviour is untouched.
        from .._lockmap import LockMap

        self._turn_lock_map = LockMap()
        self._tasks: List[asyncio.Task] = []
        
        # Initialize delivery router for proactive outbound messaging
        self._delivery_router = DeliveryRouter(self)
        
        self._enable_supervision = enable_supervision
        
        # Initialize supervisor and health monitor if enabled
        if self._enable_supervision:
            self._supervisor = ChannelSupervisor(health_config=health_monitor)
            self._health_monitor_config = health_monitor or HealthMonitorConfig()
        else:
            self._supervisor = None
            self._health_monitor_config = None
        
        self._start_times: Dict[str, float] = {}  # Track bot start times

        # Register explicit bots
        if bots:
            for bot in bots:
                self.add_bot(bot)

        # Shortcut: agent + platforms → auto-create Bot per platform
        if agent and platforms:
            for plat in platforms:
                if plat not in self._bots:
                    self.add_bot(
                        Bot(
                            plat,
                            agent=agent,
                            identity_resolver=self._identity_resolver,
                        )
                    )

    # ── Properties ──────────────────────────────────────────────────

    @property
    def is_running(self) -> bool:
        return self._is_running

    # ── Bot management ──────────────────────────────────────────────

    def add_bot(self, bot: Bot) -> None:
        """Register a Bot for orchestration.

        Args:
            bot: A Bot instance.
        """
        # W1: propagate the BotOS-level resolver to bots that don't
        # already have one, so cross-platform unification works whether
        # the user uses the shortcut API or constructs Bots manually.
        if (
            self._identity_resolver is not None
            and getattr(bot, "_identity_resolver", None) is None
        ):
            bot._identity_resolver = self._identity_resolver
        self._bots[bot.platform] = bot

    def list_bots(self) -> List[str]:
        """List platform names of all registered bots."""
        return list(self._bots.keys())

    def get_bot(self, platform: str) -> Optional[Bot]:
        """Get a registered bot by platform name."""
        return self._bots.get(platform.lower())

    def _get_hook_runner(self) -> Any:
        """Resolve a HookRunner from the first registered bot's agent.

        Returns None when no bot/agent exposes a hook runner — callers
        treat None as a no-op so there is zero overhead without hooks.
        """
        from ._protocol_mixin import _resolve_runner_from_agent

        for bot in self._bots.values():
            agent = bot.get_agent() if hasattr(bot, "get_agent") else getattr(bot, "_agent", None)
            runner = _resolve_runner_from_agent(agent)
            if runner is not None:
                return runner
        return None
    
    @property
    def delivery_router(self) -> DeliveryRouter:
        """Get the delivery router for proactive messaging."""
        return self._delivery_router

    # ── Lifecycle ───────────────────────────────────────────────────

    async def start(self) -> None:
        """Start all registered bots concurrently.

        Each bot runs in its own asyncio task. BotOS waits for all
        bots (they block until stopped).
        """
        if self._is_running:
            logger.warning("BotOS already running")
            return

        if not self._bots:
            logger.warning("BotOS: no bots registered, nothing to start")
            return

        self._is_running = True
        logger.info(f"BotOS starting {len(self._bots)} bot(s): {', '.join(self._bots.keys())}")

        # Fire GATEWAY_START lifecycle hook (no-op when no hooks registered)
        try:
            from ._protocol_mixin import fire_gateway_start
            fire_gateway_start(self._get_hook_runner(), list(self._bots.keys()))
        except Exception as e:
            logger.debug(f"GATEWAY_START emit error (non-fatal): {e}")

        # Configure delivery router from bot configurations
        self._configure_delivery_from_bots()

        # Issue #2372: give every bot's session manager a handle to the
        # delivery router so each agent turn can register a concrete
        # ``BotOutboundMessenger``, making the built-in core ``send_message``
        # tool actually deliver instead of returning "no gateway available".
        self._wire_outbound_messenger()

        # Issue #2454: share the single gateway-wide admission gate with every
        # bot's session manager so the concurrency ceiling / fair queue /
        # overflow policy is enforced in the inbound run-dispatch path. No-op
        # when admission control is not configured.
        self._wire_admission_gate()

        # Issue #3232: share one per-turn ``LockMap`` across every bot's session
        # manager so turns are serialised on the *resolved* session id across
        # adapters. Closes the cross-platform concurrent-turn hole exposed by the
        # identity resolver. No-op without a resolver (single-adapter behaviour).
        self._wire_turn_locks()

        # Start health monitoring if enabled
        if self._enable_supervision and self._supervisor:
            await self._supervisor.start_health_monitoring()
            logger.info("BotOS: health monitoring enabled")

        self._tasks = []
        for platform, bot in self._bots.items():
            task = asyncio.create_task(
                self._run_bot(platform, bot),
                name=f"botos-{platform}",
            )
            self._tasks.append(task)

        # Start schedule loop alongside bots so cron jobs execute
        schedule_task = asyncio.create_task(
            self._run_schedule_loop(),
            name="botos-scheduler",
        )
        self._tasks.append(schedule_task)

        # Issue #2332: opt-in idle-dormancy loop. Only scheduled when an
        # idle_policy is configured, so always-on gateways pay zero cost.
        if self._idle_policy is not None:
            idle_task = asyncio.create_task(
                self._run_idle_loop(),
                name="botos-idle",
            )
            self._tasks.append(idle_task)

        try:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        except asyncio.CancelledError:
            pass
        finally:
            # Stop health monitoring
            if self._enable_supervision and self._supervisor:
                await self._supervisor.stop_health_monitoring()
            self._is_running = False

    async def _run_bot(self, platform: str, bot: Bot) -> None:
        """Run a single bot with error isolation and optional supervision."""
        if self._enable_supervision and self._supervisor:
            # Run with supervision and auto-recovery
            async def start_bot(name: str, bot_instance: Bot) -> None:
                self._start_times[name] = time.time()
                await bot_instance.start()
            
            await self._supervisor.run(platform, bot, start_bot)
        else:
            # Original behavior without supervision
            try:
                logger.info(f"BotOS: starting {platform}")
                self._start_times[platform] = time.time()
                await bot.start()
            except Exception as e:
                logger.error(f"BotOS: {platform} failed: {e}")

    # ── Idle-dormancy / scale-to-zero (Issue #2332) ─────────────────

    def notify_inbound(self) -> None:
        """Record an inbound message for idle tracking.

        Resets the process-wide idle timer. Safe to call always — it is a
        cheap timestamp write whether or not an idle policy is configured.

        Note: the idle loop also passively probes each bot's session
        manager (``_active_runs``/``_last_active``) via
        :meth:`_probe_activity`, so live traffic is reflected even without
        calling this — these hooks are an optional explicit override for
        adapters that don't expose a session manager. When no
        ``idle_policy`` is configured they are no-op-cheap and the gateway
        stays always-on as before.
        """
        self._last_inbound_ts = time.time()

    def turn_started(self) -> None:
        """Mark an agent turn as in-flight (blocks dormancy)."""
        self._running_turns += 1
        self._last_inbound_ts = time.time()

    def turn_finished(self) -> None:
        """Mark an agent turn as complete."""
        if self._running_turns > 0:
            self._running_turns -= 1

    def _probe_activity(self) -> tuple[int, float]:
        """Passively read live liveness facts from bot session managers.

        Closes the "stale counters" gap (#2332 reviewer P1): rather than
        relying solely on explicit :meth:`notify_inbound`/:meth:`turn_started`
        calls (which not every adapter wires), this reads the session
        manager state that *every* adapter already maintains:

        * ``_active_runs`` — in-flight agent turns per user, populated and
          popped around each agent run.
        * ``_last_active`` — per-user last-inbound timestamp (monotonic),
          stamped on every inbound message.

        Returns ``(running_turns, last_inbound_ts)`` where the timestamp is
        wall-clock (``time.time``) to match the policy contract. Explicitly
        recorded activity (``self._running_turns`` / ``self._last_inbound_ts``)
        is merged in, so adapters that do call the hooks still win and any
        adapter that exposes neither degrades to the construction-time value.
        """
        running = self._running_turns
        last_ts = self._last_inbound_ts
        now_wall = time.time()
        now_mono = time.monotonic()
        for bot in self._bots.values():
            session = getattr(bot, "_session", None)
            if session is None:
                adapter = getattr(bot, "_adapter", None)
                session = getattr(adapter, "_session", None)
            if session is None:
                continue
            active_runs = getattr(session, "_active_runs", None)
            if isinstance(active_runs, dict):
                running += len(active_runs)
            last_active = getattr(session, "_last_active", None)
            if isinstance(last_active, dict) and last_active:
                # Stored as monotonic; convert the most-recent to wall-clock.
                newest_mono = max(last_active.values())
                wall = now_wall - max(0.0, now_mono - newest_mono)
                if wall > last_ts:
                    last_ts = wall
        return running, last_ts

    def _has_background_work(self) -> bool:
        """Whether live background work should block dormancy.

        Conservative: any *enabled* scheduled job keeps the gateway awake.
        Checking only currently-due jobs is unsafe — a job scheduled to
        fire after the idle timeout would let the gateway quiesce first,
        and the schedule loop would later deliver its output through
        stopped transports, losing the result. While transports cannot be
        revived in-process, an enabled schedule means the gateway must
        stay resident to honour it (#2332 reviewer feedback).
        """
        try:
            from praisonaiagents.tools.schedule_tools import _get_store
            from praisonaiagents.scheduler import ScheduleRunner
        except ImportError:
            return False
        try:
            runner = ScheduleRunner(_get_store())
            if runner.get_due_jobs():
                return True
            store = _get_store()
            jobs = store.list() if hasattr(store, "list") else []
            return any(getattr(job, "enabled", False) for job in jobs)
        except Exception:
            return False

    async def wake(self) -> None:
        """Resume the gateway from dormancy and reconnect transports.

        Idempotent: a no-op when not dormant. Reuses ``HookAction.WAKE``
        semantics — an inbound poke revives the process and reconnects
        the messaging transports with session state preserved.
        """
        if not self._is_dormant:
            return
        logger.info("BotOS: waking from dormancy")
        self._is_dormant = False
        self.notify_inbound()
        # Prune finished task handles so repeated wake cycles don't
        # accumulate stale entries.
        self._tasks = [t for t in self._tasks if not t.done()]
        for platform, bot in self._bots.items():
            try:
                start = getattr(bot, "start", None)
                if start is not None:
                    task = asyncio.create_task(
                        self._run_bot(platform, bot),
                        name=f"botos-{platform}",
                    )
                    # Supervise: the main start() gather already returned the
                    # handles it had at launch, so wake-restarted tasks run
                    # outside it. Attach a callback to surface their failures.
                    task.add_done_callback(self._on_wake_task_done)
                    self._tasks.append(task)
            except Exception as e:
                logger.warning(f"BotOS: error waking {platform}: {e}")

    @staticmethod
    def _on_wake_task_done(task: "asyncio.Task") -> None:
        """Surface exceptions from wake-restarted transport tasks."""
        if task.cancelled():
            return
        exc = task.exception()
        if exc is not None:
            logger.error(f"BotOS: wake task {task.get_name()} failed: {exc}")

    async def _quiesce(self, reason: str) -> None:
        """Stand transports down and signal the compute host to suspend."""
        if self._is_dormant:
            return
        logger.info(f"BotOS: quiescing (scale-to-zero): {reason}")
        self._is_dormant = True
        for platform, bot in self._bots.items():
            try:
                stop = getattr(bot, "stop", None)
                if stop is not None:
                    await bot.stop()
            except Exception as e:
                logger.warning(f"BotOS: error quiescing {platform}: {e}")
        # Drive the optional compute-host suspend (Fly/Modal/Daytona) only
        # after transports are cleanly down, so no inbound is dropped.
        if self._on_quiesce is not None:
            try:
                result = self._on_quiesce()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.warning(f"BotOS: on_quiesce driver error: {e}")

    async def _run_idle_loop(self) -> None:
        """Evaluate the idle policy and quiesce when fully idle.

        Only scheduled when an ``idle_policy`` is configured. The policy
        decision is a pure, core-side predicate; this loop supplies live
        facts and owns the side effects.
        """
        policy = self._idle_policy
        wake_url = getattr(policy, "wake_url", None)
        # Arm gating: never quiesce into a state we cannot resume from.
        if hasattr(policy, "should_arm"):
            if not policy.should_arm(
                transports_quiescable=True,
                wake_registered=wake_url is not None,
            ):
                logger.info(
                    "BotOS: idle policy not armed (no wake path); staying always-on"
                )
                return
        logger.info("BotOS: idle-dormancy armed (scale-to-zero)")
        while self._is_running:
            await asyncio.sleep(30)
            if self._is_dormant:
                continue
            try:
                # Probe live liveness from session managers so the decision
                # reflects real traffic even when adapters don't call the
                # explicit notify_inbound/turn_* hooks (#2332 reviewer P1).
                running_turns, last_inbound_ts = self._probe_activity()
                decision = policy.is_idle(
                    running_turns=running_turns,
                    last_inbound_ts=last_inbound_ts,
                    has_background_work=self._has_background_work(),
                    now=time.time(),
                )
            except Exception as e:
                logger.debug(f"BotOS: idle evaluation error: {e}")
                continue
            if getattr(decision, "idle", False):
                await self._quiesce(getattr(decision, "reason", ""))

    async def _run_schedule_loop(self) -> None:
        """Poll for due scheduled jobs and execute them.

        Runs alongside bot tasks so cron/interval schedules fire even
        without the UI. On trigger, the agent processes the message
        and results are delivered back to the originating platform.

        When the UI scheduler is already running (PraisonAIUI started),
        this loop defers to it to avoid double-firing jobs.

        Cross-process at-most-once: when the backing store supports an atomic
        claim (``claim_due``), each due job is reserved under a cross-process
        lock via ``runner.claim_due_jobs`` before running, so it fires **at most
        once** across all tickers/processes/hosts — matching the WebSocket
        gateway's ``ScheduledAgentExecutor``. The lease is released via
        ``complete_run`` after each run so it does not linger until expiry, and
        a claim not completed (crashed run) expires so the job is retried.
        Stores without atomic support fall back to the non-atomic
        ``get_due_jobs`` path (single-process behaviour is unchanged).
        """
        try:
            from praisonaiagents.tools.schedule_tools import _get_store
            from praisonaiagents.scheduler import ScheduleRunner
        except ImportError:
            logger.debug("BotOS: schedule module not available, skipping scheduler")
            return

        import os
        import socket
        import uuid

        store = _get_store()
        runner = ScheduleRunner(store)
        # Stable per-process identity for atomic claims (host:pid:uuid) so a due
        # job fires at most once across processes/hosts when the store supports
        # ``claim_due``.
        owner_id = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:8]}"
        atomic_claim = runner.supports_atomic_claim()
        logger.info(
            "BotOS: schedule loop started (30s tick, atomic_claim=%s)",
            atomic_claim,
        )

        while True:
            try:
                # Skip if the UI scheduler is already running (avoids double-fire)
                ui_running = False
                try:
                    from praisonaiui.features.schedules import _scheduler_running
                    ui_running = _scheduler_running
                except ImportError:
                    pass  # UI not installed — we're the only scheduler
                if ui_running:
                    await asyncio.sleep(30)
                    continue

                # Reserve due jobs atomically when supported; only jobs this
                # process won are returned (competitors get an empty list and
                # skip silently). Falls back to non-atomic get_due_jobs.
                due = runner.claim_due_jobs(owner_id, lease_seconds=300)
                for job in due:
                    import time as _time
                    _start = _time.time()
                    _status = "succeeded"
                    _result = None
                    _error = None
                    _delivered = False
                    try:
                        _result, _delivered = await self._execute_schedule_job(job)
                    except Exception as e:
                        _status = "failed"
                        _error = str(e)
                        logger.warning(f"BotOS: schedule job {job.name} failed: {e}")
                    finally:
                        # Release the lease so it does not linger until expiry.
                        if atomic_claim:
                            try:
                                runner.complete_run(job.id, owner_id)
                                # complete_run clears the lease on disk; also
                                # clear it in-memory so the mark_run ->
                                # store.update(job) below does not re-write the
                                # stale lease and block crash-recovery for
                                # sub-lease-interval jobs.
                                job._lease_until = 0.0
                                job._lease_owner = None
                            except Exception as e:
                                logger.warning(
                                    f"BotOS: failed to release lease for job "
                                    f"{job.name}: {e}"
                                )
                    _duration = _time.time() - _start
                    runner.mark_run(
                        job,
                        status=_status,
                        result=_result,
                        error=_error,
                        duration=_duration,
                        delivered=_delivered,
                    )
            except Exception as e:
                logger.debug(f"BotOS: schedule tick error: {e}")
            await asyncio.sleep(30)

    async def _execute_schedule_job(self, job) -> tuple:
        """Execute a single due schedule job.

        Returns:
            Tuple of (result_str, delivered_bool).
        """
        if not job.message:
            return (None, False)

        # Find the agent to execute with
        agent = None
        if job.agent_id:
            # Look for a bot whose agent matches
            for bot in self._bots.values():
                a = bot.get_agent() if hasattr(bot, 'get_agent') else getattr(bot, '_agent', None)
                if a and getattr(a, 'name', None) == job.agent_id:
                    agent = a
                    break
        if agent is None:
            # Use the first available agent
            for bot in self._bots.values():
                a = bot.get_agent() if hasattr(bot, 'get_agent') else getattr(bot, '_agent', None)
                if a:
                    agent = a
                    break
        if agent is None:
            logger.debug(f"BotOS: no agent for schedule job {job.name}")
            return (None, False)

        # Enforce the job's pinned-model snapshot before the turn: an unattended
        # job must never silently run on a different/pricier model. Delegate to
        # the canonical drift check so this path matches the gateway executor
        # (issue #4079, Defect 3). No-op for unpinned/unsnapshotted jobs.
        _restore_pin = self._enforce_pinned_model(job, agent)

        # Fire SCHEDULE_TRIGGER lifecycle hook (no-op when no hooks registered)
        try:
            from ._protocol_mixin import fire_schedule_trigger, _resolve_runner_from_agent
            fire_schedule_trigger(
                _resolve_runner_from_agent(agent),
                job_name=getattr(job, "name", ""),
                job_id=str(getattr(job, "id", "") or getattr(job, "agent_id", "") or ""),
                message=job.message,
            )
        except Exception as e:
            logger.debug(f"SCHEDULE_TRIGGER emit error (non-fatal): {e}")

        # Run the agent (restore any run-scoped model pin afterwards so it never
        # leaks into another, attended turn on the same shared agent instance).
        try:
            result = await asyncio.to_thread(agent.chat, job.message)
        finally:
            if _restore_pin is not None:
                _restore_pin()
        result_str = str(result) if result else None

        # Deliver using the new delivery router
        delivered = False
        delivery = job.delivery
        if delivery:
            # Build origin context if available
            origin = None
            if delivery.channel and delivery.channel_id:
                origin = SessionSource(
                    platform=delivery.channel,
                    channel_id=delivery.channel_id
                )
            
            # Determine target - use explicit target if set, otherwise "origin"
            target = getattr(delivery, 'target', None)
            if not target and origin:
                target = "origin"
            
            if target and result_str:
                delivered = await self._delivery_router.deliver(
                    target=target,
                    text=result_str,
                    origin=origin
                )

        logger.info(f"BotOS: executed schedule job '{job.name}'")
        return (result_str, delivered)

    @staticmethod
    def _enforce_pinned_model(job: Any, agent: Any) -> Optional[Any]:
        """Fail closed when a pinned job has drifted from its model snapshot.

        Delegates to the gateway executor's canonical ``_check_model_drift`` so
        the BotOS path enforces the exact same rule (issue #4079, Defect 3):
        raises ``RuntimeError`` with the drift reason on mismatch (recorded as a
        failed run by the surrounding tick), and otherwise returns a run-scoped
        restore callable (or ``None`` when nothing was pinned). A no-op for
        unpinned/unsnapshotted jobs.
        """
        try:
            from ..scheduler.executor import ScheduledAgentExecutor
        except ImportError as e:  # pragma: no cover - executor always co-located
            logger.debug(f"BotOS: model-pin check unavailable: {e}")
            return None
        checker = ScheduledAgentExecutor(
            runner=None, agent_resolver=lambda _id: None
        )
        drift_reason, restore = checker._check_model_drift(job, agent)
        if drift_reason:
            raise RuntimeError(drift_reason)
        return restore

    @staticmethod
    def _summarize_job_result(result: Any) -> Optional[str]:
        """Extract a human-readable summary from a background job's result.

        Background subagents return a dict shaped like
        ``{"success": bool, "output": ..., "error": ...}`` (see
        ``subagent_tool._run_subagent``). Prefer ``output`` on success and
        ``error`` on failure; fall back to ``str(result)`` for anything else.
        Returns ``None`` when there is nothing meaningful to deliver.
        """
        if result is None:
            return None
        if isinstance(result, dict):
            if result.get("success") and result.get("output") is not None:
                text = result["output"]
            elif result.get("error"):
                text = f"Task failed: {result['error']}"
            else:
                text = result.get("output") or result.get("error")
            return str(text) if text is not None else None
        text = str(result)
        return text or None

    def on_background_job_complete(self, job_info: Any) -> bool:
        """Route a completed background job's result back to its origin chat.

        Registered as the ``on_complete`` callback on ``spawn_subagent(
        ..., background=True, deliver=...)`` so a finished background job
        delivers itself into the originating conversation with no active
        turn — the defining capability of a persistent gateway. Reuses the
        SAME ``DeliveryRouter`` the scheduler uses. Fires the ``JOB_COMPLETED``
        hook for observability. Best-effort: any failure is logged, never
        raised (it runs on the background worker thread).

        Args:
            job_info: The terminal ``JobInfo`` carrying ``origin`` context
                captured at spawn time (``deliver``/``platform``/``chat_id``/
                ``thread_id``/``session_id``).

        Returns:
            True if the result was delivered, False otherwise.
        """
        try:
            origin = dict(getattr(job_info, "origin", {}) or {})
            job_id = str(getattr(job_info, "job_id", "") or "")
            status = getattr(getattr(job_info, "status", ""), "value", None) or str(
                getattr(job_info, "status", "")
            )
            error = getattr(job_info, "error", None)
            result = getattr(job_info, "result", None)
            deliver = origin.get("deliver", "")

            # Fire the observability hook regardless of whether we can deliver.
            try:
                from ._protocol_mixin import fire_job_completed
                fire_job_completed(
                    self._get_hook_runner(),
                    job_id=job_id,
                    status=status,
                    result=result,
                    error=error,
                    deliver=deliver,
                    platform=origin.get("platform", ""),
                    chat_id=origin.get("chat_id", ""),
                    thread_id=origin.get("thread_id", ""),
                    session_id=origin.get("session_id", ""),
                )
            except Exception as e:  # pragma: no cover — defensive
                logger.debug(f"JOB_COMPLETED emit error (non-fatal): {e}")

            if not deliver:
                return False

            # Build the delivery text: success summary or failure notice.
            if error:
                text = f"Background task failed: {error}"
            else:
                text = self._summarize_job_result(result)
            if not text:
                logger.debug(
                    "Background job %s completed with no deliverable text", job_id
                )
                return False

            origin_source = None
            platform = origin.get("platform", "")
            chat_id = origin.get("chat_id", "")
            if platform and chat_id:
                origin_source = SessionSource(
                    platform=platform,
                    channel_id=chat_id,
                    thread_id=origin.get("thread_id") or None,
                )

            delivered = self._run_coroutine_sync(
                self._deliver_job_text(deliver, text, origin_source)
            )
            if delivered:
                logger.info(
                    "Delivered background job %s result to %s", job_id, deliver
                )
            else:
                logger.warning(
                    "Background job %s ran but delivery to %s failed",
                    job_id, deliver,
                )
            return bool(delivered)
        except Exception as e:  # pragma: no cover — must never crash worker
            logger.warning(f"on_background_job_complete error (non-fatal): {e}")
            return False

    async def _deliver_job_text(
        self, target: str, text: str, origin: Optional[Any]
    ) -> bool:
        """Deliver ``text`` to ``target``, resolving the ``"all"`` broadcast token.

        ``DeliveryRouter`` resolves ``"origin"``, ``"platform"``, aliases and
        ``"platform:channel"`` but not the documented ``"all"`` fan-out token.
        Mirror the gateway's ``all`` semantics here by fanning out to every
        reachable home channel; anything else routes straight through the
        shared router (the scheduler's path). A send is considered delivered
        if it reaches at least one target.
        """
        if target == "all":
            directory = getattr(self._delivery_router, "directory", None)
            targets = directory.describe_targets() if directory is not None else []
            homes = [t for t in targets if t.get("kind") == "home"]
            if not homes:
                logger.warning("Background job deliver='all' has no home channels")
                return False
            delivered_any = False
            for t in homes:
                try:
                    ok = await self._delivery_router.deliver(
                        target=f"{t['platform']}:{t['channel_id']}",
                        text=text,
                        origin=origin,
                    )
                    delivered_any = delivered_any or bool(ok)
                except Exception as e:  # pragma: no cover — best-effort fan-out
                    logger.warning(
                        "Background job deliver='all' to %s:%s failed: %s",
                        t.get("platform"), t.get("channel_id"), e,
                    )
            return delivered_any
        return await self._delivery_router.deliver(
            target=target, text=text, origin=origin
        )

    @staticmethod
    def _run_coroutine_sync(coro: Any) -> Any:
        """Run an awaitable to completion from a (possibly sync) context.

        The background job runner invokes ``on_complete`` on a plain worker
        thread with no running event loop, while ``DeliveryRouter.deliver`` is
        a coroutine. If a loop is already running on this thread we schedule
        the coroutine thread-safely onto it; otherwise we run it directly.
        """
        if not asyncio.iscoroutine(coro):
            return coro
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None and loop.is_running():
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            return future.result()
        return asyncio.run(coro)

    @staticmethod
    def _find_session_manager(bot: Bot) -> Optional[Any]:
        """Locate a bot's ``BotSessionManager`` across the adapter variants.

        Adapters expose their session manager under different attribute names
        (``_session``, ``_session_mgr``) and sometimes behind an inner
        ``_adapter``. Mirrors the discovery in :meth:`_probe_activity` so the
        outbound-messenger wiring reaches every shipped transport.
        """
        for holder in (bot, getattr(bot, "_adapter", None)):
            if holder is None:
                continue
            for attr in ("_session", "_session_mgr"):
                session = getattr(holder, attr, None)
                if session is not None:
                    return session
        return None

    def _wire_outbound_messenger(self) -> None:
        """Hand the delivery router to every bot's session manager (#2372).

        Lets each agent turn register a concrete ``BotOutboundMessenger`` so
        the built-in core ``send_message`` tool can proactively reach the user.

        Adapters build their session lazily inside ``start()``, so we also stamp
        the router onto the ``Bot`` itself; ``Bot._build_adapter`` then splices
        it into the freshly-built session. Already-built sessions (e.g. an
        adapter constructed directly) are wired in place too. Best-effort: a bot
        exposing neither is skipped, preserving prior behaviour.
        """
        for platform, bot in self._bots.items():
            try:
                # Pre-start: applied when the adapter is lazily built.
                if hasattr(bot, "_delivery_router"):
                    bot._delivery_router = self._delivery_router
                # Post-start / direct adapter: wire any existing session now.
                session = self._find_session_manager(bot)
                if session is not None and hasattr(session, "_delivery_router"):
                    session._delivery_router = self._delivery_router
            except Exception as e:  # pragma: no cover — defensive
                logger.debug(
                    "Failed to wire outbound messenger for %s: %s", platform, e
                )

    def _wire_admission_gate(self) -> None:
        """Hand the shared admission gate to every bot's session manager (#2454).

        Lets each agent turn pass through the single gateway-wide admission gate
        so the aggregate concurrency ceiling, fair wait queue and overflow
        policy are enforced in the inbound run-dispatch path. Mirrors
        :meth:`_wire_outbound_messenger`: pre-start it is stamped onto the
        ``Bot`` (spliced into the lazily-built session by ``Bot._build_adapter``)
        and any already-built session is wired in place. No-op when admission
        control is not configured (``self._admission_gate is None``), preserving
        the legacy immediate-dispatch behaviour.
        """
        if self._admission_gate is None:
            return
        for platform, bot in self._bots.items():
            try:
                # Pre-start: applied when the adapter is lazily built.
                if hasattr(bot, "_admission_gate"):
                    bot._admission_gate = self._admission_gate
                # Post-start / direct adapter: wire any existing session now.
                session = self._find_session_manager(bot)
                if session is not None and hasattr(session, "_admission_gate"):
                    session._admission_gate = self._admission_gate
            except Exception as e:  # pragma: no cover — defensive
                logger.debug(
                    "Failed to wire admission gate for %s: %s", platform, e
                )

    def _wire_turn_locks(self) -> None:
        """Share one per-turn ``LockMap`` across every bot's session (#3232).

        Each ``BotSessionManager`` keys its per-turn lock on the *resolved*
        session id (the unified user id when an identity resolver is
        configured). By default every adapter owns a separate ``LockMap``, so
        two adapters that resolve the same human to one unified session hold two
        distinct locks and their turns run concurrently against one persisted
        transcript. Injecting a single shared map makes those turns serialise on
        the resolved id — regardless of which platform a message arrives on.

        Wired only when an identity resolver is present (BotOS-level or on any
        managed bot): that is the sole case where distinct adapters unify to one
        session, so single-adapter deployments keep their own map and today's
        behaviour is preserved exactly. Mirrors :meth:`_wire_admission_gate`:
        pre-start it is stamped onto the ``Bot`` (spliced into the lazily-built
        session by ``Bot._build_adapter``) and any already-built session is
        wired in place.
        """
        has_resolver = self._identity_resolver is not None or any(
            getattr(bot, "_identity_resolver", None) is not None
            for bot in self._bots.values()
        )
        if not has_resolver:
            return
        for platform, bot in self._bots.items():
            try:
                # Pre-start: applied when the adapter is lazily built.
                if hasattr(bot, "_turn_lock_map"):
                    bot._turn_lock_map = self._turn_lock_map
                # Post-start / direct adapter: wire any existing session now.
                session = self._find_session_manager(bot)
                if session is not None and hasattr(session, "_locks"):
                    session._locks = self._turn_lock_map
            except Exception as e:  # pragma: no cover — defensive
                logger.debug(
                    "Failed to wire turn locks for %s: %s", platform, e
                )

    @property
    def admission_stats(self) -> Optional[Dict[str, Any]]:
        """Live admission counters for health/metrics, or ``None`` when off.

        Surfaces the current in-flight count, queue depth, and cumulative
        admits/rejects/sheds (Issue #2454 observability requirement). Returns
        ``None`` when no admission gate is configured.
        """
        gate = self._admission_gate
        if gate is None:
            return None
        try:
            return gate.stats()
        except Exception:  # pragma: no cover — defensive
            return None

    def _configure_delivery_from_bots(self) -> None:
        """Configure delivery router from bot configurations."""
        for platform, bot in self._bots.items():
            # Check if bot has channel configuration
            # Try _config first (for manually created bots), then _kwargs (from from_config())
            config = getattr(bot, '_config', None)
            kwargs = getattr(bot, '_kwargs', {})
            
            # Extract home_channel and aliases from config or kwargs
            home_channel = None
            aliases = {}
            
            if config:
                home_channel = getattr(config, 'home_channel', None)
                aliases = getattr(config, 'aliases', {})
            elif kwargs:
                home_channel = kwargs.get('home_channel')
                aliases = kwargs.get('aliases', {})
            
            # Set home channel if configured
            if home_channel:
                self._delivery_router.directory.set_home_channel(platform, home_channel)
            
            # Add aliases if configured
            for alias_name, channel_id in aliases.items():
                self._delivery_router.directory.add_alias(alias_name, platform, channel_id)
    
    def configure_channels(self, config: Dict[str, Any]) -> None:
        """
        Configure channel directory from a dictionary.
        
        Args:
            config: Dictionary with platform configurations
            
        Example::
            
            botos.configure_channels({
                "telegram": {
                    "home_channel": "123456",
                    "aliases": {
                        "ops-alerts": "123456",
                        "dev-chat": "789012"
                    }
                },
                "discord": {
                    "home_channel": "456789"
                }
            })
        """
        self._delivery_router.configure_from_dict(config)
    
    async def deliver(self, target: str, text: str, origin: Optional[SessionSource] = None) -> bool:
        """
        Deliver a message to a target channel.
        
        Args:
            target: Target specification (origin|platform|platform:channel|alias)
            text: Message content to deliver
            origin: Optional source of the original request
            
        Returns:
            True if delivered successfully, False otherwise
            
        Example::
            
            # Reply to origin
            await botos.deliver("origin", "Hello!", origin=source)
            
            # Send to specific platform's home channel
            await botos.deliver("telegram", "Alert!")
            
            # Send to specific channel
            await botos.deliver("telegram:123456", "Build complete")
            
            # Send to aliased channel
            await botos.deliver("ops-alerts", "Disk full")
        """
        return await self._delivery_router.deliver(target, text, origin)

    @property
    def is_draining(self) -> bool:
        """Whether a graceful drain is currently in progress (#2375)."""
        return self._is_draining

    @property
    def accepting(self) -> bool:
        """Whether new inbound turns are still being dispatched (#2375).

        Adapters/ingress may consult this to stop accepting new work once
        a drain has begun, while letting in-flight turns finish.
        """
        return self._accepting

    async def drain(self, timeout: Optional[float] = None) -> int:
        """Stop accepting new inbound and wait for in-flight turns to finish.

        Bounded, opt-in graceful-drain phase for planned shutdowns
        (rolling deploy, auto-update, host restart). It (1) quiesces
        ingress so no new turns start, (2) waits — up to ``timeout``
        seconds — for ``running_turns`` to reach zero, and (3) flushes the
        outbound queue when the delivery router supports it. It does *not*
        tear anything down; callers (typically :meth:`stop`) perform the
        teardown afterwards.

        Args:
            timeout: Maximum seconds to wait for in-flight turns. Falls
                back to the construction-time ``drain_timeout``. A value of
                ``0``/``None`` makes this a no-op (today's behaviour).

        Returns:
            The number of agent turns still running when the deadline hit
            (``0`` when the drain completed cleanly).
        """
        timeout = self._drain_timeout if timeout is None else _coerce_drain_timeout(timeout)
        if not timeout or timeout <= 0:
            return 0

        self._is_draining = True
        self._accepting = False
        logger.info("BotOS: draining (graceful shutdown, timeout=%.0fs)", timeout)

        from praisonaiagents.gateway.protocols import DrainTimeoutPolicy

        policy = DrainTimeoutPolicy(drain_timeout_seconds=timeout)
        start = time.monotonic()
        running, _ = self._probe_activity()
        decision = policy.should_keep_draining(
            running_turns=running, seconds_elapsed=0.0
        )
        while decision.keep_draining:
            remaining = max(0.0, timeout - (time.monotonic() - start))
            await asyncio.sleep(min(0.5, remaining))
            running, _ = self._probe_activity()
            decision = policy.should_keep_draining(
                running_turns=running,
                seconds_elapsed=time.monotonic() - start,
            )

        # Flush any completed-but-undelivered replies before teardown.
        flush = getattr(self._delivery_router, "flush", None)
        if callable(flush):
            try:
                result = flush()
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                logger.warning("BotOS: outbox flush during drain failed: %s", e)

        running, _ = self._probe_activity()
        abandoned = max(0, running)
        if abandoned:
            logger.warning(
                "BotOS: drain timeout — %d turn(s) abandoned: %s",
                abandoned,
                decision.reason,
            )
        else:
            logger.info("BotOS: drain complete — no turns in flight")
        return abandoned

    async def stop(self, drain_timeout: Optional[float] = None) -> None:
        """Gracefully stop all running bots.

        Args:
            drain_timeout: Optional override for the graceful-drain phase
                (#2375). When set (or when the instance was constructed
                with a ``drain_timeout``), shutdown first quiesces ingress
                and waits for in-flight agent turns to finish before
                cancelling tasks. ``0``/``None`` preserves today's
                immediate-cancel behaviour.
        """
        if not self._is_running:
            return

        # Graceful drain phase (opt-in): let in-flight turns finish before
        # we cancel tasks below. No-op when no drain timeout is configured.
        effective_drain = (
            self._drain_timeout
            if drain_timeout is None
            else _coerce_drain_timeout(drain_timeout)
        )
        if effective_drain and effective_drain > 0:
            try:
                await self.drain(effective_drain)
            except Exception as e:
                logger.warning("BotOS: drain phase error (continuing teardown): %s", e)

        logger.info("BotOS stopping all bots...")

        # Fire GATEWAY_STOP lifecycle hook (no-op when no hooks registered)
        try:
            from ._protocol_mixin import fire_gateway_stop
            fire_gateway_stop(self._get_hook_runner(), list(self._bots.keys()))
        except Exception as e:
            logger.debug(f"GATEWAY_STOP emit error (non-fatal): {e}")

        # Stop health monitoring first
        if self._enable_supervision and self._supervisor:
            await self._supervisor.stop_health_monitoring()

        # Stop each bot
        for platform, bot in self._bots.items():
            try:
                await bot.stop()
                # Cleanup supervisor state
                if self._enable_supervision and self._supervisor:
                    self._supervisor.cleanup(platform)
            except Exception as e:
                logger.warning(f"BotOS: error stopping {platform}: {e}")

        # Cancel tasks
        for task in self._tasks:
            if not task.done():
                task.cancel()

        self._is_running = False
        logger.info("BotOS stopped")

    def remove_bot(self, platform: str) -> bool:
        """Remove a registered bot by platform name.

        Args:
            platform: Platform identifier to remove.

        Returns:
            True if removed, False if not found.
        """
        key = platform.lower()
        if key in self._bots:
            del self._bots[key]
            return True
        return False

    def run(self) -> None:
        """Synchronous entry point — starts all bots.

        Convenience wrapper so users don't need ``asyncio.run()``.

        Usage::

            botos = BotOS(agent=agent, platforms=["telegram", "discord"])
            botos.run()  # blocks until Ctrl+C
        """
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            logger.info("BotOS interrupted")

    @classmethod
    def from_config(cls, path: str) -> "BotOS":
        """Create a BotOS instance from a YAML config file.

        YAML format::

            name: My BotOS
            agent:
              name: assistant
              instructions: Be helpful
              llm: gpt-4o-mini
            platforms:
              telegram:
                token: ${TELEGRAM_BOT_TOKEN}
              discord:
                token: ${DISCORD_BOT_TOKEN}
            health:
              interval: 300
              startup_grace: 60
              max_restarts_per_hour: 10

        Args:
            path: Path to YAML config file.

        Returns:
            Configured BotOS instance.
        """
        import os
        import re

        try:
            import yaml
        except ImportError:
            raise ImportError("PyYAML required: pip install pyyaml")

        with open(path, "r") as f:
            raw = yaml.safe_load(f)

        if not raw or not isinstance(raw, dict):
            raise ValueError(f"Invalid BotOS config: {path}")

        def _resolve_env(val):
            if isinstance(val, str):
                return re.sub(
                    r'\$\{([^}]+)\}',
                    lambda m: os.environ.get(m.group(1), m.group(0)),
                    val,
                )
            return val

        # Build agent from config
        agent = None
        agent_cfg = raw.get("agent")
        if agent_cfg and isinstance(agent_cfg, dict):
            from praisonaiagents import Agent

            # Core params always supported
            agent_kwargs: Dict[str, Any] = {
                "name": agent_cfg.get("name", "assistant"),
                "instructions": agent_cfg.get("instructions", "You are a helpful assistant."),
            }
            if agent_cfg.get("llm"):
                agent_kwargs["llm"] = agent_cfg["llm"]

            # Extended params — memory, tools, verbose, knowledge, guardrails
            if "memory" in agent_cfg:
                agent_kwargs["memory"] = agent_cfg["memory"]

            # Pass through known Agent params
            for key in ("role", "goal", "backstory", "planning", "reflection"):
                if key in agent_cfg:
                    agent_kwargs[key] = agent_cfg[key]

            # Resolve tool names to real functions. Delegate string names to the
            # shared ToolResolver so BotOS honours the same resolution chain as
            # the rest of the framework (local tools.py -> wrapper registry ->
            # praisonaiagents -> praisonai-tools -> plugins) instead of only
            # seeing built-in praisonaiagents.tools. See issue #2585.
            tool_names = agent_cfg.get("tools")
            if tool_names and isinstance(tool_names, list):
                # Resolve string names to callables via the shared ToolResolver,
                # falling back to the built-in praisonaiagents.tools lookup if the
                # resolver is unavailable. Callables pass through unchanged and the
                # original list order is preserved (order can influence tool
                # priority/selection).
                resolver = None
                fallback_mod = None
                if any(isinstance(t, str) for t in tool_names):
                    try:
                        # Go through the praisonai.tool_resolver shim so the
                        # praisonai_code bootstrap runs in lean installs.
                        from praisonai_bot._code_bridge import import_code_module

                        ToolResolver = import_code_module("praisonai_code.tool_resolver").ToolResolver

                        # Point the resolver at the config directory's tools.py so
                        # config-local tools are found regardless of process cwd
                        # (matches the recipe loader's config-relative lookup).
                        from pathlib import Path

                        tools_py_path = str(Path(path).resolve().parent / "tools.py")
                        resolver = ToolResolver(tools_py_path=tools_py_path)
                    except ImportError:
                        import importlib
                        try:
                            fallback_mod = importlib.import_module("praisonaiagents.tools")
                        except ImportError:
                            fallback_mod = None

                resolved_tools = []
                for tool in tool_names:
                    if not isinstance(tool, str):
                        # Already-callable tools pass through unchanged.
                        resolved_tools.append(tool)
                        continue
                    if resolver is not None:
                        fn = resolver.resolve(tool)
                        if fn is not None:
                            resolved_tools.append(fn)
                        else:
                            logger.warning(
                                f"BotOS: tool '{tool}' could not be resolved "
                                "via ToolResolver (local/praisonaiagents/"
                                "praisonai-tools/plugins)"
                            )
                    else:
                        fn = getattr(fallback_mod, tool, None) if fallback_mod else None
                        if fn:
                            resolved_tools.append(fn)
                        else:
                            logger.warning(
                                f"BotOS: tool '{tool}' not found in "
                                "praisonaiagents.tools"
                            )

                if resolved_tools:
                    agent_kwargs["tools"] = resolved_tools

            if "knowledge" in agent_cfg:
                agent_kwargs["knowledge"] = agent_cfg["knowledge"]

            if "guardrail" in agent_cfg:
                agent_kwargs["guardrail"] = agent_cfg["guardrail"]

            agent = Agent(**agent_kwargs)

        # Build bots per platform
        bots = []
        platforms_cfg = raw.get("platforms", {})
        for plat_name, plat_cfg in platforms_cfg.items():
            if not isinstance(plat_cfg, dict):
                plat_cfg = {}
            # Resolve env vars in values
            resolved = {k: _resolve_env(v) for k, v in plat_cfg.items()}
            token = resolved.pop("token", None)
            bots.append(Bot(plat_name, agent=agent, token=token, **resolved))

        # Parse health configuration
        health_cfg = raw.get("health")
        health_monitor = None
        if health_cfg and isinstance(health_cfg, dict):
            health_monitor = HealthMonitorConfig.from_dict(health_cfg)

        # Check if supervision is disabled (handle null supervision key)
        supervision_cfg = raw.get("supervision") or {}
        enable_supervision = supervision_cfg.get("enabled", True)

        # Issue #2375: graceful-drain timeout. Accept either a top-level
        # ``drain_timeout`` or ``gateway.drain_timeout`` (seconds; 0/None
        # disables). Default off — preserves today's behaviour.
        gateway_cfg = raw.get("gateway") or {}
        drain_timeout = raw.get("drain_timeout", gateway_cfg.get("drain_timeout"))

        # Issue #2454: gateway-wide inbound admission control. Read from the
        # ``gateway`` block (or top-level fallback). Default 0/None disables it
        # so today's immediate-dispatch behaviour is preserved.
        max_concurrent_runs = int(
            raw.get(
                "max_concurrent_runs",
                gateway_cfg.get("max_concurrent_runs", 0),
            )
            or 0
        )
        queue_depth = int(
            raw.get("queue_depth", gateway_cfg.get("queue_depth", 0)) or 0
        )
        overflow_policy = (
            raw.get("overflow_policy", gateway_cfg.get("overflow_policy", "reject"))
            or "reject"
        )
        # Issue #3445: opt-in memory-aware admission (hard RSS ceiling in MiB).
        # Default 0 disables it, preserving concurrency-only admission.
        max_rss_mb = float(
            raw.get("max_rss_mb", gateway_cfg.get("max_rss_mb", 0)) or 0
        )

        # Issue #2531: single reliability posture. Accept a top-level
        # ``reliability`` or ``gateway.reliability``; the preset composes drain
        # + admission while any explicit field above still overrides it.
        reliability = raw.get("reliability", gateway_cfg.get("reliability"))

        return cls(
            bots=bots,
            health_monitor=health_monitor,
            enable_supervision=enable_supervision,
            drain_timeout=drain_timeout,
            max_concurrent_runs=max_concurrent_runs,
            queue_depth=queue_depth,
            overflow_policy=overflow_policy,
            max_rss_mb=max_rss_mb,
            reliability=reliability,
        )

    async def probe_all(self, timeout: float = 15.0) -> Dict[str, Any]:
        """Probe every registered bot's channel credentials concurrently.

        Pre-flight credential check (#2426): validates each channel's token
        and surfaces the bot identity *without* starting message processing.
        Unlike :meth:`health`, this is safe to call before ``start()`` — each
        bot builds its adapter lazily inside ``probe()``.

        Args:
            timeout: Per-bot deadline (seconds) so one stuck adapter cannot
                hang the whole aggregate. A timeout is reported as a failed
                ``ProbeResult`` for that platform.

        Returns:
            Dictionary mapping platform name to ``ProbeResult``.
        """
        from praisonaiagents.bots import ProbeResult

        if not self._bots:
            return {}

        platforms = list(self._bots.keys())

        async def _probe_one(bot: Bot) -> Any:
            try:
                return await asyncio.wait_for(bot.probe(), timeout=timeout)
            except asyncio.TimeoutError:
                return ProbeResult(
                    ok=False,
                    platform=bot.platform,
                    error=f"probe timed out after {timeout:g}s",
                )
            except Exception as e:  # pragma: no cover — defensive
                return ProbeResult(ok=False, platform=bot.platform, error=str(e))

        results = await asyncio.gather(
            *(_probe_one(self._bots[p]) for p in platforms)
        )
        return dict(zip(platforms, results))

    async def health(self) -> Dict[str, HealthResult]:
        """Get health status of all bots.
        
        Returns:
            Dictionary mapping platform name to HealthResult
        """
        results = {}
        current_time = time.time()
        
        for platform, bot in self._bots.items():
            try:
                if hasattr(bot, "health"):
                    results[platform] = await bot.health()
                else:
                    # Construct basic health result
                    uptime = None
                    if platform in self._start_times:
                        uptime = current_time - self._start_times[platform]
                    
                    results[platform] = HealthResult(
                        ok=bot.is_running if hasattr(bot, "is_running") else False,
                        platform=platform,
                        is_running=bot.is_running if hasattr(bot, "is_running") else False,
                        uptime_seconds=uptime,
                    )
            except Exception as e:
                results[platform] = HealthResult(
                    ok=False,
                    platform=platform,
                    is_running=False,
                    error=str(e),
                )
        
        return results
    
    def get_supervisor_status(self) -> Optional[Dict[str, Any]]:
        """Get supervisor status if enabled.
        
        Returns:
            Supervisor status dictionary or None if supervision disabled
        """
        if self._supervisor:
            return {
                "enabled": True,
                "channels": self._supervisor.get_all_status(),
                "health_monitor": self._supervisor.get_health_status(),
            }
        return {"enabled": False}
    
    def pause_bot(self, platform: str) -> bool:
        """Pause a bot (only works with supervision enabled).
        
        Args:
            platform: Platform name to pause
            
        Returns:
            True if paused, False otherwise
        """
        if self._supervisor:
            return self._supervisor.pause(platform)
        return False
    
    def resume_bot(self, platform: str) -> bool:
        """Resume a paused bot (only works with supervision enabled).
        
        Args:
            platform: Platform name to resume
            
        Returns:
            True if resumed, False otherwise
        """
        if self._supervisor:
            return self._supervisor.resume(platform)
        return False
    
    def reconnect_bot(self, platform: str) -> bool:
        """Force reconnect a bot (only works with supervision enabled).
        
        Args:
            platform: Platform name to reconnect
            
        Returns:
            True if reconnect triggered, False otherwise
        """
        if self._supervisor:
            return self._supervisor.reconnect(platform)
        return False
    
    def __repr__(self) -> str:
        platforms = list(self._bots.keys())
        supervised = "supervised" if self._enable_supervision else "unsupervised"
        return f"BotOS(platforms={platforms!r}, running={self._is_running}, mode={supervised})"
