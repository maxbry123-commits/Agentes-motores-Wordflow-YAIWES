"""
Per-user session isolation for PraisonAI bots.

Bots share a single Agent instance but each user needs independent
chat history.  BotSessionManager swaps the agent's ``chat_history``
before and after every call so conversations never leak between users.

When a ``store`` (any ``SessionStoreProtocol`` implementation) is
provided, sessions are **persisted to disk** and survive restarts.
Without a store, behaviour is identical to the original in-memory mode.

Thread-safety: an ``asyncio.Lock`` per user serialises concurrent
calls from the same user; different users run in parallel.
"""

from __future__ import annotations

import asyncio
import contextvars
import logging
import re
import time
import weakref
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from functools import partial
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from .._lockmap import LockMap
from ._reset_policy import SessionResetPolicy
from ._admission import AdmissionRejected

if TYPE_CHECKING:
    from praisonaiagents import Agent
    from praisonaiagents.gateway import WarmSession, MemoryPressureProtocol

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------
# Durability degradation registry (Issue #4339)
#
# Gateway state (webhook idempotency, session history) is durable by default.
# When a durable store genuinely cannot be initialised the boundary that owns
# it records a *durability-degraded* fact here instead of only logging a
# warning, so the gateway can surface it through the surfaces operators already
# read (``gateway doctor`` / ``gateway status``) — the same treatment channel
# credential degradation already gets. This reuses the core degraded-owner
# vocabulary (``owner_kind="gateway"``) so no new protocol is introduced; the
# gateway's ``health()`` merges this process-local registry alongside its own.
# --------------------------------------------------------------------------
try:
    from praisonaiagents.gateway import DegradedCapabilityRegistry as _DegRegistry
    _DURABILITY_REGISTRY: Optional[Any] = _DegRegistry()
except Exception:  # pragma: no cover - core registry unavailable
    _DURABILITY_REGISTRY = None


def record_durability_degraded(
    component: str,
    *,
    reason: str,
    recovery: str = "praisonai gateway doctor --fix",
) -> None:
    """Record that a durable store fell back to non-durable, in-memory operation.

    ``component`` is the owned state that lost durability (e.g. ``"session"`` or
    ``"idempotency"``); ``reason`` is a redacted, operator-safe explanation.
    Best-effort and never raises into the caller's hot path — if the core
    registry is unavailable this is a no-op (behaviour then matches the old
    log-only path).
    """
    registry = _DURABILITY_REGISTRY
    if registry is None:
        return
    try:
        from praisonaiagents.gateway import DegradedOwner

        registry.mark(
            DegradedOwner(
                owner_kind="gateway",
                owner_id=f"durability:{component}",
                state="cold",
                reason=reason,
                retry_hint=recovery,
            )
        )
    except Exception:  # pragma: no cover - defensive
        pass


def clear_durability_degraded(component: str) -> None:
    """Clear a previously-recorded durability degradation for ``component``."""
    registry = _DURABILITY_REGISTRY
    if registry is None:
        return
    try:
        registry.clear("gateway", f"durability:{component}")
    except Exception:  # pragma: no cover - defensive
        pass


def durability_degraded_owners() -> List[Any]:
    """Return the current durability-degraded owners (empty when all durable)."""
    registry = _DURABILITY_REGISTRY
    if registry is None:
        return []
    try:
        return list(registry.list_degraded())
    except Exception:  # pragma: no cover - defensive
        return []


# Turn-local resolved profile namespace (Issue #4341). A ``chat()`` turn binds
# the profile it resolved into this ContextVar for the duration of that turn, so
# every ``_storage_key`` recomputation after an await point uses *this* turn's
# tenant scope — never a value another concurrent route staged in the meantime.
# ContextVars are copied per task, so overlapping routed turns each see their own
# binding. ``None`` means unscoped (fail-closed: an unscoped turn never borrows
# another tenant's namespace).
_ACTIVE_PROFILE_NS: "contextvars.ContextVar[Optional[str]]" = contextvars.ContextVar(
    "praisonai_bot_active_profile_ns", default=None
)

# Matches one or more leading arrival-time prefixes of the form
# ``[… YYYY-MM-DD HH:MM …]`` (Issue #2834). Kept deliberately narrow — it only
# strips bracketed groups that contain a ``YYYY-MM-DD HH:MM`` date-time — so a
# user's own bracketed text (e.g. "[TODO] ...") is never eaten. Anchoring on the
# date-time (rather than an English weekday) keeps de-duplication working under
# non-English server locales (``%a`` renders ``lun.``/``Mo`` etc.) and for custom
# ``timestamp_template`` values that omit ``%a``. Used to de-duplicate the prefix
# on history replay so stamps never accumulate as ``[ts] [ts] … text``.
_TIMESTAMP_PREFIX_RE = re.compile(
    r"^(?:\[[^\]]*?\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}[^\]]*\]\s*)+"
)


def strip_leading_timestamps(content: str) -> str:
    """Remove any leading arrival-time prefixes rendered by :func:`_with_timestamp`.

    Idempotent and safe on un-stamped content. Ensures a message re-sent through
    the turn builder on history replay is stamped exactly once rather than
    accumulating ``[ts] [ts] … text``.
    """
    if not content:
        return content
    return _TIMESTAMP_PREFIX_RE.sub("", content, count=1)


class BotRunTimeout(Exception):
    """Exception raised when a bot run times out."""
    pass


@asynccontextmanager
async def _null_async_context():
    """A no-op async context manager (admission gate disabled)."""
    yield


class BotSessionManager:
    """Lightweight per-user session store for bot agents.

    Usage inside a bot message handler::

        # In-memory only (backward compatible)
        session_mgr = BotSessionManager()

        # With persistent store (recommended)
        from praisonaiagents.session import get_default_session_store
        session_mgr = BotSessionManager(
            store=get_default_session_store(),
            platform="telegram",
        )

        response = await session_mgr.chat(agent, user_id, text)

    The manager:
    1. Saves the agent's current ``chat_history``.
    2. Loads the user's history from the persistent store (or in-memory cache).
    3. Calls ``agent.chat(prompt)`` (via ``run_in_executor``).
    4. Persists the updated history back to the store.
    5. Restores the agent's original history.

    ``/new`` command → call ``session_mgr.reset(user_id)``.

    Multi-agent safety: Uses a per-Agent lock to serialise history
    swaps when the same Agent instance is shared across multiple bots
    (e.g. gateway multi-bot mode).
    """

    def __init__(
        self,
        max_history: int = 100,
        store: Optional[Any] = None,
        platform: str = "",
        dlq: Optional[Any] = None,
        identity_resolver: Optional[Any] = None,
        ingress_journal: Optional[Any] = None,
        run_control: Optional[Any] = None,
        run_timeout: float = 300.0,  # 5 minutes default timeout
        reset_policy: Optional[SessionResetPolicy] = None,
        channel_directory: Optional[Any] = None,
        inject_session_context: bool = True,
        compaction: Optional[Any] = None,
        delivery_router: Optional[Any] = None,
        session_scope: str = "per_user",
        attribution: str = "[{sender}] ",
        timestamps: bool = False,
        timestamp_template: str = "[%a %Y-%m-%d %H:%M %Z] ",
        admission_gate: Optional[Any] = None,
        turn_lock_map: Optional["LockMap"] = None,
        surface_completion_reason: bool = False,
    ) -> None:
        self._histories: Dict[str, List[Dict[str, Any]]] = {}
        # Issue #3232: the per-turn lock map is keyed on the *resolved* storage
        # key (unified user id when an identity resolver is configured), so
        # serialisation already holds within one adapter. When several adapters
        # resolve the same human to one unified session, BotOS injects a single
        # shared ``LockMap`` here so those adapters share one lock per resolved
        # id and turns run serially across platforms — no interleaved transcript.
        # Absent injection (single-adapter / direct use) each manager keeps its
        # own map, preserving today's behaviour exactly.
        self._locks = turn_lock_map if turn_lock_map is not None else LockMap()
        self._agent_locks: "weakref.WeakKeyDictionary[Any, asyncio.Lock]" = weakref.WeakKeyDictionary()
        self._max_history = max_history
        self._store = store
        self._platform = platform
        self._last_active: Dict[str, float] = {}
        self._last_reset: Dict[str, float] = {}  # Track last reset time per user
        # Issue #3804: per-session in-flight turn counter (storage_key -> depth).
        # A key is present with a positive count while a turn is executing
        # against that cache; the memory-pressure sweep skips any such key so a
        # live turn is never aborted. Empty in normal steady state.
        self._in_flight: Dict[str, int] = {}
        # Issue #3804: per-session durable-flush marker (storage_key present iff
        # the in-memory cache is known to match a completed store write). Cleared
        # before each store write and set only after it fully succeeds, so a
        # failed/partial persist leaves the key absent and the memory-pressure
        # sweep never evicts the only current copy (would lose data).
        self._flushed: set[str] = set()
        # N4: optional inbound DLQ — when set, failed agent.chat() calls
        # are persisted for later replay. Default ``None`` preserves
        # legacy behaviour (exception bubbles up untouched).
        self._dlq = dlq
        # W1: optional cross-platform identity resolver. When set, the
        # session key is the resolver-returned unified user id, so the
        # same human pinging from multiple platforms shares one history.
        self._identity_resolver = identity_resolver
        # Ingress journal: optional durable message processing with dedup.
        # When set, messages are journaled before agent processing for
        # crash recovery and webhook redelivery protection.
        self._ingress_journal = ingress_journal
        # Platform awareness: channel directory and injection flag
        self._channel_directory = channel_directory
        self._inject_session_context = inject_session_context
        # Issue #2372: the running gateway's DeliveryRouter. When set, each
        # agent turn registers a concrete ``BotOutboundMessenger`` into the
        # per-turn context so the built-in core ``send_message`` tool can
        # proactively reach the user mid-task. ``None`` preserves legacy
        # behaviour (the tool returns its "no gateway available" message).
        self._delivery_router = delivery_router
        self._last_journal_key = None  # Store key for delayed completion
        # Run control for in-flight message handling
        self._run_control = run_control
        # Issue #3296: opt-in surfacing of *why* a turn ended. When True, a turn
        # that stops early (max_steps / cancelled / error) appends a concise,
        # user-safe note to the reply so a truncated or empty answer is no longer
        # silent. Off by default so clean completions and existing deployments
        # are byte-for-byte unchanged.
        self._surface_completion_reason = surface_completion_reason
        # Run timeout and active run tracking for cancellation support
        self._run_timeout = run_timeout
        self._active_runs: Dict[str, Any] = {}  # user_id -> InterruptController
        # In-run progress liveness (Issue #2393): wall-clock timestamp of the
        # most recent real run progress (run start, streamed token/draft edit,
        # tool event). Channel health reads this via ``last_run_progress`` so a
        # long, actively-progressing run keeps the channel BUSY instead of being
        # restarted mid-run once its wall-clock crosses ``stuck_after``. A run
        # that emits nothing for ``stuck_after`` leaves this frozen and is still
        # correctly flagged STUCK.
        self._last_run_progress: Optional[float] = None
        # Per-user model overrides set via the /model command. Applied per-turn
        # inside the agent lock in chat() and restored afterwards so a shared
        # Agent instance never leaks one user's model to another. Keyed by
        # storage_key (same as _histories).
        self._model_overrides: Dict[str, Any] = {}
        # Prompt-cache-stability contract (Issue #3352): last prompt-prefix
        # signature seen per storage_key. The prefix is the cache-relevant
        # part of every request (model + tool schemas + system-prompt fp); a
        # signature change turn-over-turn means the provider prompt cache will
        # miss. Recorded here so the gateway can meter and surface that
        # invalidation instead of it happening silently. Keyed like _histories.
        self._prefix_sig: Dict[str, str] = {}
        # Optional GatewayMetrics registry. When a gateway wires one in, the
        # ``prompt_cache_invalidations_total`` counter is incremented on each
        # prefix drift. ``None`` (default) keeps direct/standalone use unchanged.
        self._metrics: Optional[Any] = None
        # Per-route toolset scope staged by a routing handler that cannot thread
        # ``tool_policy`` through the adapter's own ``chat()`` call (Issue #2298).
        # The gateway's injected on_message handler runs synchronously right
        # before the adapter's ``_session.chat()`` in the same dispatch, so it
        # stages the resolved policy here keyed by agent identity; ``chat()``
        # consumes-and-clears it when no explicit ``tool_policy`` was passed.
        # Keyed by ``id(agent)`` so a shared session serving multiple agents
        # never crosses policies.
        self._pending_tool_policies: Dict[int, Any] = {}
        # Per-tenant profile namespace staged by a routing handler (Issue #4341).
        # When a route resolves to a ``profile``, the gateway stages its
        # namespace here (keyed by ``id(agent)``, exactly like the tool-policy
        # seam) so the very next ``chat()`` for that agent enters the tenant
        # scope for the turn. ``chat()`` consumes-and-clears it and binds the
        # value into a per-turn ContextVar, so overlapping routed turns never
        # share a namespace. Empty/``None`` means unscoped — a route with no
        # profile never borrows another tenant's memory (fail-closed).
        self._pending_profile_namespaces: Dict[int, str] = {}
        # Fallback staging for callers that stage without an agent (or read
        # ``_storage_key`` outside a ``chat()`` turn): the most-recently staged
        # namespace, consumed once by the next ``chat()`` on any agent.
        self._staged_profile_namespace: Optional[str] = None
        # Session reset policy for automatic lifecycle management
        self._reset_policy = reset_policy or SessionResetPolicy(mode="none")
        # Per-user last agent-emitted presentation. ``chat()`` keeps the return
        # type ``str`` for backward compatibility; when an agent (or hook)
        # returns a MessagePresentation/AgentReply, the portable presentation is
        # captured here so channel adapters can render interactive UI via the
        # existing per-channel renderers (text fallback otherwise). Keyed by
        # storage_key and consumed via ``pop_last_presentation``.
        self._last_presentation: Dict[str, Any] = {}
        # Track storage keys we've already fired SESSION_START for, so the
        # hook fires exactly once per session lifetime (until reset).
        self._seen_sessions: set = set()
        # Per-session hook context captured when SESSION_START fires, keyed by
        # storage_key: (HookRunner, agent_name). Lets any clear path emit
        # SESSION_END with the *correct* runner/agent — never another user's.
        self._session_hook_context: Dict[str, Any] = {}
        # Group/channel session scope (Issue #2376). ``per_user`` (default)
        # preserves today's per-sender isolation. ``per_chat`` routes a
        # group/channel chat to a single shared session keyed by
        # ``(platform, chat_id, thread_id)`` so the agent sees one coherent
        # multi-party transcript, and prefixes each turn with the sender so
        # statements can be attributed. DMs always stay per_user even when
        # ``per_chat`` is set, so private conversations never collide.
        scope = (session_scope or "per_user").strip().lower()
        if scope not in ("per_user", "per_chat"):
            logger.warning(
                "Unknown session_scope %r; falling back to 'per_user'", session_scope
            )
            scope = "per_user"
        self._session_scope = scope
        # Attribution template applied to each turn's content in per_chat mode.
        # Supports ``{sender}`` and ``{time}`` placeholders. Empty disables it.
        self._attribution = attribution if attribution is not None else "[{sender}] "
        # Temporal grounding (Issue #2834): when enabled, each inbound turn is
        # prefixed with its real arrival time so the always-on gateway agent can
        # reason about "now", conversation gaps and relative-time requests.
        # Applied to both per_user (DM) and per_chat (group) scopes; the prefix
        # is stripped-then-re-rendered so replayed history never accumulates it.
        self._timestamps = bool(timestamps)
        self._timestamp_template = (
            timestamp_template if timestamp_template else "[%a %Y-%m-%d %H:%M %Z] "
        )
        # Optional history compaction. When configured, older turns are
        # summarised (instead of hard-truncated) once history exceeds the
        # configured budget, so long-lived conversations retain context.
        # Default ``None`` preserves the legacy tail-slice truncation.
        #
        # We store only the *config* and build a fresh ``ContextCompactor``
        # per ``_save_history`` call. The core compactor carries mutable
        # per-conversation state (iterative summary, anti-thrashing streaks),
        # so a single shared instance would leak context across users and
        # race under concurrent saves on the executor thread pool.
        # Issue #2454: optional gateway-wide inbound admission gate. When set,
        # each turn must acquire a global concurrency slot (bounded by
        # ``max_concurrent_runs``) before its per-user lock, with a bounded
        # wait queue and a declared overflow policy. ``None`` preserves the
        # legacy behaviour (every inbound turn dispatches immediately, only
        # per-user serialisation applies).
        self._admission_gate = admission_gate
        self._compaction_config = compaction
        # Probe availability once so behaviour/tests can detect whether
        # compaction is active without sharing the stateful instance.
        self._compaction_enabled = self._build_compactor(compaction) is not None
        # Code-skew guard (Issue #2460): capture the wrapper code fingerprint at
        # startup so a later in-place update (git pull / pip install -U) is
        # caught before a hot operation (e.g. /model) triggers a first-use lazy
        # import against changed code. Best-effort and fail-open; capturing here
        # (rather than on first /model use) also guards the very first call and
        # pre-resolves the comparison predicate while imports are known-good.
        try:
            from ._commands import capture_boot_fingerprint

            capture_boot_fingerprint(self)
        except Exception:
            pass

    def attach_gateway_runtime(self, runtime: Any) -> None:
        """Wire the gateway reliability seams into this session manager.

        Implements the core ``SupportsGatewayRuntime`` contract so the gateway
        injects the identity resolver, delivery router, admission gate, and
        shared per-turn lock map through one typed call instead of four
        duck-typed private-attribute splices. Only seams present (non-``None``)
        on ``runtime`` are applied; a ``None`` seam leaves the existing value
        untouched.

        Args:
            runtime: A ``GatewayRuntimeSeams`` carrier (or any object exposing
                the same optional attributes).
        """
        identity_resolver = getattr(runtime, "identity_resolver", None)
        if identity_resolver is not None:
            self._identity_resolver = identity_resolver
        delivery_router = getattr(runtime, "delivery_router", None)
        if delivery_router is not None:
            self._delivery_router = delivery_router
        admission_gate = getattr(runtime, "admission_gate", None)
        if admission_gate is not None:
            self._admission_gate = admission_gate
        turn_lock_map = getattr(runtime, "turn_lock_map", None)
        if turn_lock_map is not None:
            self._locks = turn_lock_map

    @staticmethod
    def _build_compactor(compaction: Optional[Any]) -> Optional[Any]:
        """Lazily construct a ``ContextCompactor`` from a compaction config.

        Accepts a ``SessionCompactionConfigSchema`` (or any object/dict with
        the same fields). Returns ``None`` when compaction is disabled or the
        core compaction engine is unavailable, in which case the manager falls
        back to the legacy tail-slice truncation.
        """
        if compaction is None:
            return None

        # Normalise to attribute access from either a pydantic model or dict.
        def _get(name, default=None):
            if isinstance(compaction, dict):
                return compaction.get(name, default)
            return getattr(compaction, name, default)

        if not _get("enabled", False):
            return None

        strategy = _get("strategy", "summarize")
        max_tokens = _get("max_tokens", None)
        max_messages = _get("max_messages", 100)
        keep_recent = _get("keep_recent", 10)

        try:
            from praisonaiagents.compaction import ContextCompactor, CompactionStrategy
        except Exception as e:  # pragma: no cover — optional dependency
            logger.warning(
                "Compaction requested but praisonaiagents.compaction is unavailable: %s",
                e,
            )
            return None

        try:
            strategy_enum = CompactionStrategy(strategy)
        except ValueError:
            logger.warning(
                "Unknown compaction strategy %r; falling back to 'summarize'", strategy
            )
            strategy_enum = CompactionStrategy.SUMMARIZE

        # Message-count budgets are translated to a rough token budget so the
        # core token-based compactor triggers at the intended history length.
        # ~4 chars/token and an estimated ~80 tokens/message keeps this simple
        # and avoids touching the core engine. NOTE: this is only an estimate —
        # actual compaction depth varies with message size. The caller keeps
        # ``max_history`` as a hard upper bound so short-message bots never grow
        # in-memory history unbounded before the token threshold is reached.
        if max_tokens is None:
            max_tokens = max(1, int(max_messages) * 80)

        try:
            return ContextCompactor(
                max_tokens=int(max_tokens),
                strategy=strategy_enum,
                preserve_recent=int(keep_recent),
            )
        except Exception as e:  # pragma: no cover — defensive
            logger.warning("Failed to build ContextCompactor: %s", e)
            return None

    def _attribute(self, prompt: str, sender: str) -> str:
        """Prefix *prompt* with the sender per the attribution template.

        Used in ``per_chat`` scope so a multi-party transcript records who
        said what (Issue #2376). The template supports ``{sender}`` and
        ``{time}`` placeholders; an empty template or missing sender leaves
        the prompt unchanged. Best-effort — any formatting error falls back
        to the original prompt so a malformed template never breaks chat.

        The ``sender`` is a third-party-controlled platform display name /
        title, so it is neutralised (newlines collapsed, control chars
        stripped, length-bounded) before interpolation so a hostile name
        cannot masquerade as a fake system directive in the prompt the model
        re-reads every turn (Issue #3313). A well-behaved name is unchanged.
        """
        if not self._attribution or not sender:
            return prompt
        # ``sender`` is a raw, third-party-controlled platform display name /
        # group title. Neutralise it before interpolation so an embedded
        # newline can't masquerade as a fake heading / system directive in
        # the per-turn prompt prefix (prompt-injection defence, on by default).
        try:
            from praisonaiagents.session.context import neutralize_untrusted_text
            safe_sender = neutralize_untrusted_text(sender)
        except Exception:  # pragma: no cover — never break chat over sanitising
            # If the core helper is unavailable (older ``praisonaiagents``), the
            # fallback must still mirror its guarantees so a platform-controlled
            # name can't recreate the injected prompt structure: collapse every
            # newline-like separator, strip control chars, bound length.
            raw = str(sender)
            for _sep in ("\r\n", "\r", "\n", "\u2028", "\u2029", "\u0085"):
                raw = raw.replace(_sep, " ")
            raw = "".join(c if c >= " " or c == "\t" else " " for c in raw)
            safe_sender = " ".join(raw.split())[:240]
        try:
            prefix = self._attribution.format(
                sender=safe_sender,
                time=datetime.now().strftime("%H:%M"),
            )
        except (KeyError, IndexError, ValueError) as e:  # pragma: no cover — defensive
            logger.warning("Invalid attribution template %r: %s", self._attribution, e)
            return prompt
        return f"{prefix}{prompt}"

    def _with_timestamp(
        self, content: str, received_at: Optional[datetime] = None
    ) -> str:
        """Prefix *content* with its real arrival time (Issue #2834).

        Grounds the always-on gateway agent in "now": the model sees each turn's
        true arrival time so it can compute relative-time requests ("in 2 hours")
        and reason about conversation gaps. ``received_at`` is the platform's
        real receive time when the caller has it, else ``datetime.now()``.

        The prefix is de-duplicated (``strip_leading_timestamps`` first) so a
        replayed message is stamped exactly once instead of accumulating. Any
        formatting error falls back to the un-stamped content so a malformed
        template never breaks chat.
        """
        if not self._timestamps or not content:
            return content
        base = strip_leading_timestamps(content)
        # Default to a timezone-aware UTC "now" so ``%Z`` in the template renders
        # a real label (``UTC``) instead of an empty string (which would leave a
        # stray space before ``]``). A caller-supplied ``received_at`` is used as-is.
        stamp_at = received_at or datetime.now(timezone.utc)
        try:
            prefix = stamp_at.strftime(self._timestamp_template)
        except (ValueError, TypeError) as e:  # pragma: no cover — defensive
            logger.warning(
                "Invalid timestamp_template %r: %s", self._timestamp_template, e
            )
            # Return the de-duplicated base (not the original content) so a
            # malformed template never re-preserves a stale prefix on replay.
            return base
        return f"{prefix}{base}"

    def _scope_for(self, chat_type: str = "") -> str:
        """Resolve the effective session scope for a given chat type.

        ``per_chat`` only applies to multi-party chat types (group/channel,
        or an undisambiguated ``unknown`` group on platforms like Telegram
        supergroups). Direct messages always stay ``per_user`` so private
        conversations are never merged into a shared transcript.

        Callers that only have a ``chat_id`` (e.g. ``reset()`` from a ``/new``
        handler) should derive ``chat_type`` via :func:`detect_chat_type`
        before calling so a DM never falls through to ``per_chat`` — see
        ``_storage_key``, which does this automatically.
        """
        if self._session_scope != "per_chat":
            return "per_user"
        if chat_type and chat_type.lower() in ("direct", "dm", "private"):
            return "per_user"
        return "per_chat"

    def _storage_key(
        self,
        user_id: str,
        *,
        account: str = "",
        chat_id: str = "",
        thread_id: str = "",
        chat_type: str = "",
    ) -> str:
        """Resolve a raw platform user id to the in-memory/store key.

        With an identity resolver this is the unified user id; without
        one, behaviour is unchanged (raw ``user_id``).

        When ``session_scope='per_chat'`` and the message arrives in a
        group/channel (``chat_id`` present, not a DM), the key is shared
        across participants — ``{platform}:acct:{account}:chat:{chat_id}:{thread_id}`` —
        so the agent sees one coherent multi-party transcript (Issue #2376).
        ``account`` namespaces the key so two gateway accounts on the same
        platform that happen to reuse a chat/thread id never collide.

        ``chat_type`` is derived from ``chat_id`` when omitted (e.g. a
        ``reset()`` call from a ``/new`` handler that only has the chat id)
        so a DM never accidentally resolves to a shared per_chat key.
        """
        effective_chat_type = chat_type
        if (
            not effective_chat_type
            and chat_id
            and self._session_scope == "per_chat"
        ):
            try:
                from .delivery import detect_chat_type
                effective_chat_type = detect_chat_type(self._platform, chat_id)
            except Exception:  # pragma: no cover — defensive
                effective_chat_type = ""
        if self._scope_for(effective_chat_type) == "per_chat" and chat_id:
            prefix = self._platform or "bot"
            account_key = account or "default"
            base = f"{prefix}:acct:{account_key}:chat:{chat_id}:{thread_id}"
        elif self._identity_resolver is not None and self._platform:
            try:
                base = self._identity_resolver.resolve(self._platform, user_id)
            except Exception as e:  # pragma: no cover — defensive
                logger.warning("identity resolver failed: %s", e)
                base = user_id
        else:
            base = user_id
        # Per-tenant memory isolation (Issue #4341): when a route resolved to a
        # ``profile``, its namespace is bound turn-locally in ``_ACTIVE_PROFILE_NS``
        # so every storage key is prefixed with the tenant scope. Reading the
        # ContextVar (not a shared field) means a key recomputed after an await
        # point always uses *this* turn's tenant — an overlapping route for
        # another tenant can never rewrite it. This keys memory/session state per
        # profile so two routes on one process never share a transcript. A route
        # with no profile stays unprefixed and never falls into a tenant's scope.
        # Prefer the turn-local binding; fall back to the instance staging only
        # when no turn is active (e.g. a direct ``_storage_key`` read before
        # ``chat()`` runs). The ContextVar never leaks across turns because
        # ``chat()`` resets it in ``finally``; the staged field is consumed by
        # the next ``chat()`` so it cannot silently persist either.
        profile_ns = _ACTIVE_PROFILE_NS.get()
        if profile_ns is None:
            profile_ns = self._staged_profile_namespace
        if profile_ns:
            return f"profile:{profile_ns}:{base}"
        return base

    def _persist_key(self, storage_key: str) -> str:
        """Derive the persistent-store key from an in-memory storage key.

        With a resolver, ``storage_key`` is already the unified user id
        and is used directly. Without a resolver, the legacy
        ``bot_{platform}_{user_id}`` prefix is preserved for back-compat.
        """
        if self._identity_resolver is not None and self._platform:
            return storage_key
        prefix = f"bot_{self._platform}" if self._platform else "bot"
        return f"{prefix}_{storage_key}"

    def _session_key(self, user_id: str, **route: str) -> str:
        """Persistent-store key for a raw platform user id (back-compat API).

        Accepts optional ``chat_id``/``thread_id``/``chat_type`` so per_chat
        scope persists to a shared key (Issue #2376); without them behaviour
        is unchanged.
        """
        return self._persist_key(self._storage_key(user_id, **route))

    def _get_lock(self, user_id: str, **route: str) -> asyncio.Lock:
        """Get or create an asyncio.Lock for *user_id* (storage-keyed)."""
        key = self._storage_key(user_id, **route)
        return self._locks.get(key)

    def _get_agent_lock(self, agent: "Agent") -> asyncio.Lock:
        """Get or create a lock for the *agent* instance (using WeakKeyDictionary)."""
        lock = self._agent_locks.get(agent)
        if lock is None:
            lock = asyncio.Lock()
            self._agent_locks[agent] = lock
        return lock

    def _maybe_fire_session_start(self, agent: "Agent", user_id: str, **route: str) -> None:
        """Fire SESSION_START once per session lifetime (no-op without hooks)."""
        storage_key = self._storage_key(user_id, **route)
        if storage_key in self._seen_sessions:
            return
        self._seen_sessions.add(storage_key)
        try:
            from ._protocol_mixin import fire_session_start, _resolve_runner_from_agent
            runner = _resolve_runner_from_agent(agent)
            agent_name = getattr(agent, "agent_name", None) or getattr(agent, "name", "bot")
            # Remember this session's runner+agent so any clear path can fire
            # SESSION_END with the correct context (never another user's agent).
            if runner is not None:
                self._session_hook_context[storage_key] = (runner, agent_name)
            fire_session_start(
                runner,
                session_id=storage_key,
                platform=self._platform,
                agent_name=agent_name,
            )
        except Exception as e:
            logger.debug("SESSION_START emit error (non-fatal): %s", e)

    def _check_prefix_stability(self, agent: "Agent", storage_key: str) -> None:
        """Meter prompt-cache prefix drift for this turn (Issue #3352).

        Computes the agent's cache-relevant prefix signature (model + sorted
        tool names + system-prompt fingerprint) *after* the per-turn tool/model
        swaps are applied, and compares it to the last signature for this
        session. On a change — the one auditable point where provider prompt
        caching is knowingly sacrificed — it increments an optional metric and
        fires the advisory PROMPT_PREFIX_INVALIDATED hook. Best-effort: any
        failure is swallowed so metering never breaks a turn.
        """
        try:
            from praisonaiagents.agent.prompt_cache import prompt_prefix_signature
            sig = prompt_prefix_signature(agent)
        except Exception as e:  # pragma: no cover - defensive
            logger.debug("prompt prefix signature error (non-fatal): %s", e)
            return
        last = self._prefix_sig.get(storage_key)
        self._prefix_sig[storage_key] = sig
        if last is None or last == sig:
            return
        if self._metrics is not None:
            try:
                self._metrics.inc("prompt_cache_invalidations_total")
            except Exception:  # pragma: no cover - defensive
                pass
        try:
            from ._protocol_mixin import (
                fire_prompt_prefix_invalidated,
                _resolve_runner_from_agent,
            )
            runner = _resolve_runner_from_agent(agent)
            agent_name = getattr(agent, "agent_name", None) or getattr(agent, "name", "bot")
            fire_prompt_prefix_invalidated(
                runner,
                session_id=storage_key,
                old_sig=last,
                new_sig=sig,
                agent_name=agent_name,
                reason="tools/model",
            )
        except Exception as e:  # pragma: no cover - defensive
            logger.debug("PROMPT_PREFIX_INVALIDATED emit error (non-fatal): %s", e)

    def _fire_session_end(self, storage_key: str, reason: str = "clear") -> None:
        """Emit SESSION_END for *storage_key* if a session was open, then forget it.

        Idempotent and best-effort: a no-op when the session was never seen or
        no hook runner was captured. Used by every session-clear path (explicit
        reset, policy auto-reset, stale reaping, reset_all) so SESSION_START can
        fire again for the next session lifetime.
        """
        if storage_key not in self._seen_sessions:
            return
        self._seen_sessions.discard(storage_key)
        runner, agent_name = self._session_hook_context.pop(storage_key, (None, "bot"))
        if runner is None:
            return
        try:
            from ._protocol_mixin import fire_session_end
            fire_session_end(
                runner,
                session_id=storage_key,
                agent_name=agent_name,
                reason=reason,
            )
        except Exception as e:
            logger.debug("SESSION_END emit error (non-fatal): %s", e)

    def _load_history(self, user_id: str, **route: str) -> List[Dict[str, Any]]:
        """Load user history from store (if available) or in-memory cache.
        
        Checks reset policy and clears history if a reset is needed.
        """
        storage_key = self._storage_key(user_id, **route)
        
        # Check if session should be reset based on policy
        if self._should_reset_session(storage_key):
            logger.info("Auto-resetting session for user %s based on policy", user_id)
            self._clear_session_data(storage_key, self._persist_key(storage_key))
            # End the expiring session so the next message re-opens a fresh one
            # (otherwise lifecycle hooks would go permanently silent for this user).
            self._fire_session_end(storage_key, reason="policy")
            # Mark the reset time
            self._last_reset[storage_key] = time.monotonic()
            return []
        
        if self._store is not None:
            key = self._session_key(user_id, **route)
            try:
                history = self._store.get_chat_history(key)
                if history:
                    return list(history)
            except Exception as e:
                logger.warning("Failed to load session from store: %s", e)
        return list(self._histories.get(storage_key, []))

    def _save_history(
        self, user_id: str, history: List[Dict[str, Any]], **route: str
    ) -> None:
        """Save user history to store (if available) and in-memory cache.

        When a compactor is configured, older turns are summarised (keeping a
        recent verbatim tail) instead of being permanently discarded, so
        long-lived conversations retain context across restarts. Without a
        compactor, the legacy tail-slice truncation is applied.

        A fresh ``ContextCompactor`` is built per call (not shared on the
        instance) so per-conversation state never leaks across users and
        concurrent saves on the executor pool don't race.
        """
        # Build a per-call compactor so its mutable per-conversation state
        # (iterative summary, anti-thrashing streaks) stays isolated per user.
        compactor = (
            self._build_compactor(self._compaction_config)
            if self._compaction_enabled
            else None
        )
        # Hard cap before compaction: short messages can under-shoot the token
        # budget yet still arrive in huge batches. Trimming first avoids running
        # token counting / summarisation over thousands of turns (and prevents
        # offline CI hangs when tiktoken tries a first-use network download).
        if compactor is not None and self._max_history > 0:
            hard_cap = self._max_history * 4
            if len(history) > hard_cap:
                # Preserve system messages (e.g. an existing compaction summary)
                # so trimming the oldest turns never erases long-term memory the
                # compactor would otherwise keep. Cap only the non-system tail.
                sys_msgs = [m for m in history if m.get("role") == "system"]
                non_sys = [m for m in history if m.get("role") != "system"]
                history = sys_msgs + non_sys[-hard_cap:]
        if compactor is not None:
            try:
                if compactor.needs_compaction(history):
                    compacted, _result = compactor.compact(history)
                    history = compacted
            except Exception as e:  # pragma: no cover — defensive
                logger.warning(
                    "History compaction failed; falling back to truncation: %s", e
                )
                if self._max_history > 0 and len(history) > self._max_history:
                    history = history[-self._max_history:]
        elif self._max_history > 0 and len(history) > self._max_history:
            history = history[-self._max_history:]

        # Always update in-memory cache (keyed by storage key)
        storage_key = self._storage_key(user_id, **route)
        self._histories[storage_key] = history

        if self._store is not None:
            # The in-memory copy now diverges from the store until the write
            # below fully succeeds; drop the flush marker so a concurrent
            # pressure sweep cannot evict this (now sole) current copy.
            self._flushed.discard(storage_key)
            key = self._session_key(user_id, **route)
            try:
                if hasattr(self._store, "set_chat_history"):
                    self._store.set_chat_history(key, history)
                else:
                    self._store.clear_session(key)
                    for msg in history:
                        self._store.add_message(
                            key,
                            msg.get("role", "user"),
                            msg.get("content", ""),
                            msg.get("metadata"),
                        )
            except Exception as e:
                logger.warning("Failed to persist session to store: %s", e)
            else:
                # Store now durably holds this exact history — safe to evict.
                self._flushed.add(storage_key)

    def set_pending_tool_policy(
        self, agent: "Agent", tool_policy: Optional[Any]
    ) -> None:
        """Stage a per-route toolset scope for ``agent``'s next ``chat()`` turn.

        Used by routing handlers (e.g. the gateway's injected Discord/Slack
        ``on_message``) that resolve a :class:`ToolPolicy` but cannot thread it
        through the adapter's own ``_session.chat()`` call (Issue #2298). The
        handler runs synchronously right before that ``chat()`` in the same
        dispatch, so the staged policy is consumed-and-cleared by the very next
        ``chat()`` for the same agent. ``None`` clears any prior staging so a
        trusted route never inherits an earlier untrusted route's scope.
        """
        if agent is None:
            return
        key = id(agent)
        if tool_policy is None:
            self._pending_tool_policies.pop(key, None)
        else:
            self._pending_tool_policies[key] = tool_policy

    def set_profile_namespace(
        self, profile: Optional[str], agent: Optional["Agent"] = None
    ) -> None:
        """Enter (or clear) a per-tenant profile scope for the next turn.

        Used by the gateway's routing handler when a route resolves to a
        ``profile`` (Issue #4341). The handler runs synchronously right before
        the adapter's own ``_session.chat()`` in the same dispatch. The resolved
        namespace is *staged* on the instance (keyed by ``id(agent)`` when an
        agent is given, so a shared session serving multiple agents never
        crosses tenants). ``chat()`` then consumes-and-clears the staged value
        and binds it turn-locally in a per-task ContextVar for the duration of
        that turn — so overlapping routed turns never share a namespace and a
        stale scope never leaks into a later turn. Every ``_storage_key`` for
        the turn is prefixed with ``profile:<name>:`` so two routes multiplexed
        on one process never share a transcript. Passing ``None``/blank clears
        the scope so a route with no profile never inherits another tenant's
        namespace (fail-closed: unscoped routes stay unscoped, never borrowed).
        """
        cleaned = str(profile).strip() if profile is not None else ""
        # Stage on the instance (not a process-wide ContextVar) so a stage never
        # leaks into an unrelated session or a later turn: ``chat()`` consumes
        # this and binds it turn-locally, resetting on exit. Keep both a
        # per-agent slot (so a shared session serving multiple agents never
        # crosses tenants) and a last-staged fallback for agentless callers and
        # direct ``_storage_key`` reads before ``chat()`` runs.
        self._staged_profile_namespace = cleaned or None
        if agent is not None:
            key = id(agent)
            if cleaned:
                self._pending_profile_namespaces[key] = cleaned
            else:
                self._pending_profile_namespaces.pop(key, None)

    @staticmethod
    def _apply_tool_policy(
        agent: "Agent", tool_policy: Optional[Any]
    ) -> Optional[Any]:
        """Scope ``agent.tools`` per ``tool_policy`` for one turn (Issue #2298).

        Returns a zero-arg callable that restores the agent's original tools,
        or ``None`` when no scoping was applied (no policy, no tools, or the
        policy removed nothing). The apply/restore mirrors the scheduler's
        proven ``_apply_toolset_scope`` so attended/trusted uses of the same
        shared agent are never affected.
        """
        if tool_policy is None:
            return None
        filter_tools = getattr(tool_policy, "filter_tools", None)
        if not callable(filter_tools):
            return None
        original = getattr(agent, "tools", None)
        if not original:
            return None
        try:
            filtered = filter_tools(list(original))
        except Exception as e:  # pragma: no cover - defensive
            logger.warning("Tool policy could not scope agent tools: %s", e)
            return None
        if len(filtered) == len(original):
            return None
        try:
            agent.tools = filtered
        except Exception as e:  # pragma: no cover - defensive
            logger.warning("Tool policy could not assign scoped tools: %s", e)
            return None

        removed = len(original) - len(filtered)
        logger.info(
            "Route tool policy scoped agent tools for inbound turn: "
            "%d -> %d (%d removed)",
            len(original),
            len(filtered),
            removed,
        )

        def _restore() -> None:
            try:
                agent.tools = original
            except Exception as e:  # pragma: no cover - defensive
                logger.warning("Tool policy could not restore agent tools: %s", e)

        return _restore

    def _admission_context(self, user_id: str):
        """Return an async context manager admitting one inbound turn.

        Issue #2454: when a gateway-wide admission gate is configured, this
        acquires a global concurrency slot (bounded by ``max_concurrent_runs``)
        with a bounded wait queue, and raises ``AdmissionRejected`` when the
        gateway is at capacity. A no-op pass-through when no gate is set, so
        the legacy dispatch path is preserved exactly.
        """
        gate = self._admission_gate
        if gate is None:
            return _null_async_context()
        return gate.admit(session_id=self._storage_key(user_id))

    async def chat(
        self,
        agent: "Agent",
        user_id: str,
        prompt: str,
        chat_id: str = "",
        thread_id: str = "",
        user_name: str = "",
        message_id: str = "",
        account: str = "",
        stream_callback: Optional[Any] = None,
        tool_policy: Optional[Any] = None,
        correlation_id: str = "",
        attachments: Optional[List[str]] = None,
        received_at: Optional[datetime] = None,
    ) -> str:
        """Run ``agent.chat(prompt)`` with *user_id*-scoped history.

        The call is wrapped in ``run_in_executor`` so the sync LLM
        round-trip never blocks the event loop.

        Uses both a per-user lock (serialise same user) and a per-agent
        lock (prevent concurrent history swaps on a shared Agent).

        Args:
            stream_callback: Optional async callback for streaming events.
                            When provided, events are bridged via agent.stream_emitter.
            tool_policy: Optional per-route toolset scope (Issue #2298). When
                            supplied, the agent's tools are filtered to the
                            policy-allowed subset for the duration of this turn
                            and restored afterwards, so an untrusted inbound
                            route never advertises dangerous tools to the model
                            while attended/trusted uses of the same shared agent
                            stay unaffected. Anything exposing ``filter_tools``
                            is accepted (e.g. ``ToolPolicy`` / ``RunPolicy``).
            attachments: Optional list of local file paths for inbound media
                            (images/documents) sent by the user (Issue #2350).
                            Forwarded to ``agent.chat(prompt, attachments=...)``
                            so the agent's existing vision capability can act on
                            them. Ephemeral per-turn (never persisted to history).

        N4 — Inbound DLQ: if a ``dlq`` was passed to ``__init__`` and
        ``agent.chat()`` raises, the failing message is persisted to
        the dead-letter queue **before** the exception is re-raised.
        This makes the error visible to the caller (so the bot adapter
        can log / show the user a friendly message) while preserving
        the message for later replay.
        
        Ingress Journal: if an ``ingress_journal`` was passed to ``__init__``
        and ``message_id`` is provided, the message is journaled with deduplication
        and claim/complete semantics for crash-safe, exactly-once processing.
        """
        # Consume any per-route toolset scope staged by a routing handler that
        # could not thread it through this call directly (Issue #2298). The
        # staged policy is always popped (so it applies exactly once and never
        # leaks into a later turn — including the dedup early-return below); an
        # explicit ``tool_policy`` argument wins, otherwise the staged one is
        # used. ``None`` here means "no policy resolved" (full toolset), so an
        # absent explicit arg safely inherits a fail-closed staged scope.
        staged_policy = self._pending_tool_policies.pop(id(agent), None)
        if tool_policy is None:
            tool_policy = staged_policy

        # Per-tenant profile scope (Issue #4341): bind the resolved namespace
        # turn-locally for the whole turn so every ``_storage_key`` recomputed
        # after an await point below uses *this* turn's tenant — an overlapping
        # route for another tenant cannot rewrite it. Prefer the value staged by
        # the routing handler for this agent (popped so it applies exactly once);
        # otherwise the last-staged instance fallback (for agentless callers).
        # Reset in the finally so it never leaks into an unrelated later turn
        # sharing this task (fail-closed: unscoped stays unscoped).
        staged_profile = self._pending_profile_namespaces.pop(id(agent), None)
        if staged_profile is None:
            staged_profile = self._staged_profile_namespace
        # Consume the last-staged fallback so it applies to exactly one turn and
        # never silently persists into a later unscoped call (fail-closed).
        self._staged_profile_namespace = None
        profile_token = _ACTIVE_PROFILE_NS.set(staged_profile or None)

        # Mint/adopt an end-to-end correlation id and bind it for this turn so
        # ingress, the agent run, and outbound delivery share one stable id in
        # structured logs. Adopts an explicit correlation_id, else the platform
        # message_id, else a fresh id. No-op import failure is non-fatal.
        cid = None
        cid_token = None
        try:
            from ._correlation import correlation_id_from, set_correlation_id
            cid = correlation_id_from(
                {"correlation_id": correlation_id, "message_id": message_id}
            )
            cid_token = set_correlation_id(cid)
            logger.debug(
                "bot turn start", extra={"correlation_id": cid, "platform": self._platform}
            )
        except Exception:  # pragma: no cover — defensive
            cid = correlation_id or message_id or None

        # Handle ingress journaling for durable message processing
        journal_key = None
        if self._ingress_journal is not None and message_id:
            payload = {
                "user_id": user_id,
                "prompt": prompt,
                "chat_id": chat_id,
                "thread_id": thread_id,
                "user_name": user_name,
                "correlation_id": cid,
            }
            journal_key = self._ingress_journal.receive(
                platform=self._platform or "unknown",
                account=account or "default",
                channel_id=chat_id or user_id,
                message_id=message_id,
                payload=payload
            )
            if journal_key is None:
                # Duplicate message - restore the correlation id before the
                # early return so the contextvar set for this turn never leaks
                # into an unrelated subsequent call sharing the same task.
                if cid_token is not None:
                    try:
                        from ._correlation import reset_correlation_id
                        reset_correlation_id(cid_token)
                    except Exception as e:  # pragma: no cover — defensive
                        logger.debug("Failed to reset correlation id: %s", e)
                # Reset the turn-local profile scope on this early return too so
                # a deduped duplicate never leaves a tenant namespace bound for a
                # later unrelated call sharing this task (Issue #4341).
                try:
                    _ACTIVE_PROFILE_NS.reset(profile_token)
                except Exception as e:  # pragma: no cover — defensive
                    logger.debug("Failed to reset profile namespace: %s", e)
                return ""
                
        # Resolve the routing context once so per_chat scope (Issue #2376)
        # keys the session and locks by the shared chat — not the sender —
        # for group/channel chats, while DMs and per_user stay sender-keyed.
        # ``route`` is empty in per_user mode so every keyed helper behaves
        # exactly as before (full back-compat).
        chat_type = ""
        route: Dict[str, str] = {}
        if self._session_scope == "per_chat":
            try:
                from .delivery import detect_chat_type
                chat_type = detect_chat_type(self._platform, chat_id)
            except Exception:  # pragma: no cover — defensive
                chat_type = ""
            if self._scope_for(chat_type) == "per_chat" and chat_id:
                route = {
                    "account": account,
                    "chat_id": chat_id,
                    "thread_id": thread_id,
                    "chat_type": chat_type,
                }
                # Attribute each turn to its sender so the agent can follow a
                # multi-party thread ("who said what"). Only applied in the
                # shared per_chat session; per_user content is untouched.
                prompt = self._attribute(prompt, user_name or user_id)

        # Temporal grounding (Issue #2834): stamp each inbound turn with its real
        # arrival time so the always-on agent has a clock. Applied to both DM
        # (per_user) and group (per_chat) turns, after any sender attribution so
        # the time sits outermost; de-duplicated on replay. No-op when disabled.
        if self._timestamps:
            prompt = self._with_timestamp(prompt, received_at)

        user_lock = self._get_lock(user_id, **route)
        agent_lock = self._get_agent_lock(agent)

        # W1: set task-local session context so any tool the agent
        # invokes can read platform / chat / user metadata without
        # relying on os.environ globals.
        ctx_token = None
        _clear_ctx = None
        try:
            from praisonaiagents.session.context import (
                set_session_context as _set_ctx,
                clear_session_context as _clear_ctx,
                Origin,
                ReachableTarget,
            )
            
            # Build enriched context if platform awareness is enabled
            origin = None
            reachable_targets = None
            
            if self._inject_session_context:
                # Detect chat type and build origin
                from .delivery import detect_chat_type
                chat_type = detect_chat_type(self._platform, chat_id)
                origin = Origin(
                    platform=self._platform,
                    chat_type=chat_type,
                    display_name=chat_id,  # Use chat_id as display_name since chat_name is not available
                    thread_id=thread_id,
                )
                
                # Get reachable targets from channel directory
                if self._channel_directory:
                    targets_data = self._channel_directory.describe_targets()
                    reachable_targets = [
                        ReachableTarget(
                            name=t['name'],
                            platform=t['platform'],
                            channel_id=t['channel_id'],
                            kind=t['kind'],
                        )
                        for t in targets_data
                    ]
            
            ctx_token = _set_ctx(
                platform=self._platform,
                chat_id=chat_id,
                thread_id=thread_id,
                user_id=user_id,
                user_name=user_name,
                unified_user_id=self._storage_key(user_id),
                origin=origin,
                reachable_targets=reachable_targets,
            )
        except Exception:  # pragma: no cover — defensive
            _clear_ctx = None  # type: ignore[assignment]

        # Issue #2372: register a concrete outbound messenger for this turn so
        # the built-in core ``send_message`` tool can proactively reach the
        # user. Bound to the running gateway's DeliveryRouter and this turn's
        # origin so ``send_message("origin", ...)`` replies on the channel the
        # message came from. Cleared in the finally below so it never leaks
        # into an unrelated turn. No router -> no-op (legacy behaviour).
        messenger_token = None
        _clear_messenger = None
        if self._delivery_router is not None:
            try:
                from ._outbound_messenger import BotOutboundMessenger
                from .delivery import SessionSource
                from praisonaiagents.session.context import (
                    register_outbound_messenger as _register_messenger,
                    clear_outbound_messenger as _clear_messenger,
                )

                origin_source = None
                if self._platform and chat_id:
                    origin_source = SessionSource(
                        platform=self._platform,
                        channel_id=chat_id,
                        user_id=user_id,
                        thread_id=thread_id,
                        message_id=message_id or None,
                    )
                messenger = BotOutboundMessenger(
                    self._delivery_router, origin=origin_source
                )
                messenger_token = _register_messenger(messenger)
            except Exception as e:  # pragma: no cover — defensive
                logger.debug("Failed to register outbound messenger: %s", e)
                _clear_messenger = None  # type: ignore[assignment]

        # Initialize result variable
        result: Optional[str] = None
        claim_ctx = None
        # Issue #2454: admission-gate context for this turn (released in the
        # finally below regardless of outcome). ``None`` when no gate is set.
        _admission_cm = None
        _admission_active = False
        # Issue #3804: mark this session in-flight for the duration of the turn
        # so the memory-pressure sweep never soft-evicts a cache with a live
        # turn executing against it. Set inside the user_lock below, cleared in
        # the outer finally on every exit path.
        _inflight_key: Optional[str] = None

        try:
            # Claim journal entry if we have one
            if journal_key is not None:
                claim_ctx = self._ingress_journal.aclaim(journal_key)
                await claim_ctx.__aenter__()
                
            try:
                # Issue #2454: gateway-wide admission gate in front of the
                # per-user lock. Acquires a global concurrency slot (bounded
                # by ``max_concurrent_runs``) with a bounded wait queue; sheds
                # with a busy ack when the queue is full. A no-op when no gate
                # is configured, so legacy behaviour is preserved exactly.
                _admission_cm = self._admission_context(user_id)
                try:
                    await _admission_cm.__aenter__()
                    _admission_active = True
                except AdmissionRejected as _rej:
                    # Over capacity and the wait queue is full: shed this turn
                    # with a clean, model-readable busy ack rather than starting
                    # an (N+1)th concurrent provider call. Release the journal
                    # claim (if any) so the message can be retried later.
                    _admission_cm = None
                    if claim_ctx is not None:
                        try:
                            await claim_ctx.__aexit__(
                                type(_rej), _rej, _rej.__traceback__
                            )
                        except Exception as e:  # pragma: no cover — defensive
                            logger.debug("Failed to release claim on shed: %s", e)
                    return _rej.message
                # The gate is held for the full turn; released in the outer
                # finally below so a slot is never leaked on any exit path.
                async with user_lock:
                    # Issue #3804: this session now has a live turn; record it so
                    # the pressure sweep skips it (never abort in-flight work).
                    _inflight_key = self._storage_key(user_id, **route)
                    self._in_flight[_inflight_key] = self._in_flight.get(_inflight_key, 0) + 1
                    # Load history (may hit disk via run_in_executor for async safety)
                    loop = asyncio.get_running_loop()
                    # Run in the current context so the turn-local profile scope
                    # (Issue #4341) is visible to ``_storage_key`` on the executor
                    # thread — ``run_in_executor`` does not copy ContextVars, so
                    # without this the history key would drop the tenant prefix.
                    _load_ctx = contextvars.copy_context()
                    user_history = await loop.run_in_executor(
                        None, partial(_load_ctx.run, partial(self._load_history, user_id, **route))
                    )
                    
                    # Update last active timestamp AFTER history load and reset check
                    self._last_active[self._storage_key(user_id, **route)] = time.monotonic()

                    # Fire SESSION_START once per session lifetime (no-op when
                    # no hooks registered).  BEFORE_AGENT / AFTER_AGENT are
                    # emitted by ``agent.chat()`` itself, so we deliberately do
                    # NOT re-fire them here to avoid double-dispatch.
                    self._maybe_fire_session_start(agent, user_id, **route)

                    # W1 robustness: hold ``agent_lock`` across the FULL LLM call
                    # (not only the history swap) so concurrent users on a shared
                    # Agent instance never observe each other's chat_history.
                    async with agent_lock:
                        saved_history = agent.chat_history
                        agent.chat_history = user_history

                        # Per-route toolset scope (Issue #2298): swap the
                        # agent's tools to the policy-allowed subset for this
                        # turn so untrusted inbound routes never advertise
                        # dangerous tools to the model. Restored in the finally
                        # below alongside chat_history/model, so a shared Agent
                        # instance never leaks a scoped toolset to another turn.
                        _restore_tools = self._apply_tool_policy(agent, tool_policy)

                        # Apply a per-user model override (set via the /model
                        # command) for the duration of this turn only. The swap
                        # happens inside the per-agent lock and is restored in
                        # the finally below, so a shared Agent instance never
                        # leaks one user's model to another concurrent user.
                        _model_overridden = False
                        _saved_llm = None
                        _override = self._model_overrides.get(self._storage_key(user_id))
                        if _override is not None and hasattr(agent, "llm"):
                            _saved_llm = agent.llm
                            if _override != _saved_llm:
                                agent.llm = _override
                                _model_overridden = True

                        # Create interrupt controller for this run and register it
                        try:
                            from praisonaiagents.agent.interrupt import InterruptController
                        except ImportError:
                            # Fallback if InterruptController is not available
                            InterruptController = None
                        
                        controller = InterruptController() if InterruptController else None
                        storage_key = self._storage_key(user_id)
                        if controller:
                            self._active_runs[storage_key] = controller
                        # Prompt-cache-stability contract (Issue #3352): now that
                        # the per-turn tool/model swaps are applied, meter whether
                        # this turn's cached prompt prefix drifted from the last
                        # turn so silent provider-cache misses become auditable.
                        self._check_prefix_stability(agent, storage_key)
                        # In-run progress liveness (Issue #2393): mark progress
                        # at run start so a fresh long run is never STUCK on a
                        # stale inbound timestamp; streamed events refresh it
                        # below while the turn executes.
                        self.note_run_progress()

                        bridged_stream_callback = None
                        try:
                            # Choose streaming vs non-streaming path based on callback
                            if stream_callback:
                                # Streaming path: bridge events via stream_emitter because
                                # achat()/astart() do not accept stream_callback directly.
                                emitter = getattr(agent, "stream_emitter", None)
                                if emitter is not None:
                                    def bridged_stream_callback(event):
                                        # In-run progress liveness (Issue #2393):
                                        # every streamed token/draft edit/tool
                                        # event is real progress, so refresh the
                                        # heartbeat to keep the channel BUSY for
                                        # the full duration of a long stream.
                                        self.note_run_progress()
                                        try:
                                            result = stream_callback(event)
                                            if asyncio.iscoroutine(result):
                                                asyncio.get_running_loop().create_task(result)
                                        except Exception as cb_exc:
                                            logger.warning("Stream callback failed: %s", cb_exc)

                                    emitter.add_callback(bridged_stream_callback)

                                astart_kwargs = {"stream": True}
                                if controller:
                                    astart_kwargs["cancel_token"] = controller
                                # Thread inbound media to the agent's vision path
                                # only when astart() accepts it (Issue #2350), so
                                # agents without an attachments param keep working.
                                if attachments:
                                    import inspect as _inspect
                                    try:
                                        _astart_params = _inspect.signature(agent.astart).parameters
                                    except (ValueError, TypeError):
                                        _astart_params = {}
                                    if "attachments" in _astart_params or any(
                                        p.kind == p.VAR_KEYWORD for p in _astart_params.values()
                                    ):
                                        astart_kwargs["attachments"] = attachments

                                try:
                                    response = await asyncio.wait_for(
                                        agent.astart(prompt, **astart_kwargs),
                                        timeout=self._run_timeout if self._run_timeout > 0 else None,
                                    )
                                    if hasattr(response, "output"):
                                        response = response.output
                                except asyncio.TimeoutError:
                                    if controller:
                                        controller.request("run timeout")
                                    raise BotRunTimeout(
                                        f"Agent run timed out after {self._run_timeout}s"
                                    )
                                finally:
                                    if emitter is not None and bridged_stream_callback is not None:
                                        emitter.remove_callback(bridged_stream_callback)
                            else:
                                # Legacy non-streaming path: use agent.chat() in executor with cancel_token and timeout
                                import inspect
                                _ctx = contextvars.copy_context()

                                # In-run progress liveness (Issue #2393): attach a
                                # progress-only callback to the agent's event
                                # emitter so internal tool/token events during a
                                # non-streamed run still refresh the heartbeat,
                                # keeping a long, actively-progressing run BUSY.
                                # A genuinely-hung run emits nothing, leaving the
                                # timestamp frozen so STUCK is still detectable.
                                progress_emitter = getattr(agent, "stream_emitter", None)
                                progress_callback = None
                                if progress_emitter is not None and hasattr(progress_emitter, "add_callback"):
                                    def progress_callback(_event):  # noqa: ANN001
                                        self.note_run_progress()
                                    try:
                                        progress_emitter.add_callback(progress_callback)
                                    except Exception:  # noqa: BLE001 — best-effort liveness
                                        progress_callback = None

                                # Create agent.chat call with cancel_token if supported
                                # Use inspect.signature for safer parameter checking
                                _chat_params = inspect.signature(agent.chat).parameters if hasattr(agent, 'chat') else {}
                                _chat_kwargs = {}
                                if controller and 'cancel_token' in _chat_params:
                                    _chat_kwargs['cancel_token'] = controller
                                # Thread inbound media to the agent's vision path
                                # when the agent supports it (Issue #2350). Honor
                                # wrappers that forward **kwargs to a vision-capable
                                # agent, matching the streaming (astart) path.
                                if attachments and (
                                    'attachments' in _chat_params
                                    or any(
                                        p.kind == p.VAR_KEYWORD
                                        for p in _chat_params.values()
                                    )
                                ):
                                    _chat_kwargs['attachments'] = attachments
                                chat_call = partial(agent.chat, prompt, **_chat_kwargs)
                                
                                # Run with timeout and interruption support
                                try:
                                    response = await asyncio.wait_for(
                                        loop.run_in_executor(None, _ctx.run, chat_call),
                                        timeout=self._run_timeout if self._run_timeout > 0 else None,
                                    )
                                except asyncio.TimeoutError:
                                    if controller:
                                        controller.request("run timeout")
                                    raise BotRunTimeout(f"Agent run timed out after {self._run_timeout}s")
                                finally:
                                    if progress_emitter is not None and progress_callback is not None:
                                        try:
                                            progress_emitter.remove_callback(progress_callback)
                                        except Exception:  # noqa: BLE001 — best-effort cleanup
                                            pass
                            # Capture updated history before restoring caller's.
                            updated_history = agent.chat_history
                        except Exception as exc:
                            # N4: persist the failed inbound message before bubbling.
                            # Skip DLQ for timeout exceptions to prevent infinite retry loops
                            if self._dlq is not None and not isinstance(exc, BotRunTimeout):
                                try:
                                    await loop.run_in_executor(
                                        None,
                                        lambda: self._dlq.enqueue(
                                            platform=self._platform,
                                            user_id=user_id,
                                            prompt=prompt,
                                            error=f"{type(exc).__name__}: {exc}",
                                            chat_id=chat_id,
                                            thread_id=thread_id,
                                            user_name=user_name,
                                        )
                                    )
                                except Exception as dlq_exc:  # pragma: no cover — defensive
                                    logger.error(
                                        "Failed to enqueue inbound DLQ entry: %s", dlq_exc
                                    )
                            agent.chat_history = saved_history
                            raise
                        finally:
                            agent.chat_history = saved_history
                            # Restore the agent's original toolset if a
                            # per-route policy scoped it for this turn.
                            if _restore_tools is not None:
                                _restore_tools()
                            # Restore the agent's original model if we applied a
                            # per-user override for this turn.
                            if _model_overridden:
                                agent.llm = _saved_llm
                            # Clean up active run tracking
                            if controller:
                                self._active_runs.pop(storage_key, None)

                    # Persist outside the agent_lock — it's session-scoped and
                    # the agent is no longer touched. ``route`` keys the shared
                    # per_chat session when active (empty otherwise). Run in the
                    # current context so the turn-local profile scope (Issue
                    # #4341) reaches ``_storage_key`` on the executor thread —
                    # otherwise the save would land in the unscoped key.
                    _save_ctx = contextvars.copy_context()
                    await loop.run_in_executor(
                        None,
                        partial(
                            _save_ctx.run,
                            partial(self._save_history, user_id, updated_history, **route),
                        ),
                    )

                    # Normalise an agent-emitted presentation (if any) into
                    # (text, presentation). Agents/hooks may return a plain str
                    # (unchanged), a MessagePresentation, or an AgentReply. The
                    # portable presentation is captured per-user so channel
                    # adapters can render interactive UI; the text is returned as
                    # before so the str contract and text fallback are preserved.
                    try:
                        from praisonaiagents.bots.agent_reply import (
                            extract_presentation,
                            extract_completion,
                            append_completion_note,
                        )
                        storage_key = self._storage_key(user_id)
                        text, presentation = extract_presentation(response)
                        # Issue #3296: optionally surface *why* the turn ended.
                        # The completion is read from the agent-emitted result
                        # first (AgentReply/dict), falling back to the agent's
                        # own ``last_stop_reason`` so a plain-text turn that
                        # stopped early (max_steps / cancelled / error) still
                        # explains itself. Off by default → no change to clean
                        # completions or existing deployments.
                        if self._surface_completion_reason:
                            completion = extract_completion(response)
                            if completion is None:
                                completion = extract_completion(agent)
                            text = append_completion_note(
                                text, completion, enabled=True
                            )
                        # Always normalise to plain text so chat() never leaks a
                        # non-str (e.g. AgentReply) past its str contract.
                        response = text
                        if presentation is not None:
                            self._last_presentation[storage_key] = presentation
                        else:
                            # Clear any stale UI from an earlier turn so a later
                            # plain-text turn cannot reuse it via run-control.
                            self._last_presentation.pop(storage_key, None)
                    except Exception as e:  # pragma: no cover — defensive
                        logger.debug("presentation extraction skipped: %s", e)

                    # Store response to return after cleanup
                    result = response
                    
            except Exception as e:
                # Handle any remaining exceptions and ensure claim is released 
                if claim_ctx is not None:
                    await claim_ctx.__aexit__(type(e), e, e.__traceback__)
                raise
            else:
                # Clean exit - mark journal complete before releasing claim
                if journal_key is not None and self._ingress_journal is not None:
                    try:
                        self._ingress_journal.complete(journal_key)
                        self._last_journal_key = None
                    except Exception as e:
                        logger.warning("Failed to complete journal entry: %s", e)
                if claim_ctx is not None:
                    await claim_ctx.__aexit__(None, None, None)
                return result or ""
        finally:
            # Issue #3804: clear this turn's in-flight mark so the pressure
            # sweep can once again consider this cache for eviction. Guarded by
            # ``_inflight_key`` so a turn shed before the lock never underflows.
            if _inflight_key is not None:
                _n = self._in_flight.get(_inflight_key, 0) - 1
                if _n > 0:
                    self._in_flight[_inflight_key] = _n
                else:
                    self._in_flight.pop(_inflight_key, None)
            # Issue #2454: release the admission slot for this turn (frees a
            # global concurrency slot and lets a queued waiter proceed). Done
            # first so capacity is returned promptly on every exit path.
            if _admission_active and _admission_cm is not None:
                try:
                    await _admission_cm.__aexit__(None, None, None)
                except Exception as e:  # pragma: no cover — defensive
                    logger.debug("Failed to release admission slot: %s", e)
            # Always clear task-local session context, even if an exception occurred.
            if ctx_token is not None and _clear_ctx is not None:
                try:
                    _clear_ctx(ctx_token)
                except Exception as e:
                    logger.debug("Failed to clear task-local session context for ctx_token=%r: %s", ctx_token, e)
            # Issue #2372: clear the per-turn outbound messenger so it never
            # leaks into an unrelated subsequent call sharing the same task.
            if messenger_token is not None and _clear_messenger is not None:
                try:
                    _clear_messenger(messenger_token)
                except Exception as e:  # pragma: no cover — defensive
                    logger.debug("Failed to clear outbound messenger: %s", e)
            # Restore the previous correlation id so the contextvar never leaks
            # the id of this turn into an unrelated subsequent call.
            if cid_token is not None:
                try:
                    from ._correlation import reset_correlation_id
                    reset_correlation_id(cid_token)
                except Exception as e:  # pragma: no cover — defensive
                    logger.debug("Failed to reset correlation id: %s", e)
            # Reset the turn-local profile scope so this turn's tenant namespace
            # never leaks into an unrelated later call sharing this task, and a
            # subsequent unscoped route always fails closed (Issue #4341).
            try:
                _ACTIVE_PROFILE_NS.reset(profile_token)
            except Exception as e:  # pragma: no cover — defensive
                logger.debug("Failed to reset profile namespace: %s", e)

    async def chat_with_run_control(
        self,
        agent: "Agent",
        user_id: str,
        prompt: str,
        chat_id: str = "",
        thread_id: str = "",
        user_name: str = "",
        received_at: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """Run agent.chat() with run control for better UX during long operations.
        
        This method integrates with SessionRunControl to provide:
        - Busy acknowledgment for mid-run messages
        - Pending message slot for follow-ups
        - Interrupt support via /stop command
        - Optional steering for real-time guidance
        
        Returns:
            Dict with 'response' (str) and 'metadata' (dict) keys.
            Metadata includes run control information.
        """
        if self._run_control is None:
            # Fall back to regular chat if no run control
            response = await self.chat(
                agent, user_id, prompt, chat_id, thread_id, user_name,
                received_at=received_at,
            )
            return {"response": response, "metadata": {"run_control": False}}
        
        try:
            # Import here to avoid circular dependency
            from ._run_control import RunDecision
        except ImportError:
            # Fall back if run control not available
            response = await self.chat(
                agent, user_id, prompt, chat_id, thread_id, user_name,
                received_at=received_at,
            )
            return {"response": response, "metadata": {"run_control": False, "error": "run_control_unavailable"}}
        
        # Submit message to run control
        decision = await self._run_control.submit(user_id, prompt)
        
        if decision == RunDecision.STEERED:
            # Message was injected into the live run via steering; the running
            # turn folds in the new guidance without a separate response here.
            ack_msg = await self._run_control.get_busy_ack_message(user_id, decision)
            return {
                "response": ack_msg,
                "metadata": {
                    "run_control": True,
                    "decision": decision.value,
                    "steered": True,
                }
            }

        if decision in (RunDecision.QUEUED, RunDecision.MERGED):
            # Message was queued or merged, return acknowledgment
            ack_msg = await self._run_control.get_busy_ack_message(user_id, decision)
            return {
                "response": ack_msg,
                "metadata": {
                    "run_control": True,
                    "decision": decision.value,
                    "queued": True
                }
            }

        # We're running now (RUN_NOW or INTERRUPTED)
        current_prompt = prompt
        # Only the original turn carries the platform's true arrival time; pending
        # follow-ups picked up below are later messages, so they fall back to now().
        current_received_at = received_at
        last_response = ""
        last_decision = decision
        pending_processed: List[str] = []

        while True:
            run_generation = None
            interrupt_controller = None

            if last_decision in (RunDecision.RUN_NOW, RunDecision.INTERRUPTED):
                # Register the live agent for each fresh run so that mid-run
                # STEER messages can be injected into it. finish_run() clears the
                # handle after every turn, so re-register on each pending iteration
                # too (otherwise STEER silently falls back to QUEUE after the
                # first run).
                if hasattr(self._run_control, "register_agent"):
                    try:
                        self._run_control.register_agent(user_id, agent)
                    except Exception:  # noqa: BLE001 - registration is best-effort
                        logger.debug("Failed to register agent for steering", exc_info=True)

                interrupt_controller = self._run_control.get_interrupt_controller(user_id)

            status = self._run_control.get_run_status(user_id)
            run_generation = status.get("run_generation")

            try:
                original_interrupt = None
                if interrupt_controller and hasattr(agent, 'interrupt_controller'):
                    original_interrupt = getattr(agent, 'interrupt_controller', None)
                    agent.interrupt_controller = interrupt_controller

                last_response = await self.chat(
                    agent, user_id, current_prompt, chat_id, thread_id, user_name,
                    received_at=current_received_at,
                )

            except Exception as e:
                if interrupt_controller and interrupt_controller.is_set():
                    reason = interrupt_controller.reason or "unknown"
                    return {
                        "response": f"⚠️ Task cancelled: {reason}",
                        "metadata": {
                            "run_control": True,
                            "decision": last_decision.value,
                            "interrupted": True,
                            "reason": reason,
                            "run_generation": run_generation,
                        },
                    }
                raise

            finally:
                if interrupt_controller and hasattr(agent, 'interrupt_controller'):
                    if original_interrupt is not None:
                        agent.interrupt_controller = original_interrupt
                    else:
                        agent.interrupt_controller = None

                if run_generation is not None:
                    await self._run_control.finish_run(user_id, run_generation)

            pending = self._run_control.next_pending(user_id)
            if not pending:
                break

            pending_processed.append(
                pending[:100] + "..." if len(pending) > 100 else pending
            )
            current_prompt = pending
            # A pending follow-up is a distinct, later message — drop the original
            # arrival time so it is stamped with its own (now()) receive time.
            current_received_at = None
            last_decision = await self._run_control.submit(user_id, pending)

        metadata: Dict[str, Any] = {
            "run_control": True,
            "decision": decision.value,
            "completed": True,
            "run_generation": run_generation,
        }
        if pending_processed:
            metadata["pending_processed"] = pending_processed

        # Surface any agent-emitted presentation captured during the run(s) so
        # run-control callers can render interactive UI alongside the text reply.
        presentation = self.pop_last_presentation(user_id)
        if presentation is not None:
            metadata["presentation"] = presentation

        return {"response": last_response, "metadata": metadata}

    def reap_stale(self, max_age_seconds: int) -> int:
        """Remove sessions older than *max_age_seconds*.  Returns count reaped.

        Call this periodically or lazily (e.g. on each chat() call) to
        auto-clean inactive sessions and free memory.
        """
        if max_age_seconds <= 0:
            return 0
        now = time.monotonic()
        stale = [
            uid for uid, ts in self._last_active.items()
            if (now - ts) > max_age_seconds
        ]
        for storage_key in stale:
            # End the session so lifecycle hooks fire and can re-open later.
            self._fire_session_end(storage_key, reason="stale")
            self._histories.pop(storage_key, None)
            # Drop the prompt-prefix baseline so a reopened session establishes
            # a fresh one instead of emitting a false invalidation (Issue #3352).
            self._prefix_sig.pop(storage_key, None)
            self._last_active.pop(storage_key, None)
            self._flushed.discard(storage_key)
            self._locks.drop(storage_key)
            if self._store is not None:
                key = self._persist_key(storage_key)
                try:
                    self._store.clear_session(key)
                except Exception as e:
                    logger.warning("Failed to reap session %s: %s", key, e)
        if stale:
            logger.debug("BotSessionManager: reaped %d stale sessions", len(stale))
        return len(stale)

    def warm_sessions(self) -> "List[WarmSession]":
        """Snapshot the warm per-session caches as :class:`WarmSession` facts.

        Issue #3804: carries just enough state for the pure core planner
        (:func:`praisonaiagents.gateway.plan_pressure_evictions`) to name the
        coldest *rebuildable* caches to soft-evict under memory pressure:

        * ``last_activity`` — the LRU key (coldest evicted first).
        * ``in_flight`` — a turn is executing against the cache (never evict).
        * ``flushed`` — the transcript is durably persisted and therefore
          rebuildable. Only true when a persistent ``store`` is configured *and*
          this session's last write completed (tracked per key in
          ``_flushed``). Without a store, or after a failed/partial persist,
          the in-memory copy is the only current one, so it is treated as
          unflushed and never evicted (evicting it would lose data).
        """
        from praisonaiagents.gateway import WarmSession  # lazy, core contract

        has_store = self._store is not None
        return [
            WarmSession(
                session_id=key,
                last_activity=self._last_active.get(key, 0.0),
                in_flight=self._in_flight.get(key, 0) > 0,
                flushed=has_store and key in self._flushed,
            )
            for key in list(self._histories.keys())
        ]

    def _soft_evict(self, storage_key: str) -> bool:
        """Drop only the *in-memory* history for *storage_key* (no store touch).

        The durable copy in the session store is left intact, so the next turn
        transparently reloads the transcript — soft eviction is a lossless,
        self-healing pressure valve, not a session teardown. Unlike
        ``reap_stale`` it does NOT fire ``SESSION_END`` or clear the store.
        Returns ``True`` if an in-memory cache was actually dropped.
        """
        if storage_key not in self._histories:
            return False
        self._histories.pop(storage_key, None)
        # Reset the prompt-prefix baseline so the reloaded session starts a
        # fresh baseline rather than firing a false invalidation (Issue #3352).
        self._prefix_sig.pop(storage_key, None)
        # The in-memory copy is gone; its flush marker no longer applies (the
        # next load re-establishes state from the store).
        self._flushed.discard(storage_key)
        return True

    def sweep_under_pressure(
        self,
        memory_pressure: "MemoryPressureProtocol",
        headroom: float = 0.9,
    ) -> int:
        """Soft-evict the coldest rebuildable caches under memory pressure.

        Issue #3804: the runtime enactor for the core planner. Reads the real
        container budget/RSS from *memory_pressure* (a
        :class:`praisonaiagents.gateway.MemoryPressureProtocol`), asks
        :func:`plan_pressure_evictions` which caches to shed, and drops their
        in-memory history LRU-first — re-sampling RSS as it goes so it stops as
        soon as RSS is back within ``headroom`` of the budget (avoiding
        over-shedding). In-flight and unflushed caches are never touched.

        A no-op (returns ``0``) when the platform cannot report a budget, so a
        host without a cgroup limit keeps today's behaviour exactly. Call it on
        the gateway's existing periodic tick, alongside ``reap_stale``.
        """
        from praisonaiagents.gateway import plan_pressure_evictions  # lazy

        try:
            budget = memory_pressure.cgroup_limit_mb()
            rss = memory_pressure.anon_rss_mb()
        except Exception as e:  # pragma: no cover — defensive
            logger.debug("Memory-pressure probe failed; skipping sweep: %s", e)
            return 0

        plan = plan_pressure_evictions(
            budget, rss, self.warm_sessions(), headroom_ratio=headroom
        )
        if not plan:
            return 0

        try:
            target = float(budget) * float(headroom)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            target = 0.0

        evicted = 0
        for storage_key in plan:
            # Re-check in-flight at enact time: a turn may have started against
            # this cache after the plan was computed. Never abort live work.
            if self._in_flight.get(storage_key, 0) > 0:
                continue
            if self._soft_evict(storage_key):
                evicted += 1
                # Re-sample and stop once back within budget so we shed the
                # minimum number of caches (planner returns all, coldest-first).
                try:
                    if memory_pressure.anon_rss_mb() <= target:
                        break
                except Exception:  # pragma: no cover — defensive
                    break
        if evicted:
            logger.info(
                "BotSessionManager: soft-evicted %d cold session cache(s) "
                "under memory pressure", evicted
            )
        return evicted

    def complete_last_journal_entry(self) -> bool:
        """Complete the last journal entry if one exists.
        
        Call this after successfully delivering a message to the platform
        to ensure the journal entry is marked as completed.
        
        Returns True if an entry was completed, False if no entry was pending.
        """
        if self._last_journal_key is not None and self._ingress_journal is not None:
            try:
                self._ingress_journal.complete(self._last_journal_key)
                self._last_journal_key = None
                return True
            except Exception as e:
                logger.warning("Failed to complete journal entry: %s", e)
        return False

    def _should_reset_session(self, storage_key: str) -> bool:
        """Check if a session should be reset based on the policy.
        
        Args:
            storage_key: The storage key for the user
            
        Returns:
            True if session should be reset
        """
        if self._reset_policy.mode == "none":
            return False
        
        # Get timestamps
        now = time.monotonic()
        last_activity = self._last_active.get(storage_key, now)
        last_reset = self._last_reset.get(storage_key, 0)
        
        # If this is a new session, initialize timestamps but don't reset
        if storage_key not in self._last_reset:
            self._last_reset[storage_key] = now
            if storage_key not in self._last_active:
                self._last_active[storage_key] = now
                return False
        
        return self._reset_policy.should_reset(
            last_activity=last_activity,
            last_reset=last_reset,
            now=now,
            current_datetime=datetime.now()
        )
    
    def _clear_session_data(self, storage_key: str, persist_key: str) -> None:
        """Clear session data for a session.

        Args:
            storage_key: The in-memory storage key for the session
            persist_key: The persistent-store key for the session (already
                derived via ``_session_key``/``_persist_key`` so per_chat
                scope clears the shared key, not a re-derived per_user one).
        """
        self._histories.pop(storage_key, None)
        # Reset the prompt-prefix baseline with the history so the next turn on
        # this key starts a fresh baseline rather than comparing against the
        # cleared session and firing a false invalidation (Issue #3352).
        self._prefix_sig.pop(storage_key, None)
        # Don't clear last_active as we still need it for idle tracking
        # Don't drop lock here as it may still be held by caller
        
        if self._store is not None:
            try:
                self._store.clear_session(persist_key)
            except Exception as e:
                logger.warning("Failed to clear session in store: %s", e)
    
    def pop_last_presentation(self, user_id: str) -> Optional[Any]:
        """Return and clear the last agent-emitted presentation for *user_id*.

        Channel adapters call this immediately after ``chat()`` to check whether
        the agent attached interactive UI to its reply. Returns the portable
        ``MessagePresentation`` (which the adapter renders via the per-channel
        renderer) or ``None`` when the reply was plain text. Consuming clears it
        so a later text-only turn never re-renders stale buttons.
        """
        return self._last_presentation.pop(self._storage_key(user_id), None)

    def record_passive(
        self,
        user_id: str,
        content: str,
        sender: str = "",
        **route: str,
    ) -> bool:
        """Append a group message as passive context without running the agent.

        Issue #3380: under the ``observe`` group policy a message that does not
        address the bot is recorded into the session transcript as an ordinary
        ``user`` turn (optionally attributed to its sender for multi-party
        chats) so that when the bot is next mentioned it can see the preceding
        conversation. No agent run is dispatched. Appends directly under a
        per-key threading lock so it is safe to call from any sync/async
        context (including inline on the inbound handler's own loop thread);
        errors are swallowed.

        Optional ``chat_id``/``thread_id``/``account``/``chat_type`` route kwargs
        are threaded through so that with ``session_scope='per_chat'`` the
        passive entry lands on the same shared group key that a subsequent
        addressed turn reads from (Issue #2376 routing); without them behaviour
        is unchanged (per_user, keyed by the sender's session).
        """
        if not content:
            return False
        text = self._attribute(content, sender) if sender else content
        entry = {
            "role": "user",
            "content": text,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "passive": True,
        }
        # A single fire-and-forget append. Unlike the outbound mirror (called
        # from other threads / cron), ``record_passive`` runs inline on the
        # inbound handler's own event-loop thread, so the cross-thread
        # ``run_coroutine_threadsafe`` bridge would dead-lock waiting on the
        # very loop that is calling it. Append directly under a per-key
        # threading lock (no asyncio lock touched) so it is safe from any
        # context and never blocks the loop.
        try:
            storage_key = self._storage_key(user_id, **route)
            sync_locks = getattr(self, "_user_sync_locks", None)
            if sync_locks is None:
                self._user_sync_locks = sync_locks = {}
            lock = sync_locks.get(storage_key)
            if lock is None:
                import threading
                lock = sync_locks[storage_key] = threading.Lock()
            with lock:
                history = list(self._load_history(user_id, **route))
                history.append(entry)
                self._save_history(user_id, history, **route)
                self._last_active[storage_key] = time.monotonic()
            return True
        except Exception as e:  # pragma: no cover — defensive, never break inbound
            logger.warning("record_passive failed: %s", e)
            return False

    def reset(self, user_id: str, **route: str) -> bool:
        """Clear a session's history.  Returns True if it existed.

        Accepts optional ``chat_id``/``thread_id``/``chat_type`` so a ``/new``
        command issued in a group/channel clears the shared per_chat session
        (Issue #2376); without them behaviour is unchanged (per_user).
        """
        storage_key = self._storage_key(user_id, **route)
        existed = storage_key in self._histories
        
        self._clear_session_data(storage_key, self._persist_key(storage_key))
        self._last_active.pop(storage_key, None)
        self._last_reset[storage_key] = time.monotonic()
        # Clear any per-user model override (set via /model) so a "start fresh"
        # actually remedies a bad/unavailable model instead of every later turn
        # silently failing at the provider (Issue #4318). Overrides are keyed by
        # the per-user storage key (no route), exactly as /model and chat() key
        # them, so a group /new still clears the issuing user's override.
        self._model_overrides.pop(self._storage_key(user_id), None)

        # Fire SESSION_END lifecycle hook (no-op when no hooks registered),
        # then forget the session so a subsequent message re-opens it.
        self._fire_session_end(storage_key, reason="clear")

        return existed

    def cancel_run(self, user_id: str, reason: str = "user_cancel") -> bool:
        """Cancel an active run for a user.
        
        Args:
            user_id: Raw platform user id
            reason: Reason for cancellation
            
        Returns:
            bool: True if there was an active run to cancel, False otherwise
        """
        storage_key = self._storage_key(user_id)
        controller = self._active_runs.get(storage_key)
        if controller:
            controller.request(reason)
            return True
        return False

    def get_active_runs(self) -> List[str]:
        """Get list of user IDs with active runs."""
        return list(self._active_runs.keys())

    def note_run_progress(self) -> None:
        """Record in-run progress for channel-health liveness (Issue #2393).

        Called when a run makes real progress (run start, a streamed
        token/draft edit bridged through ``stream_callback``, or a tool event)
        so the health monitor can tell an actively-progressing long run from a
        genuinely-hung one. Best-effort and side-effect-free beyond the
        timestamp; never raises.
        """
        self._last_run_progress = time.time()

    def last_run_progress(self) -> Optional[float]:
        """Return the most recent in-run progress timestamp (or ``None``).

        Read by the bot adapter's health builder so the evaluator's busy branch
        can use ``max(last_activity, last_run_progress)`` — keeping a streaming
        or tool-calling run BUSY rather than mistaking its wall-clock for a
        stuck socket.
        """
        return self._last_run_progress

    def _add_mirror_entry_sync(self, user_id: str, entry: dict) -> bool:
        """Thread-safe method to add a mirror entry to user's history.
        
        This method coordinates with the asyncio locks used by chat() 
        to prevent race conditions. Called by mirror_to_session().
        
        Args:
            user_id: Raw platform user id
            entry: Mirror entry dict to append to history
            
        Returns:
            bool: True on success, False on failure
        """
        import asyncio
        
        def _sync_add_entry():
            # Get the event loop that owns the asyncio locks
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # No event loop running - we need to use threading synchronization
                # This happens when called from sync contexts like cron jobs
                storage_key = self._storage_key(user_id)
                self._last_active[storage_key] = time.monotonic()
                
                # Create a temporary threading lock for this user to prevent concurrent
                # access to the same user's history from multiple sync threads
                import threading
                user_sync_lock = getattr(self, '_user_sync_locks', None)
                if user_sync_lock is None:
                    self._user_sync_locks = {}
                    user_sync_lock = self._user_sync_locks
                
                if storage_key not in user_sync_lock:
                    user_sync_lock[storage_key] = threading.Lock()
                
                with user_sync_lock[storage_key]:
                    history = list(self._load_history(user_id))
                    history.append(entry)
                    self._save_history(user_id, history)
                return True
                
            # There's an event loop - we need to coordinate with asyncio locks
            # This is more complex but necessary for thread safety
            future = asyncio.run_coroutine_threadsafe(
                self._add_mirror_entry_async(user_id, entry), loop
            )
            return future.result(timeout=10.0)  # 10 second timeout
        
        try:
            return _sync_add_entry()
        except Exception as e:
            logger.warning("_add_mirror_entry_sync failed: %s", e)
            return False
    
    async def _add_mirror_entry_async(self, user_id: str, entry: dict) -> bool:
        """Async helper for _add_mirror_entry_sync."""
        try:
            storage_key = self._storage_key(user_id) 
            self._last_active[storage_key] = time.monotonic()
            
            # Use the same per-user lock that chat() uses
            user_lock = self._get_lock(user_id)
            async with user_lock:
                # Load history (may hit disk via run_in_executor for async safety)
                loop = asyncio.get_running_loop()
                history = await loop.run_in_executor(
                    None, self._load_history, user_id
                )
                history = list(history)  # Ensure it's mutable
                history.append(entry)
                
                # Save updated history
                await loop.run_in_executor(
                    None, self._save_history, user_id, history
                )
            return True
        except Exception as e:
            logger.warning("_add_mirror_entry_async failed: %s", e)
            return False

    def reset_all(self) -> int:
        """Clear all user sessions.  Returns the count cleared."""
        count = len(self._histories)

        # End every open session so lifecycle hooks fire and can re-open later.
        for storage_key in list(self._seen_sessions):
            self._fire_session_end(storage_key, reason="clear_all")

        if self._store is not None:
            for storage_key in list(self._histories.keys()):
                key = self._persist_key(storage_key)
                try:
                    self._store.clear_session(key)
                except Exception as e:
                    logger.warning("Failed to clear session %s: %s", key, e)

        self._histories.clear()
        # Clear prompt-prefix baselines alongside history so reopened sessions
        # each establish a fresh baseline (Issue #3352).
        self._prefix_sig.clear()
        # Clear per-user model overrides too so a global reset actually starts
        # every user fresh on the agent's configured model (Issue #4318).
        self._model_overrides.clear()
        return count

    @property
    def active_sessions(self) -> int:
        """Number of users with stored history."""
        return len(self._histories)

    def get_user_ids(self) -> List[str]:
        """List user IDs with active sessions."""
        return list(self._histories.keys())


def resolve_durable_store_dir(platform: str = ""):
    """Resolve the canonical per-platform SQLite store directory for durability.

    Returns ``~/.praisonai/state/<platform>/`` (created if missing), where the
    inbound journal, inbound DLQ and outbound queue databases for a given
    platform live so all durable components share one canonical store instead of
    three ad-hoc file paths. ``PRAISONAI_HOME`` overrides the base directory when
    set.

    The store is scoped by ``platform`` so that bots on different platforms
    (telegram, discord, slack, ...) running under the same ``PRAISONAI_HOME`` do
    not share a journal/DLQ. This prevents one platform's DLQ replay from
    consuming another platform's failed inbound events and avoids dedup-tuple
    collisions across platforms.
    """
    from pathlib import Path
    import os as _os
    import re as _re

    base = _os.environ.get("PRAISONAI_HOME")
    root = Path(base).expanduser() if base else Path.home() / ".praisonai"
    store_dir = root / "state"
    # Scope by platform so each adapter gets an isolated journal + DLQ.
    safe_platform = _re.sub(r"[^A-Za-z0-9_.-]", "_", platform).strip("_") if platform else ""
    if safe_platform:
        store_dir = store_dir / safe_platform
    store_dir.mkdir(parents=True, exist_ok=True)
    return store_dir


def _build_durable_components(config, platform: str):
    """Default-construct the inbound journal + DLQ for durable delivery.

    Durability is on by default for gateway/bot runs. Reads an optional
    ``delivery`` config block (``durable`` flag + ``store`` override); when
    durability is enabled, builds an :class:`InboundJournal` (dedup + crash
    replay) and an :class:`InboundDLQ` (failed-inbound replay) against one
    canonical per-agent SQLite store. Returns ``(ingress_journal, dlq)``;
    either may be ``None`` if durability is disabled or construction fails
    (in which case the manager safely falls back to in-memory behaviour).
    """
    delivery = getattr(config, "delivery", None) if config is not None else None
    # Default ON: durability is the safe default unless explicitly disabled.
    durable = True if delivery is None else getattr(delivery, "durable", True)
    if not durable:
        return None, None

    try:
        from pathlib import Path
        store_override = getattr(delivery, "store", None) if delivery is not None else None
        if store_override:
            store_dir = Path(store_override).expanduser()
            # Allow either a directory or an explicit file path. When a file is
            # given, place sibling DBs next to it so all components share a dir.
            if store_dir.suffix:
                store_dir = store_dir.parent
            store_dir.mkdir(parents=True, exist_ok=True)
        else:
            store_dir = resolve_durable_store_dir(platform)

        from ._ingress import InboundJournal
        from ._dlq import InboundDLQ

        ingress_journal = InboundJournal(path=str(store_dir / "ingress.sqlite"))
        dlq = InboundDLQ(path=str(store_dir / "inbound_dlq.sqlite"))
        logger.info(
            "Durable delivery enabled for %s (store=%s)",
            platform or "bot",
            store_dir,
        )
        return ingress_journal, dlq
    except Exception as exc:  # pragma: no cover — defensive
        logger.warning(
            "Durable delivery requested but could not be initialised; "
            "falling back to in-memory delivery: %s",
            exc,
        )
        return None, None


def build_session_manager(config, platform: str, *, run_control=None) -> BotSessionManager:
    """Build a BotSessionManager with standard configuration from a BotConfig.
    
    This helper extracts the common session manager setup logic that's duplicated
    across all bot adapters, including:
    - Session store acquisition
    - Reset policy extraction
    - Backward-compatible max_history resolution
    - Durable inbound delivery (journal + DLQ) wired by default
    
    Args:
        config: BotConfig instance with session configuration
        platform: Platform identifier (e.g., "telegram", "slack")
        run_control: Optional run control for Telegram (keyword-only)
    
    Returns:
        Configured BotSessionManager instance
    """
    # Try to get the default session store. Sessions are durable by default;
    # a genuine store-init failure is recorded as a durability-degraded fact
    # (Issue #4339) — surfaced by ``gateway doctor`` / ``gateway status`` — not
    # just logged, so an operator is told their bot is now running non-durably.
    try:
        from praisonaiagents.session import get_default_session_store
    except ImportError:
        # Module not available, fallback to in-memory
        store = None
    else:
        try:
            store = get_default_session_store()
        except Exception as exc:
            # Raw exception (which may embed a filesystem path) stays in the log
            # only; the operator-facing reason is redacted so health() and
            # ``gateway status`` never echo backend paths (#4339).
            logger.warning(
                "Default session store unavailable; falling back to in-memory store: %s",
                exc,
            )
            record_durability_degraded(
                "session",
                reason="session store unavailable (running in-memory)",
            )
            store = None
        else:
            # Store came up (or was restored): clear any prior degraded fact so
            # a recovered gateway no longer reports non-durable sessions.
            clear_durability_degraded("session")
    
    # Extract reset policy from config
    reset_policy = None
    if getattr(config, "session", None) and getattr(config.session, "reset", None):
        reset_policy = SessionResetPolicy.from_dict(config.session.reset.model_dump())

    # Extract optional history compaction config (disabled unless configured)
    compaction = None
    if getattr(config, "session", None) and getattr(config.session, "compaction", None):
        compaction = config.session.compaction

    # Extract group/channel session scope + attribution (Issue #2376).
    # Defaults preserve per_user isolation when unset.
    session_scope = "per_user"
    attribution = "[{sender}] "
    # Temporal grounding (Issue #2834): off by default for prompt-cache stability.
    timestamps = False
    timestamp_template = "[%a %Y-%m-%d %H:%M %Z] "
    if getattr(config, "session", None):
        session_scope = getattr(config.session, "session_scope", None) or session_scope
        _attr = getattr(config.session, "attribution", None)
        if _attr is not None:
            attribution = _attr
        timestamps = bool(getattr(config.session, "timestamps", False))
        _tmpl = getattr(config.session, "timestamp_template", None)
        if _tmpl:
            timestamp_template = _tmpl
    
    # Support backward compatibility with max_history at channel level
    max_history = 100
    if getattr(config, "max_history", None) is not None:
        max_history = config.max_history
    elif getattr(config, "session", None) and getattr(config.session, "max_history", None) is not None:
        max_history = config.session.max_history
    
    # Durable inbound delivery (on by default for gateway/bot runs): wire a
    # deduplicating inbound journal and an inbound DLQ against one canonical
    # per-agent SQLite store so a crash mid-turn or a platform webhook
    # redelivery never silently loses or double-processes a message.
    ingress_journal, dlq = _build_durable_components(config, platform)

    return BotSessionManager(
        max_history=max_history,
        store=store,
        platform=platform,
        reset_policy=reset_policy,
        run_control=run_control,
        compaction=compaction,
        ingress_journal=ingress_journal,
        dlq=dlq,
        session_scope=session_scope,
        attribution=attribution,
        timestamps=timestamps,
        timestamp_template=timestamp_template,
    )
