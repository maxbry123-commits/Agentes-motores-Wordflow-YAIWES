"""
Unified and durable message delivery for PraisonAI bots.

Provides both unified delivery with platform capabilities (streaming, chunking,
rate limiting) and durable delivery with persistence and retry logic.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Optional, Union, Dict, Any, List, Awaitable, Callable, Protocol

if TYPE_CHECKING:
    from praisonaiagents.bots import BotProtocol, PlatformCapabilities

from ._chunk import chunk_message, _calculate_length
from ._streaming import DraftStreamer, StreamingConfig, StreamingMode
from ._rate_limit import RateLimiter
from ._resilience import (
    BackoffPolicy,
    compute_backoff,
    is_recoverable_error,
    server_retry_after,
    sleep_with_abort,
)

logger = logging.getLogger(__name__)

# Constant for permanent error detection
PERMANENT_ERROR_PREFIX = "Permanent error:"

# Prefix prepended to a crash-recovered outbound message that is re-sent without
# positive reconciliation. Such a re-send may be a duplicate, so the copy the
# recipient receives is labelled honestly rather than delivered silently.
RECOVERED_PREFIX = (
    "\u267b\ufe0f Recovered reply \u2014 the gateway restarted during "
    "delivery, so this may be a duplicate.\n\n"
)


def _annotate_recovered_payload(entry: Any, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Prefix a recovered entry's textual content with ``RECOVERED_PREFIX``.

    Only string ``content`` is labelled; non-text payloads are returned
    unchanged so a media/structured send is never corrupted. Returns a new dict
    so the persisted payload is untouched.
    """
    content = payload.get("content")
    if not isinstance(content, str) or content.startswith(RECOVERED_PREFIX):
        return payload
    annotated = dict(payload)
    annotated["content"] = f"{RECOVERED_PREFIX}{content}"
    return annotated


class _TransientDeliveryError(Exception):
    """Recoverable delivery failure carrying the underlying error text.

    Raised by the durable drain sender so the outbox persists the real error
    (and any server Retry-After hint embedded in it) instead of a generic
    "Delivery returned false". Always classified recoverable so the entry is
    retried rather than marked a permanent failure.
    """


class MessageSender(Protocol):
    """Protocol for message sending implementations."""
    
    async def send_message(
        self,
        channel_id: str,
        content: Union[str, Dict[str, Any]],
        **kwargs
    ) -> Any:
        """Send a message to a channel."""
        ...


class UnifiedDelivery:
    """Unified message delivery that adapts to platform capabilities.
    
    This class demonstrates how platform capabilities enable uniform
    feature delivery across all bot adapters.
    """
    
    def __init__(self, bot: "BotProtocol"):
        """Initialize with a bot instance.
        
        Args:
            bot: Bot adapter implementing BotProtocol
        """
        self.bot = bot
        self._capabilities: Optional["PlatformCapabilities"] = None
        self._rate_limiter: Optional[RateLimiter] = None
        self._streamer: Optional[DraftStreamer] = None
        self._background_tasks: set[asyncio.Task] = set()
    
    @property
    def capabilities(self) -> "PlatformCapabilities":
        """Get platform capabilities (cached)."""
        if self._capabilities is None:
            # Use platform_capabilities property from the updated protocol
            self._capabilities = self.bot.platform_capabilities
        return self._capabilities
    
    async def send_message(
        self,
        channel_id: str,
        content: Union[str, Dict[str, Any]],
        stream: bool = False,
        typing: bool = True,
        **kwargs,
    ) -> List[Any]:
        """Send a message with platform-aware features.
        
        Args:
            channel_id: Target channel ID
            content: Message content
            stream: Whether to use streaming if supported
            typing: Whether to show typing indicator
            **kwargs: Additional platform-specific arguments
            
        Returns:
            List of sent messages (may be multiple due to chunking)
        """
        caps = self.capabilities
        text = content if isinstance(content, str) else str(content)
        
        # Show typing indicator if supported
        if typing and caps.supports_typing:
            task = asyncio.create_task(self._show_typing(channel_id))
            self._background_tasks.add(task)
            task.add_done_callback(self._background_tasks.discard)
        
        # Check if we should stream
        if stream and caps.supports_edit and _calculate_length(text, caps.length_unit) > caps.max_message_length // 2:
            # Use streaming for long messages on platforms that support edits
            return await self._send_streamed(channel_id, text, **kwargs)
        
        # Chunk the message based on platform limits
        chunks = chunk_message(
            text,
            max_length=caps.max_message_length,
            length_unit=caps.length_unit,
            preserve_fences=True,
        )
        
        # Send each chunk
        messages = []
        for chunk in chunks:
            # Apply rate limiting per chunk
            if caps.needs_rate_limit:
                await self._acquire_rate_limit(channel_id)
            
            msg = await self.bot.send_message(channel_id, chunk, **kwargs)
            messages.append(msg)
        
        return messages
    
    async def _send_streamed(
        self,
        channel_id: str,
        text: str,
        **kwargs,
    ) -> List[Any]:
        """Send a message using streaming/progressive edits.
        
        Args:
            channel_id: Target channel ID
            text: Full message text
            **kwargs: Additional arguments
            
        Returns:
            List containing the final message
        """
        caps = self.capabilities
        
        if self._streamer is None:
            config = StreamingConfig(
                mode=StreamingMode.DRAFT,
                min_interval=caps.edit_interval_ms / 1000.0,
                min_delta=50,
            )
            self._streamer = DraftStreamer(self.bot, config)
        
        # Send initial placeholder
        message = await self.bot.send_message(
            channel_id,
            "🤔 Thinking...",
            **kwargs,
        )
        messages = [message]  # Initialize messages list for returning
        
        # Progressively update with content using proper length calculation
        chunk_size = min(100, caps.max_message_length // 10)
        current_pos = 0
        
        # Stream partial content
        streaming_completed = False
        while current_pos < len(text):
            # Calculate next position based on platform's length unit
            next_pos = current_pos + chunk_size
            if next_pos > len(text):
                next_pos = len(text)
            
            partial = text[:next_pos]
            
            # Check if partial exceeds platform limit
            if _calculate_length(partial, caps.length_unit) > caps.max_message_length:
                # Back off to find safe length
                while next_pos > current_pos and _calculate_length(text[:next_pos], caps.length_unit) > caps.max_message_length:
                    next_pos -= 10
                if next_pos <= current_pos:
                    break  # Can't fit more content
                partial = text[:next_pos]
            
            # Respect edit interval
            await asyncio.sleep(caps.edit_interval_ms / 1000.0)
            
            # Apply rate limiting for edits
            if caps.needs_rate_limit:
                await self._acquire_rate_limit(channel_id)
            
            # Add ellipsis if not complete
            display_text = partial if next_pos >= len(text) else partial + "..."
            
            await self.bot.edit_message(
                channel_id,
                message.message_id,
                display_text,
            )
            
            if next_pos >= len(text):
                streaming_completed = True
                break  # Complete text has been sent
            
            current_pos = next_pos
        
        # If text is too long and couldn't fit in one message, chunk it
        if _calculate_length(text, caps.length_unit) > caps.max_message_length:
            # Final content needs chunking
            chunks = chunk_message(
                text,
                max_length=caps.max_message_length,
                length_unit=caps.length_unit,
                preserve_fences=True,
            )
            
            # Edit first message with first chunk
            await asyncio.sleep(caps.edit_interval_ms / 1000.0)
            if caps.needs_rate_limit:
                await self._acquire_rate_limit(channel_id)
            
            await self.bot.edit_message(
                channel_id,
                message.message_id,
                chunks[0],
            )
            
            # Send remaining chunks as new messages
            for chunk in chunks[1:]:
                if caps.needs_rate_limit:
                    await self._acquire_rate_limit(channel_id)
                msg = await self.bot.send_message(channel_id, chunk)
                messages.append(msg)
        elif not streaming_completed:
            # Final edit with complete content (fits in limit and wasn't already sent)
            await asyncio.sleep(caps.edit_interval_ms / 1000.0)
            if caps.needs_rate_limit:
                await self._acquire_rate_limit(channel_id)
            
            await self.bot.edit_message(
                channel_id,
                message.message_id,
                text,
            )
        
        return messages
    
    async def _show_typing(self, channel_id: str) -> None:
        """Show typing indicator for a few seconds.
        
        Args:
            channel_id: Target channel ID
        """
        try:
            for _ in range(3):  # Show for ~3 seconds
                await self.bot.send_typing(channel_id)
                await asyncio.sleep(1)
        except Exception as e:
            logger.debug("Could not show typing indicator: %s", e)
    
    async def _acquire_rate_limit(self, channel_id: Optional[str] = None) -> None:
        """Acquire rate limit token if platform needs it.
        
        Args:
            channel_id: Optional channel ID for per-channel limiting
        """
        if self._rate_limiter is None:
            # Use platform-specific rate limiter
            self._rate_limiter = RateLimiter.for_platform(self.bot.platform)
        
        if self._rate_limiter:
            await self._rate_limiter.acquire(channel_id)


def create_delivery(bot: "BotProtocol") -> UnifiedDelivery:
    """Create a unified delivery instance for a bot.
    
    Args:
        bot: Bot adapter
        
    Returns:
        UnifiedDelivery instance configured for the bot's platform
    """
    return UnifiedDelivery(bot)


async def deliver_with_retry(
    adapter: MessageSender,
    channel_id: str,
    content: Union[str, Dict[str, Any]],
    *,
    backoff: Optional[BackoffPolicy] = None,
    max_attempts: int = 3,
    abort_signal: Optional[asyncio.Event] = None,
    platform: str = "",
    rate_limiter: Optional[RateLimiter] = None,
    **send_kwargs
) -> tuple[bool, Optional[str]]:
    """Attempt delivery with bounded exponential backoff retry.
    
    Args:
        adapter: The adapter to send through
        channel_id: Target channel ID
        content: Message content to send
        backoff: Backoff policy for retries
        max_attempts: Maximum delivery attempts
        abort_signal: Optional event to cancel retries
        platform: Platform name for error classification
        rate_limiter: Optional limiter to penalise after a server throttle
            signal so subsequent sends to the channel hold off.
        **send_kwargs: Additional kwargs for send_message
        
    Returns:
        Tuple of (success, error_message)
        - (True, None) on successful delivery
        - (False, error_msg) on permanent failure
        - (False, error_msg) on transient failure after max attempts
    """
    backoff = backoff or BackoffPolicy()
    last_error = None
    
    for attempt in range(1, max_attempts + 1):
        try:
            # Attempt delivery
            await adapter.send_message(channel_id, content, **send_kwargs)
            
            # Success!
            if attempt > 1:
                logger.info(
                    f"[{platform}] Delivery succeeded after {attempt} attempts "
                    f"to channel {channel_id}"
                )
            
            return True, None
            
        except Exception as e:
            last_error = str(e)
            
            # Check if error is permanent
            if not is_recoverable_error(e, platform):
                logger.error(
                    f"[{platform}] Permanent delivery failure to {channel_id}: {e}"
                )
                return False, f"{PERMANENT_ERROR_PREFIX} {last_error}"
            
            # Check if we're out of attempts
            if attempt >= max_attempts:
                logger.warning(
                    f"[{platform}] Delivery failed after {attempt} attempts "
                    f"to {channel_id}: {e}"
                )
                return False, f"Max attempts exceeded: {last_error}"
            
            # Honour a server-mandated wait (Telegram retry_after, HTTP
            # Retry-After) over the generic backoff estimate.
            mandated = server_retry_after(e)
            delay = mandated if mandated is not None else compute_backoff(backoff, attempt)
            
            # Widen this channel's lane so the next send does not immediately
            # re-trip the platform limit. Only penalise on a server-mandated
            # wait — a generic backoff after an ordinary transient error must
            # not synthetically throttle later sends to this channel.
            if mandated is not None and rate_limiter is not None and delay > 0:
                try:
                    await rate_limiter.penalise(channel_id, delay)
                except Exception:
                    pass
            
            hint = " (server Retry-After)" if mandated is not None else ""
            logger.warning(
                f"[{platform}] Delivery attempt {attempt} failed to {channel_id}: "
                f"{e}; retrying in {delay:.1f}s{hint}"
            )
            
            # Sleep with abort capability
            if not await sleep_with_abort(delay, abort_signal):
                logger.info(f"[{platform}] Delivery retry aborted by signal")
                return False, "Aborted by signal"
    
    # Should never reach here, but for safety
    return False, last_error


async def deliver_chunked(
    adapter: MessageSender,
    channel_id: str,
    content: str,
    *,
    max_length: int = 4096,
    preserve_fences: bool = True,
    **send_kwargs
) -> int:
    """Deliver a long message in chunks.
    
    Args:
        adapter: The adapter to send through
        channel_id: Target channel ID  
        content: Message content to send
        max_length: Maximum length per chunk
        preserve_fences: Whether to preserve code fence boundaries
        **send_kwargs: Additional kwargs for send_message
        
    Returns:
        Number of chunks sent
    """
    if len(content) <= max_length:
        await adapter.send_message(channel_id, content, **send_kwargs)
        return 1
    
    chunks = chunk_message(content, max_length=max_length, preserve_fences=preserve_fences)
    
    for i, chunk in enumerate(chunks):
        # Only apply reply_to to first chunk
        chunk_kwargs = send_kwargs.copy()
        if i > 0 and 'reply_to' in chunk_kwargs:
            chunk_kwargs.pop('reply_to')
        
        await adapter.send_message(channel_id, chunk, **chunk_kwargs)
    
    return len(chunks)


class DurableDelivery:
    """Helper for durable message delivery with outbound queue integration.
    
    Example::
    
        from praisonai_bot.bots import OutboundQueue, DurableDelivery, TelegramAdapter
        
        outbox = OutboundQueue(path="~/.praisonai/state/outbox.sqlite")
        adapter = TelegramAdapter(token="...")
        delivery = DurableDelivery(outbox, adapter, platform="telegram")
        
        # Send with durability
        success = await delivery.send(
            channel_id="12345",
            content="Hello, world!",
            idempotency_key="msg-123"
        )
        
        # On startup, drain pending
        await delivery.drain_pending()
    """
    
    def __init__(
        self,
        outbox: Optional[Any] = None,  # OutboundQueue
        adapter: Optional[MessageSender] = None,
        *,
        platform: str = "",
        backoff: Optional[BackoffPolicy] = None,
        max_attempts: int = 3,
        mark_recovered: bool = False,
    ):
        self.outbox = outbox
        self.adapter = adapter
        self.platform = platform
        self.backoff = backoff or BackoffPolicy()
        self.max_attempts = max_attempts
        # When True, a crash-recovered entry re-sent without positive
        # reconciliation is labelled as a possible duplicate (honest
        # at-least-once) rather than re-delivered silently. Off by default to
        # preserve the historic behaviour.
        self.mark_recovered = mark_recovered
    
    async def send(
        self,
        channel_id: str,
        content: Union[str, Dict[str, Any]],
        *,
        idempotency_key: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **send_kwargs
    ) -> bool:
        """Send a message with optional durability.
        
        If outbox is configured, the message is persisted before sending
        and marked as sent only on success. On failure, it remains in the
        queue for later retry via drain_pending().
        
        Args:
            channel_id: Target channel ID
            content: Message content
            idempotency_key: Optional key for deduplication
            metadata: Optional metadata for tracking
            **send_kwargs: Additional kwargs for send_message
            
        Returns:
            True if sent successfully, False otherwise
        """
        if not self.adapter:
            raise RuntimeError("No adapter configured")
        
        # If no outbox, just send directly with retry
        if not self.outbox:
            success, _ = await deliver_with_retry(
                self.adapter,
                channel_id,
                content,
                backoff=self.backoff,
                max_attempts=self.max_attempts,
                platform=self.platform,
                **send_kwargs
            )
            return success
        
        # With outbox: persist first, then deliver
        if not idempotency_key:
            import uuid
            idempotency_key = str(uuid.uuid4())
        
        # Prepare payload. Carry the idempotency key inside the payload so a
        # crash-recovered re-send can embed it in the platform message (letting
        # a reconciling adapter later confirm the send via was_delivered).
        payload = {
            "content": content,
            "kwargs": send_kwargs,
            "idempotency_key": idempotency_key,
        }
        
        # Enqueue
        target = f"{self.platform}:{channel_id}" if self.platform else channel_id
        key = await self.outbox.enqueue(
            idempotency_key=idempotency_key,
            target=target,
            payload=payload,
            metadata=metadata,
        )
        
        # Forward the idempotency key on the FIRST send too (not just the
        # crash-recovered drain), so a crash between a successful send and
        # mark_sent() can be reconciled instead of blindly re-sent as a
        # duplicate. Only adapters that accept the param are stamped; others
        # stay backward-compatible.
        first_send_kwargs = dict(send_kwargs)
        if self._send_accepts_idempotency_key():
            first_send_kwargs.setdefault("idempotency_key", idempotency_key)

        # Attempt delivery
        success, error = await deliver_with_retry(
            self.adapter,
            channel_id,
            content,
            backoff=self.backoff,
            max_attempts=self.max_attempts,
            platform=self.platform,
            **first_send_kwargs
        )
        
        # Update status
        if success:
            await self.outbox.mark_sent(key)
        else:
            # Check if permanent error
            permanent = error and error.startswith(PERMANENT_ERROR_PREFIX)
            await self.outbox.mark_failed(key, error or "Unknown error", permanent=permanent)
        
        return success
    
    def _send_accepts_idempotency_key(self) -> bool:
        """Whether the adapter's ``send_message`` accepts an idempotency key.

        Only adapters that can embed the key in the platform message (so a
        later ``was_delivered`` can confirm the send) expose the parameter;
        adapters with a fixed signature must not be passed the extra kwarg.
        """
        send = getattr(self.adapter, "send_message", None)
        if send is None:
            return False
        import inspect

        try:
            params = inspect.signature(send).parameters
        except (TypeError, ValueError):  # pragma: no cover — builtins/edge cases
            return False
        # Require an explicit ``idempotency_key`` parameter. A ``**kwargs``
        # fallback would silently forward the key to any generic adapter that
        # relays kwargs to its platform SDK, which most SDKs reject. Adapters
        # opt in by declaring the parameter explicitly.
        return "idempotency_key" in params

    def _build_reconciler(self) -> Optional[Callable[[Any], Awaitable[bool]]]:
        """Build a reconciler for the outbox drain, if the adapter supports it.

        Returns an async callable that confirms whether a recovered (mid-send
        crash) entry was already delivered, enabling effectively-once delivery.
        Returns None when the adapter cannot reconcile, in which case drain
        falls back to at-least-once re-send.

        An adapter opts in by declaring
        ``PlatformCapabilities.reconciles_unknown_send`` and exposing an async
        ``was_delivered(target, idempotency_key) -> bool`` method (a legacy
        single-argument ``was_delivered(idempotency_key)`` is still accepted).
        """
        adapter = self.adapter
        if adapter is None:
            return None

        caps = getattr(adapter, "platform_capabilities", None)
        if caps is None or not getattr(caps, "reconciles_unknown_send", False):
            return None

        was_delivered = getattr(adapter, "was_delivered", None)
        if not callable(was_delivered):
            return None

        # An adapter needs the target channel to query the platform for the
        # delivery state, so pass it when ``was_delivered`` accepts it. Fall
        # back to the legacy single-argument form for older adapters. If the
        # adapter also accepts a ``thread_id`` it is passed so threaded sends
        # (invisible to a channel-history scan) can be reconciled too.
        import inspect
        import json

        try:
            params = inspect.signature(was_delivered).parameters
        except (TypeError, ValueError):  # pragma: no cover — builtins/edge cases
            params = {}
        wants_target = len(params) >= 2
        wants_thread = "thread_id" in params or any(
            p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
        )

        def _thread_id_of(entry: Any) -> Optional[str]:
            payload = getattr(entry, "payload", None)
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except (ValueError, TypeError):
                    return None
            if not isinstance(payload, dict):
                return None
            kwargs = payload.get("kwargs") or {}
            return kwargs.get("thread_id") if isinstance(kwargs, dict) else None

        async def reconciler(entry: Any) -> bool:
            if not wants_target:
                return bool(await was_delivered(entry.idempotency_key))
            if wants_thread:
                return bool(
                    await was_delivered(
                        entry.target,
                        entry.idempotency_key,
                        thread_id=_thread_id_of(entry),
                    )
                )
            return bool(await was_delivered(entry.target, entry.idempotency_key))

        return reconciler

    async def drain_pending(self, limit: Optional[int] = None) -> tuple[int, int]:
        """Process pending messages from the outbox.
        
        Called on startup to retry messages that failed to send.
        
        Recovered entries (those that were in-flight when the process last
        crashed) are reconciled before re-dispatch when the adapter declares
        ``reconciles_unknown_send`` and exposes ``was_delivered`` — this avoids
        sending the same channel message twice (effectively-once). Otherwise
        delivery remains at-least-once.
        
        Args:
            limit: Optional max messages to process
            
        Returns:
            Tuple of (succeeded, failed) counts
        """
        if not self.outbox:
            return 0, 0
        
        if not self.adapter:
            raise RuntimeError("No adapter configured")
        
        async def sender(target: str, payload: Dict[str, Any]) -> bool:
            """Delivery function for outbox.drain()"""
            # Extract channel_id from target
            if ":" in target:
                _, channel_id = target.split(":", 1)
            else:
                channel_id = target
            
            # Extract content and kwargs
            content = payload.get("content", "")
            send_kwargs = dict(payload.get("kwargs", {}))

            # Forward the idempotency key to adapters whose send_message can
            # embed it in the platform message, so a later was_delivered() can
            # confirm this (re-)send landed (effectively-once). Adapters with a
            # fixed signature are left untouched to stay backward-compatible.
            idempotency_key = payload.get("idempotency_key")
            if idempotency_key and self._send_accepts_idempotency_key():
                send_kwargs.setdefault("idempotency_key", idempotency_key)

            # Attempt delivery with retry
            success, error = await deliver_with_retry(
                self.adapter,
                channel_id,
                content,
                backoff=self.backoff,
                max_attempts=1,  # Single attempt per drain cycle
                platform=self.platform,
                **send_kwargs
            )
            
            # Preserve permanent failure information
            if not success and error and error.startswith(PERMANENT_ERROR_PREFIX):
                raise RuntimeError(error)
            
            # Surface a transient failure (with its underlying error text) so the
            # outbox records it and its retry gate can honour any server
            # Retry-After hint carried in that text. Returning False would store
            # a generic "Delivery returned false" and lose the hint.
            if not success and error:
                raise _TransientDeliveryError(error)
            
            return success
        
        annotator = _annotate_recovered_payload if self.mark_recovered else None
        return await self.outbox.drain(
            sender,
            limit=limit,
            reconciler=self._build_reconciler(),
            recovery_annotator=annotator,
        )


__all__ = [
    "UnifiedDelivery",
    "create_delivery",
    "MessageSender",
    "deliver_with_retry", 
    "deliver_chunked",
    "DurableDelivery",
]