from typing import Any
from colorama import Fore, Style

from gpt_researcher.utils.workers import WorkerPool
from ..scraper import Scraper
from ..config.config import Config
from ..utils.logger import get_formatted_logger

logger = get_formatted_logger()


async def scrape_urls(
    urls, cfg: Config, worker_pool: WorkerPool
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """
    Scrapes the urls
    Args:
        urls: List of urls
        cfg: Config (optional)

    Returns:
        tuple[list[dict[str, Any]], list[dict[str, Any]]]: tuple containing scraped content and images

    """
    scraped_data = []
    images = []
    user_agent = (
        cfg.user_agent
        if cfg
        else "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    )

    scraper = None
    try:
        scraper = Scraper(urls, user_agent, cfg.scraper, worker_pool=worker_pool)
        scraped_data = await scraper.run()
        for item in scraped_data:
            if not isinstance(item, dict):
                continue
            image_urls = item.get("image_urls")
            if image_urls:
                images.extend(image_urls)
    except Exception as e:
        print(f"{Fore.RED}Error in scrape_urls: {e}{Style.RESET_ALL}")
    finally:
        # Close the requests.Session so its underlying connection pool (and the
        # sockets it keeps alive) is released
        if scraper is not None and getattr(scraper, "session", None) is not None:
            scraper.session.close()

    return scraped_data, images


async def filter_urls(urls: list[str], config: Config) -> list[str]:
    """
    Filter URLs based on configuration settings.

    Args:
        urls (list[str]): List of URLs to filter.
        config (Config): Configuration object.

    Returns:
        list[str]: Filtered list of URLs.
    """
    filtered_urls = []
    excluded = getattr(config, "excluded_domains", None) or []
    if not isinstance(excluded, (list, tuple, set)):
        excluded = []
    for url in urls or []:
        # URLs must be non-empty strings; null/int noise TypeErrors the
        # substring check on excluded domains.
        if not isinstance(url, str) or not url:
            continue
        if not any(isinstance(ex, str) and ex and ex in url for ex in excluded):
            filtered_urls.append(url)
    return filtered_urls

async def extract_main_content(html_content: str) -> str:
    """
    Extract the main content from HTML.

    Args:
        html_content (str): Raw HTML content.

    Returns:
        str: Extracted main content.
    """
    # Implement content extraction logic here
    # This could involve using libraries like BeautifulSoup or custom parsing logic
    # For now, we'll just return the raw HTML as a placeholder
    return html_content

async def process_scraped_data(scraped_data: list[dict[str, Any]], config: Config) -> list[dict[str, Any]]:
    """
    Process the scraped data to extract and clean the main content.

    Args:
        scraped_data (list[dict[str, Any]]): List of dictionaries containing scraped data.
        config (Config): Configuration object.

    Returns:
        list[dict[str, Any]]: Processed scraped data.
    """
    processed_data = []
    for item in scraped_data:
        if not isinstance(item, dict):
            continue
        # Partial scraper payloads historically used strict key access and
        # crashed mid-batch; skip/or re-emit guards keep the rest of the run.
        status = item.get("status")
        if status == "success":
            main_content = await extract_main_content(item.get("content") or "")
            processed_data.append({
                "url": item.get("url") or "",
                "content": main_content,
                "status": "success",
            })
        else:
            processed_data.append(item)
    return processed_data
