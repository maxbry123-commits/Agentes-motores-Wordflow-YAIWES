package history

import (
	"context"
	"fmt"
	"time"

	enumsspb "go.temporal.io/server/api/enums/v1"
	healthspb "go.temporal.io/server/api/health/v1"
	"go.temporal.io/server/api/historyservice/v1"
	healthcheck "go.temporal.io/server/common/health"
	"go.temporal.io/server/common/metrics"
	"go.temporal.io/server/common/persistence"
	"go.temporal.io/server/common/rpc/interceptor"
	"go.temporal.io/server/service/history/configs"
	"google.golang.org/grpc/health"
	grpchealthspb "google.golang.org/grpc/health/grpc_health_v1"
)

type deepHealthCheckHandler struct {
	healthServer            *health.Server
	metricsHandler          metrics.Handler
	config                  *configs.Config
	historyHealthSignal     interceptor.HealthSignalAggregator
	persistenceHealthSignal persistence.HealthSignalAggregator
	startupTime             time.Time
}

// DeepHealthCheck implements the grpc API from
// ./proto/internal/temporal/server/api/historyservice/v1/request_response.proto
func (h *deepHealthCheckHandler) DeepHealthCheck(
	ctx context.Context, now time.Time,
) (*historyservice.DeepHealthCheckResponse, error) {
	var checks []*healthspb.HealthCheck

	status, err := h.healthServer.Check(ctx, &grpchealthspb.HealthCheckRequest{Service: serviceName})
	if err != nil || status == nil {
		metrics.HistoryHostHealthGauge.With(h.metricsHandler).Record(float64(enumsspb.HEALTH_STATE_NOT_SERVING))
		return &historyservice.DeepHealthCheckResponse{
			State: enumsspb.HEALTH_STATE_NOT_SERVING,
			Checks: []*healthspb.HealthCheck{{
				CheckType: healthcheck.CheckTypeGRPCHealth,
				State:     enumsspb.HEALTH_STATE_NOT_SERVING,
				Message:   fmt.Sprintf("gRPC health check failed: %v", err),
			}},
		}, nil
	}

	checks = append(checks, &healthspb.HealthCheck{
		CheckType: healthcheck.CheckTypeGRPCHealth,
		// Convert to SERVING to avoid false positives during initialization
		State:   suppressStartupErrors(status.Status, now.Sub(h.startupTime), h.config.HealthHistoryInitializationTime()),
		Message: fmt.Sprintf("historyservice gRPC health check: %s", status.Status.String()),
	})

	// TODO: Remove AverageLatency check once Latency is used by default.
	checks = append(checks, errorIfOverThreshold(healthcheck.CheckTypeRPCLatency,
		h.historyHealthSignal.AverageLatency(), h.config.HealthRPCLatencyFailure(),
		"historyservice latency", true))

	for _, settings := range h.config.HealthRPCLatencyPercentiles().PercentileSettings {
		latency, found := h.historyHealthSignal.LatencyQuantile(settings.Percentile)
		if !found {
			continue
		}

		checks = append(checks, errorIfOverThreshold(
			healthcheck.CheckTypeRPCLatency+fmt.Sprintf("_P%0.2f", 100.0*settings.Percentile),
			latency,
			float64(settings.Threshold.Milliseconds()),
			fmt.Sprintf("historyservice percentile latency (P%0.2f < %d, enforced: %t)", 100.0*settings.Percentile, settings.Threshold.Milliseconds(), settings.Enforced),
			settings.Enforced,
		))
	}

	errRatio, found := h.historyHealthSignal.ErrorRatio()
	if found {
		checks = append(checks, errorIfOverThreshold(
			healthcheck.CheckTypeRPCErrorRatio,
			errRatio,
			h.config.HealthRPCErrorRatio(),
			"historyservice error ratio",
			true, // enforced
		))
	}

	// //////////////////
	// overall latency
	// //////////////////

	healthCheckSettings := h.config.HealthCheckHistoryGRPCSettings()

	for _, qt := range healthCheckSettings.Overall.QuantileThresholds {
		latency, found := h.historyHealthSignal.LatencyQuantile(qt.Quantile)
		if !found {
			continue
		}

		checks = append(checks, errorIfOverThreshold(
			healthcheck.CheckTypeRPCLatencyOverall+fmt.Sprintf("_P%0.2f", 100.0*qt.Quantile),
			latency,
			float64(qt.Threshold.Milliseconds()),
			fmt.Sprintf("history service overall percentile latency (P%0.2f < %dms, enforced: %t)", 100.0*qt.Quantile, qt.Threshold.Milliseconds(), healthCheckSettings.Overall.Enforced),
			healthCheckSettings.Overall.Enforced,
		))
	}

	// //////////////////
	// overall error ratio
	// //////////////////

	if healthCheckSettings.Overall.ErrorRatioThreshold != nil {
		errorRatio, found := h.historyHealthSignal.ErrorRatio()
		if found {
			checks = append(checks, errorIfOverThreshold(
				healthcheck.CheckTypeRPCErrorRatioOverall,
				errorRatio,
				healthCheckSettings.Overall.ErrorRatioThreshold.Threshold,
				fmt.Sprintf("history service overall error ratio (< %0.2f, enforced: %t)", healthCheckSettings.Overall.ErrorRatioThreshold.Threshold, healthCheckSettings.Overall.Enforced),
				healthCheckSettings.Overall.Enforced,
			))
		}
	}

	// //////////////////
	// groups
	// //////////////////

	for _, group := range healthCheckSettings.Groups {
		for _, qt := range group.Thresholds.QuantileThresholds {
			latency, found := h.historyHealthSignal.LatencyQuantileByGroup(group.Name, qt.Quantile)
			if !found {
				continue
			}

			checks = append(checks, errorIfOverThreshold(
				fmt.Sprintf("%s_%s_P%0.2f", healthcheck.CheckTypeRPCLatencyGroup, group.Name, 100.0*qt.Quantile),
				latency,
				float64(qt.Threshold.Milliseconds()),
				fmt.Sprintf("history service %s group percentile latency (P%0.2f < %dms, enforced: %t)", group.Name, 100.0*qt.Quantile, qt.Threshold.Milliseconds(), group.Thresholds.Enforced),
				group.Thresholds.Enforced,
			))
		}

		if group.Thresholds.ErrorRatioThreshold != nil {
			errorRatio, found := h.historyHealthSignal.ErrorRatioByGroup(group.Name)
			if found {
				checks = append(checks, errorIfOverThreshold(
					fmt.Sprintf("%s_%s", healthcheck.CheckTypeRPCErrorRatioGroup, group.Name),
					errorRatio,
					group.Thresholds.ErrorRatioThreshold.Threshold,
					fmt.Sprintf("history service %s group error ratio (< %0.2f, enforced: %t)", group.Name, group.Thresholds.ErrorRatioThreshold.Threshold, group.Thresholds.Enforced),
					group.Thresholds.Enforced,
				))
			}
		}
	}

	// TODO: Remove AverageLatency check once Latency is used by default.
	checks = append(checks, errorIfOverThreshold(healthcheck.CheckTypePersistenceLatency,
		h.persistenceHealthSignal.AverageLatency(), h.config.HealthPersistenceLatencyFailure(),
		"persistenceservice latency", true))

	for _, settings := range h.config.HealthPersistenceLatencyPercentiles().PercentileSettings {
		checks = append(checks, errorIfOverThreshold(
			healthcheck.CheckTypePersistenceLatency+fmt.Sprintf("_P%0.2f", 100.0*settings.Percentile),
			h.persistenceHealthSignal.LatencyQuantile(settings.Percentile),
			float64(settings.Threshold.Milliseconds()),
			fmt.Sprintf("persistenceservice percentile latency (P%0.2f < %d, enforced: %t)", 100.0*settings.Percentile, settings.Threshold.Milliseconds(), settings.Enforced),
			settings.Enforced,
		))
	}

	checks = append(checks, errorIfOverThreshold(healthcheck.CheckTypePersistenceErrRatio,
		h.persistenceHealthSignal.ErrorRatio(), h.config.HealthPersistenceErrorRatio(),
		"persistenceservice error ratio", true))

	overallState := enumsspb.HEALTH_STATE_SERVING

	for _, check := range checks {
		if check.State == enumsspb.HEALTH_STATE_NOT_SERVING {
			overallState = check.State
			break
		}
	}

	metrics.HistoryHostHealthGauge.With(h.metricsHandler).Record(float64(overallState))

	return &historyservice.DeepHealthCheckResponse{
		State:  overallState,
		Checks: checks,
	}, nil
}

func suppressStartupErrors(status grpchealthspb.HealthCheckResponse_ServingStatus,
	dur time.Duration, threshold time.Duration,
) enumsspb.HealthState {
	if dur < threshold {
		return enumsspb.HEALTH_STATE_SERVING
	}
	return toLocalHealthProto(status)
}

func errorIfOverThreshold(checkType string, value float64, threshold float64, message string, enforced bool) *healthspb.HealthCheck {
	state := enumsspb.HEALTH_STATE_SERVING
	if value > threshold && enforced {
		state = enumsspb.HEALTH_STATE_NOT_SERVING
	}
	return &healthspb.HealthCheck{
		CheckType: checkType,
		State:     state,
		Value:     value,
		Threshold: threshold,
		Message:   message,
	}
}

func toLocalHealthProto(in grpchealthspb.HealthCheckResponse_ServingStatus) enumsspb.HealthState {
	switch in {
	case grpchealthspb.HealthCheckResponse_SERVING:
		return enumsspb.HEALTH_STATE_SERVING
	case grpchealthspb.HealthCheckResponse_NOT_SERVING:
		return enumsspb.HEALTH_STATE_NOT_SERVING
	default:
		return enumsspb.HEALTH_STATE_UNSPECIFIED
	}
}
