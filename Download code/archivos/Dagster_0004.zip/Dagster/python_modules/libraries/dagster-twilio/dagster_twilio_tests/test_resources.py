import os

import pytest
from dagster import op
from dagster._utils.test import wrap_op_in_graph_and_execute
from dagster_twilio import TwilioResource, twilio_resource
from twilio.base.exceptions import TwilioRestException


@pytest.fixture(name="twilio_resource_option", params=[True, False])
def twilio_resource_option_fixture(request):
    if request.param:
        return twilio_resource
    else:
        return TwilioResource.configure_at_launch()


@pytest.mark.integration
def test_twilio_resource(twilio_resource_option) -> None:
    account_sid = os.environ.get("TWILIO_TEST_ACCOUNT_SID")
    auth_token = os.environ.get("TWILIO_TEST_AUTH_TOKEN")

    if not account_sid or not auth_token:
        pytest.skip("Missing TWILIO_TEST_ACCOUNT_SID or TWILIO_TEST_AUTH_TOKEN")

    @op
    def twilio_op(twilio_resource: TwilioResource):
        # These tests are against the live SMS APIs using test creds/numbers; see
        # https://www.twilio.com/docs/iam/test-credentials#test-sms-messages

        twilio = twilio_resource.create_client()
        twilio.messages.create(body="test message", from_="+15005550006", to="+15005550006")

        # Should fail because the "to" number is not a valid test number
        with pytest.raises(TwilioRestException):
            twilio.messages.create(body="test message", from_="+15005550006", to="+15005550001")

    result = wrap_op_in_graph_and_execute(
        twilio_op,
        resources={
            "twilio_resource": TwilioResource(account_sid=account_sid, auth_token=auth_token)
        },
    )
    assert result.success
