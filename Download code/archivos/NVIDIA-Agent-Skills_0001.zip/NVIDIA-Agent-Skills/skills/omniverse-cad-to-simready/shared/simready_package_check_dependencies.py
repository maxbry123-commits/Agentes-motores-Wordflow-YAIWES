#!/usr/bin/env python3
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from script_utils import check_result as _check, emit_json_report

from preflight_manifest import preflight_required, preflight_status_check


def _skill_name() -> str:
    return Path(sys.argv[0]).resolve().parents[1].name


def _write_report(payload: dict[str, Any], report_path: Path | None) -> None:
    emit_json_report(payload, report_path)


def check_dependencies() -> dict[str, Any]:
    skill = _skill_name()
    if preflight_required():
        preflight_check = preflight_status_check(skill, "openusd_python")
        if not preflight_check["passed"]:
            return {
                "skill": skill,
                "passed": False,
                "checks": [preflight_check],
                "errors": [preflight_check["message"]],
            }
    checks = [
        _check("python_available", True, f"Python executable: {sys.executable}", "info"),
    ]
    try:
        from pxr import Sdf, Usd  # noqa: F401
    except Exception as exc:
        checks.append(_check("openusd_python_available", False, f"OpenUSD Python modules are unavailable: {exc}"))
    else:
        checks.append(_check("openusd_python_available", True, "OpenUSD Python modules are available", "info"))
    errors = [check["message"] for check in checks if check["severity"] == "error" and not check["passed"]]
    return {
        "skill": _skill_name(),
        "passed": not errors,
        "checks": checks,
        "errors": errors,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check portable SimReady package dependencies.")
    parser.add_argument("--report", type=Path, help="Write dependency check JSON to this path.")
    args = parser.parse_args(argv)

    payload = check_dependencies()
    _write_report(payload, args.report)
    return 0 if payload["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
