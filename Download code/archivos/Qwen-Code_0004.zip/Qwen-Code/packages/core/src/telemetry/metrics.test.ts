/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect, vi, beforeEach, type Mock } from 'vitest';
import type {
  Counter,
  Meter,
  Attributes,
  Context,
  Histogram,
} from '@opentelemetry/api';
import type { Config } from '../config/config.js';
import {
  FileOperation,
  MemoryMetricType,
  ToolExecutionPhase,
  ApiRequestPhase,
} from './metrics.js';
import { makeFakeConfig } from '../test-utils/config.js';

const mockCounterAddFn: Mock<
  (value: number, attributes?: Attributes, context?: Context) => void
> = vi.fn();
const mockHistogramRecordFn: Mock<
  (value: number, attributes?: Attributes, context?: Context) => void
> = vi.fn();

const mockCreateCounterFn: Mock<(name: string, options?: unknown) => Counter> =
  vi.fn();
const mockCreateHistogramFn: Mock<
  (name: string, options?: unknown) => Histogram
> = vi.fn();

const mockCounterInstance: Counter = {
  add: mockCounterAddFn,
} as Partial<Counter> as Counter;

const mockHistogramInstance: Histogram = {
  record: mockHistogramRecordFn,
} as Partial<Histogram> as Histogram;

const mockMeterInstance: Meter = {
  createCounter: mockCreateCounterFn.mockReturnValue(mockCounterInstance),
  createHistogram: mockCreateHistogramFn.mockReturnValue(mockHistogramInstance),
} as Partial<Meter> as Meter;

function originalOtelMockFactory() {
  return {
    metrics: {
      getMeter: vi.fn(),
    },
    ValueType: {
      INT: 1,
      DOUBLE: 2,
    },
    diag: {
      setLogger: vi.fn(),
      warn: vi.fn(),
    },
  } as const;
}

vi.mock('@opentelemetry/api');

describe('Telemetry Metrics', () => {
  let initializeMetricsModule: typeof import('./metrics.js').initializeMetrics;
  let recordToolCallMetricsModule: typeof import('./metrics.js').recordToolCallMetrics;
  let recordTokenUsageMetricsModule: typeof import('./metrics.js').recordTokenUsageMetrics;
  let recordToolExecutionMetricsModule: typeof import('./metrics.js').recordToolExecutionMetrics;
  let recordRepeatedToolFailureGuardMetricsModule: typeof import('./metrics.js').recordRepeatedToolFailureGuardMetrics;
  let recordFileOperationMetricModule: typeof import('./metrics.js').recordFileOperationMetric;
  let recordChatCompressionMetricsModule: typeof import('./metrics.js').recordChatCompressionMetrics;
  let recordStartupPerformanceModule: typeof import('./metrics.js').recordStartupPerformance;
  let recordMemoryUsageModule: typeof import('./metrics.js').recordMemoryUsage;
  let recordCpuUsageModule: typeof import('./metrics.js').recordCpuUsage;
  let recordToolQueueDepthModule: typeof import('./metrics.js').recordToolQueueDepth;
  let recordToolExecutionBreakdownModule: typeof import('./metrics.js').recordToolExecutionBreakdown;
  let recordTokenEfficiencyModule: typeof import('./metrics.js').recordTokenEfficiency;
  let recordApiRequestBreakdownModule: typeof import('./metrics.js').recordApiRequestBreakdown;
  let recordPerformanceScoreModule: typeof import('./metrics.js').recordPerformanceScore;
  let recordPerformanceRegressionModule: typeof import('./metrics.js').recordPerformanceRegression;
  let recordBaselineComparisonModule: typeof import('./metrics.js').recordBaselineComparison;
  let recordChannelMemoryRecallMetricsModule: typeof import('./metrics.js').recordChannelMemoryRecallMetrics;
  let recordMemoryRecallDeliveryMetricsModule: typeof import('./metrics.js').recordMemoryRecallDeliveryMetrics;

  beforeEach(async () => {
    vi.resetModules();
    vi.doMock('@opentelemetry/api', () => {
      const actualApi = originalOtelMockFactory();
      (actualApi.metrics.getMeter as Mock).mockReturnValue(mockMeterInstance);
      return actualApi;
    });

    const metricsJsModule = await import('./metrics.js');
    initializeMetricsModule = metricsJsModule.initializeMetrics;
    recordToolCallMetricsModule = metricsJsModule.recordToolCallMetrics;
    recordTokenUsageMetricsModule = metricsJsModule.recordTokenUsageMetrics;
    recordToolExecutionMetricsModule =
      metricsJsModule.recordToolExecutionMetrics;
    recordRepeatedToolFailureGuardMetricsModule =
      metricsJsModule.recordRepeatedToolFailureGuardMetrics;
    recordFileOperationMetricModule = metricsJsModule.recordFileOperationMetric;
    recordChatCompressionMetricsModule =
      metricsJsModule.recordChatCompressionMetrics;
    recordStartupPerformanceModule = metricsJsModule.recordStartupPerformance;
    recordMemoryUsageModule = metricsJsModule.recordMemoryUsage;
    recordCpuUsageModule = metricsJsModule.recordCpuUsage;
    recordToolQueueDepthModule = metricsJsModule.recordToolQueueDepth;
    recordToolExecutionBreakdownModule =
      metricsJsModule.recordToolExecutionBreakdown;
    recordTokenEfficiencyModule = metricsJsModule.recordTokenEfficiency;
    recordApiRequestBreakdownModule = metricsJsModule.recordApiRequestBreakdown;
    recordPerformanceScoreModule = metricsJsModule.recordPerformanceScore;
    recordPerformanceRegressionModule =
      metricsJsModule.recordPerformanceRegression;
    recordBaselineComparisonModule = metricsJsModule.recordBaselineComparison;
    recordChannelMemoryRecallMetricsModule =
      metricsJsModule.recordChannelMemoryRecallMetrics;
    recordMemoryRecallDeliveryMetricsModule =
      metricsJsModule.recordMemoryRecallDeliveryMetrics;

    const otelApiModule = await import('@opentelemetry/api');

    mockCounterAddFn.mockClear();
    mockCreateCounterFn.mockClear();
    mockCreateHistogramFn.mockClear();
    mockHistogramRecordFn.mockClear();
    (otelApiModule.metrics.getMeter as Mock).mockClear();

    (otelApiModule.metrics.getMeter as Mock).mockReturnValue(mockMeterInstance);
    mockCreateCounterFn.mockReturnValue(mockCounterInstance);
    mockCreateHistogramFn.mockReturnValue(mockHistogramInstance);
  });

  describe('recordToolCallMetrics', () => {
    const config = makeFakeConfig({
      sessionId: 'test-session-id',
    });

    it('records an explicit terminal status only on the counter', () => {
      initializeMetricsModule(config);

      recordToolCallMetricsModule(config, 25, {
        function_name: 'read_file',
        success: false,
        status: 'cancelled',
        tool_type: 'native',
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        function_name: 'read_file',
        success: false,
        status: 'cancelled',
        tool_type: 'native',
      });
      expect(mockHistogramRecordFn).toHaveBeenCalledWith(25, {
        function_name: 'read_file',
      });
    });

    it('derives status from success for legacy callers', () => {
      initializeMetricsModule(config);

      recordToolCallMetricsModule(config, 10, {
        function_name: 'legacy_tool',
        success: false,
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        function_name: 'legacy_tool',
        success: false,
        status: 'error',
      });
    });
  });

  describe('recordChatCompressionMetrics', () => {
    it('does not record metrics if not initialized', () => {
      const lol = makeFakeConfig({});

      recordChatCompressionMetricsModule(lol, {
        tokens_after: 100,
        tokens_before: 200,
      });

      expect(mockCounterAddFn).not.toHaveBeenCalled();
    });

    it('records token compression with the correct attributes', () => {
      const config = makeFakeConfig({
        sessionId: 'test-session-id',
      });
      initializeMetricsModule(config);

      recordChatCompressionMetricsModule(config, {
        tokens_after: 100,
        tokens_before: 200,
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        tokens_after: 100,
        tokens_before: 200,
      });
    });
  });

  describe('recordTokenUsageMetrics', () => {
    const mockConfig = {
      getSessionId: () => 'test-session-id',
      getTelemetryEnabled: () => true,
      getTelemetryMetricsIncludeSessionId: () => false,
    } as unknown as Config;

    it('should not record metrics if not initialized', () => {
      recordTokenUsageMetricsModule(mockConfig, 100, {
        model: 'gemini-pro',
        type: 'input',
      });
      expect(mockCounterAddFn).not.toHaveBeenCalled();
    });

    it('should record token usage with the correct attributes', () => {
      initializeMetricsModule(mockConfig);
      recordTokenUsageMetricsModule(mockConfig, 100, {
        model: 'gemini-pro',
        type: 'input',
      });
      expect(mockCounterAddFn).toHaveBeenCalledTimes(2);
      expect(mockCounterAddFn).toHaveBeenNthCalledWith(1, 1, {});
      expect(mockCounterAddFn).toHaveBeenNthCalledWith(2, 100, {
        model: 'gemini-pro',
        type: 'input',
      });
    });

    it('should record token usage for different types', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordTokenUsageMetricsModule(mockConfig, 50, {
        model: 'gemini-pro',
        type: 'output',
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(50, {
        model: 'gemini-pro',
        type: 'output',
      });

      recordTokenUsageMetricsModule(mockConfig, 25, {
        model: 'gemini-pro',
        type: 'thought',
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(25, {
        model: 'gemini-pro',
        type: 'thought',
      });

      recordTokenUsageMetricsModule(mockConfig, 75, {
        model: 'gemini-pro',
        type: 'cache',
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(75, {
        model: 'gemini-pro',
        type: 'cache',
      });
    });

    it('should handle different models', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordTokenUsageMetricsModule(mockConfig, 200, {
        model: 'gemini-ultra',
        type: 'input',
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(200, {
        model: 'gemini-ultra',
        type: 'input',
      });
    });
  });

  describe('recordToolExecutionMetrics', () => {
    const mockConfig = {
      getSessionId: () => 'test-session-id',
      getTelemetryEnabled: () => true,
      getTelemetryMetricsIncludeSessionId: () => false,
    } as unknown as Config;

    it('does not record before metrics are initialized', () => {
      recordToolExecutionMetricsModule(mockConfig, {
        execution_status: 'unknown',
        tool_type: 'native',
      });

      expect(mockCounterAddFn).not.toHaveBeenCalled();
    });

    it('uses a dedicated low-cardinality counter', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordToolExecutionMetricsModule(mockConfig, {
        execution_status: 'error',
        tool_type: 'mcp',
      });

      expect(mockCreateCounterFn).toHaveBeenCalledWith(
        'qwen-code.tool.execution.count',
        expect.any(Object),
      );
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        execution_status: 'error',
        tool_type: 'mcp',
      });
    });

    it('merges common attributes when session id is opted in', () => {
      const configWithSession = {
        ...mockConfig,
        getTelemetryMetricsIncludeSessionId: () => true,
      } as unknown as Config;
      initializeMetricsModule(configWithSession);
      mockCounterAddFn.mockClear();

      recordToolExecutionMetricsModule(configWithSession, {
        execution_status: 'success',
        tool_type: 'native',
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        'session.id': 'test-session-id',
        execution_status: 'success',
        tool_type: 'native',
      });
    });
  });

  describe('recordRepeatedToolFailureGuardMetrics', () => {
    const config = makeFakeConfig({
      sessionId: 'test-session-id',
    });

    it('records only low-cardinality transition attributes', () => {
      initializeMetricsModule(config);
      mockCounterAddFn.mockClear();

      recordRepeatedToolFailureGuardMetricsModule({
        route: 'acp_foreground',
        mode: 'enforce',
        phase_before: 'warned',
        phase_after: 'latched',
        decision: 'stopped',
        failure_count_bucket: '8+',
        batch_count_bucket: '3+',
        terminal_status: 'error',
        execution_status: 'error',
        tool_type: 'mcp',
      });

      expect(mockCreateCounterFn).toHaveBeenCalledWith(
        'qwen-code.repeated_tool_failure_guard.count',
        expect.any(Object),
      );
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        route: 'acp_foreground',
        mode: 'enforce',
        phase_before: 'warned',
        phase_after: 'latched',
        decision: 'stopped',
        failure_count_bucket: '8+',
        batch_count_bucket: '3+',
        terminal_status: 'error',
        execution_status: 'error',
        tool_type: 'mcp',
      });
    });
  });

  describe('recordFileOperationMetric', () => {
    const mockConfig = {
      getSessionId: () => 'test-session-id',
      getTelemetryEnabled: () => true,
      getTelemetryMetricsIncludeSessionId: () => false,
    } as unknown as Config;

    it('should not record metrics if not initialized', () => {
      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.CREATE,
        lines: 10,
        mimetype: 'text/plain',
        extension: 'txt',
      });
      expect(mockCounterAddFn).not.toHaveBeenCalled();
    });

    it('should record file creation with all attributes', () => {
      initializeMetricsModule(mockConfig);
      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.CREATE,
        lines: 10,
        mimetype: 'text/plain',
        extension: 'txt',
      });

      expect(mockCounterAddFn).toHaveBeenCalledTimes(2);
      expect(mockCounterAddFn).toHaveBeenNthCalledWith(1, 1, {});
      expect(mockCounterAddFn).toHaveBeenNthCalledWith(2, 1, {
        operation: FileOperation.CREATE,
        lines: 10,
        mimetype: 'text/plain',
        extension: 'txt',
      });
    });

    it('should record file read with minimal attributes', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.READ,
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        operation: FileOperation.READ,
      });
    });

    it('should record file update with some attributes', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.UPDATE,
        mimetype: 'application/javascript',
      });
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        operation: FileOperation.UPDATE,
        mimetype: 'application/javascript',
      });
    });

    it('should record file operation without diffStat', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.UPDATE,
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        operation: FileOperation.UPDATE,
      });
    });

    it('should record minimal file operation when optional parameters are undefined', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.UPDATE,
        lines: 10,
        mimetype: 'text/plain',
        extension: 'txt',
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        operation: FileOperation.UPDATE,
        lines: 10,
        mimetype: 'text/plain',
        extension: 'txt',
      });
    });

    it('should not include diffStat attributes when diffStat is not provided', () => {
      initializeMetricsModule(mockConfig);
      mockCounterAddFn.mockClear();

      recordFileOperationMetricModule(mockConfig, {
        operation: FileOperation.UPDATE,
      });

      expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
        operation: FileOperation.UPDATE,
      });
    });
  });

  describe('Performance Monitoring Metrics', () => {
    const mockConfig = {
      getSessionId: () => 'test-session-id',
      getTelemetryEnabled: () => true,
      getTelemetryMetricsIncludeSessionId: () => false,
    } as unknown as Config;

    describe('recordStartupPerformance', () => {
      it('should not record metrics when performance monitoring is disabled', async () => {
        // Re-import with performance monitoring disabled by mocking the config
        const mockConfigDisabled = {
          getSessionId: () => 'test-session-id',
          getTelemetryEnabled: () => false, // Disable telemetry to disable performance monitoring
          getTelemetryMetricsIncludeSessionId: () => false,
        } as unknown as Config;

        initializeMetricsModule(mockConfigDisabled);
        mockHistogramRecordFn.mockClear();

        recordStartupPerformanceModule(mockConfigDisabled, 100, {
          phase: 'settings_loading',
          details: {
            auth_type: 'gemini',
          },
        });

        expect(mockHistogramRecordFn).not.toHaveBeenCalled();
      });

      it('should record startup performance with phase and details', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordStartupPerformanceModule(mockConfig, 150, {
          phase: 'settings_loading',
          details: {
            auth_type: 'gemini',
            telemetry_enabled: true,
            settings_sources: 2,
          },
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(150, {
          phase: 'settings_loading',
          auth_type: 'gemini',
          telemetry_enabled: true,
          settings_sources: 2,
        });
      });

      it('should record startup performance without details', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordStartupPerformanceModule(mockConfig, 50, { phase: 'cleanup' });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(50, {
          phase: 'cleanup',
        });
      });

      it('should handle floating-point duration values from performance.now()', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        // Test with realistic floating-point values that performance.now() would return
        const floatingPointDuration = 123.45678;
        recordStartupPerformanceModule(mockConfig, floatingPointDuration, {
          phase: 'total_startup',
          details: {
            is_tty: true,
            has_question: false,
          },
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(
          floatingPointDuration,
          {
            phase: 'total_startup',
            is_tty: true,
            has_question: false,
          },
        );
      });
    });

    describe('recordMemoryUsage', () => {
      it('should record memory usage for different memory types', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordMemoryUsageModule(mockConfig, 15728640, {
          memory_type: MemoryMetricType.HEAP_USED,
          component: 'startup',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(15728640, {
          memory_type: 'heap_used',
          component: 'startup',
        });
      });

      it('should record memory usage for all memory metric types', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordMemoryUsageModule(mockConfig, 31457280, {
          memory_type: MemoryMetricType.HEAP_TOTAL,
          component: 'api_call',
        });
        recordMemoryUsageModule(mockConfig, 2097152, {
          memory_type: MemoryMetricType.EXTERNAL,
          component: 'tool_execution',
        });
        recordMemoryUsageModule(mockConfig, 41943040, {
          memory_type: MemoryMetricType.RSS,
          component: 'memory_monitor',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledTimes(3); // One for each call
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(1, 31457280, {
          memory_type: 'heap_total',
          component: 'api_call',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(2, 2097152, {
          memory_type: 'external',
          component: 'tool_execution',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(3, 41943040, {
          memory_type: 'rss',
          component: 'memory_monitor',
        });
      });

      it('should record memory usage without component', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordMemoryUsageModule(mockConfig, 15728640, {
          memory_type: MemoryMetricType.HEAP_USED,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(15728640, {
          memory_type: 'heap_used',
        });
      });
    });

    describe('recordCpuUsage', () => {
      it('should record CPU usage percentage', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordCpuUsageModule(mockConfig, 85.5, {
          component: 'tool_execution',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(85.5, {
          component: 'tool_execution',
        });
      });

      it('should record CPU usage without component', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordCpuUsageModule(mockConfig, 42.3, {});

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(42.3, {});
      });
    });

    describe('recordToolQueueDepth', () => {
      it('should record tool queue depth', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordToolQueueDepthModule(mockConfig, 3);

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(3, {});
      });

      it('should record zero queue depth', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordToolQueueDepthModule(mockConfig, 0);

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(0, {});
      });
    });

    describe('recordToolExecutionBreakdown', () => {
      it('should record tool execution breakdown for all phases', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordToolExecutionBreakdownModule(mockConfig, 25, {
          function_name: 'Read',
          phase: ToolExecutionPhase.VALIDATION,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(25, {
          function_name: 'Read',
          phase: 'validation',
        });
      });

      it('should record execution breakdown for different phases', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordToolExecutionBreakdownModule(mockConfig, 50, {
          function_name: 'Bash',
          phase: ToolExecutionPhase.PREPARATION,
        });
        recordToolExecutionBreakdownModule(mockConfig, 1500, {
          function_name: 'Bash',
          phase: ToolExecutionPhase.EXECUTION,
        });
        recordToolExecutionBreakdownModule(mockConfig, 75, {
          function_name: 'Bash',
          phase: ToolExecutionPhase.RESULT_PROCESSING,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledTimes(3); // One for each call
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(1, 50, {
          function_name: 'Bash',
          phase: 'preparation',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(2, 1500, {
          function_name: 'Bash',
          phase: 'execution',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(3, 75, {
          function_name: 'Bash',
          phase: 'result_processing',
        });
      });
    });

    describe('recordTokenEfficiency', () => {
      it('should record token efficiency metrics', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordTokenEfficiencyModule(mockConfig, 0.85, {
          model: 'gemini-pro',
          metric: 'cache_hit_rate',
          context: 'api_request',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(0.85, {
          model: 'gemini-pro',
          metric: 'cache_hit_rate',
          context: 'api_request',
        });
      });

      it('should record token efficiency without context', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordTokenEfficiencyModule(mockConfig, 125.5, {
          model: 'gemini-pro',
          metric: 'tokens_per_operation',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(125.5, {
          model: 'gemini-pro',
          metric: 'tokens_per_operation',
        });
      });
    });

    describe('recordApiRequestBreakdown', () => {
      it('should record API request breakdown for all phases', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordApiRequestBreakdownModule(mockConfig, 15, {
          model: 'gemini-pro',
          phase: ApiRequestPhase.REQUEST_PREPARATION,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(15, {
          model: 'gemini-pro',
          phase: 'request_preparation',
        });
      });

      it('should record API request breakdown for different phases', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordApiRequestBreakdownModule(mockConfig, 250, {
          model: 'gemini-pro',
          phase: ApiRequestPhase.NETWORK_LATENCY,
        });
        recordApiRequestBreakdownModule(mockConfig, 100, {
          model: 'gemini-pro',
          phase: ApiRequestPhase.RESPONSE_PROCESSING,
        });
        recordApiRequestBreakdownModule(mockConfig, 50, {
          model: 'gemini-pro',
          phase: ApiRequestPhase.TOKEN_PROCESSING,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledTimes(3); // One for each call
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(1, 250, {
          model: 'gemini-pro',
          phase: 'network_latency',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(2, 100, {
          model: 'gemini-pro',
          phase: 'response_processing',
        });
        expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(3, 50, {
          model: 'gemini-pro',
          phase: 'token_processing',
        });
      });
    });

    describe('recordPerformanceScore', () => {
      it('should record performance score with category and baseline', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordPerformanceScoreModule(mockConfig, 85.5, {
          category: 'memory_efficiency',
          baseline: 80.0,
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(85.5, {
          category: 'memory_efficiency',
          baseline: 80.0,
        });
      });

      it('should record performance score without baseline', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordPerformanceScoreModule(mockConfig, 92.3, {
          category: 'overall_performance',
        });

        expect(mockHistogramRecordFn).toHaveBeenCalledWith(92.3, {
          category: 'overall_performance',
        });
      });
    });

    describe('recordPerformanceRegression', () => {
      it('should record performance regression with baseline comparison', () => {
        initializeMetricsModule(mockConfig);
        mockCounterAddFn.mockClear();
        mockHistogramRecordFn.mockClear();

        recordPerformanceRegressionModule(mockConfig, {
          metric: 'startup_time',
          current_value: 1200,
          baseline_value: 1000,
          severity: 'medium',
        });

        // Verify regression counter
        expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
          metric: 'startup_time',
          severity: 'medium',
          current_value: 1200,
          baseline_value: 1000,
        });

        // Verify baseline comparison histogram (20% increase)
        expect(mockHistogramRecordFn).toHaveBeenCalledWith(20, {
          metric: 'startup_time',
          severity: 'medium',
          current_value: 1200,
          baseline_value: 1000,
        });
      });

      it('should handle zero baseline value gracefully', () => {
        initializeMetricsModule(mockConfig);
        mockCounterAddFn.mockClear();
        mockHistogramRecordFn.mockClear();

        recordPerformanceRegressionModule(mockConfig, {
          metric: 'memory_usage',
          current_value: 100,
          baseline_value: 0,
          severity: 'high',
        });

        // Verify regression counter still recorded
        expect(mockCounterAddFn).toHaveBeenCalledWith(1, {
          metric: 'memory_usage',
          severity: 'high',
          current_value: 100,
          baseline_value: 0,
        });

        // Verify no baseline comparison due to zero baseline
        expect(mockHistogramRecordFn).not.toHaveBeenCalled();
      });

      it('should record different severity levels', () => {
        initializeMetricsModule(mockConfig);
        mockCounterAddFn.mockClear();

        recordPerformanceRegressionModule(mockConfig, {
          metric: 'api_latency',
          current_value: 500,
          baseline_value: 400,
          severity: 'low',
        });
        recordPerformanceRegressionModule(mockConfig, {
          metric: 'cpu_usage',
          current_value: 90,
          baseline_value: 70,
          severity: 'high',
        });

        expect(mockCounterAddFn).toHaveBeenNthCalledWith(1, 1, {
          metric: 'api_latency',
          severity: 'low',
          current_value: 500,
          baseline_value: 400,
        });
        expect(mockCounterAddFn).toHaveBeenNthCalledWith(2, 1, {
          metric: 'cpu_usage',
          severity: 'high',
          current_value: 90,
          baseline_value: 70,
        });
      });
    });

    describe('recordBaselineComparison', () => {
      it('should record baseline comparison with percentage change', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordBaselineComparisonModule(mockConfig, {
          metric: 'memory_usage',
          current_value: 120,
          baseline_value: 100,
          category: 'performance_tracking',
        });

        // 20% increase: (120 - 100) / 100 * 100 = 20%
        expect(mockHistogramRecordFn).toHaveBeenCalledWith(20, {
          metric: 'memory_usage',
          category: 'performance_tracking',
          current_value: 120,
          baseline_value: 100,
        });
      });

      it('should handle negative percentage change (improvement)', () => {
        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordBaselineComparisonModule(mockConfig, {
          metric: 'startup_time',
          current_value: 800,
          baseline_value: 1000,
          category: 'optimization',
        });

        // 20% decrease: (800 - 1000) / 1000 * 100 = -20%
        expect(mockHistogramRecordFn).toHaveBeenCalledWith(-20, {
          metric: 'startup_time',
          category: 'optimization',
          current_value: 800,
          baseline_value: 1000,
        });
      });

      it('should skip recording when baseline is zero', async () => {
        // Access the actual mocked module
        const mockedModule = (await vi.importMock('@opentelemetry/api')) as {
          diag: { warn: ReturnType<typeof vi.fn> };
        };
        const diagSpy = vi.spyOn(mockedModule.diag, 'warn');

        initializeMetricsModule(mockConfig);
        mockHistogramRecordFn.mockClear();

        recordBaselineComparisonModule(mockConfig, {
          metric: 'new_metric',
          current_value: 50,
          baseline_value: 0,
          category: 'testing',
        });

        expect(diagSpy).toHaveBeenCalledWith(
          'Baseline value is zero, skipping comparison.',
        );
        expect(mockHistogramRecordFn).not.toHaveBeenCalled();
      });
    });
  });

  describe('metric attribute cardinality controls', () => {
    it('records memory recall delivery with low-cardinality attributes', () => {
      const config = makeFakeConfig({ sessionId: 'cardinality-test' });
      initializeMetricsModule(config);
      mockCounterAddFn.mockClear();
      mockHistogramRecordFn.mockClear();

      recordMemoryRecallDeliveryMetricsModule(config, 42, {
        phase: 'refined',
        delivery_point: 'discarded',
        discard_reason: 'reset',
        strategy: 'model',
      });

      const expectedAttrs = {
        phase: 'refined',
        delivery_point: 'discarded',
        discard_reason: 'reset',
        strategy: 'model',
      };
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, expectedAttrs);
      expect(mockHistogramRecordFn).toHaveBeenCalledWith(42, expectedAttrs);
    });

    it('omits session.id from metric attributes by default', () => {
      const config = makeFakeConfig({ sessionId: 'cardinality-test' });
      initializeMetricsModule(config);
      mockCounterAddFn.mockClear();

      recordChatCompressionMetricsModule(config, {
        tokens_after: 1,
        tokens_before: 2,
      });

      const attrs = mockCounterAddFn.mock.calls[0]?.[1] ?? {};
      expect(attrs).not.toHaveProperty('session.id');
    });

    it('includes session.id when telemetry.metrics.includeSessionId is true', () => {
      const config = makeFakeConfig({
        sessionId: 'cardinality-test',
        telemetry: { metrics: { includeSessionId: true } },
      });
      initializeMetricsModule(config);
      mockCounterAddFn.mockClear();

      recordChatCompressionMetricsModule(config, {
        tokens_after: 1,
        tokens_before: 2,
      });

      const attrs = mockCounterAddFn.mock.calls[0]?.[1] ?? {};
      expect(attrs['session.id']).toBe('cardinality-test');
    });
  });

  describe('recordChannelMemoryRecallMetrics', () => {
    it('does not record before metrics are initialized', () => {
      recordChannelMemoryRecallMetricsModule({
        durationMs: 12,
        cache: 'hit',
        result: 'selected',
        selectedCount: 2,
      });

      expect(mockCounterAddFn).not.toHaveBeenCalled();
      expect(mockHistogramRecordFn).not.toHaveBeenCalled();
    });

    it('records only bounded recall outcome attributes', () => {
      initializeMetricsModule(makeFakeConfig({ sessionId: 'secret-session' }));
      mockCounterAddFn.mockClear();
      mockHistogramRecordFn.mockClear();

      recordChannelMemoryRecallMetricsModule({
        durationMs: 12.5,
        cache: 'miss',
        result: 'revision_unstable',
        selectedCount: 1,
      });

      const attributes = {
        cache: 'miss',
        result: 'revision_unstable',
      };
      expect(mockCounterAddFn).toHaveBeenCalledWith(1, attributes);
      expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(
        1,
        12.5,
        attributes,
      );
      expect(mockHistogramRecordFn).toHaveBeenNthCalledWith(2, 1, attributes);
      expect(Object.keys(mockCounterAddFn.mock.calls[0]![1]!).sort()).toEqual([
        'cache',
        'result',
      ]);
    });

    it('initializes dedicated channel memory recall instruments', () => {
      initializeMetricsModule(makeFakeConfig({}));

      expect(mockCreateCounterFn).toHaveBeenCalledWith(
        'qwen-code.channel.memory.recall.count',
        expect.any(Object),
      );
      expect(mockCreateHistogramFn).toHaveBeenCalledWith(
        'qwen-code.channel.memory.recall.duration',
        expect.objectContaining({ unit: 'ms' }),
      );
      expect(mockCreateHistogramFn).toHaveBeenCalledWith(
        'qwen-code.channel.memory.recall.selected_count',
        expect.any(Object),
      );
    });
  });
});
