/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import type { LogAttributes, LogRecord } from '@opentelemetry/api-logs';
import { logs } from '@opentelemetry/api-logs';
import { SemanticAttributes } from '@opentelemetry/semantic-conventions';
import type { Config } from '../config/config.js';
import { isInternalPromptId } from '../utils/internalPromptIds.js';
import { safeJsonStringify } from '../utils/safeJsonStringify.js';
import {
  EVENT_API_ERROR,
  EVENT_API_CANCEL,
  EVENT_API_REQUEST,
  EVENT_API_RESPONSE,
  EVENT_CLI_CONFIG,
  EVENT_EXTENSION_UNINSTALL,
  EVENT_EXTENSION_ENABLE,
  EVENT_IDE_CONNECTION,
  EVENT_TOOL_CALL,
  EVENT_REPEATED_TOOL_FAILURE_GUARD,
  EVENT_USER_PROMPT,
  EVENT_USER_RETRY,
  EVENT_FLASH_FALLBACK,
  EVENT_NEXT_SPEAKER_CHECK,
  SERVICE_NAME,
  EVENT_SLASH_COMMAND,
  EVENT_CONVERSATION_FINISHED,
  EVENT_CHAT_COMPRESSION,
  EVENT_CONTENT_RETRY,
  EVENT_CONTENT_RETRY_FAILURE,
  EVENT_PROTOCOL_TAG_SANITIZED,
  EVENT_API_RETRY,
  EVENT_FILE_OPERATION,
  EVENT_RIPGREP_FALLBACK,
  EVENT_RIPGREP_RUNTIME_RECOVERY,
  EVENT_EXTENSION_INSTALL,
  EVENT_MODEL_SLASH_COMMAND,
  EVENT_EXTENSION_DISABLE,
  EVENT_SUBAGENT_EXECUTION,
  EVENT_MALFORMED_JSON_RESPONSE,
  EVENT_INVALID_CHUNK,
  EVENT_AUTH,
  EVENT_SKILL_LAUNCH,
  EVENT_EXTENSION_UPDATE,
  EVENT_USER_FEEDBACK,
  EVENT_ARENA_SESSION_STARTED,
  EVENT_ARENA_AGENT_COMPLETED,
  EVENT_ARENA_SESSION_ENDED,
  EVENT_PROMPT_SUGGESTION,
  EVENT_SPECULATION,
  EVENT_WORKFLOW_KEYWORD,
  EVENT_WORKFLOW_RUN,
  EVENT_MEMORY_EXTRACT,
  EVENT_MEMORY_DREAM,
  EVENT_MEMORY_RECALL,
  EVENT_MEMORY_RECALL_DELIVERY,
  EVENT_TOOL_OUTPUT_TRUNCATED,
} from './constants.js';
import {
  recordApiErrorMetrics,
  recordApiResponseMetrics,
  recordChatCompressionMetrics,
  recordContentRetry,
  recordContentRetryFailure,
  recordApiRetry,
  recordFileOperationMetric,
  recordInvalidChunk,
  recordModelSlashCommand,
  recordSubagentExecutionMetrics,
  recordTokenUsageMetrics,
  recordToolCallMetrics,
  recordToolExecutionMetrics,
  recordRepeatedToolFailureGuardMetrics,
  recordArenaSessionStartedMetrics,
  recordArenaAgentCompletedMetrics,
  recordArenaSessionEndedMetrics,
  recordMemoryExtractMetrics,
  recordMemoryDreamMetrics,
  recordMemoryRecallMetrics,
  recordMemoryRecallDeliveryMetrics,
} from './metrics.js';
import { QwenLogger } from './qwen-logger/qwen-logger.js';
import { isTelemetrySdkInitialized } from './sdk.js';
import type {
  ApiErrorEvent,
  ApiCancelEvent,
  ApiRequestEvent,
  ApiResponseEvent,
  FileOperationEvent,
  IdeConnectionEvent,
  StartSessionEvent,
  ToolCallEvent,
  UserPromptEvent,
  UserRetryEvent,
  FlashFallbackEvent,
  NextSpeakerCheckEvent,
  LoopDetectedEvent,
  RepeatedToolFailureGuardEvent,
  LoopDetectionDisabledEvent,
  SlashCommandEvent,
  ConversationFinishedEvent,
  KittySequenceOverflowEvent,
  ChatCompressionEvent,
  ContentRetryEvent,
  ContentRetryFailureEvent,
  ProtocolTagSanitizedEvent,
  ApiRetryEvent,
  RipgrepFallbackEvent,
  RipgrepRuntimeRecoveryEvent,
  ToolOutputTruncatedEvent,
  ExtensionDisableEvent,
  ExtensionEnableEvent,
  ExtensionUninstallEvent,
  ExtensionUpdateEvent,
  ExtensionInstallEvent,
  ModelSlashCommandEvent,
  SubagentExecutionEvent,
  MalformedJsonResponseEvent,
  InvalidChunkEvent,
  AuthEvent,
  SkillLaunchEvent,
  UserFeedbackEvent,
  ArenaSessionStartedEvent,
  ArenaAgentCompletedEvent,
  ArenaSessionEndedEvent,
  PromptSuggestionEvent,
  SpeculationEvent,
  WorkflowKeywordEvent,
  WorkflowRunEvent,
  MemoryExtractEvent,
  MemoryDreamEvent,
  MemoryRecallEvent,
  MemoryRecallDeliveryEvent,
} from './types.js';
import type { HookCallEvent } from './types.js';
import type { UiEvent, UiSubagentIdentity } from './uiTelemetry.js';
import { uiTelemetryService } from './uiTelemetry.js';
import { apiActivityTracker } from './api-activity-tracker.js';
import { recordTokenUsageFromApiResponseBestEffort } from '../services/tokenUsageService.js';
import { isChatRecordingSuppressed } from '../utils/chat-recording-suppression-context.js';
import { ToolErrorType } from '../tools/tool-error.js';
import { createDebugLogger } from '../utils/debugLogger.js';
import { emitSessionEnd, emitSessionStart } from './session-events.js';

const shouldLogUserPrompts = (config: Config): boolean =>
  config.getTelemetryLogPromptsEnabled();

function getCommonAttributes(config: Config): LogAttributes {
  return {
    'session.id': config.getSessionId(),
  };
}

function recordUiTelemetryEventToChat(config: Config, uiEvent: UiEvent): void {
  if (isChatRecordingSuppressed()) return;
  config.getChatRecordingService()?.recordUiTelemetryEvent(uiEvent);
}

export { getCommonAttributes };

type NormalizedToolCallEvent = ToolCallEvent & {
  execution_status: NonNullable<ToolCallEvent['execution_status']>;
};

/**
 * Normalizes a tool call event for telemetry sinks. Error fields are
 * deleted (not set to undefined) on success so downstream consumers
 * see key-absent rather than key-present-with-undefined.
 */
export function normalizeToolCallEvent(
  event: ToolCallEvent,
): NormalizedToolCallEvent {
  const functionName = event.function_name ?? '';
  const normalized: NormalizedToolCallEvent = {
    ...event,
    function_name:
      functionName.trim().length > 0 ? functionName : 'unknown_tool',
    success: event.status === 'success',
    execution_status: event.execution_status ?? 'unknown',
  };

  if (event.status === 'error') {
    normalized.error_type = event.error_type?.trim() || ToolErrorType.UNKNOWN;
  } else {
    delete normalized.error;
    delete normalized.error_type;
  }

  return normalized;
}

const debugLogger = createDebugLogger('TELEMETRY_SINK');

function runToolTelemetrySink(sink: () => void): void {
  try {
    sink();
  } catch (e) {
    debugLogger.debug('Telemetry sink failed (best-effort):', e);
  }
}

export function logStartSession(
  config: Config,
  event: StartSessionEvent,
  previousSessionId?: string,
): void {
  QwenLogger.getInstance(config)?.logStartSessionEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_CLI_CONFIG,
    'event.timestamp': new Date().toISOString(),
    model: event.model,
    sandbox_enabled: event.sandbox_enabled,
    core_tools_enabled: event.core_tools_enabled,
    approval_mode: event.approval_mode,
    file_filtering_respect_git_ignore: event.file_filtering_respect_git_ignore,
    debug_mode: event.debug_enabled,
    truncate_tool_output_threshold: event.truncate_tool_output_threshold,
    truncate_tool_output_lines: event.truncate_tool_output_lines,
    mcp_servers: event.mcp_servers,
    mcp_servers_count: event.mcp_servers_count,
    mcp_tools: event.mcp_tools,
    mcp_tools_count: event.mcp_tools_count,
    hooks: event.hooks,
    ide_enabled: event.ide_enabled,
    interactive_shell_enabled: event.interactive_shell_enabled,
    output_format: event.output_format,
    skills: event.skills,
    subagents: event.subagents,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: 'CLI configuration loaded.',
    attributes,
  };
  logger.emit(logRecord);
  emitSessionStart(config.getSessionId(), previousSessionId);
}

export function logSessionEnd(config: Config): void {
  if (!isTelemetrySdkInitialized()) return;
  emitSessionEnd(config.getSessionId());
}

export function logUserPrompt(config: Config, event: UserPromptEvent): void {
  QwenLogger.getInstance(config)?.logNewPromptEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_USER_PROMPT,
    'event.timestamp': new Date().toISOString(),
    prompt_length: event.prompt_length,
    prompt_id: event.prompt_id,
  };

  if (event.auth_type) {
    attributes['auth_type'] = event.auth_type;
  }

  if (event.model) {
    attributes['model'] = event.model;
  }

  if (shouldLogUserPrompts(config)) {
    attributes['prompt'] = event.prompt;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `User prompt. Length: ${event.prompt_length}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logUserRetry(config: Config, event: UserRetryEvent): void {
  QwenLogger.getInstance(config)?.logRetryEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_USER_RETRY,
    'event.timestamp': new Date().toISOString(),
    prompt_id: event.prompt_id,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `User retry.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logToolCall(config: Config, event: ToolCallEvent): void {
  const normalizedEvent = normalizeToolCallEvent(event);
  const uiEvent = {
    ...normalizedEvent,
    'event.name': EVENT_TOOL_CALL,
    'event.timestamp': new Date().toISOString(),
  } as UiEvent;
  runToolTelemetrySink(() => {
    uiTelemetryService.addEvent(uiEvent, config.getSessionId());
  });
  runToolTelemetrySink(() => {
    if (!isInternalPromptId(normalizedEvent.prompt_id)) {
      recordUiTelemetryEventToChat(config, uiEvent);
    }
  });
  runToolTelemetrySink(() => {
    QwenLogger.getInstance(config)?.logToolCallEvent(normalizedEvent);
  });
  if (!isTelemetrySdkInitialized()) return;

  runToolTelemetrySink(() => {
    const attributes: LogAttributes = {
      ...getCommonAttributes(config),
      ...normalizedEvent,
      'event.name': EVENT_TOOL_CALL,
      'event.timestamp': new Date().toISOString(),
      function_args: safeJsonStringify(normalizedEvent.function_args, 2),
    };
    if (normalizedEvent.error) {
      attributes['error.message'] = normalizedEvent.error;
    }
    if (normalizedEvent.error_type) {
      attributes['error.type'] = normalizedEvent.error_type;
    }

    const logger = logs.getLogger(SERVICE_NAME);
    const logRecord: LogRecord = {
      body: `Tool call: ${normalizedEvent.function_name}${normalizedEvent.decision ? `. Decision: ${normalizedEvent.decision}` : ''}. Success: ${normalizedEvent.success}. Duration: ${normalizedEvent.duration_ms}ms.`,
      attributes,
    };
    logger.emit(logRecord);
  });
  runToolTelemetrySink(() => {
    recordToolCallMetrics(config, normalizedEvent.duration_ms, {
      function_name: normalizedEvent.function_name,
      status: normalizedEvent.status,
      success: normalizedEvent.success,
      decision: normalizedEvent.decision,
      tool_type: normalizedEvent.tool_type,
    });
  });
  runToolTelemetrySink(() => {
    recordToolExecutionMetrics(config, {
      execution_status: normalizedEvent.execution_status,
      tool_type: normalizedEvent.tool_type,
    });
  });
}

export function logToolOutputTruncated(
  config: Config,
  event: ToolOutputTruncatedEvent,
): void {
  QwenLogger.getInstance(config)?.logToolOutputTruncatedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    // event class's `eventName` (short, no prefix) leaks via spread — override with
    // full namespaced constant for OTel compliance. Same pattern as other event loggers.
    'event.name': EVENT_TOOL_OUTPUT_TRUNCATED,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Tool output truncated for ${event.tool_name}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logFileOperation(
  config: Config,
  event: FileOperationEvent,
): void {
  QwenLogger.getInstance(config)?.logFileOperationEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_FILE_OPERATION,
    'event.timestamp': new Date().toISOString(),
    tool_name: event.tool_name,
    operation: event.operation,
  };

  if (event.lines) {
    attributes['lines'] = event.lines;
  }
  if (event.mimetype) {
    attributes['mimetype'] = event.mimetype;
  }
  if (event.extension) {
    attributes['extension'] = event.extension;
  }
  if (event.programming_language) {
    attributes['programming_language'] = event.programming_language;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `File operation: ${event.operation}. Lines: ${event.lines}.`,
    attributes,
  };
  logger.emit(logRecord);

  recordFileOperationMetric(config, {
    operation: event.operation,
    lines: event.lines,
    mimetype: event.mimetype,
    extension: event.extension,
    programming_language: event.programming_language,
  });
}

export function logApiRequest(
  config: Config,
  event: ApiRequestEvent,
  sessionId?: string,
): void {
  // QwenLogger.getInstance(config)?.logApiRequestEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    ...(sessionId ? { 'session.id': sessionId } : {}),
    'event.name': EVENT_API_REQUEST,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `API request to ${event.model}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logFlashFallback(
  config: Config,
  event: FlashFallbackEvent,
): void {
  QwenLogger.getInstance(config)?.logFlashFallbackEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_FLASH_FALLBACK,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Switching to flash as Fallback.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logRipgrepFallback(
  config: Config,
  event: RipgrepFallbackEvent,
): void {
  QwenLogger.getInstance(config)?.logRipgrepFallbackEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_RIPGREP_FALLBACK,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Switching to grep as fallback.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logRipgrepRuntimeRecovery(
  config: Config,
  event: RipgrepRuntimeRecoveryEvent,
): void {
  // Runtime recovery is separate from startup fallback; it describes a selected
  // ripgrep binary that started but did not complete normally.
  QwenLogger.getInstance(config)?.logRipgrepRuntimeRecoveryEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_RIPGREP_RUNTIME_RECOVERY,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Ripgrep runtime recovery: ${event.failure_kind}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logApiError(
  config: Config,
  event: ApiErrorEvent,
  sessionId?: string,
  uiSubagentIdentity?: UiSubagentIdentity,
): void {
  const uiEvent = {
    ...event,
    ...(uiSubagentIdentity
      ? {
          subagent_id: uiSubagentIdentity.id,
          subagent_type: uiSubagentIdentity.type,
          subagent_task_name: uiSubagentIdentity.taskName,
        }
      : {}),
    'event.name': EVENT_API_ERROR,
    'event.timestamp': new Date().toISOString(),
  } as UiEvent;
  uiTelemetryService.addEvent(uiEvent, config.getSessionId());
  // Feed the daemon-status model-API-health charts: one model API error per
  // failed attempt, drained per live model round by the ACP MessageEmitter.
  apiActivityTracker.recordError();
  if (!isInternalPromptId(event.prompt_id)) {
    recordUiTelemetryEventToChat(config, uiEvent);
  }
  QwenLogger.getInstance(config)?.logApiErrorEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    ...(sessionId ? { 'session.id': sessionId } : {}),
    'event.name': EVENT_API_ERROR,
    'event.timestamp': new Date().toISOString(),
    ['error.message']: event.error_message,
    model_name: event.model,
    duration: event.duration_ms,
  };

  if (event.error_type) {
    attributes['error.type'] = event.error_type;
  }
  if (typeof event.status_code === 'number') {
    attributes[SemanticAttributes.HTTP_STATUS_CODE] = event.status_code;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `API error for ${event.model}. Error: ${event.error_message}. Duration: ${event.duration_ms}ms.`,
    attributes,
  };
  logger.emit(logRecord);
  recordApiErrorMetrics(config, event.duration_ms, {
    model: event.model,
    status_code: event.status_code,
    error_type: event.error_type,
  });
}

export function logApiCancel(config: Config, event: ApiCancelEvent): void {
  const uiEvent = {
    ...event,
    'event.name': EVENT_API_CANCEL,
    'event.timestamp': new Date().toISOString(),
  } as UiEvent;
  uiTelemetryService.addEvent(uiEvent, config.getSessionId());
  QwenLogger.getInstance(config)?.logApiCancelEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_API_CANCEL,
    'event.timestamp': new Date().toISOString(),
    model_name: event.model,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `API request cancelled for ${event.model}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logApiResponse(
  config: Config,
  event: ApiResponseEvent,
  sessionId?: string,
  uiSubagentIdentity?: UiSubagentIdentity,
): void {
  const uiEvent = {
    ...event,
    ...(uiSubagentIdentity
      ? {
          subagent_id: uiSubagentIdentity.id,
          subagent_type: uiSubagentIdentity.type,
          subagent_task_name: uiSubagentIdentity.taskName,
        }
      : {}),
    'event.name': EVENT_API_RESPONSE,
    'event.timestamp': new Date().toISOString(),
  } as UiEvent;
  uiTelemetryService.addEvent(uiEvent, config.getSessionId());
  if (!isInternalPromptId(event.prompt_id)) {
    if (config.getUsageStatisticsEnabled()) {
      recordTokenUsageFromApiResponseBestEffort(config, event);
    }
    recordUiTelemetryEventToChat(config, uiEvent);
  }
  QwenLogger.getInstance(config)?.logApiResponseEvent(event);
  if (!isTelemetrySdkInitialized()) return;
  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    ...(sessionId ? { 'session.id': sessionId } : {}),
    'event.name': EVENT_API_RESPONSE,
    'event.timestamp': new Date().toISOString(),
  };
  if (event.response_text) {
    attributes['response_text'] = event.response_text;
  }
  if (event.status_code) {
    if (typeof event.status_code === 'number') {
      attributes[SemanticAttributes.HTTP_STATUS_CODE] = event.status_code;
    }
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `API response from ${event.model}. Status: ${event.status_code || 'N/A'}. Duration: ${event.duration_ms}ms.`,
    attributes,
  };
  logger.emit(logRecord);
  recordApiResponseMetrics(config, event.duration_ms, {
    model: event.model,
    status_code: event.status_code,
  });
  recordTokenUsageMetrics(config, event.input_token_count, {
    model: event.model,
    type: 'input',
  });
  recordTokenUsageMetrics(config, event.output_token_count, {
    model: event.model,
    type: 'output',
  });
  recordTokenUsageMetrics(config, event.cached_content_token_count, {
    model: event.model,
    type: 'cache',
  });
  recordTokenUsageMetrics(config, event.thoughts_token_count, {
    model: event.model,
    type: 'thought',
  });
}

export function logLoopDetected(
  config: Config,
  event: LoopDetectedEvent,
  options: { recordToQwenLogger?: boolean } = {},
): void {
  if (options.recordToQwenLogger !== false) {
    QwenLogger.getInstance(config)?.logLoopDetectedEvent(event);
  }
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Loop detected. Type: ${event.loop_type}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logRepeatedToolFailureGuard(
  event: RepeatedToolFailureGuardEvent,
): void {
  // Deployment cohort and service version come from the OpenTelemetry
  // Resource, which is attached to both the logger and meter providers.
  runToolTelemetrySink(() => {
    if (isTelemetrySdkInitialized()) {
      const logger = logs.getLogger(SERVICE_NAME);
      logger.emit({
        body: `Repeated tool failure guard decision: ${event.decision}.`,
        attributes: {
          ...event,
          'event.name': EVENT_REPEATED_TOOL_FAILURE_GUARD,
        },
      });
    }
  });
  runToolTelemetrySink(() => {
    recordRepeatedToolFailureGuardMetrics({
      route: event.route,
      mode: event.mode,
      phase_before: event.phase_before,
      phase_after: event.phase_after,
      decision: event.decision,
      failure_count_bucket: event.failure_count_bucket,
      batch_count_bucket: event.batch_count_bucket,
      ...(event.reset_reason !== undefined
        ? { reset_reason: event.reset_reason }
        : {}),
      ...(event.terminal_status !== undefined
        ? { terminal_status: event.terminal_status }
        : {}),
      ...(event.execution_status !== undefined
        ? { execution_status: event.execution_status }
        : {}),
      ...(event.tool_type !== undefined ? { tool_type: event.tool_type } : {}),
    });
  });
}

export function logLoopDetectionDisabled(
  config: Config,
  _event: LoopDetectionDisabledEvent,
): void {
  QwenLogger.getInstance(config)?.logLoopDetectionDisabledEvent();
}

export function logNextSpeakerCheck(
  config: Config,
  event: NextSpeakerCheckEvent,
): void {
  QwenLogger.getInstance(config)?.logNextSpeakerCheck(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_NEXT_SPEAKER_CHECK,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Next speaker check.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logSlashCommand(
  config: Config,
  event: SlashCommandEvent,
): void {
  QwenLogger.getInstance(config)?.logSlashCommandEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_SLASH_COMMAND,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Slash command: ${event.command}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logIdeConnection(
  config: Config,
  event: IdeConnectionEvent,
): void {
  QwenLogger.getInstance(config)?.logIdeConnectionEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_IDE_CONNECTION,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Ide connection. Type: ${event.connection_type}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logConversationFinishedEvent(
  config: Config,
  event: ConversationFinishedEvent,
): void {
  QwenLogger.getInstance(config)?.logConversationFinishedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_CONVERSATION_FINISHED,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Conversation finished.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logChatCompression(
  config: Config,
  event: ChatCompressionEvent,
): void {
  QwenLogger.getInstance(config)?.logChatCompressionEvent(event);

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_CHAT_COMPRESSION,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Chat compression (Saved ${event.tokens_before - event.tokens_after} tokens)`,
    attributes,
  };
  logger.emit(logRecord);

  recordChatCompressionMetrics(config, {
    tokens_before: event.tokens_before,
    tokens_after: event.tokens_after,
  });
}

export function logKittySequenceOverflow(
  config: Config,
  event: KittySequenceOverflowEvent,
): void {
  QwenLogger.getInstance(config)?.logKittySequenceOverflowEvent(event);
  if (!isTelemetrySdkInitialized()) return;
  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
  };
  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Kitty sequence buffer overflow: ${event.sequence_length} bytes`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logMalformedJsonResponse(
  config: Config,
  event: MalformedJsonResponseEvent,
): void {
  QwenLogger.getInstance(config)?.logMalformedJsonResponseEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_MALFORMED_JSON_RESPONSE,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Malformed JSON response from ${event.model}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logInvalidChunk(
  config: Config,
  event: InvalidChunkEvent,
): void {
  QwenLogger.getInstance(config)?.logInvalidChunkEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_INVALID_CHUNK,
    'event.timestamp': event['event.timestamp'],
  };

  if (event.error_message) {
    attributes['error.message'] = event.error_message;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Invalid chunk received from stream.`,
    attributes,
  };
  logger.emit(logRecord);
  recordInvalidChunk(config);
}

export function logContentRetry(
  config: Config,
  event: ContentRetryEvent,
): void {
  QwenLogger.getInstance(config)?.logContentRetryEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_CONTENT_RETRY,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Content retry attempt ${event.attempt_number} due to ${event.error_type}.`,
    attributes,
  };
  logger.emit(logRecord);
  recordContentRetry(config);
}

export function logProtocolTagSanitized(
  config: Config,
  event: ProtocolTagSanitizedEvent,
): void {
  QwenLogger.getInstance(config)?.logProtocolTagSanitizedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_PROTOCOL_TAG_SANITIZED,
  };

  logs.getLogger(SERVICE_NAME).emit({
    body: `Suppressed a standalone closing ${event.tag_name} tag and preserved ${event.tool_call_count} tool call(s).`,
    attributes,
  });
}

export function logContentRetryFailure(
  config: Config,
  event: ContentRetryFailureEvent,
): void {
  QwenLogger.getInstance(config)?.logContentRetryFailureEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_CONTENT_RETRY_FAILURE,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `All content retries failed after ${event.total_attempts} attempts.`,
    attributes,
  };
  logger.emit(logRecord);
  recordContentRetryFailure(config);
}

/**
 * Phase 4b — Emits an HTTP-status retry event fired from `retryWithBackoff`
 * at an LLM call site (via the `onRetry` callback opt-in). Distinct from
 * `logContentRetry`, which is fired by `llmChat`'s content-recovery loop.
 *
 * Fan-out (sink 0 fires first, before the SDK guard, so retries are counted
 * even with telemetry off; sinks 1–3 match the `logContentRetry` shape):
 *   0. `apiActivityTracker` increment — daemon-status model-API-health charts
 *      (drained per live model round by the ACP MessageEmitter).
 *   1. QwenLogger RUM ingestion (Aliyun internal stats)
 *   2. OTel log signal via `logger.emit()` — picked up by LogToSpanProcessor
 *      and bridged to a span sibling under the caller's active span (typically
 *      interaction or tool, NOT the failed LLM span — that span has already
 *      ended by the time onRetry fires).
 *   3. `recordApiRetry` Counter increment for per-model retry-rate dashboards.
 */
export function logApiRetry(config: Config, event: ApiRetryEvent): void {
  apiActivityTracker.recordRetry(); // sink 0 — see fan-out above
  QwenLogger.getInstance(config)?.logApiRetryEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_API_RETRY,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `API retry attempt ${event.attempt_number} for ${event.model} (status ${event.status_code ?? 'unknown'}).`,
    attributes,
  };
  logger.emit(logRecord);
  recordApiRetry(config, { model: event.model });
}

export function logSubagentExecution(
  config: Config,
  event: SubagentExecutionEvent,
): void {
  QwenLogger.getInstance(config)?.logSubagentExecutionEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_SUBAGENT_EXECUTION,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Subagent execution: ${event.subagent_name}.`,
    attributes,
  };
  logger.emit(logRecord);
  recordSubagentExecutionMetrics(
    config,
    event.subagent_name,
    event.status,
    event.terminate_reason,
  );
}

export function logModelSlashCommand(
  config: Config,
  event: ModelSlashCommandEvent,
): void {
  QwenLogger.getInstance(config)?.logModelSlashCommandEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_MODEL_SLASH_COMMAND,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Model slash command. Model: ${event.model_name}`,
    attributes,
  };
  logger.emit(logRecord);
  recordModelSlashCommand(config, event);
}

export function logHookCall(config: Config, event: HookCallEvent): void {
  // Log to QwenLogger for RUM telemetry only
  QwenLogger.getInstance(config)?.logHookCallEvent(event);
}

export function logExtensionInstallEvent(
  config: Config,
  event: ExtensionInstallEvent,
): void {
  QwenLogger.getInstance(config)?.logExtensionInstallEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_EXTENSION_INSTALL,
    'event.timestamp': new Date().toISOString(),
    extension_name: event.extension_name,
    extension_version: event.extension_version,
    extension_source: event.extension_source,
    status: event.status,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Installed extension ${event.extension_name}`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logExtensionUninstall(
  config: Config,
  event: ExtensionUninstallEvent,
): void {
  QwenLogger.getInstance(config)?.logExtensionUninstallEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_EXTENSION_UNINSTALL,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Uninstalled extension ${event.extension_name}`,
    attributes,
  };
  logger.emit(logRecord);
}

export async function logExtensionUpdateEvent(
  config: Config,
  event: ExtensionUpdateEvent,
): Promise<void> {
  QwenLogger.getInstance(config)?.logExtensionUpdateEvent(event);

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_EXTENSION_UPDATE,
    'event.timestamp': new Date().toISOString(),
    extension_name: event.extension_name,
    extension_id: event.extension_id,
    extension_previous_version: event.extension_previous_version,
    extension_version: event.extension_version,
    extension_source: event.extension_source,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Updated extension ${event.extension_name} from ${event.extension_previous_version} to ${event.extension_version}`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logExtensionEnable(
  config: Config,
  event: ExtensionEnableEvent,
): void {
  QwenLogger.getInstance(config)?.logExtensionEnableEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_EXTENSION_ENABLE,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Enabled extension ${event.extension_name}`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logExtensionDisable(
  config: Config,
  event: ExtensionDisableEvent,
): void {
  QwenLogger.getInstance(config)?.logExtensionDisableEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_EXTENSION_DISABLE,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Disabled extension ${event.extension_name}`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logAuth(config: Config, event: AuthEvent): void {
  QwenLogger.getInstance(config)?.logAuthEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_AUTH,
    'event.timestamp': new Date().toISOString(),
    auth_type: event.auth_type,
    action_type: event.action_type,
    status: event.status,
  };

  if (event.error_message) {
    attributes['error.message'] = event.error_message;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Auth event: ${event.action_type} ${event.status} for ${event.auth_type}`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logSkillLaunch(config: Config, event: SkillLaunchEvent): void {
  QwenLogger.getInstance(config)?.logSkillLaunchEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_SKILL_LAUNCH,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Skill launch: ${event.skill_name}. Success: ${event.success}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function recordSkillInvocation(
  config: Config,
  event: { skillName: string; success: boolean },
): void {
  uiTelemetryService.recordSkillInvocation(
    event.skillName,
    event.success,
    config.getSessionId(),
  );
}

export function logUserFeedback(
  config: Config,
  event: UserFeedbackEvent,
): void {
  const uiEvent = {
    ...event,
    'event.name': EVENT_USER_FEEDBACK,
    'event.timestamp': new Date().toISOString(),
  } as UiEvent;
  uiTelemetryService.addEvent(uiEvent, config.getSessionId());
  recordUiTelemetryEventToChat(config, uiEvent);
  QwenLogger.getInstance(config)?.logUserFeedbackEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_USER_FEEDBACK,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `User feedback: Rating ${event.rating} for session ${event.session_id}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logArenaSessionStarted(
  config: Config,
  event: ArenaSessionStartedEvent,
): void {
  QwenLogger.getInstance(config)?.logArenaSessionStartedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    model_ids: JSON.stringify(event.model_ids),
    'event.name': EVENT_ARENA_SESSION_STARTED,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Arena session started. Agents: ${event.model_ids.length}.`,
    attributes,
  };
  logger.emit(logRecord);
  recordArenaSessionStartedMetrics(config);
}

export function logArenaAgentCompleted(
  config: Config,
  event: ArenaAgentCompletedEvent,
): void {
  QwenLogger.getInstance(config)?.logArenaAgentCompletedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_ARENA_AGENT_COMPLETED,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Arena agent ${event.agent_model_id} ${event.status}. Duration: ${event.duration_ms}ms. Tokens: ${event.total_tokens}.`,
    attributes,
  };
  logger.emit(logRecord);
  recordArenaAgentCompletedMetrics(
    config,
    event.agent_model_id,
    event.status,
    event.duration_ms,
    event.input_tokens,
    event.output_tokens,
  );
}

export function logArenaSessionEnded(
  config: Config,
  event: ArenaSessionEndedEvent,
): void {
  QwenLogger.getInstance(config)?.logArenaSessionEndedEvent(event);
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    ...event,
    'event.name': EVENT_ARENA_SESSION_ENDED,
    'event.timestamp': new Date().toISOString(),
  };

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Arena session ended: ${event.status}.${event.winner_model_id ? ` Winner: ${event.winner_model_id}.` : ''}`,
    attributes,
  };
  logger.emit(logRecord);
  recordArenaSessionEndedMetrics(
    config,
    event.status,
    event.display_backend,
    event.duration_ms,
    event.winner_model_id,
  );
}

export function logPromptSuggestion(
  config: Config,
  event: PromptSuggestionEvent,
): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_PROMPT_SUGGESTION,
    'event.timestamp': event['event.timestamp'],
    outcome: event.outcome,
  };

  if (event.prompt_id) {
    attributes['prompt_id'] = event.prompt_id;
  }
  if (event.accept_method) {
    attributes['accept_method'] = event.accept_method;
  }
  if (event.accept_source) {
    attributes['accept_source'] = event.accept_source;
  }
  if (event.time_to_accept_ms !== undefined) {
    attributes['time_to_accept_ms'] = event.time_to_accept_ms;
  }
  if (event.time_to_ignore_ms !== undefined) {
    attributes['time_to_ignore_ms'] = event.time_to_ignore_ms;
  }
  if (event.time_to_first_keystroke_ms !== undefined) {
    attributes['time_to_first_keystroke_ms'] = event.time_to_first_keystroke_ms;
  }
  if (event.suggestion_length !== undefined) {
    attributes['suggestion_length'] = event.suggestion_length;
  }
  if (event.similarity !== undefined) {
    attributes['similarity'] = event.similarity;
  }
  if (event.was_focused_when_shown !== undefined) {
    attributes['was_focused_when_shown'] = event.was_focused_when_shown;
  }
  if (event.reason) {
    attributes['reason'] = event.reason;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Prompt suggestion: ${event.outcome}.`,
    attributes,
  };
  logger.emit(logRecord);
}

export function logSpeculation(config: Config, event: SpeculationEvent): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_SPECULATION,
    'event.timestamp': event['event.timestamp'],
    outcome: event.outcome,
    turns_used: event.turns_used,
    files_written: event.files_written,
    tool_use_count: event.tool_use_count,
    duration_ms: event.duration_ms,
    had_pipelined_suggestion: event.had_pipelined_suggestion,
  };

  if (event.boundary_type) {
    attributes['boundary_type'] = event.boundary_type;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  const logRecord: LogRecord = {
    body: `Speculation: ${event.outcome}.`,
    attributes,
  };
  logger.emit(logRecord);
}

// ─── Workflow Log Functions (#4721) ──────────────────────────────────────────

export function logWorkflowKeyword(
  config: Config,
  event: WorkflowKeywordEvent,
): void {
  if (!isTelemetrySdkInitialized()) return;
  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_WORKFLOW_KEYWORD,
    'event.timestamp': event['event.timestamp'],
  };
  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({ body: 'Workflow keyword trigger fired.', attributes });
}

export function logWorkflowRun(config: Config, event: WorkflowRunEvent): void {
  if (!isTelemetrySdkInitialized()) return;
  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_WORKFLOW_RUN,
    'event.timestamp': event['event.timestamp'],
    status: event.status,
    agents_dispatched: event.agents_dispatched,
    agents_completed: event.agents_completed,
    phase_count: event.phase_count,
    tokens_spent: event.tokens_spent,
    duration_ms: event.duration_ms,
  };
  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({ body: `Workflow run ${event.status}.`, attributes });
}

// ─── Auto-Memory Log Functions ───────────────────────────────────────────────

export function logMemoryExtract(
  config: Config,
  event: MemoryExtractEvent,
): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_MEMORY_EXTRACT,
    'event.timestamp': event['event.timestamp'],
    trigger: event.trigger,
    status: event.status,
    patches_count: event.patches_count,
    touched_topics: event.touched_topics,
    duration_ms: event.duration_ms,
  };
  if (event.skipped_reason) {
    attributes['skipped_reason'] = event.skipped_reason;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({
    body: `Memory extract: ${event.status}. Patches: ${event.patches_count}. Topics: ${event.touched_topics || 'none'}.`,
    attributes,
  });
  recordMemoryExtractMetrics(config, event.duration_ms, {
    trigger: event.trigger,
    status: event.status,
    patches_count: event.patches_count,
  });
}

export function logMemoryDream(config: Config, event: MemoryDreamEvent): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_MEMORY_DREAM,
    'event.timestamp': event['event.timestamp'],
    trigger: event.trigger,
    status: event.status,
    deduped_entries: event.deduped_entries,
    touched_topics_count: event.touched_topics_count,
    touched_topics: event.touched_topics,
    duration_ms: event.duration_ms,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({
    body: `Memory dream: ${event.status}. Deduped: ${event.deduped_entries}. Topics: ${event.touched_topics || 'none'}.`,
    attributes,
  });
  recordMemoryDreamMetrics(config, event.duration_ms, {
    trigger: event.trigger,
    status: event.status,
    deduped_entries: event.deduped_entries,
  });
}

export function logMemoryRecall(
  config: Config,
  event: MemoryRecallEvent,
): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_MEMORY_RECALL,
    'event.timestamp': event['event.timestamp'],
    query_length: event.query_length,
    docs_scanned: event.docs_scanned,
    docs_selected: event.docs_selected,
    strategy: event.strategy,
    duration_ms: event.duration_ms,
  };

  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({
    body: `Memory recall: strategy=${event.strategy}. Selected ${event.docs_selected}/${event.docs_scanned} docs.`,
    attributes,
  });
  recordMemoryRecallMetrics(config, event.duration_ms, {
    strategy: event.strategy,
    docs_selected: event.docs_selected,
  });
}

export function logMemoryRecallDelivery(
  config: Config,
  event: MemoryRecallDeliveryEvent,
): void {
  if (!isTelemetrySdkInitialized()) return;

  const attributes: LogAttributes = {
    ...getCommonAttributes(config),
    'event.name': EVENT_MEMORY_RECALL_DELIVERY,
    'event.timestamp': event['event.timestamp'],
    phase: event.phase,
    delivery_point: event.delivery_point,
    strategy: event.strategy,
    docs_selected: event.docs_selected,
    latency_ms: event.latency_ms,
  };
  if (event.discard_reason) {
    attributes['discard_reason'] = event.discard_reason;
  }

  const logger = logs.getLogger(SERVICE_NAME);
  logger.emit({
    body: `Memory recall delivery: phase=${event.phase}. delivery_point=${event.delivery_point}. Selected ${event.docs_selected} doc(s).`,
    attributes,
  });
  recordMemoryRecallDeliveryMetrics(config, event.latency_ms, {
    phase: event.phase,
    delivery_point: event.delivery_point,
    ...(event.discard_reason ? { discard_reason: event.discard_reason } : {}),
    strategy: event.strategy,
  });
}
