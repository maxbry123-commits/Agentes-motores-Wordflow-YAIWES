/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import type { Attributes, Meter, Counter, Histogram } from '@opentelemetry/api';
import { diag, metrics, ValueType } from '@opentelemetry/api';
import { SERVICE_NAME, EVENT_CHAT_COMPRESSION } from './constants.js';
import type { Config } from '../config/config.js';
import type { TelemetryRuntimeConfig } from './runtime-config.js';
import type {
  ModelSlashCommandEvent,
  MemoryRecallDeliveryPhase,
  MemoryRecallDeliveryPoint,
  MemoryRecallDiscardReason,
} from './types.js';
import type { ToolExecutionStatus } from '../core/turn.js';

const TOOL_CALL_COUNT = `${SERVICE_NAME}.tool.call.count`;
const TOOL_EXECUTION_COUNT = `${SERVICE_NAME}.tool.execution.count`;
export const REPEATED_TOOL_FAILURE_GUARD_COUNT = `${SERVICE_NAME}.repeated_tool_failure_guard.count`;
const TOOL_CALL_LATENCY = `${SERVICE_NAME}.tool.call.latency`;
const API_REQUEST_COUNT = `${SERVICE_NAME}.api.request.count`;
const API_REQUEST_LATENCY = `${SERVICE_NAME}.api.request.latency`;
const TOKEN_USAGE = `${SERVICE_NAME}.token.usage`;
const SESSION_COUNT = `${SERVICE_NAME}.session.count`;
const FILE_OPERATION_COUNT = `${SERVICE_NAME}.file.operation.count`;
const INVALID_CHUNK_COUNT = `${SERVICE_NAME}.chat.invalid_chunk.count`;
const CONTENT_RETRY_COUNT = `${SERVICE_NAME}.chat.content_retry.count`;
const CONTENT_RETRY_FAILURE_COUNT = `${SERVICE_NAME}.chat.content_retry_failure.count`;
// Phase 4b — Counts HTTP-status retries emitted by `retryWithBackoff` at LLM
// call sites. Tagged by `model` so operators can graph per-model retry rate.
const API_RETRY_COUNT = `${SERVICE_NAME}.api.retry.count`;
const MODEL_SLASH_COMMAND_CALL_COUNT = `${SERVICE_NAME}.slash_command.model.call_count`;
export const SUBAGENT_EXECUTION_COUNT = `${SERVICE_NAME}.subagent.execution.count`;

// Arena Metrics
const ARENA_SESSION_COUNT = `${SERVICE_NAME}.arena.session.count`;
const ARENA_SESSION_DURATION = `${SERVICE_NAME}.arena.session.duration`;
const ARENA_AGENT_COUNT = `${SERVICE_NAME}.arena.agent.count`;
const ARENA_AGENT_DURATION = `${SERVICE_NAME}.arena.agent.duration`;
const ARENA_AGENT_TOKENS = `${SERVICE_NAME}.arena.agent.tokens`;
const ARENA_RESULT_SELECTED = `${SERVICE_NAME}.arena.result.selected`;

// Performance Monitoring Metrics
const STARTUP_TIME = `${SERVICE_NAME}.startup.duration`;
const MEMORY_USAGE = `${SERVICE_NAME}.memory.usage`;
const CPU_USAGE = `${SERVICE_NAME}.cpu.usage`;
const TOOL_QUEUE_DEPTH = `${SERVICE_NAME}.tool.queue.depth`;
const TOOL_EXECUTION_BREAKDOWN = `${SERVICE_NAME}.tool.execution.breakdown`;
const TOKEN_EFFICIENCY = `${SERVICE_NAME}.token.efficiency`;
const API_REQUEST_BREAKDOWN = `${SERVICE_NAME}.api.request.breakdown`;
const PERFORMANCE_SCORE = `${SERVICE_NAME}.performance.score`;
const REGRESSION_DETECTION = `${SERVICE_NAME}.performance.regression`;
const REGRESSION_PERCENTAGE_CHANGE = `${SERVICE_NAME}.performance.regression.percentage_change`;
const BASELINE_COMPARISON = `${SERVICE_NAME}.performance.baseline.comparison`;

// Auto-Memory Metrics
const MEMORY_EXTRACT_COUNT = `${SERVICE_NAME}.memory.extract.count`;
const MEMORY_EXTRACT_DURATION = `${SERVICE_NAME}.memory.extract.duration`;
const MEMORY_DREAM_COUNT = `${SERVICE_NAME}.memory.dream.count`;
const MEMORY_DREAM_DURATION = `${SERVICE_NAME}.memory.dream.duration`;
const MEMORY_RECALL_COUNT = `${SERVICE_NAME}.memory.recall.count`;
const MEMORY_RECALL_DURATION = `${SERVICE_NAME}.memory.recall.duration`;
const CHANNEL_MEMORY_RECALL_COUNT = `${SERVICE_NAME}.channel.memory.recall.count`;
const CHANNEL_MEMORY_RECALL_DURATION = `${SERVICE_NAME}.channel.memory.recall.duration`;
const CHANNEL_MEMORY_RECALL_SELECTED_COUNT = `${SERVICE_NAME}.channel.memory.recall.selected_count`;
const MEMORY_RECALL_DELIVERY_COUNT = `${SERVICE_NAME}.memory.recall.delivery.count`;
const MEMORY_RECALL_DELIVERY_LATENCY = `${SERVICE_NAME}.memory.recall.delivery.latency`;

const baseMetricDefinition = {
  // session.id on metrics is opt-in: each session is a new value, so
  // attaching it by default would create unbounded time-series fan-out on
  // every metric backend. Operators who need session-level metric slicing
  // can enable QWEN_TELEMETRY_METRICS_INCLUDE_SESSION_ID or
  // telemetry.metrics.includeSessionId. Spans and logs always carry
  // session.id for trace/log correlation.
  getCommonAttributes: (config: TelemetryRuntimeConfig): Attributes => {
    const out: Attributes = {};
    if (config.getTelemetryMetricsIncludeSessionId()) {
      out['session.id'] = config.getSessionId();
    }
    return out;
  },
};

const COUNTER_DEFINITIONS = {
  [TOOL_CALL_COUNT]: {
    description:
      'Counts tool calls, tagged by function name and terminal status.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (toolCallCounter = c),
    attributes: {} as {
      function_name: string;
      success: boolean;
      status?: 'success' | 'error' | 'cancelled';
      decision?: 'accept' | 'reject' | 'modify' | 'auto_accept';
      tool_type?: 'native' | 'mcp';
    },
  },
  [TOOL_EXECUTION_COUNT]: {
    description: 'Counts tool execution outcomes.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (toolExecutionCounter = c),
    attributes: {} as {
      execution_status: ToolExecutionStatus | 'unknown';
      tool_type: 'native' | 'mcp';
    },
  },
  [REPEATED_TOOL_FAILURE_GUARD_COUNT]: {
    description:
      'Counts privacy-safe repeated tool execution failure guard transitions.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (repeatedToolFailureGuardCounter = c),
    attributes: {} as {
      route: 'acp_foreground';
      mode: 'shadow' | 'warn' | 'enforce';
      phase_before: 'idle' | 'tracking' | 'warned' | 'latched';
      phase_after: 'idle' | 'tracking' | 'warned' | 'latched';
      decision:
        | 'reset'
        | 'tracked'
        | 'would_warn'
        | 'warned'
        | 'would_stop'
        | 'stopped';
      failure_count_bucket: '0' | '1-2' | '3-4' | '5-7' | '8+';
      batch_count_bucket: '0' | '1' | '2' | '3+';
      reset_reason?:
        | 'success'
        | 'cancelled'
        | 'not_started'
        | 'post_execution_failure'
        | 'unknown'
        | 'mixed'
        | 'incomplete'
        | 'external_input'
        | 'queued_prompt'
        | 'unreliable_input'
        | 'contract_violation';
      terminal_status?: 'error';
      execution_status?: 'error';
      tool_type?: 'native' | 'mcp';
    },
  },
  [API_REQUEST_COUNT]: {
    description: 'Counts API requests, tagged by model and status.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (apiRequestCounter = c),
    attributes: {} as {
      model: string;
      status_code?: number | string;
      error_type?: string;
    },
  },
  [TOKEN_USAGE]: {
    description: 'Counts the total number of tokens used.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (tokenUsageCounter = c),
    attributes: {} as {
      model: string;
      type: 'input' | 'output' | 'thought' | 'cache';
    },
  },
  [SESSION_COUNT]: {
    description: 'Count of CLI sessions started.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (sessionCounter = c),
    attributes: {} as Record<string, never>,
  },
  [FILE_OPERATION_COUNT]: {
    description: 'Counts file operations (create, read, update).',
    valueType: ValueType.INT,
    assign: (c: Counter) => (fileOperationCounter = c),
    attributes: {} as {
      operation: FileOperation;
      lines?: number;
      mimetype?: string;
      extension?: string;
      programming_language?: string;
    },
  },
  [INVALID_CHUNK_COUNT]: {
    description: 'Counts invalid chunks received from a stream.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (invalidChunkCounter = c),
    attributes: {} as Record<string, never>,
  },
  [CONTENT_RETRY_COUNT]: {
    description: 'Counts retries due to content errors (e.g., empty stream).',
    valueType: ValueType.INT,
    assign: (c: Counter) => (contentRetryCounter = c),
    attributes: {} as Record<string, never>,
  },
  [CONTENT_RETRY_FAILURE_COUNT]: {
    description: 'Counts occurrences of all content retries failing.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (contentRetryFailureCounter = c),
    attributes: {} as Record<string, never>,
  },
  [API_RETRY_COUNT]: {
    description:
      'Counts HTTP-status retries (429/5xx) at LLM call sites, emitted by retryWithBackoff onRetry callback.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (apiRetryCounter = c),
    attributes: {} as {
      model: string;
    },
  },
  [MODEL_SLASH_COMMAND_CALL_COUNT]: {
    description: 'Counts model slash command calls.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (modelSlashCommandCallCounter = c),
    attributes: {} as {
      'slash_command.model.model_name': string;
    },
  },
  [EVENT_CHAT_COMPRESSION]: {
    description: 'Counts chat compression events.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (chatCompressionCounter = c),
    attributes: {} as {
      tokens_before: number;
      tokens_after: number;
    },
  },
} as const;

const HISTOGRAM_DEFINITIONS = {
  [TOOL_CALL_LATENCY]: {
    description: 'Latency of tool calls in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (toolCallLatencyHistogram = h),
    attributes: {} as {
      function_name: string;
    },
  },
  [API_REQUEST_LATENCY]: {
    description: 'Latency of API requests in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (apiRequestLatencyHistogram = h),
    attributes: {} as {
      model: string;
    },
  },
} as const;

const PERFORMANCE_COUNTER_DEFINITIONS = {
  [REGRESSION_DETECTION]: {
    description: 'Performance regression detection events.',
    valueType: ValueType.INT,
    assign: (c: Counter) => (regressionDetectionCounter = c),
    attributes: {} as {
      metric: string;
      severity: 'low' | 'medium' | 'high';
      current_value: number;
      baseline_value: number;
    },
  },
} as const;

const PERFORMANCE_HISTOGRAM_DEFINITIONS = {
  [STARTUP_TIME]: {
    description:
      'CLI startup time in milliseconds, broken down by initialization phase.',
    unit: 'ms',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (startupTimeHistogram = h),
    attributes: {} as {
      phase: string;
      details?: Record<string, string | number | boolean>;
    },
  },
  [MEMORY_USAGE]: {
    description: 'Memory usage in bytes.',
    unit: 'bytes',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (memoryUsageGauge = h),
    attributes: {} as {
      memory_type: MemoryMetricType;
      component?: string;
    },
  },
  [CPU_USAGE]: {
    description: 'CPU usage percentage.',
    unit: 'percent',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (cpuUsageGauge = h),
    attributes: {} as {
      component?: string;
    },
  },
  [TOOL_QUEUE_DEPTH]: {
    description: 'Number of tools in execution queue.',
    unit: 'count',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (toolQueueDepthGauge = h),
    attributes: {} as Record<string, never>,
  },
  [TOOL_EXECUTION_BREAKDOWN]: {
    description: 'Tool execution time breakdown by phase in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (toolExecutionBreakdownHistogram = h),
    attributes: {} as {
      function_name: string;
      phase: ToolExecutionPhase;
    },
  },
  [TOKEN_EFFICIENCY]: {
    description:
      'Token efficiency metrics (tokens per operation, cache hit rate, etc.).',
    unit: 'ratio',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (tokenEfficiencyHistogram = h),
    attributes: {} as {
      model: string;
      metric: string;
      context?: string;
    },
  },
  [API_REQUEST_BREAKDOWN]: {
    description: 'API request time breakdown by phase in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
    assign: (h: Histogram) => (apiRequestBreakdownHistogram = h),
    attributes: {} as {
      model: string;
      phase: ApiRequestPhase;
    },
  },
  [PERFORMANCE_SCORE]: {
    description: 'Composite performance score (0-100).',
    unit: 'score',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (performanceScoreGauge = h),
    attributes: {} as {
      category: string;
      baseline?: number;
    },
  },
  [REGRESSION_PERCENTAGE_CHANGE]: {
    description:
      'Percentage change compared to baseline for detected regressions.',
    unit: 'percent',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (regressionPercentageChangeHistogram = h),
    attributes: {} as {
      metric: string;
      severity: 'low' | 'medium' | 'high';
      current_value: number;
      baseline_value: number;
    },
  },
  [BASELINE_COMPARISON]: {
    description:
      'Performance comparison to established baseline (percentage change).',
    unit: 'percent',
    valueType: ValueType.DOUBLE,
    assign: (h: Histogram) => (baselineComparisonHistogram = h),
    attributes: {} as {
      metric: string;
      category: string;
      current_value: number;
      baseline_value: number;
    },
  },
} as const;

type AllMetricDefs = typeof COUNTER_DEFINITIONS &
  typeof HISTOGRAM_DEFINITIONS &
  typeof PERFORMANCE_COUNTER_DEFINITIONS &
  typeof PERFORMANCE_HISTOGRAM_DEFINITIONS;

export type MetricDefinitions = {
  [K in keyof AllMetricDefs]: {
    attributes: AllMetricDefs[K]['attributes'];
  };
};

export enum FileOperation {
  CREATE = 'create',
  READ = 'read',
  UPDATE = 'update',
}

export enum PerformanceMetricType {
  STARTUP = 'startup',
  MEMORY = 'memory',
  CPU = 'cpu',
  TOOL_EXECUTION = 'tool_execution',
  API_REQUEST = 'api_request',
  TOKEN_EFFICIENCY = 'token_efficiency',
}

export enum MemoryMetricType {
  HEAP_USED = 'heap_used',
  HEAP_TOTAL = 'heap_total',
  EXTERNAL = 'external',
  RSS = 'rss',
}

export enum ToolExecutionPhase {
  VALIDATION = 'validation',
  PREPARATION = 'preparation',
  EXECUTION = 'execution',
  RESULT_PROCESSING = 'result_processing',
}

export enum ApiRequestPhase {
  REQUEST_PREPARATION = 'request_preparation',
  NETWORK_LATENCY = 'network_latency',
  RESPONSE_PROCESSING = 'response_processing',
  TOKEN_PROCESSING = 'token_processing',
}

let cliMeter: Meter | undefined;
let toolCallCounter: Counter | undefined;
let toolExecutionCounter: Counter | undefined;
let repeatedToolFailureGuardCounter: Counter | undefined;
let toolCallLatencyHistogram: Histogram | undefined;
let apiRequestCounter: Counter | undefined;
let apiRequestLatencyHistogram: Histogram | undefined;
let tokenUsageCounter: Counter | undefined;
let sessionCounter: Counter | undefined;
let fileOperationCounter: Counter | undefined;
let chatCompressionCounter: Counter | undefined;
let invalidChunkCounter: Counter | undefined;
let contentRetryCounter: Counter | undefined;
let contentRetryFailureCounter: Counter | undefined;
let apiRetryCounter: Counter | undefined;
let subagentExecutionCounter: Counter | undefined;
let modelSlashCommandCallCounter: Counter | undefined;

// Performance Monitoring Metrics
let startupTimeHistogram: Histogram | undefined;
let memoryUsageGauge: Histogram | undefined; // Using Histogram until ObservableGauge is available
let cpuUsageGauge: Histogram | undefined;
let toolQueueDepthGauge: Histogram | undefined;
let toolExecutionBreakdownHistogram: Histogram | undefined;
let tokenEfficiencyHistogram: Histogram | undefined;
let apiRequestBreakdownHistogram: Histogram | undefined;
let performanceScoreGauge: Histogram | undefined;
let regressionDetectionCounter: Counter | undefined;
let regressionPercentageChangeHistogram: Histogram | undefined;
let baselineComparisonHistogram: Histogram | undefined;
// Arena Metrics
let arenaSessionCounter: Counter | undefined;
let arenaSessionDurationHistogram: Histogram | undefined;
let arenaAgentCounter: Counter | undefined;
let arenaAgentDurationHistogram: Histogram | undefined;
let arenaAgentTokensCounter: Counter | undefined;
let arenaResultSelectedCounter: Counter | undefined;

// Auto-Memory Metrics
let memoryExtractCounter: Counter | undefined;
let memoryExtractDurationHistogram: Histogram | undefined;
let memoryDreamCounter: Counter | undefined;
let memoryDreamDurationHistogram: Histogram | undefined;
let memoryRecallCounter: Counter | undefined;
let memoryRecallDurationHistogram: Histogram | undefined;
let channelMemoryRecallCounter: Counter | undefined;
let channelMemoryRecallDurationHistogram: Histogram | undefined;
let channelMemoryRecallSelectedCountHistogram: Histogram | undefined;
let memoryRecallDeliveryCounter: Counter | undefined;
let memoryRecallDeliveryLatencyHistogram: Histogram | undefined;

let isMetricsInitialized = false;
let isPerformanceMonitoringEnabled = false;

export function getMeter(): Meter | undefined {
  if (!cliMeter) {
    cliMeter = metrics.getMeter(SERVICE_NAME);
  }
  return cliMeter;
}

export function initializeMetrics(config: TelemetryRuntimeConfig): void {
  if (isMetricsInitialized) return;

  const meter = getMeter();
  if (!meter) return;

  // Initialize core metrics
  Object.entries(COUNTER_DEFINITIONS).forEach(
    ([name, { description, valueType, assign }]) => {
      assign(meter.createCounter(name, { description, valueType }));
    },
  );
  subagentExecutionCounter = meter.createCounter(SUBAGENT_EXECUTION_COUNT, {
    description:
      'Counts subagent execution events, tagged by status and subagent name.',
    valueType: ValueType.INT,
  });

  // Arena metrics
  arenaSessionCounter = meter.createCounter(ARENA_SESSION_COUNT, {
    description: 'Counts arena sessions by status and display backend.',
    valueType: ValueType.INT,
  });
  arenaSessionDurationHistogram = meter.createHistogram(
    ARENA_SESSION_DURATION,
    {
      description: 'Duration of arena sessions in milliseconds.',
      unit: 'ms',
      valueType: ValueType.INT,
    },
  );
  arenaAgentCounter = meter.createCounter(ARENA_AGENT_COUNT, {
    description: 'Counts arena agent completions by status and model.',
    valueType: ValueType.INT,
  });
  arenaAgentDurationHistogram = meter.createHistogram(ARENA_AGENT_DURATION, {
    description: 'Duration of arena agent execution in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
  });
  arenaAgentTokensCounter = meter.createCounter(ARENA_AGENT_TOKENS, {
    description: 'Token usage by arena agents.',
    valueType: ValueType.INT,
  });
  arenaResultSelectedCounter = meter.createCounter(ARENA_RESULT_SELECTED, {
    description: 'Counts arena result selections by model.',
    valueType: ValueType.INT,
  });

  Object.entries(HISTOGRAM_DEFINITIONS).forEach(
    ([name, { description, unit, valueType, assign }]) => {
      assign(meter.createHistogram(name, { description, unit, valueType }));
    },
  );

  // Increment session counter after all metrics are initialized
  sessionCounter?.add(1, baseMetricDefinition.getCommonAttributes(config));

  // Auto-Memory metrics
  memoryExtractCounter = meter.createCounter(MEMORY_EXTRACT_COUNT, {
    description:
      'Counts auto-memory extraction runs, tagged by trigger and status.',
    valueType: ValueType.INT,
  });
  memoryExtractDurationHistogram = meter.createHistogram(
    MEMORY_EXTRACT_DURATION,
    {
      description: 'Duration of auto-memory extraction in milliseconds.',
      unit: 'ms',
      valueType: ValueType.INT,
    },
  );
  memoryDreamCounter = meter.createCounter(MEMORY_DREAM_COUNT, {
    description:
      'Counts auto-memory dream (consolidation) runs, tagged by trigger and status.',
    valueType: ValueType.INT,
  });
  memoryDreamDurationHistogram = meter.createHistogram(MEMORY_DREAM_DURATION, {
    description: 'Duration of auto-memory dream runs in milliseconds.',
    unit: 'ms',
    valueType: ValueType.INT,
  });
  memoryRecallCounter = meter.createCounter(MEMORY_RECALL_COUNT, {
    description: 'Counts auto-memory recall operations, tagged by strategy.',
    valueType: ValueType.INT,
  });
  memoryRecallDurationHistogram = meter.createHistogram(
    MEMORY_RECALL_DURATION,
    {
      description: 'Duration of auto-memory recall operations in milliseconds.',
      unit: 'ms',
      valueType: ValueType.INT,
    },
  );
  channelMemoryRecallCounter = meter.createCounter(
    CHANNEL_MEMORY_RECALL_COUNT,
    {
      description:
        'Counts channel memory recall attempts by cache path and bounded result.',
      valueType: ValueType.INT,
    },
  );
  channelMemoryRecallDurationHistogram = meter.createHistogram(
    CHANNEL_MEMORY_RECALL_DURATION,
    {
      description: 'Duration of channel memory recall attempts.',
      unit: 'ms',
      valueType: ValueType.DOUBLE,
      advice: {
        explicitBucketBoundaries: [0.1, 0.5, 1, 2, 5, 10, 25, 50, 100, 250],
      },
    },
  );
  channelMemoryRecallSelectedCountHistogram = meter.createHistogram(
    CHANNEL_MEMORY_RECALL_SELECTED_COUNT,
    {
      description: 'Number of channel memory entries selected per attempt.',
      valueType: ValueType.INT,
    },
  );
  memoryRecallDeliveryCounter = meter.createCounter(
    MEMORY_RECALL_DELIVERY_COUNT,
    {
      description:
        'Counts auto-memory recall delivery outcomes, tagged by phase and delivery point.',
      valueType: ValueType.INT,
    },
  );
  memoryRecallDeliveryLatencyHistogram = meter.createHistogram(
    MEMORY_RECALL_DELIVERY_LATENCY,
    {
      description:
        'Latency from auto-memory recall prefetch start to delivery or discard.',
      unit: 'ms',
      valueType: ValueType.INT,
    },
  );
  // Initialize performance monitoring metrics if enabled
  initializePerformanceMonitoring(config);

  isMetricsInitialized = true;
}

export function recordChatCompressionMetrics(
  config: Config,
  attributes: MetricDefinitions[typeof EVENT_CHAT_COMPRESSION]['attributes'],
) {
  if (!chatCompressionCounter || !isMetricsInitialized) return;
  chatCompressionCounter.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  });
}

export function recordToolCallMetrics(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof TOOL_CALL_COUNT]['attributes'],
): void {
  if (!toolCallCounter || !toolCallLatencyHistogram || !isMetricsInitialized)
    return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
    status: attributes.status ?? (attributes.success ? 'success' : 'error'),
  };
  toolCallCounter.add(1, metricAttributes);
  toolCallLatencyHistogram.record(durationMs, {
    ...baseMetricDefinition.getCommonAttributes(config),
    function_name: attributes.function_name,
  });
}

export function recordToolExecutionMetrics(
  config: TelemetryRuntimeConfig,
  attributes: MetricDefinitions[typeof TOOL_EXECUTION_COUNT]['attributes'],
): void {
  if (!toolExecutionCounter || !isMetricsInitialized) return;
  toolExecutionCounter.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  });
}

export function recordRepeatedToolFailureGuardMetrics(
  attributes: MetricDefinitions[typeof REPEATED_TOOL_FAILURE_GUARD_COUNT]['attributes'],
): void {
  if (!repeatedToolFailureGuardCounter || !isMetricsInitialized) return;
  repeatedToolFailureGuardCounter.add(1, attributes);
}

export function recordTokenUsageMetrics(
  config: Config,
  tokenCount: number,
  attributes: MetricDefinitions[typeof TOKEN_USAGE]['attributes'],
): void {
  if (!tokenUsageCounter || !isMetricsInitialized) return;
  tokenUsageCounter.add(tokenCount, {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  });
}

export function recordApiResponseMetrics(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof API_REQUEST_COUNT]['attributes'],
): void {
  if (
    !apiRequestCounter ||
    !apiRequestLatencyHistogram ||
    !isMetricsInitialized
  )
    return;
  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    model: attributes.model,
    status_code: attributes.status_code ?? 'ok',
  };
  apiRequestCounter.add(1, metricAttributes);
  apiRequestLatencyHistogram.record(durationMs, {
    ...baseMetricDefinition.getCommonAttributes(config),
    model: attributes.model,
  });
}

export function recordApiErrorMetrics(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof API_REQUEST_COUNT]['attributes'],
): void {
  if (
    !apiRequestCounter ||
    !apiRequestLatencyHistogram ||
    !isMetricsInitialized
  )
    return;
  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    model: attributes.model,
    status_code: attributes.status_code ?? 'error',
    error_type: attributes.error_type ?? 'unknown',
  };
  apiRequestCounter.add(1, metricAttributes);
  apiRequestLatencyHistogram.record(durationMs, {
    ...baseMetricDefinition.getCommonAttributes(config),
    model: attributes.model,
  });
}

export function recordFileOperationMetric(
  config: Config,
  attributes: MetricDefinitions[typeof FILE_OPERATION_COUNT]['attributes'],
): void {
  if (!fileOperationCounter || !isMetricsInitialized) return;
  fileOperationCounter.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  });
}

// --- New Metric Recording Functions ---

/**
 * Records a metric for when an invalid chunk is received from a stream.
 */
export function recordInvalidChunk(config: Config): void {
  if (!invalidChunkCounter || !isMetricsInitialized) return;
  invalidChunkCounter.add(1, baseMetricDefinition.getCommonAttributes(config));
}

/**
 * Records a metric for when a retry is triggered due to a content error.
 */
export function recordContentRetry(config: Config): void {
  if (!contentRetryCounter || !isMetricsInitialized) return;
  contentRetryCounter.add(1, baseMetricDefinition.getCommonAttributes(config));
}

/**
 * Records a metric for when all content error retries have failed for a request.
 */
export function recordContentRetryFailure(config: Config): void {
  if (!contentRetryFailureCounter || !isMetricsInitialized) return;
  contentRetryFailureCounter.add(
    1,
    baseMetricDefinition.getCommonAttributes(config),
  );
}

/**
 * Phase 4b — Records a metric for an HTTP-status retry at an LLM call site.
 * Tagged by `model` so operators can graph per-model retry rate. Called from
 * `logApiRetry` in loggers.ts which is wired to `retryWithBackoff`'s `onRetry`
 * callback at the 4 LLM call sites.
 */
export function recordApiRetry(
  config: Config,
  attributes: MetricDefinitions[typeof API_RETRY_COUNT]['attributes'],
): void {
  if (!apiRetryCounter || !isMetricsInitialized) return;
  apiRetryCounter.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  });
}

export function recordModelSlashCommand(
  config: Config,
  event: ModelSlashCommandEvent,
): void {
  if (!modelSlashCommandCallCounter || !isMetricsInitialized) return;
  modelSlashCommandCallCounter.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    'slash_command.model.model_name': event.model_name,
  });
}

// Performance Monitoring Functions

export function initializePerformanceMonitoring(
  config: TelemetryRuntimeConfig,
): void {
  const meter = getMeter();
  if (!meter) return;

  // Check if performance monitoring is enabled in config
  // For now, enable performance monitoring when telemetry is enabled
  // TODO: Add specific performance monitoring settings to config
  isPerformanceMonitoringEnabled = config.getTelemetryEnabled();

  if (!isPerformanceMonitoringEnabled) return;

  Object.entries(PERFORMANCE_COUNTER_DEFINITIONS).forEach(
    ([name, { description, valueType, assign }]) => {
      assign(meter.createCounter(name, { description, valueType }));
    },
  );

  Object.entries(PERFORMANCE_HISTOGRAM_DEFINITIONS).forEach(
    ([name, { description, unit, valueType, assign }]) => {
      assign(meter.createHistogram(name, { description, unit, valueType }));
    },
  );
}

export function recordStartupPerformance(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof STARTUP_TIME]['attributes'],
): void {
  if (!startupTimeHistogram || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    phase: attributes.phase,
    ...attributes.details,
  };

  startupTimeHistogram.record(durationMs, metricAttributes);
}

export function recordMemoryUsage(
  config: Config,
  bytes: number,
  attributes: MetricDefinitions[typeof MEMORY_USAGE]['attributes'],
): void {
  if (!memoryUsageGauge || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  memoryUsageGauge.record(bytes, metricAttributes);
}

export function recordCpuUsage(
  config: Config,
  percentage: number,
  attributes: MetricDefinitions[typeof CPU_USAGE]['attributes'],
): void {
  if (!cpuUsageGauge || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  cpuUsageGauge.record(percentage, metricAttributes);
}

export function recordToolQueueDepth(config: Config, queueDepth: number): void {
  if (!toolQueueDepthGauge || !isPerformanceMonitoringEnabled) return;

  const attributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
  };

  toolQueueDepthGauge.record(queueDepth, attributes);
}

export function recordToolExecutionBreakdown(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof TOOL_EXECUTION_BREAKDOWN]['attributes'],
): void {
  if (!toolExecutionBreakdownHistogram || !isPerformanceMonitoringEnabled)
    return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  toolExecutionBreakdownHistogram.record(durationMs, metricAttributes);
}

export function recordTokenEfficiency(
  config: Config,
  value: number,
  attributes: MetricDefinitions[typeof TOKEN_EFFICIENCY]['attributes'],
): void {
  if (!tokenEfficiencyHistogram || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  tokenEfficiencyHistogram.record(value, metricAttributes);
}

export function recordApiRequestBreakdown(
  config: Config,
  durationMs: number,
  attributes: MetricDefinitions[typeof API_REQUEST_BREAKDOWN]['attributes'],
): void {
  if (!apiRequestBreakdownHistogram || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  apiRequestBreakdownHistogram.record(durationMs, metricAttributes);
}

export function recordPerformanceScore(
  config: Config,
  score: number,
  attributes: MetricDefinitions[typeof PERFORMANCE_SCORE]['attributes'],
): void {
  if (!performanceScoreGauge || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  performanceScoreGauge.record(score, metricAttributes);
}

export function recordPerformanceRegression(
  config: Config,
  attributes: MetricDefinitions[typeof REGRESSION_DETECTION]['attributes'],
): void {
  if (!regressionDetectionCounter || !isPerformanceMonitoringEnabled) return;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  regressionDetectionCounter.add(1, metricAttributes);

  if (attributes.baseline_value !== 0 && regressionPercentageChangeHistogram) {
    const percentageChange =
      ((attributes.current_value - attributes.baseline_value) /
        attributes.baseline_value) *
      100;
    regressionPercentageChangeHistogram.record(
      percentageChange,
      metricAttributes,
    );
  }
}

export function recordBaselineComparison(
  config: Config,
  attributes: MetricDefinitions[typeof BASELINE_COMPARISON]['attributes'],
): void {
  if (!baselineComparisonHistogram || !isPerformanceMonitoringEnabled) return;

  if (attributes.baseline_value === 0) {
    diag.warn('Baseline value is zero, skipping comparison.');
    return;
  }
  const percentageChange =
    ((attributes.current_value - attributes.baseline_value) /
      attributes.baseline_value) *
    100;

  const metricAttributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    ...attributes,
  };

  baselineComparisonHistogram.record(percentageChange, metricAttributes);
}

// Utility function to check if performance monitoring is enabled
export function isPerformanceMonitoringActive(): boolean {
  return isPerformanceMonitoringEnabled && isMetricsInitialized;
}

/**
 * Records a metric for subagent execution events.
 */
export function recordSubagentExecutionMetrics(
  config: Config,
  subagentName: string,
  status: 'started' | 'completed' | 'failed' | 'cancelled',
  terminateReason?: string,
): void {
  if (!subagentExecutionCounter || !isMetricsInitialized) return;

  const attributes: Attributes = {
    ...baseMetricDefinition.getCommonAttributes(config),
    subagent_name: subagentName,
    status,
  };

  if (terminateReason) {
    attributes['terminate_reason'] = terminateReason;
  }

  subagentExecutionCounter.add(1, attributes);
}

// ─── Arena Metric Recording Functions ───────────────────────────

export function recordArenaSessionStartedMetrics(config: Config): void {
  if (!isMetricsInitialized) return;
  arenaSessionCounter?.add(1, {
    ...baseMetricDefinition.getCommonAttributes(config),
    status: 'started',
  });
}

export function recordArenaAgentCompletedMetrics(
  config: Config,
  modelId: string,
  status: string,
  durationMs: number,
  inputTokens: number,
  outputTokens: number,
): void {
  if (!isMetricsInitialized) return;

  const common = baseMetricDefinition.getCommonAttributes(config);

  arenaAgentCounter?.add(1, {
    ...common,
    status,
    model_id: modelId,
  });

  arenaAgentDurationHistogram?.record(durationMs, {
    ...common,
    model_id: modelId,
  });

  if (inputTokens > 0) {
    arenaAgentTokensCounter?.add(inputTokens, {
      ...common,
      model_id: modelId,
      type: 'input',
    });
  }

  if (outputTokens > 0) {
    arenaAgentTokensCounter?.add(outputTokens, {
      ...common,
      model_id: modelId,
      type: 'output',
    });
  }
}

export function recordArenaSessionEndedMetrics(
  config: Config,
  status: string,
  displayBackend?: string,
  durationMs?: number,
  winnerModelId?: string,
): void {
  if (!isMetricsInitialized) return;

  const common = baseMetricDefinition.getCommonAttributes(config);

  arenaSessionCounter?.add(1, {
    ...common,
    status,
    ...(displayBackend ? { display_backend: displayBackend } : {}),
  });

  if (durationMs !== undefined && arenaSessionDurationHistogram) {
    arenaSessionDurationHistogram.record(durationMs, {
      ...common,
      status,
    });
  }

  if (winnerModelId) {
    arenaResultSelectedCounter?.add(1, {
      ...common,
      model_id: winnerModelId,
    });
  }
}

// ─── Auto-Memory Metric Recording Functions ─────────────────────────────────

export function recordMemoryExtractMetrics(
  config: Config,
  durationMs: number,
  attrs: {
    trigger: 'auto' | 'manual';
    status: 'completed' | 'skipped' | 'failed';
    patches_count: number;
  },
): void {
  if (!isMetricsInitialized) return;
  const common = baseMetricDefinition.getCommonAttributes(config);
  memoryExtractCounter?.add(1, {
    ...common,
    trigger: attrs.trigger,
    status: attrs.status,
  });
  memoryExtractDurationHistogram?.record(durationMs, {
    ...common,
    trigger: attrs.trigger,
    status: attrs.status,
  });
}

export function recordMemoryDreamMetrics(
  config: Config,
  durationMs: number,
  attrs: {
    trigger: 'auto' | 'manual';
    status: 'updated' | 'noop' | 'failed' | 'cancelled';
    deduped_entries: number;
  },
): void {
  if (!isMetricsInitialized) return;
  const common = baseMetricDefinition.getCommonAttributes(config);
  memoryDreamCounter?.add(1, {
    ...common,
    trigger: attrs.trigger,
    status: attrs.status,
  });
  memoryDreamDurationHistogram?.record(durationMs, {
    ...common,
    trigger: attrs.trigger,
    status: attrs.status,
  });
}

export function recordMemoryRecallMetrics(
  config: Config,
  durationMs: number,
  attrs: { strategy: 'none' | 'heuristic' | 'model'; docs_selected: number },
): void {
  if (!isMetricsInitialized) return;
  const common = baseMetricDefinition.getCommonAttributes(config);
  memoryRecallCounter?.add(1, { ...common, strategy: attrs.strategy });
  memoryRecallDurationHistogram?.record(durationMs, {
    ...common,
    strategy: attrs.strategy,
  });
}

export function recordChannelMemoryRecallMetrics(observation: {
  durationMs: number;
  cache: 'hit' | 'miss' | 'bypass';
  result: 'selected' | 'empty' | 'stale' | 'read_error' | 'revision_unstable';
  selectedCount: number;
}): void {
  if (!isMetricsInitialized) return;
  const attributes = {
    cache: observation.cache,
    result: observation.result,
  };
  channelMemoryRecallCounter?.add(1, attributes);
  channelMemoryRecallDurationHistogram?.record(
    observation.durationMs,
    attributes,
  );
  channelMemoryRecallSelectedCountHistogram?.record(
    observation.selectedCount,
    attributes,
  );
}

export function recordMemoryRecallDeliveryMetrics(
  config: Config,
  latencyMs: number,
  attrs: {
    phase: MemoryRecallDeliveryPhase;
    delivery_point: MemoryRecallDeliveryPoint;
    discard_reason?: MemoryRecallDiscardReason;
    strategy: 'none' | 'heuristic' | 'model';
  },
): void {
  if (!isMetricsInitialized) return;
  const common = baseMetricDefinition.getCommonAttributes(config);
  const metricAttributes = {
    ...common,
    phase: attrs.phase,
    delivery_point: attrs.delivery_point,
    strategy: attrs.strategy,
    ...(attrs.discard_reason ? { discard_reason: attrs.discard_reason } : {}),
  };
  memoryRecallDeliveryCounter?.add(1, metricAttributes);
  memoryRecallDeliveryLatencyHistogram?.record(latencyMs, metricAttributes);
}
