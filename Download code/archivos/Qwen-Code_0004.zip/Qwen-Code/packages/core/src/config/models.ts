/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

export { DEFAULT_QWEN_MODEL } from '../utils/default-qwen-model.js';
export const DEFAULT_QWEN_FLASH_MODEL = 'coder-model';
export const DEFAULT_QWEN_EMBEDDING_MODEL = 'text-embedding-v4';
export const MAINLINE_CODER_MODEL = 'qwen3.7-max';
