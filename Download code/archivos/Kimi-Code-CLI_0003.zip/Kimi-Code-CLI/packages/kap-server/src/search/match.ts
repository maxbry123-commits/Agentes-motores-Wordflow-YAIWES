import { createHash } from 'node:crypto';

import { normalizeLiteral } from '@moonshot-ai/minidb';

import {
  GlobalSearchError,
  type GlobalSearchIncomplete,
  type GlobalSearchSource,
} from './contract.ts';
import type { MessageDoc, SearchDoc, TitleDoc } from './docs.ts';

export interface NormalizedQuery {
  readonly query: string;
  readonly mode: 'terms' | 'literal';
  readonly literalQuery?: string;
  readonly termsQuery?: readonly string[];
  readonly op: 'AND' | 'OR';
  readonly container?: { readonly sessionId?: string; readonly agentId?: string };
  readonly role?: 'user' | 'assistant' | 'title';
  readonly startTime?: number;
  readonly endTime?: number;
  readonly sort: 'score' | 'time_desc' | 'time_asc';
  readonly pageSize: number;
}

export interface SearchBudgets {
  readonly literalCandidateCap: number;
  readonly maxTextHits: number;
  readonly postingsVisitBudget: number;
  readonly queryDeadlineMs: number;
  readonly queryTextBudgetChars: number;
}

export type SortBoundary = readonly (number | string)[];

export type DecodedPage =
  | { readonly kind: 'first' }
  | { readonly kind: 'keyset'; readonly boundary: SortBoundary }
  | { readonly kind: 'legacy'; readonly skip: number };

export function boundaryWidth(q: NormalizedQuery): 2 | 3 {
  return q.mode !== 'literal' && q.sort === 'score' ? 3 : 2;
}

export interface MatchedRow {
  readonly key: string;
  readonly value: MessageDoc | TitleDoc;
  readonly score: number;
  readonly anchor?: number;
}

export interface MatchBudget {
  readonly deadlineAt: number;
  textCharsLeft: number;
}

function cmpKey(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

export function compareRows(q: NormalizedQuery, a: MatchedRow, b: MatchedRow): number {
  if (q.mode !== 'literal' && q.sort === 'score') {
    return b.score - a.score || b.value.time - a.value.time || cmpKey(a.key, b.key);
  }
  if (q.mode !== 'literal' && q.sort === 'time_asc') {
    return a.value.time - b.value.time || cmpKey(a.key, b.key);
  }
  return b.value.time - a.value.time || cmpKey(a.key, b.key);
}

export function boundaryOf(q: NormalizedQuery, row: MatchedRow): SortBoundary {
  return boundaryWidth(q) === 3 ? [row.score, row.value.time, row.key] : [row.value.time, row.key];
}

function rowAfterBoundary(q: NormalizedQuery, row: MatchedRow, boundary: SortBoundary): boolean {
  let cmp: number;
  if (boundary.length === 3) {
    const [bs, bt, bk] = boundary as readonly [number, number, string];
    cmp = bs - row.score || bt - row.value.time || cmpKey(row.key, bk);
  } else {
    const [bt, bk] = boundary as readonly [number, string];
    cmp =
      q.mode !== 'literal' && q.sort === 'time_asc'
        ? row.value.time - bt || cmpKey(row.key, bk)
        : bt - row.value.time || cmpKey(row.key, bk);
  }
  return cmp > 0;
}

export class RowTopK {
  private readonly a: MatchedRow[] = [];

  constructor(
    private readonly q: NormalizedQuery,
    private readonly k: number,
  ) {}

  private worse(x: MatchedRow, y: MatchedRow): boolean {
    return compareRows(this.q, x, y) > 0;
  }

  offer(row: MatchedRow): void {
    const a = this.a;
    if (a.length < this.k) {
      a.push(row);
      let i = a.length - 1;
      while (i > 0) {
        const p = (i - 1) >> 1;
        if (!this.worse(a[i]!, a[p]!)) break;
        [a[p], a[i]] = [a[i]!, a[p]!];
        i = p;
      }
      return;
    }
    if (this.k === 0 || !this.worse(a[0]!, row)) return;
    a[0] = row;
    let i = 0;
    for (;;) {
      let w = i;
      const l = 2 * i + 1;
      const r = 2 * i + 2;
      if (l < a.length && this.worse(a[l]!, a[w]!)) w = l;
      if (r < a.length && this.worse(a[r]!, a[w]!)) w = r;
      if (w === i) break;
      [a[w], a[i]] = [a[i]!, a[w]!];
      i = w;
    }
  }

  sorted(): MatchedRow[] {
    return this.a.sort((x, y) => compareRows(this.q, x, y));
  }
}

const DEADLINE_CHECK_STRIDE = 64;

export function matchDocs(
  q: NormalizedQuery,
  docs: Iterable<{ key: string; value: SearchDoc | undefined; score: number }>,
  boundary: SortBoundary | undefined,
  budget: MatchBudget,
): { rows: MatchedRow[]; incomplete?: GlobalSearchIncomplete } {
  const literalQuery = q.literalQuery;
  const rows: MatchedRow[] = [];
  let i = 0;
  for (const { key, value: doc, score } of docs) {
    if ((i++ & (DEADLINE_CHECK_STRIDE - 1)) === 0 && Date.now() > budget.deadlineAt) {
      return { rows, incomplete: 'deadline' };
    }
    if (doc === undefined || (doc.kind !== 'message' && doc.kind !== 'title')) continue;
    if (q.container?.sessionId !== undefined && doc.sessionId !== q.container.sessionId) continue;
    if (q.container?.agentId !== undefined && doc.agentId !== q.container.agentId) continue;
    if (q.role !== undefined && doc.role !== q.role) continue;
    if (q.startTime !== undefined && doc.time < q.startTime) continue;
    if (q.endTime !== undefined && doc.time > q.endTime) continue;
    if (boundary !== undefined && !rowAfterBoundary(q, { key, value: doc, score }, boundary)) {
      continue;
    }
    if (literalQuery !== undefined) {
      budget.textCharsLeft -= doc.text.length;
      if (budget.textCharsLeft < 0) return { rows, incomplete: 'deadline' };
      const at = normalizeLiteral(doc.text).indexOf(literalQuery);
      if (at === -1) continue;
      rows.push({ key, value: doc, score: 0, anchor: at });
    } else {
      rows.push({ key, value: doc, score });
    }
  }
  return { rows };
}

export function paginateRows(
  q: NormalizedQuery,
  page: DecodedPage,
  rows: MatchedRow[],
): { pageRows: MatchedRow[]; hasMore: boolean } {
  let pageRows: MatchedRow[];
  let hasMore: boolean;
  if (page.kind === 'legacy') {
    rows.sort((a, b) => compareRows(q, a, b));
    const slice = rows.slice(page.skip, page.skip + q.pageSize + 1);
    hasMore = slice.length > q.pageSize;
    pageRows = slice.slice(0, q.pageSize);
  } else {
    const top = new RowTopK(q, q.pageSize + 1);
    for (const row of rows) top.offer(row);
    const slice = top.sorted();
    hasMore = slice.length > q.pageSize;
    pageRows = slice.slice(0, q.pageSize);
  }
  return { pageRows, hasMore };
}

export function tokenFingerprint(q: NormalizedQuery, source: GlobalSearchSource): string {
  const basis = JSON.stringify([
    q.query,
    q.mode,
    q.op,
    q.container?.sessionId,
    q.container?.agentId,
    q.role,
    q.startTime,
    q.endTime,
    q.sort,
    source,
  ]);
  return createHash('sha256').update(basis).digest('base64url').slice(0, 16);
}

const PAGE_TOKEN_VERSION = 2;

export function encodePageToken(
  q: NormalizedQuery,
  source: GlobalSearchSource,
  boundary: SortBoundary,
  generation: string | undefined,
): string {
  return Buffer.from(
    JSON.stringify({ v: PAGE_TOKEN_VERSION, f: tokenFingerprint(q, source), g: generation, b: boundary }),
  ).toString('base64url');
}

export function decodePageToken(
  q: NormalizedQuery,
  source: GlobalSearchSource,
  token: string | undefined,
  generation: string | undefined,
): DecodedPage {
  if (token === undefined) return { kind: 'first' };
  let parsed: unknown;
  try {
    parsed = JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
  } catch {
    throw new GlobalSearchError('invalid_page_token', 'pageToken is malformed');
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new GlobalSearchError('invalid_page_token', 'pageToken is malformed');
  }
  const p = parsed as { v?: unknown; f?: unknown; s?: unknown; g?: unknown; b?: unknown };
  if (p.f !== tokenFingerprint(q, source)) {
    throw new GlobalSearchError(
      'invalid_page_token',
      'pageToken does not match the query conditions; query conditions must not change mid-pagination',
    );
  }
  if (p.v === undefined) {
    if (typeof p.s !== 'number' || !Number.isInteger(p.s) || p.s < 0) {
      throw new GlobalSearchError('invalid_page_token', 'pageToken is malformed');
    }
    return { kind: 'legacy', skip: p.s };
  }
  if (p.v !== PAGE_TOKEN_VERSION) {
    throw new GlobalSearchError('invalid_page_token', 'pageToken has an unsupported version');
  }
  if (generation !== undefined && p.g !== generation) {
    throw new GlobalSearchError(
      'invalid_page_token',
      'pageToken was issued by an older index generation (the index was rebuilt, reopened or rescanned); restart the search',
    );
  }
  const width = boundaryWidth(q);
  if (
    !Array.isArray(p.b) ||
    p.b.length !== width ||
    typeof p.b[0] !== 'number' ||
    typeof p.b[width - 1] !== 'string' ||
    (width === 3 && typeof p.b[1] !== 'number')
  ) {
    throw new GlobalSearchError('invalid_page_token', 'pageToken is malformed');
  }
  return { kind: 'keyset', boundary: p.b as SortBoundary };
}
