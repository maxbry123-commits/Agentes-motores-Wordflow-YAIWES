"""Child-process entry point for a CodeAct snippet (#1593 PR-3).

Invoked as ``python -m reyn.core.kernel._codeact_harness`` inside the sandbox. Unlike
``_python_harness`` (a pure one-shot function runner), CodeAct code interleaves
computation with **synchronous tool calls** mid-execution, so this harness opens a
**duplex control channel** to the parent: the only world-effect path exposed to the
snippet is a ``tool(name, /, **args)`` shim that round-trips each call to the parent,
where the SAME OS exclude + ``dispatch_tool`` + permission gate runs it (P5). The
snippet never holds permission authority or reaches Reyn internals directly.

Wire format (newline-delimited JSON over the inherited control fd)
------------------------------------------------------------------
Request (stdin, single JSON object):
    {
      "code":            "<the snippet>",
      "control_fd":      <int>,                # inherited AF_UNIX socketpair fd
      "allowed_modules": ["json", ...]         # safe-mode import allowlist
    }

Control channel (duplex, during execution):
    child → parent:  {"op": "tool_call", "name": "<qualified>", "args": {...}}\\n
    parent → child:  {"op": "result", "result": {...}}\\n     # dispatch_tool envelope

Response (stdout, single JSON object):
    {"ok": true,  "result": <JSON>}                          # snippet completed
    {"ok": false, "error": "<message>", "kind": "<class>"}   # snippet raised

The control fd survives the OS sandbox (an inherited AF_UNIX socketpair is not a
``network*`` socket — verified on Seatbelt under ``(deny default)+(deny network*)``);
it is the single, audited hole, carrying only marshalled tool calls the parent
re-gates. Direct FS-write / network / subprocess remain blocked by the sandbox.
"""
from __future__ import annotations

import ast
import json
import socket
import sys
import traceback
from typing import Any

# Reuse the existing safe-mode validator + restricted builtins (#1593
# correspondence: harness restricted-namespace mechanism reused; CodeAct only
# adds the permission-proxy shim on top).
from reyn.core.kernel._python_harness import (
    _build_restricted_builtins,
    _validate_safe_ast,
)


class _ControlChannel:
    """Newline-delimited JSON duplex channel to the parent over the inherited fd."""

    def __init__(self, sock: socket.socket) -> None:
        self._sock = sock
        self._buf = b""

    def call(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Send one request and block for the single-line reply."""
        self._sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))
        return self._recv_line()

    def send(self, payload: dict[str, Any]) -> None:
        """Send one frame with NO reply (#1618 root-2: the snippet's final result
        envelope travels on this control channel, NOT stdout — so user-code
        ``print()`` to stdout can never corrupt the protocol)."""
        self._sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))

    def _recv_line(self) -> dict[str, Any]:
        while b"\n" not in self._buf:
            chunk = self._sock.recv(65536)
            if not chunk:
                raise _ControlChannelClosed(
                    "parent closed the CodeAct control channel mid-call"
                )
            self._buf += chunk
        line, _, self._buf = self._buf.partition(b"\n")
        return json.loads(line.decode("utf-8"))


class _ControlChannelClosed(RuntimeError):
    """The parent hung up the control channel before replying."""


def _make_tool_shim(channel: _ControlChannel):
    """Build the ``tool(name, /, **args)`` callable injected into the snippet namespace.

    Marshals ``(name, args)`` to the parent, which runs the OS exclude +
    ``dispatch_tool`` + permission gate, and returns the result envelope's payload.
    A ``status == "error"`` envelope is raised as ``ToolError`` so the snippet can
    try/except it the way it would a normal Python call (permission_denied /
    tool_excluded / unknown_tool surface here).

    ``name`` is **positional-only** (#3041). It means "which tool to call", but
    ``**args`` carries the TARGET tool's own schema keys — and ~20 registered tools
    (``mcp_install_local``, ``spawn_agent``, ``remember_shared``, ``run_pipeline``
    …) declare a parameter literally called ``name``. Without the ``/``, that key
    binds to this function's own ``name`` slot, which ``_make_action_stub`` has
    ALREADY filled positionally, and Python raises ``TypeError: got multiple values
    for argument 'name'`` before the call ever reaches the parent gate — making every
    such tool uncallable under CodeAct with no LLM-side workaround (the collision is
    in the shim, not in the snippet). The ``/`` closes the namespace: a positional-only
    parameter cannot be filled by a keyword, so ``name='reyn_chunker'`` lands in
    ``**args`` where it belongs. A ``**kwargs`` catch-all can never collide, so
    pinning ``name`` behind the ``/`` is sufficient — no other parameter here is
    keyword-reachable."""

    def tool(name: str, /, **args: Any) -> Any:
        reply = channel.call({"op": "tool_call", "name": name, "args": args})
        result = reply.get("result", {})
        if isinstance(result, dict) and result.get("status") == "error":
            err = result.get("error", {}) or {}
            raise ToolError(
                err.get("message", "tool call failed"),
                kind=err.get("kind", "error"),
                name=name,
            )
        # dispatch_tool success envelope is {"status": "ok", "data": <value>}.
        if isinstance(result, dict) and "data" in result:
            return result["data"]
        return result

    return tool


def _make_action_stub(action_name: str, tool_shim: Any):
    """#1658: a gated DIRECT-FUNCTION stub for one action — a thin renamed wrapper of
    the ``tool`` marshalling primitive with the qualified name BAKED IN. Calling
    ``read_file(path=...)`` marshals ``('read_file', kwargs)`` over the SAME control
    channel to the SAME parent gate (exclude + dispatch_tool + permission). Gating is
    identical to the old ``tool('read_file', ...)`` proxy; only the LLM-facing surface
    changes (a selected identifier, never a produced string). Keyword args only
    (matches the proxy contract + the SP's keyword example); a positional call raises a
    clear TypeError the model self-corrects from.

    The qualified name rides ``tool``'s POSITIONAL-ONLY first slot (#3041), so a
    ``kwargs`` key named ``name`` — which the target tool's own schema is entitled to
    declare — flows through to the parent as an argument instead of colliding with
    this stub's "which tool" channel."""

    def _stub(**kwargs: Any) -> Any:
        return tool_shim(action_name, **kwargs)

    return _stub


class ToolError(RuntimeError):
    """Raised inside a CodeAct snippet when a proxied tool call returns an error
    envelope (permission_denied / tool_excluded / unknown_tool / exception)."""

    def __init__(self, message: str, *, kind: str = "error", name: str = "") -> None:
        super().__init__(message)
        self.kind = kind
        self.name = name


def _exec_codeact(
    code: str,
    channel: _ControlChannel,
    allowed_modules: frozenset[str],
    actions: "dict[str, str] | None" = None,
) -> Any:
    """Validate + exec the snippet with the restricted builtins + the gated
    direct-function stubs.

    Returns the snippet's ``result`` binding if it defines one, else None. The
    snippet affects the world ONLY through the injected action functions (#1658:
    ``read_file(...)`` etc., each a parent-gated stub) — or the internal ``tool()``
    primitive they wrap (kept available but NOT advertised). The restricted builtins
    block ``open`` / ``eval`` / ``__import__`` of non-allowlisted modules
    (defense-in-depth on top of the sandbox)."""
    tree = ast.parse(code, filename="<codeact>")
    _validate_safe_ast(tree, allowed_modules)
    builtins_dict = _build_restricted_builtins(allowed_modules)

    tool_shim = _make_tool_shim(channel)
    namespace: dict[str, Any] = {
        "__builtins__": builtins_dict,
        "__name__": "__reyn_codeact__",
        # Internal marshalling primitive — the stubs wrap it. Kept callable for
        # back-compat but NOT advertised in the SP (the code-API lists the direct
        # functions only; advertising tool('name') would reintroduce the
        # string-production hallucination path #1658 eliminates).
        "tool": tool_shim,
    }
    # #1658: inject one gated direct-function stub per action (identifier →
    # qualified-name closure over the SAME tool_shim → SAME parent gate).
    for ident, qualified in (actions or {}).items():
        namespace[ident] = _make_action_stub(qualified, tool_shim)
    compiled = compile(tree, filename="<codeact>", mode="exec")
    exec(compiled, namespace)  # noqa: S102 — sandboxed subprocess + restricted ns
    return namespace.get("result")


def _read_request() -> dict[str, Any]:
    raw = sys.stdin.read()
    if not raw:
        raise ValueError("codeact harness received empty stdin")
    return json.loads(raw)


def _write_response(payload: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, default=str))
    sys.stdout.flush()


def main() -> int:
    # #3869: name this child the same way reyn's own main process does
    # (#3870) — the CodeAct harness is a genuinely reyn-authored Python
    # entry point (unlike sandboxed_exec's arbitrary third-party argv,
    # which reyn does not control the code of), so the same
    # setproctitle-based mechanism applies directly. A no-op (returns
    # False) on a host without setproctitle installed — never an error,
    # matching proctitle.py's own module docstring.
    from reyn.runtime.proctitle import set_process_title
    set_process_title("codeact")

    sock: socket.socket | None = None
    channel: "_ControlChannel | None" = None
    try:
        req = _read_request()
        code = str(req["code"])
        control_fd = int(req["control_fd"])
        allowed_modules = frozenset(req.get("allowed_modules") or [])
        actions = req.get("actions") or {}  # #1658 {identifier: action_name}

        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM, fileno=control_fd)
        channel = _ControlChannel(sock)

        result = _exec_codeact(code, channel, allowed_modules, actions)
        # #1618 root-2: final result on the CONTROL CHANNEL (op="final"), not stdout
        # — user code's stdout/stderr stay clean for the parent to capture as data.
        channel.send({"op": "final", "ok": True, "result": result})
        return 0
    except Exception as exc:  # noqa: BLE001 — surface every failure as a response
        _final = {
            "op": "final",
            "ok": False,
            "kind": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(limit=20),
        }
        # Prefer the control channel; if it never opened (early error) or is dead,
        # fall back to stdout so the parent's no-final crash-path still surfaces it.
        if channel is not None:
            try:
                channel.send(_final)
            except OSError:
                _write_response(_final)
        else:
            _write_response(_final)
        return 1
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass


if __name__ == "__main__":
    sys.exit(main())
