"""``/reset`` — wipe in-flight run state from inside the TUI.

The pre-existing ``reyn chat --reset`` CLI flag prompts for confirmation
via ``input()`` BEFORE the TUI mounts, so users who realise mid-session
they want a reset have no in-app affordance — they have to ``Ctrl+D``,
restart with ``--reset``, answer the prompt at the bare terminal, then
get the TUI back. UX wave finding F14.

Two-step confirmation pattern (= no Textual ModalScreen / new widget
needed; the simplest path to a TUI-native flow):

  /reset            → prints the warning + asks user to type
                      ``/reset confirm`` to proceed.
  /reset confirm    → calls ``_reset_project_state(confirm=False)``
                      and reports the outcome.

The CLI flag stays — ``--cui`` mode (no TUI) and external-script
invocations still rely on it. This is a *parallel* affordance, not a
replacement.
"""
from __future__ import annotations

from reyn.interfaces.slash import SlashContext, reply, reply_error, slash


@slash(
    "reset",
    summary="Reset in-flight run state (snapshots + WAL; audit logs preserved)",
    locus="session",
    usage="/reset confirm",
    see_also=("docs/guide/crash-recovery-and-resume.md",),
)
async def reset_cmd(ctx: "SlashContext", args: str) -> None:
    token = args.strip().lower()
    if token != "confirm":
        await reply(
            ctx,
            "⚠ This will delete all in-flight run state "
            "(snapshots + WAL). Audit logs are preserved.\n"
            "Type `/reset confirm` to proceed, or anything else to abort.\n"
            "See docs/guide/crash-recovery-and-resume.md "
            "for what snapshots+WAL hold.",
        )
        return

    registry = getattr(ctx.session, "_registry", None)
    if registry is None:
        await reply_error(
            ctx,
            "registry not wired; /reset only works in `reyn chat`",
        )
        return
    project_root = getattr(registry, "_project_root", None)
    if project_root is None:
        await reply_error(
            ctx,
            "registry has no _project_root; /reset cannot locate state directory",
        )
        return

    # Lazy import so the slash registry doesn't pull the CLI module on every
    # session bootstrap (slash dispatch happens far more often than reset).
    from reyn.interfaces.cli.commands.chat import _reset_project_state

    proceeded = _reset_project_state(project_root, confirm=False)
    if proceeded:
        await reply(
            ctx,
            "✓ State reset complete. Snapshots + WAL removed; audit logs "
            "preserved. Restart `reyn chat` for the changes to fully apply "
            "to the active session.",
        )
    else:
        # _reset_project_state only returns False when confirm=True and the
        # interactive prompt is declined — we passed confirm=False, so this
        # branch shouldn't normally hit. Guarded for defence in depth.
        await reply_error(ctx, "Reset did not proceed (unexpected).")
