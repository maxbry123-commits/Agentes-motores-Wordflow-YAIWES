"""/agent slash command — agent lifecycle from chat.

Sub-commands:
  /agent new <name>          — create a new agent and attach to it
  /agent edit role <text>    — replace the attached agent's role text;
                                next turn picks up the new role.

Removal / rename are intentionally NOT here yet — the registry's
``remove()`` exists but cascade safety (= topology references,
in-flight tasks, history continuity on rename) deserves explicit
confirmation UX that isn't a one-liner. Filing as follow-ups if
surfaced.
"""
from __future__ import annotations

from dataclasses import replace

from reyn.interfaces.slash import SlashContext, reply, reply_error, slash
from reyn.runtime.profile import AgentProfile

_USAGE = (
    "Usage:\n"
    "  /agent new <name>          — create a new agent and attach to it\n"
    "                                (name: 1-32 chars of [a-z0-9_-], "
    "starting with [a-z0-9])\n"
    "  /agent edit role <text>    — replace the attached agent's role text"
)
_NO_REGISTRY = (
    "agent registry not wired; /agent only works in `reyn chat`"
)


@slash(
    "agent",
    summary=(
        "Agent lifecycle: new <name> / edit role <text> "
        "(rm via `reyn agent rm`)"
    ),
    locus="session",
    usage="/agent new <name> | /agent edit role <text>",
)
async def agent_cmd(ctx: "SlashContext", args: str) -> None:
    """Dispatch ``/agent <sub>`` subcommands."""
    parts = args.strip().split(maxsplit=1)
    if not parts:
        await reply(ctx, _USAGE)
        return
    sub = parts[0]
    sub_args = parts[1] if len(parts) > 1 else ""
    if sub == "new":
        await _create_agent(ctx, sub_args)
    elif sub == "edit":
        await _edit_agent(ctx, sub_args)
    else:
        await reply_error(ctx, _USAGE)


async def _create_agent(ctx: "SlashContext", name: str) -> None:
    """Create a new agent profile and attach to it.

    #4534 PR-2: uses the same ``request_attach`` named-operation seam as
    ``/attach`` (until #191 lands, the header label won't refresh — same
    constraint as /attach). The reply is ordered AFTER the call and reads
    its return (lead-coder review, #4534 remainder): ``request_attach``'s
    ``False`` is ambiguous by transport (AG-UI's is "unknown" — an
    unconfirmed remote ack; in-process's is a definitive local failure), so
    the reply on ``False`` says "could not confirm", never "failed" — the
    wording that would be true for one transport and wrong for the other.

    #5080: an optional SECOND whitespace-separated token is the new
    agent's ``base_dir`` override — ``/agent new <name> [base_dir]``, the
    same simple positional shape this command already uses for ``name``
    (no ``--flag`` syntax anywhere else in this file, so none introduced
    here). Validated ⊆ the project workspace by ``registry.create`` itself
    (the ONE seam); a rejection surfaces through the SAME ``ValueError``
    handling as an invalid name below.
    """
    parts = name.strip().split(maxsplit=1)
    name = parts[0] if parts else ""
    base_dir = parts[1] if len(parts) > 1 else None
    if not name:
        await reply_error(ctx, "Usage: /agent new <name> [base_dir]")
        return
    if ctx.session._registry is None:
        await reply_error(ctx, _NO_REGISTRY)
        return
    try:
        # #2103 S2b: emit agent_created
        await ctx.session._registry.create_agent(name, base_dir=base_dir)
    except FileExistsError:
        await reply_error(
            ctx,
            f"agent {name!r} already exists; use /attach {name} instead",
        )
        return
    except ValueError as exc:
        # _validate_agent_name / the #5080 base_dir bound-check both raise
        # with the rule embedded — surface verbatim so the user sees
        # exactly what's wrong with the name.
        await reply_error(ctx, str(exc))
        return
    attached = await ctx.transport.request_attach(name)
    if attached:
        await reply(ctx, f"created agent {name!r}; attaching…")
    else:
        await reply(
            ctx,
            f"created agent {name!r}; could not confirm the attach — try /attach {name}",
        )


async def _edit_agent(ctx: "SlashContext", args: str) -> None:
    """Dispatch ``/agent edit <field> <value>`` — currently ``role`` only.

    Edits operate on the **attached agent** (= ``session.agent_name``).
    Cross-agent edit (= "edit role on some-other-agent") would need a
    name argument and clearer mental model; deferred.
    """
    parts = args.strip().split(maxsplit=1)
    if not parts:
        await reply_error(ctx, "Usage: /agent edit role <text>")
        return
    field = parts[0]
    rest = parts[1] if len(parts) > 1 else ""
    if field == "role":
        await _edit_role(ctx, rest)
    else:
        await reply_error(
            ctx,
            f"unknown edit field {field!r}; only `role` is supported.",
        )


async def _edit_role(ctx: "SlashContext", new_role: str) -> None:
    """Replace the attached agent's role text on disk + in-memory.

    Two-side update:
      1. ``profile.yaml`` rewritten via ``AgentProfile.save`` so the
         change survives restart.
      2. ``session._agent_role`` mutated so the next router turn picks
         up the new role without restart (= consumed at Agent
         construction time per line ~2655 in session.py).
    """
    new_role = new_role.strip()
    if not new_role:
        await reply_error(
            ctx,
            "Usage: /agent edit role <text>  (text must be non-empty; "
            "clearing the role intentionally is not yet supported)",
        )
        return

    registry = ctx.session._registry
    if registry is None:
        await reply_error(ctx, _NO_REGISTRY)
        return

    name = ctx.session.agent_name
    agent_dir = registry._dir / name
    try:
        profile = AgentProfile.load(agent_dir)
    except FileNotFoundError:
        await reply_error(
            ctx,
            f"profile for agent {name!r} not found at {agent_dir}/profile.yaml",
        )
        return

    updated = replace(profile, role=new_role)
    try:
        updated.save(agent_dir)
    except OSError as exc:
        await reply_error(ctx, f"failed to save profile: {exc}")
        return

    # Mutate in-memory so the next turn's Agent construction picks up
    # the new role (= session._agent_role is read at
    # ``_construct_agent`` time, not cached on a prompt object).
    ctx.session._agent_role = new_role

    await reply(
        ctx,
        f"✓ Updated agent {name!r} role.\n  new role: {new_role}\n"
        "Next user turn will use the new role.",
    )
