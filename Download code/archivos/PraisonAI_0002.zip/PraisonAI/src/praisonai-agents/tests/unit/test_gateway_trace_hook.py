"""Unit tests for the gateway pipeline span-tracing seam (Issue #2716).

Covers the pure, core-side tracing-hook protocol (``GatewayTraceHook``), its
zero-cost no-op default (``NullGatewayTraceHook``), and the ``resolve_trace_hook``
helper, matching the shape of the sibling gateway policy protocols
(send / idle / drain / concurrency / rate-limit).
"""

from contextlib import AbstractContextManager, contextmanager

import pytest

from praisonaiagents.gateway import (
    GATEWAY_TRACE_STAGES,
    GatewayTraceHook,
    NULL_GATEWAY_TRACE_HOOK,
    NullGatewayTraceHook,
    resolve_trace_hook,
)


def test_null_hook_conforms_to_protocol():
    assert isinstance(NullGatewayTraceHook(), GatewayTraceHook)
    assert isinstance(NULL_GATEWAY_TRACE_HOOK, GatewayTraceHook)


def test_stage_returns_context_manager():
    hook = NullGatewayTraceHook()
    scope = hook.stage("agent.run", correlation_id="abc", session="s1")
    assert isinstance(scope, AbstractContextManager)


def test_null_stage_is_usable_and_ignores_args():
    hook = NullGatewayTraceHook()
    with hook.stage("agent.run", correlation_id="abc", model="gpt-4", extra=1) as span:
        assert span is None


def test_null_stage_works_without_correlation_id():
    hook = NullGatewayTraceHook()
    with hook.stage("inbound") as span:
        assert span is None


def test_null_stage_does_not_swallow_exceptions():
    hook = NullGatewayTraceHook()
    with pytest.raises(ValueError):
        with hook.stage("tool.call", tool="search"):
            raise ValueError("boom")


def test_resolve_trace_hook_returns_default_when_none():
    assert resolve_trace_hook(None) is NULL_GATEWAY_TRACE_HOOK


def test_resolve_trace_hook_passes_through_supplied_hook():
    class _Recorder:
        def __init__(self):
            self.calls = []

        def stage(self, name, *, correlation_id=None, **attrs):
            self.calls.append((name, correlation_id, attrs))
            return NULL_GATEWAY_TRACE_HOOK.stage(name)

    rec = _Recorder()
    resolved = resolve_trace_hook(rec)
    assert resolved is rec
    with resolved.stage("delivery", correlation_id="cid", channel="telegram"):
        pass
    assert rec.calls == [("delivery", "cid", {"channel": "telegram"})]


def test_canonical_stage_names_cover_pipeline():
    for stage in ("inbound", "admit", "agent.run", "llm.call",
                  "tool.call", "outbox.enqueue", "delivery"):
        assert stage in GATEWAY_TRACE_STAGES


def test_null_stage_accepts_parent_carrier():
    hook = NullGatewayTraceHook()
    carrier = {"traceparent": "00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01"}
    with hook.stage("agent.run", correlation_id="abc", parent_carrier=carrier) as span:
        assert span is None


def test_null_inject_context_is_noop():
    hook = NullGatewayTraceHook()
    carrier: dict = {}
    assert hook.inject_context(carrier) is None
    assert carrier == {}


def test_null_extract_carrier_returns_none():
    hook = NullGatewayTraceHook()
    carrier = {"traceparent": "00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01"}
    assert hook.extract_carrier(carrier) is None


def test_propagation_capable_hook_conforms_to_protocol():
    class _Prop:
        def stage(self, name, *, correlation_id=None, parent_carrier=None, **attrs):
            return NULL_GATEWAY_TRACE_HOOK.stage(name)

        def inject_context(self, carrier):
            carrier["traceparent"] = "00-abc-def-01"

        def extract_carrier(self, carrier):
            return dict(carrier) if "traceparent" in carrier else None

    hook = _Prop()
    assert isinstance(hook, GatewayTraceHook)

    out: dict = {}
    hook.inject_context(out)
    assert out["traceparent"] == "00-abc-def-01"

    assert hook.extract_carrier({}) is None
    parent = hook.extract_carrier({"traceparent": "00-abc-def-01"})
    with hook.stage("agent.run", parent_carrier=parent) as span:
        assert span is None


def test_custom_hook_scope_wraps_stage():
    events = []

    class _Tracer:
        def stage(self, name, *, correlation_id=None, **attrs):
            return self._span(name, correlation_id, attrs)

        @contextmanager
        def _span(self, name, correlation_id, attrs):
            events.append(("start", name, correlation_id))
            try:
                yield name
            finally:
                events.append(("end", name, correlation_id))

    tracer = resolve_trace_hook(_Tracer())
    with tracer.stage("agent.run", correlation_id="c1") as span:
        assert span == "agent.run"
    assert events == [("start", "agent.run", "c1"), ("end", "agent.run", "c1")]
