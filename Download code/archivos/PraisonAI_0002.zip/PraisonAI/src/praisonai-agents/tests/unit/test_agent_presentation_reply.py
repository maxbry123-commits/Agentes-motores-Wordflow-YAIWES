"""Tests for agent-authored interactive replies (presentation emit + reply route).

Covers the core seam added so an agent can emit a portable MessagePresentation
as a normal reply and have a button/select click routed back into the next turn.
"""

import asyncio

from praisonaiagents.bots import (
    MessagePresentation,
    PresentationBlock,
    PresentationButton,
    PresentationAction,
    PresentationLimits,
    ActionType,
    BlockType,
    AgentReply,
    TurnCompletion,
    extract_presentation,
    extract_completion,
    append_completion_note,
    adapt_presentation,
    encode_action,
    decode_callback,
    create_registry,
    make_reply_handler,
    InteractiveContext,
    REPLY_NAMESPACE,
)


def test_reply_action_factory():
    action = PresentationAction.reply("env=staging")
    assert action.type == ActionType.REPLY
    assert action.value == "env=staging"


def test_block_make_helpers():
    assert PresentationBlock.make_text("hi").type == BlockType.TEXT
    assert PresentationBlock.make_context("note").type == BlockType.CONTEXT
    assert PresentationBlock.make_buttons([]).type == BlockType.BUTTONS


def test_quick_replies_builds_reply_buttons():
    block = PresentationBlock.quick_replies([("Staging", "env=staging"), "Prod"])
    assert block.type == BlockType.BUTTONS
    assert block.buttons[0].action.type == ActionType.REPLY
    assert block.buttons[0].action.value == "env=staging"
    # Plain string choice uses itself as both label and value.
    assert block.buttons[1].label == "Prod"
    assert block.buttons[1].action.value == "Prod"


def test_question_builds_prompt_and_reply_options():
    pres = MessagePresentation.question(
        "Which environment should I deploy to?",
        options=[("Staging", "staging"), "production", "cancel"],
    )
    # First block is the prompt text.
    assert pres.blocks[0].type == BlockType.TEXT
    assert "environment" in pres.blocks[0].text
    # Last block is the reply-action option buttons.
    buttons = pres.blocks[-1].buttons
    assert pres.blocks[-1].type == BlockType.BUTTONS
    assert buttons[0].action.type == ActionType.REPLY
    assert buttons[0].action.value == "staging"
    assert buttons[1].action.value == "production"
    assert buttons[2].label == "cancel"


def test_question_includes_optional_context():
    pres = MessagePresentation.question(
        "Pick a plan",
        options=["basic", "pro"],
        context="Billing applies immediately.",
    )
    assert pres.blocks[0].type == BlockType.TEXT
    assert pres.blocks[1].type == BlockType.CONTEXT
    assert pres.blocks[1].text == "Billing applies immediately."
    assert pres.blocks[2].type == BlockType.BUTTONS


def test_question_options_render_as_native_buttons_per_channel():
    pres = MessagePresentation.question("Pick", options=["a", "b"])
    adapted = adapt_presentation(pres, PresentationLimits.telegram())
    btn = adapted.blocks[-1].buttons[0]
    # Reply degrades to a channel-safe callback so native renderers can carry it.
    assert btn.action.type == ActionType.CALLBACK
    assert btn.action.value == "reply:a"


def test_encode_reply_action():
    enc = encode_action("ignored", PresentationAction.reply("pick=a"))
    assert enc == "reply:pick=a"
    namespace, payload = decode_callback(enc)
    assert namespace == REPLY_NAMESPACE
    assert payload["value"] == "pick=a"


def test_adapt_degrades_reply_to_callback():
    p = MessagePresentation([
        PresentationBlock.make_buttons([
            PresentationButton(label="Staging", action=PresentationAction.reply("env=staging")),
        ])
    ])
    adapted = adapt_presentation(p, PresentationLimits.telegram())
    btn = adapted.blocks[0].buttons[0]
    # Renderers only know command/callback/url/web_app; reply degrades to callback.
    assert btn.action.type == ActionType.CALLBACK
    assert btn.action.value == "reply:env=staging"


def test_adapt_reply_callback_respects_length_cap():
    long_value = "x" * 200
    p = MessagePresentation([
        PresentationBlock.make_buttons([
            PresentationButton(label="L", action=PresentationAction.reply(long_value)),
        ])
    ])
    adapted = adapt_presentation(p, PresentationLimits.telegram())
    val = adapted.blocks[0].buttons[0].action.value
    # Cap is a byte limit; an over-cap value becomes a collision-resistant hash
    # marked with ``#`` (not a lossy prefix) so distinct choices stay distinct.
    assert len(val.encode("utf-8")) <= 64
    assert val.startswith("reply:#")


def test_adapt_long_replies_do_not_collide():
    # Two distinct long values that share a prefix must NOT collapse to the same
    # callback payload (the prefix-truncation bug). Hashing keeps them distinct.
    a = "shared-prefix-" + "a" * 200
    b = "shared-prefix-" + "b" * 200
    p = MessagePresentation([
        PresentationBlock.make_buttons([
            PresentationButton(label="A", action=PresentationAction.reply(a)),
            PresentationButton(label="B", action=PresentationAction.reply(b)),
        ])
    ])
    adapted = adapt_presentation(p, PresentationLimits.telegram())
    va = adapted.blocks[0].buttons[0].action.value
    vb = adapted.blocks[0].buttons[1].action.value
    assert va != vb


def test_adapt_reply_callback_byte_cap_with_non_ascii():
    # Non-ASCII values can stay under 64 *chars* yet exceed 64 *bytes*; the
    # cap must be enforced in UTF-8 bytes.
    value = "é" * 40  # 40 chars, 80 bytes
    p = MessagePresentation([
        PresentationBlock.make_buttons([
            PresentationButton(label="L", action=PresentationAction.reply(value)),
        ])
    ])
    adapted = adapt_presentation(p, PresentationLimits.telegram())
    val = adapted.blocks[0].buttons[0].action.value
    assert len(val.encode("utf-8")) <= 64
    # Over-cap -> hashed marker form, which is pure ASCII (no split codepoint).
    assert val.startswith("reply:#")


def test_reply_handler_declines_hashed_value():
    # A hashed (non-routable) reply value must NOT be fed into the turn — the
    # agent never authored the digest. The handler declines instead.
    called = {"hit": False}

    async def continue_turn(value, context):
        called["hit"] = True
        return "should not run"

    registry = create_registry()
    registry.register(REPLY_NAMESPACE, make_reply_handler(continue_turn))
    ctx = InteractiveContext(callback_data="reply:#deadbeefdeadbeef", user_id="u1")
    handled = asyncio.run(registry.dispatch(ctx))
    assert handled is False
    assert called["hit"] is False


def test_encode_empty_string_reply_preserved():
    # PresentationAction.reply("") is a valid choice; the encoder must keep the
    # reserved reply: prefix instead of falling back to the caller namespace.
    enc = encode_action("ns", PresentationAction.reply(""))
    assert enc == "reply:"
    namespace, payload = decode_callback(enc)
    assert namespace == REPLY_NAMESPACE
    assert payload["value"] == ""


def test_extract_presentation_plain_str():
    text, pres = extract_presentation("hello")
    assert text == "hello"
    assert pres is None


def test_extract_presentation_from_presentation():
    p = MessagePresentation([
        PresentationBlock.make_text("Which environment?"),
        PresentationBlock.quick_replies([("Staging", "staging")]),
    ])
    text, pres = extract_presentation(p)
    assert pres is p
    assert "Which environment?" in text


def test_extract_presentation_from_agent_reply():
    p = MessagePresentation([PresentationBlock.quick_replies([("A", "a")])])
    reply = AgentReply(text="Pick one", presentation=p)
    text, pres = extract_presentation(reply)
    assert text == "Pick one"
    assert pres is p


def test_extract_presentation_from_dict():
    p = MessagePresentation([PresentationBlock.make_text("hi")])
    data = AgentReply(text="t", presentation=p).to_dict()
    text, pres = extract_presentation(data)
    assert text == "t"
    assert isinstance(pres, MessagePresentation)
    assert pres.blocks[0].text == "hi"


def test_agent_reply_roundtrip():
    p = MessagePresentation([PresentationBlock.quick_replies([("A", "a")])])
    reply = AgentReply(text="hi", presentation=p)
    restored = AgentReply.from_dict(reply.to_dict())
    assert restored.text == "hi"
    assert restored.presentation.blocks[0].buttons[0].action.value == "a"


def test_turn_completion_completed_is_clean():
    c = TurnCompletion()  # defaults to "completed"
    assert c.reason == "completed"
    assert c.truncated is False
    assert c.note() == ""


def test_turn_completion_max_steps_surfaces_note():
    c = TurnCompletion(reason="max_steps")
    assert c.truncated is True
    assert "step limit" in c.note()


def test_turn_completion_detail_overrides_default_note():
    c = TurnCompletion(reason="error", detail="custom message")
    assert c.note() == "custom message"


def test_turn_completion_unknown_reason_degrades_gracefully():
    c = TurnCompletion(reason="something_new")
    assert c.truncated is True
    assert c.note() != ""


def test_turn_completion_roundtrip():
    c = TurnCompletion(reason="max_steps", detail="d")
    restored = TurnCompletion.from_dict(c.to_dict())
    assert restored.reason == "max_steps"
    assert restored.detail == "d"


def test_agent_reply_completion_roundtrip():
    reply = AgentReply(text="hi", completion=TurnCompletion(reason="cancelled"))
    restored = AgentReply.from_dict(reply.to_dict())
    assert restored.completion.reason == "cancelled"


def test_agent_reply_completion_defaults_none():
    reply = AgentReply(text="hi")
    assert reply.completion is None
    assert "completion" not in reply.to_dict()


def test_extract_completion_from_reply():
    reply = AgentReply(text="hi", completion=TurnCompletion(reason="max_steps"))
    c = extract_completion(reply)
    assert c is not None and c.reason == "max_steps"


def test_extract_completion_from_stop_reason_attr():
    class FakeAgent:
        last_stop_reason = "cancelled"

    c = extract_completion(FakeAgent())
    assert c is not None and c.reason == "cancelled"


def test_extract_completion_plain_str_and_none():
    assert extract_completion("hello") is None
    assert extract_completion(None) is None


def test_append_completion_note_disabled_by_default():
    c = TurnCompletion(reason="max_steps")
    assert append_completion_note("answer", c) == "answer"


def test_append_completion_note_enabled_appends():
    c = TurnCompletion(reason="max_steps")
    out = append_completion_note("answer", c, enabled=True)
    assert out.startswith("answer")
    assert "step limit" in out


def test_append_completion_note_completed_is_noop():
    c = TurnCompletion(reason="completed")
    assert append_completion_note("answer", c, enabled=True) == "answer"


def test_append_completion_note_empty_text_uses_note_only():
    c = TurnCompletion(reason="max_steps")
    out = append_completion_note("", c, enabled=True)
    assert "step limit" in out


def test_reply_handler_routes_value_back_into_turn():
    seen = {}

    async def continue_turn(value, context):
        seen["value"] = value
        seen["user"] = context.user_id
        return f"ran with {value}"

    registry = create_registry()
    registry.register(REPLY_NAMESPACE, make_reply_handler(continue_turn))

    ctx = InteractiveContext(callback_data="reply:env=prod", user_id="u1")
    handled = asyncio.run(registry.dispatch(ctx))

    assert handled is True
    assert seen["value"] == "env=prod"
    assert seen["user"] == "u1"
