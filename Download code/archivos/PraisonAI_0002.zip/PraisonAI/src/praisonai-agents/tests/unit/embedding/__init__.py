# Embedding module tests
