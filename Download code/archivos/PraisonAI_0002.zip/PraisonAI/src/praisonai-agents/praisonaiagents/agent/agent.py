import os
import time
import json
import logging
from praisonaiagents._logging import get_logger
import asyncio
import contextlib
import threading
import concurrent.futures
import random
from typing import List, Optional, Any, Dict, Union, Literal, TYPE_CHECKING, Callable, Generator
from collections import OrderedDict
import inspect

# Decomposed agent functionality - real implementations in mixin files
from .chat_mixin import ChatMixin
from .execution_mixin import ExecutionMixin
from .memory_mixin import MemoryMixin
from .async_memory_mixin import AsyncMemoryMixin
from .tool_execution import ToolExecutionMixin, BackoffPolicy
from .chat_handler import ChatHandlerMixin
from .session_manager import SessionManagerMixin
from .async_safety import AsyncSafeState, DualLock
# NOTE: UnifiedExecutionMixin is deprecated and unused by any production path
# (Issue #2644). It is kept in the MRO for backward compatibility during the
# deprecation cycle and will be removed afterwards.
from .unified_execution_mixin import UnifiedExecutionMixin
from .sandbox_mixin import SandboxMixin
from .message_steering import SteeringMixin
from .skill_review import SkillReviewMixin
from ..goal.loop import GoalLoopMixin

# Module-level logger for thread safety errors and debugging
logger = get_logger(__name__)

# ============================================================================
# Performance: Lazy imports for heavy dependencies
# Rich, LLM, and display utilities are only imported when needed (output=verbose)
# This reduces import time from ~420ms to ~20ms for silent mode
# ============================================================================

# Shared, cached, thread-safe display lazy-loaders (single source of truth)
from ._lazy_display import _get_console, _get_live, _get_display_functions

# Lazy-loaded modules (populated on first use, protected by _lazy_import_lock)
_lazy_import_lock = threading.Lock()

# Serializes the check-and-enable of the mutually-exclusive process-global
# output modes (editor/trace/status) so concurrently-constructed Agents cannot
# both observe "no mode enabled" and clobber each other's callbacks. First
# mode wins.
_output_mode_lock = threading.Lock()
_llm_module = None
_hooks_module = None
_stream_emitter_class = None

def _get_llm_functions():
    """Lazy load LLM functions (thread-safe)."""
    global _llm_module
    if _llm_module is None:
        with _lazy_import_lock:
            if _llm_module is None:
                from ..llm import get_openai_client, process_stream_chunks
                _llm_module = {
                    'get_openai_client': get_openai_client,
                    'process_stream_chunks': process_stream_chunks,
                }
    return _llm_module

def _get_hooks_module():
    """Lazy load hooks module for HookRunner and HookRegistry (thread-safe)."""
    global _hooks_module
    if _hooks_module is None:
        with _lazy_import_lock:
            if _hooks_module is None:
                from ..hooks import HookRunner, HookRegistry, get_default_registry
                _hooks_module = {
                    'HookRunner': HookRunner,
                    'HookRegistry': HookRegistry,
                    'get_default_registry': get_default_registry,
                }
    return _hooks_module

def _get_stream_emitter():
    """Lazy load StreamEventEmitter class (thread-safe)."""
    global _stream_emitter_class
    if _stream_emitter_class is None:
        with _lazy_import_lock:
            if _stream_emitter_class is None:
                from ..streaming.events import StreamEventEmitter
                _stream_emitter_class = StreamEventEmitter
    return _stream_emitter_class

# File extensions that indicate a file path (for output parameter detection)
_FILE_EXTENSIONS = frozenset({'.txt', '.md', '.json', '.yaml', '.yml', '.html', '.csv', '.log', '.xml', '.rst'})

def _is_file_path(value: str) -> bool:
    """Check if a string looks like a file path (not a preset name).
    
    Used to detect when output="path/to/file.txt" should be treated as
    output_file instead of a preset name.
    
    Args:
        value: String to check
        
    Returns:
        True if the string looks like a file path
    """
    # Contains path separator
    if '/' in value or '\\' in value:
        return True
    # Ends with common file extension
    lower = value.lower()
    for ext in _FILE_EXTENSIONS:
        if lower.endswith(ext):
            return True
    return False

# ============================================================================
# Performance: Module-level imports for param resolution (moved from __init__)
# These imports are lightweight and avoid per-Agent import overhead
# ============================================================================
from ..config.param_resolver import resolve, ArrayMode
from ..config.presets import (
    OUTPUT_PRESETS, EXECUTION_PRESETS, MEMORY_PRESETS, MEMORY_URL_SCHEMES,
    WEB_PRESETS, PLANNING_PRESETS, REFLECTION_PRESETS, CACHING_PRESETS,
    CONTEXT_PRESETS, AUTONOMY_PRESETS,
    DEFAULT_OUTPUT_MODE,
)
from ..config.feature_configs import (
    OutputConfig, ExecutionConfig, MemoryConfig, KnowledgeConfig,
    PlanningConfig, ReflectionConfig, RulesConfig, GuardrailConfig, WebConfig,
    TemplateConfig, CachingConfig, HooksConfig, SkillsConfig,
    DEFAULT_TOOL_OUTPUT_LIMIT,
)

# Default tool output limit (16000 chars ≈ 4000 tokens)
# Single source of truth defined in config.feature_configs and imported here
# (re-exported for backward compatibility) so OutputConfig.tool_output_limit,
# ToolConfig.output_limit, and this constant cannot drift apart.

# ============================================================================
# Preset-string validation
# ============================================================================
# Agent params whose string form must name a preset from a CLOSED set. Each
# entry maps the param name to a zero-arg callable returning the accepted
# names, so registries outside praisonaiagents.config stay lazily imported —
# the table is only consulted when the caller actually passed a string.
#
# Deliberately NOT listed (their string form is free-form, not a preset):
#   knowledge= (source path/URL), guardrails= (LLM validator prompt),
#   skills= (skill path/name), runtime= (open plugin registry), auth= (open
#   provider registry validated loudly at use time).
def _approval_preset_names():
    """Accepted approval= strings: deny-set presets + PermissionMode aliases."""
    from ..approval.registry import PERMISSION_PRESETS
    from ..permissions.rules import _MODE_ALIASES
    # "true"/"false" are legacy stringified bools accepted by the branch below.
    return set(PERMISSION_PRESETS) | set(_MODE_ALIASES) | {"true", "false"}


_PRESET_STRING_PARAMS = {
    "output": lambda: OUTPUT_PRESETS.keys(),
    "execution": lambda: EXECUTION_PRESETS.keys(),
    "context": lambda: CONTEXT_PRESETS.keys(),
    "autonomy": lambda: AUTONOMY_PRESETS.keys(),
    "approval": _approval_preset_names,
    # Mirrors the LearnMode branch in __init__.
    "learn": lambda: ("disabled", "agentic", "propose"),
    # Mirrors the self-improve mode branch in __init__.
    "self_improve": lambda: (
        "inline", "blocking", "sync", "background", "async",
        "true", "on", "yes", "1", "false", "off", "no", "0",
    ),
}


def _validate_preset_params(params):
    """Fail loudly on a typo'd preset name instead of silently using defaults.

    Args:
        params: Mapping of param name -> raw value. Non-string values are
            ignored; string values must name a preset from the closed set
            declared in ``_PRESET_STRING_PARAMS``.

    Raises:
        ValueError: With a "Did you mean ...?" suggestion and the valid names.
    """
    from ..config.parse_utils import validate_preset_string

    for name, value in params.items():
        if not isinstance(value, str):
            continue
        # output= doubles as an output-file path (output="report.md").
        if name == "output" and _is_file_path(value):
            continue
        validate_preset_string(name, value, _PRESET_STRING_PARAMS[name]())


# Don't import FastAPI dependencies here - use lazy loading instead

if TYPE_CHECKING:
    from ..approval.protocols import ApprovalConfig, ApprovalProtocol
    from ..config.feature_configs import LearnConfig, MemoryConfig, ToolConfig
    from ..context.models import ContextConfig
    from ..context.manager import ContextManager
    from ..knowledge.knowledge import Knowledge
    from .interrupt import InterruptController
    from ..agent.autonomy import AutonomyConfig
    from ..task.task import Task
    from .handoff import Handoff, HandoffConfig, HandoffResult
    from ..rag.models import RAGResult, ContextPack
    from ..eval.results import EvaluationLoopResult
    from ..tools.retry import RetryPolicy
    from ..skills.protocols import SkillReviewProtocol

# Import structured error from central errors module
from ..errors import BudgetExceededError

# Import retry configuration
from .retry_utils import RetryBackoffConfig

class Agent(GoalLoopMixin, SteeringMixin, SandboxMixin, SkillReviewMixin, UnifiedExecutionMixin, ToolExecutionMixin, ChatHandlerMixin, SessionManagerMixin, ChatMixin, ExecutionMixin, MemoryMixin, AsyncMemoryMixin):
    # Class-level counter for generating unique display names for nameless agents
    _agent_counter = 0
    _agent_counter_lock = threading.Lock()
    # Class-level cache for environment variables (avoid repeated os.environ.get)
    # Protected by _env_cache_lock for thread safety
    _env_cache_lock = threading.Lock()
    _env_output_mode = None
    _env_output_checked = False
    _default_model = None
    _default_model_checked = False

    # Deprecated __init__ params (accepted via **legacy_kwargs, mapped to config
    # objects). Kept out of the explicit signature to keep the API minimal.
    # name -> original default value.
    _LEGACY_AGENT_PARAMS = {
        "allow_delegation": False,      # -> handoffs=
        "allow_code_execution": False,  # -> execution=ExecutionConfig(code_execution=True)
        "code_execution_mode": "safe",  # -> execution=ExecutionConfig(code_mode=...)
        "auto_save": None,              # -> memory=MemoryConfig(auto_save="name")
        "rate_limiter": None,           # -> execution=ExecutionConfig(rate_limiter=obj)
        "verification_hooks": None,     # -> autonomy=AutonomyConfig(verification_hooks=[...])
        "cli_backend": None,            # -> runtime=
    }

    @property
    def _hook_runner(self):
        """Lazy-loaded HookRunner for event-based hooks (zero overhead when not used)."""
        if self.__hook_runner is None:
            hooks_mod = _get_hooks_module()
            # Default to the global registry so plugins bridged via
            # PluginManager.wire_into_hook_registry() are actually fired.
            if isinstance(self._hooks_registry_param, hooks_mod['HookRegistry']):
                registry = self._hooks_registry_param
            else:
                registry = hooks_mod['get_default_registry']()
            self.__hook_runner = hooks_mod['HookRunner'](
                registry=registry,
                cwd=os.getcwd()
            )
        return self.__hook_runner
    
    @property
    def stream_emitter(self) -> Optional[Any]:
        """Lazy-loaded StreamEventEmitter for real-time events (zero overhead when not used)."""
        if self.__stream_emitter is None:
            self.__stream_emitter = _get_stream_emitter()()
        return self.__stream_emitter
    
    @stream_emitter.setter
    def stream_emitter(self, value: Optional[Any]) -> None:
        """Allow setting stream_emitter directly."""
        self.__stream_emitter = value
    
    @classmethod
    def _get_env_output_mode(cls):
        """Get cached PRAISONAI_OUTPUT env var value (thread-safe)."""
        if not cls._env_output_checked:
            with cls._env_cache_lock:
                if not cls._env_output_checked:
                    cls._env_output_mode = os.environ.get('PRAISONAI_OUTPUT', '').lower()
                    cls._env_output_checked = True
        return cls._env_output_mode
    
    # Ordered (credential env-var, provider-appropriate default model). The
    # first provider whose credential is present wins. OpenAI is first so
    # existing OpenAI users keep their default; any other single configured
    # provider yields a matching default instead of a failing OpenAI default.
    _PROVIDER_DEFAULT_MODELS = (
        ("OPENAI_API_KEY", "gpt-4o-mini"),
        ("ANTHROPIC_API_KEY", "anthropic/claude-3-5-sonnet-latest"),
        ("GEMINI_API_KEY", "gemini/gemini-1.5-flash"),
        ("GOOGLE_API_KEY", "google/gemini-1.5-flash"),
        ("GROQ_API_KEY", "groq/llama-3.3-70b-versatile"),
        ("COHERE_API_KEY", "cohere/command-r"),
        ("OLLAMA_HOST", "ollama/llama3.2"),
    )

    # Default model per subscription auth provider, used only when the caller
    # gave `auth=` without a model. A subscription seat is tied to one vendor,
    # so the plain OpenAI default would ship the OAuth token to the wrong
    # endpoint. Overridable by passing model=/llm=.
    _AUTH_DEFAULT_MODELS = {
        "claude-code": "anthropic/claude-sonnet-4-5",
        "qwen-cli": "openai/qwen3-coder-plus",
    }

    @classmethod
    def _resolve_default_model(cls):
        """Resolve a provider-aware default model from present credentials.

        Precedence: ``OPENAI_MODEL_NAME`` (backward compatible) > first
        provider whose credential env var is set > hardcoded ``gpt-4o-mini``.
        Keeps core free of provider-detection policy beyond a simple env scan;
        the wrapper layer owns recency state and first-run notices.
        """
        explicit = os.getenv('OPENAI_MODEL_NAME')
        if explicit:
            return explicit
        for key_var, model in cls._PROVIDER_DEFAULT_MODELS:
            if os.environ.get(key_var):
                return model
        return 'gpt-4o-mini'

    @classmethod
    def _get_default_model(cls):
        """Get cached provider-aware default model name (thread-safe)."""
        if not cls._default_model_checked:
            with cls._env_cache_lock:
                if not cls._default_model_checked:
                    cls._default_model = cls._resolve_default_model()
                    cls._default_model_checked = True
        return cls._default_model
    
    def _apply_default_llm(self, model) -> None:
        """Adopt a container-level default model, unless this agent chose one.

        ``AgentTeam(llm=...)`` and ``AgentFlow(llm=...)`` document their model as
        the *default* for their agents. An agent that named its own model keeps
        it -- that is already how AgentFlow builds the agents it creates
        (``llm=config.get("llm", model)``), so both containers follow one rule.
        """
        if not model or self._llm_explicit or self._panel_descriptor is not None:
            return
        self.llm = model
        self._llm_instance = None
        # A used agent caches a dispatcher (chat_mixin) bound to the old model --
        # the OpenAI path bakes model= into it, the custom path wraps the old
        # llm_instance. Drop it so the next chat rebuilds against the new model.
        if getattr(self, '_unified_dispatcher', None) is not None:
            self._unified_dispatcher = None
        if self._llm_init_params is not None:
            # base_url path: keep the connection settings, swap the model.
            self._llm_init_params = {**self._llm_init_params, 'model': model}
        elif isinstance(model, str) and "/" in model:
            params = {'model': model, **self._llm_option_kwargs}
            if self.api_key:
                params['api_key'] = self.api_key
            self._llm_init_params = params
            self._using_custom_llm = True

    def _ensure_llm_instance(self):
        """Lazy-create LLM instance from deferred init params (avoids import at Agent())."""
        if self._llm_instance is not None:
            return self._llm_instance
        if self._panel_descriptor is not None:
            try:
                from ..llm.panel import create_panel_llm
                # Forward the same Agent-level connection/execution settings a
                # normal model selection preserves (base_url, api_key, auth,
                # metrics, max_iter, web_search, web_fetch, prompt_caching,
                # claude_memory) so the panel aggregator behaves identically.
                self._llm_instance = create_panel_llm(
                    self._panel_descriptor, **self._panel_llm_kwargs
                )
            except ImportError as e:
                raise ImportError(
                    "LLM features requested but dependencies not installed. "
                    "Please install with: pip install \"praisonaiagents[llm]\""
                ) from e
            return self._llm_instance
        if self._llm_init_params:
            try:
                from ..llm.llm import LLM
                self._llm_instance = LLM(**self._llm_init_params)
            except ImportError as e:
                raise ImportError(
                    "LLM features requested but dependencies not installed. "
                    "Please install with: pip install \"praisonaiagents[llm]\""
                ) from e
        return self._llm_instance

    @property
    def llm_instance(self):
        return self._ensure_llm_instance()

    @llm_instance.setter
    def llm_instance(self, value):
        self._llm_instance = value
        if value is not None:
            self._llm_init_params = None

    def _ensure_loop_guard(self):
        """Lazy-create loop guard on first tool execution."""
        if self._loop_guard is None:
            from ..escalation.loop_guard import LoopGuard, LoopGuardConfig
            self._loop_guard = LoopGuard(LoopGuardConfig(enabled=True))
        return self._loop_guard

    def _ensure_loop_detector(self):
        """Lazy-create the result-aware tool-loop detector on first tool call.

        Returns a (history, config) pair. The detector is enabled by default so
        that name+args+result-hash fingerprinting actually runs in the tool loop.
        A polling tool returning changing output is NOT flagged (streak breaks on
        result-hash change); a genuinely stuck repeat or A->B->A->B oscillation is.
        """
        if self._loop_detector_config is None:
            from .loop_detection import LoopDetectionConfig
            self._loop_detector_config = LoopDetectionConfig(enabled=True)
            self._loop_detector_history = []
        return self._loop_detector_history, self._loop_detector_config
    
    @classmethod
    def _configure_logging(cls):
        """Configure logging settings once for all agent instances."""
        # Configure logging to suppress unwanted outputs
        get_logger("litellm").setLevel(logging.WARNING)
        
        # Allow httpx logging when LOGLEVEL=debug, otherwise suppress it
        loglevel = os.environ.get('LOGLEVEL', 'INFO').upper()
        if loglevel == 'DEBUG':
            get_logger("httpx").setLevel(logging.INFO)
            get_logger("httpcore").setLevel(logging.INFO)
        else:
            get_logger("httpx").setLevel(logging.WARNING)
            get_logger("httpcore").setLevel(logging.WARNING)
    
    @classmethod
    def from_template(
        cls,
        uri: str,
        config: Optional[Dict[str, Any]] = None,
        offline: bool = False,
        **kwargs
    ) -> 'Agent':
        """
        Create an Agent from a template.
        
        Args:
            uri: Template URI (local path, package ref, or github ref)
                Examples:
                - "./my-template" (local path)
                - "transcript-generator" (default recipes repo)
                - "github:owner/repo/template@v1.0.0" (GitHub with version)
                - "package:agent_recipes/transcript-generator" (installed package)
            config: Optional configuration overrides
            offline: If True, only use cached templates (no network)
            **kwargs: Additional Agent constructor arguments
            
        Returns:
            Configured Agent instance
            
        Example:
            ```python
            from praisonaiagents import Agent
            
            # From default recipes repo
            agent = Agent.from_template("transcript-generator")
            result = agent.chat("Transcribe ./audio.mp3")
            
            # With config overrides
            agent = Agent.from_template(
                "data-transformer",
                config={"output_format": "json"},
                verbose=True
            )
            ```
        """
        try:
            # Lazy import to avoid circular dependencies and keep core SDK lean
            from praisonai.templates.loader import create_agent_from_template
            return create_agent_from_template(uri, config=config, offline=offline, **kwargs)
        except ImportError:
            raise ImportError(
                "Template support requires the 'praisonai' package. "
                "Install with: pip install praisonai"
            )
    
    def _generate_tool_definition(self, function_name):
        """
        Generate a tool definition from a function name by inspecting the function.
        """
        logging.debug(f"Attempting to generate tool definition for: {function_name}")
        
        # First try to get the tool definition if it exists
        tool_def_name = f"{function_name}_definition"
        tool_def = globals().get(tool_def_name)
        logging.debug(f"Looking for {tool_def_name} in globals: {tool_def is not None}")
        
        if not tool_def:
            import __main__
            tool_def = getattr(__main__, tool_def_name, None)
            logging.debug(f"Looking for {tool_def_name} in __main__: {tool_def is not None}")
        
        if tool_def:
            logging.debug(f"Found tool definition: {tool_def}")
            return tool_def

        # Try to find the function in the agent's tools list first
        func = None
        for tool in self.tools:
            if callable(tool) and getattr(tool, '__name__', '') == function_name:
                func = tool
                break
        
        logging.debug(f"Looking for {function_name} in agent tools: {func is not None}")
        
        # If not found in tools, try globals and main
        if not func:
            func = globals().get(function_name)
            logging.debug(f"Looking for {function_name} in globals: {func is not None}")
            
            if not func:
                import __main__
                func = getattr(__main__, function_name, None)
                logging.debug(f"Looking for {function_name} in __main__: {func is not None}")

        if not func or not callable(func):
            logging.debug(f"Function {function_name} not found or not callable")
            return None

        # Delegate signature introspection + schema generation to the shared
        # core helper so all layers produce identical, provider-safe schemas
        # (including array 'items' normalisation).
        from ..tools.schema import build_tool_definition
        tool_def = build_tool_definition(func, function_name)
        logging.debug(f"Generated tool definition: {tool_def}")
        return tool_def

    @staticmethod
    def _hosted_backend_for(provider: str):
        """Build the managed backend that ``run_on=<provider>`` is shorthand for.

        ``run_on="anthropic"`` and ``backend=HostedAgent(provider="anthropic")``
        place the agent identically; the first is the readable spelling for the
        common case, the second is what you reach for when the runtime needs
        configuring (model, system prompt, its own tools).
        """
        try:
            from praisonai.integrations import HostedAgent
        except ImportError as exc:
            raise ImportError(
                f"Agent(run_on={provider!r}) runs the whole agent on a managed "
                f"runtime, which ships in the wrapper package.\n"
                f"  pip install praisonai\n"
                f"To keep thinking on this machine and move only the tools, use "
                f"tools_run_on= instead -- that needs no extra install for "
                f"local places."
            ) from exc
        return HostedAgent(provider=provider)

    def __init__(
        self,
        # Core identity
        name: Optional[str] = None,
        role: Optional[str] = None,
        goal: Optional[str] = None,
        backstory: Optional[str] = None,
        instructions: Optional[str] = None,
        # LLM configuration
        llm: Optional[Union[str, Any]] = None,  # Can be string, dict, or LLMConfig object
        model: Optional[Union[str, Any]] = None,  # Alias for llm=
        base_url: Optional[str] = None,  # Kept separate (connection/auth)
        api_key: Optional[str] = None,  # Kept separate (connection/auth)
        auth: Optional[str] = None,  # Subscription auth provider: "claude-code", "codex", etc.
        # Tools
        tools: Optional[List[Any]] = None,
        toolsets: Optional[List[str]] = None,  # Named toolset groups to resolve
        # ============================================================
        # Keyword-only separator.
        #
        # The 7 deprecated params (allow_delegation, allow_code_execution,
        # code_execution_mode, auto_save, rate_limiter, verification_hooks,
        # cli_backend) that used to sit between `toolsets` and `handoffs` were
        # consolidated into **legacy_kwargs (see _LEGACY_AGENT_PARAMS). Making
        # `handoffs` and every consolidated feature param below keyword-only
        # prevents a stray positional value — e.g. an old, undocumented
        # `Agent(..., True)` that used to fill the `allow_delegation` slot —
        # from silently binding to `handoffs` or a config param. All of these
        # are (and have always been) passed by keyword in practice.
        # ============================================================
        *,
        handoffs: Optional[List[Union['Agent', 'Handoff']]] = None,
        # ============================================================
        # CONSOLIDATED FEATURE PARAMS (agent-centric API)
        # Each follows: False=disabled, True=defaults, Config=custom
        # ============================================================
        memory: Optional[Union[bool, str, 'MemoryConfig', Any]] = None,
        knowledge: Optional[Union[bool, str, List[str], 'KnowledgeConfig', 'Knowledge']] = None,
        planning: Optional[Union[bool, str, 'PlanningConfig']] = False,
        reflection: Optional[Union[bool, str, 'ReflectionConfig']] = None,
        rules: Optional[Union[bool, 'RulesConfig']] = None,  # Auto-apply per-project rules (AGENTS.md, .praisonai/rules/)
        guardrails: Optional[Union[bool, str, Callable, 'GuardrailConfig']] = None,
        web: Optional[Union[bool, str, 'WebConfig']] = None,
        context: Optional[Union[bool, str, Dict[str, Any], 'ContextConfig', 'ContextManager']] = None,
        autonomy: Optional[Union[bool, str, Dict[str, Any], 'AutonomyConfig']] = None,
        output: Optional[Union[bool, str, Dict[str, Any], 'OutputConfig']] = None,
        execution: Optional[Union[bool, str, Dict[str, Any], 'ExecutionConfig']] = None,
        templates: Optional[Union[Dict[str, Any], 'TemplateConfig']] = None,
        caching: Optional[Union[bool, str, Dict[str, Any], 'CachingConfig']] = None,
        hooks: Optional[Union[List[Any], Dict[str, Any], 'HooksConfig']] = None,
        skills: Optional[Union[List[str], str, Dict[str, Any], 'SkillsConfig']] = None,
        self_improve: Optional[Union[bool, str, 'SkillReviewProtocol']] = False,  # Autonomous skill self-improvement loop (off by default)
        approval: Optional[Union[bool, str, Dict[str, Any], 'ApprovalConfig', 'ApprovalProtocol']] = None,
        tool_config: Optional[Union[bool, 'ToolConfig']] = None,  # Tool execution configuration (timeout, retry, parallel)
        learn: Optional[Union[bool, str, Dict[str, Any], 'LearnConfig']] = None,  # Continuous learning (peer to memory)
        backend: Optional[Any] = None,  # External managed agent backend (e.g., ManagedAgentIntegration)
        run_on: Optional[Union['ManagedRuntime', str]] = None,  # Run the WHOLE agent on a managed runtime, e.g. "anthropic"
        tools_run_on: Optional[Union['ToolPlace', str, Any]] = None,  # Run only this agent's TOOLS elsewhere, e.g. "docker"
        runtime: Optional[Union[bool, str, Dict[str, Any], 'AgentRuntimeConfig', 'RuntimeConfig']] = None,  # Model-scoped runtime configuration with capability validation
        interrupt_controller: Optional['InterruptController'] = None,  # G2: Cooperative cancellation
        tool_search: Optional[Union[bool, str, Dict[str, Any], 'ToolSearchConfig']] = False,  # Progressive tool disclosure
        message_steering: Optional[Union[bool, 'MessageSteeringProtocol']] = False,  # Real-time message steering during execution
        sandbox: Optional[Union[bool, 'SandboxConfig']] = None,  # Sandbox for safe code execution
        retry: Optional[Union[bool, Dict[str, Any], 'RetryBackoffConfig']] = None,  # Retry configuration with exponential backoff
        reasoning_effort: Optional[str] = None,  # Provider-portable reasoning effort: off|minimal|low|medium|high (Issue #4452)
        **legacy_kwargs: Any,  # Deprecated params (see _LEGACY_AGENT_PARAMS) consolidated into config objects
    ):
        """Initialize an Agent instance.

        Args:
            name: Agent name for identification and logging. Defaults to "Agent".
            role: Role/job title defining expertise (e.g., "Data Analyst").
            goal: Primary objective the agent aims to achieve.
            backstory: Background context shaping personality and decisions.
            instructions: Direct instructions (overrides role/goal/backstory). Recommended for simple agents.
            llm: Model name string ("gpt-4o", "anthropic/claude-3-sonnet"), LLMConfig object, or custom LLM.
                Can accept LLMConfig(model="gpt-4o", fallback_models=["claude-3-5-sonnet", "gpt-4o-mini"]).
                Defaults to OPENAI_MODEL_NAME env var or "gpt-4o-mini".
            model: The model to use, e.g. "gpt-4o-mini" or "anthropic/claude-sonnet-4-5".
                Also accepts an LLMConfig object. This is the canonical name;
                llm= is a deprecated alias for it. Passing both raises TypeError.
            base_url: Custom LLM endpoint URL (e.g., for Ollama). Kept separate for auth.
            api_key: API key for LLM provider. Kept separate for auth.
            tools: List of tools, functions, callables, or MCP instances.
            allow_delegation: **Deprecated** — use ``handoffs=`` instead.
            allow_code_execution: **Deprecated** — use ``execution=ExecutionConfig(code_execution=True)``.
            code_execution_mode: **Deprecated** — use ``execution=ExecutionConfig(code_mode="safe")``.
            handoffs: List of Agent or Handoff objects for agent-to-agent collaboration.
            auto_save: **Deprecated** — use ``memory=MemoryConfig(auto_save="name")``.
            rate_limiter: **Deprecated** — use ``execution=ExecutionConfig(rate_limiter=obj)``.
            memory: Memory system configuration. Accepts:
                - bool: True enables defaults, False disables
                - MemoryConfig: Custom configuration
                - Any: Pre-configured memory instance
            knowledge: Knowledge sources. Accepts:
                - bool: True enables defaults
                - List[str]: File paths, URLs, or text content
                - KnowledgeConfig: Custom configuration
            planning: Planning mode. Accepts:
                - bool: True enables with defaults
                - PlanningConfig: Custom configuration
            reflection: Self-reflection. Accepts:
                - bool: True enables with defaults
                - ReflectionConfig: Custom configuration
            rules: Auto-apply per-project rules/instructions (AGENTS.md, CLAUDE.md,
                .praisonai/rules/*.md) into the system prompt on every run. Accepts:
                - None/True: auto-discover and apply when instruction files exist (default)
                - False: opt out (reproducible/sandboxed runs)
                - RulesConfig: Custom configuration (char_budget, files, workspace_path)
            self_improve: Autonomous skill self-improvement loop (off by default).
                After each task, runs a guarded review pass restricted to the
                ``skill_manage`` tool that asks the agent to capture a reusable
                technique as a new/patched skill. Accepts:
                - bool: True enables with the default review policy, False disables
                - str: "inline"/"blocking" runs the review synchronously (same
                  as True); "background" delivers the reply first and runs the
                  review + auto-memory/auto-learning extraction off the hot path
                  on the core BackgroundJobManager (recommended for long-lived
                  gateway/bot agents, issue #2985).
                - SkillReviewProtocol: Custom review policy
                This is distinct from ``reflection`` (which is answer-quality
                retry) — it captures durable capability across runs.
            guardrails: Output validation. Accepts:
                - bool: True enables with defaults
                - Callable: Validation function
                - GuardrailConfig: Custom configuration
            web: Web search/fetch. Accepts:
                - bool: True enables with defaults
                - WebConfig: Custom configuration
            context: Context management. Accepts:
                - bool: True enables with defaults
                - str: Preset name ("sliding_window", "summarize", "truncate")
                - Dict[str, Any]: ContextConfig fields
                - ContextConfig: Custom configuration
                - ContextManager: Pre-configured instance
            autonomy: Autonomy settings. Accepts:
                - bool: True enables with defaults
                - str: Level preset ("suggest", "auto_edit", "full_auto")
                - Dict[str, Any]: Configuration dict
                - AutonomyConfig: Custom configuration
            verification_hooks: **Deprecated** — use ``autonomy=AutonomyConfig(verification_hooks=[...])``.
                Still works for backward compatibility.
            output: Output configuration. Accepts:
                - bool: True=default OutputConfig, False=disabled
                - str: Preset name ("silent", "actions", "verbose", "json", "stream")
                - Dict[str, Any]: Config overrides (e.g. {"verbose": 2, "stream": True})
                - OutputConfig: Custom configuration
                Controls: verbose, markdown, stream, metrics, reasoning_steps
            execution: Execution configuration. Accepts:
                - bool: True=default ExecutionConfig, False=disabled
                - str: Preset name ("fast", "balanced", "thorough")
                - Dict[str, Any]: Config overrides (e.g. {"max_iter": 10, "max_rpm": 60})
                - ExecutionConfig: Custom configuration
                Controls: max_iter, max_rpm, max_execution_time, max_retry_limit
            templates: Template configuration. Accepts:
                - Dict[str, Any]: Template fields (e.g. {"system": "...", "prompt": "..."})
                - TemplateConfig: Custom configuration
                Controls: system_template, prompt_template, response_template
            caching: Caching configuration. Accepts:
                - bool: True enables with defaults
                - CachingConfig: Custom configuration
            hooks: Event hooks. Accepts:
                - List: List of hook callables
                - HooksConfig: Custom configuration
            skills: Agent skills. Accepts:
                - List[str]: Skill directory paths
                - SkillsConfig: Custom configuration
            learn: Continuous learning configuration. Accepts:
                - bool: True enables with defaults (AGENTIC mode), False disables
                - str: Mode string ("disabled", "agentic", "propose")
                - Dict[str, Any]: Config fields (e.g. {"mode": "agentic", "backend": "sqlite"})
                - LearnConfig: Custom configuration
                Learning is a first-class citizen, peer to memory. It captures patterns,
                preferences, and insights from interactions to improve future responses.
            tool_config: Tool execution configuration. Accepts:
                - bool: True enables defaults, False disables
                - ToolConfig: Custom configuration for timeout, retry policy, parallel execution
                Consolidates tool timeout, retry policy, and parallel execution settings.
            backend: External managed agent backend for hybrid execution. Accepts:
                - ManagedAgentIntegration: External managed agent service
                - None: Use local execution (default)
                When provided, agent can delegate execution to managed infrastructure
                for long-running tasks or when local resources are constrained.
            cli_backend: **DEPRECATED** CLI backend for delegating full turns. Use 'runtime' parameter instead.
                This parameter is deprecated in favor of model-scoped runtime configuration.
                Will emit deprecation warning when used.
            runtime: Model-scoped runtime configuration with capability validation. Accepts:
                - bool: False=disabled, True=basic capability validation
                - str: Runtime ID ("claude-code", "praisonai", "native", "plugin-harness") 
                - Dict[str, Any]: Runtime config with required_capabilities, preferred_runtime, config_overrides, etc.
                - AgentRuntimeConfig: Pre-configured runtime instance (model-scoped)
                - RuntimeConfig: Configuration with capability requirements and preferences
                - None: Use model-based resolution (default)
                Combines turn delegation with per-model runtime selection and fail-fast capability
                validation at config time to catch incompatibilities early.
            tool_search: Progressive tool disclosure configuration. Accepts:
                - bool: False=disabled (default), True=auto mode
                - str: Mode ("auto", "on", "off")  
                - Dict[str, Any]: Config overrides (e.g. {"threshold_pct": 15})
                - ToolSearchConfig: Custom configuration
                When enabled, replaces large tool schemas with bridge tools (tool_search,
                tool_describe, tool_call) to save context. Core SDK tools never defer.
                Auto mode activates based on token threshold. Opt-in feature.

        Raises:
            ValueError: If all of name, role, goal, backstory, and instructions are None.
            ImportError: If memory or LLM features are requested but dependencies are not installed.

        Note:
            Many legacy parameters have been consolidated into config objects:
            - verbose, markdown, stream, metrics, reasoning_steps → output=
            - max_iter, max_rpm, max_execution_time, max_retry_limit → execution=
            - self_reflect, max_reflect, min_reflect, reflect_llm → reflection=
            - guardrail, max_guardrail_retries → guardrails=
            - system_template, prompt_template, response_template → templates=
            - cache, prompt_caching → caching=
            - web_search, web_fetch → web=
            - allow_delegation → handoffs=
            - allow_code_execution, code_execution_mode → execution=
            - auto_save → memory=MemoryConfig(auto_save=)
            - rate_limiter → execution=ExecutionConfig(rate_limiter=)
            - verification_hooks → autonomy=AutonomyConfig(verification_hooks=)
            - Use tool_config=ToolConfig(...) for tool execution configuration
        """
        # ============================================================
        # LEGACY PARAM UNPACKING
        # Deprecated params are accepted via **legacy_kwargs to keep the
        # visible constructor signature minimal. They are rebound to locals
        # here with their original defaults so downstream logic is unchanged,
        # and still emit DeprecationWarnings further below.
        # ============================================================
        _legacy_defaults = Agent._LEGACY_AGENT_PARAMS
        # Internal-only kwarg: clone_for_channel() forwards the resolved
        # fallback_models list so per-channel clones keep their LLM fallbacks.
        # There is no public fallback_models= param (it is set via
        # LLMConfig(fallback_models=[...])), so accept it here without exposing
        # it in the signature and seed the local below.
        _cloned_fallback_models = legacy_kwargs.pop("fallback_models", None)
        # `thinking_budget` is a backward-compatible alias for `reasoning_effort`
        # (Issue #4452); accept it here (like fallback_models) without exposing
        # it in the signature so the unknown-kwarg guard below does not reject it.
        _thinking_budget_alias = legacy_kwargs.pop("thinking_budget", None)
        _unknown = set(legacy_kwargs) - _legacy_defaults.keys()
        if _unknown:
            # Unknown kwargs are rejected rather than swallowed, so a typo can
            # never silently disable the behaviour it was meant to configure.
            # Some names are near-universal in this ecosystem, though -- and
            # `verbose` is accepted by six sibling classes here -- so name the
            # supported alternative instead of leaving the user to search a
            # 41-parameter signature for something that is not in it.
            _HINTS = {
                "verbose": (
                    "verbosity moved into output=; use output='verbose' "
                    "(or output=OutputConfig(verbose=True))."
                ),
                "stream": (
                    "streaming moved into output=; use "
                    "output=OutputConfig(stream=True)."
                ),
            }
            _hint = "".join(
                f"\n  {name}: {_HINTS[name]}" for name in sorted(_unknown) if name in _HINTS
            )
            raise TypeError(
                f"Agent.__init__() got unexpected keyword argument(s): "
                f"{', '.join(sorted(_unknown))}{_hint}"
            )
        allow_delegation = legacy_kwargs.get("allow_delegation", _legacy_defaults["allow_delegation"])
        allow_code_execution = legacy_kwargs.get("allow_code_execution", _legacy_defaults["allow_code_execution"])
        code_execution_mode = legacy_kwargs.get("code_execution_mode", _legacy_defaults["code_execution_mode"])
        auto_save = legacy_kwargs.get("auto_save", _legacy_defaults["auto_save"])
        rate_limiter = legacy_kwargs.get("rate_limiter", _legacy_defaults["rate_limiter"])
        verification_hooks = legacy_kwargs.get("verification_hooks", _legacy_defaults["verification_hooks"])
        cli_backend = legacy_kwargs.get("cli_backend", _legacy_defaults["cli_backend"])

        # ── where does this agent run? ───────────────────────────────────────
        # Resolved before anything else is built so a contradiction fails at the
        # call site, with the parameter name the user actually wanted, instead
        # of surfacing later as tools mysteriously running on the wrong machine.
        from .placement import resolve_placement

        _placement = resolve_placement(
            "Agent", run_on=run_on, tools_run_on=tools_run_on, backend=backend
        )
        if _placement.whole is not None:
            backend = self._hosted_backend_for(_placement.whole)
        self.tools_run_on = _placement.tools
        self._tools_sandbox = None

        # Add check at start if memory is requested.
        # Skip the probe for values that resolve to the zero-dependency FileMemory
        # backend (True, "file", and file-provider dicts without learn); those never
        # touch the heavy memory.memory module, so probing it just wastes an import.
        _uses_file_memory = (
            memory is True
            or memory == "file"
            or (
                isinstance(memory, dict)
                and not memory.get("learn", False)
                and memory.get("provider", memory.get("backend", "file")) == "file"
            )
        )
        if memory is not None and not _uses_file_memory:
            try:
                from ..memory.memory import Memory  # noqa: F401
                _ = Memory  # Silence unused import warning - we just check availability
            except ImportError:
                raise ImportError(
                    "Memory features requested in Agent but memory dependencies not installed. "
                    "Please install with: pip install \"praisonaiagents[memory]\""
                )

        # Handle backward compatibility for required fields
        if all(x is None for x in [name, role, goal, backstory, instructions]):
            raise ValueError("At least one of name, role, goal, backstory, or instructions must be provided")

        # Configure logging only once at the class level
        if not hasattr(Agent, '_logging_configured'):
            Agent._configure_logging()
            Agent._logging_configured = True

        # Auto-enable entry-point plugins when PRAISONAI_PLUGINS / config.toml requests it
        try:
            from ..plugins import maybe_enable_from_config
            maybe_enable_from_config()
        except Exception as _plugin_exc:
            import logging as _logging
            _logging.getLogger(__name__).debug("Plugin auto-enable failed: %s", _plugin_exc)

        # ============================================================
        # CONFIG-DRIVEN DEFAULTS (apply before parameter resolution)
        # Precedence: Explicit params > Config file > Built-in defaults
        # Only applies when param is None (not explicitly set)
        # ============================================================
        from ..config.loader import apply_config_defaults, get_default, _defaults_has_any_values
        
        # Apply config defaults for LLM if not explicitly set
        if llm is None and model is None and _defaults_has_any_values():
            config_model = get_default("model")
            if config_model:
                llm = config_model
        
        # Apply config defaults for base_url if not explicitly set
        if base_url is None and _defaults_has_any_values():
            config_base_url = get_default("base_url")
            if config_base_url:
                base_url = config_base_url
        
        # Apply config defaults for feature params (memory, knowledge, etc.)
        # These use apply_config_defaults which handles enabled=True/False logic
        if memory is None:
            memory = apply_config_defaults("memory", memory, MemoryConfig)
        if knowledge is None:
            knowledge = apply_config_defaults("knowledge", knowledge, KnowledgeConfig)
        if planning is False:  # Only override if explicitly False (default)
            config_planning = apply_config_defaults("planning", None, PlanningConfig)
            if config_planning:
                planning = config_planning
        if reflection is None:
            reflection = apply_config_defaults("reflection", reflection, ReflectionConfig)
        if web is None:
            web = apply_config_defaults("web", web, WebConfig)
        if output is None:
            output = apply_config_defaults("output", output, OutputConfig)
        if execution is None:
            execution = apply_config_defaults("execution", execution, ExecutionConfig)
        if caching is None:
            caching = apply_config_defaults("caching", caching, CachingConfig)
        if autonomy is None:
            # AutonomyConfig is in agent/autonomy.py - use dict for config defaults
            autonomy = apply_config_defaults("autonomy", autonomy, None)
        if retry is None:
            retry = apply_config_defaults("retry", retry, RetryBackoffConfig)

        # ============================================================
        # DEPRECATION WARNINGS for params consolidated into configs
        # Old params still work but emit warnings pointing to new API
        # ============================================================
        from ..utils.deprecation import warn_deprecated_param
        
        if allow_delegation:
            warn_deprecated_param(
                "allow_delegation",
                since="1.0.0",
                removal="2.0.0",
                alternative="use 'handoffs=[other_agent]' instead",
                stacklevel=3
            )
        if allow_code_execution:
            warn_deprecated_param(
                "allow_code_execution", 
                since="1.0.0",
                removal="2.0.0",
                alternative="use 'execution=ExecutionConfig(code_execution=True)' instead",
                stacklevel=3
            )
        if code_execution_mode != "safe":
            warn_deprecated_param(
                "code_execution_mode",
                since="1.0.0", 
                removal="2.0.0",
                alternative='use \'execution=ExecutionConfig(code_mode="unsafe")\' instead',
                stacklevel=3
            )
        if auto_save is not None:
            warn_deprecated_param(
                "auto_save",
                since="1.0.0",
                removal="2.0.0", 
                alternative='use \'memory=MemoryConfig(auto_save="name")\' instead',
                stacklevel=3
            )
        if rate_limiter is not None:
            warn_deprecated_param(
                "rate_limiter",
                since="1.0.0",
                removal="2.0.0",
                alternative="use 'execution=ExecutionConfig(rate_limiter=obj)' instead",
                stacklevel=3
            )
        # Note: parallel_tool_calls moved to tool_config pattern
        if verification_hooks is not None:
            warn_deprecated_param(
                "verification_hooks",
                since="1.0.0", 
                removal="2.0.0",
                alternative="use 'autonomy=AutonomyConfig(verification_hooks=[...])' instead",
                stacklevel=3
            )

        # ============================================================
        # CONSOLIDATED PARAMS EXTRACTION (agent-centric API)
        # Uses unified resolver: Instance > Config > Array > String > Bool > Default
        # Note: Imports moved to module level for performance
        # ============================================================
        # Reject a typo'd preset name (e.g. output="streem", approval="read_onl")
        # before any of the fast paths below silently fall back to defaults.
        # memory/planning/reflection/web/caching/tool_search already raise via
        # their own resolvers; this covers the params that did not.
        _validate_preset_params({
            "output": output,
            "execution": execution,
            "context": context,
            "autonomy": autonomy,
            "approval": approval,
            "learn": learn,
            "self_improve": self_improve,
        })

        # Initialize extracted values with defaults
        user_id = None
        session_id = None
        db = None
        auto_memory = None
        claude_memory = None
        self_reflect = False
        max_reflect = 3
        min_reflect = 1
        reflect_llm = None
        reflect_prompt = None
        guardrail = None
        max_guardrail_retries = 3
        web_search = None
        web_fetch = None
        plan_mode = False
        planning_tools = None
        planning_reasoning = False
        policy = None
        output_style = None
        # `thinking_budget` (popped above) is a backward-compatible alias for
        # `reasoning_effort` (Issue #4452). Fold the legacy int budget / graded
        # level into one internal effort value for the LLM request pipeline.
        if reasoning_effort is None and _thinking_budget_alias is not None:
            reasoning_effort = _thinking_budget_alias
        skills_dirs = None
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve OUTPUT param - FAST PATH for common cases
        # DEFAULT: "silent" mode (zero overhead, fastest performance)
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None -> silent defaults (use cached env var)
        if output is None:
            env_output = Agent._get_env_output_mode()
            if env_output and env_output in OUTPUT_PRESETS:
                output = env_output
            else:
                output = DEFAULT_OUTPUT_MODE
            _has_explicit_output = False
        else:
            _has_explicit_output = True
        
        # Fast path: string preset lookup (most common case)
        if isinstance(output, str):
            from ..config.parse_utils import canonical_preset_key
            output_lower = canonical_preset_key(output)
            preset_value = OUTPUT_PRESETS.get(output_lower)
            if preset_value is not None:
                _output_config = OutputConfig(**preset_value) if isinstance(preset_value, dict) else preset_value
            elif _is_file_path(output):
                # String looks like a file path - use as output_file
                _output_config = OutputConfig(output_file=output)
            else:
                _output_config = OutputConfig()  # Default silent
        elif isinstance(output, OutputConfig):
            _output_config = output
        else:
            # Complex case: use full resolver
            _output_config = resolve(
                value=output,
                param_name="output",
                config_class=OutputConfig,
                presets=OUTPUT_PRESETS,
                array_mode=ArrayMode.PRESET_OVERRIDE,
                default=OutputConfig(),
            )
        if _output_config:
            verbose = _output_config.verbose
            markdown = _output_config.markdown
            stream = _output_config.stream
            metrics = _output_config.metrics
            reasoning_steps = _output_config.reasoning_steps
            output_style = getattr(_output_config, 'style', None)
            actions_trace = getattr(_output_config, 'actions_trace', False)  # Default False (silent)
            json_output = getattr(_output_config, 'json_output', False)
            status_trace = getattr(_output_config, 'status_trace', False)  # New: clean inline status
            simple_output = getattr(_output_config, 'simple_output', False)  # status preset: no timestamps
            editor_output = getattr(_output_config, 'editor_output', False)  # Editor: Step N display
            output_file = getattr(_output_config, 'output_file', None)  # Auto-save to file
            output_template = getattr(_output_config, 'template', None)  # Response template
            tool_output_limit = getattr(_output_config, 'tool_output_limit', DEFAULT_TOOL_OUTPUT_LIMIT)
        else:
            # Fallback defaults match silent mode (zero overhead)
            verbose, markdown, stream, metrics, reasoning_steps = False, False, False, False, False
            actions_trace = False  # No callbacks by default
            json_output = False
            status_trace = False
            simple_output = False
            editor_output = False
            tool_output_limit = DEFAULT_TOOL_OUTPUT_LIMIT
        
        # Output modes (editor/trace/status) register callbacks on the same
        # process-wide, event-type-keyed registry in main.py, so they are
        # mutually exclusive at the process level. If a *different* mode is
        # already active (e.g. a prior Agent enabled it), we must not clobber
        # its callbacks — that would silently route this agent's events through
        # the other mode's sink (wrong formatting/redaction). First mode wins.
        def _any_output_mode_enabled():
            try:
                from ..output.editor import is_editor_output_enabled
                if is_editor_output_enabled():
                    return True
            except ImportError:
                pass
            try:
                from ..output.trace import is_trace_output_enabled
                if is_trace_output_enabled():
                    return True
            except ImportError:
                pass
            try:
                from ..output.status import is_status_output_enabled
                if is_status_output_enabled():
                    return True
            except ImportError:
                pass
            return False

        # The check-and-enable below must be atomic across threads: two Agents
        # constructed concurrently could otherwise both see "no mode enabled"
        # and clobber each other's callbacks. Only take the lock when a mode is
        # actually requested (the common silent path stays lock-free).
        if editor_output or status_trace or actions_trace:
            with _output_mode_lock:
                # Enable editor output mode if configured (beginner-friendly, takes priority)
                # Shows: Step 1: 📄 Creating file: path → ✓ Done
                if editor_output:
                    try:
                        from ..output.editor import enable_editor_output, is_editor_output_enabled
                        if not is_editor_output_enabled() and not _any_output_mode_enabled():
                            enable_editor_output(use_color=True)
                    except ImportError:
                        pass  # Editor module not available
                # Enable trace output mode if configured
                # This provides timestamped inline status with duration
                elif status_trace:
                    try:
                        from ..output.trace import enable_trace_output, is_trace_output_enabled
                        if not is_trace_output_enabled() and not _any_output_mode_enabled():
                            enable_trace_output(use_color=True, show_timestamps=True)
                    except ImportError:
                        pass  # Trace module not available
                # Enable status output mode if configured (simple progress, no timestamps)
                # This registers callbacks to capture tool calls and final output
                elif actions_trace:
                    try:
                        from ..output.status import enable_status_output, is_status_output_enabled
                        if not is_status_output_enabled() and not _any_output_mode_enabled():
                            output_format = "jsonl" if json_output else "text"
                            # simple_output=True means status preset (no timestamps)
                            # metrics=True means debug preset (show token/cost info)
                            enable_status_output(
                                redact=True,
                                use_color=True,
                                format=output_format,
                                show_timestamps=not simple_output,
                                show_metrics=metrics
                            )
                    except ImportError:
                        pass  # Status module not available
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve EXECUTION param - FAST PATH for common cases
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None -> default config (skip resolve() call)
        if execution is None:
            _exec_config = ExecutionConfig()
        elif isinstance(execution, ExecutionConfig):
            _exec_config = execution
        elif isinstance(execution, str):
            from ..config.parse_utils import canonical_preset_key
            preset_value = EXECUTION_PRESETS.get(canonical_preset_key(execution))
            if preset_value is not None:
                _exec_config = ExecutionConfig(**preset_value) if isinstance(preset_value, dict) else preset_value
            else:
                _exec_config = ExecutionConfig()
        else:
            _exec_config = resolve(
                value=execution,
                param_name="execution",
                config_class=ExecutionConfig,
                presets=EXECUTION_PRESETS,
                array_mode=ArrayMode.PRESET_OVERRIDE,
                default=ExecutionConfig(),
            )
        if _exec_config:
            # Unified step budget: when max_steps is set it governs the LiteLLM
            # loop (LLM.max_iter) too, so both tool-execution loops honour the
            # same budget. Falls back to max_iter when max_steps is unset.
            _resolver = getattr(_exec_config, "resolved_max_steps", None)
            max_iter = _resolver() if callable(_resolver) else _exec_config.max_iter
            max_rpm = _exec_config.max_rpm
            max_execution_time = _exec_config.max_execution_time
            max_retry_limit = _exec_config.max_retry_limit
            # Extract consolidated fields (config takes precedence over deprecated standalone params)
            if _exec_config.rate_limiter is not None:
                rate_limiter = _exec_config.rate_limiter
            if _exec_config.code_execution:
                allow_code_execution = True
            if _exec_config.code_mode != "safe":
                code_execution_mode = _exec_config.code_mode
            # Get parallel_tool_calls from ExecutionConfig
            parallel_tool_calls = getattr(_exec_config, 'parallel_tool_calls', False)
            # Budget guard extraction
            _max_budget = getattr(_exec_config, 'max_budget', None)
            _on_budget_exceeded = getattr(_exec_config, 'on_budget_exceeded', 'stop') or 'stop'
        else:
            max_iter, max_rpm, max_execution_time, max_retry_limit = 20, None, None, 2
            _max_budget = None
            _on_budget_exceeded = 'stop'
            # Default to False when no ExecutionConfig provided
            parallel_tool_calls = False
            _exec_config = ExecutionConfig()  # Default config for non-execution case
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve TEMPLATES param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None -> no templates (skip resolve() call)
        if templates is None:
            _template_config = None
        elif isinstance(templates, TemplateConfig):
            _template_config = templates
        elif isinstance(templates, dict):
            _template_config = TemplateConfig(**templates)
        else:
            _template_config = resolve(
                value=templates,
                param_name="templates",
                config_class=TemplateConfig,
                default=None,
            )
        if _template_config:
            system_template = _template_config.system
            prompt_template = _template_config.prompt
            response_template = _template_config.response
            use_system_prompt = _template_config.use_system_prompt
        else:
            system_template, prompt_template, response_template, use_system_prompt = None, None, None, True
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve CACHING param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None -> default caching, False -> disabled
        if caching is None:
            _caching_config = CachingConfig()
        elif caching is False:
            _caching_config = None
        elif caching is True:
            _caching_config = CachingConfig()
        elif isinstance(caching, CachingConfig):
            _caching_config = caching
        else:
            _caching_config = resolve(
                value=caching,
                param_name="caching",
                config_class=CachingConfig,
                presets=CACHING_PRESETS,
                default=CachingConfig(),
            )
        if _caching_config:
            cache = _caching_config.enabled
            prompt_caching = _caching_config.prompt_caching
        elif caching is False:
            cache, prompt_caching = False, None
        else:
            cache, prompt_caching = True, None
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve HOOKS param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        _hooks_list = []
        step_callback = None
        # Fast path: None -> no hooks (skip resolve() call)
        if hooks is None:
            _hooks_config = None
        elif isinstance(hooks, list):
            _hooks_config = hooks  # Passthrough list directly
        elif isinstance(hooks, HooksConfig):
            _hooks_config = hooks
        else:
            _hooks_config = resolve(
                value=hooks,
                param_name="hooks",
                config_class=HooksConfig,
                array_mode=ArrayMode.PASSTHROUGH,
                default=None,
            )
        if _hooks_config is not None:
            if isinstance(_hooks_config, list):
                _hooks_list = _hooks_config
            elif isinstance(_hooks_config, HooksConfig):
                step_callback = _hooks_config.on_step
                _hooks_list = _hooks_config.middleware or []
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve SKILLS param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        _skills = None
        skills_dirs = None
        # Fast path: None -> no skills (skip resolve() call)
        if skills is None:
            _skills_config = None
        elif isinstance(skills, list):
            _skills_config = SkillsConfig(paths=skills)
        elif isinstance(skills, SkillsConfig):
            _skills_config = skills
        else:
            _skills_config = resolve(
                value=skills,
                param_name="skills",
                config_class=SkillsConfig,
                array_mode=ArrayMode.SOURCES,
                string_mode="path_as_source",
                default=None,
            )
        _skills_auto_discover = False
        if _skills_config is not None:
            if isinstance(_skills_config, SkillsConfig):
                _skills = _skills_config.paths
                skills_dirs = _skills_config.dirs
                _skills_auto_discover = bool(_skills_config.auto_discover)
            elif isinstance(_skills_config, list):
                _skills = _skills_config
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve MEMORY param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None/False -> no memory (skip resolve() call)
        if memory is None or memory is False:
            _memory_config = None
        elif memory is True:
            _memory_config = MemoryConfig()
        elif isinstance(memory, MemoryConfig):
            _memory_config = memory
        elif hasattr(memory, 'search') and hasattr(memory, 'add'):
            _memory_config = memory  # Memory instance passthrough
        elif hasattr(memory, 'database_url'):
            _memory_config = memory  # db() instance passthrough
        else:
            _memory_config = resolve(
                value=memory,
                param_name="memory",
                config_class=MemoryConfig,
                presets=MEMORY_PRESETS,
                url_schemes=MEMORY_URL_SCHEMES,
                instance_check=lambda v: (hasattr(v, 'search') and hasattr(v, 'add')) or hasattr(v, 'database_url'),
                array_mode=ArrayMode.SINGLE_OR_LIST,
                default=None,
            )
        
        # Persist the resolved memory config so clone_for_channel() can forward
        # (and isolate) it per channel. Without this, clones would receive no
        # memory config at all (getattr returned None).
        #
        # A live Memory/db() backend passed by the user is NOT reconstructable
        # configuration - it is a single shared store. If we persisted it here,
        # _isolated_memory_for_clone() would forward the same object by reference
        # to every per-channel clone, leaking one user's memory into another.
        # Leave _memory_config unset for live backends so the clone falls back to
        # _memory_instance and rebuilds an isolated backend.
        _is_live_backend = (
            _memory_config is not None
            and not isinstance(_memory_config, MemoryConfig)
            and (
                (hasattr(_memory_config, 'search') and hasattr(_memory_config, 'add'))
                or hasattr(_memory_config, 'database_url')
            )
        )
        self._memory_config = None if _is_live_backend else _memory_config

        # Extract values from resolved memory config
        if _memory_config is not None:
            if hasattr(_memory_config, 'database_url'):
                # It's a db() instance - pass through
                db = _memory_config
                memory = True
            elif isinstance(_memory_config, MemoryConfig):
                user_id = _memory_config.user_id
                session_id = _memory_config.session_id
                db = _memory_config.db
                auto_memory = _memory_config.auto_memory
                claude_memory = _memory_config.claude_memory
                # Extract auto_save from MemoryConfig (takes precedence over standalone param)
                if _memory_config.auto_save is not None:
                    auto_save = _memory_config.auto_save
                # Convert to internal format
                memory_backend = _memory_config.backend
                if hasattr(memory_backend, 'value'):
                    memory_backend = memory_backend.value
                # If learn is enabled, pass as dict to trigger full Memory class
                if _memory_config.learn:
                    memory = _memory_config.to_dict()
                elif memory_backend == "file":
                    memory = True
                elif _memory_config.config:
                    memory = _memory_config.config
                else:
                    memory = memory_backend
            elif hasattr(_memory_config, 'search') and hasattr(_memory_config, 'add'):
                # Memory instance - pass through
                pass
        elif memory is False:
            memory = None
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve LEARN param - FAST PATH (top-level, peer to memory)
        # learn= is a first-class citizen, independent of memory=
        # ─────────────────────────────────────────────────────────────────────
        from ..config.feature_configs import LearnConfig
        
        _learn_config = None
        
        # Top-level learn= takes precedence over memory.learn
        if learn is not None:
            # Explicit top-level learn= param
            if learn is False:
                _learn_config = None
            elif learn is True:
                # learn=True shorthand enables AGENTIC mode (auto-learning)
                from ..memory.learn.protocols import LearnMode
                _learn_config = LearnConfig(mode=LearnMode.AGENTIC)
            elif isinstance(learn, LearnConfig):
                _learn_config = learn
            elif isinstance(learn, dict):
                _learn_config = LearnConfig(**learn)
            elif isinstance(learn, str):
                # String mode: "disabled", "agentic", "propose".
                # Normalise case/whitespace so this branch agrees with the
                # closed-set validation in _validate_preset_params (which
                # already accepted "AGENTIC"/" agentic "); otherwise a validated
                # value would fall through to the else and silently disable.
                from ..memory.learn.protocols import LearnMode
                _learn_mode = learn.strip().lower()
                if _learn_mode == "disabled":
                    _learn_config = None
                elif _learn_mode == "agentic":
                    _learn_config = LearnConfig(mode=LearnMode.AGENTIC)
                elif _learn_mode == "propose":
                    _learn_config = LearnConfig(mode=LearnMode.PROPOSE)
                else:
                    # Unknown string mode, disable learning
                    _learn_config = None
            else:
                logging.warning(
                    "Unsupported learn= value %r; expected bool, dict, or LearnConfig. "
                    "Learning disabled.", learn
                )
                _learn_config = None
        elif _memory_config is not None and isinstance(_memory_config, MemoryConfig):
            # Fallback to memory.learn for backward compatibility
            if _memory_config.learn:
                if _memory_config.learn is True:
                    # learn=True shorthand enables AGENTIC mode
                    from ..memory.learn.protocols import LearnMode
                    _learn_config = LearnConfig(mode=LearnMode.AGENTIC)
                elif isinstance(_memory_config.learn, LearnConfig):
                    _learn_config = _memory_config.learn
                elif isinstance(_memory_config.learn, dict):
                    _learn_config = LearnConfig(**_memory_config.learn)
        
        # If learn is enabled but memory is not, we need to enable memory for learn to work
        if _learn_config is not None and memory is None:
            # Enable minimal memory for learn to work
            memory = {"learn": _learn_config.to_dict() if hasattr(_learn_config, 'to_dict') else _learn_config}
        elif _learn_config is not None and isinstance(memory, dict):
            # Merge learn config into memory dict
            memory["learn"] = _learn_config.to_dict() if hasattr(_learn_config, 'to_dict') else _learn_config
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve HISTORY from MemoryConfig - FAST PATH
        # History is enabled via memory="history" preset or MemoryConfig(history=True)
        # ─────────────────────────────────────────────────────────────────────
        _history_enabled = False
        _history_limit = 10
        _history_session_id = None
        
        # Check if memory config has history settings
        if _memory_config is not None and isinstance(_memory_config, MemoryConfig):
            if _memory_config.history:
                _history_enabled = True
                _history_limit = _memory_config.history_limit
                # Use explicit session_id from MemoryConfig if provided
                if _memory_config.session_id:
                    _history_session_id = _memory_config.session_id
        
        # Use auto_save session if no explicit session and history is enabled
        if _history_enabled and _history_session_id is None and auto_save:
            _history_session_id = auto_save
        
        # Auto-generate session_id when history=True but no session_id set
        # This ensures _init_session_store() can create the store
        if _history_enabled and session_id is None and _history_session_id is not None:
            session_id = _history_session_id
        elif _history_enabled and session_id is None and _history_session_id is None:
            import hashlib as _hl
            import os as _os
            _name = name or "agent"
            # Workspace-scoped id so same-named agents in different projects don't
            # collide (Issue #3154). Opt out with PRAISONAI_GLOBAL_SESSIONS=true for
            # name-only global continuity.
            _global_scope = _os.environ.get("PRAISONAI_GLOBAL_SESSIONS", "").lower() in ("1", "true", "yes")
            if _global_scope:
                _workspace_id = "global"
            else:
                from ..session.workspace import workspace_id as _wid
                _workspace_id = _wid()
            _workspace_hash = _hl.sha256(f"{_workspace_id}:{_name}".encode()).hexdigest()[:8]
            _new_id = f"history_{_workspace_hash}"
            # Backward-compat ids (resolution order: name-only sha256, then md5)
            _name_sha_id = f"history_{_hl.sha256(_name.encode()).hexdigest()[:8]}"
            _name_md5_id = f"history_{_hl.md5(_name.encode()).hexdigest()[:8]}"
            # Resolve the migration lookup against the SAME directory the session
            # store uses at runtime, so a custom PRAISONAI_HOME is honoured (the
            # store reads from get_sessions_dir()). Fall back to the default path
            # only if that helper is unavailable.
            try:
                from ..paths import get_sessions_dir as _get_sessions_dir
                _session_dir = str(_get_sessions_dir())
            except Exception:
                _session_dir = _os.path.join(_os.path.expanduser("~"), ".praisonai", "sessions")
            # Prefer an existing workspace-scoped session. Legacy (pre-workspace)
            # name-only files are only adopted in global scope: doing so in a
            # workspace-scoped run would silently share Project A's history with a
            # same-named agent in Project B (Issue #3154). Global scope is the
            # explicit opt-in for that name-only continuity.
            if _os.path.exists(_os.path.join(_session_dir, f"{_new_id}.json")):
                session_id = _new_id
            elif _global_scope and _os.path.exists(_os.path.join(_session_dir, f"{_name_sha_id}.json")):
                session_id = _name_sha_id  # preserve existing history
            elif _global_scope and _os.path.exists(_os.path.join(_session_dir, f"{_name_md5_id}.json")):
                session_id = _name_md5_id  # preserve existing history
            else:
                session_id = _new_id
            _history_session_id = session_id
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve KNOWLEDGE param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        retrieval_config = None
        embedder_config = None
        
        # Fast path: None/False -> no knowledge (skip resolve() call)
        if knowledge is None or knowledge is False:
            _knowledge_config = None
        elif knowledge is True:
            _knowledge_config = KnowledgeConfig()
        elif isinstance(knowledge, KnowledgeConfig):
            _knowledge_config = knowledge
        elif isinstance(knowledge, list):
            _knowledge_config = KnowledgeConfig(sources=knowledge)
        elif hasattr(knowledge, 'search') and hasattr(knowledge, 'add'):
            _knowledge_config = knowledge  # Knowledge instance passthrough
        else:
            _knowledge_config = resolve(
                value=knowledge,
                param_name="knowledge",
                config_class=KnowledgeConfig,
                instance_check=lambda v: hasattr(v, 'search') and hasattr(v, 'add'),
                array_mode=ArrayMode.SOURCES_WITH_CONFIG,
                string_mode="path_as_source",
                default=None,
            )
        
        if _knowledge_config is not None:
            if hasattr(_knowledge_config, 'search') and hasattr(_knowledge_config, 'add'):
                # Knowledge instance - pass through
                knowledge = _knowledge_config
            elif isinstance(_knowledge_config, KnowledgeConfig):
                embedder_config = _knowledge_config.embedder_config
                # Every declared field is forwarded. Previously only top_k /
                # rerank survived: 'threshold' was spelled 'min_score' by
                # RetrievalConfig.from_dict, 'rerank_model' had no field at
                # all, and chunking + vector_store were never forwarded, so
                # those settings were silently inert.
                _chunker = _knowledge_config.chunker or {}
                _strategy = _knowledge_config.chunking_strategy
                _strategy = getattr(_strategy, 'value', _strategy)
                _vector_store = _knowledge_config.vector_store or {}
                retrieval_config = {
                    'enabled': _knowledge_config.auto_retrieve,
                    'top_k': _knowledge_config.retrieval_k,
                    'min_score': _knowledge_config.retrieval_threshold,
                    'rerank': _knowledge_config.rerank,
                    'rerank_model': _knowledge_config.rerank_model,
                    'chunking_strategy': _chunker.get('type', _strategy),
                    'chunk_size': _chunker.get('chunk_size', _knowledge_config.chunk_size),
                    'chunk_overlap': _chunker.get(
                        'chunk_overlap', _knowledge_config.chunk_overlap),
                }
                if _vector_store:
                    _vs = dict(_vector_store)
                    _vs_provider = _vs.pop('provider', None)
                    if _vs_provider:
                        retrieval_config['vector_store_provider'] = _vs_provider
                    _vs_inner = _vs.pop('config', None)
                    if isinstance(_vs_inner, dict):
                        _vs.update(_vs_inner)
                    if 'collection_name' in _vs:
                        retrieval_config['collection_name'] = _vs.pop('collection_name')
                    if 'path' in _vs:
                        retrieval_config['persist_path'] = _vs.pop('path')
                    if _vs:
                        retrieval_config['vector_store_config'] = _vs
                # Forward embedder settings so they reach Knowledge (mem0).
                # embedder is a provider shorthand (e.g. "gemini"); embedder_config
                # is the full mem0 embedder dict. Only override when explicitly set.
                if _knowledge_config.embedder and _knowledge_config.embedder != "openai":
                    retrieval_config.setdefault('embedder_provider', _knowledge_config.embedder)
                if _knowledge_config.embedder_config:
                    retrieval_config.setdefault('embedder_config', _knowledge_config.embedder_config)
                # `config=` is an escape hatch for keys the dataclass does not
                # model. It now overrides the resolved values instead of
                # replacing the whole dict, which silently reset retrieval_k.
                if _knowledge_config.config:
                    retrieval_config.update(_knowledge_config.config)
                knowledge = _knowledge_config.sources if _knowledge_config.sources else None
            elif isinstance(_knowledge_config, list):
                knowledge = _knowledge_config
        elif knowledge is False:
            knowledge = None
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve PLANNING param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None/False -> no planning (skip resolve() call)
        if planning is None or planning is False:
            _planning_config = None
        elif planning is True:
            _planning_config = PlanningConfig()
        elif isinstance(planning, PlanningConfig):
            _planning_config = planning
        else:
            _planning_config = resolve(
                value=planning,
                param_name="planning",
                config_class=PlanningConfig,
                presets=PLANNING_PRESETS,
                string_mode="llm_model",
                array_mode=ArrayMode.PRESET_OVERRIDE,
                default=None,
            )
        
        if _planning_config is not None:
            if isinstance(_planning_config, PlanningConfig):
                planning = True
                planning_tools = _planning_config.tools
                planning_reasoning = _planning_config.reasoning
                plan_mode = _planning_config.read_only
            else:
                planning = bool(_planning_config)
        elif planning is True:
            pass  # Keep as True
        else:
            planning = False
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve REFLECTION param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None/False -> no reflection (skip resolve() call)
        if reflection is None or reflection is False:
            _reflection_config = None
        elif reflection is True:
            _reflection_config = ReflectionConfig()
        elif isinstance(reflection, ReflectionConfig):
            _reflection_config = reflection
        else:
            _reflection_config = resolve(
                value=reflection,
                param_name="reflection",
                config_class=ReflectionConfig,
                presets=REFLECTION_PRESETS,
                array_mode=ArrayMode.PRESET_OVERRIDE,
                default=None,
            )
        
        if _reflection_config is not None:
            if isinstance(_reflection_config, ReflectionConfig):
                self_reflect = True
                min_reflect = _reflection_config.min_iterations
                max_reflect = _reflection_config.max_iterations
                reflect_llm = _reflection_config.llm
                reflect_prompt = _reflection_config.prompt
            else:
                self_reflect = bool(_reflection_config)
        elif reflection is True:
            self_reflect = True
        elif reflection is False:
            self_reflect = False
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve GUARDRAILS param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fail loud instead of silently ignoring policy-string guardrails. The
        # documented `guardrails=["policy:strict", ...]` shorthand has no
        # enforcement path wired up, so accepting it silently would run with zero
        # enforcement — a "safe by default" violation. Checked before resolution
        # so the clear message wins over the generic resolver's error. Direct
        # users to the working `Agent(policy=PolicyEngine(...))` param.
        if isinstance(guardrails, (list, tuple)):
            from ..config.parse_utils import is_policy_string
            _policy_strs = [g for g in guardrails if isinstance(g, str) and is_policy_string(g)]
            if _policy_strs:
                raise ValueError(
                    f"Policy-string guardrails {_policy_strs} are not enforced. "
                    "Use Agent(policy=PolicyEngine(...)) for tool policy enforcement, "
                    "or pass a validator via guardrails=... / GuardrailConfig(validator=...)."
                )

        # Apply [defaults].guardrails from config when not explicitly provided,
        # mirroring the memory/web/caching/etc. resolution above so a config-wide
        # guardrail safety net is actually honoured instead of silently ignored.
        if guardrails is None:
            guardrails = apply_config_defaults("guardrails", None, GuardrailConfig)

        # Fast path: None/False -> no guardrails (skip resolve() call)
        if guardrails is None or guardrails is False:
            _guardrails_config = None
        elif callable(guardrails) and not isinstance(guardrails, type):
            _guardrails_config = guardrails  # Callable passthrough
        elif isinstance(guardrails, GuardrailConfig):
            _guardrails_config = guardrails
        elif isinstance(guardrails, str):
            # String could be LLM prompt - passthrough for later processing
            _guardrails_config = guardrails
        else:
            # A protocol-conforming guardrail *object* (validate_input /
            # validate_output / validate_tool_call) is not ``callable()``, so it
            # used to fall straight through to the resolver, which returns None
            # for an unknown object - the validator was silently discarded and
            # the agent ran with zero enforcement. Adapt it into a
            # ``GuardrailChain``, which is callable (so it satisfies the existing
            # guardrail runner) and forwards every protocol method.
            from ..guardrails.protocols import is_guardrail_object
            if is_guardrail_object(guardrails):
                from ..guardrails import GuardrailChain
                _guardrails_config = GuardrailChain([guardrails])
            elif isinstance(guardrails, (list, tuple)) and any(
                is_guardrail_object(g) for g in guardrails
            ):
                _bad = [g for g in guardrails if not is_guardrail_object(g)]
                if _bad:
                    raise TypeError(
                        "guardrails=[...] may not mix guardrail objects with "
                        f"{[type(g).__name__ for g in _bad]}. Every item must implement "
                        "validate_input/validate_output/validate_tool_call, or wrap the "
                        "list yourself with GuardrailChain([...])."
                    )
                from ..guardrails import GuardrailChain
                _guardrails_config = GuardrailChain(list(guardrails))
            else:
                from ..config.param_resolver import resolve_guardrails as _resolve_guardrails
                _guardrails_config = _resolve_guardrails(
                    value=guardrails,
                    config_class=GuardrailConfig,
                )
        
        # Same fail-loud guard for GuardrailConfig.policy/.policies passed
        # directly — those fields are never consumed downstream, so silently
        # accepting them would also run with zero enforcement.
        if isinstance(_guardrails_config, GuardrailConfig) and (
            _guardrails_config.policy is not None or _guardrails_config.policies
        ):
            raise ValueError(
                "GuardrailConfig.policy/.policies are not enforced. "
                "Use Agent(policy=PolicyEngine(...)) for tool policy enforcement, "
                "or pass a validator via GuardrailConfig(validator=...)."
            )

        # Fail loud when the value could not be turned into an enforceable
        # guardrail, instead of storing something that never runs. Silently
        # dropping a validator the caller explicitly asked for is a "safe by
        # default" violation, same rationale as the policy-string guard above.
        # An empty list/tuple resolves to None (no validator was actually
        # supplied), which the resolver already treated as a no-op on main -
        # keep that backward-compatible instead of raising on an empty opt-in.
        _is_empty_guardrails = (
            isinstance(guardrails, (list, tuple)) and len(guardrails) == 0
        )
        if (
            guardrails is not None
            and guardrails is not False
            and not _is_empty_guardrails
            and not (
                callable(_guardrails_config)
                or isinstance(_guardrails_config, (GuardrailConfig, str))
            )
        ):
            raise TypeError(
                f"guardrails={guardrails!r} (type {type(guardrails).__name__}) is not a "
                "supported guardrail. Pass a validator callable taking one TaskOutput, an "
                "object implementing validate_input/validate_output/validate_tool_call, a "
                "list of such objects, a GuardrailConfig, or a string LLM-validation prompt."
            )

        if _guardrails_config is not None:
            if callable(_guardrails_config) and not isinstance(_guardrails_config, type):
                # Callable validator function
                guardrail = _guardrails_config
            elif isinstance(_guardrails_config, GuardrailConfig):
                guardrail = _guardrails_config.validator or _guardrails_config.llm_validator
                max_guardrail_retries = _guardrails_config.max_retries
            elif isinstance(_guardrails_config, str):
                # LLM validator prompt
                guardrail = _guardrails_config

        # Persist the resolved value so clone_for_channel() can forward it.
        # Without this the attribute never exists, its getattr(..., None) in
        # clone_for_channel() yields None, and every served clone runs with no
        # output guardrail at all (one clone per gateway channel / HTTP call).
        self._guardrails_config = _guardrails_config
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve WEB param - FAST PATH
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None/False -> no web (skip resolve() call)
        if web is None or web is False:
            _web_config = None
        elif web is True:
            _web_config = WebConfig()
        elif isinstance(web, WebConfig):
            _web_config = web
        else:
            _web_config = resolve(
                value=web,
                param_name="web",
                config_class=WebConfig,
                presets=WEB_PRESETS,
                array_mode=ArrayMode.PRESET_OVERRIDE,
                default=None,
            )
        
        if _web_config is not None:
            if isinstance(_web_config, WebConfig):
                web_search = _web_config.search
                web_fetch = _web_config.fetch
            else:
                web_search = bool(_web_config)
                web_fetch = bool(_web_config)
        elif web is True:
            web_search = True
            web_fetch = True
        elif web is False:
            web_search = False
            web_fetch = False
        
        # ─────────────────────────────────────────────────────────────────────
        # Resolve TOOL_SEARCH param
        # ─────────────────────────────────────────────────────────────────────
        # Fast path: None/False -> disabled (zero overhead)
        if tool_search is None or tool_search is False:
            self._tool_search_config = None
        elif tool_search is True:
            # True -> auto mode with defaults
            from ..tools.tool_search import ToolSearchConfig as _ToolSearchConfig
            self._tool_search_config = _ToolSearchConfig(enabled="auto")
        elif isinstance(tool_search, str):
            # String mode ("auto", "on", "off")
            from ..tools.tool_search import ToolSearchConfig as _ToolSearchConfig
            self._tool_search_config = _ToolSearchConfig.from_raw(tool_search)
        elif isinstance(tool_search, dict):
            # Dict -> config overrides
            from ..tools.tool_search import ToolSearchConfig as _ToolSearchConfig
            self._tool_search_config = _ToolSearchConfig(**tool_search)
        else:
            from ..tools.tool_search import ToolSearchConfig as _ToolSearchConfig
            if isinstance(tool_search, _ToolSearchConfig):
                self._tool_search_config = tool_search
            else:
                raise TypeError(
                    "tool_search must be False/None, True, a mode string, "
                    "a dict of ToolSearchConfig fields, or ToolSearchConfig"
                )
        
        # Process tool_config and artifact storage (moved from tool_output)
        self._artifact_store = None
        
        # ============================================================
        # END CONSOLIDATED PARAMS EXTRACTION
        # ============================================================
        
        # Initialize autonomy features (agent-centric escalation/doom-loop)
        self._init_autonomy(autonomy, verification_hooks=verification_hooks)
        
        # Initialize loop guard lazily on first tool execution (zero init overhead)
        self._loop_guard = None

        # Result-aware tool-loop detector (name + args + result-hash fingerprints).
        # History and detector are created lazily on first tool call to keep
        # init overhead at zero. See _ensure_loop_detector().
        self._loop_detector_history = None
        self._loop_detector_config = None
        self._loop_warned_this_turn = False
        self._pending_self_correction = None

        # If instructions are provided, use them to set role, goal, and backstory
        if instructions:
            # Only use explicitly provided name, don't auto-generate from instructions
            # Auto-generation was producing confusing names like "You Are Agent" from
            # instructions like "You are a helpful assistant"
            if name:
                self.name = name
                self._agent_index = None  # Named agents don't need an index
            else:
                # Don't auto-generate - None signals "no explicit name provided"
                # Display logic will skip Agent Info panel when name is None
                self.name = None
                # Assign unique index for display_name
                with Agent._agent_counter_lock:
                    Agent._agent_counter += 1
                    self._agent_index = Agent._agent_counter
            self.role = role or "Assistant"
            self.goal = goal or instructions
            self.backstory = backstory or instructions
            # Set self_reflect to False by default for instruction-based agents
            self.self_reflect = False if self_reflect is None else self_reflect
        else:
            # Use provided values or defaults
            self.name = name or "Agent"
            self._agent_index = None  # Named agents don't need an index
            self.role = role or "Assistant"
            self.goal = goal or "Help the user with their tasks"
            self.backstory = backstory or "I am an AI assistant"
            # Default to True for traditional agents if not specified
            self.self_reflect = True if self_reflect is None else self_reflect
        
        self.instructions = instructions

        # Unique, per-instance scope id for skill auto-approval grants. The
        # display ``name`` defaults to the literal "Agent" for every unnamed
        # agent, so keying auto-approval by name alone would let one agent's
        # skill grant leak onto every other unnamed agent in the same process
        # (a cross-tenant privilege escalation). This id can never collide
        # across unrelated instances.
        import uuid as _uuid
        self._approval_scope_id = f"{self.name}:{_uuid.uuid4().hex}"

        # Resolve tool_config for tool execution settings
        _tool_config = Agent._resolve_tool_config(
            tool_config=tool_config
        )
        
        # Set up artifact store if enabled in tool_config
        if _tool_config and _tool_config.enable_artifacts:
            from ..context.artifact_store import FileSystemArtifactStore
            self._artifact_store = _tool_config.artifact_store or FileSystemArtifactStore(
                retention_days=_tool_config.artifact_retention_days,
                redact_secrets=_tool_config.redact_secrets
            )
        
        # Gap 2: one setting, two spellings. ExecutionConfig.parallel_tool_calls
        # is the source of truth (it is what chat/achat/iter_stream forward to
        # the LLM); ToolConfig.parallel is a deprecated alias that feeds it.
        self.parallel_tool_calls, _exec_config = Agent._merge_parallel_tool_calls(
            _tool_config, _exec_config
        )
        # G2: Store interrupt controller for cooperative cancellation
        self.interrupt_controller = interrupt_controller
        # Check for model name in environment variable if not provided
        self._using_custom_llm = False
        self._llm_instance = None
        self._llm_init_params = None
        # Did the caller name a model? Recorded before llm/model are normalised
        # so a container-level default (AgentTeam(llm=)/AgentFlow(llm=)) can fill
        # in agents that never chose one without overriding those that did.
        # auth= pins the vendor too, so it counts as an explicit choice.
        self._llm_explicit = llm is not None or model is not None or auth is not None
        self._panel_descriptor = None
        self._panel_llm_kwargs = {}
        # Flag to track if final result has been displayed to prevent duplicates
        self._final_display_shown = False
        
        # Store hooks for middleware system (zero overhead when empty)
        self._hooks = _hooks_list if _hooks_list else []
        self._middleware_manager = None  # Lazy init
        
        # Lazy init for HookRunner and StreamEventEmitter (zero overhead when not used)
        self.__hook_runner = None  # Will be initialized on first access
        self.__stream_emitter = None  # Will be initialized on first access
        self._hooks_registry_param = hooks  # Store for lazy init
        
        # Handle llm= deprecation: model= is the preferred parameter name
        # llm= still works but shows deprecation warning
        # Seed from clone_for_channel()'s forwarded list (if any); an explicit
        # LLMConfig(fallback_models=[...]) on llm=/model= still takes precedence.
        fallback_models = _cloned_fallback_models  # Initialize for internal use

        # One rule for the alias pair: passing both is refused, everywhere.
        from ..utils.model_alias import resolve_model_alias
        resolve_model_alias(llm, model, type(self).__name__)

        # Check if llm is an LLMConfig object
        from ..config import LLMConfig
        if isinstance(llm, LLMConfig):
            # Extract values from LLMConfig
            llm_config_obj = llm
            llm = llm_config_obj.model
            fallback_models = llm_config_obj.fallback_models
            if base_url is None:
                base_url = llm_config_obj.base_url
            if api_key is None:
                api_key = llm_config_obj.api_key
            if auth is None:
                auth = llm_config_obj.auth
        elif llm is not None and model is None:
            warn_deprecated_param(
                "llm",
                since="1.0.0",
                removal="2.0.0", 
                alternative="use 'model' instead. Example: Agent(model='gpt-4o-mini')",
                stacklevel=3
            )
        
        # model= is the preferred parameter (no warning)
        if model is not None:
            # Check if model is an LLMConfig object
            if isinstance(model, LLMConfig):
                # Extract values from LLMConfig (same as llm handling)
                llm = model.model
                if fallback_models is None:
                    fallback_models = model.fallback_models
                if base_url is None:
                    base_url = model.base_url
                if api_key is None:
                    api_key = model.api_key
                if auth is None:
                    auth = model.auth
            else:
                llm = model  # model= takes precedence
        
        # Resolve the subscription auth provider eagerly. `auth=` is opt-in, so
        # this costs nothing for everyone else, and a user who asked to be
        # billed against a subscription must never be silently downgraded to
        # API-key billing: an unknown id, an unusable provider or missing
        # credentials all have to fail at construction, not at request time
        # where the surrounding error handling turns them into a None result.
        if auth is not None:
            from ..auth import resolve_subscription_credentials
            resolve_subscription_credentials(auth)
            # A subscription seat is tied to one vendor, so the OpenAI default
            # model would ship the provider's OAuth token to the wrong endpoint.
            if llm is None:
                llm = self._AUTH_DEFAULT_MODELS.get(auth) or llm
        
        # Store rate limiter (optional, zero overhead when None).
        # Auto-build a RateLimiter from max_rpm when no explicit limiter is
        # provided so ExecutionConfig(max_rpm=N) actually throttles requests.
        if max_rpm is not None and max_rpm <= 0:
            raise ValueError(f"max_rpm must be a positive int, got {max_rpm!r}")
        if rate_limiter is None and max_rpm is not None:
            from praisonaiagents.llm.rate_limiter import RateLimiter
            rate_limiter = RateLimiter(requests_per_minute=max_rpm)
        self._rate_limiter = rate_limiter
        
        # Store OpenAI client parameters for lazy initialization (kept separate)
        self._openai_api_key = api_key
        self._openai_base_url = base_url
        self.__openai_client = None
        
        # Expose base_url, api_key and auth as properties for tests and for
        # clone_for_channel(), which serialises them back into the constructor.
        self.base_url = base_url
        self.api_key = api_key
        self.auth = auth

        # Resolve Agent(retry=...) into LLM init kwargs so the custom-LLM path
        # (any "provider/model", dict, or base_url config) honours it, instead of
        # falling back to LLM's hardcoded max_retries=3. self._retry_config is
        # normalized later (after these branches), so derive the values here from
        # the raw `retry` argument to forward them into _llm_init_params.
        _retry_init_params = {}
        if isinstance(retry, RetryBackoffConfig):
            _retry_init_params = {'max_retries': retry.max_retries}
        elif isinstance(retry, dict):
            _rc = RetryBackoffConfig(**retry)
            _retry_init_params = {'max_retries': _rc.max_retries}
        elif retry is False:
            _retry_init_params = {'max_retries': 0}

        # Connection/execution options that every LLM construction branch
        # forwards. Kept so a container default applied after construction
        # (_apply_default_llm) builds the same LLM the constructor would have.
        self._llm_option_kwargs = {
            'metrics': metrics,
            'max_iter': max_iter,
            'web_search': web_search,
            'web_fetch': web_fetch,
            'prompt_caching': prompt_caching,
            'claude_memory': claude_memory,
            **_retry_init_params,
        }
        # Forward the unified reasoning-effort control to every LLM-construction
        # branch (Issue #4452). Only set when provided so unset stays a no-op and
        # older dict/string branches that don't spread these kwargs are unaffected.
        if reasoning_effort is not None:
            self._llm_option_kwargs['reasoning_effort'] = reasoning_effort

        # Panel (multi-model) descriptor: "panel:<name>" or {"provider": "panel"}.
        # Resolved lazily into a PanelLLM; composes with the normal tool loop.
        # Detected inline (no heavy import) to keep Agent() construction lazy.
        _is_panel = (
            (isinstance(llm, str) and llm.startswith("panel:"))
            or (isinstance(llm, dict) and llm.get("provider") == "panel")
        )
        if _is_panel:
            self._panel_descriptor = llm
            self._using_custom_llm = True
            self.llm = llm if isinstance(llm, str) else "panel"
            # Capture the same connection/execution options the normal LLM paths
            # forward, so the panel aggregator (and references) behave identically
            # to a regular model selection. Stored now because some (e.g. auth)
            # are not retained as Agent attributes.
            self._panel_llm_kwargs = {
                k: v
                for k, v in (
                    ("base_url", base_url),
                    ("api_key", api_key),
                    ("auth", auth),
                    ("metrics", metrics),
                    ("max_iter", max_iter),
                    ("web_search", web_search),
                    ("web_fetch", web_fetch),
                    ("prompt_caching", prompt_caching),
                    ("claude_memory", claude_memory),
                )
                if v is not None
            }
        # If base_url is provided, defer custom LLM instance creation
        elif base_url:
            if isinstance(llm, dict):
                llm_config = llm.copy()
                llm_config['base_url'] = base_url
                if api_key:
                    llm_config['api_key'] = api_key
                if auth:
                    llm_config['auth'] = auth
                llm_config['metrics'] = metrics
                llm_config['max_iter'] = max_iter
                if _retry_init_params and 'max_retries' not in llm_config:
                    llm_config.update(_retry_init_params)
                self._llm_init_params = llm_config
                self.llm = llm.get('model', Agent._get_default_model())
            else:
                model_name = llm or Agent._get_default_model()
                self._llm_init_params = {
                    'model': model_name,
                    'base_url': base_url,
                    'api_key': api_key,
                    'auth': auth,
                    'metrics': metrics,
                    'max_iter': max_iter,
                    'web_search': web_search,
                    'web_fetch': web_fetch,
                    'prompt_caching': prompt_caching,
                    'claude_memory': claude_memory,
                    **_retry_init_params,
                }
                self.llm = model_name
            self._using_custom_llm = True
        # If the user passes a dictionary (for advanced configuration)
        elif isinstance(llm, dict) and "model" in llm:
            llm_config = llm.copy()
            if api_key and 'api_key' not in llm_config:
                llm_config['api_key'] = api_key
            if auth and 'auth' not in llm_config:
                llm_config['auth'] = auth
            llm_config['metrics'] = metrics
            llm_config['max_iter'] = max_iter
            if _retry_init_params and 'max_retries' not in llm_config:
                llm_config.update(_retry_init_params)
            self._llm_init_params = llm_config
            self._using_custom_llm = True
            self.llm = llm_config.get('model', Agent._get_default_model())
        # If the user passes a string with a slash (provider/model) — defer LiteLLM import
        elif isinstance(llm, str) and "/" in llm:
            llm_params = {'model': llm}
            if api_key:
                llm_params['api_key'] = api_key
            if auth:
                llm_params['auth'] = auth
            llm_params['metrics'] = metrics
            llm_params['web_search'] = web_search
            llm_params['web_fetch'] = web_fetch
            llm_params['prompt_caching'] = prompt_caching
            llm_params['claude_memory'] = claude_memory
            llm_params['max_iter'] = max_iter
            if _retry_init_params:
                llm_params.update(_retry_init_params)
            self._llm_init_params = llm_params
            self._using_custom_llm = True
            self.llm = llm
            
            if tools:
                logging.debug(f"Tools passed to Agent with custom LLM: {tools}")
                self.tools = tools
        # Otherwise, fall back to OpenAI environment/name (cached for performance)
        else:
            model_name = llm or Agent._get_default_model()
            if auth:
                # A subscription auth provider only takes effect inside LLM
                # (which injects the resolved OAuth credentials), so a bare
                # model name plus auth= must still build an LLM instance rather
                # than falling through to the plain OpenAI client.
                llm_params = {'model': model_name, 'auth': auth}
                if api_key:
                    llm_params['api_key'] = api_key
                llm_params['metrics'] = metrics
                llm_params['web_search'] = web_search
                llm_params['web_fetch'] = web_fetch
                llm_params['prompt_caching'] = prompt_caching
                llm_params['claude_memory'] = claude_memory
                llm_params['max_iter'] = max_iter
                if _retry_init_params:
                    llm_params.update(_retry_init_params)
                self._llm_init_params = llm_params
                self._using_custom_llm = True
            self.llm = model_name

        # Thread the unified reasoning-effort control into whichever LLM-init
        # params the branch chain above produced (Issue #4452), so it reaches the
        # LLM request pipeline regardless of how the model was specified. Only set
        # when provided and not already present, keeping unset a zero-cost no-op.
        if reasoning_effort is not None and getattr(self, "_llm_init_params", None):
            self._llm_init_params.setdefault('reasoning_effort', reasoning_effort)

        # Store fallback models for resilience (defensive copy to avoid external mutations)
        self.fallback_models = list(fallback_models) if fallback_models else []
        
        # Handle tools parameter - ensure it's always a list
        if callable(tools):
            # If a single function/callable is passed, wrap it in a list
            self.tools = [tools]
        elif isinstance(tools, str):
            # Single tool name string - resolve from registry
            self.tools = self._resolve_tool_names([tools])
        elif isinstance(tools, (list, tuple)):
            # Resolve tool-name strings PER ELEMENT. An all-or-nothing `all(...)`
            # test silently left every name unresolved as soon as one callable
            # was present, so `tools=[my_tool, 'read_file']` dropped 'read_file'.
            self.tools = self._resolve_tools_list(tools)
        else:
            self.tools = tools or []
        
        # Handle toolsets parameter - resolve named toolset groups
        if toolsets:
            try:
                from ..toolsets import resolve_toolsets_for_model
                from ..tools.resolver import ToolResolutionError
                # Advertise the model-family's preferred edit primitive first
                # (e.g. apply_patch for Claude, edit_file for GPT). Unknown /
                # non-string models fall back to the byte-for-byte default order.
                model_id = self.llm if isinstance(self.llm, str) else None
                toolset_tool_names = resolve_toolsets_for_model(toolsets, model_id)
                # Remove duplicates with existing tools
                existing_tool_names = set()
                for tool in self.tools:
                    name = getattr(tool, 'name', getattr(tool, '__name__', str(tool)))
                    existing_tool_names.add(name)
                
                unique_tool_names = [name for name in toolset_tool_names if name not in existing_tool_names]
                toolset_tools = self._resolve_tool_names(unique_tool_names)
                self.tools.extend(toolset_tools)
                logging.debug(f"Resolved toolsets {toolsets} to {len(toolset_tools)} tools: {[getattr(t, '__name__', str(t)) for t in toolset_tools]}")
            except ToolResolutionError:
                # Preserve the typed error (with .unknown / .suggestions) so
                # strict-mode callers get the same self-correcting contract as
                # the direct tools= path instead of a flattened ValueError.
                raise
            except (ValueError, KeyError) as e:
                raise ValueError(
                    f"Agent '{getattr(self, 'display_name', 'unknown')}' failed to resolve toolsets {toolsets}: {e}. "
                    "Verify names with praisonaiagents.toolsets.list_toolsets()."
                ) from e
            except ImportError as e:
                raise ImportError(
                    f"Agent '{getattr(self, 'display_name', 'unknown')}' failed to import toolsets module: {e}. "
                    "Ensure praisonaiagents is properly installed."
                ) from e
        
        # Inject default tools for autonomy mode (after self.tools is initialized)
        # ONLY inject if caller didn't provide tools - avoid duplicates with CLI/wrapper tools
        if self.autonomy_enabled and hasattr(self, '_autonomy_config_obj'):
            config = self._autonomy_config_obj
            if config.default_tools is not None:
                # User provided custom default tools via AutonomyConfig
                self.tools.extend(config.default_tools)
            elif not self.tools:
                # Only inject AUTONOMY_PROFILE if no tools were provided by caller
                # This prevents duplicates when CLI/wrapper already provides tools
                try:
                    from ..tools.profiles import AUTONOMY_PROFILE
                    from .. import tools as tools_module
                    resolved_tools = []
                    for tool_name in AUTONOMY_PROFILE.tools:
                        try:
                            tool = getattr(tools_module, tool_name)
                            if tool is not None:
                                resolved_tools.append(tool)
                        except AttributeError:
                            pass  # Tool not available, skip
                    self.tools.extend(resolved_tools)
                except ImportError:
                    # Fallback to ast-grep tools if profiles not available
                    try:
                        from ..tools.ast_grep_tool import get_ast_grep_tools
                        self.tools.extend(get_ast_grep_tools())
                    except ImportError:
                        pass  # No default tools available
        
        self.max_iter = max_iter
        self.max_rpm = max_rpm
        self.max_execution_time = max_execution_time
        self._memory_instance = None
        self._init_memory(memory, user_id)
        self._init_message_steering(message_steering)
        self.verbose = verbose
        self._has_explicit_output_config = _has_explicit_output  # Track if user set output mode
        # Use tool_config output_limit if configured, otherwise use parameter value
        self.tool_output_limit = _tool_config.output_limit if _tool_config else tool_output_limit
        self.allow_delegation = allow_delegation
        self.step_callback = step_callback
        # Token budget guard (zero overhead when _max_budget is None)
        self._max_budget = _max_budget
        self._on_budget_exceeded = _on_budget_exceeded
        # Thread-safe cost/token tracking (Gap 1a fix)
        self._cost_lock = threading.Lock()
        self._total_cost = 0.0
        self._total_tokens_in = 0
        self._total_tokens_out = 0
        self._llm_call_count = 0
        self.cache = cache
        self.system_template = system_template
        self.prompt_template = prompt_template
        self.response_template = response_template
        self.allow_code_execution = allow_code_execution
        self.max_retry_limit = max_retry_limit
        self.code_execution_mode = code_execution_mode
        # Store execution config for guardrail retry backoff
        self._execution_config = _exec_config
        self.embedder_config = embedder_config
        self.knowledge = knowledge
        self.use_system_prompt = use_system_prompt
        
        # Store ExecutionConfig for context compaction policy access
        self.execution = _exec_config
        # Async-safe chat_history with dual-lock protection
        self.__chat_history_state = AsyncSafeState([])
        
        # Async-safe snapshot/redo stack lock - always available even when autonomy is disabled
        self.__snapshot_state = AsyncSafeState(None)
        self.markdown = markdown
        self.stream = stream
        self.metrics = metrics
        self.max_reflect = max_reflect
        self.min_reflect = min_reflect
        self.reflect_prompt = reflect_prompt
        # Use the same model selection logic for reflect_llm (cached for performance)
        self.reflect_llm = reflect_llm or Agent._get_default_model()
        self._console = None  # Lazy load console when needed
        
        # Initialize system prompt
        self.system_prompt = f"""{self.backstory}\n
Your Role: {self.role}\n
Your Goal: {self.goal}
        """

        # Per-invocation system-prompt append (never persisted). Sourced from the
        # PRAISONAI_APPEND_SYSTEM_PROMPT env var so every construction path (CLI
        # code/chat/run, YAML, Python) picks it up without a new constructor
        # param. Appended at the END of the stable prompt to preserve the
        # prompt-cache prefix (#2993). No-op when unset/empty.
        _append_system_prompt = os.environ.get("PRAISONAI_APPEND_SYSTEM_PROMPT")
        if _append_system_prompt and _append_system_prompt.strip():
            self.system_prompt = f"{self.system_prompt}\n{_append_system_prompt.strip()}"

        # Lazy generate unique ID when needed
        self._agent_id = None

        # Store user_id
        self.user_id = user_id or "praison"
        self.reasoning_steps = reasoning_steps
        self.plan_mode = plan_mode  # Read-only mode for planning
        self.planning = planning  # Enable planning mode
        self.planning_tools = planning_tools  # Tools for planning phase
        self.planning_reasoning = planning_reasoning  # Enable reasoning during planning
        self._planning_agent = None  # Lazy loaded PlanningAgent
        self.web_search = web_search
        self.web_fetch = web_fetch
        self.prompt_caching = prompt_caching
        self.claude_memory = claude_memory
        
        # Initialize closure flag for GC cleanup
        self._closed = False
        
        # Session management
        self.auto_save = auto_save  # Session name for auto-saving
        
        # Initialize rules manager for persistent context (like Cursor/Windsurf)
        # NOTE: Lazy initialization - rules are loaded only when accessed (performance optimization)
        self._rules_manager = None
        self._rules_manager_initialized = False
        # Resolve auto-apply rules config: None/True -> auto-discover + apply,
        # False -> disabled, RulesConfig -> custom. Discovery-gated so zero-config
        # runs pay no cost when no instruction file is present.
        self._rules_config = None if isinstance(rules, bool) else rules
        self._rules_enabled = rules is not False
        
        # Handle web_search fallback: inject DuckDuckGo tool for unsupported models
        if web_search and not self._model_supports_web_search():
            from ..tools.duckduckgo_tools import internet_search
            # Check if internet_search is not already in tools
            tool_names = [getattr(t, '__name__', str(t)) for t in self.tools]
            if 'internet_search' not in tool_names and 'duckduckgo' not in tool_names:
                self.tools.append(internet_search)
                logging.info("Model does not support native web search. Added DuckDuckGo fallback tool.")
        
        # Raise error if web_fetch is explicitly enabled but model doesn't support it
        # Web fetch is only supported by Anthropic/Claude models
        if web_fetch and not self._model_supports_web_fetch():
            raise ValueError(
                f"web_fetch is only supported on Anthropic/Claude models. "
                f"Model '{self.llm}' does not support web fetch. "
                f"Either use a Claude model (e.g., 'anthropic/claude-sonnet-4') or disable fetch with web=WebConfig(fetch=False)."
            )
        
        # Initialize guardrail settings
        self.guardrail = guardrail
        self.max_guardrail_retries = max_guardrail_retries
        self._guardrail_fn = None
        self._setup_guardrail()
        
        # Initialize approval backend (agent-centric approval)
        # True = AutoApproveBackend, False/None = registry fallback,
        # object = custom backend (dangerous tools only),
        # ApprovalConfig = full control (all_tools, timeout, etc.)
        # str = permission preset ("safe", "read_only", "full")
        from ..approval.protocols import ApprovalConfig
        # Persist the approval kwarg exactly as given: it round-trips through the
        # constructor (str | bool | ApprovalConfig | dict | backend object).
        # clone_for_channel() reads this; without it the attribute never exists
        # and every served clone loses its approval policy.
        self._approval_config = approval
        self._perm_deny = frozenset()  # Permission tier deny set (empty = no denials)
        self._perm_allow = None        # Permission tier allow set (None = allow all)
        # Optional pattern-based PermissionManager (rules from
        # .praisonai/permissions/, YAML or Python). When attached, its ``deny``
        # rules both hide tools from the advertised schema and block them at
        # call time (native + MCP, uniformly). None = no pattern rules consulted.
        self._permission_manager = None
        # Optional Claude-Code-parity PermissionMode (bypass/plan/dont_ask/…).
        # None = normal rule flow. Consulted at tool-call approval time.
        self._permission_mode = None
        if isinstance(approval, str) and approval not in ('True', 'False'):
            # One string entry point for "how much the agent may do":
            #   • deny-set presets — "safe"/"read_only"/"full"/"off"/"default"
            #   • PermissionMode presets — "plan"/"bypass"/"accept_edits"/
            #     "dont_ask" (+ aliases like "yolo", "auto_edit", "reject").
            # Deny-set presets are matched first so their exact behaviour is
            # unchanged; anything else falls through to the canonical
            # PermissionMode resolver, so all spellings share one model.
            from ..approval.registry import PERMISSION_PRESETS
            # Normalise -/_ too so "read-only" hits the deny-set preset instead
            # of falling through to PermissionMode.resolve (which returns None
            # for deny-set names), which would silently produce an EMPTY deny
            # set — the exact read-only-sandbox bypass this validation prevents.
            preset_deny = PERMISSION_PRESETS.get(
                approval.strip().lower().replace("-", "_")
            )
            self._approval_backend = None
            self._approve_all_tools = False
            self._approval_timeout = 0
            self._approval_permissions = None
            if preset_deny is not None:
                self._perm_deny = preset_deny
            else:
                # Not a deny-set preset — try the canonical PermissionMode
                # presets (plan/bypass/accept_edits/dont_ask + aliases).
                from ..permissions.rules import PermissionMode
                self._permission_mode = PermissionMode.resolve(approval)
                # Unknown string with no mode → treat as no approval.
        elif approval is True:
            from ..approval.backends import AutoApproveBackend
            self._approval_backend = AutoApproveBackend()
            self._approve_all_tools = False
            self._approval_timeout = 0  # 0 = use backend default
            self._approval_permissions = None
        elif approval is False or approval is None:
            self._approval_backend = None
            self._approve_all_tools = False
            self._approval_timeout = 0
            self._approval_permissions = None
            # No explicit approval kwarg — honour PRAISONAI_TOOL_SAFETY.
            # Default preset "default" blocks only destructive ops
            # (delete_*, execute_command, execute_code, kill_process, move/copy)
            # while leaving read / create / edit tools fully auto-approved.
            # Users who want the pre-4.6.27 "trust everything" behaviour
            # export PRAISONAI_TOOL_SAFETY=off. This adds zero Agent kwargs.
            _raw_safety_env = os.environ.get("PRAISONAI_TOOL_SAFETY")
            _safety_env = (_raw_safety_env or "").strip().lower()
            _bypass_safety = _safety_env in ("off", "full", "none", "0", "false")
            if not _bypass_safety:
                from ..approval.registry import PERMISSION_PRESETS
                _resolved_safety_env = _safety_env or "default"
                _preset_deny = PERMISSION_PRESETS.get(_resolved_safety_env)
                if _preset_deny is None and _safety_env:
                    # Unknown env value - fall back to safe default and log warning
                    # (logging is already imported at module level; a local `import logging`
                    # here would shadow it and cause UnboundLocalError on earlier uses
                    # inside __init__ such as the custom-LLM tools branch.)
                    logging.getLogger(__name__).warning(
                        "Unknown PRAISONAI_TOOL_SAFETY value %r; falling back to 'default' preset.",
                        _raw_safety_env,
                    )
                    _resolved_safety_env = "default"
                    _preset_deny = PERMISSION_PRESETS.get(_resolved_safety_env)

                # Safe-by-default ask: when no approval kwarg was supplied
                # (``approval is None``) and we are attached to an interactive
                # terminal, route dangerous built-in tools (shell exec, file
                # writes, etc.) through an interactive approval prompt instead
                # of silently hard-denying them. This makes a fresh, un-flagged
                # agent safe *and* usable — the user is asked once per dangerous
                # call and can allow/deny.
                #
                # In non-interactive contexts (pipes, CI) — or when the user
                # explicitly passed ``approval=False`` to opt out of prompting —
                # we keep the existing deny-by-default preset so dangerous tools
                # never execute unattended without an explicit policy. The full
                # bypass remains ``PRAISONAI_TOOL_SAFETY=off`` / ``approval="bypass"``.
                if approval is None and self._is_interactive_session():
                    from ..approval.backends import ConsoleBackend
                    self._approval_backend = ConsoleBackend()
                    # Leave _perm_deny empty so dangerous tools reach the backend
                    # (which classifies them via DEFAULT_DANGEROUS_TOOLS) and the
                    # user is prompted to allow/deny rather than auto-denied.
                elif _preset_deny is not None:
                    self._perm_deny = _preset_deny
        elif isinstance(approval, ApprovalConfig):
            self._approval_backend = approval.backend
            self._approve_all_tools = approval.all_tools
            self._approval_timeout = approval.timeout  # None = indefinite, 0 = backend default
            # Store permissions if provided (for CI-safe declarative policies)
            self._approval_permissions = getattr(approval, 'permissions', None)
            self._permission_mode = getattr(approval, 'permission_mode', None)
            # Configuring approval must never be a WEAKER posture than passing
            # nothing. When no declarative ``permissions`` policy is supplied,
            # fall back to the same env-driven default deny set the bare
            # ``approval is None`` path uses, so e.g. ``ApprovalConfig(timeout=30)``
            # keeps the default denials (execute_command, delete_file, …) instead
            # of silently dropping all of them. ``is None`` (not falsiness) so an
            # explicit empty policy (``permissions={}``) is still an intentional
            # policy that owns denial — only a genuinely absent policy inherits
            # the env-driven default deny set.
            if self._approval_permissions is None:
                self._perm_deny = self._resolve_default_deny_set()
        elif isinstance(approval, dict):
            # Dict config: convert to ApprovalConfig
            approval_config = ApprovalConfig(**approval)
            self._approval_backend = approval_config.backend
            self._approve_all_tools = approval_config.all_tools
            self._approval_timeout = approval_config.timeout
            self._approval_permissions = getattr(approval_config, 'permissions', None)
            self._permission_mode = getattr(approval_config, 'permission_mode', None)
            # See the ApprovalConfig branch above: never weaken the default
            # posture just because a config object was passed. ``is None`` so an
            # explicit empty policy (``approval={"permissions": {}}``) still owns
            # denial rather than inheriting the default deny set.
            if self._approval_permissions is None:
                self._perm_deny = self._resolve_default_deny_set()
        else:
            # Plain backend object — dangerous tools only, backend default timeout
            self._approval_backend = approval
            self._approve_all_tools = False
            self._approval_timeout = 0
            self._approval_permissions = None
        
        # Per-agent autonomy→approval bridge (G-BRIDGE-1 fix)
        # If autonomy level is full_auto and no explicit approval was set,
        # auto-approve all tools for this agent (no global env var).
        autonomy_level = getattr(self, '_autonomy_level_for_approval', None)
        if autonomy_level == "full_auto" and (approval is False or approval is None):
            from ..approval.backends import AutoApproveBackend
            self._approval_backend = AutoApproveBackend()

        # Wire the pattern-based PermissionManager when a declarative
        # ``permissions:`` block was supplied (ApprovalConfig/dict). Its
        # ``deny`` rules then both hide tools from the advertised schema and
        # block them at call time (native + MCP, uniformly). Failures here are
        # non-fatal — the frozenset tier and call-time gate remain in effect.
        if self._approval_permissions:
            try:
                from ..permissions import PermissionManager, PermissionRule
                if isinstance(self._approval_permissions, PermissionManager):
                    # Reuse the caller's manager as-is (no disk I/O side-effect).
                    _mgr = self._approval_permissions
                else:
                    _mgr = PermissionManager(agent_name=self.name)
                    if isinstance(self._approval_permissions, dict):
                        _mgr.load_rules_from_config(self._approval_permissions)
                    elif isinstance(self._approval_permissions, (list, tuple)):
                        for _rule in self._approval_permissions:
                            if isinstance(_rule, PermissionRule):
                                _mgr.add_rule(_rule)
                self._permission_manager = _mgr
            except Exception as _e:
                logging.getLogger(__name__).debug(
                    "Could not initialize PermissionManager from permissions config: %s", _e
                )

        # Pending approvals for async (non-blocking) mode
        self._pending_approvals = {}
        self._approvals_lock = asyncio.Lock()
        
        # Store the resolved tool_config for cloning (resolved earlier in __init__)
        self._tool_config = _tool_config
        
        # P8/G11: Tool timeout - prevent slow tools from blocking
        self._tool_timeout = _tool_config.timeout if _tool_config else None
        
        # Store tool retry policy for tool execution with exponential backoff
        self._tool_retry_policy = _tool_config.retry_policy if _tool_config else None

        # Whether undeclared tool names may resolve via the process-global @tool
        # registry. Default False keeps the agent scoped to its own tools=[...].
        self._allow_global_tools = (
            _tool_config.allow_global_tools if _tool_config else False
        )
        
        # Retry configuration with jittered exponential backoff.
        # Default (retry is None) applies RetryBackoffConfig() so the native
        # OpenAI-client path retries transient errors by default, matching the
        # LiteLLM path (max_retries=3). Only retry=False disables retries.
        if isinstance(retry, RetryBackoffConfig):
            self._retry_config = retry
        elif isinstance(retry, dict):
            self._retry_config = RetryBackoffConfig(**retry)
        elif retry is False:
            self._retry_config = None  # Explicitly disabled
        else:
            self._retry_config = RetryBackoffConfig()  # Use defaults (retry is True or None)
        
        # Cache for system prompts and formatted tools with eager thread-safe lock
        # Use OrderedDict for LRU behavior
        self._system_prompt_cache = OrderedDict()
        self._formatted_tools_cache = OrderedDict()
        self.__cache_lock = threading.RLock()  # Eager initialization to prevent race conditions
        # Limit cache size to prevent unbounded growth
        self._max_cache_size = 100

        # Process handoffs and convert them to tools
        self.handoffs = handoffs if handoffs else []
        self._process_handoffs()

        # Initialize unified retrieval configuration
        # retrieval_config is the SINGLE configuration surface (extracted from knowledge= param)
        self._retrieval_config = None
        if retrieval_config is not None:
            from ..rag.retrieval_config import RetrievalConfig
            if isinstance(retrieval_config, RetrievalConfig):
                self._retrieval_config = retrieval_config
            elif isinstance(retrieval_config, dict):
                self._retrieval_config = RetrievalConfig.from_dict(retrieval_config)
        
        # Check if knowledge parameter has any values
        if not knowledge:
            self.knowledge = None
            self._knowledge_sources = None
            self._knowledge_processed = True  # No knowledge to process
            self._rag_instance = None
        else:
            # Check if knowledge is a Knowledge instance (shared knowledge)
            if hasattr(knowledge, 'search') and hasattr(knowledge, 'add'):
                # It's a Knowledge instance - use directly
                self.knowledge = knowledge
                self._knowledge_sources = None
                self._knowledge_processed = True
            else:
                # It's a list of sources - store for lazy processing
                self._knowledge_sources = knowledge
                self._knowledge_processed = False
                self.knowledge = None  # Will be initialized on first use
            self._rag_instance = None  # Lazy loaded RAG instance
            
            # Create default retrieval config if knowledge provided but no config
            if self._retrieval_config is None:
                from ..rag.retrieval_config import RetrievalConfig
                self._retrieval_config = RetrievalConfig()

        # Agent Skills configuration (lazy loaded for zero performance impact)
        self._skills = _skills
        self._skills_dirs = skills_dirs
        self._skills_auto_discover = _skills_auto_discover
        self._skill_manager = None  # Lazy loaded
        self._skills_initialized = False

        # Autonomous skill self-improvement loop (issue #2231). Off by default;
        # when enabled, a guarded review pass restricted to skill_manage runs
        # after each task. A SkillReviewProtocol instance customises the policy.
        # Execution mode for the after-agent self-improvement side-effects
        # (skill-review + auto-memory + auto-learning). "inline" (default)
        # preserves today's synchronous behaviour; "background" delivers the
        # reply first and runs the extra LLM work off the hot path on the core
        # BackgroundJobManager (issue #2985).
        self._self_improve_mode = "inline"
        if isinstance(self_improve, str):
            mode = self_improve.strip().lower()
            if mode in ("background", "async"):
                self._self_improve = True
                self._self_improve_policy = None
                self._self_improve_mode = "background"
            elif mode in ("inline", "blocking", "sync", "true", "on", "yes", "1"):
                self._self_improve = True
                self._self_improve_policy = None
            else:
                # Falsy ("false"/"off"/"no"/"0"/""), or an unrecognised value
                # (e.g. a typo like "backround"): default to disabled rather
                # than silently enabling an extra review turn on every reply.
                if mode not in ("false", "off", "no", "0", ""):
                    logger.warning(
                        "Unknown self_improve mode %r; disabling self-improvement. "
                        "Use 'inline', 'background', or a bool.", self_improve,
                    )
                self._self_improve = False
                self._self_improve_policy = None
        elif self_improve is True or self_improve is False or self_improve is None:
            self._self_improve = bool(self_improve)
            self._self_improve_policy = None
        else:
            # Custom policy object implementing SkillReviewProtocol.
            self._self_improve = True
            self._self_improve_policy = self_improve
        self._in_skill_review = False
        # Per-turn tool-name buffer feeding the self-improve review policy.
        # Populated in _execute_tool_with_context, reset each chat turn, and
        # read by _trigger_after_agent_hook when tools_used is not passed.
        # Guarded by a DualLock (like chat_history) so concurrent chat()/achat()
        # turns on the same Agent instance don't corrupt each other's buffer.
        self._turn_tools_used = []
        self._turn_tools_lock = DualLock()

        # Database persistence (lazy - no imports until used)
        self._db = db
        self._session_id = session_id
        self._db_initialized = False
        
        # Session store for JSON-based persistence (lazy - no imports until used)
        # Used when session_id is provided but no DB adapter
        self._session_store = None
        self._session_store_initialized = False
        
        # History injection settings (for auto-injecting session history into context)
        self._history_enabled = _history_enabled
        self._history_limit = _history_limit
        self._history_session_id = _history_session_id
        
        # Learning configuration (top-level, peer to memory)
        # Stored for access via agent._learn_config
        self._learn_config = _learn_config

        # Agent-centric feature instances (lazy loaded for zero performance impact)
        self._auto_memory = auto_memory
        self._policy = policy
        self._output_style = output_style
        # Backward-compatible: `thinking_budget` property mirrors the legacy int
        # budget when supplied via the alias (Issue #4452); the unified effort is
        # what actually drives the request pipeline via `_llm_init_params`.
        self._thinking_budget = (
            _thinking_budget_alias
            if isinstance(_thinking_budget_alias, int)
            else None
        )
        # Store the resolved unified reasoning-effort as a canonical graded level
        # (off|minimal|low|medium|high) for session persistence. A legacy int
        # ``thinking_budget`` alias is normalised to its nearest level so the
        # persisted/queried value is always provider-portable (Issue #4452). The
        # LLM request pipeline still accepts the raw value too, so behaviour is
        # unchanged when unset.
        if reasoning_effort is not None:
            try:
                from ..thinking.effort import normalize_effort
                self._reasoning_effort = normalize_effort(reasoning_effort)
            except Exception:
                self._reasoning_effort = reasoning_effort
        else:
            self._reasoning_effort = None
        
        # Context management (lazy loaded for zero overhead when disabled)
        # Smart default: auto-enable context when tools are present
        if context is None and self.tools:
            # Tools present but no explicit context setting - auto-enable
            self._context_param = True
        else:
            self._context_param = context  # Store raw param for lazy init
        self._context_manager = None  # Lazy initialized on first use
        self._context_manager_initialized = False
        self._session_dedup_cache = None  # Shared session cache from workflow
        
        # Action trace mode - handled via display callbacks, not separate emitter
        self._actions_trace = actions_trace
        
        # Output file and template - for auto-saving response to file
        self._output_file = output_file if _output_config else None
        self._output_template = output_template if _output_config else None

        # Backend - external managed agent backend for hybrid execution
        self.backend = backend
        
        # CLI Backend - external CLI backend for delegating full turns (DEPRECATED)
        self._cli_backend = None
        if cli_backend is not None:
            from ..utils.deprecation import warn_deprecated_param
            warn_deprecated_param(
                "cli_backend",
                since="1.0.0",
                removal="2.0.0",
                alternative="use 'runtime=' instead for model-scoped runtime configuration. For migration assistance, run: praisonai doctor fix --execute",
                stacklevel=3
            )
            self._cli_backend = self._resolve_cli_backend(cli_backend)
        
        # Runtime Configuration - model-scoped runtime selection with capability validation
        self._runtime_config = None
        if runtime is not None:
            self._runtime_config = self._resolve_runtime_config(runtime)
            # Perform capability validation if enabled
            if self._runtime_config and hasattr(self._runtime_config, 'validate_on_creation') and self._runtime_config.validate_on_creation:
                self._validate_runtime_capabilities()
        
        # Runtime resolver for per-turn resolution
        self._runtime_resolver = None  # Will be initialized on first use

        # Telemetry - lazy initialized via property for performance
        self.__telemetry = None
        self.__telemetry_initialized = False
        
        # Sandbox configuration - initialize SandboxMixin
        super().__init__(sandbox=sandbox)

        # NOTE: `sandbox=` deliberately does NOT add code-execution tools.
        #
        # An earlier version auto-attached execute_python_code /
        # execute_shell_command here. That was reverted: `sandbox=` is a
        # RESTRICTION, and it must never grant a capability the caller did not
        # ask for. Concretely, the injection
        #   - escalated privilege: Agent(approval="read_only") exposes no tools,
        #     but Agent(approval="read_only", sandbox=True) exposed two ungated
        #     arbitrary-code-execution tools, since the injected names are not in
        #     the approval registry's dangerous-tool presets; and
        #   - advertised them to the model as "safely in sandbox" while the
        #     default subprocess backend enforces none of its own SecurityPolicy
        #     (network reachable despite allow_network=False; ~/.ssh readable
        #     despite blocked_paths; `import subprocess` works despite
        #     blocked_imports).
        #
        # `sandbox=` still configures isolation for the explicit, user-invoked
        # agent.execute_code() / run_shell_command() APIs, which is what it has
        # always meant. Giving the model a sandboxed execution tool should be an
        # explicit act by the caller, the way MCP() is.

        # A managed backend takes over the whole turn before any local execution,
        # so a sandbox set alongside it silently does nothing. Say so.
        if self.sandbox_config is not None and getattr(self, "backend", None) is not None:
            import warnings

            warnings.warn(
                "Agent(sandbox=..., backend=...): the managed backend handles the "
                "entire turn, so the sandbox= setting is ignored. Configure "
                "isolation on the backend instead (e.g. LocalAgent(compute='docker')).",
                FutureWarning,
                stacklevel=2,
            )

    @staticmethod
    def _merge_parallel_tool_calls(tool_config, exec_config):
        """Merge the two spellings of "run batched tool calls in parallel".

        ``ExecutionConfig.parallel_tool_calls`` is the single source of truth:
        it is the value ``chat()``, ``achat()`` and ``iter_stream()`` forward to
        the LLM. ``ToolConfig.parallel`` is a deprecated alias -- ``None`` means
        "not set here", an explicit ``True``/``False`` feeds the source of truth.

        Returns ``(resolved_bool, exec_config)``. The ExecutionConfig is copied
        (never mutated) when the alias contributes a value, so a config instance
        shared between agents is not rewritten behind the caller's back.
        """
        alias = getattr(tool_config, 'parallel', None) if tool_config is not None else None
        current = bool(getattr(exec_config, 'parallel_tool_calls', False))
        if alias is None:
            return current, exec_config
        alias = bool(alias)
        if alias == current:
            return current, exec_config
        # The two spellings disagree. Only raise when the source of truth was set
        # *explicitly* -- an omitted ExecutionConfig.parallel_tool_calls (its bool
        # default) must not masquerade as a real value, or an explicit
        # ToolConfig(parallel=False) would be silently overridden (and vice versa).
        explicit = getattr(exec_config, '_parallel_tool_calls_explicit', current)
        if explicit:
            raise TypeError(
                f"Agent(tool_config=ToolConfig(parallel={alias}), "
                f"execution=ExecutionConfig(parallel_tool_calls={current})) is not "
                "valid: both name the same setting and they disagree.\n"
                "  ToolConfig.parallel is a deprecated alias for "
                "ExecutionConfig.parallel_tool_calls.\n"
                "  To run batched tool calls in parallel:  "
                "Agent(execution=ExecutionConfig(parallel_tool_calls=True))\n"
                "  To run them sequentially (the default): drop both spellings."
            )
        import copy as _copy
        exec_config = _copy.copy(exec_config)
        exec_config.parallel_tool_calls = alias
        return alias, exec_config

    @staticmethod
    def _resolve_tool_config(tool_config):
        """Resolve tool_config parameter with backward compatibility."""
        # Import here to avoid circular imports
        from ..config.feature_configs import ToolConfig, resolve_tools
        
        # Handle the new consolidated parameter
        if tool_config is not None:
            resolved_config = resolve_tools(tool_config)
            return resolved_config
        
        return None

    def __deepcopy__(self, memo: dict) -> "Agent":
        """Custom deepcopy that creates fresh threading primitives.

        threading primitives cannot be deep-copied on all supported Python
        versions, while copying an asyncio.Lock can preserve its locked/waiter
        state. This hook replaces the Agent-owned locks directly, while
        lock-bearing state wrappers provide their own deepcopy hooks, so the
        clone receives independent state and fresh locks.
        """
        import copy
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        for k, v in self.__dict__.items():
            if k in ("_Agent__cache_lock",):
                object.__setattr__(result, k, threading.RLock())
            elif k == "_cost_lock":
                object.__setattr__(result, k, threading.Lock())
            elif k == "_approvals_lock":
                object.__setattr__(result, k, asyncio.Lock())
            else:
                object.__setattr__(result, k, copy.deepcopy(v, memo))
        return result

    def _isolated_memory_for_clone(self):
        """Resolve a memory backend for a channel clone without sharing one store.

        MemoryConfig/db()/dict configs are re-resolved into a fresh backend per
        Agent, so they are safe to forward as-is. A live Memory/FileMemory
        instance, however, is stored by reference on ``_memory_instance``;
        forwarding it would make every per-channel/per-user clone read and write
        the same long-term store (leaking one user's history into another). Try
        to re-instantiate a fresh backend from the instance's own config; if that
        isn't possible, fall back to sharing (with a warning) so cloning never
        hard-fails.
        """
        mem_cfg = getattr(self, '_memory_config', None)
        # A stored MemoryConfig/db()/dict config is re-resolved per Agent - safe.
        if mem_cfg is not None:
            return mem_cfg

        # No config object: the user passed a live memory backend instance, which
        # was stored directly on _memory_instance. Rebuild a fresh, isolated one.
        mem_inst = getattr(self, '_memory_instance', None)
        if mem_inst is None:
            return None
        try:
            import copy
            return copy.deepcopy(mem_inst)
        except Exception:
            pass
        # deepcopy failed (e.g. thread-locals/connections). Re-instantiate the same
        # backend type from its stored config so each clone gets its own store.
        try:
            cfg = getattr(mem_inst, 'cfg', None)
            if cfg is not None:
                return type(mem_inst)(cfg)
        except Exception:
            pass
        logging.warning(
            "clone_for_channel: could not isolate the live memory backend; clones "
            "will share it. Pass memory via MemoryConfig/db() for per-channel isolation."
        )
        return mem_inst


    def _backstory_without_sandbox_prompt(self):
        """This agent's backstory as it was before any sandbox was attached."""
        shared = getattr(self, "_tools_sandbox", None)
        if shared is not None:
            for ref, _tools, original_backstory in getattr(shared, "_patched", []):
                if ref() is self:
                    return original_backstory
        return self.backstory

    def clone_for_channel(self) -> "Agent":
        """Return a fully independent copy of this agent for a gateway channel.
        
        This method safely clones an agent for use in multi-channel scenarios
        by avoiding deepcopy issues with tools/handoffs and creating fresh
        instances of mutable objects like interrupt_controller.
        
        Returns:
            Agent: A new Agent instance with copied configuration but fresh
                  locks, interrupt controller, and shallow-copied tools.
        """
        import copy
        from ..tools.base import BaseTool
        
        # Build kwargs for new Agent instance, copying core attributes
        clone_kwargs = {
            # Core identity
            'name': self.name,
            'role': self.role, 
            'goal': self.goal,
            # The pre-attach backstory when a sandbox is live: attach() appends
            # the capability prompt to backstory, so cloning the current value
            # and then attaching again gives the clone two copies of it.
            'backstory': self._backstory_without_sandbox_prompt(),
            'instructions': self.instructions,
            
            # LLM configuration 
            'llm': self.llm,
            'fallback_models': list(self.fallback_models) if hasattr(self, 'fallback_models') and self.fallback_models else None,
            'base_url': getattr(self, 'base_url', None),
            'api_key': getattr(self, 'api_key', None),
            'auth': getattr(self, 'auth', None),
            
            # Shallow copy tools to avoid deepcopy issues with nested objects.
            # Drop framework-generated sandbox tools: they close over the source
            # agent, so the constructor must regenerate clone-bound replacements
            # (see the sandbox wiring below). User tools with colliding names
            # lack the tag and are preserved. as_tool() handoff closures also
            # close over the source agent; swap each back for its source Handoff
            # so the clone's _process_handoffs rebinds it to the clone instead of
            # delegating with the original agent's history/tools/memory.
            'tools': (
                [
                    getattr(t, "_praison_handoff_source", t)
                    for t in self.tools
                    if not getattr(t, "_praison_sandbox_tool", False)
                ]
                if self.tools else None
            ),
            
            # Skip handoffs entirely - they shouldn't be shared across channels
            # and can contain nested Agent instances that cause RLock issues
            'handoffs': None,
            
            # Feature configurations - check for actual stored config objects
            # Isolate a live Memory/FileMemory backend so per-channel clones
            # don't share one store (would leak one user's history into another).
            'memory': self._isolated_memory_for_clone(),
            'knowledge': getattr(self, '_knowledge_config', None), 
            'planning': getattr(self, '_planning_config', None),
            'reflection': getattr(self, '_reflection_config', None),
            'guardrails': getattr(self, '_guardrails_config', None),
            'web': getattr(self, '_web_config', None),
            'context': getattr(self, '_context_config', None),
            'autonomy': getattr(self, '_autonomy_config', None),
            'output': getattr(self, '_output_config', None),
            'execution': getattr(self, '_execution_config', None),
            'templates': getattr(self, '_template_config', None),
            'caching': getattr(self, '_caching_config', None),
            'hooks': getattr(self, '_hooks_config', None),
            'skills': getattr(self, '_skills_config', None),
            'approval': getattr(self, '_approval_config', None),
            'learn': getattr(self, '_learn_config', None),
            # Autonomous skill self-improvement: forward the custom policy when
            # set, else the execution-mode string ("background") when enabled so
            # clones keep the same hot-path behaviour, else the opt-in boolean.
            'self_improve': (
                getattr(self, '_self_improve_policy', None)
                or (
                    getattr(self, '_self_improve_mode', 'inline')
                    if getattr(self, '_self_improve', False)
                    and getattr(self, '_self_improve_mode', 'inline') == 'background'
                    else getattr(self, '_self_improve', False)
                )
            ),
            'tool_search': getattr(self, '_tool_search_config', None),
            # Tool configuration - use consolidated config when available  
            'tool_config': getattr(self, '_tool_config', None),
            
            # Retry configuration
            'retry': getattr(self, '_retry_config', None),
            
            # CLI backend
            'cli_backend': getattr(self, '_cli_backend', None),
            
            # Create fresh interrupt controller to avoid shared state
            'interrupt_controller': None,  # Let new instance create its own
            
            # Sandbox config
            # SandboxMixin stores this as `sandbox_config`; reading the
            # underscore name (never assigned) made every clone silently drop
            # its sandbox and run unisolated.
            'sandbox': getattr(self, 'sandbox_config', None),

            # Where the tools run must survive cloning for the same reason the
            # sandbox must: a gateway-channel clone that quietly drops it runs
            # every tool on the host while its repr still claims otherwise.
            # The clone gets its own sandbox instance -- placement is a choice,
            # not a live connection to share.
            'tools_run_on': getattr(self, 'tools_run_on', None),
        }
        
        # Handle deprecated parameters for backward compatibility
        import warnings
        
        # Check for deprecated standalone attributes and emit warnings
        deprecated_attrs = [
            ('allow_code_execution', 'execution'),
            ('code_execution_mode', 'execution'), 
            ('auto_save', 'memory'),
            ('rate_limiter', 'execution'),
            ('allow_delegation', 'handoffs'),
            ('verification_hooks', 'autonomy')
        ]
        
        for old_attr, new_param in deprecated_attrs:
            if hasattr(self, old_attr):
                value = getattr(self, old_attr)
                if value is not None and value != False:  # Skip None/False defaults
                    warnings.warn(
                        f"Deprecated attribute '{old_attr}' found in agent clone. "
                        f"Use '{new_param}=' parameter instead.",
                        DeprecationWarning,
                        stacklevel=2
                    )
                    # For basic compatibility, include in clone_kwargs if not already set
                    if old_attr == 'allow_code_execution' and clone_kwargs['execution'] is None:
                        from ..config.feature_configs import ExecutionConfig
                        clone_kwargs['execution'] = ExecutionConfig(code_execution=value)
                    elif old_attr == 'auto_save' and clone_kwargs['memory'] is None:
                        from ..config.feature_configs import MemoryConfig
                        clone_kwargs['memory'] = MemoryConfig(auto_save=value)
        
        # Create new Agent instance
        return self.__class__(**{k: v for k, v in clone_kwargs.items() if v is not None})

    @property
    def _telemetry(self):
        """Lazy-loaded telemetry instance for performance."""
        if not self.__telemetry_initialized:
            try:
                from ..telemetry import get_telemetry
                self.__telemetry = get_telemetry()
            except (ImportError, AttributeError):
                self.__telemetry = None
            self.__telemetry_initialized = True
        return self.__telemetry

    @property
    def chat_history(self):
        """Get chat history (read-only access, use context managers for modifications)."""
        return self.__chat_history_state.get()
    
    @chat_history.setter
    def chat_history(self, value):
        """Set chat history (updates the underlying async-safe state with lock)."""
        with self.__chat_history_state.lock():
            self.__chat_history_state.value = value
    
    @property
    def _history_lock(self):
        """Get appropriate lock for chat history based on execution context."""
        return self.__chat_history_state
    
    def _append_to_chat_history(self, message: dict):
        """Thread-safe append to chat history using proper locking.

        Also records the appended message into the current turn's per-turn
        ownership tracker (when one is active) so a failing turn's rollback
        removes only its own messages by identity and never a concurrent
        turn's. This is the append path every real chat()/achat() turn uses,
        so without recording here _rollback_chat_history_to would always take
        the unsafe positional-delete branch.
        """
        from .memory_mixin import _active_turn_owned
        with self._history_lock.lock():
            self._history_lock.value.append(message)
            owned = _active_turn_owned.get()
            if owned is not None:
                owned.append(message)
    
    def _replace_chat_history(self, new_history: List[Dict[str, Any]]):
        """Thread-safe replacement of entire chat history using proper locking."""
        with self._history_lock.lock():
            self._history_lock.value[:] = new_history

    @property
    def _cache_lock(self):
        """Thread-safe cache lock."""
        return self.__cache_lock

    @property
    def _snapshot_lock(self):
        """Async-safe snapshot/redo stack lock."""
        return self.__snapshot_state
    
    
    @property
    def auto_memory(self) -> Optional[bool]:
        """AutoMemory instance for automatic memory extraction."""
        return self._auto_memory
    
    @auto_memory.setter
    def auto_memory(self, value: Optional[bool]) -> None:
        self._auto_memory = value

    @property
    def policy(self) -> Optional[Any]:
        """PolicyEngine instance for execution control."""
        return self._policy
    
    @policy.setter
    def policy(self, value: Optional[Any]) -> None:
        self._policy = value

    @property
    def output_style(self) -> Optional[str]:
        """OutputStyle instance for response formatting."""
        return self._output_style
    
    @output_style.setter
    def output_style(self, value: Optional[str]) -> None:
        self._output_style = value

    @property
    def thinking_budget(self) -> Optional[int]:
        """ThinkingBudget instance for extended thinking control."""
        return self._thinking_budget
    
    @thinking_budget.setter
    def thinking_budget(self, value: Optional[int]) -> None:
        # `thinking_budget` is a backward-compatible alias for the unified
        # `reasoning_effort` control (Issue #4452). Setting it must route through
        # the same request-pipeline sync as `reasoning_effort`, otherwise the
        # CLI's `--thinking` (which assigns this property after construction)
        # stays dormant — the value would be stored but never emitted.
        self._thinking_budget = value if isinstance(value, int) else None
        self.reasoning_effort = value

    @property
    def reasoning_effort(self) -> Optional[str]:
        """Unified, provider-portable reasoning-effort level (Issue #4452).

        One of ``off|minimal|low|medium|high``. Core translates it to the
        target provider's native parameter (OpenAI/xAI ``reasoning_effort``,
        Anthropic/Gemini extended-thinking budget) on the request path.
        """
        return getattr(self, "_reasoning_effort", None)

    @reasoning_effort.setter
    def reasoning_effort(self, value: Optional[str]) -> None:
        # Normalise to a canonical graded level so the stored/persisted value is
        # always provider-portable, whether set as a level or a legacy int budget.
        if value is not None:
            try:
                from ..thinking.effort import normalize_effort
                value = normalize_effort(value)
            except Exception:
                pass
        self._reasoning_effort = value
        # Keep the live LLM-init params in sync so a post-construction change
        # still reaches the request pipeline (mirrors thinking_budget aliasing).
        if getattr(self, "_llm_init_params", None) is not None:
            if value is None:
                self._llm_init_params.pop('reasoning_effort', None)
            else:
                self._llm_init_params['reasoning_effort'] = value
        # If an LLM instance has already been built (lazy cache), update it too so
        # a post-construction change still takes effect without a rebuild.
        instance = getattr(self, "_llm_instance", None)
        if instance is not None:
            try:
                instance.reasoning_effort = value
            except Exception:
                pass

    @property
    def total_cost(self) -> float:
        """Cumulative USD cost of all LLM calls in this agent run."""
        # Thread-safe cost reading (Gap 1a fix)
        with self._cost_lock:
            return self._total_cost

    @property
    def cost_summary(self) -> dict:
        """Summary of cost and token usage.

        Returns:
            dict with keys: tokens_in, tokens_out, cost, llm_calls
        """
        # Thread-safe cost reading (Gap 1a fix)
        with self._cost_lock:
            return {
                "tokens_in": self._total_tokens_in,
                "tokens_out": self._total_tokens_out,
                "cost": self._total_cost,
                "llm_calls": self._llm_call_count,
            }

    def _run_spend(self) -> tuple:
        """Return cumulative (usd, tokens) spent by this agent so far.

        Reuses the per-run cost/token accounting already accumulated in
        ``chat``/``achat`` (``_total_cost``, ``_total_tokens_in/out``). Used by
        ``run_autonomous`` to enforce the spend kill-switch each iteration.
        """
        with self._cost_lock:
            return (
                self._total_cost,
                self._total_tokens_in + self._total_tokens_out,
            )

    def _autonomy_budget_result(self, iterations, stage, actions_taken,
                                start_time, started_at, last_output,
                                spend_baseline=(0.0, 0)):
        """Return an AutonomyResult if the run's spend cap is exceeded, else None.

        Compares *this run's* spend against the autonomy
        ``max_budget_usd``/``max_tokens`` caps. ``spend_baseline`` is the
        ``(usd, tokens)`` snapshot taken at the start of the autonomous loop, so
        prior usage on a reused Agent (earlier ``chat``/``run_autonomous`` calls
        accumulated in the lifetime counters) does not count against this run's
        cap. Either/both caps unset = unlimited, preserving today's behaviour
        (returns None → run continues). On exceed, returns a typed
        ``budget_exhausted`` outcome carrying spend-so-far and the partial
        result; ``budget_action='pause'`` marks it recoverable.
        """
        cap_usd = self.autonomy_config.get("max_budget_usd")
        cap_tok = self.autonomy_config.get("max_tokens")
        if cap_usd is None and cap_tok is None:
            return None
        raw_usd, raw_toks = self._run_spend()
        base_usd, base_toks = spend_baseline
        usd = raw_usd - base_usd
        toks = raw_toks - base_toks
        exceeded = (
            (cap_usd is not None and usd >= cap_usd)
            or (cap_tok is not None and toks >= cap_tok)
        )
        if not exceeded:
            return None
        import time as _time_module
        from .autonomy import AutonomyResult
        from ..run_outcome import TerminationReason
        action = self.autonomy_config.get("budget_action", "pause")
        status = "paused" if action == "pause" else "stopped"
        return AutonomyResult(
            success=False,
            output=last_output or "",
            completion_reason=TerminationReason.BUDGET_EXHAUSTED.value,
            iterations=iterations,
            stage=stage,
            actions=actions_taken,
            duration_seconds=_time_module.time() - start_time,
            started_at=started_at,
            metadata={
                "spend_usd": usd,
                "tokens": toks,
                "max_budget_usd": cap_usd,
                "max_tokens": cap_tok,
                "status": status,
            },
        )

    @property
    def context_manager(self) -> Optional[Any]:
        """
        ContextManager instance for unified context management.
        
        Lazy initialized on first access when context=True or context=ManagerConfig.
        Returns None when context=False (zero overhead).
        
        Example:
            agent = Agent(instructions="...", context=True)
            # Access manager for advanced operations
            if agent.context_manager:
                stats = agent.context_manager.get_stats()
        """
        if self._context_manager_initialized:
            return self._context_manager
        
        # Initialize based on context param type
        if self._context_param is False or self._context_param is None:
            # Zero overhead - no context management
            self._context_manager = None
            self._context_manager_initialized = True
            return None
        
        # Lazy import to avoid overhead when not used
        try:
            from ..context import ContextManager, ManagerConfig
        except ImportError:
            # Context module not available
            self._context_manager = None
            self._context_manager_initialized = True
            return None
        
        if self._context_param is True:
            # Enable with safe defaults
            self._context_manager = ContextManager(
                model=self.llm if isinstance(self.llm, str) else "gpt-4o-mini",
                agent_name=self.name or "Agent",
                session_cache=self._session_dedup_cache,  # Share session cache from workflow
                llm_summarize_fn=self._create_llm_summarize_fn(),  # Auto-wire LLM summarization
            )
        elif isinstance(self._context_param, ManagerConfig):
            # Use provided ManagerConfig
            self._context_manager = ContextManager(
                model=self.llm if isinstance(self.llm, str) else "gpt-4o-mini",
                config=self._context_param,
                agent_name=self.name or "Agent",
                session_cache=self._session_dedup_cache,  # Share session cache from workflow
                llm_summarize_fn=self._create_llm_summarize_fn() if self._context_param.llm_summarize else None,
            )
        elif hasattr(self._context_param, 'auto_compact') and hasattr(self._context_param, 'tool_output_max'):
            # ContextConfig from YAML - convert to ManagerConfig
            try:
                from ..context.models import ContextConfig as _ContextConfig
                if isinstance(self._context_param, _ContextConfig):
                    # Build ManagerConfig from ContextConfig fields
                    manager_config = self._manager_config_from_context_config(self._context_param)
                    # Check if llm_summarize is enabled in ContextConfig
                    llm_summarize_enabled = getattr(self._context_param, 'llm_summarize', False)
                    if llm_summarize_enabled:
                        manager_config.llm_summarize = True
                    self._context_manager = ContextManager(
                        model=self.llm if isinstance(self.llm, str) else "gpt-4o-mini",
                        config=manager_config,
                        agent_name=self.name or "Agent",
                        session_cache=self._session_dedup_cache,  # Share session cache from workflow
                        llm_summarize_fn=self._create_llm_summarize_fn() if llm_summarize_enabled else None,
                    )
                else:
                    self._context_manager = None
            except Exception as e:
                logging.debug(f"ContextConfig conversion failed: {e}")
                self._context_manager = None
        elif hasattr(self._context_param, 'process'):
            # Already a ContextManager instance
            self._context_manager = self._context_param
        elif isinstance(self._context_param, str):
            # String preset: "sliding_window", "summarize", "truncate"
            from ..config.presets import CONTEXT_PRESETS
            from ..config.parse_utils import canonical_preset_key
            preset_config = CONTEXT_PRESETS.get(canonical_preset_key(self._context_param))
            if preset_config is not None:
                # Convert preset to ContextConfig, then to ManagerConfig
                try:
                    from ..context.models import ContextConfig as _ContextConfig
                    context_config = _ContextConfig(**preset_config)
                    manager_config = self._manager_config_from_context_config(context_config)
                    self._context_manager = ContextManager(
                        model=self.llm if isinstance(self.llm, str) else "gpt-4o-mini",
                        config=manager_config,
                        agent_name=self.name or "Agent",
                        session_cache=self._session_dedup_cache,
                        llm_summarize_fn=None,
                    )
                except Exception as e:
                    logging.debug(f"Context preset conversion failed: {e}")
                    self._context_manager = None
            else:
                # Unknown string preset, disable
                self._context_manager = None
        elif isinstance(self._context_param, dict):
            # Dict config: convert to ContextConfig, then to ManagerConfig
            try:
                from ..context.models import ContextConfig as _ContextConfig
                context_config = _ContextConfig(**self._context_param)
                manager_config = self._manager_config_from_context_config(context_config)
                llm_summarize_enabled = self._context_param.get('llm_summarize', False)
                self._context_manager = ContextManager(
                    model=self.llm if isinstance(self.llm, str) else "gpt-4o-mini",
                    config=manager_config,
                    agent_name=self.name or "Agent",
                    session_cache=self._session_dedup_cache,
                    llm_summarize_fn=self._create_llm_summarize_fn() if llm_summarize_enabled else None,
                )
            except Exception as e:
                logging.debug(f"Context dict conversion failed: {e}")
                self._context_manager = None
        else:
            # Unknown type, disable
            self._context_manager = None
        
        self._context_manager_initialized = True
        return self._context_manager
    
    @context_manager.setter
    def context_manager(self, value):
        """Set context manager directly."""
        self._context_manager = value
        self._context_manager_initialized = True

    def _manager_config_from_context_config(self, cc: Any) -> Any:
        """Build a ManagerConfig from a ContextConfig (single source of truth)."""
        from ..context import ManagerConfig
        return ManagerConfig(
            auto_compact=cc.auto_compact,
            compact_threshold=cc.compact_threshold,
            strategy=cc.strategy,
            output_reserve=cc.output_reserve,
            default_tool_output_max=cc.tool_output_max,  # Map field name
            protected_tools=list(cc.protected_tools),
            keep_recent_turns=cc.keep_recent_turns,
            monitor_enabled=cc.monitor.enabled if cc.monitor else False,
        )

    def _create_llm_summarize_fn(self) -> Optional[Callable]:
        """
        Create an LLM summarization function using the agent's LLM.
        
        Returns a function that can be used by the context optimizer to
        intelligently summarize conversation history.
        
        Returns:
            Callable that takes (messages, max_tokens) and returns summary string,
            or None if LLM is not available.
        """
        def llm_summarize(messages: List[Dict[str, Any]], max_tokens: int = 500) -> str:
            """Summarize messages using the agent's LLM."""
            try:
                # Build summarization prompt
                conversation_text = "\n".join([
                    f"{m.get('role', 'unknown')}: {m.get('content', '')[:500]}"
                    for m in messages if m.get('content')
                ])
                
                prompt = f"""Summarize the following conversation in a concise way that preserves key information, decisions, and context. Keep the summary under {max_tokens} tokens.

Conversation:
{conversation_text}

Summary:"""
                
                # Use agent's LLM to generate summary. Route this internal,
                # non-user-facing call through the configured auxiliary
                # ``small_model`` when set; otherwise fall back to the primary
                # model (unchanged behaviour).
                client = _get_llm_functions()['get_openai_client'](self.llm, self.base_url, self.api_key)
                primary_model = self.llm if isinstance(self.llm, str) else None
                try:
                    from ..config.loader import get_small_model
                    model_name = get_small_model(
                        primary_model=primary_model, fallback="gpt-4o-mini"
                    ) or "gpt-4o-mini"
                except Exception:
                    model_name = primary_model or "gpt-4o-mini"
                
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=max_tokens,
                    temperature=0.3,
                )
                
                return response.choices[0].message.content or "[Summary unavailable]"
            except Exception as e:
                logging.debug(f"LLM summarization failed: {e}")
                return f"[Previous conversation summary - {len(messages)} messages]"
        
        return llm_summarize

    @property
    def console(self) -> Optional[Any]:
        """Lazily initialize Rich Console only when needed AND verbose is True."""
        # Only return console if verbose mode is enabled
        # This prevents panels from being shown in status/silent modes
        if not self.verbose:
            return None
        if self._console is None:
            from rich.console import Console
            self._console = _get_console()()
        return self._console
    
    @property
    def skill_manager(self) -> Optional[Any]:
        """Lazily initialize SkillManager only when skills are accessed."""
        auto_discover = bool(getattr(self, "_skills_auto_discover", False))
        should_init = self._skill_manager is None and (
            self._skills or self._skills_dirs or auto_discover
        )
        if should_init:
            from ..skills import SkillManager
            self._skill_manager = SkillManager()

            # Discover bundles so '@bundle' selectors in self._skills can be
            # expanded into their member skill names before injection. Honour
            # the configured discovery scope: only fall back to default skill
            # dirs when auto_discover is enabled or no explicit dirs are set.
            try:
                self._skill_manager.discover_bundles(
                    self._skills_dirs,
                    include_defaults=auto_discover or not self._skills_dirs,
                )
            except Exception as e:  # noqa: BLE001 - bundles are optional
                logging.debug("Bundle discovery skipped: %s", e)

            # Add explicit skill selectors. '@bundle' entries expand to their
            # member skill names (resolved by name against discovered skills);
            # plain paths pass through unchanged and load directly. Member
            # discovery honours the configured scope (only fall back to default
            # skill dirs when auto_discover is on), and a missing member is
            # logged so a typo'd bundle entry is not silently dropped.
            if self._skills:
                from ..skills.bundles import is_bundle_selector
                for selector in self._skills:
                    if is_bundle_selector(selector):
                        for member in self._skill_manager.resolve([selector]):
                            loaded = self._skill_manager.add_skill_by_name(
                                member, self._skills_dirs,
                                include_defaults=auto_discover,
                            )
                            if loaded is None:
                                logging.warning(
                                    "Skill bundle member '%s' (from '%s') not "
                                    "found; skipping.", member, selector,
                                )
                    else:
                        self._skill_manager.add_skill(selector)

            # Discover skills from directories; honour SkillsConfig.auto_discover
            # by falling back to default locations when requested.
            if self._skills_dirs:
                self._skill_manager.discover(
                    self._skills_dirs,
                    include_defaults=auto_discover,
                )
            elif auto_discover:
                self._skill_manager.discover(include_defaults=True)

            self._skills_initialized = True

            # Auto-add skill execution tools if not already present
            self._add_skill_tools()
        return self._skill_manager
    
    def _add_skill_tools(self):
        """Add tools required for skill execution (read_file, run_skill_script).

        Uses lazy imports from praisonaiagents.tools to avoid performance impact
        when skills are not used.

        G-E fix: run_skill_script is now safer by default:
        - PRAISONAI_DISABLE_SKILL_TOOLS=1: disables all skill tools (explicit deny wins)
        - PRAISONAI_ENABLE_SKILL_TOOLS=1: enables run_skill_script by default
        - Any loaded skill with 'run_skill_script' in allowed-tools: enables it
        - Otherwise: only read_file is added (safer default)
        """
        import os as _os
        if _os.environ.get("PRAISONAI_DISABLE_SKILL_TOOLS") in ("1", "true", "True"):
            logging.info("Skill helper tools disabled via PRAISONAI_DISABLE_SKILL_TOOLS")
            return

        # Check if tools already include required capabilities
        tool_names = set()
        for tool in self.tools:
            if callable(tool) and hasattr(tool, '__name__'):
                tool_names.add(tool.__name__)
            elif hasattr(tool, 'name'):
                tool_names.add(tool.name)
        
        # Add read_file if not present (low risk, always enabled)
        if 'read_file' not in tool_names:
            try:
                from ..tools import read_file
                self.tools.append(read_file)
                logging.debug("Added read_file tool for skill support")
            except ImportError:
                logging.warning("Could not import read_file tool for skills")
        
        # G-E fix: run_skill_script safer by default
        # Only add if explicitly enabled OR any skill declares it in allowed-tools
        should_add_script_tool = False
        
        # Check explicit environment enable
        if _os.environ.get("PRAISONAI_ENABLE_SKILL_TOOLS") in ("1", "true", "True"):
            should_add_script_tool = True
            logging.debug("run_skill_script enabled via PRAISONAI_ENABLE_SKILL_TOOLS")
        
        # Check if any loaded skill declares it in allowed-tools
        if self._skill_manager and not should_add_script_tool:
            for skill in self._skill_manager.skills:
                allowed_tools = self._skill_manager.get_allowed_tools(skill.properties.name)
                if "run_skill_script" in allowed_tools:
                    should_add_script_tool = True
                    logging.debug(f"run_skill_script enabled by skill '{skill.properties.name}' allowed-tools")
                    break
        
        # Add run_skill_script if conditions are met
        if should_add_script_tool and 'run_skill_script' not in tool_names:
            try:
                from ..tools.skill_tools import create_skill_tools
                # Create skill tools with current working directory
                skill_tools = create_skill_tools()
                self.tools.append(skill_tools.run_skill_script)
                logging.debug("Added run_skill_script tool for skill support")
            except ImportError as e:
                logging.warning(f"Could not import skill_tools: {e}")
    
    def get_skills_prompt(self) -> str:
        """Get the XML prompt for available skills.
        
        Returns:
            XML string with <available_skills> block, or empty string if no skills
        """
        if self.skill_manager is None:
            return ""
        return self.skill_manager.to_prompt()
    
    @property
    def _openai_client(self):
        """Lazily initialize OpenAI client only when needed."""
        if self.__openai_client is None:
            try:
                self.__openai_client = _get_llm_functions()['get_openai_client'](
                    api_key=self._openai_api_key, 
                    base_url=self._openai_base_url
                )
            except ValueError as e:
                # If we're using a custom LLM, we might not need the OpenAI client
                # Return None and let the calling code handle it
                if self._using_custom_llm:
                    return None
                else:
                    raise e
        return self.__openai_client

    @property
    def last_stop_reason(self) -> str:
        """Structured reason the last tool-execution loop stopped.

        One of ``"completed"`` (task finished), ``"max_steps"`` (the unified
        step budget from ``ExecutionConfig.max_steps`` was reached and the run was
        truncated), a provider block/refusal/truncation
        (``"content_filtered" | "refused" | "length_truncated"``) derived from the
        LLM ``finish_reason``/refusal signal, or ``"error"``. Lets CLI/CI callers
        branch on the terminal reason instead of parsing a magic string. Reads
        from whichever backend (OpenAI-native or LiteLLM) executed the last turn.
        """
        # OpenAI-native path records the finish-reason classification directly on
        # the agent (see ``_extract_llm_response_content``); prefer it so a
        # provider block/refusal isn't masked by a backend default of "completed".
        own = getattr(self, '_last_stop_reason', None)
        # Prefer a specific agent-owned provider block/refusal/truncation before
        # any backend fallback so a stale backend reason (e.g. ``max_steps``)
        # cannot mask the OpenAI-native classification recorded for this turn.
        if own and own != "completed":
            return own
        # Read from the already-instantiated backends only. ``__openai_client``
        # is the raw (name-mangled) attribute, never the lazy ``_openai_client``
        # property, so this never triggers OpenAI client creation for
        # LiteLLM-only agents.
        for backend in (getattr(self, 'llm_instance', None),
                        getattr(self, '_Agent__openai_client', None)):
            if backend is None:
                continue
            reason = getattr(backend, '_last_stop_reason', None)
            if reason and reason != "completed":
                return reason
        if own:
            return own
        return "completed"

    @property
    def agent_id(self) -> str:
        """Lazily generate agent ID when first accessed."""
        if self._agent_id is None:
            import uuid
            self._agent_id = str(uuid.uuid4())
        return self._agent_id
    
    @property
    def display_name(self) -> str:
        """Safe display name that never returns None.
        
        Returns the agent's name if set, otherwise returns 'Agent N' where N is a unique index.
        Use this for UI display, logging, and string operations where None would cause errors.
        """
        if self.name:
            return self.name
        # Use unique index for nameless agents
        if hasattr(self, '_agent_index') and self._agent_index is not None:
            return f"Agent {self._agent_index}"
        return "Agent"
    
    def _init_autonomy(self, autonomy: Any, verification_hooks: Optional[List[Any]] = None) -> None:
        """Initialize autonomy features (agent-centric escalation/doom-loop).
        
        Args:
            autonomy: True, False, dict config, or AutonomyConfig
            verification_hooks: Optional list of verification hooks
        """
        # Initialize verification hooks (always available, even without autonomy)
        self._verification_hooks = verification_hooks or []

        # Goal-loop state (default: disabled → autonomous loop unchanged)
        self._init_goal_state()

        if autonomy is None or autonomy is False:
            self.autonomy_enabled = False
            self.autonomy_config = {}
            self._autonomy_trigger = None
            self._doom_loop_tracker = None
            self._file_snapshot = None
            self._snapshot_stack = []
            self._redo_stack = []
            self._autonomy_turn_tool_count = 0
            self._consecutive_no_tool_turns = 0
            self._doom_recovery_active = False
            return
        
        self.autonomy_enabled = True
        
        # Lazy import to avoid overhead when not used
        from .autonomy import AutonomyConfig, AutonomyTrigger, DoomLoopTracker
        
        if autonomy is True:
            config = AutonomyConfig()
        elif isinstance(autonomy, dict):
            config = AutonomyConfig.from_dict(autonomy)
            # Extract verification_hooks from dict if provided
            if "verification_hooks" in autonomy and not verification_hooks:
                self._verification_hooks = autonomy.get("verification_hooks", [])
        elif isinstance(autonomy, AutonomyConfig):
            config = autonomy
            # Extract verification_hooks from AutonomyConfig if provided
            if autonomy.verification_hooks and not verification_hooks:
                self._verification_hooks = autonomy.verification_hooks
        elif isinstance(autonomy, str):
            # String preset: "suggest", "auto_edit", "full_auto"
            from ..config.presets import AUTONOMY_PRESETS
            from ..config.parse_utils import canonical_preset_key
            preset_config = AUTONOMY_PRESETS.get(canonical_preset_key(autonomy))
            if preset_config is not None:
                config = AutonomyConfig.from_dict(preset_config)
            else:
                # Unknown string preset — disable autonomy
                self.autonomy_enabled = False
                self.autonomy_config = {}
                self._autonomy_trigger = None
                self._doom_loop_tracker = None
                self._file_snapshot = None
                self._snapshot_stack = []
                self._redo_stack = []
                self._autonomy_turn_tool_count = 0
                self._consecutive_no_tool_turns = 0
                self._doom_recovery_active = False
                return
        else:
            self.autonomy_enabled = False
            self.autonomy_config = {}
            self._autonomy_trigger = None
            self._doom_loop_tracker = None
            self._file_snapshot = None
            self._snapshot_stack = []
            self._redo_stack = []
            self._autonomy_turn_tool_count = 0
            self._consecutive_no_tool_turns = 0
            self._doom_recovery_active = False
            return
        
        # Preserve ALL AutonomyConfig fields in the dict (G14 fix: no lossy extraction)
        self.autonomy_config = {
            "enabled": config.enabled,
            "level": config.level,
            "mode": config.mode,
            "max_iterations": config.max_iterations,
            "doom_loop_threshold": config.doom_loop_threshold,
            "auto_escalate": config.auto_escalate,
            "observe": config.observe,
            "completion_promise": config.completion_promise,
            "clear_context": config.clear_context,
            "track_changes": config.effective_track_changes,
            "snapshot_dir": config.snapshot_dir,
            "default_tools": config.default_tools,
            "max_budget_usd": config.max_budget_usd,
            "max_tokens": config.max_tokens,
            "budget_action": config.budget_action,
        }
        # Also preserve any extra user-provided keys from dict input
        if isinstance(autonomy, dict):
            for k, v in autonomy.items():
                if k not in self.autonomy_config:
                    self.autonomy_config[k] = v
        
        # Store the AutonomyConfig object for typed access
        self._autonomy_config_obj = config
        
        self._autonomy_trigger = AutonomyTrigger()
        self._doom_loop_tracker = DoomLoopTracker(threshold=config.doom_loop_threshold)
        self._doom_recovery_active = False
        
        # Initialize FileSnapshot for filesystem tracking (lazy import)
        self._file_snapshot = None
        self._snapshot_stack = []  # Stack of snapshot hashes for undo/redo
        self._redo_stack = []  # Redo stack
        if config.effective_track_changes:
            try:
                from ..snapshot import FileSnapshot
                import os
                self._file_snapshot = FileSnapshot(
                    project_path=os.getcwd(),
                    snapshot_dir=config.snapshot_dir,
                )
            except Exception as e:
                logger.debug(f"FileSnapshot init failed (git may not be available): {e}")
        
        # Wire ObservabilityHooks when observe=True (G-UNUSED-2 fix)
        if config.observe:
            from ..escalation.observability import ObservabilityHooks
            self._observability_hooks = ObservabilityHooks()
        else:
            self._observability_hooks = None
        
        # Wire level → approval bridge (G3 fix)
        self._bridge_autonomy_level(config.level)
    
    # ================================================================
    # Filesystem tracking convenience methods (powered by FileSnapshot)
    # ================================================================

    def set_snapshot_root(self, project_path: str) -> bool:
        """Root filesystem change-tracking at ``project_path``.

        Bots/gateway resolve file tools against a per-chat ``Workspace`` and
        attach it *after* construction, but the FileSnapshot backing
        :meth:`undo`/:meth:`redo`/:meth:`diff` was created at ``__init__`` time
        rooted at ``os.getcwd()``. Without this, ``/undo`` tracks the wrong
        directory (never where the tools actually wrote). Call this once after
        the workspace is known so change tracking follows the tools.

        Rooting at a new directory clears the undo/redo stacks (they belong to
        the previous root). A no-op when the root is unchanged. Returns ``True``
        when a snapshot manager is rooted at ``project_path``.
        """
        import os
        new_root = os.path.abspath(str(project_path))
        current = self._file_snapshot
        if current is not None and getattr(current, "project_path", None) == new_root:
            return True
        try:
            from ..snapshot import FileSnapshot
            snapshot_dir = None
            cfg = getattr(self, "autonomy_config", None)
            if isinstance(cfg, dict):
                snapshot_dir = cfg.get("snapshot_dir")
            self._file_snapshot = FileSnapshot(
                project_path=new_root,
                snapshot_dir=snapshot_dir,
            )
            with self._snapshot_lock:
                self._snapshot_stack = []
                self._redo_stack = []
            return True
        except Exception as e:  # pragma: no cover - git may be unavailable
            logger.debug(f"Re-rooting FileSnapshot failed: {e}")
            return False

    def undo(self) -> bool:
        """Undo the last set of file changes.
        
        Restores files to the state before the last autonomous iteration.
        Requires ``autonomy=AutonomyConfig(track_changes=True)``.
        
        Returns:
            True if undo was successful, False if nothing to undo.
            
        Example::
        
            agent = Agent(autonomy="full_auto")
            result = agent.start("Refactor utils.py")
            agent.undo()  # Restore original files
        """
        if self._file_snapshot is None:
            return False
        
        with self._snapshot_lock:
            if not self._snapshot_stack:
                return False
            try:
                target_hash = self._snapshot_stack.pop()
                # Get current hash before restore (for redo)
                current_hash = self._file_snapshot.get_current_hash()
                if current_hash:
                    self._redo_stack.append(current_hash)
                self._file_snapshot.restore(target_hash)
                return True
            except Exception as e:
                logger.debug(f"Undo failed: {e}")
                return False
    
    def redo(self) -> bool:
        """Redo a previously undone set of file changes.
        
        Re-applies file changes that were reverted by :meth:`undo`.
        
        Returns:
            True if redo was successful, False if nothing to redo.
        """
        if self._file_snapshot is None:
            return False
        
        with self._snapshot_lock:
            if not self._redo_stack:
                return False
            try:
                target_hash = self._redo_stack.pop()
                current_hash = self._file_snapshot.get_current_hash()
                if current_hash:
                    self._snapshot_stack.append(current_hash)
                self._file_snapshot.restore(target_hash)
                return True
            except Exception as e:
                logger.debug(f"Redo failed: {e}")
                return False
    
    def diff(self, from_hash: Optional[str] = None):
        """Get file diffs from autonomous execution.
        
        Returns a list of :class:`FileDiff` objects showing what files
        were modified, with additions/deletions counts.
        
        Args:
            from_hash: Base commit hash to diff from. If None, uses the
                first snapshot (pre-autonomous state).
        
        Returns:
            List of FileDiff objects, or empty list if tracking not enabled.
            
        Example::
        
            agent = Agent(autonomy="full_auto")
            result = agent.start("Refactor utils.py")
            for d in agent.diff():
                print(f"{d.status}: {d.path} (+{d.additions}/-{d.deletions})")
        """
        if self._file_snapshot is None:
            return []
        try:
            base = from_hash
            if base is None:
                # Protect snapshot stack read with lock to prevent TOCTOU with undo/redo
                with self._snapshot_lock:
                    if self._snapshot_stack:
                        base = self._snapshot_stack[0]
            if base is None:
                return []
            return self._file_snapshot.diff(base)
        except Exception as e:
            logger.debug(f"Diff failed: {e}")
            return []
    
    def analyze_prompt(self, prompt: str) -> set:
        """Analyze prompt for autonomy signals.
        
        Args:
            prompt: The user prompt
            
        Returns:
            Set of detected signal names
        """
        if not self.autonomy_enabled or self._autonomy_trigger is None:
            return set()
        return self._autonomy_trigger.analyze(prompt)
    
    def get_recommended_stage(self, prompt: str) -> str:
        """Get recommended execution stage for prompt.
        
        Args:
            prompt: The user prompt
            
        Returns:
            Stage name as string (direct, heuristic, planned, autonomous)
        """
        if not self.autonomy_enabled or self._autonomy_trigger is None:
            return "direct"
        
        signals = self._autonomy_trigger.analyze(prompt)
        stage = self._autonomy_trigger.recommend_stage(signals)
        return stage.name.lower()
    
    def _record_action(self, action_type: str, args: dict, result: Any, success: bool) -> None:
        """Record an action for doom loop tracking.
        
        Args:
            action_type: Type of action
            args: Action arguments
            result: Action result
            success: Whether action succeeded
        """
        if self._doom_loop_tracker is not None:
            self._doom_loop_tracker.record(action_type, args, result, success)
    
    @staticmethod
    def _response_indicates_failure(response_str: str) -> bool:
        """Best-effort per-iteration failure signal for doom-loop tracking.

        Replaces the old hard-coded ``success=True`` fed to the DoomLoopTracker,
        which made the consecutive-failure detector impossible to fire. This is a
        lightweight heuristic on the visible response text; the authoritative
        result-aware loop detection now runs in the tool-execution path.
        """
        if not response_str:
            return True
        lowered = response_str.strip().lower()
        # Only unambiguous hard-failure markers. Phrases like "i am/was unable
        # to <X>" are deliberately excluded: an agent can complete a task via an
        # alternate path while noting it could not obtain some optional data, so
        # treating those as failures would trip consecutive-failure recovery even
        # while progress is being made.
        _markers = (
            "traceback (most recent call last)",
            "an error occurred",
            "i encountered an error",
            "failed to complete the task",
        )
        return any(m in lowered for m in _markers)

    def _is_doom_loop(self) -> bool:
        """Check if we're in a doom loop.
        
        Returns:
            True if doom loop detected
        """
        if self._doom_loop_tracker is None:
            return False
        return self._doom_loop_tracker.is_doom_loop()
    
    def _reset_doom_loop(self) -> None:
        """Reset doom loop tracking."""
        if self._doom_loop_tracker is not None:
            self._doom_loop_tracker.reset()

    def _reset_loop_warnings(self) -> None:
        """Clear stale loop-warning latch/nudge from a prior autonomous run.

        Called at the top of run_autonomous(_async) so a self-correction
        queued near the end of a previous run never leaks into an unrelated
        task's first prompt.
        """
        self._pending_self_correction = None
        self._loop_warned_this_turn = False

    def _consume_self_correction(self, prompt: str) -> str:
        """Reset the per-turn warning latch and inject any queued nudge.

        Two-tier response: if the result-aware tool-loop detector queued a
        self-correction nudge last turn, append it to this turn's prompt (one
        chance to adapt before the critical hard-stop fires on persistence).
        """
        self._loop_warned_this_turn = False
        if getattr(self, '_pending_self_correction', None):
            prompt = f"{prompt}\n\n{self._pending_self_correction}"
            self._pending_self_correction = None
        return prompt
    
    @staticmethod
    def _is_completion_signal(response_text: str) -> bool:
        """Check if response contains a completion signal using word boundaries.
        
        Uses regex word boundaries to avoid false positives like
        'abandoned' matching 'done' or 'unfinished' matching 'finished'.
        
        Args:
            response_text: The agent response to check
            
        Returns:
            True if a completion signal is detected
        """
        import re
        response_lower = response_text.lower()
        # Negation patterns that should NOT be treated as completion
        _NEGATION_RE = re.compile(
            r'\b(?:not|never|no longer|hardly|barely|isn\'t|aren\'t|wasn\'t|weren\'t|hasn\'t|haven\'t|hadn\'t|won\'t|wouldn\'t|can\'t|couldn\'t|shouldn\'t|don\'t|doesn\'t|didn\'t)\b'
            r'.{0,20}'   # up to 20 chars between negation and keyword
        )
        # Word-boundary patterns to avoid substring false positives
        _COMPLETION_PATTERNS = [
            (re.compile(r'\btask\s+completed?\b'), False),         # no negation check needed
            (re.compile(r'\bcompleted\s+successfully\b'), False),
            (re.compile(r'\ball\s+done\b'), False),
            (re.compile(r'\bdone\b'), True),          # 'done' needs negation check
            (re.compile(r'\bfinished\b'), True),      # 'finished' needs negation check
        ]
        for pattern, needs_negation_check in _COMPLETION_PATTERNS:
            match = pattern.search(response_lower)
            if match:
                if needs_negation_check:
                    # Check if a negation word precedes the match within 30 chars
                    start = max(0, match.start() - 30)
                    prefix = response_lower[start:match.start()]
                    if _NEGATION_RE.search(prefix):
                        continue  # Skip — negated completion
                    # Also check "not X yet" pattern
                    end = min(len(response_lower), match.end() + 10)
                    suffix = response_lower[match.end():end]
                    if 'yet' in suffix:
                        neg_prefix = response_lower[max(0, match.start() - 15):match.start()]
                        if 'not' in neg_prefix:
                            continue
                return True
        return False
    
    def _get_doom_recovery(self) -> str:
        """Get doom loop recovery action from tracker.
        
        Returns:
            Recovery action string: continue, retry_different, escalate_model,
            request_help, or abort
        """
        if self._doom_loop_tracker is None:
            return "continue"
        return self._doom_loop_tracker.get_recovery_action()
    
    def _bridge_autonomy_level(self, level: str) -> None:
        """Bridge autonomy level to per-agent approval backend (G3/G-BRIDGE-1 fix).
        
        Sets a flag so the approval backend setup (later in __init__) can
        configure per-agent approval based on autonomy level.
        Does NOT use global env var — ensures multi-agent isolation.
        
        Args:
            level: Autonomy level string (suggest, auto_edit, full_auto)
        """
        # Store the requested autonomy level for the approval setup to use.
        # The actual _approval_backend is configured later in __init__
        # (after _init_autonomy), so we set a flag here.
        self._autonomy_level_for_approval = level
    
    def run_autonomous(
        self,
        prompt: str,
        max_iterations: Optional[int] = None,
        timeout_seconds: Optional[float] = None,
        completion_promise: Optional[str] = None,
        clear_context: bool = False,
    ):
        """Run an autonomous task execution loop.
        
        This method executes a task autonomously, using the agent's tools
        and capabilities to complete the task. It handles:
        - Progressive escalation based on task complexity
        - Doom loop detection and recovery
        - Iteration limits and timeouts
        - Completion detection (keyword-based or promise-based)
        - Optional context clearing between iterations
        
        Args:
            prompt: The task to execute
            max_iterations: Override max iterations (default from config)
            timeout_seconds: Timeout in seconds (default: no timeout)
            completion_promise: Optional string that signals completion when 
                wrapped in <promise>TEXT</promise> tags in the response
            clear_context: Whether to clear chat history between iterations
                (forces agent to rely on external state like files)
            
        Returns:
            AutonomyResult with success status, output, and metadata
            
        Raises:
            ValueError: If autonomy is not enabled
            
        Example:
            agent = Agent(instructions="...", autonomy=True)
            result = agent.run_autonomous(
                "Refactor the auth module",
                completion_promise="DONE",
                clear_context=True
            )
            if result.success:
                print(result.output)
        """
        from .autonomy import AutonomyResult
        import time as time_module
        from datetime import datetime, timezone
        
        if not self.autonomy_enabled:
            raise ValueError(
                "Autonomy must be enabled to use run_autonomous(). "
                "Create agent with autonomy=True or autonomy={...}"
            )
        
        # Take initial snapshot before autonomous execution starts
        # NOTE: Snapshot tracking is disabled by default for performance (G12 fix)
        # FileSnapshot.track() walks entire project and is too slow for large codebases
        # Enable with autonomy={"snapshot": True} if needed
        if self._file_snapshot is not None and self.autonomy_config.get("snapshot", False):
            try:
                snap_info = self._file_snapshot.track(message="pre-autonomous")
                with self._snapshot_lock:
                    self._snapshot_stack.append(snap_info.commit_hash)
                    self._redo_stack.clear()
            except Exception as e:
                logging.debug(f"Pre-autonomous snapshot failed: {e}")
        
        start_time = time_module.time()
        started_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        iterations = 0
        actions_taken = []
        # Spend baseline: snapshot lifetime spend so the budget cap measures
        # only THIS run (reused Agents keep prior chat/run spend in the counters).
        spend_baseline = self._run_spend()
        
        # Get config values
        config_max_iter = self.autonomy_config.get("max_iterations", 20)
        effective_max_iter = max_iterations if max_iterations is not None else config_max_iter
        
        # Get completion_promise from config if not provided as param
        effective_promise = completion_promise
        if effective_promise is None:
            effective_promise = self.autonomy_config.get("completion_promise")
        
        # Get clear_context from config if not explicitly set
        effective_clear_context = clear_context
        if not clear_context:
            effective_clear_context = self.autonomy_config.get("clear_context", False)
        
        # Analyze prompt and get recommended stage
        stage = self.get_recommended_stage(prompt)
        
        # Reset doom loop tracker for new task
        self._reset_doom_loop()
        # Clear any stale loop-warning latch/nudge from a previous run.
        self._reset_loop_warnings()
        
        # P3/G2: Import callback helper for autonomy events
        from ..main import execute_sync_callback
        
        try:
            # Execute the autonomous loop
            while iterations < effective_max_iter:
                iterations += 1
                
                # P3/G2: Emit autonomy_iteration callback for CLI visibility
                execute_sync_callback('autonomy_iteration',
                    iteration=iterations,
                    max_iterations=effective_max_iter,
                    stage=stage
                )
                
                # Check timeout
                if timeout_seconds and (time_module.time() - start_time) > timeout_seconds:
                    return AutonomyResult(
                        success=False,
                        output="Task timed out",
                        completion_reason="timeout",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # G2: Check for interrupt request (cooperative cancellation) - sync version
                if self.interrupt_controller and self.interrupt_controller.is_set():
                    reason = self.interrupt_controller.reason or "unknown"
                    return AutonomyResult(
                        success=False,
                        output=f"Task interrupted: {reason}",
                        completion_reason="interrupted",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # Execute one turn using the agent's chat method
                # Always use the original prompt (prompt re-injection)
                # Reset per-turn tool count for no-tool-call detection
                self._autonomy_turn_tool_count = 0
                # Reset the per-turn warning latch and inject any queued nudge.
                turn_prompt = self._consume_self_correction(prompt)
                try:
                    response = self.chat(turn_prompt)
                except Exception as e:
                    return AutonomyResult(
                        success=False,
                        output=str(e),
                        completion_reason="error",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        error=str(e),
                        started_at=started_at,
                    )
                
                response_str = str(response)
                
                # Spend kill-switch: halt if cumulative cost/tokens exceed cap.
                # Zero overhead when no cap is set (returns None immediately).
                _budget_result = self._autonomy_budget_result(
                    iterations, stage, actions_taken, start_time, started_at,
                    response_str, spend_baseline
                )
                if _budget_result is not None:
                    execute_sync_callback('autonomy_complete',
                        completion_reason=_budget_result.completion_reason,
                        iterations=iterations,
                        duration_seconds=time_module.time() - start_time
                    )
                    return _budget_result
                
                # Record response text for content streaming loop detection
                if self._doom_loop_tracker is not None:
                    self._doom_loop_tracker.record_response(response_str)
                
                # Record the action for doom loop tracking (G1 fix: was missing).
                # The result-aware tool-loop detector (name+args+result-hash,
                # ping-pong) now owns per-tool-call loop detection in the
                # tool-execution path; DoomLoopDetector is kept for the
                # content-loop/"chanting" and time checks it does uniquely.
                # Derive a REAL success signal instead of the old hard-coded True
                # (which made the failure-streak detector impossible to fire).
                iteration_success = not self._response_indicates_failure(response_str)
                self._record_action(
                    "chat",
                    {"response_hash": hash(response_str[:500])},
                    response_str[:200],
                    iteration_success,
                )
                
                # Check doom loop AFTER recording action so detector sees
                # the current iteration's fingerprint (repositioned from top
                # of loop for correct detection timing).
                if self._is_doom_loop():
                    recovery = self._get_doom_recovery()
                    
                    # P3/G2: Emit doom loop callback for CLI visibility
                    execute_sync_callback('autonomy_doom_loop',
                        iteration=iterations,
                        recovery_action=recovery
                    )
                    
                    obs = getattr(self, '_observability_hooks', None)
                    if obs is not None:
                        from ..escalation.observability import EventType as _EvtType
                        obs.emit(_EvtType.STEP_END, {
                            "doom_loop": True,
                            "recovery_action": recovery,
                            "iteration": iterations,
                        })
                    if recovery == "retry_different":
                        prompt = prompt + "\n\n[System: Previous approach repeated. Try a completely different strategy.]"
                        if self._doom_loop_tracker is not None:
                            self._doom_loop_tracker.clear_actions()
                        self._consecutive_no_tool_turns = 0
                        self._doom_recovery_active = True
                        continue
                    elif recovery == "escalate_model":
                        prompt = prompt + "\n\n[System: You are stuck in a loop. CRITICAL: Check that all tool argument names exactly match the function signature. Do NOT add '=' to argument names. Use only the documented parameter names.]"
                        if self._doom_loop_tracker is not None:
                            self._doom_loop_tracker.clear_actions()
                        self._consecutive_no_tool_turns = 0
                        self._doom_recovery_active = True
                        continue
                    elif recovery == "request_help":
                        return AutonomyResult(
                            success=False,
                            output="Task needs human guidance (doom loop recovery exhausted)",
                            completion_reason="needs_help",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    else:
                        return AutonomyResult(
                            success=False,
                            output="Task stopped due to repeated actions (doom loop)",
                            completion_reason="doom_loop",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                
                # Record for action history
                actions_taken.append({
                    "iteration": iterations,
                    "response": response_str[:500],
                })
                
                # Observability logging via ObservabilityHooks (G-UNUSED-2 fix)
                obs = getattr(self, '_observability_hooks', None)
                if obs is not None:
                    from ..escalation.observability import EventType as _EvtType
                    obs.increment_step()
                    obs.emit(_EvtType.STEP_END, {
                        "iteration": iterations,
                        "stage": stage,
                        "response_len": len(response_str),
                        "agent_name": getattr(self, 'name', None),
                    })
                elif self.autonomy_config.get("observe"):
                    get_logger(__name__).info(
                        f"[autonomy] iteration={iterations} stage={stage} "
                        f"response_len={len(response_str)}"
                    )
                
                # Auto-save session after each iteration (memory integration)
                self._auto_save_session()

                # ─────────────────────────────────────────────────────────────
                # GOAL COMPLETION JUDGE (opt-in): when a goal loop is active,
                # an independent judge gates termination on the goal's
                # acceptance criteria instead of the keyword/promise heuristics.
                # When no goal is set, this is a no-op (behaviour unchanged).
                # ─────────────────────────────────────────────────────────────
                _goal_gate = self._goal_gate(response_str)
                if _goal_gate is not None:
                    _outcome, _reason = _goal_gate
                    if _outcome == "done":
                        return AutonomyResult(
                            success=True, output=response_str,
                            completion_reason="goal_met", iterations=iterations,
                            stage=stage, actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    if _outcome == "budget_paused":
                        return AutonomyResult(
                            success=False, output=response_str,
                            completion_reason="budget_paused",
                            iterations=iterations, stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    prompt = self._goal_continuation_prompt(self._goal_state)
                    continue

                # ─────────────────────────────────────────────────────────────
                # VERIFICATION GATE (opt-in): before any success signal below
                # can finalise the run, all blocking verification hooks must
                # pass. On failure, feed captured stdout/stderr back and keep
                # iterating (never-passing checks end at max_iterations).
                # No-op when no verification hooks are configured.
                # ─────────────────────────────────────────────────────────────
                _gate_feedback = self._verification_gate(response_str, iterations)
                if _gate_feedback is not None:
                    prompt = _gate_feedback
                    continue

                # ─────────────────────────────────────────────────────────────
                # TOOL-CALL COMPLETION: If the model used tools this turn AND
                # produced a substantive response, the inner loop completed
                # the task naturally (model stopped calling tools = done).
                # This is the same signal the CLI/wrapper path trusts.
                # ─────────────────────────────────────────────────────────────
                if self._autonomy_turn_tool_count > 0 and len(response_str) > 100:
                    # P3/G2: Emit completion callback
                    execute_sync_callback('autonomy_complete',
                        completion_reason="tool_completion",
                        iterations=iterations,
                        duration_seconds=time_module.time() - start_time
                    )
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="tool_completion",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # Auto-escalate stage if stuck (G11 fix: wire auto_escalate)
                if (self.autonomy_config.get("auto_escalate")
                        and iterations > 1
                        and stage in ("direct", "heuristic")):
                    stage_order = ["direct", "heuristic", "planned", "autonomous"]
                    idx = stage_order.index(stage) if stage in stage_order else 0
                    if idx < len(stage_order) - 1:
                        prev_stage = stage
                        stage = stage_order[idx + 1]
                        
                        # P3/G2: Emit stage change callback for CLI visibility
                        execute_sync_callback('autonomy_stage_change',
                            from_stage=prev_stage,
                            to_stage=stage
                        )
                        
                        if obs is not None:
                            obs.emit(_EvtType.STAGE_ESCALATE, {"from": prev_stage, "to": stage})
                
                # Check for completion promise FIRST (structured signal)
                if effective_promise:
                    promise_tag = f"<promise>{effective_promise}</promise>"
                    if promise_tag in response_str:
                        # P3/G2: Emit completion callback
                        execute_sync_callback('autonomy_complete',
                            completion_reason="promise",
                            iterations=iterations,
                            duration_seconds=time_module.time() - start_time
                        )
                        return AutonomyResult(
                            success=True,
                            output=response_str,
                            completion_reason="promise",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                
                # Check for keyword-based completion signals (word-boundary, G-COMPLETION-1 fix)
                if self._is_completion_signal(response_str):
                    # P3/G2: Emit completion callback
                    execute_sync_callback('autonomy_complete',
                        completion_reason="goal",
                        iterations=iterations,
                        duration_seconds=time_module.time() - start_time
                    )
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="goal",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # For DIRECT stage, complete after first response
                if stage == "direct":
                    # P3/G2: Emit completion callback
                    execute_sync_callback('autonomy_complete',
                        completion_reason="goal",
                        iterations=iterations,
                        duration_seconds=time_module.time() - start_time
                    )
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="goal",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # Clear context between iterations if enabled
                if effective_clear_context:
                    self.clear_history()
                
                # No-tool-call termination: if model makes no tool calls for 2+
                # consecutive turns, treat as completion signal.
                # Skip first iteration (model may be planning).
                # Suppressed when doom recovery is active — once a doom loop
                # is detected, no_tool_calls (a success exit) should not fire;
                # the doom loop system manages termination instead.
                if (self._autonomy_turn_tool_count == 0 and iterations > 1
                        and not self._doom_recovery_active):
                    self._consecutive_no_tool_turns += 1
                    if self._consecutive_no_tool_turns >= 2:
                        execute_sync_callback('autonomy_complete',
                            completion_reason="no_tool_calls",
                            iterations=iterations,
                            duration_seconds=time_module.time() - start_time
                        )
                        return AutonomyResult(
                            success=True,
                            output=response_str,
                            completion_reason="no_tool_calls",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                else:
                    self._consecutive_no_tool_turns = 0
            
            # Max iterations reached
            # P3/G2: Emit completion callback for max iterations
            execute_sync_callback('autonomy_complete',
                completion_reason="max_iterations",
                iterations=iterations,
                duration_seconds=time_module.time() - start_time
            )
            return AutonomyResult(
                success=False,
                output="Max iterations reached",
                completion_reason="max_iterations",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                started_at=started_at,
            )
        
        except KeyboardInterrupt:
            return AutonomyResult(
                success=False,
                output="Task cancelled by user",
                completion_reason="cancelled",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                started_at=started_at,
            )
        except Exception as e:
            return AutonomyResult(
                success=False,
                output=str(e),
                completion_reason="error",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                error=str(e),
                started_at=started_at,
            )
    
    async def run_autonomous_async(
        self,
        prompt: str,
        max_iterations: Optional[int] = None,
        timeout_seconds: Optional[float] = None,
        completion_promise: Optional[str] = None,
        clear_context: bool = False,
    ):
        """Async variant of run_autonomous() for concurrent agent execution.
        
        This method executes a task autonomously using async I/O, enabling
        multiple agents to run concurrently without blocking. It handles:
        - Progressive escalation based on task complexity
        - Doom loop detection and recovery
        - Iteration limits and timeouts
        - Completion detection (keyword-based or promise-based)
        - Optional context clearing between iterations
        
        Args:
            prompt: The task to execute
            max_iterations: Override max iterations (default from config)
            timeout_seconds: Timeout in seconds (default: no timeout)
            completion_promise: Optional string that signals completion when 
                wrapped in <promise>TEXT</promise> tags in the response
            clear_context: Whether to clear chat history between iterations
                (forces agent to rely on external state like files)
            
        Returns:
            AutonomyResult with success status, output, and metadata
            
        Raises:
            ValueError: If autonomy is not enabled
            
        Example:
            import asyncio
            
            async def main():
                agent = Agent(instructions="...", autonomy=True)
                result = await agent.run_autonomous_async(
                    "Refactor the auth module",
                    completion_promise="DONE",
                    clear_context=True
                )
                if result.success:
                    print(result.output)
            
            asyncio.run(main())
        """
        from .autonomy import AutonomyResult
        import time as time_module
        from datetime import datetime, timezone
        import asyncio
        
        if not self.autonomy_enabled:
            raise ValueError(
                "Autonomy must be enabled to use run_autonomous_async(). "
                "Create agent with autonomy=True or autonomy={...}"
            )
        
        start_time = time_module.time()
        started_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        iterations = 0
        actions_taken = []
        # Spend baseline: snapshot lifetime spend so the budget cap measures
        # only THIS run (reused Agents keep prior chat/run spend in the counters).
        spend_baseline = self._run_spend()
        
        # Get config values
        config_max_iter = self.autonomy_config.get("max_iterations", 20)
        effective_max_iter = max_iterations if max_iterations is not None else config_max_iter
        
        # Get completion_promise from config if not provided as param
        effective_promise = completion_promise
        if effective_promise is None:
            effective_promise = self.autonomy_config.get("completion_promise")
        
        # Get clear_context from config if not explicitly set
        effective_clear_context = clear_context
        if not clear_context:
            effective_clear_context = self.autonomy_config.get("clear_context", False)
        
        # Analyze prompt and get recommended stage
        stage = self.get_recommended_stage(prompt)
        
        # Reset doom loop tracker for new task
        self._reset_doom_loop()
        # Clear any stale loop-warning latch/nudge from a previous run.
        self._reset_loop_warnings()
        
        try:
            # Execute the autonomous loop
            while iterations < effective_max_iter:
                iterations += 1
                
                # Check timeout
                if timeout_seconds and (time_module.time() - start_time) > timeout_seconds:
                    return AutonomyResult(
                        success=False,
                        output="Task timed out",
                        completion_reason="timeout",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # G2: Check for interrupt request (cooperative cancellation)
                if self.interrupt_controller and self.interrupt_controller.is_set():
                    reason = self.interrupt_controller.reason or "unknown"
                    return AutonomyResult(
                        success=False,
                        output=f"Task interrupted: {reason}",
                        completion_reason="interrupted",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                
                # Execute one turn using the agent's async chat method
                # Always use the original prompt (prompt re-injection)
                # Reset per-turn tool count for no-tool-call detection
                self._autonomy_turn_tool_count = 0
                # Reset the per-turn warning latch and inject any queued nudge.
                turn_prompt = self._consume_self_correction(prompt)
                try:
                    response = await self.achat(turn_prompt)
                except Exception as e:
                    return AutonomyResult(
                        success=False,
                        output=str(e),
                        completion_reason="error",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        error=str(e),
                        started_at=started_at,
                    )
                
                response_str = str(response)
                
                # Spend kill-switch: halt if cumulative cost/tokens exceed cap.
                # Zero overhead when no cap is set (returns None immediately).
                _budget_result = self._autonomy_budget_result(
                    iterations, stage, actions_taken, start_time, started_at,
                    response_str, spend_baseline
                )
                if _budget_result is not None:
                    return _budget_result
                
                # Record response text for content streaming loop detection
                if self._doom_loop_tracker is not None:
                    self._doom_loop_tracker.record_response(response_str)
                
                # Record the action for doom loop tracking (G1 fix: was missing).
                # The result-aware tool-loop detector (name+args+result-hash,
                # ping-pong) now owns per-tool-call loop detection in the
                # tool-execution path; DoomLoopDetector is kept for the
                # content-loop/"chanting" and time checks it does uniquely.
                # Derive a REAL success signal instead of the old hard-coded True
                # (which made the failure-streak detector impossible to fire).
                iteration_success = not self._response_indicates_failure(response_str)
                self._record_action(
                    "chat",
                    {"response_hash": hash(response_str[:500])},
                    response_str[:200],
                    iteration_success,
                )
                
                # Check doom loop AFTER recording action so detector sees
                # the current iteration's fingerprint (repositioned from top
                # of loop for correct detection timing).
                if self._is_doom_loop():
                    recovery = self._get_doom_recovery()
                    obs = getattr(self, '_observability_hooks', None)
                    if obs is not None:
                        from ..escalation.observability import EventType as _EvtType
                        obs.emit(_EvtType.STEP_END, {
                            "doom_loop": True,
                            "recovery_action": recovery,
                            "iteration": iterations,
                        })
                    if recovery == "retry_different":
                        prompt = prompt + "\n\n[System: Previous approach repeated. Try a completely different strategy.]"
                        if self._doom_loop_tracker is not None:
                            self._doom_loop_tracker.clear_actions()
                        self._consecutive_no_tool_turns = 0
                        self._doom_recovery_active = True
                        continue
                    elif recovery == "escalate_model":
                        prompt = prompt + "\n\n[System: You are stuck in a loop. CRITICAL: Check that all tool argument names exactly match the function signature. Do NOT add '=' to argument names. Use only the documented parameter names.]"
                        if self._doom_loop_tracker is not None:
                            self._doom_loop_tracker.clear_actions()
                        self._consecutive_no_tool_turns = 0
                        self._doom_recovery_active = True
                        continue
                    elif recovery == "request_help":
                        return AutonomyResult(
                            success=False,
                            output="Task needs human guidance (doom loop recovery exhausted)",
                            completion_reason="needs_help",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    else:
                        return AutonomyResult(
                            success=False,
                            output="Task stopped due to repeated actions (doom loop)",
                            completion_reason="doom_loop",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                
                # Record for action history
                actions_taken.append({
                    "iteration": iterations,
                    "response": response_str[:500],
                })
                
                # Observability logging via ObservabilityHooks (G-UNUSED-2 fix)
                obs = getattr(self, '_observability_hooks', None)
                if obs is not None:
                    from ..escalation.observability import EventType as _EvtType
                    obs.increment_step()
                    obs.emit(_EvtType.STEP_END, {
                        "iteration": iterations,
                        "stage": stage,
                        "response_len": len(response_str),
                        "agent_name": getattr(self, 'name', None),
                    })
                elif self.autonomy_config.get("observe"):
                    get_logger(__name__).info(
                        f"[autonomy-async] iteration={iterations} stage={stage} "
                        f"response_len={len(response_str)}"
                    )
                
                # Auto-save session after each async iteration (memory integration)
                self._auto_save_session()

                # ─────────────────────────────────────────────────────────────
                # GOAL COMPLETION JUDGE (opt-in): independent acceptance-criteria
                # gate. No-op when no goal loop is active (behaviour unchanged).
                # ─────────────────────────────────────────────────────────────
                _goal_gate = self._goal_gate(response_str)
                if _goal_gate is not None:
                    _outcome, _reason = _goal_gate
                    if _outcome == "done":
                        return AutonomyResult(
                            success=True, output=response_str,
                            completion_reason="goal_met", iterations=iterations,
                            stage=stage, actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    if _outcome == "budget_paused":
                        return AutonomyResult(
                            success=False, output=response_str,
                            completion_reason="budget_paused",
                            iterations=iterations, stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                    prompt = self._goal_continuation_prompt(self._goal_state)
                    await asyncio.sleep(0)
                    continue

                # ─────────────────────────────────────────────────────────────
                # VERIFICATION GATE (opt-in): blocking hooks must pass before a
                # success signal below can finalise the run. No-op when unset.
                # ─────────────────────────────────────────────────────────────
                _gate_feedback = await self._verification_gate_async(response_str, iterations)
                if _gate_feedback is not None:
                    prompt = _gate_feedback
                    await asyncio.sleep(0)
                    continue

                # ─────────────────────────────────────────────────────────────
                # TOOL-CALL COMPLETION: If the model used tools this turn AND
                # produced a substantive response, the inner loop completed
                # the task naturally (model stopped calling tools = done).
                # ─────────────────────────────────────────────────────────────
                if self._autonomy_turn_tool_count > 0 and len(response_str) > 100:
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="tool_completion",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # Auto-escalate stage if stuck (G11 fix: wire auto_escalate)
                if (self.autonomy_config.get("auto_escalate")
                        and iterations > 1
                        and stage in ("direct", "heuristic")):
                    stage_order = ["direct", "heuristic", "planned", "autonomous"]
                    idx = stage_order.index(stage) if stage in stage_order else 0
                    if idx < len(stage_order) - 1:
                        stage = stage_order[idx + 1]
                        if obs is not None:
                            obs.emit(_EvtType.STAGE_ESCALATE, {"from": stage_order[idx], "to": stage})
                
                # Check for completion promise FIRST (structured signal)
                if effective_promise:
                    promise_tag = f"<promise>{effective_promise}</promise>"
                    if promise_tag in response_str:
                        return AutonomyResult(
                            success=True,
                            output=response_str,
                            completion_reason="promise",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                
                # Check for keyword-based completion signals (word-boundary, G-COMPLETION-1 fix)
                if self._is_completion_signal(response_str):
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="goal",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # For DIRECT stage, complete after first response
                if stage == "direct":
                    return AutonomyResult(
                        success=True,
                        output=response_str,
                        completion_reason="goal",
                        iterations=iterations,
                        stage=stage,
                        actions=actions_taken,
                        duration_seconds=time_module.time() - start_time,
                        started_at=started_at,
                    )
                
                # Clear context between iterations if enabled
                if effective_clear_context:
                    self.clear_history()
                
                # No-tool-call termination: if model makes no tool calls for 2+
                # consecutive turns, treat as completion signal.
                # Suppressed when doom recovery is active — once a doom loop
                # is detected, no_tool_calls (a success exit) should not fire;
                # the doom loop system manages termination instead.
                if (self._autonomy_turn_tool_count == 0 and iterations > 1
                        and not self._doom_recovery_active):
                    self._consecutive_no_tool_turns += 1
                    if self._consecutive_no_tool_turns >= 2:
                        return AutonomyResult(
                            success=True,
                            output=response_str,
                            completion_reason="no_tool_calls",
                            iterations=iterations,
                            stage=stage,
                            actions=actions_taken,
                            duration_seconds=time_module.time() - start_time,
                            started_at=started_at,
                        )
                else:
                    self._consecutive_no_tool_turns = 0
                
                # Yield control to allow other async tasks to run
                await asyncio.sleep(0)
            
            # Final auto-save before returning
            self._auto_save_session()
            
            # Max iterations reached
            return AutonomyResult(
                success=False,
                output="Max iterations reached",
                completion_reason="max_iterations",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                started_at=started_at,
            )
        
        except (KeyboardInterrupt, asyncio.CancelledError):
            return AutonomyResult(
                success=False,
                output="Task cancelled",
                completion_reason="cancelled",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                started_at=started_at,
            )
        except Exception as e:
            return AutonomyResult(
                success=False,
                output=str(e),
                completion_reason="error",
                iterations=iterations,
                stage=stage,
                actions=actions_taken,
                duration_seconds=time_module.time() - start_time,
                error=str(e),
                started_at=started_at,
            )
    
    def handoff_to(
        self,
        target_agent: 'Agent',
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        config: Optional['HandoffConfig'] = None,
    ) -> 'HandoffResult':
        """
        Programmatically hand off a task to another agent.
        
        This is the unified programmatic handoff API that replaces delegate().
        It uses the same Handoff mechanism as LLM-driven handoffs but can be
        called directly from code.
        
        Args:
            target_agent: The agent to hand off to
            prompt: The task/prompt to pass to target agent
            context: Optional additional context dictionary
            config: Optional HandoffConfig for advanced settings
            
        Returns:
            HandoffResult with response or error
            
        Example:
            ```python
            result = agent_a.handoff_to(agent_b, "Complete this analysis")
            if result.success:
                print(result.response)
            ```
        """
        from .handoff import Handoff, HandoffConfig
        
        handoff_obj = Handoff(
            agent=target_agent,
            config=config or HandoffConfig(),
        )
        return handoff_obj.execute_programmatic(self, prompt, context)
    
    def run_until(
        self,
        prompt: str,
        criteria: str = "",
        threshold: float = 8.0,
        max_iterations: int = 5,
        mode: str = "optimize",
        on_iteration: Optional[Callable[[Any], None]] = None,
        verbose: bool = False,
        goal: Optional[str] = None,
        goal_criteria: Optional[Any] = None,
        judge_model: Optional[str] = None,
    ) -> "EvaluationLoopResult":
        """
        Run agent iteratively until output meets quality criteria.
        
        This method implements the "Ralph Loop" pattern: run agent → judge output
        → improve based on feedback → repeat until threshold met.

        When ``goal`` is provided, delegates to the tool-using goal loop
        (:meth:`run_goal`) so the acceptance-criteria completion judge gates a
        real tool-iteration loop (rather than re-generating a whole answer).

        Args:
            prompt: The prompt to send to the agent
            criteria: Evaluation criteria for the Judge (e.g., "Response is thorough")
            threshold: Score threshold for success (default: 8.0, scale 1-10)
            max_iterations: Maximum iterations before stopping (default: 5)
            mode: "optimize" (stop on success) or "review" (run all iterations)
            on_iteration: Optional callback called after each iteration
            verbose: Enable verbose logging
            goal: Optional goal text — enables the tool-using goal loop
            goal_criteria: Optional structured GoalCriteria for the goal loop
            judge_model: Optional independent judge model for the goal loop
            
        Returns:
            EvaluationLoopResult with iteration history and final score.

            NOTE: when ``goal`` is provided this delegates to the tool-using
            goal loop and returns an
            :class:`~praisonaiagents.agent.autonomy.AutonomyResult` instead
            (``success``/``output``/``completion_reason``), which is a
            different shape from the default ``EvaluationLoopResult``.

        Example:
            ```python
            agent = Agent(name="analyzer", instructions="Analyze systems")
            result = agent.run_until(
                "Analyze the auth flow",
                criteria="Analysis is thorough and actionable",
                threshold=8.0,
            )
            print(result.final_score)  # 8.5
            print(result.success)      # True
            ```
        """
        if goal is not None:
            # Prefer explicit structured criteria; otherwise fold the string
            # ``criteria`` into a GoalCriteria so it is not silently dropped.
            effective_criteria = goal_criteria
            if effective_criteria is None and criteria:
                from ..goal.models import GoalCriteria
                effective_criteria = GoalCriteria(outcome=criteria)
            return self.run_goal(
                prompt, goal, criteria=effective_criteria,
                max_turns=max_iterations, judge_model=judge_model,
            )
        from ..eval.loop import EvaluationLoop
        
        loop = EvaluationLoop(
            agent=self,
            criteria=criteria,
            threshold=threshold,
            max_iterations=max_iterations,
            mode=mode,
            on_iteration=on_iteration,
            verbose=verbose,
        )
        return loop.run(prompt)
    
    async def run_until_async(
        self,
        prompt: str,
        criteria: str,
        threshold: float = 8.0,
        max_iterations: int = 5,
        mode: str = "optimize",
        on_iteration: Optional[Callable[[Any], None]] = None,
        verbose: bool = False,
    ) -> "EvaluationLoopResult":
        """
        Async version of run_until().
        
        Run agent iteratively until output meets quality criteria.
        
        Args:
            prompt: The prompt to send to the agent
            criteria: Evaluation criteria for the Judge
            threshold: Score threshold for success (default: 8.0)
            max_iterations: Maximum iterations before stopping (default: 5)
            mode: "optimize" (stop on success) or "review" (run all iterations)
            on_iteration: Optional callback called after each iteration
            verbose: Enable verbose logging
            
        Returns:
            EvaluationLoopResult with iteration history and final score
        """
        from ..eval.loop import EvaluationLoop
        
        loop = EvaluationLoop(
            agent=self,
            criteria=criteria,
            threshold=threshold,
            max_iterations=max_iterations,
            mode=mode,
            on_iteration=on_iteration,
            verbose=verbose,
        )
        return await loop.run_async(prompt)
    
    async def handoff_to_async(
        self,
        target_agent: 'Agent',
        prompt: str,
        context: Optional[Dict[str, Any]] = None,
        config: Optional['HandoffConfig'] = None,
    ) -> 'HandoffResult':
        """
        Asynchronously hand off a task to another agent.
        
        This is the async version of handoff_to() with concurrency control
        and timeout support.
        
        Args:
            target_agent: The agent to hand off to
            prompt: The task/prompt to pass to target agent
            context: Optional additional context dictionary
            config: Optional HandoffConfig for advanced settings
            
        Returns:
            HandoffResult with response or error
            
        Example:
            ```python
            result = await agent_a.handoff_to_async(agent_b, "Complete this analysis")
            if result.success:
                print(result.response)
            ```
        """
        from .handoff import Handoff, HandoffConfig
        
        handoff_obj = Handoff(
            agent=target_agent,
            config=config or HandoffConfig(),
        )
        return await handoff_obj.execute_async(self, prompt, context)
    
    # -------------------------------------------------------------------------
    #                     Runtime Capability Management
    # -------------------------------------------------------------------------
    
    def _run_verification_hooks(self) -> List[Dict[str, Any]]:
        """Run all registered verification hooks.

        Preserves the full result payload (``details``/``error``/
        ``duration_seconds`` — including ``returncode``/``stdout``/``stderr``
        captured by :class:`CommandVerificationHook`) so callers and the goal
        judge can gate on executable evidence, not just a boolean.

        Returns:
            List of verification result dicts.
        """
        results: List[Dict[str, Any]] = []
        for hook in getattr(self, '_verification_hooks', None) or []:
            try:
                result = hook.run()
                if isinstance(result, dict):
                    record = dict(result)
                    record.setdefault("success", False)
                elif hasattr(result, "to_dict"):
                    record = result.to_dict()
                else:
                    record = {
                        "success": getattr(result, "success", False),
                        "output": getattr(result, "output", ""),
                        "details": getattr(result, "details", {}),
                        "error": getattr(result, "error", None),
                        "duration_seconds": getattr(result, "duration_seconds", 0.0),
                    }
                record["hook"] = getattr(hook, "name", "unknown")
                record["blocking"] = getattr(hook, "blocking", True)
                results.append(record)
            except Exception as e:
                results.append({
                    "hook": getattr(hook, 'name', 'unknown'),
                    "blocking": getattr(hook, "blocking", True),
                    "success": False,
                    "error": str(e),
                })
        return results

    def add_verification(self, hook: Any) -> None:
        """Register a verification hook for the current run.

        Lets an autonomous agent (or caller) add a task-specific completion
        gate discovered mid-run, e.g. the regression test it just wrote.
        """
        if not hasattr(self, "_verification_hooks") or self._verification_hooks is None:
            self._verification_hooks = []
        self._verification_hooks.append(hook)

    def remove_verification(self, name: str) -> bool:
        """Remove a verification hook by name. Returns True if one was removed."""
        hooks = getattr(self, "_verification_hooks", None) or []
        remaining = [h for h in hooks if getattr(h, "name", None) != name]
        removed = len(remaining) != len(hooks)
        self._verification_hooks = remaining
        return removed

    def _verification_summary_tail(self, results: List[Dict[str, Any]], limit: int = 800) -> str:
        """Build a compact human-readable summary of gate results for feedback."""
        lines = []
        for r in results:
            status = "PASS" if r.get("success") else "FAIL"
            details = r.get("details") or {}
            rc = details.get("returncode")
            head = f"[{status}] {r.get('hook')}"
            if rc is not None:
                head += f" (exit={rc})"
            lines.append(head)
            out = r.get("output") or r.get("error") or ""
            if out and not r.get("success"):
                lines.append(str(out)[-limit:])
        return "\n".join(lines)

    def _verification_gate(self, response_str: str, iterations: int) -> Optional[str]:
        """Run verification hooks and gate completion.

        Returns ``None`` when no hooks are configured or all blocking hooks
        pass (loop may finalise with success). Otherwise returns a feedback
        prompt containing the failing hooks' captured output so the loop can
        continue and the agent can fix the failure.
        """
        if not getattr(self, "_verification_hooks", None):
            return None
        results = self._run_verification_hooks()
        return self._verification_gate_feedback(results)

    async def _verification_gate_async(
        self, response_str: str, iterations: int
    ) -> Optional[str]:
        """Async counterpart of :meth:`_verification_gate`.

        Hook execution (which may shell out via :class:`CommandVerificationHook`)
        is offloaded to a worker thread so a slow or blocking check never stalls
        the event loop shared by other concurrent agents.
        """
        if not getattr(self, "_verification_hooks", None):
            return None
        import asyncio as _asyncio

        results = await _asyncio.to_thread(self._run_verification_hooks)
        return self._verification_gate_feedback(results)

    def _verification_gate_feedback(
        self, results: List[Dict[str, Any]]
    ) -> Optional[str]:
        """Shared post-processing for the sync/async gates.

        Persists the results, records them durably, and returns a feedback
        prompt when a blocking hook failed (else ``None`` to allow completion).
        """
        self._last_verification_results = results
        self._record_verification_journal(results)
        failed = [r for r in results if r.get("blocking", True) and not r.get("success")]
        if not failed:
            return None
        summary = self._verification_summary_tail(failed)
        return (
            "Completion is blocked: the following verification checks failed. "
            "Fix the underlying problem, then continue.\n" + summary
        )

    def _verification_journal_payloads(
        self, results: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Build durable ``verification``-kind payloads for the run journal."""
        import hashlib

        payloads: List[Dict[str, Any]] = []
        for r in results:
            details = r.get("details") or {}
            output = r.get("output") or ""
            payloads.append({
                "name": r.get("hook"),
                "success": bool(r.get("success")),
                "returncode": details.get("returncode"),
                "command": details.get("command"),
                "path": details.get("path"),
                "duration_seconds": r.get("duration_seconds"),
                "output_hash": hashlib.sha256(str(output).encode()).hexdigest(),
            })
        return payloads

    def _record_verification_journal(self, results: List[Dict[str, Any]]) -> None:
        """Best-effort durable record of gate results to the run journal.

        Only writes when an opt-in durable run is active (``Agent(...,
        durable=True)``): the active :class:`DurableRunContext` appends each
        result as a ``verification``-kind :class:`JournalEvent`. When no durable
        run is active this is a no-op, so the default (journal-off) path stays
        zero-overhead.
        """
        get_ctx = getattr(self, "_get_durable_run_context", None)
        if not callable(get_ctx):
            return
        try:
            context = get_ctx()
        except Exception:  # pragma: no cover - defensive
            context = None
        if context is None:
            return
        try:
            context.record_verification(
                self._verification_journal_payloads(results)
            )
        except Exception:  # pragma: no cover - journalling is best-effort
            pass

    def get_available_tools(self) -> List[Any]:
        """
        Get tools available to this agent, filtered by plan_mode if enabled.
        
        In plan_mode, only read-only tools are available to prevent
        modifications during the planning phase.
        
        Returns:
            List of available tools
        """
        if not self.plan_mode:
            return self.tools
            
        # Filter to read-only tools only
        from ..planning import RESTRICTED_TOOLS
        
        filtered_tools = []
        for tool in self.tools:
            tool_name = getattr(tool, '__name__', str(tool)).lower()
            
            # Check if tool is in restricted list
            is_restricted = any(
                restricted.lower() in tool_name 
                for restricted in RESTRICTED_TOOLS
            )
            
            if not is_restricted:
                filtered_tools.append(tool)
                
        return filtered_tools
    
    def add_mcp_server(self, name: str, mcp: Any) -> Any:
        """
        Attach an MCP server to a live agent at runtime.

        Connects the MCP server (discovering its tools), tracks it by name, and
        appends it to ``self.tools`` so its tools become available on the next
        turn of the same run — no agent rebuild required. New MCP tools flow
        through the existing tool-execution and approval paths automatically.

        Args:
            name: Unique name for this MCP server (used by ``remove_mcp_server``).
            mcp: An ``MCP`` instance (e.g. ``MCP("npx -y @notionhq/notion-mcp-server")``).

        Returns:
            The attached ``MCP`` instance.

        Example:
            ```python
            from praisonaiagents.mcp import MCP
            agent.add_mcp_server("notion", MCP("npx -y @notionhq/notion-mcp-server"))
            # tools live on the next turn
            ```
        """
        if not name:
            raise ValueError("add_mcp_server requires a non-empty name")

        if not hasattr(self, "_mcp_servers"):
            self._mcp_servers = {}

        if name in self._mcp_servers:
            raise ValueError(
                f"MCP server '{name}' is already attached. "
                "Call remove_mcp_server() first to replace it."
            )

        # Ensure self.tools is a mutable list we can append to
        if not isinstance(self.tools, list):
            self.tools = list(self.tools) if self.tools else []

        self._mcp_servers[name] = mcp
        self.tools.append(mcp)
        self.refresh_tools()
        logging.debug(f"Attached MCP server '{name}' with runtime tools")
        return mcp

    def remove_mcp_server(self, name: str) -> bool:
        """
        Disconnect and deregister a previously attached MCP server.

        Removes the server's tools from ``self.tools`` and shuts the connection
        down cleanly (no leaked background loops). Tools disappear on the next
        turn.

        Args:
            name: The name used in ``add_mcp_server``.

        Returns:
            True if a server was removed, False if no server by that name existed.
        """
        servers = getattr(self, "_mcp_servers", None)
        if not servers or name not in servers:
            return False

        mcp = servers.pop(name)

        if isinstance(self.tools, list):
            self.tools = [t for t in self.tools if t is not mcp]

        # Best-effort clean shutdown of the MCP connection
        try:
            if hasattr(mcp, "shutdown"):
                mcp.shutdown()
        except Exception as e:
            logging.warning(f"MCP server '{name}' shutdown failed: {e}")

        self.refresh_tools()
        logging.debug(f"Removed MCP server '{name}'")
        return True

    def refresh_tools(self) -> List[Any]:
        """
        Re-derive the live toolset from ``self.tools``.

        Per-turn tool assembly already reads from ``self.tools`` directly, so
        tools added/removed via ``add_mcp_server``/``remove_mcp_server`` are
        picked up automatically on the next turn. This method clears any cached
        tool definitions so callers (or an MCP ``tools/list_changed`` event) can
        force an immediate refresh, and returns the current toolset.

        Returns:
            The current list of tools/MCP instances on the agent.
        """
        # Invalidate any cached tool definitions if such a cache exists
        for cache_attr in ("_cached_tool_definitions", "_tool_definitions_cache"):
            if hasattr(self, cache_attr):
                try:
                    setattr(self, cache_attr, None)
                except Exception:
                    pass
        return self.tools

    def list_mcp_servers(self) -> List[str]:
        """Return the names of MCP servers currently attached at runtime."""
        return list(getattr(self, "_mcp_servers", {}).keys())

    def _shutdown_runtime_mcp_servers(self) -> None:
        """Shut down all runtime-attached MCP servers, guarding each individually.

        Used by both ``close()`` and ``aclose()`` so a single failing
        ``shutdown()`` never aborts cleanup of the remaining servers. The
        registry is always cleared afterwards.
        """
        servers = getattr(self, "_mcp_servers", None)
        if not servers:
            return
        for name, server in list(servers.items()):
            try:
                if hasattr(server, "shutdown"):
                    server.shutdown()
            except Exception as e:
                logger.warning(f"Runtime MCP server '{name}' cleanup failed: {e}")
        servers.clear()

    def _cleanup_circuit_breakers(self) -> None:
        """Remove this agent's instance-scoped tool circuit breakers.

        Breakers are keyed on ``id(self)`` in a process-global registry. Since
        CPython may reuse an object id after this agent is collected, leaving the
        entries behind could let a future agent inherit a stale OPEN breaker.
        Removing them on close keeps the registry bounded and correct.
        """
        try:
            from ..tools.circuit_breaker import _get_global_registry
        except Exception:
            return
        try:
            registry = _get_global_registry()
            prefix = f"tool_{id(self)}_"
            for name in registry.list_services():
                if name.startswith(prefix):
                    registry.remove(name)
        except Exception as e:
            logger.warning(f"Circuit breaker cleanup failed: {e}")

    def _model_supports_web_search(self) -> bool:
        """
        Check if the agent's model supports native web search via LiteLLM.
        
        Returns:
            bool: True if the model supports native web search, False otherwise
        """
        from ..llm.model_capabilities import supports_web_search
        
        # Get the model name
        if hasattr(self, 'llm_instance') and self.llm_instance:
            model_name = self.llm_instance.model
        elif hasattr(self, 'llm') and self.llm:
            model_name = self.llm
        else:
            model_name = "gpt-4o-mini"
        
        return supports_web_search(model_name)
    
    def _model_supports_web_fetch(self) -> bool:
        """
        Check if the agent's model supports web fetch via LiteLLM.
        
        Web fetch allows the model to retrieve full content from specific URLs.
        Currently only supported by Anthropic Claude models.
        
        Returns:
            bool: True if the model supports web fetch, False otherwise
        """
        from ..llm.model_capabilities import supports_web_fetch
        
        # Get the model name
        if hasattr(self, 'llm_instance') and self.llm_instance:
            model_name = self.llm_instance.model
        elif hasattr(self, 'llm') and self.llm:
            model_name = self.llm
        else:
            model_name = "gpt-4o-mini"
        
        return supports_web_fetch(model_name)
    
    def _model_supports_prompt_caching(self) -> bool:
        """
        Check if the agent's model supports prompt caching via LiteLLM.
        
        Prompt caching allows caching parts of prompts to reduce costs and latency.
        Supported by OpenAI, Anthropic, Bedrock, and Deepseek.
        
        Returns:
            bool: True if the model supports prompt caching, False otherwise
        """
        from ..llm.model_capabilities import supports_prompt_caching
        
        # Get the model name
        if hasattr(self, 'llm_instance') and self.llm_instance:
            model_name = self.llm_instance.model
        elif hasattr(self, 'llm') and self.llm:
            model_name = self.llm
        else:
            model_name = "gpt-4o-mini"
        
        return supports_prompt_caching(model_name)
    
    @property
    def rules_manager(self) -> Optional[Any]:
        """
        Lazy-initialized RulesManager for persistent rules/instructions.
        
        This property initializes the RulesManager only when first accessed,
        avoiding expensive filesystem operations during agent instantiation.
        
        Returns:
            RulesManager instance or None if not available
        """
        if not self._rules_manager_initialized:
            self._init_rules_manager()
        return self._rules_manager
    
    def _init_rules_manager(self):
        """
        Initialize RulesManager for persistent rules/instructions.
        
        Automatically discovers rules from:
        - ~/.praisonai/rules/ (global)
        - .praisonai/rules/ (workspace)
        - Subdirectory rules
        
        NOTE: This is called lazily via the rules_manager property for performance.
        """
        self._rules_manager_initialized = True
        try:
            from ..memory.rules_manager import RulesManager
            import os
            
            # Get workspace path (config override or current working directory)
            config = self._rules_config
            workspace_path = getattr(config, "workspace_path", None) or os.getcwd()
            
            self._rules_manager = RulesManager(
                workspace_path=workspace_path,
                verbose=1 if self.verbose else 0
            )
            
            # Register any extra instruction files/globs from RulesConfig.files
            # before the discovery gate so a workspace whose only rules are
            # explicit files is not dropped.
            extra_files = getattr(config, "files", None) or []
            for extra in extra_files:
                self._rules_manager.add_rule_file(extra)
            
            # Discovery gate: if no rules were found, drop the manager so that
            # zero-config runs incur no per-run injection cost.
            stats = self._rules_manager.get_stats()
            if stats["total_rules"] > 0:
                logging.debug(f"RulesManager: Discovered {stats['total_rules']} rules")
            else:
                self._rules_manager = None
        except ImportError:
            logging.debug("RulesManager not available")
            self._rules_manager = None
        except Exception as e:
            logging.debug(f"Could not initialize RulesManager: {e}")
            self._rules_manager = None
    
    def get_rules_context(self, file_path: Optional[str] = None, include_manual: Optional[List[str]] = None) -> str:
        """
        Get rules context for the current conversation.
        
        Args:
            file_path: Optional file path for glob-based rule matching
            include_manual: Optional list of manual rule names to include (via @mention)
            
        Returns:
            Formatted rules context string
        """
        if not self.rules_manager:
            return ""
        
        # Honour char budget from RulesConfig if provided
        char_budget = getattr(self._rules_config, "char_budget", None)
        kwargs = {"file_path": file_path, "include_manual": include_manual}
        if char_budget is not None:
            kwargs["max_chars"] = char_budget
        return self.rules_manager.build_rules_context(**kwargs)
    
    def _init_memory(self, memory, user_id: Optional[str] = None):
        """
        Initialize memory based on the memory parameter.
        
        Args:
            memory: Can be:
                - True: Use FileMemory with default settings
                - False/None: No memory
                - "file": Use FileMemory
                - "sqlite": Use existing Memory class with SQLite
                - dict: Configuration for memory
                - Memory/FileMemory instance: Use directly
            user_id: User identifier for memory isolation
        """
        self.memory = memory
        
        if memory is None or memory is False:
            self._memory_instance = None
            return
        
        # Determine user_id. A shared constant default (e.g. "praison") would
        # silently merge different sessions'/users' private memory onto the same
        # on-disk path. When memory is enabled and no explicit user_id was given,
        # fall back to a per-instance, non-shared id so agents are isolated by
        # default. Pass user_id=... explicitly to persist/share memory across runs.
        mem_user_id = user_id
        if not mem_user_id:
            import uuid
            mem_user_id = f"agent-{uuid.uuid4().hex[:12]}"
            logging.warning(
                "Agent memory enabled without an explicit user_id; using an "
                "auto-generated, non-shared id (%s). Pass user_id=... explicitly "
                "to persist/share memory across runs.", mem_user_id,
            )
        
        from ..memory.adapters.registry import resolve_memory_adapter_name as _resolve_memory_adapter_name

        if memory is True or memory == "file":
            # Use FileMemory (zero dependencies)
            from ..memory.file_memory import FileMemory
            self._memory_instance = FileMemory(
                user_id=mem_user_id,
                verbose=1 if getattr(self, 'verbose', False) else 0
            )
        elif isinstance(memory, str) and _resolve_memory_adapter_name(memory):
            # Full Memory class, backend name passed through untouched.
            # Rewriting "sqlite" -> "rag" here made memory="sqlite" build a
            # ChromaDB store while Memory({"provider": "sqlite"}) built a real
            # SQLite one. The accepted set now comes from the registry, so
            # register_memory_adapter() backends are reachable from here.
            try:
                from ..memory.memory import Memory
                config = {"provider": _resolve_memory_adapter_name(memory)}
                # Scope the store to this agent's isolation id (same id the
                # FileMemory branches use) so two agents in one process/dir do
                # not silently share one on-disk store when no user_id is given.
                config.setdefault("user_id", mem_user_id)
                config.setdefault("collection_name", f"memory_{mem_user_id}")
                self._memory_instance = Memory(config)
            except ImportError:
                logging.warning(f"Memory provider '{memory}' requires additional dependencies. Falling back to FileMemory.")
                from ..memory.file_memory import FileMemory
                self._memory_instance = FileMemory(user_id=mem_user_id)
            except Exception as e:
                # The backend package is installed but could not initialise
                # (e.g. a SaaS backend like mem0 needs credentials/network).
                # Honour the same "Falling back to FileMemory" contract used for
                # missing dependencies so construction never hard-crashes.
                logging.warning(f"Memory provider '{memory}' could not initialise ({e}). Falling back to FileMemory.")
                from ..memory.file_memory import FileMemory
                self._memory_instance = FileMemory(user_id=mem_user_id)
        elif isinstance(memory, dict):
            # Configuration dict
            provider = memory.get("provider", memory.get("backend", "file"))
            learn_enabled = memory.get("learn", False)
            
            # Build a scoped config so an explicit user_id in the dict wins but a
            # missing one falls back to this agent's isolation id (matching the
            # FileMemory branches) instead of a process-wide shared store.
            scoped_memory = dict(memory)
            scoped_memory.setdefault("user_id", mem_user_id)
            scoped_memory.setdefault("collection_name", f"memory_{scoped_memory['user_id']}")

            # Use full Memory class if learn is enabled (requires LearnManager)
            if learn_enabled:
                try:
                    from ..memory.memory import Memory
                    self._memory_instance = Memory(scoped_memory)
                except ImportError:
                    logging.warning("Memory with learn requires additional dependencies. Falling back to FileMemory (learn disabled).")
                    from ..memory.file_memory import FileMemory
                    self._memory_instance = FileMemory(user_id=memory.get("user_id", mem_user_id))
            elif provider == "file":
                from ..memory.file_memory import FileMemory
                self._memory_instance = FileMemory(
                    user_id=memory.get("user_id", mem_user_id),
                    config=memory
                )
            else:
                try:
                    from ..memory.memory import Memory
                    self._memory_instance = Memory(scoped_memory)
                except ImportError:
                    logging.warning("Full Memory class requires additional dependencies. Falling back to FileMemory.")
                    from ..memory.file_memory import FileMemory
                    self._memory_instance = FileMemory(user_id=mem_user_id)
        elif isinstance(memory, str):
            # Unknown string backend - fall back to FileMemory with warning
            logging.warning(f"Unknown memory backend '{memory}'. Falling back to FileMemory.")
            from ..memory.file_memory import FileMemory
            self._memory_instance = FileMemory(user_id=mem_user_id)
        else:
            # Assume it's already a memory instance
            self._memory_instance = memory
    
    def get_memory_context(self, query: Optional[str] = None) -> str:
        """
        Get memory context for the current conversation.
        
        Args:
            query: Optional query to focus the context
            
        Returns:
            Formatted memory context string
        """
        if not self._memory_instance:
            return ""
        
        if hasattr(self._memory_instance, 'get_context'):
            return self._memory_instance.get_context(query=query)
        
        return ""
    
    def get_learn_context(self) -> str:
        """
        Get learning context for injection into system prompt.
        
        Returns learned preferences, insights, and patterns when memory="learn"
        is enabled. Returns empty string when learn is not enabled (zero overhead).
        
        Returns:
            Formatted learning context string, or empty string if learn not enabled
        """
        if not self._memory_instance:
            return ""
        
        if hasattr(self._memory_instance, 'get_learn_context'):
            return self._memory_instance.get_learn_context()
        
        return ""
    
    def store_memory(self, content: str, memory_type: str = "short_term", action: str = "add", **kwargs: Any) -> None:
        """
        Store content in memory.
        
        Args:
            content: Content to store
            memory_type: Type of memory (short_term, long_term, entity, episodic)
            action: Type of operation ("add", "replace", "remove")
            **kwargs: Additional arguments for the memory method
        """
        if not self._memory_instance:
            return
        
        # Validate memory_type
        supported_types = ["short_term", "long_term", "entity", "episodic"]
        if memory_type not in supported_types:
            raise ValueError(f"Unsupported memory_type '{memory_type}'. Supported: {supported_types}")
        
        # Perform the actual storage operation first
        storage_success = False
        try:
            if action == "add":
                # Use protocol names first (store_*), fallback to legacy names (add_*)
                if memory_type == "short_term":
                    if hasattr(self._memory_instance, 'store_short_term'):
                        self._memory_instance.store_short_term(content, **kwargs)
                        storage_success = True
                    elif hasattr(self._memory_instance, 'add_short_term'):
                        self._memory_instance.add_short_term(content, **kwargs)
                        storage_success = True
                elif memory_type == "long_term":
                    if hasattr(self._memory_instance, 'store_long_term'):
                        self._memory_instance.store_long_term(content, **kwargs)
                        storage_success = True
                    elif hasattr(self._memory_instance, 'add_long_term'):
                        self._memory_instance.add_long_term(content, **kwargs)
                        storage_success = True
                elif memory_type == "entity" and hasattr(self._memory_instance, 'add_entity'):
                    self._memory_instance.add_entity(content, **kwargs)
                    storage_success = True
                elif memory_type == "episodic" and hasattr(self._memory_instance, 'add_episodic'):
                    self._memory_instance.add_episodic(content, **kwargs)
                    storage_success = True
            elif action == "replace":
                # For replace operations - look for replace_ or update_ methods
                method_name = f"replace_{memory_type}" if hasattr(self._memory_instance, f'replace_{memory_type}') else f"update_{memory_type}"
                if hasattr(self._memory_instance, method_name):
                    getattr(self._memory_instance, method_name)(content, **kwargs)
                    storage_success = True
                else:
                    raise ValueError(f"Memory provider does not support 'replace' for {memory_type}")
            elif action == "remove":
                # For remove operations - look for remove_ or delete_ methods  
                method_name = f"remove_{memory_type}" if hasattr(self._memory_instance, f'remove_{memory_type}') else f"delete_{memory_type}"
                if hasattr(self._memory_instance, method_name):
                    getattr(self._memory_instance, method_name)(content, **kwargs)
                    storage_success = True
                else:
                    raise ValueError(f"Memory provider does not support 'remove' for {memory_type}")
            else:
                raise ValueError(f"Unsupported action '{action}'. Supported: add, replace, remove")
                
            if not storage_success:
                raise ValueError(f"Memory provider does not support {memory_type} storage")
                
        except Exception as e:
            logging.warning(f"[{self.name}] Memory storage failed: {e}")
            raise
        
        # Only call on_memory_write hook AFTER successful storage
        if storage_success:
            try:
                metadata = kwargs.get('metadata', None)
                # Try async version first if in async context, fallback to sync
                import asyncio
                try:
                    loop = asyncio.get_running_loop()
                    # In async context - prefer async hook if available
                    if hasattr(self._memory_instance, 'aon_memory_write'):
                        # Schedule async hook without blocking (fire and forget)
                        asyncio.create_task(self._memory_instance.aon_memory_write(action, memory_type, content, metadata))
                    elif hasattr(self._memory_instance, 'on_memory_write'):
                        self._memory_instance.on_memory_write(action, memory_type, content, metadata)
                except RuntimeError:
                    # Not in async context - use sync hook
                    if hasattr(self._memory_instance, 'on_memory_write'):
                        self._memory_instance.on_memory_write(action, memory_type, content, metadata)
            except Exception as e:
                logging.warning(f"[{self.name}] Memory on_memory_write hook failed: {e}")
    
    def _display_memory_info(self):
        """Display memory information to user in a friendly format."""
        if not self._memory_instance:
            return
        
        # Only display once per chat session
        if hasattr(self, '_memory_displayed') and self._memory_displayed:
            return
        self._memory_displayed = True
        
        stats = self._memory_instance.get_stats()
        short_count = stats.get('short_term_count', 0)
        long_count = stats.get('long_term_count', 0)
        entity_count = stats.get('entity_count', 0)
        storage_path = stats.get('storage_path', '')
        
        total_memories = short_count + long_count + entity_count
        
        if total_memories > 0:
            from rich.panel import Panel
            from rich.text import Text
            
            # Build memory info text
            info_parts = []
            if long_count > 0:
                info_parts.append(f"💾 {long_count} long-term")
            if short_count > 0:
                info_parts.append(f"⚡ {short_count} short-term")
            if entity_count > 0:
                info_parts.append(f"👤 {entity_count} entities")
            
            memory_text = Text()
            memory_text.append("🧠 Memory loaded: ", style="bold cyan")
            memory_text.append(" | ".join(info_parts))
            memory_text.append(f"\n📁 Storage: {storage_path}", style="dim")
            
            self.console.print(Panel(
                memory_text,
                title="[bold]Agent Memory[/bold]",
                border_style="cyan",
                expand=False
            ))
    
    @property
    def llm_model(self) -> Optional[str]:
        """Unified property to get the LLM model regardless of configuration type.
        
        Returns:
            The LLM model/instance being used by this agent.
            - For standard models: returns the model string (e.g., "gpt-4o-mini")
            - For custom LLM instances: returns the LLM instance object
            - For provider models: returns the LLM instance object
        """
        if hasattr(self, 'llm_instance') and self.llm_instance:
            return self.llm_instance
        elif hasattr(self, 'llm') and self.llm:
            return self.llm
        else:
            # Default fallback
            return "gpt-4o-mini"

    def _ensure_knowledge_processed(self):
        """Ensure knowledge is initialized and processed when first accessed."""
        if not self._knowledge_processed and self._knowledge_sources:
            # Initialize Knowledge with config from retrieval_config
            from praisonaiagents.knowledge import Knowledge
            
            knowledge_config = None
            if self._retrieval_config is not None:
                knowledge_config = self._retrieval_config.to_knowledge_config()
            
            self.knowledge = Knowledge(knowledge_config)
            
            # Process all knowledge sources
            for source in self._knowledge_sources:
                self._process_knowledge(source)
            
            self._knowledge_processed = True
    
    @property
    def retrieval_config(self) -> Optional[Any]:
        """Get the unified retrieval configuration."""
        return self._retrieval_config
    
    @property
    def rag(self) -> Optional[Any]:
        """
        Lazy-loaded RAG instance for advanced retrieval with citations.
        
        Returns RAG instance configured with agent's knowledge and retrieval_config.
        Returns None if no knowledge is configured.
        
        Usage:
            agent = Agent(knowledge=["doc.pdf"], retrieval_config={"citations": True})
            result = agent.rag.query("What is the main finding?")
            print(result.answer)
            for citation in result.citations:
                print(f"[{citation.id}] {citation.source}")
        """
        # Check if we have knowledge (either sources or direct instance)
        if not self._knowledge_sources and self.knowledge is None:
            return None
        
        if self._rag_instance is None:
            self._ensure_knowledge_processed()
            if self.knowledge:
                try:
                    from praisonaiagents.rag import RAG, RAGConfig
                    
                    # Build RAGConfig from unified retrieval_config
                    rag_config_obj = RAGConfig()
                    if self._retrieval_config is not None:
                        rag_dict = self._retrieval_config.to_rag_config()
                        for key, value in rag_dict.items():
                            if hasattr(rag_config_obj, key):
                                setattr(rag_config_obj, key, value)
                    
                    # Get LLM instance for RAG
                    llm = None
                    if hasattr(self, 'llm_instance') and self.llm_instance:
                        llm = self.llm_instance
                    
                    self._rag_instance = RAG(
                        knowledge=self.knowledge,
                        config=rag_config_obj,
                        llm=llm,
                    )
                except ImportError:
                    logging.warning("RAG module not available. Install with: pip install 'praisonaiagents[rag]'")
                    return None
        
        return self._rag_instance
    
    def _get_knowledge_context(self, query: str, use_rag: bool = False) -> tuple:
        """
        Get knowledge context for a query using unified retrieval pipeline.
        
        Args:
            query: The user's question/prompt
            use_rag: If True, use RAG pipeline for token-aware context building
            
        Returns:
            Tuple of (context_string, citations_list or None)
        """
        # Check if we have knowledge (sources or direct instance)
        if not self._knowledge_sources and self.knowledge is None:
            return "", None
        
        self._ensure_knowledge_processed()
        
        if not self.knowledge:
            return "", None
        
        # Use RAG pipeline for token-aware context building (DRY - single path)
        if use_rag and self.rag:
            try:
                context_pack = self.rag.retrieve(query, user_id=self.user_id, agent_id=self.agent_id)
                return context_pack.context, context_pack.citations
            except Exception as e:
                logging.warning(f"RAG retrieve failed, falling back to basic retrieval: {e}")
        
        # Fallback: basic retrieval with token-aware formatting
        try:
            from praisonaiagents.rag.context import build_context
            
            search_results = self.knowledge.search(query, agent_id=self.agent_id)
            if not search_results:
                return "", None
            
            # Normalize results format (filter out None values, handle None metadata)
            # Normalize results format (filter out None values, handle None metadata)
            if hasattr(search_results, "results") and isinstance(getattr(search_results, "results"), list):
                search_results = getattr(search_results, "results")
            elif isinstance(search_results, dict) and 'results' in search_results:
                search_results = search_results['results']
                
            if isinstance(search_results, list):
                results = []
                for r in search_results:
                    if r is None:
                        continue
                    if isinstance(r, dict):
                        text = r.get('memory', '') or r.get('text', '') or ''
                        metadata = r.get('metadata') or {}
                    else:
                        text = getattr(r, 'text', None) or getattr(r, 'memory', None) or ''
                        metadata = getattr(r, 'metadata', None)
                        if metadata is None:
                            metadata = {}
                    
                    if text:
                        results.append({"text": str(text), "metadata": metadata})
            else:
                results = [{"text": str(search_results), "metadata": {}}] if search_results else []
            
            # Use token-aware context building (same as RAG pipeline)
            max_tokens = 4000
            if self._retrieval_config:
                max_tokens = self._retrieval_config.max_context_tokens
            
            context, _ = build_context(results, max_tokens=max_tokens)
            return context, None
            
        except ImportError:
            # Fallback to simple concatenation if RAG context module not available
            search_results = self.knowledge.search(query, agent_id=self.agent_id)
            if not search_results:
                return "", None
            
            if isinstance(search_results, dict) and 'results' in search_results:
                # CRITICAL: Handle None results and get 'memory' field safely
                parts = []
                for result in search_results['results']:
                    if result is not None:
                        memory = result.get('memory', '') or ''
                        if memory:
                            parts.append(memory)
                knowledge_content = "\n".join(parts)
            else:
                knowledge_content = "\n".join(search_results) if isinstance(search_results, list) else str(search_results)
            
            return knowledge_content, None
    
    def retrieve(self, query: str, **kwargs) -> "ContextPack":
        """
        Retrieve context from knowledge without LLM generation.
        
        Returns a ContextPack that can be passed to chat_with_context().
        This enables conditional retrieval - only retrieve when needed.
        
        Args:
            query: Search query
            **kwargs: Additional arguments (top_k, rerank, etc.)
            
        Returns:
            ContextPack with context string and citations (no LLM call)
            
        Raises:
            ValueError: If no knowledge is configured
            ImportError: If RAG module is not available
            
        Usage:
            agent = Agent(knowledge=["docs/"], retrieval_config={"citations": True})
            context = agent.retrieve("What are the key findings?")
            print(f"Found {len(context.citations)} sources")
            response = agent.chat_with_context("Summarize", context)
        """
        if not self._knowledge_sources and self.knowledge is None:
            raise ValueError("No knowledge configured. Add knowledge=[] to Agent init.")
        
        if not self.rag:
            raise ImportError("RAG module not available. Install with: pip install 'praisonaiagents[rag]'")
        
        kwargs.setdefault('user_id', self.user_id)
        kwargs.setdefault('agent_id', self.agent_id)
        
        return self.rag.retrieve(query, **kwargs)
    
    def query(self, question: str, **kwargs) -> "RAGResult":
        """
        Query knowledge and get a structured answer with citations.
        
        This is the recommended method for getting answers with source citations.
        Returns a structured result with answer, citations, context used, and metadata.
        
        Args:
            question: The question to answer
            **kwargs: Additional arguments (top_k, rerank, etc.)
            
        Returns:
            RAGResult with answer, citations, context_used, and metadata
            
        Raises:
            ValueError: If no knowledge is configured
            ImportError: If RAG module is not available
            
        Usage:
            agent = Agent(knowledge=["doc.pdf"], retrieval_config={"citations": True})
            result = agent.query("What is the main finding?")
            print(result.answer)
            for citation in result.citations:
                print(f"  [{citation.id}] {citation.source}")
        """
        if not self._knowledge_sources and self.knowledge is None:
            raise ValueError("No knowledge configured. Add knowledge=[] to Agent init.")
        
        if not self.rag:
            raise ImportError("RAG module not available. Install with: pip install 'praisonaiagents[rag]'")
        
        kwargs.setdefault('user_id', self.user_id)
        kwargs.setdefault('agent_id', self.agent_id)
        
        return self.rag.query(question, **kwargs)
    
    def rag_query(self, question: str, **kwargs) -> "RAGResult":
        """
        Query knowledge using RAG pipeline with citations.
        
        This is the recommended way to get answers with citations from an agent's knowledge.
        
        Args:
            question: The question to answer
            **kwargs: Additional arguments passed to RAG.query()
            
        Returns:
            RAGResult with answer, citations, context_used, and metadata
            
        Raises:
            ValueError: If no knowledge sources are configured
            ImportError: If RAG module is not available
            
        Usage:
            agent = Agent(knowledge=["doc.pdf"], rag_config={"include_citations": True})
            result = agent.rag_query("What is the main finding?")
            print(result.answer)
            for citation in result.citations:
                print(f"[{citation.id}] {citation.source}: {citation.text[:100]}")
        """
        if not self._knowledge_sources:
            raise ValueError("No knowledge sources configured. Add knowledge=[] to Agent init.")
        
        if not self.rag:
            raise ImportError("RAG module not available. Install with: pip install 'praisonaiagents[rag]'")
        
        # Pass agent context
        kwargs.setdefault('user_id', self.user_id)
        kwargs.setdefault('agent_id', self.agent_id)
        
        return self.rag.query(question, **kwargs)
    
    def chat_with_context(
        self,
        message: str,
        context: "ContextPack",
        *,
        citations_mode: str = "append",
        **kwargs,
    ) -> str:
        """
        Chat with pre-retrieved context.
        
        This method allows AutoRagAgent or manual workflows to inject 
        pre-retrieved context into the agent's chat, enabling conditional 
        retrieval without duplicating RAG logic.
        
        Args:
            message: User message/question
            context: ContextPack from RAG.retrieve()
            citations_mode: How to include citations (append/hidden/none)
            **kwargs: Additional arguments passed to chat()
            
        Returns:
            Agent response with optional citations
            
        Usage:
            from praisonaiagents import AutoRagAgent
            
            auto_rag = AutoRagAgent(agent=my_agent)
            result = auto_rag.chat("What are the key findings?")
            
            # Or manually:
            context_pack = rag.retrieve("What are the key findings?")
            response = agent.chat_with_context("What are the key findings?", context_pack)
        """
        # Build augmented prompt with context
        augmented_prompt = f"""Based on the following context, answer the question.

Context:
{context.context}

Question: {message}

Answer:"""
        
        # Call chat with augmented prompt
        response = self.chat(augmented_prompt, **kwargs)
        
        # Add citations if configured
        if citations_mode == "append" and context.has_citations:
            sources = "\n\nSources:\n"
            for citation in context.citations:
                sources += f"  [{citation.id}] {citation.source}\n"
            response = response + sources
        
        return response
    
    def _process_knowledge(self, knowledge_item):
        """Process and store knowledge from a file path, URL, or string."""
        try:
            if os.path.exists(knowledge_item):
                # It's a file path
                self.knowledge.add(knowledge_item, user_id=self.user_id, agent_id=self.agent_id)
            elif knowledge_item.startswith("http://") or knowledge_item.startswith("https://"):
                # It's a URL. URL knowledge ingestion is not yet implemented in the
                # core SDK, so warn instead of silently dropping the source. Log only
                # the scheme+host to avoid leaking any credentials or signed tokens
                # embedded in the userinfo or query string.
                from urllib.parse import urlsplit
                _parts = urlsplit(knowledge_item)
                _safe_url = f"{_parts.scheme}://{_parts.hostname or ''}"
                logging.warning(
                    f"Knowledge source '{_safe_url}...' is a URL; URL knowledge "
                    "ingestion is not yet implemented in the core SDK. This source "
                    "will be skipped. Fetch and pass the content as text, or a local "
                    "file path, instead."
                )
            else:
                # It's a string content
                self.knowledge.store(knowledge_item, user_id=self.user_id, agent_id=self.agent_id)
        except Exception as e:
            logging.error(f"Error processing knowledge item: {knowledge_item}, error: {e}")

    @staticmethod
    def _is_interactive_session() -> bool:
        """Return True when running attached to an interactive terminal.

        Used to decide whether dangerous built-in tools should be routed
        through an interactive approval prompt (safe-by-default ``ask``) or
        hard-denied (non-interactive deny-by-default). A session counts as
        interactive only when both stdin and stdout are TTYs, so pipes, CI
        runners and redirected I/O fall back to the deny-by-default policy.
        """
        try:
            import sys
            return bool(sys.stdin.isatty() and sys.stdout.isatty())
        except Exception:
            return False

    @staticmethod
    def _resolve_default_deny_set() -> frozenset:
        """Return the env-driven default permission deny set.

        Mirrors the ``approval is None`` path: honour ``PRAISONAI_TOOL_SAFETY``
        (``off``/``full``/``none``/``0``/``false`` → no denials), otherwise use
        the named preset (defaulting to ``"default"``, which blocks destructive
        ops like ``execute_command``/``delete_file``/``kill_process``/
        ``execute_code``). An unknown env value falls back to ``"default"``.

        Shared by the ``ApprovalConfig``/``dict`` branches so configuring
        approval never silently drops the default denials — passing a config
        object must not be a weaker posture than passing nothing.
        """
        _raw_safety_env = os.environ.get("PRAISONAI_TOOL_SAFETY")
        _safety_env = (_raw_safety_env or "").strip().lower()
        if _safety_env in ("off", "full", "none", "0", "false"):
            return frozenset()
        from ..approval.registry import PERMISSION_PRESETS
        _resolved = _safety_env or "default"
        _preset = PERMISSION_PRESETS.get(_resolved)
        if _preset is None:
            _preset = PERMISSION_PRESETS.get("default")
        return _preset if _preset is not None else frozenset()

    def _setup_guardrail(self):
        """Setup the guardrail function based on the provided guardrail parameter."""
        # ``tool_execution._check_tool_policy_and_guardrails`` reads
        # ``self._tool_call_guardrails`` but nothing ever assigned it, so the
        # whole ``validate_tool_call`` surface was dead code. Always define it.
        self._tool_call_guardrails = []
        if self.guardrail is None:
            self._guardrail_fn = None
            return
            
        if callable(self.guardrail):
            # Validate function signature
            sig = inspect.signature(self.guardrail)
            positional_args = [
                param for param in sig.parameters.values()
                if param.default is inspect.Parameter.empty
            ]
            if len(positional_args) != 1:
                raise ValueError("Agent guardrail function must accept exactly one parameter (TaskOutput)")
            
            # Check return annotation if present
            from typing import get_args, get_origin
            return_annotation = sig.return_annotation
            if return_annotation != inspect.Signature.empty:
                return_annotation_args = get_args(return_annotation)
                if not (
                    get_origin(return_annotation) is tuple
                    and len(return_annotation_args) == 2
                    and return_annotation_args[0] is bool
                    and (
                        return_annotation_args[1] is Any
                        or return_annotation_args[1] is str
                        or str(return_annotation_args[1]).endswith('TaskOutput')
                        or str(return_annotation_args[1]).startswith('typing.Union')
                    )
                ):
                    raise ValueError(
                        "If return type is annotated, it must be Tuple[bool, Any] or Tuple[bool, Union[str, TaskOutput]]"
                    )
            
            self._guardrail_fn = self.guardrail
        elif isinstance(self.guardrail, str):
            # Create LLM-based guardrail
            from ..guardrails import LLMGuardrail
            # Prefer the configured LLM instance (with api_key/base_url/client
            # overrides) over the bare model-name string in self.llm.
            llm = getattr(self, 'llm_instance', None) or getattr(self, 'llm', None)
            # Guardrail validation is an internal, non-user-facing LLM call.
            # When it would fall back to the bare primary model-name string
            # (no explicit LLM instance), route through the auxiliary
            # ``small_model`` (unset -> primary model, i.e. unchanged behaviour).
            if isinstance(llm, str):
                try:
                    from ..config.loader import get_small_model
                    llm = get_small_model(primary_model=llm, fallback=llm) or llm
                except Exception:
                    pass
            self._guardrail_fn = LLMGuardrail(description=self.guardrail, llm=llm)
            # A string guardrail is an output-quality validator. Although the
            # resulting LLMGuardrail also exposes ``validate_input`` (via
            # GuardrailProtocol), it must NOT be invoked as an input gate here:
            # doing so would fire an extra, synchronous LLM call on every
            # chat()/achat() (a hot-path regression, and blocking on the async
            # event loop). Mark it so input validation skips it. Explicit
            # GuardrailChain/GuardrailProtocol objects (passed as callables)
            # remain the only deliberate input surface.
            self._guardrail_fn._praison_output_only = True
        else:
            raise ValueError("Agent guardrail must be either a callable or a string description")

        # Register the tool-call surface when the guardrail actually exposes one.
        # Output-only (string/LLM) guardrails are excluded on purpose: running an
        # LLM validation before every tool call would be a hot-path regression,
        # the same reasoning that keeps them out of the input gate above.
        _fn = self._guardrail_fn
        if (
            _fn is not None
            and callable(getattr(_fn, "validate_tool_call", None))
            and not getattr(_fn, "_praison_output_only", False)
        ):
            self._tool_call_guardrails = [_fn]

    def _process_handoffs(self):
        """Process handoffs and convert them to tools that can be used by the agent."""
        # Import here to avoid circular imports
        from .handoff import Handoff

        # as_tool() returns a Handoff, and its own docstring passes the result in
        # tools=[...]. tools= stores objects verbatim, so an unconverted Handoff
        # is invisible to both the LLM tool schema and execute_tool(). Convert in
        # place here -- the first point where the parent agent that
        # to_tool_function() needs actually exists.
        if isinstance(self.tools, list):
            for index, tool_item in enumerate(self.tools):
                if isinstance(tool_item, Handoff):
                    try:
                        tool_func = tool_item.to_tool_function(self)
                        # Retain the source Handoff so clone_for_channel() can
                        # rebind it to the clone. The generated closure captures
                        # THIS agent (its chat_history/tools/memory); a shallow
                        # clone that copied the closure verbatim would delegate
                        # using the original agent's state, leaking one channel's
                        # context into another.
                        tool_func._praison_handoff_source = tool_item
                        self.tools[index] = tool_func
                    except Exception as e:
                        logging.error(
                            f"Failed to convert as_tool()/handoff {tool_item} "
                            f"passed in tools=: {e}"
                        )

        if not self.handoffs:
            return

        for handoff_item in self.handoffs:
            try:
                if isinstance(handoff_item, Handoff):
                    # Convert Handoff object to a tool function
                    tool_func = handoff_item.to_tool_function(self)
                    self.tools.append(tool_func)
                elif hasattr(handoff_item, 'name') and hasattr(handoff_item, 'chat'):
                    # Direct agent reference - create a simple handoff
                    from .handoff import handoff
                    handoff_obj = handoff(handoff_item)
                    tool_func = handoff_obj.to_tool_function(self)
                    self.tools.append(tool_func)
                else:
                    logging.warning(
                        f"Invalid handoff item type: {type(handoff_item)}. "
                        "Expected Agent or Handoff instance."
                    )
            except Exception as e:
                logging.error(f"Failed to process handoff item {handoff_item}: {e}")

    def _process_guardrail(self, task_output):
        """Process the guardrail validation for a task output.
        
        Args:
            task_output: The task output to validate
            
        Returns:
            GuardrailResult: The result of the guardrail validation
        """
        from ..guardrails import GuardrailResult
        
        if not self._guardrail_fn:
            return GuardrailResult(success=True, result=task_output)
        
        try:
            # Call the guardrail function
            result = self._guardrail_fn(task_output)
            
            # Convert the result to a GuardrailResult
            return GuardrailResult.from_tuple(result)

        except Exception as e:
            logging.error(f"Agent {self.name}: Error in guardrail validation: {e}")
            # On error, return failure
            return GuardrailResult(
                success=False,
                result=None,
                error=f"Agent guardrail validation error: {str(e)}"
            )

    def _validate_input_with_guardrail(self, prompt):
        """Validate the incoming prompt with the guardrail's input surface.

        Only runs when the configured guardrail exposes a ``validate_input``
        method (e.g. a ``GuardrailChain`` or an object implementing
        ``GuardrailProtocol``). Plain callable guardrails and string (output-
        quality) guardrails have no deliberate input surface and are skipped,
        so behaviour is unchanged for them.

        Returns (success, result, error). Fails closed on error.
        """
        fn = getattr(self, "_guardrail_fn", None)
        if fn is None or not hasattr(fn, "validate_input"):
            return True, prompt, None
        # String guardrails are output-only validators; do not run them as an
        # input gate (would add a synchronous LLM call to every chat/achat).
        if getattr(fn, "_praison_output_only", False):
            return True, prompt, None
        try:
            is_valid, result = fn.validate_input(prompt, agent_name=self.name)
            if is_valid:
                return True, (result if isinstance(result, str) else prompt), None
            return False, None, (result if isinstance(result, str) else "Input blocked by guardrail")
        except Exception as e:
            logging.error(f"Agent {self.name}: Error in input guardrail validation: {e}")
            return False, None, f"Input guardrail validation error: {str(e)}"

    def _validate_with_guardrail(self, response_text):
        """Validate response with guardrail. Returns (success, result, error)."""
        if not self._guardrail_fn:
            return True, response_text, None
            
        from ..main import TaskOutput
        
        task_output = TaskOutput(
            description="Agent response output",
            raw=response_text,
            agent=self.name
        )
        
        guardrail_result = self._process_guardrail(task_output)
        
        if guardrail_result.success:
            # Return the potentially modified result
            if guardrail_result.result and hasattr(guardrail_result.result, 'raw'):
                return True, guardrail_result.result.raw, None
            elif guardrail_result.result:
                return True, str(guardrail_result.result), None
            else:
                return True, response_text, None
        else:
            return False, None, guardrail_result.error

    def _apply_guardrail_with_retry(self, response_text, prompt, temperature=1.0, tools=None, task_name=None, task_description=None, task_id=None, cancel_token=None):
        """Apply guardrail validation with retry logic (sync version)."""
        retry_count = 0
        current_response = response_text
        
        while retry_count <= self.max_guardrail_retries:
            success, result, error = self._validate_with_guardrail(current_response)
            
            if success:
                logging.info(f"Agent {self.name}: Guardrail validation passed")
                return result
            
            # Guardrail failed
            if retry_count >= self.max_guardrail_retries:
                raise Exception(
                    f"Agent {self.name} response failed guardrail validation after {self.max_guardrail_retries} retries. "
                    f"Last error: {error}"
                )
            
            retry_count += 1
            logging.warning(f"Agent {self.name}: Guardrail validation failed (retry {retry_count}/{self.max_guardrail_retries}): {error}")
            
            # Add exponential backoff delay to avoid hammering the LLM
            execution_config = getattr(self, '_execution_config', None)
            if execution_config is not None:
                total_delay = BackoffPolicy.delay(
                    retry_count,
                    execution_config.retry_initial_delay,
                    execution_config.retry_backoff_factor,
                    execution_config.retry_jitter
                )
            else:
                # Fall back to simple backoff if no execution config
                total_delay = 1.0 * (2.0 ** (retry_count - 1))
            
            logging.info(f"Agent {self.name}: Waiting {total_delay:.2f}s before guardrail retry")
            time.sleep(total_delay)
            
            # Regenerate response for retry
            try:
                retry_prompt = f"{prompt}\n\nNote: Previous response failed validation due to: {error}. Please provide an improved response."
                response = self._chat_completion([{"role": "user", "content": retry_prompt}], temperature, tools, task_name=task_name, task_description=task_description, task_id=task_id, cancel_token=cancel_token)
                if response and response.choices:
                    content = response.choices[0].message.content
                    current_response = content.strip() if content else ""
                else:
                    raise Exception("Failed to generate retry response")
            except Exception as e:
                logging.error(f"Agent {self.name}: Error during guardrail retry: {e}")
                raise Exception(f"Agent {self.name} guardrail retry failed: {e}")
        
        return current_response

    async def _aapply_guardrail_with_retry(self, response_text, prompt, temperature=1.0, tools=None, task_name=None, task_description=None, task_id=None):
        """Apply guardrail validation with retry logic (async version)."""
        retry_count = 0
        current_response = response_text
        
        while retry_count <= self.max_guardrail_retries:
            # A string/LLMGuardrail guardrail fires a *blocking* LLM call inside
            # _validate_with_guardrail. Offload it to a thread so it does not
            # stall the event loop (and every other concurrently-running task
            # under asyncio.gather), mirroring async_memory_mixin's
            # _run_memory_in_thread executor-offload pattern.
            loop = asyncio.get_event_loop()
            # Preserve contextvars (trace emission, session context) across the
            # executor thread so a custom guardrail sees the same contextual
            # state as the synchronous path, matching every other
            # run_in_executor call site in the SDK.
            from ..trace.context_events import copy_context_to_callable
            success, result, error = await loop.run_in_executor(
                None,
                copy_context_to_callable(
                    lambda: self._validate_with_guardrail(current_response)
                ),
            )
            
            if success:
                logging.info(f"Agent {self.name}: Guardrail validation passed")
                return result
            
            # Guardrail failed
            if retry_count >= self.max_guardrail_retries:
                raise Exception(
                    f"Agent {self.name} response failed guardrail validation after {self.max_guardrail_retries} retries. "
                    f"Last error: {error}"
                )
            
            retry_count += 1
            logging.warning(f"Agent {self.name}: Guardrail validation failed (retry {retry_count}/{self.max_guardrail_retries}): {error}")
            
            # Add exponential backoff delay to avoid hammering the LLM
            execution_config = getattr(self, '_execution_config', None)
            if execution_config is not None:
                total_delay = BackoffPolicy.delay(
                    retry_count,
                    execution_config.retry_initial_delay,
                    execution_config.retry_backoff_factor,
                    execution_config.retry_jitter
                )
            else:
                # Fall back to simple backoff if no execution config
                total_delay = 1.0 * (2.0 ** (retry_count - 1))
            
            logging.info(f"Agent {self.name}: Waiting {total_delay:.2f}s before guardrail retry")
            await asyncio.sleep(total_delay)
            
            # Regenerate response for retry (async version)
            try:
                retry_prompt = f"{prompt}\n\nNote: Previous response failed validation due to: {error}. Please provide an improved response."
                response = await self._execute_unified_achat_completion([{"role": "user", "content": retry_prompt}], temperature, tools, task_name=task_name, task_description=task_description, task_id=task_id)
                if response and hasattr(response, 'choices') and response.choices:
                    content = response.choices[0].message.content
                    current_response = content.strip() if content else ""
                elif isinstance(response, str):
                    current_response = response.strip()
                else:
                    raise Exception("Failed to generate retry response")
            except Exception as e:
                logging.error(f"Agent {self.name}: Error during guardrail retry: {e}")
                raise Exception(f"Agent {self.name} guardrail retry failed: {e}")
        
        return current_response
    
    def _get_tools_cache_key(self, tools):
        """Generate a cache key for tools list."""
        if tools is None:
            return "none"
        if not tools:
            return "empty"
        # Create a simple hash based on tool names
        tool_names = []
        for tool in tools:
            if callable(tool) and hasattr(tool, '__name__'):
                tool_names.append(tool.__name__)
            elif isinstance(tool, dict) and 'function' in tool and 'name' in tool['function']:
                tool_names.append(tool['function']['name'])
            elif isinstance(tool, str):
                tool_names.append(tool)
        return "|".join(sorted(tool_names))
    

    # -------------------------------------------------------------------------
    #                       History Management Methods
    # -------------------------------------------------------------------------
    
    
    # -------------------------------------------------------------------------
    #                       CLI Backend Management
    # -------------------------------------------------------------------------
    
    def _resolve_cli_backend(self, cli_backend):
        """Validate and return CLI backend protocol instance.
        
        Args:
            cli_backend: CliBackendProtocol instance or callable that returns one
            
        Returns:
            CliBackendProtocol instance
            
        Note:
            String backend IDs must be resolved to instances in the wrapper layer
            before passing to Agent. This maintains proper dependency direction
            per AGENTS.md (core SDK should not import from wrapper).
        """
        # Import protocols
        try:
            from ..cli_backend import CliBackendProtocol
        except ImportError:
            raise ImportError(
                "CLI backend features requested but protocols not available. "
                "This should not happen in a properly installed praisonaiagents package."
            )
        
        # If already a protocol instance, return as-is
        if hasattr(cli_backend, 'execute') and hasattr(cli_backend, 'stream'):
            return cli_backend
            
        # If callable (factory function), call it to get instance
        if callable(cli_backend):
            instance = cli_backend()
            if hasattr(instance, 'execute') and hasattr(instance, 'stream'):
                return instance
            raise TypeError(f"CLI backend factory returned invalid type: {type(instance)}. Expected CliBackendProtocol.")
        
        # String IDs are no longer supported at core level - must be resolved in wrapper
        if isinstance(cli_backend, str):
            raise TypeError(
                f"String CLI backend IDs ('{cli_backend}') must be resolved to instances "
                "in the wrapper layer. Use: praisonai.Agent(cli_backend='claude-code') "
                "or manually resolve: agent = praisonaiagents.Agent(cli_backend=resolve_cli_backend('claude-code'))"
            )
        
        raise TypeError(f"Invalid cli_backend type: {type(cli_backend)}. Expected CliBackendProtocol instance or factory callable.")
    
    def _resolve_runtime_config(self, runtime):
        """Resolve runtime parameter to AgentRuntimeConfig or RuntimeConfig instance.
        
        Args:
            runtime: Runtime configuration parameter
            
        Returns:
            AgentRuntimeConfig or RuntimeConfig instance
            
        Raises:
            TypeError: If runtime type is invalid
            ValueError: If runtime configuration is invalid
        """
        # Try to import AgentRuntimeConfig (from main's turn-based runtime)
        AgentRuntimeConfig = None
        try:
            from ..runtime import AgentRuntimeConfig
        except ImportError:
            pass
        
        # Try to import RuntimeConfig (from capability validation system)
        RuntimeConfig = None
        try:
            from ..config.feature_configs import RuntimeConfig, resolve_runtime
        except ImportError:
            pass
        
        if not AgentRuntimeConfig and not RuntimeConfig:
            raise ImportError(
                "Runtime configuration features requested but not available. "
                "This should not happen in a properly installed praisonaiagents package."
            )
        
        # If already an AgentRuntimeConfig instance, return as-is
        if AgentRuntimeConfig and isinstance(runtime, AgentRuntimeConfig):
            return runtime
        
        # If already a RuntimeConfig instance, normalise its runtime name so a
        # typo in preferred_runtime (e.g. "nativ") raises instead of silently
        # dropping capabilities. resolve_runtime returns a normalised copy.
        if RuntimeConfig and hasattr(RuntimeConfig, '__name__') and isinstance(runtime, RuntimeConfig):
            if resolve_runtime:
                return resolve_runtime(runtime)
            return runtime
        
        # Handle capability validation style (bool, RuntimeConfig)
        if RuntimeConfig and resolve_runtime:
            try:
                result = resolve_runtime(runtime)
                if result is not None:
                    return result
            except ValueError:
                # An invalid runtime *name* (e.g. a typo) must surface rather
                # than falling through and being stored verbatim, which would
                # silently drop most capabilities.
                raise
            except TypeError:
                pass  # Not this style; try AgentRuntimeConfig path
        
        # Handle turn-based style (AgentRuntimeConfig)
        if AgentRuntimeConfig:
            # If string, create config with runtime ID
            if isinstance(runtime, str):
                if hasattr(AgentRuntimeConfig, 'from_runtime_id'):
                    return AgentRuntimeConfig.from_runtime_id(runtime)
            
            # If dictionary, create config from dict
            if isinstance(runtime, dict):
                if hasattr(AgentRuntimeConfig, 'from_dict'):
                    return AgentRuntimeConfig.from_dict(runtime)
        
        raise TypeError(f"Invalid runtime type: {type(runtime)}. Expected bool, str, dict, RuntimeConfig, or AgentRuntimeConfig instance.")
    
    def _validate_runtime_capabilities(self):
        """Validate runtime capabilities against requirements.
        
        Raises:
            CapabilityValidationError: If runtime lacks required capabilities
        """
        if not self._runtime_config:
            return
        
        # Import capability validation components
        try:
            from ..runtime.capabilities import (
                RuntimeCapability,
                validate_capabilities,
                get_native_runtime_capabilities,
                get_reduced_harness_capabilities
            )
        except ImportError:
            # Capability validation not available, skip
            return
        
        # Get required capabilities from config
        required_capabilities = getattr(self._runtime_config, 'required_capabilities', None)
        if not required_capabilities:
            return
        
        # Convert string capabilities to enum
        required_set = set()
        for cap in required_capabilities:
            if isinstance(cap, str):
                try:
                    required_set.add(RuntimeCapability[cap.upper()])
                except KeyError:
                    raise ValueError(f"Unknown capability: {cap}")
            elif isinstance(cap, RuntimeCapability):
                required_set.add(cap)
            else:
                raise TypeError(f"Invalid capability type: {type(cap)}")
        
        # Determine runtime name. Normalise so spelling variants (NATIVE,
        # " native ", native) map to the same matrix instead of silently
        # dropping capabilities; an unknown name raises rather than degrading.
        raw_runtime = getattr(self._runtime_config, 'preferred_runtime', None) or 'native'
        from ..config.feature_configs import canonical_runtime_name
        runtime_name = canonical_runtime_name(raw_runtime)
        
        # Get runtime capabilities based on runtime type
        if runtime_name == 'native':
            runtime_matrix = get_native_runtime_capabilities()
        else:
            runtime_matrix = get_reduced_harness_capabilities()
        
        # Validate capabilities
        validate_capabilities(runtime_matrix, required_set, runtime_name)
    
    def _get_runtime_resolver(self):
        """Get or create runtime resolver instance (lazy initialization)."""
        if self._runtime_resolver is None:
            try:
                from ..runtime.resolver import RuntimeResolver
                self._runtime_resolver = RuntimeResolver()
            except ImportError:
                raise ImportError(
                    "Runtime resolution features requested but not available. "
                    "This should not happen in a properly installed praisonaiagents package."
                )
        return self._runtime_resolver
    
    async def _resolve_turn_runtime(self):
        """Resolve runtime for current turn based on model and configuration.
        
        Returns:
            Runtime instance if resolution succeeds, None otherwise
        """
        try:
            from ..runtime.resolver import RuntimeResolutionContext
        except ImportError:
            return None
        
        # Create resolution context with current model and provider info
        context = RuntimeResolutionContext(
            model_name=getattr(self, 'llm', None),
            provider_name=self._extract_provider_from_model(getattr(self, 'llm', None)),
            agent_config={'agent_id': getattr(self, 'agent_id', None)}
        )
        
        try:
            resolver = self._get_runtime_resolver()
            result = resolver.resolve_runtime_instance(
                context=context,
                model_runtime_configs=getattr(self, '_model_runtime_configs', None),
                provider_runtime_configs=getattr(self, '_provider_runtime_configs', None),
                legacy_cli_backend=getattr(self, '_cli_backend', None)
            )
            
            if result and result.runtime:
                return result.runtime
            
        except (ValueError, RuntimeError) as e:
            # Only fall back for registry not initialized, propagate configuration errors
            if "not initialized" in str(e).lower():
                # Registry not initialized - this is expected in SDK-only mode
                pass
            else:
                # Configuration error (unknown runtime ID etc.) - fail closed
                raise RuntimeError(
                    f"Runtime resolution failed for agent={getattr(self, 'display_name', 'unknown')!r}, "
                    f"model={getattr(self, 'llm', None)!r}: {e}. "
                    "Fix the runtime ID/configuration or remove the runtime override."
                ) from e
        
        return None
    
    def _extract_provider_from_model(self, model_name):
        """Extract provider name from model name.
        
        Args:
            model_name: Model name string (e.g., "anthropic/claude-3-sonnet")
            
        Returns:
            Provider name if detectable, None otherwise
        """
        if not model_name or not isinstance(model_name, str):
            return None
        
        # Common provider patterns
        if '/' in model_name:
            return model_name.split('/')[0]
        
        # Provider inference based on model name patterns
        model_lower = model_name.lower()
        if 'claude' in model_lower or 'anthropic' in model_lower:
            return 'anthropic'
        elif 'gpt' in model_lower or 'openai' in model_lower:
            return 'openai'
        elif 'gemini' in model_lower or 'google' in model_lower:
            return 'google'
        elif 'llama' in model_lower:
            return 'meta'
        
        return None
    
    async def _chat_via_runtime(self, runtime_instance, prompt: str, **kwargs) -> Optional[str]:
        """Chat implementation using resolved runtime instance.
        
        This is similar to _chat_via_cli_backend but uses the resolved runtime
        from the model-scoped runtime resolution system.
        
        Args:
            runtime_instance: Resolved runtime instance (CliBackendProtocol)
            prompt: User prompt
            **kwargs: Additional chat parameters
            
        Returns:
            Runtime response content
        """
        if not runtime_instance:
            raise RuntimeError("Runtime instance is None")
        
        # Delegate to CLI backend implementation with runtime instance
        # Pass runtime instance directly to avoid mutating shared state
        return await self._chat_via_cli_backend(prompt=prompt, cli_backend=runtime_instance, **kwargs)
    
    async def _chat_via_cli_backend(self, prompt: str, cli_backend: Any = None, **kwargs) -> Optional[str]:
        """Chat implementation using CLI backend delegation.
        
        Args:
            prompt: User prompt
            cli_backend: Optional specific backend instance to use (for runtime delegation)
            **kwargs: Additional chat parameters (passed through as metadata)
            
        Returns:
            CLI backend response content
        """
        # Use provided backend or fall back to instance backend
        backend = cli_backend or self._cli_backend
        if not backend:
            raise RuntimeError("CLI backend not configured")

        # Bound before the try so the failure hook can carry the backend's
        # result (and its audit metadata) when execution returned an error.
        result = None
        try:
            # Import backend types
            from ..cli_backend import CliSessionBinding
            
            # Build session binding for state management. A session the agent
            # has already delegated a turn for is a resume: the backend then
            # continues the CLI-side conversation (and skips re-sending the
            # system prompt where configured) instead of starting fresh.
            session_id = getattr(self, '_session_id', None) or f"agent-{self.agent_id}"
            started_sessions = getattr(self, '_cli_backend_sessions_started', None)
            if started_sessions is None:
                started_sessions = set()
                self._cli_backend_sessions_started = started_sessions
            # Serialise session establishment per session id: without the
            # lock, concurrent turns could both observe "not started" and
            # spawn two fresh CLI conversations for one session.
            session_locks = getattr(self, '_cli_backend_session_locks', None)
            if session_locks is None:
                session_locks = {}
                self._cli_backend_session_locks = session_locks
            session_lock = session_locks.setdefault(session_id, asyncio.Lock())
            try:
                await session_lock.acquire()
            except RuntimeError:
                # The stored lock is bound to a previous (closed) event loop —
                # common when sync callers wrap each turn in its own loop.
                # Re-key a fresh lock for this loop; cross-loop turns are
                # serial by construction, so mutual exclusion is preserved.
                session_lock = asyncio.Lock()
                session_locks[session_id] = session_lock
                await session_lock.acquire()
            lock_held = True
            session_binding = CliSessionBinding(
                session_id=session_id,
                is_resume=session_id in started_sessions,
            )
            
            # Get system prompt from agent configuration
            system_prompt = None
            if hasattr(self, 'system_prompt') and self.system_prompt:
                system_prompt = self.system_prompt
            elif self.backstory or self.role or self.goal:
                # Build system prompt from agent identity
                parts = []
                if self.backstory:
                    parts.append(self.backstory)
                if self.role:
                    parts.append(f"Your Role: {self.role}")
                if self.goal:
                    parts.append(f"Your Goal: {self.goal}")
                system_prompt = "\n".join(parts)
            
            # Extract images from attachments (if any)
            images = kwargs.get('attachments')
            if images:
                # Filter for image files
                image_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}
                images = [
                    img for img in images 
                    if any(img.lower().endswith(ext) for ext in image_extensions)
                ]
                if not images:
                    images = None
            
            # Execute CLI backend
            result = await backend.execute(
                prompt=prompt,
                session=session_binding,
                images=images,
                system_prompt=system_prompt
            )

            # Check for CLI backend errors BEFORE the (cancellable) hook and
            # before marking the session started, so a failed turn never
            # records a resumable session.
            if result is None:
                raise RuntimeError(
                    f"CLI backend returned no result for agent={self.display_name!r}, "
                    f"session_id={session_id!r}"
                )
            if getattr(result, "error", None):
                raise RuntimeError(
                    f"CLI backend failed for agent={self.display_name!r}, "
                    f"session_id={session_id!r}: {result.error}"
                )

            # A successful turn establishes the CLI-side session; subsequent
            # turns under the same session_id are resumes. Recorded (and the
            # lock released) BEFORE the hook await: cancellation during the
            # hook must not lose the resume state or hold the lock.
            started_sessions.add(session_id)
            session_lock.release()
            lock_held = False

            # The external command has completed at this point. Hook emission
            # and history bookkeeping failures are contained here so they are
            # never reported as backend-execution failures — that mislabel
            # invites callers to retry work the CLI already finished.
            try:
                await self._emit_cli_backend_hook(
                    backend=backend,
                    session_id=session_id,
                    result=result,
                )

                # Update chat history with the exchange
                if hasattr(self, '_append_to_chat_history'):
                    self._append_to_chat_history({
                        "role": "user",
                        "content": prompt
                    })
                    if result.content:
                        self._append_to_chat_history({
                            "role": "assistant",
                            "content": result.content
                        })
            except Exception as post_exc:
                logging.warning(
                    f"Post-execution bookkeeping failed after successful CLI "
                    f"backend turn (agent={self.display_name!r}, "
                    f"session_id={session_id!r}): {post_exc}"
                )

            return result.content

        except asyncio.CancelledError:
            # Cancellation is BaseException: it bypasses ``except Exception``,
            # so release here or later turns on this session block forever.
            # ``lock_held`` guards against releasing a lock a concurrent turn
            # has since acquired; names may be unbound if cancellation preceded
            # their assignment.
            try:
                if lock_held and session_lock.locked():
                    session_lock.release()
            except (NameError, UnboundLocalError, RuntimeError):
                pass
            raise
        except Exception as e:
            # Release the per-session lock on any failure path; ``session_lock``
            # may be unbound when the exception preceded its assignment.
            try:
                if lock_held and session_lock.locked():
                    session_lock.release()
            except (NameError, UnboundLocalError, RuntimeError):
                pass
            # ``result`` carries the backend's error result (and its audit
            # metadata) when execution completed with an error; it is None when
            # the failure preceded execution.
            await self._emit_cli_backend_hook(
                backend=backend,
                session_id=session_id,
                result=result,
                error=str(e),
            )
            raise RuntimeError(
                f"CLI backend execution failed for agent={self.display_name!r}: {e}"
            ) from e

    async def _emit_cli_backend_hook(
        self,
        *,
        backend: Any,
        session_id: Optional[str],
        result: Any,
        error: Optional[str] = None,
    ) -> None:
        """Emit the CLI_BACKEND_EXECUTE hook (no-op when no listener is registered).

        Fires on both success and failure so subprocess startup errors and
        timeouts remain observable. Prompt-bearing argv values are redacted at
        the payload serialization boundary.
        """
        from ..hooks.types import HookEvent

        if not self._hook_runner.registry.has_hooks(HookEvent.CLI_BACKEND_EXECUTE):
            return

        from ..hooks.events import CliBackendExecuteInput
        from ..cli_backend.debug import backend_label

        metadata = getattr(result, "metadata", None) or {}
        hook_input = CliBackendExecuteInput(
            session_id=session_id,
            cwd=os.getcwd(),
            event_name=HookEvent.CLI_BACKEND_EXECUTE.value,
            timestamp=str(time.time()),
            agent_name=self.display_name,
            backend=backend_label(backend),
            command=metadata.get("command"),
            content=getattr(result, "content", None),
            error=error if error is not None else getattr(result, "error", None),
        )
        await self._hook_runner.execute(
            HookEvent.CLI_BACKEND_EXECUTE,
            hook_input,
        )

    # -------------------------------------------------------------------------
    #                       Resource Lifecycle Management
    # -------------------------------------------------------------------------
    
    def close(self) -> None:
        """Synchronously close the agent and clean up resources."""
        if getattr(self, '_closed', False):
            return

        # Memory cleanup
        try:
            memory = getattr(self, "_memory_instance", None)
            if memory and hasattr(memory, 'close_connections'):
                memory.close_connections()
        except Exception as e:
            logger.warning(f"Memory cleanup failed: {e}")

        # LLM client cleanup - target actual live clients, not model strings
        try:
            # Primary cleanup targets - actual live clients
            if hasattr(self, 'llm_instance') and self.llm_instance:
                if hasattr(self.llm_instance, 'aclose'):
                    # Try async close first
                    try:
                        if asyncio.iscoroutinefunction(self.llm_instance.aclose):
                            # Use async bridge to safely close from any context
                            from ..utils.async_bridge import run_coroutine_from_any_context
                            run_coroutine_from_any_context(self.llm_instance.aclose())
                        else:
                            self.llm_instance.aclose()
                    except Exception:
                        # Fall back to sync close if async fails
                        if hasattr(self.llm_instance, 'close'):
                            self.llm_instance.close()
                elif hasattr(self.llm_instance, 'close'):
                    self.llm_instance.close()
            
            # Check for OpenAI client (common pattern in agents)
            if hasattr(self, '_Agent__openai_client') and self._Agent__openai_client:
                if hasattr(self._Agent__openai_client, 'close'):
                    self._Agent__openai_client.close()
            
            # Legacy fallback - check self.llm._client (but less likely to work)
            if hasattr(self, 'llm') and self.llm and not isinstance(self.llm, str):
                llm_client = getattr(self.llm, '_client', None)
                if llm_client and hasattr(llm_client, 'close'):
                    llm_client.close()
        except Exception as e:
            logger.warning(f"LLM client cleanup failed: {e}")

        # MCP cleanup — shut down MCP clients passed via tools=[MCP(...)]
        # (mirrors remove_mcp_server()'s best-effort shutdown)
        try:
            if isinstance(self.tools, list):
                for t in self.tools:
                    if hasattr(t, 'shutdown'):
                        try:
                            t.shutdown()
                        except Exception as e:
                            logger.warning(f"MCP tool cleanup failed: {e}")
        except Exception as e:
            logger.warning(f"MCP cleanup failed: {e}")

        # Runtime-attached MCP servers cleanup (each guarded individually)
        self._shutdown_runtime_mcp_servers()

        # Circuit breaker cleanup — remove this agent's instance-scoped breakers
        # so a reused id(self) can't inherit a stale OPEN breaker.
        self._cleanup_circuit_breakers()

        # Server registry cleanup
        try:
            self._cleanup_server_registrations()
        except Exception as e:
            logger.warning(f"Server cleanup failed: {e}")

        # Background tasks cleanup
        try:
            for task in getattr(self, '_background_tasks', []):
                if hasattr(task, 'cancel'):
                    task.cancel()
        except Exception as e:
            logger.warning(f"Task cleanup failed: {e}")

        # ThreadPoolExecutor cleanup
        try:
            if hasattr(self, '_tool_executor') and self._tool_executor:
                # Use cancel_futures only if supported (Python 3.9+)
                import sys
                if sys.version_info >= (3, 9):
                    self._tool_executor.shutdown(wait=False, cancel_futures=True)
                else:
                    self._tool_executor.shutdown(wait=False)
                delattr(self, '_tool_executor')
        except Exception as e:
            logger.warning(f"ThreadPoolExecutor cleanup failed: {e}")

        # Always set closed flag
        self._closed = True
    
    async def aclose(self) -> None:
        """Async version of close() for async context managers."""
        try:
            # Close memory connections asynchronously if supported
            if hasattr(self, 'memory') and self.memory:
                if hasattr(self.memory, 'aclose'):
                    await self.memory.aclose()
                elif hasattr(self.memory, 'close_connections'):
                    self.memory.close_connections()
            
            # Close MCP clients passed via tools=[MCP(...)]
            # (mirrors remove_mcp_server()'s best-effort shutdown)
            if isinstance(self.tools, list):
                for t in self.tools:
                    if hasattr(t, 'aclose'):
                        try:
                            await t.aclose()
                        except Exception as e:
                            logger.warning(f"MCP tool cleanup failed: {e}")
                    elif hasattr(t, 'shutdown'):
                        try:
                            t.shutdown()
                        except Exception as e:
                            logger.warning(f"MCP tool cleanup failed: {e}")

            # Runtime-attached MCP servers cleanup (each guarded individually)
            self._shutdown_runtime_mcp_servers()

            # Circuit breaker cleanup — remove this agent's instance-scoped breakers
            self._cleanup_circuit_breakers()

            # Clean up server registrations and tasks
            self._cleanup_server_registrations()
            
            if hasattr(self, '_background_tasks'):
                for task in self._background_tasks:
                    if hasattr(task, 'cancel'):
                        task.cancel()
                    # Wait for cancellation to complete
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass

            # ThreadPoolExecutor cleanup (async-safe)
            if hasattr(self, '_tool_executor') and self._tool_executor:
                import sys
                loop = asyncio.get_running_loop()
                # Use run_in_executor to avoid blocking the event loop
                if sys.version_info >= (3, 9):
                    await loop.run_in_executor(
                        None, 
                        lambda: self._tool_executor.shutdown(wait=False, cancel_futures=True)
                    )
                else:
                    await loop.run_in_executor(
                        None, 
                        lambda: self._tool_executor.shutdown(wait=False)
                    )
                delattr(self, '_tool_executor')
            
            self._closed = True
            
        except Exception as e:
            logger.warning(f"Error during async agent cleanup: {e}")
    
    def _cleanup_server_registrations(self) -> None:
        """Clean up global server registry entries for this agent."""
        if getattr(self, '_agent_id', None) is None:
            return  # No ID generated, nothing registered

        try:
            # Tear down the routes launch() actually registered (module-level
            # state in execution_mixin.py).
            from .execution_mixin import cleanup_launch_registration
            cleanup_launch_registration(self._agent_id)

        except Exception as e:
            import sys
            if sys.meta_path is not None:
                try:
                    logger.warning(f"Error cleaning up server registrations: {e}")
                except Exception:
                    pass
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - clean up resources."""
        self.close()
    
    async def __aenter__(self):
        """Async context manager entry.""" 
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - clean up resources."""
        await self.aclose()
    
    def __del__(self):
        """Lightweight cleanup that only closes resources if not already closed."""
        if not getattr(self, '_closed', False):
            # Only close connections, skip anything that could fail during GC
            try:
                memory = getattr(self, "_memory_instance", None)
                if memory and hasattr(memory, 'close_connections'):
                    memory.close_connections()
                    
                # Clean up old artifacts if artifact store is configured
                artifact_store = getattr(self, "_artifact_store", None)
                if artifact_store and hasattr(artifact_store, 'cleanup_old_artifacts'):
                    try:
                        artifact_store.cleanup_old_artifacts()
                    except Exception as e:
                        # Log the error for debugging but don't fail cleanup
                        import logging
                        logging.debug(
                            f"Failed to cleanup artifacts for agent {self.name}: {e}"
                        )
            except Exception as exc:  # noqa: BLE001 - finalizers must not raise
                import contextlib
                with contextlib.suppress(Exception):
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.debug("Agent GC memory cleanup failed: %s", exc)
            finally:
                self._closed = True
        
    @property
    def is_closed(self) -> bool:
        """Returns True if the agent has been closed."""
        return getattr(self, '_closed', False)

    def __str__(self):
        return f"Agent(name='{self.name}', role='{self.role}', goal='{self.goal}')"

    def __repr__(self):
        """Show WHERE this agent works, not just what it is called.

        The default object repr said nothing, so a reader had to consult docs to
        learn whether tools ran locally or in a container. Now the object says it.
        """
        from .execution_location import repr_fields

        return f"Agent(name={self.name!r}, {repr_fields(self)})"

    def where_does_it_run(self) -> str:
        """Plain-English answer to "where does my code actually run?".

        Example::

            >>> print(Agent(name="builder").where_does_it_run())
            Thinking (the AI model calls) happens on this machine.
            Tools run on this machine.
            Nothing is isolated: tools you pass run in this program, with your permissions.
        """
        from .execution_location import explain

        return explain(self)
