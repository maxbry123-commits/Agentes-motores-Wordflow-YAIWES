# AGENTS.md - PraisonAI SDK Comprehensive Guide

> **For AI Agents and Developers**: This document provides the complete context needed to work with the PraisonAI ecosystem, including design principles, architecture, repository structure, and implementation guidelines.

---

## 1. What is PraisonAI?

PraisonAI is a **high-performance, agentic AI framework** designed for building production-ready AI agents and multi-agent workflows.

### Core Philosophy

```
Simpler than competitors • More extensible • Faster • Agent-centric
```

| Principle | Description |
|-----------|-------------|
| **Agent-Centric** | Every design decision centers on Agents, workflows, sessions, tools, and memory |
| **Protocol-Driven Core** | Core SDK is lightweight with protocols/hooks/adapters only |
| **Minimal API** | Fewer parameters, sensible defaults, explicit overrides |
| **Performance-First** | Lazy loading, optional dependencies, no hot-path regressions |
| **Production-Ready** | Safe by default, multi-agent safe, async-safe |
| **Open Core** | Core free and open source; clear paid upgrade path (support/cloud/services) |

Powerful, lightweight, highly reliable and robust.
Easy and developer-friendly for non-developers.
Each feature runs 3 ways: **CLI, YAML, Python**.

> **Lightweight & powerful — no scope creep.** The aim of this package is to stay lightweight and powerful. Do a critical review at **each stage** — issue triage, fix planning, and PR review/implementation. Reject scope creep for the sake of adding features: prefer existing Agent capabilities (`instructions`/`backstory`/`tools`/`hooks`/`memory`) over new params, modules, or exports. A change must genuinely strengthen the SDK; never add a knob with no live consumer or that duplicates existing behaviour. Even when fixing a raised issue, keep the fix minimal and lightweight rather than expanding surface area.
---

## 2. Repository Structure

### 2.1 Canonical Paths

```
/Users/praison/praisonai-package/
├── src/
│   ├── praisonai-agents/          # Core SDK (praisonaiagents)
│   │   ├── praisonaiagents/       # Python package
│   │   ├── tests/                 # Unit & integration tests
│   │   ├── examples/              # Package-level examples
│   │   └── pyproject.toml         # Package config
│   │
│   ├── praisonai/                 # Wrapper (praisonai)
│   │   ├── praisonai/             # Bot/channel CLI, integrations, heavy impls
│   │   └── pyproject.toml
│   │
│   ├── praisonai-code/            # Agentic terminal CLI (praisonai_code)
│   │   ├── praisonai_code/        # run, chat, code, runtime, cli_backends
│   │   └── pyproject.toml
│   │
│   └── praisonai-ts/              # TypeScript SDK
│       └── src/
│
├── examples/                      # Main examples directory
│   ├── python/                # Python examples (primary)
│   ├── yaml/                  # YAML configuration examples
│   ├── js/                    # JavaScript/TypeScript examples
│   └── cookbooks/             # End-to-end recipes
│
/Users/praison/PraisonAI-tools/    # External tools/plugins
/Users/praison/PraisonAIDocs/      # Documentation (Mintlify)
    └── docs/
        ├── agents/
        ├── api/
        ├── capabilities/
        ├── cli/
        ├── concepts/
        ├── features/
        ├── guides/
        ├── knowledge/
        ├── memory/
        ├── models/
        ├── observability/
        ├── rag/
        ├── sdk/
        ├── tools/
        ├── tutorials/
        └── ... (49+ subdirectories)
```

### 2.2 Package Hierarchy

```
┌─────────────────────────────────────────────────────────────────┐
│                      praisonai (Wrapper)                        │
│     Integrations • framework_adapters • serve • dashboard       │
├─────────────────────┬─────────────────────┬─────────────────────┤
│ praisonai-code      │ praisonai-bot       │ praisonai-train     │
│ run • chat • code   │ bots • gateway •    │ LLM fine-tune •     │
│ • doctor            │ BotOS • CLI         │ agent training      │
├─────────────────────┴─────────────────────┴─────────────────────┤
│                    praisonaiagents (Core SDK)                   │
│  Protocols • Hooks • Adapters • Base Classes • Decorators       │
├─────────────────────────────────────────────────────────────────┤
│                   praisonai-tools (External)                    │
│  Optional Tools • Plugins • Community Extensions                │
└─────────────────────────────────────────────────────────────────┘
```

### 2.3 `praisonai-code` — Agentic Terminal CLI Split (C5/C6)

The **agentic terminal CLI** (`run`, `chat`, `code`, warm runtime, CLI backends, Typer app) lives in **`praisonai-code`** (`praisonai_code`). **Bots, gateway, and channel CLI** live in **`praisonai-bot`** (`praisonai_bot`) after C9. **LLM fine-tuning and agent training** live in **`praisonai-train`** (`praisonai_train`) after C10. The **`praisonai`** wrapper keeps integrations, framework adapters, serve, and dashboard. **`pip install praisonai`** still installs everything; old import paths are preserved via shims.

| Product | Location | Stays out of |
|---------|----------|--------------|
| Agentic terminal CLI | `src/praisonai-code/praisonai_code/` | Must **not** depend on `praisonai` (PyPI cycle) |
| Bot/channel runtime | `src/praisonai-bot/praisonai_bot/` | Must **not** PyPI-depend on `praisonai` or `praisonai-code` |
| Core SDK | `src/praisonai-agents/praisonaiagents/` | Heavy CLI / integrations |
| Wrapper shims | `src/praisonai/praisonai/bots`, `gateway`, … | `alias_package` → `praisonai_bot` |

**Moved into `praisonai_code` (~304 modules):**

| Step | Content |
|------|---------|
| C1 | `runtime/`, `cli_backends/` |
| C2 | `cli/interactive/`, `execution/`, `ui/`, `output/`, `state/` |
| C3 | `cli/commands/*` (80 Typer command modules) |
| C4 | `cli/features/*` (158 feature handlers; bot features excepted) |
| C5 | `cli/main.py`, `app.py`, `configuration/`, `session/`, `utils/`, schema modules |

**Intentionally retained in the wrapper (not shims):**

- **Commands:** `gateway`, `bot`, `pairing`, `identity`, `onboard`, `kanban`, `dashboard`, `claw`
- **Features:** `gateway`, `bots_cli`, `onboard`, `approval`, `serve`
- **Domains:** `praisonai.gateway.*`, `praisonai.bots.*`, integrations, endpoints

**Backward-compat shim patterns** (old `praisonai.*` paths must keep working):

| Pattern | Used for | Module identity |
|---------|----------|-----------------|
| `sys.modules[__name__] = _impl` | `cli/main`, `cli/app`, each moved `cli/commands/*`, schema modules | Same object as `praisonai_code.*` |
| `alias_package()` + `_AliasFinder` | `cli/output`, `interactive`, `execution`, `ui`, `state`, `session`, `configuration`, `utils` | Same submodule objects |
| Package `__getattr__` + submodule alias | `runtime/`, `cli_backends/` | Submodules identical; package object differs |
| `features/__init__.py` `__path__` extension | Extracted features; five bot features stay local | Handler imports via `__getattr__` |

**Typer lazy-load:** `praisonai_code.cli.app._WRAPPER_COMMANDS` lists bot/channel commands that resolve via **`praisonai.cli.commands.*`** (wrapper), not `praisonai_code.cli.commands.*`.

**Monorepo bootstrap:** `praisonai._bootstrap.ensure_praisonai_code()` adds sibling `src/praisonai-code` to `sys.path` so `PYTHONPATH=src/praisonai-agents:src/praisonai` works without an explicit code entry.

**Install order (CI and local dev):** `praisonai-agents` → `praisonai-code` → `praisonai-bot` → `praisonai-train` → `praisonai-browser` → `praisonai-mcp` → `praisonai-sandbox` → `praisonai-deploy` → `praisonai` (see `.github/actions/install-monorepo-packages`).

**Invocation paths that must remain valid:**

```bash
praisonai …                          # console script → praisonai.__main__
python -m praisonai …
python -m praisonai.cli.main …
python -m praisonai.runtime …
from praisonai.cli.main import PraisonAI
from praisonai.cli.commands.run import …
unittest.mock.patch("praisonai.cli.commands.run.X")   # same module object
```

**Regression gate:** `src/praisonai/tests/unit/test_c5_backward_compat.py` (also run in optimised CI smoke). Standalone `pip install praisonai-code` requires declared deps (e.g. `toml` for config resolver).

**Key files:**

| What | Where |
|------|-------|
| Typer app + lazy commands | `praisonai_code/cli/app.py` |
| Shim helper | `praisonai/cli/_shim.py` |
| Bootstrap | `praisonai/_bootstrap.py` |
| CLI main shim | `praisonai/cli/main.py` |
| Runtime / backends shims | `praisonai/runtime/`, `praisonai/cli_backends/` |

**Do not** recreate `src/praisonai/praisonai_code/` — it shadows the real package.

**PyPI publish order:** `praisonaiagents` → `praisonai-code` → `praisonai` (see `src/praisonai/scripts/bump_and_release.py` and `.github/workflows/pypi-release.yml`). Gateway/bots changes release via wrapper only; agentic CLI changes also bump `praisonai-code`.

#### C6 integration gate (#2519)

C6 is the **sign-off step** after C0–C5 file moves: no further moves, only regression verification and release wiring.

| Check | Command / artefact |
|-------|-------------------|
| Smoke `--help` | `praisonai`, `praisonai run/chat/code/daemon/attach/gateway/bot/doctor --help` |
| Compat regression | `pytest src/praisonai/tests/unit/test_c5_backward_compat.py` |
| CLI shard | `pytest src/praisonai/tests/unit/cli/` |
| Warm runtime | `pytest src/praisonai/tests/unit/test_warm_runtime.py` |
| Doctor shard | `pytest src/praisonai/tests/unit/doctor/` |
| Import perf | `pytest src/praisonai/tests/unit/test_performance_benchmarks.py` (< 500ms) |
| Real LLM smoke | `RUN_REAL_KEY_TESTS=1 PRAISONAI_ALLOW_NETWORK=1 PRAISONAI_TEST_PROVIDERS=all pytest src/praisonai/tests/integration/test_real_key_smoke.py` |
| Verification log | `src/praisonai/tests/C6_VERIFICATION.md` |

**Command split (wrapper vs code):**

| Install target | Agentic CLI (`run`, `chat`, `code`, …) | Bot/gateway (`bot`, `gateway`, `pairing`, …) |
|----------------|----------------------------------------|---------------------------------------------|
| `pip install praisonai` | Yes (via `praisonai-code` dep + shims) | Yes |
| `pip install praisonai-code` only | Yes — agentic hot path (`run`, `chat`, `code`, warm runtime) without wrapper import | No — wrapper-only commands hidden when `praisonai` absent |

**C7 (hot path complete):** Core agentic CLI imports no longer require the `praisonai`
wrapper at module level. Remaining lazy wrapper imports (~211, regression-gated) are optional commands
and features (capabilities, bots, framework adapters) — use
`praisonai_code._wrapper_bridge` or `pip install praisonai`. See
`src/praisonai/tests/C7_VERIFICATION.md`. CI gate: `scripts/check_c7_imports.sh`.

### 2.4 Package ownership (C7.1)

| Tier | Package | Owns |
|------|---------|------|
| 1 | `praisonaiagents` | Agent, tools, memory, hooks, `frameworks/` protocols |
| 2 | `praisonai-code` | `run`/`chat`/`code`, Typer, runtime, llm, tool resolution |
| 2b | `praisonai-bot` | Bots, gateway, channel CLI, OS daemon |
| 2c | `praisonai-train` | LLM fine-tuning (Unsloth), agent training, `train` CLI |
| 3 | `praisonai` | `framework_adapters/`, capabilities, serve orchestration, dashboard |
| 1-TS | `praisonai-ts` | TypeScript/JavaScript SDK (`npm: praisonai`); canonical path `src/praisonai-ts/` |

**Cross-tier rule:** `praisonai-code` must not declare a PyPI dependency on `praisonai`. Use
[`praisonai_code._wrapper_bridge`](../praisonai-code/praisonai_code/_wrapper_bridge.py) for lazy wrapper access.

**framework_adapters:** protocols in SDK; registry + CrewAI/AutoGen/PraisonAI bodies stay in
[`praisonai/framework_adapters/`](../praisonai/praisonai/framework_adapters/). Do not move to `praisonai-code`.

**Typer routing sets** (in `praisonai_code/cli/app.py`): `_BOT_RESIDENT_COMMANDS` loads from
`praisonai_bot.cli.commands.*` (`bot`, `gateway`, `pairing`, …); `_TRAIN_RESIDENT_COMMANDS` loads
from `praisonai_train.cli.commands.*` (`train`, C10); `_WRAPPER_RESIDENT_COMMANDS` loads from
`praisonai.cli.commands.*` (`dashboard`, `flow`, …). Commands implemented in `praisonai_code`
(`serve`, …) stay local; bridge internal wrapper imports.

Full boundary doc: [`src/praisonai/tests/C7.1_BOUNDARIES.md`](../praisonai/tests/C7.1_BOUNDARIES.md).

### 2.5 TypeScript SDK (`praisonai-ts`)

Python guidelines in this file do **not** replace the TypeScript SDK guide. For any issue, PR, or review touching `src/praisonai-ts/`:

1. Read [`src/praisonai-ts/AGENTS.md`](../praisonai-ts/AGENTS.md) — architecture, parity, triage, and PR review rules.
2. Implement fixes in **`src/praisonai-ts/`** in this monorepo (not in `praisonaiagents/`).
3. Verify with `cd src/praisonai-ts && npm install && npm run build && npm test`.
4. After merge, maintainers sync the npm mirror: `gh workflow run "Sync to praisonai-js" --repo MervinPraison/PraisonAI`.

[MervinPraison/praisonai-js](https://github.com/MervinPraison/praisonai-js) is the public npm checkout; direction is **monorepo → praisonai-js** only. Claude merge gate and `@claude` review TS changes under `src/praisonai-ts/` using the TS AGENTS.md criteria (lightweight, type-safe, Python parity where applicable).

---

## 3. Core SDK Architecture (praisonaiagents)

### 3.1 Key Modules

| Module | Size | Purpose |
|--------|------|---------|
| `agent/` | 1.7M | Agent class, protocols, handoff, autonomy |
| `memory/` | 784K | Memory protocols, adapters, file memory |
| `context/` | 840K | Context management, artifacts, fast context |
| `tools/` | 816K | Tool SDK, decorators, registry, protocols |
| `llm/` | 756K | LLM client, model router |
| `workflows/` | 472K | Workflow engine, patterns (Route, Parallel, Loop) |
| `mcp/` | 404K | Model Context Protocol integration |
| `eval/` | 384K | Evaluation framework |
| `agents/` | 376K | Multi-agent orchestration (AgentTeam, AgentFlow) |
| `knowledge/` | 300K | Knowledge/RAG protocols, vector stores |
| `rag/` | 264K | RAG protocols, retriever, reranker |
| `config/` | 252K | Feature configs (ExecutionConfig, OutputConfig, etc.) |
| `session/` | 224K | Session management, persistence |
| `plugins/` | 204K | Plugin manager, registry |
| `hooks/` | 184K | Hook system, middleware, events |
| `storage/` | 136K | Storage protocols, adapters |
| `scheduler/` | 132K | Schedule models, store, parser, runner |
| `trace/` | 116K | Trace protocols, context events |
| `approval/` | 92K | Human-in-the-loop approval protocols |
| `bots/` | 80K | BotOS protocols, config |
| `policy/` | 76K | Policy engine |
| `gateway/` | 60K | Gateway protocols |
| `sandbox/` | 56K | Code execution sandbox |
| `bus/` | 48K | Event bus |
| `streaming/` | 44K | Streaming events, callbacks |
| `conditions/` | 40K | Conditional logic protocols |
| `db/` | 32K | Database adapter protocols |

### 3.2 Protocol-First Design

Core SDK uses `typing.Protocol` for all extension points:

```
Pattern: Each major module has a protocols.py file

- Protocols define WHAT (interface contract)
- Adapters implement HOW (concrete implementation)
- Naming: XProtocol for interfaces, XAdapter for implementations
  (ALWAYS suffix with "Protocol" — never use bare concept names like TraceSink)
- File placement: All protocols live in protocols.py within their module
- Users can implement any protocol for custom behavior
```

**Discovery:** Find all protocols dynamically:
```bash
grep -r "class.*Protocol" praisonaiagents/ --include="*.py"
```

**Key principle:** When adding new extensibility, create a Protocol first, then implement adapters.

### 3.3 Core Dependencies

```toml
# Required (always loaded) - pyproject.toml
dependencies = [
    "pydantic>=2.10.0",    # Type validation
    "rich",                # Terminal UI
    "openai>=2.0.0",       # OpenAI client
    "posthog>=3.0.0",      # Telemetry
    "aiohttp>=3.8.0"       # Async HTTP
]

# Optional (lazy loaded)
[project.optional-dependencies]
memory = ["chromadb>=1.0.0", "litellm>=1.81.0"]
knowledge = ["mem0ai>=0.1.0", "chromadb>=1.0.0", "markitdown[all]>=0.1.0"]
mcp = ["mcp>=1.20.0", "fastapi>=0.115.0", "uvicorn>=0.34.0"]
llm = ["litellm>=1.81.0"]
api = ["fastapi>=0.115.0", "uvicorn>=0.34.0"]
auth = ["PyJWT>=2.8.0", "passlib[bcrypt]>=1.7.4"]
mongodb = ["pymongo>=4.6.3", "motor>=3.4.0"]
```

---

## 4. Core Engineering Principles

### 4.1 Protocol-Driven Core (MUST)

```
Core SDK (praisonaiagents)     praisonai-code (terminal CLI)    Wrapper (praisonai)
━━━━━━━━━━━━━━━━━━━━━━━━━━━    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━    ━━━━━━━━━━━━━━━━━━━
✅ Protocols                   ✅ run/chat/code/doctor/setup      ✅ Bot/gateway CLI
✅ Hooks                        ✅ runtime, cli_backends           ✅ Integrations
✅ Adapters                     ✅ Typer app, moved commands       ✅ Heavy implementations
✅ Base classes                 ✅ Depends on agents only           ✅ Optional deps
✅ Decorators                   ❌ Must not import praisonai        ✅ UI, DB adapters
❌ Heavy implementations        ❌ Bot/channel commands             ❌ Core logic
```

### 4.2 No Performance Impact (MUST)

```python
# ✅ CORRECT: Lazy import
def use_chromadb():
    try:
        import chromadb
    except ImportError:
        raise ImportError("Install with: pip install praisonaiagents[memory]")

# ❌ WRONG: Module-level heavy import
import chromadb  # Adds 500ms+ to import time
```

**Rules:**
- No module-level imports of optional dependencies
- No heavy initialization in `__init__.py`
- Use `__getattr__` for lazy loading in package roots
- Target: < 200ms package import time

### 4.3 DRY Approach (MUST)

- Reuse existing abstractions; don't duplicate
- Refactor safely when duplication is found
- Check existing protocols before creating new ones
- Use existing EventBus instead of creating new messaging

### 4.4 Agent-Centric Design (MUST)

Every API decision must prioritize:
1. **Agents** - Core execution unit
2. **Multi-agent workflows** - Coordination patterns
3. **Sessions** - State management
4. **Tools** - Agent capabilities
5. **Memory** - Persistence and context

### 4.5 Async-Safe & Multi-Agent Safe (MUST)

```
Async-Safe:
- All I/O operations must have async variants
- Never block the event loop with sync I/O in async context
- Use asyncio primitives for coordination (not threading)

Multi-Agent Safe:
- No shared mutable global state between agents
- Each agent owns its context, memory, and session
- Cross-agent communication via explicit channels (EventBus, handoff)
- Resource isolation by default, explicit sharing when needed
```

### 4.6 Invariants (Never Break)

| Invariant | Meaning |
|-----------|---------|
| Protocol-driven core | Core SDK has NO heavy implementations |
| Lazy imports | Optional deps never imported at module level |
| Backward compatible | Public API changes require deprecation cycle |
| Safe defaults | New features are opt-in, not opt-out |
| Deterministic tests | Tests must not depend on timing or external state |

### 4.7 Concurrency Model

```
Sync/Async Boundaries:
- User-facing: Both sync and async entry points (run/start)
- Internal: Prefer async, wrap for sync callers
- Tools: Support both sync and async execution
- Hooks: Fire in the current execution context (sync or async)

Event Loop Rules:
- One event loop per thread
- Never nest event loops
- Use asyncio.run() only at top level
```

### 4.8 Error Handling & Observability

```
Error Model:
- Fail fast with clear error messages
- Include remediation hints in exceptions
- Propagate context (agent name, tool name, session ID)
- Hook points for error interception (on_error events)

Observability Hooks:
- All key operations emit events via EventBus
- Trace protocols for external observability integration
- Structured logging with correlation IDs
- Metrics collection via optional adapters
```

### 4.9 Naming Conventions

```python
# Registration/Mutation
add_X()          # User-facing registration (add_hook, add_policy)
remove_X()       # Unregistration
register_X()     # Internal/framework registration

# Retrieval
get_X()          # Single item by ID (get_tool, get_policy)
search_X()       # Multiple by query (search_memory)
list_X()         # All items (list_tools, list_plugins)
has_X()          # Existence check

# Persistence
save() / load()  # Disk persistence (NOT store)

# Configuration
class XConfig:   # Configuration dataclass (MemoryConfig, HooksConfig)

# Protocols — ALWAYS suffix with "Protocol"
class XProtocol(Protocol):  # Abstract interface (TraceSinkProtocol, MemoryProtocol)
class XAdapter:             # Concrete implementation (ChromaAdapter, FileAdapter)

# ✅ CORRECT protocol naming:
class MemoryProtocol(Protocol): ...        # Clear it's a protocol
class SessionStoreProtocol(Protocol): ...  # Descriptive + Protocol suffix
class TraceSinkProtocol(Protocol): ...     # In protocols.py + suffixed

# ❌ WRONG protocol naming:
class TraceSink(Protocol): ...     # Missing Protocol suffix — ambiguous
class IMemory(Protocol): ...       # TypeScript convention, not Python
class MemoryBase(Protocol): ...    # "Base" implies ABC, not Protocol

# Execution
run()            # Synchronous, blocking
start()          # Async/long-running
execute()        # Internal/low-level
```

---

## 5. API Philosophy

### 5.1 Simple API (User-Facing)

```python
# Basic usage - 3 lines
from praisonaiagents import Agent
agent = Agent(name="assistant", instructions="Be helpful")
response = agent.start("Hello!")

# With tools - still simple
from praisonaiagents import Agent, tool

@tool
def search(query: str) -> list:
    """Search the web."""
    return [{"result": query}]

agent = Agent(name="researcher", tools=[search])
```

### 5.2 Progressive Disclosure

```python
# Level 1: Minimal (most users)
agent = Agent(name="assistant")

# Level 2: With common options
agent = Agent(
    name="assistant",
    llm="gpt-4o-mini",
    memory=True
)

# Level 3: Full control (power users)
from praisonaiagents import Agent, MemoryConfig, HooksConfig

agent = Agent(
    name="assistant",
    llm="gpt-4o-mini",
    memory=MemoryConfig(provider="chroma", use_long_term=True),
    hooks=HooksConfig(before_tool=[my_validator]),
    guardrail=my_guardrail
)
```

### 5.3 Parameter Consolidation

Agent parameters are consolidated into Config objects following the pattern:
`False=disabled, True=defaults, Config=custom`

**Consolidated Parameters (use these):**

| Config Object | Replaces (Deprecated) |
|--------------|----------------------|
| `execution=ExecutionConfig(code_execution=True, code_mode="safe", rate_limiter=obj, context_compaction=False)` | `allow_code_execution`, `code_execution_mode`, `rate_limiter` |
| `memory=MemoryConfig(auto_save="session_name")` | `auto_save` |
| `autonomy=AutonomyConfig(verification_hooks=[...])` | `verification_hooks` |
| `handoffs=[other_agent]` | `allow_delegation` |
| `output=OutputConfig(...)` | `verbose`, `markdown`, `stream`, `metrics` |
| `reflection=ReflectionConfig(...)` | `self_reflect`, `max_reflect`, `min_reflect` |
| `templates=TemplateConfig(...)` | `system_template`, `prompt_template`, `response_template` |
| `caching=CachingConfig(...)` | `cache`, `prompt_caching` |
| `web=WebConfig(...)` | `web_search`, `web_fetch` |

**Deprecated standalone params still work** (backward compatible) but emit `DeprecationWarning`.

> **📢 Deprecation Notice:** `ExecutionConfig.context_compaction` currently defaults to `False` during a deprecation period. In the next release, it will default to `True` for automatic proactive context overflow protection. To opt out explicitly, set `context_compaction=False`. To use the new behavior early, set `context_compaction=True`.

```python
# ❌ Old way (deprecated)
agent = Agent(
    name="coder",
    allow_code_execution=True,
    code_execution_mode="safe",
    auto_save="my_session",
    rate_limiter=my_limiter,
    allow_delegation=True,
    verification_hooks=[my_hook],
)

# ✅ New way (consolidated)
from praisonaiagents import Agent, ExecutionConfig, MemoryConfig
from praisonaiagents.agent.autonomy import AutonomyConfig

agent = Agent(
    name="coder",
    handoffs=[reviewer_agent],
    execution=ExecutionConfig(
        code_execution=True,
        code_mode="safe",
        rate_limiter=my_limiter,
        context_compaction=False,  # prepare for next release when default becomes True; warning still fires during deprecation period
    ),
    memory=MemoryConfig(auto_save="my_session"),
    autonomy=AutonomyConfig(verification_hooks=[my_hook]),
)
```

---

## 6. Extension Points

### 6.1 Tools

```python
# Decorator style (simplest)
from praisonaiagents import tool

@tool
def my_tool(query: str) -> str:
    """Tool description."""
    return f"Result: {query}"

# Class style (more control)
from praisonaiagents.tools import BaseTool

class MyTool(BaseTool):
    name = "my_tool"
    description = "Does something"
    
    def run(self, query: str) -> str:
        return f"Result: {query}"
```

**Base files:**
- `praisonaiagents/tools/base.py` - BaseTool class
- `praisonaiagents/tools/decorator.py` - @tool decorator
- `praisonaiagents/tools/registry.py` - Tool registry

> [!IMPORTANT]
> **Agents only recognize parameters.** When creating tools, always expose all options as function parameters—agents cannot discover env vars or config files.

### 6.2 Hooks & Middleware

```python
from praisonaiagents.hooks import add_hook, before_tool, after_tool

@before_tool
def validate_args(event):
    print(f"Calling: {event.tool_name}")

@after_tool
def log_result(event):
    print(f"Result: {event.result}")

# Or functional style
hook_id = add_hook("before_tool", my_handler)
```

### 6.3 Memory Adapters

```python
from praisonaiagents.memory.protocols import MemoryProtocol

class MyMemoryAdapter:  # Implements MemoryProtocol
    def store_short_term(self, text, metadata=None):
        ...
    def search_short_term(self, query, limit=5):
        ...
```

### 6.4 Schedule Tools

Agent-centric scheduling via standalone `@tool` functions (no Agent class bloat):

```python
from praisonaiagents import Agent
from praisonaiagents.tools import schedule_add, schedule_list, schedule_remove

agent = Agent(
    name="assistant",
    tools=[schedule_add, schedule_list, schedule_remove],
)
```

**Schedule expression formats:**
- Keywords: `"hourly"`, `"daily"`, `"weekly"`
- Intervals: `"*/30m"`, `"*/6h"`, `"*/10s"`
- Cron: `"cron:0 7 * * *"` (requires optional `croniter`)
- One-shot: `"at:2026-03-01T09:00:00"`
- Relative: `"in 20 minutes"`

**Core components:**
- `scheduler/models.py` — `Schedule` and `ScheduleJob` dataclasses
- `scheduler/store.py` — `FileScheduleStore` (thread-safe JSON persistence at `~/.praisonai/schedules/jobs.json`)
- `scheduler/parser.py` — `parse_schedule()` for human-friendly expressions
- `scheduler/runner.py` — `ScheduleRunner` (stateless due-job checker)
- `tools/schedule_tools.py` — `schedule_add`, `schedule_list`, `schedule_remove`

**Hook events:** `SCHEDULE_ADD`, `SCHEDULE_REMOVE`, `SCHEDULE_TRIGGER` (in `hooks/types.py`)

### 6.5 Database Adapters

```python
# Base files in praisonaiagents/db/
from praisonaiagents.db import DbAdapter, AsyncDbAdapter

class MyDbAdapter(DbAdapter):
    def connect(self): ...
    def query(self, sql, params): ...
```

---

## 7. CLI & YAML Representation

Every feature must run 3 ways: **Python, CLI, and YAML**.

```bash
# Basic agent
praisonai agent run --name "assistant" --prompt "Hello"

# With tools
praisonai agent run --tools web_search --prompt "Search for Python"

# Multi-agent workflow
praisonai workflow run --file workflow.yaml

# Server mode
praisonai serve --port 8000
```

---

## 8. Documentation Standards

### 8.1 Mintlify Components

Use these Mintlify components for docs:

- `<Accordion>` / `<AccordionGroup>` - Collapsible content
- `<Card>` / `<CardGroup>` / `<Columns>` - Visual containers
- `<CodeGroup>` - Tabbed code blocks
- `<Steps>` / `<Step>` - Sequential instructions
- `<Tabs>` / `<Tab>` - Tabbed content
- `<Note>`, `<Warning>`, `<Info>`, `<Tip>` - Callouts
- `<Frame>` - Image containers
- `<Icon>` - Inline icons
- `<Tooltip>` - Hover text

### 8.2 Mermaid Diagram Standards

```
Two-color scheme:
- Dark Red (#8B0000) - Agents, inputs, outputs
- Teal/Cyan (#189AB4) - Tools
- White text (#fff) for contrast
```

```mermaid
graph LR
    A[Input]:::agent --> B[Agent]:::agent
    B --> C[Tool]:::tool
    C --> D[Output]:::agent
    
    classDef agent fill:#8B0000,color:#fff
    classDef tool fill:#189AB4,color:#fff
```

### 8.3 Documentation Principles

| Principle | Description |
|-----------|-------------|
| **Beginner-friendly** | Non-developers should understand core concepts |
| **Copy-paste success** | Code examples must run with minimal setup |
| **Less text, more interaction** | Prefer components over long paragraphs |
| **Show, don't tell** | Use diagrams, tabs, and accordions to explain |
| **Few lines, big impact** | Examples should feel like "only 3 lines to do this" |

### 8.4 Page Title Conventions

```
SDK docs:     "Memory Module", "Tools Module", "Hooks Module"
API docs:     "Agent API", "Tool API", "Memory API"
Guides:       "Single Agent Guide", "Multi-Agent Guide"
Tutorials:    "Build a Research Agent", "Create Custom Tools"
```

### 8.5 Example Quality Standards

```
Every code example MUST:
- Run without modification (copy-paste success)
- Include necessary imports
- Use realistic but simple data
- Show expected output in comments
- Be the SHORTEST way to accomplish the task
```

---

## 9. Testing Standards

### 9.1 TDD Mandatory

```python
# 1. Write failing test first
def test_new_feature():
    result = new_feature()
    assert result == expected

# 2. Implement feature
# 3. Verify test passes
```

### 9.2 Test Structure

```
tests/
├── unit/                  # Fast, isolated tests
├── integration/           # Cross-module tests
├── e2e/                  # End-to-end tests
└── fixtures/             # Test data
```

### 9.3 Run Tests

```bash
# All tests
pytest tests/

# Specific category
pytest tests/unit/

# With coverage
pytest --cov=praisonaiagents tests/
```

### 9.4 Real Agentic Test (MANDATORY)

Every feature MUST include a real agentic test — not just smoke tests.

A **real agentic test** means the agent actually runs and calls the LLM:

```python
# ✅ REAL agentic test — agent runs end-to-end
from praisonaiagents import Agent
agent = Agent(name="test", instructions="You are a helpful assistant")
result = agent.start("Say hello in one sentence")
print(result)  # Must produce actual LLM output

# ❌ SMOKE test only — NOT sufficient alone
agent = Agent(name="test")  # Just object construction
assert agent.name == "test"  # No LLM call
```

**Rules:**
- Both smoke AND real agentic tests are required
- Agent MUST call `agent.start()` with a real prompt
- Agent MUST call the LLM and produce a text response
- Print full output so developers can verify end-to-end behavior

---

## 10. Implementation Checklist

For every feature/change:

- [ ] **Protocol-first**: Add protocol to core if needed
- [ ] **No new deps**: Use optional dependencies only
- [ ] **Lazy imports**: Heavy deps imported inside functions
- [ ] **Naming**: Follow conventions (add_*, get_*, XConfig)
- [ ] **Tests**: TDD — write failing tests first
- [ ] **Real agentic test**: Agent must call LLM end-to-end (§9.4)
- [ ] **CLI**: Add corresponding CLI command/option
- [ ] **YAML**: Ensure YAML config parity with Python API
- [ ] **Docs**: Update Mintlify documentation
- [ ] **Examples**: Add to examples/ directory
- [ ] **Multi-agent safe**: No shared mutable state
- [ ] **Async-safe**: Support async/await patterns
- [ ] **Performance**: No import-time or hot-path regressions

---

## 11. Quick Reference

### 11.1 Core Imports

```python
# Most common
from praisonaiagents import Agent, Agents, Task, tool, Tools

# Configuration
from praisonaiagents import (
    MemoryConfig, KnowledgeConfig, PlanningConfig,
    OutputConfig, ExecutionConfig, HooksConfig
)

# Hooks
from praisonaiagents.hooks import add_hook, before_tool, after_tool

# Event Bus
from praisonaiagents.bus import EventBus, get_default_bus

# Memory
from praisonaiagents import Memory, Session

# Workflows
from praisonaiagents import Workflow, Route, Parallel, Loop
```

### 11.2 File Locations

| What | Where |
|------|-------|
| Agent class | `praisonaiagents/agent/agent.py` |
| Tool decorator | `praisonaiagents/tools/decorator.py` |
| Base tool | `praisonaiagents/tools/base.py` |
| Hook system | `praisonaiagents/hooks/` |
| Memory protocols | `praisonaiagents/memory/protocols.py` |
| Event bus | `praisonaiagents/bus/bus.py` |
| Workflow engine | `praisonaiagents/workflows/workflows.py` |
| Policy engine | `praisonaiagents/policy/engine.py` |
| Scheduler module | `praisonaiagents/scheduler/` |
| Schedule tools | `praisonaiagents/tools/schedule_tools.py` |
| Agentic CLI (Typer) | `praisonai_code/cli/app.py` |
| CLI main / run | `praisonai_code/cli/main.py` |
| Warm runtime | `praisonai_code/runtime/` |
| CLI backends | `praisonai_code/cli_backends/` |
| Back-compat shims | `praisonai/cli/_shim.py`, `praisonai/cli/main.py` |
| C5 regression tests | `praisonai/tests/unit/test_c5_backward_compat.py` |
| TypeScript SDK | `src/praisonai-ts/` — see `src/praisonai-ts/AGENTS.md` |
| npm mirror (sync only) | [MervinPraison/praisonai-js](https://github.com/MervinPraison/praisonai-js) |

---

## 12. BotOS — Multi-Platform Bot Orchestration

### 12.1 Architecture

BotOS is the multi-platform bot orchestration layer for PraisonAI. It follows the same protocol-driven, agent-centric philosophy as the rest of the SDK.

```
┌──────────────────────────────────────────────────┐
│                    BotOS                          │
│   Multi-platform orchestrator (runs all bots)    │
├──────────┬──────────┬──────────┬─────────────────┤
│ Bot      │ Bot      │ Bot      │ Bot             │
│ telegram │ discord  │ slack    │ custom_platform │
├──────────┴──────────┴──────────┴─────────────────┤
│       Agent / AgentTeam / AgentFlow              │
│              (AI brain)                           │
└──────────────────────────────────────────────────┘
```

### 12.2 Layer Separation

| Layer | Package | Purpose |
|-------|---------|---------|
| `BotOSProtocol` | `praisonaiagents` (Core SDK) | Interface contract — lightweight |
| `BotOSConfig` | `praisonaiagents` (Core SDK) | Configuration dataclass |
| `Bot`, `BotOS`, adapters | `praisonai-bot` (Tier 2b) | Platform bots and multi-bot orchestration |
| `_registry` | `praisonai_bot.bots._registry` | Platform adapter registry (entry-point `praisonai.channels`) |
| Shims | `praisonai.bots` / `praisonai.gateway` | Backward-compat `alias_package` re-exports |

### 12.3 Usage Patterns

```python
# === Level 1: Single bot, 3 lines ===
from praisonai_bot.bots import Bot
from praisonaiagents import Agent

bot = Bot("telegram", agent=Agent(name="assistant", instructions="Be helpful"))
bot.run()

# Shims: ``from praisonai.bots import Bot`` still works when the wrapper is installed.

# === Level 2: Multi-platform, shared agent ===
from praisonai_bot.bots import BotOS
from praisonaiagents import Agent

agent = Agent(name="assistant", instructions="Be helpful")
botos = BotOS(agent=agent, platforms=["telegram", "discord"])
botos.run()

# === Level 3: AgentTeam in BotOS ===
from praisonai_bot.bots import BotOS, Bot
from praisonaiagents import Agent, AgentTeam, Task

researcher = Agent(name="researcher", instructions="Research topics")
writer = Agent(name="writer", instructions="Write content")
t1 = Task(name="research", description="Research AI", agent=researcher)
t2 = Task(name="write", description="Write about AI", agent=writer)
team = AgentTeam(agents=[researcher, writer], tasks=[t1, t2])

botos = BotOS(bots=[Bot("telegram", agent=team)])
botos.run()

# === Level 4: YAML config ===
botos = BotOS.from_config("botos.yaml")
botos.run()

# === Level 5: Custom platform extension ===
from praisonai.bots._registry import register_platform

class MyCustomBot:
    def __init__(self, **kwargs): ...
    async def start(self): ...
    async def stop(self): ...

register_platform("mychat", MyCustomBot)
bot = Bot("mychat", agent=agent, token="my-token")
bot.run()
```

### 12.4 Token Resolution

Tokens are resolved in order: `explicit token=` > env var > empty string.

| Platform | Env Var |
|----------|---------|
| Telegram | `TELEGRAM_BOT_TOKEN` |
| Discord | `DISCORD_BOT_TOKEN` |
| Slack | `SLACK_BOT_TOKEN` + `SLACK_APP_TOKEN` |
| WhatsApp | `WHATSAPP_ACCESS_TOKEN` + `WHATSAPP_PHONE_NUMBER_ID` |
| Custom | `{PLATFORM}_BOT_TOKEN` |

### 12.5 File Locations

| What | Where |
|------|-------|
| BotOSProtocol | `praisonaiagents/bots/protocols.py` |
| BotOSConfig | `praisonaiagents/bots/config.py` |
| Bot class | `praisonai_bot/bots/bot.py` (shim: `praisonai/bots/bot.py`) |
| BotOS class | `praisonai_bot/bots/botos.py` (shim: `praisonai/bots/botos.py`) |
| Platform registry | `praisonai_bot/bots/_registry.py` |
| Unit tests | `tests/unit/test_botos_protocol.py` |
| Integration tests | `tests/unit/test_botos_integration.py` |

### 12.6 Extending Platforms

Third-party platforms can be registered at runtime:

```python
from praisonai.bots._registry import register_platform, list_platforms

# Register
register_platform("line", LineBot)
register_platform("viber", ViberBot)

# Verify
print(list_platforms())  # [..., "line", "viber", ...]

# Use
bot = Bot("line", agent=agent, token="my-line-token")
```

**Adapter contract**: Custom adapters must implement `async start()` and `async stop()`. Optional: `send_message()`, `on_message()`, `on_command()`, `is_running` property.

### 12.7 YAML Config Format

```yaml
# botos.yaml
agent:
  name: assistant
  instructions: You are a helpful assistant.
  llm: gpt-4o-mini
platforms:
  telegram:
    token: ${TELEGRAM_BOT_TOKEN}
  discord:
    token: ${DISCORD_BOT_TOKEN}
  slack:
    token: ${SLACK_BOT_TOKEN}
    app_token: ${SLACK_APP_TOKEN}
```

---

## 13. Design Goals

> Make PraisonAI the **best agent framework in the world**

1. **Simpler** than competitors (fewer concepts, cleaner API)
2. **More extensible** (protocol-driven, plugin-ready)
3. **Faster** (lazy loading, minimal overhead)
4. **Safer** (guardrails, policies, HITL by default)
5. **Production-ready** (observability, checkpoints, replay)

---

## 14. Paid Value Path

The core remains **free and open source**. Clear upgrade paths to paid value:

| Free (Core) | Paid (Cloud/Services) |
|-------------|----------------------|
| All protocols | Managed hosting |
| All base classes | Enterprise support |
| Local execution | Budget management |
| File-based memory | Multi-tenant RBAC |
| Basic observability | Advanced analytics |
| Community support | SLA-backed support |

---

## 15. Context / Harness / Loop (CHL) Engineering

PraisonAI's reliability engineering rests on three pillars — **C**ontext, **H**arness, **L**oop. Full principles, cross-links, and the **measurable rubric** live in the docs: [`concepts/chl-engineering`](https://docs.praison.ai/concepts/chl-engineering) (source: `PraisonAIDocs/docs/concepts/chl-engineering.mdx`).

| Pillar | Meaning | Code anchors | Evaluator (rubric) |
|--------|---------|--------------|--------------------|
| **Context** | Budget, compaction, injection, handoff | `context/`, `compaction/`, `ContextAgent` | `ContextEvaluator` |
| **Harness** | Turn-context parity, traces, artifacts | `runtime/turn_context.py`, interactive test harness | `HarnessEvaluator` |
| **Loop** | Convergence, guardrails, efficiency | `eval/loop.py` (`EvaluationLoop`), `agent/autonomy.py` | `LoopEvaluator` |

**Rubric summary** (targets are defaults, configurable per project):

| Principle | Metric | Target |
|-----------|--------|--------|
| Context handoff | handoff score 0–10 | ≥ 8.0 |
| Context budget | tokens ≤ budget | 100% |
| Compaction loss | semantic retention (judge) | ≥ 7.0 |
| Harness parity | tool schema hash match | 100% |
| Harness artifacts | required files present | 100% |
| Loop convergence | iterations to threshold | ≤ N |
| Doom-loop safety | guard fires on repeat fixture | required |

> **Evaluator status.** The `ContextEvaluator` / `HarnessEvaluator` / `LoopEvaluator` classes named in the rubric are **planned follow-ups** (PA-CHL-001–004), not yet in the repo. Until they land, the equivalent checks are covered by existing modules:
>
> - **Context** — `context/tokens.py` and `eval/tokens.py` (`estimate_tokens` / `count_tokens`) for budget; `compaction/compactor.py` (`ContextCompactor`) for compaction/retention.
> - **Harness** — `runtime/turn_context.py` for turn-context parity; `examples/runtime/example_harness.py` and `tests/` for harness/artifact checks.
> - **Loop** — `eval/loop.py` (`EvaluationLoop`) and `agent/autonomy.py` for convergence and doom-loop guards.
>
> Keep terminology consistent with the `agent/context_agent.py` (`ContextAgent`) PRP methodology.

---

*This document is the source of truth for the PraisonAI SDK architecture and design principles.*
