### ORCHESTRATION PROCESS

from collections.abc import Iterator

# `third_party_api` is a fictional package representing a third-party library (or user code)
# providing APIs for launching and polling a process in some external environment.
from third_party_api import (  # type: ignore
    is_external_process_done,
    launch_external_process,
)

import dagster as dg


@dg.asset
def some_pipes_asset(
    context: dg.AssetExecutionContext,
) -> Iterator[dg.PipesExecutionResult]:
    with dg.open_pipes_session(
        context=context,
        extras={"foo": "bar"},
        context_injector=dg.PipesTempFileContextInjector(),
        message_reader=dg.PipesTempFileMessageReader(),
    ) as pipes_session:
        # Get the bootstrap payload encoded as a Dict[str, str] suitable for passage as environment
        # variables.
        env_vars = pipes_session.get_bootstrap_env_vars()

        # `launch_external_process` is responsible for including the passed `env_vars` in the
        # launched external process.
        external_process = launch_external_process(env_vars)

        # Continually poll the external process and stream any incrementally received messages back
        # to Dagster
        while not is_external_process_done(external_process):
            yield from pipes_session.get_results()

    # Yield any remaining results received from the external process.
    yield from pipes_session.get_results()
