from dagster_fivetran import FivetranWorkspace, build_fivetran_assets_definitions

import dagster as dg

# start_retry_on_reschedule
# When Fivetran reschedules a sync due to quota limits, the default behavior
# is to raise RetryRequested, which will retry the Dagster step after the
# rescheduled time. Set retry_on_reschedule=False to instead continue polling
# until the rescheduled sync completes.
fivetran_workspace = FivetranWorkspace(
    account_id=dg.EnvVar("FIVETRAN_ACCOUNT_ID"),
    api_key=dg.EnvVar("FIVETRAN_API_KEY"),
    api_secret=dg.EnvVar("FIVETRAN_API_SECRET"),
    retry_on_reschedule=False,
)
# end_retry_on_reschedule

all_fivetran_assets = build_fivetran_assets_definitions(workspace=fivetran_workspace)


@dg.definitions
def defs():
    return dg.Definitions(
        assets=all_fivetran_assets,
        resources={"fivetran": fivetran_workspace},
    )
