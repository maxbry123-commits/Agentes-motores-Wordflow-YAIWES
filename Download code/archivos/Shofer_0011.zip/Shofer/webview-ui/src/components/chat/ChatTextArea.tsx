import React, { forwardRef, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react"
import { useEvent } from "react-use"
import DynamicTextArea from "react-textarea-autosize"
import { VolumeX, Image, WandSparkles, SendHorizontal, X, ListEnd, Square } from "lucide-react"

import type { ExtensionMessage } from "@shofer/types"

import { mentionRegex, mentionRegexGlobal, commandRegexGlobal, unescapeSpaces } from "@shofer/types"
import { WebviewMessage } from "@shofer/types"
import { Mode, getAllModes } from "@shofer/types"

import { vscode } from "@src/utils/vscode"
import { useExtensionState } from "@src/context/ExtensionStateContext"
import { useAppTranslation } from "@src/i18n/TranslationContext"
import { type DroppedContextFile, extractUriPayload, parseDroppedUris } from "@src/utils/droppedContextFiles"
import {
	ContextMenuOptionType,
	getContextMenuOptions,
	insertMention,
	removeMention,
	shouldShowContextMenu,
	SearchResult,
} from "@src/utils/context-mentions"
import { cn } from "@src/lib/utils"
import { StandardTooltip } from "@src/components/ui"

import Thumbnails from "../common/Thumbnails"
import { ModeSelector } from "./ModeSelector"
import { ApiConfigSelector } from "./ApiConfigSelector"
import { AutoApproveDropdown } from "./AutoApproveDropdown"
import { CommandsButton } from "./CommandsButton"
import { SkillsButton } from "./SkillsButton"
import { PluginSlot } from "../plugins/PluginSlot"
import { MAX_IMAGES_PER_MESSAGE } from "./ChatView"
import ContextMenu from "./ContextMenu"
import { usePromptHistory } from "./hooks/usePromptHistory"
// CloudAccountSwitcher removed

interface ChatTextAreaProps {
	inputValue: string
	setInputValue: (value: string) => void
	sendingDisabled: boolean
	selectApiConfigDisabled: boolean
	placeholderText: string
	selectedImages: string[]
	setSelectedImages: React.Dispatch<React.SetStateAction<string[]>>
	onSend: () => void
	onSelectImages: () => void
	shouldDisableImages: boolean
	onHeightChange?: (height: number) => void
	mode: Mode
	setMode: (value: Mode) => void
	/**
	 * True when a task is currently focused. When false (home screen), the mode
	 * and API-config dropdowns act as pure tier-1 drafts owned by the webview:
	 * selecting a value updates local state only and is forwarded to the host on
	 * the next `newTask`, instead of mutating the global active profile/mode.
	 */
	hasActiveTask?: boolean
	modeShortcutText: string
	// Edit mode props
	isEditMode?: boolean
	onCancel?: () => void
	// Stop/Queue functionality
	isStreaming?: boolean
	/**
	 * True when the current task is in a state where the user should be
	 * able to abort it via the textarea Stop button. This is a superset of
	 * `isStreaming`: it also covers states like awaiting command approval
	 * or while a CLI command is mid-execution, where the underlying task
	 * is still active and stoppable but `isStreaming` is false because an
	 * approval ask is currently rendered. Per UX requirement: Stop must be
	 * possible at all times while a task is active.
	 */
	canStop?: boolean
	onStop?: () => void
	onEnqueueMessage?: () => void
	/**
	 * Called when path-style drops (Explorer files / editor tabs) land on
	 * the textarea.  ChatView uses this to populate the shared
	 * `droppedContextFiles` state.  This is the only drop path that
	 * actually fires inside VSCode Desktop's webview, where the cross-
	 * origin overlay swallows events that don't target a native
	 * form-control descendant.
	 */
	onContextFilesDropped?: (files: DroppedContextFile[]) => void
}

export const ChatTextArea = forwardRef<HTMLTextAreaElement, ChatTextAreaProps>(
	(
		{
			inputValue,
			setInputValue,
			selectApiConfigDisabled,
			placeholderText,
			selectedImages,
			setSelectedImages,
			onSend,
			onSelectImages,
			shouldDisableImages,
			onHeightChange,
			mode,
			setMode,
			hasActiveTask = false,
			modeShortcutText,
			isEditMode = false,
			onCancel,
			isStreaming = false,
			canStop = false,
			onStop,
			onEnqueueMessage,
			onContextFilesDropped,
		},
		ref,
	) => {
		const { t } = useAppTranslation()
		const {
			filePaths,
			openedTabs,
			currentApiConfigName,
			setCurrentApiConfigName,
			listApiConfigMeta,
			modeApiConfigs,
			customModes,
			customModePrompts,
			cwd,
			pinnedApiConfigs,
			togglePinnedApiConfig,
			taskHistory,
			shoferMessages,
			commands,
			cloudUserInfo,
			enterBehavior,
			lockApiConfigAcrossModes,
		} = useExtensionState()

		// Find the ID and display text for the currently selected API configuration.
		const { currentConfigId, displayName } = useMemo(() => {
			const currentConfig = listApiConfigMeta?.find((config) => config.name === currentApiConfigName)
			return {
				currentConfigId: currentConfig?.id || "",
				displayName: currentApiConfigName || "", // Use the name directly for display.
			}
		}, [listApiConfigMeta, currentApiConfigName])

		const [gitCommits, setGitCommits] = useState<any[]>([])
		const [showDropdown, setShowDropdown] = useState(false)
		const stopGuardRef = useRef(false)

		// Reset the stop guard when the task becomes non-stoppable (e.g. after
		// rehydration), so the button can be clicked again for the next task.
		useEffect(() => {
			if (!isStreaming && !canStop) {
				stopGuardRef.current = false
			}
		}, [isStreaming, canStop])

		const handleStop = useCallback(() => {
			if (stopGuardRef.current) {
				return // Already clicked — prevent duplicate cancelTask IPC
			}
			stopGuardRef.current = true
			onStop?.()
		}, [onStop])
		const [fileSearchResults, setFileSearchResults] = useState<SearchResult[]>([])
		const [searchLoading, setSearchLoading] = useState(false)
		const [searchRequestId, setSearchRequestId] = useState<string>("")

		// Close dropdown when clicking outside.
		useEffect(() => {
			const handleClickOutside = () => {
				if (showDropdown) {
					setShowDropdown(false)
				}
			}

			document.addEventListener("mousedown", handleClickOutside)
			return () => document.removeEventListener("mousedown", handleClickOutside)
		}, [showDropdown])

		// Handle enhanced prompt response and search results.
		useEffect(() => {
			const messageHandler = (event: MessageEvent) => {
				const message = event.data

				if (message.type === "enhancedPrompt") {
					if (message.text && textAreaRef.current) {
						try {
							// Use execCommand to replace text while preserving undo history
							if (document.execCommand) {
								// Use native browser methods to preserve undo stack
								const textarea = textAreaRef.current

								// Focus the textarea to ensure it's the active element
								textarea.focus()

								// Select all text first
								textarea.select()
								document.execCommand("insertText", false, message.text)
							} else {
								setInputValue(message.text)
							}
						} catch {
							setInputValue(message.text)
						}
					}

					setIsEnhancingPrompt(false)
				} else if (message.type === "insertTextIntoTextarea") {
					if (message.text && textAreaRef.current) {
						// Insert the command text at the current cursor position
						const textarea = textAreaRef.current
						const currentValue = inputValue
						const cursorPos = textarea.selectionStart || 0

						// Check if we need to add a space before the command
						const textBefore = currentValue.slice(0, cursorPos)
						const needsSpaceBefore = textBefore.length > 0 && !textBefore.endsWith(" ")
						const prefix = needsSpaceBefore ? " " : ""

						// Insert the text at cursor position
						const newValue =
							currentValue.slice(0, cursorPos) +
							prefix +
							message.text +
							" " +
							currentValue.slice(cursorPos)
						setInputValue(newValue)

						// Set cursor position after the inserted text
						const newCursorPos = cursorPos + prefix.length + message.text.length + 1
						setTimeout(() => {
							if (textAreaRef.current) {
								textAreaRef.current.focus()
								textAreaRef.current.setSelectionRange(newCursorPos, newCursorPos)
							}
						}, 0)
					}
				} else if (message.type === "commitSearchResults") {
					const commits = message.commits.map((commit: any) => ({
						type: ContextMenuOptionType.Git,
						value: commit.hash,
						label: commit.subject,
						description: `${commit.shortHash} by ${commit.author} on ${commit.date}`,
						icon: "$(git-commit)",
					}))

					setGitCommits(commits)
				} else if (message.type === "fileSearchResults") {
					setSearchLoading(false)
					if (message.requestId === searchRequestId) {
						setFileSearchResults(message.results || [])
					}
				}
			}

			window.addEventListener("message", messageHandler)
			return () => window.removeEventListener("message", messageHandler)
		}, [setInputValue, searchRequestId, inputValue])

		const [isDraggingOver, setIsDraggingOver] = useState(false)
		const [textAreaBaseHeight, setTextAreaBaseHeight] = useState<number | undefined>(undefined)
		const [showContextMenu, setShowContextMenu] = useState(false)
		const [cursorPosition, setCursorPosition] = useState(0)
		const [searchQuery, setSearchQuery] = useState("")
		const textAreaRef = useRef<HTMLTextAreaElement | null>(null)
		const [isMouseDownOnMenu, setIsMouseDownOnMenu] = useState(false)
		const highlightLayerRef = useRef<HTMLDivElement>(null)
		const [selectedMenuIndex, setSelectedMenuIndex] = useState(-1)
		const [selectedType, setSelectedType] = useState<ContextMenuOptionType | null>(null)
		const [justDeletedSpaceAfterMention, setJustDeletedSpaceAfterMention] = useState(false)
		const [intendedCursorPosition, setIntendedCursorPosition] = useState<number | null>(null)
		const contextMenuContainerRef = useRef<HTMLDivElement>(null)
		const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false)
		const [isFocused, setIsFocused] = useState(false)

		// Use custom hook for prompt history navigation
		const { handleHistoryNavigation, resetHistoryNavigation, resetOnInputChange } = usePromptHistory({
			shoferMessages,
			taskHistory,
			cwd,
			inputValue,
			setInputValue,
		})

		// Fetch git commits when Git is selected or when typing a hash.
		useEffect(() => {
			if (selectedType === ContextMenuOptionType.Git || /^[a-f0-9]+$/i.test(searchQuery)) {
				const message: WebviewMessage = {
					type: "searchCommits",
					query: searchQuery || "",
				} as const
				vscode.postMessage(message)
			}
		}, [selectedType, searchQuery])

		const handleEnhancePrompt = useCallback(() => {
			const trimmedInput = inputValue.trim()

			if (trimmedInput) {
				setIsEnhancingPrompt(true)
				vscode.postMessage({ type: "enhancePrompt" as const, text: trimmedInput })
			} else {
				setInputValue(t("chat:enhancePromptDescription"))
			}
		}, [inputValue, setInputValue, t])

		const allModes = useMemo(() => getAllModes(customModes), [customModes])

		// Memoized check for whether the input has content (text or images)
		const hasInputContent = useMemo(() => {
			return inputValue.trim().length > 0 || selectedImages.length > 0
		}, [inputValue, selectedImages])

		// Disambiguate WHY images are disabled. `shouldDisableImages` is true
		// either because the selected model lacks vision OR the per-message cap
		// is reached. A non-vision model can never have accumulated images (paste/
		// drop/pick are all blocked), so a non-empty `selectedImages` at the cap is
		// the only way to be disabled-by-cap.
		const imagesDisabledByCap = shouldDisableImages && selectedImages.length >= MAX_IMAGES_PER_MESSAGE
		const imageButtonTooltip = !shouldDisableImages
			? t("chat:addImages")
			: imagesDisabledByCap
				? t("chat:maxImagesReached", { count: MAX_IMAGES_PER_MESSAGE })
				: t("chat:imagesNotSupportedByModel")

		// Transient inline notice shown when a paste/drop of an image is rejected,
		// so the rejection is never silent. Auto-clears after a few seconds.
		const [imageRejectedNotice, setImageRejectedNotice] = useState<string | null>(null)
		const imageRejectedTimeoutRef = useRef<number | null>(null)
		const notifyImagesRejected = useCallback(() => {
			const message = imagesDisabledByCap
				? t("chat:imagesRejectedMaxReached", { count: MAX_IMAGES_PER_MESSAGE })
				: t("chat:imagesRejectedNotSupported")
			setImageRejectedNotice(message)
			if (imageRejectedTimeoutRef.current !== null) {
				window.clearTimeout(imageRejectedTimeoutRef.current)
			}
			imageRejectedTimeoutRef.current = window.setTimeout(() => {
				setImageRejectedNotice(null)
				imageRejectedTimeoutRef.current = null
			}, 4000)
		}, [imagesDisabledByCap, t])
		useEffect(() => {
			return () => {
				if (imageRejectedTimeoutRef.current !== null) {
					window.clearTimeout(imageRejectedTimeoutRef.current)
				}
			}
		}, [])

		// Compute the key combination text for the send button tooltip based on enterBehavior
		const sendKeyCombination = useMemo(() => {
			if (enterBehavior === "newline") {
				// When Enter = newline, Ctrl/Cmd+Enter sends
				const isMac = navigator.platform.toUpperCase().indexOf("MAC") >= 0
				return isMac ? "⌘+Enter" : "Ctrl+Enter"
			}
			// Default: Enter sends
			return "Enter"
		}, [enterBehavior])

		const queryItems = useMemo(() => {
			return [
				{ type: ContextMenuOptionType.Problems, value: "problems" },
				{ type: ContextMenuOptionType.Terminal, value: "terminal" },
				...gitCommits,
				...openedTabs
					.filter((tab) => tab.path)
					.map((tab) => ({
						type: ContextMenuOptionType.OpenedFile,
						value: "/" + tab.path,
					})),
				...filePaths
					.map((file) => "/" + file)
					.filter((path) => !openedTabs.some((tab) => tab.path && "/" + tab.path === path)) // Filter out paths that are already in openedTabs
					.map((path) => ({
						type: path.endsWith("/") ? ContextMenuOptionType.Folder : ContextMenuOptionType.File,
						value: path,
					})),
			]
		}, [filePaths, gitCommits, openedTabs])

		useEffect(() => {
			const handleClickOutside = (event: MouseEvent) => {
				if (
					contextMenuContainerRef.current &&
					!contextMenuContainerRef.current.contains(event.target as Node)
				) {
					setShowContextMenu(false)
				}
			}

			if (showContextMenu) {
				document.addEventListener("mousedown", handleClickOutside)
			}

			return () => {
				document.removeEventListener("mousedown", handleClickOutside)
			}
		}, [showContextMenu, setShowContextMenu])

		const handleMentionSelect = useCallback(
			(type: ContextMenuOptionType, value?: string) => {
				if (type === ContextMenuOptionType.NoResults) {
					return
				}

				if (type === ContextMenuOptionType.Mode && value) {
					// Handle mode selection.
					setMode(value)
					setInputValue("")
					setShowContextMenu(false)
					// Scope to the focused task when present; on the home screen the
					// selection is a pure tier-1 draft (forwarded via `newTask`).
					if (hasActiveTask) {
						vscode.postMessage({ type: "mode", text: value })
					}
					return
				}

				if (type === ContextMenuOptionType.Command && value) {
					// Handle command selection.
					setSelectedMenuIndex(-1)
					setInputValue("")
					setShowContextMenu(false)

					// Insert the command mention into the textarea
					const commandMention = `/${value}`
					setInputValue(commandMention + " ")
					setCursorPosition(commandMention.length + 1)
					setIntendedCursorPosition(commandMention.length + 1)

					// Focus the textarea
					setTimeout(() => {
						if (textAreaRef.current) {
							textAreaRef.current.focus()
						}
					}, 0)
					return
				}

				if (
					type === ContextMenuOptionType.File ||
					type === ContextMenuOptionType.Folder ||
					type === ContextMenuOptionType.Git
				) {
					if (!value) {
						setSelectedType(type)
						setSearchQuery("")
						setSelectedMenuIndex(0)
						return
					}
				}

				setShowContextMenu(false)
				setSelectedType(null)

				if (textAreaRef.current) {
					let insertValue = value || ""

					if (type === ContextMenuOptionType.URL) {
						insertValue = value || ""
					} else if (type === ContextMenuOptionType.File || type === ContextMenuOptionType.Folder) {
						insertValue = value || ""
					} else if (type === ContextMenuOptionType.Problems) {
						insertValue = "problems"
					} else if (type === ContextMenuOptionType.Terminal) {
						insertValue = "terminal"
					} else if (type === ContextMenuOptionType.Git) {
						insertValue = value || ""
					} else if (type === ContextMenuOptionType.Command) {
						insertValue = value ? `/${value}` : ""
					}

					// Determine if this is a slash command selection
					const isSlashCommand = type === ContextMenuOptionType.Mode || type === ContextMenuOptionType.Command

					const { newValue, mentionIndex } = insertMention(
						textAreaRef.current.value,
						cursorPosition,
						insertValue,
						isSlashCommand,
					)

					setInputValue(newValue)
					const newCursorPosition = newValue.indexOf(" ", mentionIndex + insertValue.length) + 1
					setCursorPosition(newCursorPosition)
					setIntendedCursorPosition(newCursorPosition)

					// Scroll to cursor.
					setTimeout(() => {
						if (textAreaRef.current) {
							textAreaRef.current.blur()
							textAreaRef.current.focus()
						}
					}, 0)
				}
			},
			// eslint-disable-next-line react-hooks/exhaustive-deps
			[setInputValue, cursorPosition, hasActiveTask],
		)

		const handleKeyDown = useCallback(
			(event: React.KeyboardEvent<HTMLTextAreaElement>) => {
				if (showContextMenu) {
					if (event.key === "Escape") {
						setSelectedType(null)
						setSelectedMenuIndex(3) // File by default
						return
					}

					if (event.key === "ArrowUp" || event.key === "ArrowDown") {
						event.preventDefault()
						setSelectedMenuIndex((prevIndex) => {
							const direction = event.key === "ArrowUp" ? -1 : 1
							const options = getContextMenuOptions(
								searchQuery,
								selectedType,
								queryItems,
								fileSearchResults,
								allModes,
								commands,
							)
							const optionsLength = options.length

							if (optionsLength === 0) return prevIndex

							// Find selectable options (non-URL types)
							const selectableOptions = options.filter(
								(option) =>
									option.type !== ContextMenuOptionType.URL &&
									option.type !== ContextMenuOptionType.NoResults &&
									option.type !== ContextMenuOptionType.SectionHeader,
							)

							if (selectableOptions.length === 0) return -1 // No selectable options

							// Find the index of the next selectable option
							const currentSelectableIndex = selectableOptions.findIndex(
								(option) => option === options[prevIndex],
							)

							const newSelectableIndex =
								(currentSelectableIndex + direction + selectableOptions.length) %
								selectableOptions.length

							// Find the index of the selected option in the original options array
							return options.findIndex((option) => option === selectableOptions[newSelectableIndex])
						})
						return
					}
					if ((event.key === "Enter" || event.key === "Tab") && selectedMenuIndex !== -1) {
						event.preventDefault()
						const selectedOption = getContextMenuOptions(
							searchQuery,
							selectedType,
							queryItems,
							fileSearchResults,
							allModes,
							commands,
						)[selectedMenuIndex]
						if (
							selectedOption &&
							selectedOption.type !== ContextMenuOptionType.URL &&
							selectedOption.type !== ContextMenuOptionType.NoResults &&
							selectedOption.type !== ContextMenuOptionType.SectionHeader
						) {
							handleMentionSelect(selectedOption.type, selectedOption.value)
						}
						return
					}
				}

				const isComposing = event.nativeEvent?.isComposing ?? false

				// Handle prompt history navigation using custom hook
				if (handleHistoryNavigation(event, showContextMenu, isComposing)) {
					return
				}

				// Handle Enter key based on enterBehavior setting
				if (event.key === "Enter" && !isComposing) {
					if (enterBehavior === "newline") {
						// New behavior: Enter = newline, Shift+Enter or Ctrl+Enter = send
						if (event.shiftKey || event.ctrlKey || event.metaKey) {
							event.preventDefault()
							resetHistoryNavigation()
							onSend()
						}
						// Otherwise, let Enter create newline (don't preventDefault)
					} else {
						// Default behavior: Enter = send, Shift+Enter = newline
						if (!event.shiftKey) {
							event.preventDefault()
							resetHistoryNavigation()
							onSend()
						}
					}
				}

				if (event.key === "Backspace" && !isComposing) {
					const charBeforeCursor = inputValue[cursorPosition - 1]
					const charAfterCursor = inputValue[cursorPosition + 1]

					const charBeforeIsWhitespace =
						charBeforeCursor === " " || charBeforeCursor === "\n" || charBeforeCursor === "\r\n"

					const charAfterIsWhitespace =
						charAfterCursor === " " || charAfterCursor === "\n" || charAfterCursor === "\r\n"

					// Checks if char before cursor is whitespace after a mention.
					if (
						charBeforeIsWhitespace &&
						// "$" is added to ensure the match occurs at the end of the string.
						inputValue.slice(0, cursorPosition - 1).match(new RegExp(mentionRegex.source + "$"))
					) {
						const newCursorPosition = cursorPosition - 1
						// If mention is followed by another word, then instead
						// of deleting the space separating them we just move
						// the cursor to the end of the mention.
						if (!charAfterIsWhitespace) {
							event.preventDefault()
							textAreaRef.current?.setSelectionRange(newCursorPosition, newCursorPosition)
							setCursorPosition(newCursorPosition)
						}

						setCursorPosition(newCursorPosition)
						setJustDeletedSpaceAfterMention(true)
					} else if (justDeletedSpaceAfterMention) {
						const { newText, newPosition } = removeMention(inputValue, cursorPosition)

						if (newText !== inputValue) {
							event.preventDefault()
							setInputValue(newText)
							setIntendedCursorPosition(newPosition) // Store the new cursor position in state
						}

						setJustDeletedSpaceAfterMention(false)
						setShowContextMenu(false)
					} else {
						setJustDeletedSpaceAfterMention(false)
					}
				}
			},
			[
				onSend,
				showContextMenu,
				searchQuery,
				selectedMenuIndex,
				handleMentionSelect,
				selectedType,
				inputValue,
				cursorPosition,
				setInputValue,
				justDeletedSpaceAfterMention,
				queryItems,
				allModes,
				fileSearchResults,
				handleHistoryNavigation,
				resetHistoryNavigation,
				commands,
				enterBehavior,
			],
		)

		useLayoutEffect(() => {
			if (intendedCursorPosition !== null && textAreaRef.current) {
				textAreaRef.current.setSelectionRange(intendedCursorPosition, intendedCursorPosition)
				setIntendedCursorPosition(null) // Reset the state.
			}
		}, [inputValue, intendedCursorPosition])

		// Ref to store the search timeout.
		const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null)

		const handleInputChange = useCallback(
			(e: React.ChangeEvent<HTMLTextAreaElement>) => {
				const newValue = e.target.value
				setInputValue(newValue)

				// Reset history navigation when user types
				resetOnInputChange()

				const newCursorPosition = e.target.selectionStart
				setCursorPosition(newCursorPosition)

				const showMenu = shouldShowContextMenu(newValue, newCursorPosition)
				setShowContextMenu(showMenu)

				if (showMenu) {
					if (newValue.startsWith("/") && !newValue.includes(" ")) {
						// Handle slash command - request fresh commands
						const query = newValue
						setSearchQuery(query)
						// Set to first selectable item (skip section headers)
						setSelectedMenuIndex(1) // Section header is at 0, first command is at 1
						// Request commands fresh each time slash menu is shown
						vscode.postMessage({ type: "requestCommands" })
					} else {
						// Existing @ mention handling.
						const lastAtIndex = newValue.lastIndexOf("@", newCursorPosition - 1)
						const query = newValue.slice(lastAtIndex + 1, newCursorPosition)
						setSearchQuery(query)

						// Send file search request if query is not empty.
						if (query.length > 0) {
							setSelectedMenuIndex(0)

							// Don't clear results until we have new ones. This
							// prevents flickering.

							// Clear any existing timeout.
							if (searchTimeoutRef.current) {
								clearTimeout(searchTimeoutRef.current)
							}

							// Set a timeout to debounce the search requests.
							searchTimeoutRef.current = setTimeout(() => {
								// Generate a request ID for this search.
								const reqId = Math.random().toString(36).substring(2, 9)
								setSearchRequestId(reqId)
								setSearchLoading(true)

								// Send message to extension to search files.
								vscode.postMessage({
									type: "grepSearch",
									query: unescapeSpaces(query),
									requestId: reqId,
								})
							}, 200) // 200ms debounce.
						} else {
							setSelectedMenuIndex(3) // Set to "File" option by default.
						}
					}
				} else {
					setSearchQuery("")
					setSelectedMenuIndex(-1)
					setFileSearchResults([]) // Clear file search results.
				}
			},
			[setInputValue, setSearchRequestId, setFileSearchResults, setSearchLoading, resetOnInputChange],
		)

		useEffect(() => {
			if (!showContextMenu) {
				setSelectedType(null)
			}
		}, [showContextMenu])

		const handleBlur = useCallback(() => {
			// Only hide the context menu if the user didn't click on it.
			if (!isMouseDownOnMenu) {
				setShowContextMenu(false)
			}

			setIsFocused(false)
		}, [isMouseDownOnMenu])

		const handlePaste = useCallback(
			async (e: React.ClipboardEvent) => {
				const items = e.clipboardData.items

				// Log all clipboard MIME types for debugging paste issues.
				const itemTypes = Array.from(items).map((item) => item.type)
				vscode.postMessage({ type: "webviewLog", text: `[paste] items: ${JSON.stringify(itemTypes)}` })

				const pastedText = e.clipboardData.getData("text")
				const urlRegex = /^\S+:\/\/\S+$/
				if (urlRegex.test(pastedText.trim())) {
					e.preventDefault()
					const trimmedUrl = pastedText.trim()
					const newValue =
						inputValue.slice(0, cursorPosition) + trimmedUrl + " " + inputValue.slice(cursorPosition)
					setInputValue(newValue)
					const newCursorPosition = cursorPosition + trimmedUrl.length + 1
					setCursorPosition(newCursorPosition)
					setIntendedCursorPosition(newCursorPosition)
					setShowContextMenu(false)

					// Scroll to new cursor position.
					setTimeout(() => {
						if (textAreaRef.current) {
							textAreaRef.current.blur()
							textAreaRef.current.focus()
						}
					}, 0)

					return
				}

				const acceptedTypes = ["png", "jpeg", "webp"]

				const imageItems = Array.from(items).filter((item) => {
					const [type, subtype] = item.type.split("/")
					return type === "image" && acceptedTypes.includes(subtype)
				})

				if (shouldDisableImages && imageItems.length > 0) {
					// Surface a visible reason instead of silently dropping the paste.
					notifyImagesRejected()
					vscode.postMessage({
						type: "webviewLog",
						text: `[paste] images disabled, imageItems=${imageItems.length}`,
					})
				}

				if (!shouldDisableImages && imageItems.length > 0) {
					vscode.postMessage({ type: "webviewLog", text: `[paste] processing ${imageItems.length} image(s)` })
					e.preventDefault()

					const imagePromises = imageItems.map((item) => {
						return new Promise<string | null>((resolve) => {
							const blob = item.getAsFile()

							if (!blob) {
								resolve(null)
								return
							}

							const reader = new FileReader()

							reader.onloadend = () => {
								if (reader.error) {
									console.error(t("chat:errorReadingFile"), reader.error)
									resolve(null)
								} else {
									const result = reader.result
									resolve(typeof result === "string" ? result : null)
								}
							}

							reader.readAsDataURL(blob)
						})
					})

					const imageDataArray = await Promise.all(imagePromises)
					const dataUrls = imageDataArray.filter((dataUrl): dataUrl is string => dataUrl !== null)

					if (dataUrls.length > 0) {
						setSelectedImages((prevImages) => [...prevImages, ...dataUrls].slice(0, MAX_IMAGES_PER_MESSAGE))
						vscode.postMessage({ type: "webviewLog", text: `[paste] added ${dataUrls.length} image(s)` })
					} else {
						console.warn(t("chat:noValidImages"))
						vscode.postMessage({ type: "webviewLog", text: "[paste] no valid images extracted" })
					}
				} else if (imageItems.length === 0) {
					// No images found — text paste falls through to browser default.
					vscode.postMessage({
						type: "webviewLog",
						text: `[paste] text paste (${pastedText.length} chars), letting browser handle`,
					})
				}
			},
			[
				shouldDisableImages,
				setSelectedImages,
				cursorPosition,
				setInputValue,
				inputValue,
				t,
				notifyImagesRejected,
			],
		)

		const handleMenuMouseDown = useCallback(() => {
			setIsMouseDownOnMenu(true)
		}, [])

		const updateHighlights = useCallback(() => {
			if (!textAreaRef.current || !highlightLayerRef.current) return

			const text = textAreaRef.current.value

			// Helper function to check if a command is valid
			const isValidCommand = (commandName: string): boolean => {
				return commands?.some((cmd) => cmd.name === commandName) || false
			}

			// Process the text to highlight mentions and valid commands
			let processedText = text
				.replace(/\n$/, "\n\n")
				.replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c] || c)
				.replace(mentionRegexGlobal, '<mark class="mention-context-textarea-highlight">$&</mark>')

			// Custom replacement for commands - only highlight valid ones
			processedText = processedText.replace(commandRegexGlobal, (match, commandName) => {
				// Only highlight if the command exists in the valid commands list
				if (isValidCommand(commandName)) {
					// Check if the match starts with a space
					const startsWithSpace = match.startsWith(" ")
					const commandPart = `/${commandName}`

					if (startsWithSpace) {
						// Keep the space but only highlight the command part
						return ` <mark class="mention-context-textarea-highlight">${commandPart}</mark>`
					} else {
						// Highlight the entire command (starts at beginning of line)
						return `<mark class="mention-context-textarea-highlight">${commandPart}</mark>`
					}
				}
				return match // Return unhighlighted if command is not valid
			})

			highlightLayerRef.current.innerHTML = processedText

			highlightLayerRef.current.scrollTop = textAreaRef.current.scrollTop
			highlightLayerRef.current.scrollLeft = textAreaRef.current.scrollLeft
		}, [commands])

		useLayoutEffect(() => {
			updateHighlights()
		}, [inputValue, updateHighlights])

		const updateCursorPosition = useCallback(() => {
			if (textAreaRef.current) {
				setCursorPosition(textAreaRef.current.selectionStart)
			}
		}, [])

		const handleKeyUp = useCallback(
			(e: React.KeyboardEvent<HTMLTextAreaElement>) => {
				if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End"].includes(e.key)) {
					updateCursorPosition()
				}
			},
			[updateCursorPosition],
		)

		/**
		 * Handle drops on the textarea container.
		 *
		 * VSCode Desktop's cross-origin webview overlay swallows drag events
		 * that target the iframe root, but it *does* deliver them to native
		 * form-control descendants — the textarea container is therefore the
		 * only reliable drop target on Desktop.  We handle two payloads here:
		 *
		 *  1. Path-style drops (Explorer files, editor tabs):
		 *     Parsed via the shared `extractUriPayload` / `parseDroppedUris`
		 *     helpers and forwarded to ChatView via `onContextFilesDropped`,
		 *     which appends them to the same `droppedContextFiles` state used
		 *     by the webview-root drop handler.
		 *
		 *  2. Image file drops (PNG/JPEG/WebP from the OS file manager):
		 *     Read as data URLs and added to `selectedImages`.
		 *
		 * Image pastes (Ctrl+V) go through `handlePaste` instead.
		 */
		const handleDrop = useCallback(
			async (e: React.DragEvent<HTMLDivElement>) => {
				e.preventDefault()
				setIsDraggingOver(false)

				// Log all MIME types and modifier keys for debugging drop
				// issues (e.g. Alt+drag from Explorer on Linux, where the
				// window manager may consume Alt before VSCode sees it, and
				// VSCode's cross-origin overlay may deliver different MIME
				// types depending on the modifier).
				const dt = e.dataTransfer
				const dtTypes = Array.from(dt.types)
				const samplePayloads: Record<string, string> = {}
				for (const t of dtTypes) {
					try {
						const val = dt.getData(t)
						if (val) {
							samplePayloads[t] = val.length > 400 ? val.slice(0, 400) + "…" : val
						}
					} catch {
						// best-effort
					}
				}
				vscode.postMessage({
					type: "webviewLog",
					text: `[drop:textarea] fired alt=${e.altKey} ctrl=${e.ctrlKey} shift=${e.shiftKey} meta=${e.metaKey} types=[${dtTypes.join(",")}] files=${dt.files.length} payloads=${JSON.stringify(samplePayloads)}`,
				})

				// 1. Path-style drops first — these never carry a `files` list,
				//    only a URI/text payload.
				const payload = extractUriPayload(e.dataTransfer)
				if (payload && onContextFilesDropped) {
					vscode.postMessage({
						type: "webviewLog",
						text: `[drop:textarea] extracted payload (${payload.length}ch): ${payload.length > 300 ? payload.slice(0, 300) + "…" : payload}`,
					})
					const newFiles = parseDroppedUris(payload, cwd, [])
					if (newFiles.length > 0) {
						vscode.postMessage({
							type: "webviewLog",
							text: `[drop:textarea] parsed ${newFiles.length} file(s): ${newFiles.map((f) => f.path).join(", ")}`,
						})
						onContextFilesDropped(newFiles)
						return
					}
					vscode.postMessage({
						type: "webviewLog",
						text: `[drop:textarea] parseDroppedUris returned 0 files from payload`,
					})
				}

				// 2. Image file drops.
				const acceptedTypes = ["png", "jpeg", "webp"]
				const files = Array.from(e.dataTransfer.files)
				if (files.length === 0 || shouldDisableImages) {
					// If actual image files were dropped on a model that can't take
					// them, surface a visible reason instead of silently ignoring.
					if (
						shouldDisableImages &&
						files.some((file) => {
							const [type, subtype] = file.type.split("/")
							return type === "image" && acceptedTypes.includes(subtype)
						})
					) {
						notifyImagesRejected()
					}
					if (files.length === 0 && !payload) {
						vscode.postMessage({
							type: "webviewLog",
							text: `[drop:textarea] no payload and no files — drop ignored`,
						})
					}
					return
				}

				const imageFiles = files.filter((file) => {
					const [type, subtype] = file.type.split("/")
					return type === "image" && acceptedTypes.includes(subtype)
				})
				if (imageFiles.length === 0) {
					vscode.postMessage({
						type: "webviewLog",
						text: `[drop:textarea] ${files.length} file(s) but none are accepted image types`,
					})
					return
				}

				const imagePromises = imageFiles.map((file) => {
					return new Promise<string | null>((resolve) => {
						const reader = new FileReader()
						reader.onloadend = () => {
							if (reader.error) {
								console.error(t("chat:errorReadingFile"), reader.error)
								resolve(null)
							} else {
								const result = reader.result
								resolve(typeof result === "string" ? result : null)
							}
						}
						reader.readAsDataURL(file)
					})
				})

				const imageDataArray = await Promise.all(imagePromises)
				const dataUrls = imageDataArray.filter((dataUrl): dataUrl is string => dataUrl !== null)

				if (dataUrls.length > 0) {
					setSelectedImages((prevImages) => [...prevImages, ...dataUrls].slice(0, MAX_IMAGES_PER_MESSAGE))
					vscode.postMessage({ type: "draggedImages", dataUrls })
				} else {
					console.warn(t("chat:noValidImages"))
				}
			},
			[cwd, onContextFilesDropped, shouldDisableImages, setSelectedImages, t, notifyImagesRejected],
		)

		const [isTtsPlaying, setIsTtsPlaying] = useState(false)

		useEvent("message", (event: MessageEvent) => {
			const message: ExtensionMessage = event.data

			if (message.type === "ttsStart") {
				setIsTtsPlaying(true)
			} else if (message.type === "ttsStop") {
				setIsTtsPlaying(false)
			}
		})

		const placeholderBottomText = `\n(${t("chat:addContext")}${shouldDisableImages ? `, ${t("chat:dragFiles")}` : `, ${t("chat:dragFilesImages")}`})`

		// Common mode selector handler
		const handleModeChange = useCallback(
			(value: Mode) => {
				setMode(value)
				// With a focused task, the mode switch is scoped to that task on the
				// host. On the home screen the selection is a pure tier-1 draft that
				// rides along with the next `newTask`, so no host round-trip. The
				// home-screen effect below keeps the API-config draft in sync with the
				// mode's association.
				if (hasActiveTask) {
					vscode.postMessage({ type: "mode", text: value })
				}
			},
			[setMode, hasActiveTask],
		)

		// Home screen (no focused task): keep the API-config draft pointed at the
		// active mode's association (modeApiConfigs[mode]) so a new task started on a
		// mode uses that mode's profile — even when the mode was not just changed
		// (e.g. carried over from a previous session, or after returning from a task).
		// Keyed on the resolved config *id* (a stable primitive) rather than the
		// modeApiConfigs object, which is a fresh reference on every state push — that
		// keeps a manual selector override (which changes only currentApiConfigName,
		// not the mode) from being clobbered on the next state update.
		const modeConfigId = modeApiConfigs?.[mode]
		useEffect(() => {
			if (hasActiveTask) {
				return
			}
			const name = modeConfigId ? listApiConfigMeta?.find((c) => c.id === modeConfigId)?.name : undefined
			if (name && name !== currentApiConfigName) {
				setCurrentApiConfigName(name)
			}
			// currentApiConfigName is intentionally omitted: a manual override must
			// persist until the mode (and thus modeConfigId) changes.
			// eslint-disable-next-line react-hooks/exhaustive-deps
		}, [mode, hasActiveTask, modeConfigId])

		// Helper function to handle API config change
		const handleApiConfigChange = useCallback(
			(value: string) => {
				if (hasActiveTask) {
					// Active task: scope the profile change to THIS task only. The host
					// rebinds the task's API handler + sticky profile without activating
					// the profile globally, so the default for future new tasks
					// (Settings → Provider) is left untouched.
					vscode.postMessage({ type: "setTaskApiConfiguration", text: value })
					return
				}
				// Home screen: pure tier-1 draft. Map the selected config id back to
				// its name and update local state only; the global active profile is
				// untouched and the choice is forwarded with the next `newTask`.
				const selected = listApiConfigMeta?.find((config) => config.id === value)
				if (selected?.name) {
					setCurrentApiConfigName(selected.name)
				}
			},
			[hasActiveTask, listApiConfigMeta, setCurrentApiConfigName],
		)

		const handleToggleLockApiConfig = useCallback(() => {
			const newValue = !lockApiConfigAcrossModes
			vscode.postMessage({ type: "lockApiConfigAcrossModes", bool: newValue })
		}, [lockApiConfigAcrossModes])

		return (
			<div
				className={cn(
					"flex flex-col gap-1 bg-editor-background outline-none border border-none box-border",
					isEditMode ? "p-2 w-full" : "relative px-1.5 pb-1 w-[calc(100%-16px)] ml-auto mr-auto",
				)}>
				<div className={cn(!isEditMode && "relative")}>
					<div
						className={cn("chat-text-area", !isEditMode && "relative", "flex", "flex-col", "outline-none")}
						onDrop={handleDrop}
						onDragOver={(e) => {
							e.preventDefault()
							setIsDraggingOver(true)
							e.dataTransfer.dropEffect = "copy"
						}}
						onDragLeave={(e) => {
							e.preventDefault()
							const rect = e.currentTarget.getBoundingClientRect()

							if (
								e.clientX <= rect.left ||
								e.clientX >= rect.right ||
								e.clientY <= rect.top ||
								e.clientY >= rect.bottom
							) {
								setIsDraggingOver(false)
							}
						}}>
						{showContextMenu && (
							<div
								ref={contextMenuContainerRef}
								className={cn(
									"absolute",
									"bottom-full",
									isEditMode ? "left-6" : "left-0",
									"right-0",
									"z-[1000]",
									isEditMode ? "-mb-3" : "mb-2",
									"filter",
									"drop-shadow-md",
								)}>
								<ContextMenu
									onSelect={handleMentionSelect}
									searchQuery={searchQuery}
									inputValue={inputValue}
									onMouseDown={handleMenuMouseDown}
									selectedIndex={selectedMenuIndex}
									setSelectedIndex={setSelectedMenuIndex}
									selectedType={selectedType}
									queryItems={queryItems}
									modes={allModes}
									loading={searchLoading}
									dynamicSearchResults={fileSearchResults}
									commands={commands}
								/>
							</div>
						)}

						<div
							className={cn(
								"relative",
								"flex-1",
								"flex",
								"flex-col-reverse",
								"min-h-0",
								"overflow-hidden",
								"rounded-lg",
							)}>
							<div
								ref={highlightLayerRef}
								data-testid="highlight-layer"
								className={cn(
									"absolute",
									"inset-0",
									"pointer-events-none",
									"whitespace-pre-wrap",
									"break-words",
									"text-transparent",
									"overflow-hidden",
									"font-vscode-font-family",
									"text-vscode-editor-font-size",
									"leading-vscode-editor-line-height",
									isFocused
										? "border border-vscode-focusBorder outline outline-vscode-focusBorder"
										: isDraggingOver
											? "border-2 border-dashed border-vscode-focusBorder"
											: "border border-transparent",
									"pl-2",
									"py-2",
									isEditMode ? "pr-20" : "pr-9",
									"z-10",
									"forced-color-adjust-none",
									"rounded-lg",
								)}
								style={{
									color: "transparent",
								}}
							/>
							<DynamicTextArea
								ref={(el) => {
									if (typeof ref === "function") {
										ref(el)
									} else if (ref) {
										ref.current = el
									}
									textAreaRef.current = el
								}}
								value={inputValue}
								onChange={(e) => {
									handleInputChange(e)
									updateHighlights()
								}}
								onFocus={() => setIsFocused(true)}
								onKeyDown={(e) => {
									// Handle ESC to cancel in edit mode
									if (isEditMode && e.key === "Escape" && !e.nativeEvent?.isComposing) {
										e.preventDefault()
										onCancel?.()
										return
									}
									handleKeyDown(e)
								}}
								onKeyUp={handleKeyUp}
								onBlur={handleBlur}
								onPaste={handlePaste}
								onSelect={updateCursorPosition}
								onMouseUp={updateCursorPosition}
								onHeightChange={(height) => {
									if (textAreaBaseHeight === undefined || height < textAreaBaseHeight) {
										setTextAreaBaseHeight(height)
									}

									onHeightChange?.(height)
								}}
								placeholder={placeholderText}
								minRows={3}
								maxRows={15}
								autoFocus={true}
								className={cn(
									"w-full",
									"text-vscode-input-foreground",
									"font-vscode-font-family",
									"text-vscode-editor-font-size",
									"leading-vscode-editor-line-height",
									"cursor-text",
									"py-2 pl-2",
									isFocused
										? "border border-vscode-focusBorder outline outline-vscode-focusBorder"
										: isDraggingOver
											? "border-2 border-dashed border-vscode-focusBorder"
											: "border border-transparent",
									isDraggingOver
										? "bg-[color-mix(in_srgb,var(--vscode-input-background)_95%,var(--vscode-focusBorder))]"
										: "bg-vscode-input-background",
									"transition-background-color duration-150 ease-in-out",
									"will-change-background-color",
									"min-h-[94px]",
									"box-border",
									"rounded",
									"resize-none",
									"overflow-x-hidden",
									"overflow-y-auto",
									isEditMode ? "pr-20" : "pr-9",
									"flex-none flex-grow",
									"z-[2]",
									"scrollbar-none",
									"scrollbar-hide",
								)}
								onScroll={() => updateHighlights()}
							/>

							<div className="absolute bottom-2 right-1 z-30 flex flex-col items-center gap-0">
								<StandardTooltip content={imageButtonTooltip}>
									<button
										aria-label={imageButtonTooltip}
										disabled={shouldDisableImages}
										onClick={!shouldDisableImages ? onSelectImages : undefined}
										className={cn(
											"relative inline-flex items-center justify-center",
											"bg-transparent border-none p-1.5",
											"rounded-md min-w-[28px] min-h-[28px]",
											"text-vscode-descriptionForeground hover:text-vscode-foreground",
											"transition-all duration-1000",
											"cursor-pointer",
											// Disabled styling is owned by the `shouldDisableImages` block
											// below (greyed + grayscale). Keep the button non-interactive
											// here but do NOT set opacity-0 — it conflicted with the
											// opacity-40 below, leaving the rendered state ambiguous.
											!shouldDisableImages
												? "opacity-50 hover:opacity-100 delay-750 pointer-events-auto"
												: "pointer-events-none duration-200 delay-0",
											!shouldDisableImages &&
												"hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
											"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
											!shouldDisableImages && "active:bg-[rgba(255,255,255,0.1)]",
											shouldDisableImages &&
												"opacity-40 cursor-not-allowed grayscale-[30%] hover:bg-transparent hover:border-[rgba(255,255,255,0.08)] active:bg-transparent",
										)}>
										<Image className="w-4 h-4" />
									</button>
								</StandardTooltip>
								{isEditMode ? (
									<StandardTooltip content={t("chat:cancel.title")}>
										<button
											aria-label={t("chat:cancel.title")}
											disabled={false}
											onClick={onCancel}
											className={cn(
												"relative inline-flex items-center justify-center",
												"bg-transparent border-none p-1.5",
												"rounded-md min-w-[28px] min-h-[28px]",
												"opacity-60 hover:opacity-100 text-vscode-descriptionForeground hover:text-vscode-foreground",
												"transition-all duration-150",
												"hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
												"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
												"active:bg-[rgba(255,255,255,0.1)]",
												"cursor-pointer",
											)}>
											<X className="w-4 h-4" />
										</button>
									</StandardTooltip>
								) : (
									<StandardTooltip content={t("chat:enhancePrompt")}>
										<button
											aria-label={t("chat:enhancePrompt")}
											disabled={false}
											onClick={handleEnhancePrompt}
											className={cn(
												"relative inline-flex items-center justify-center",
												"bg-transparent border-none p-1.5",
												"rounded-md min-w-[28px] min-h-[28px]",
												"text-vscode-descriptionForeground hover:text-vscode-foreground",
												"transition-all duration-1000",
												"cursor-pointer",
												hasInputContent
													? "opacity-50 hover:opacity-100 delay-750 pointer-events-auto"
													: "opacity-0 pointer-events-none duration-200 delay-0",
												hasInputContent &&
													"hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
												"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
												hasInputContent && "active:bg-[rgba(255,255,255,0.1)]",
											)}>
											<WandSparkles
												className={cn("w-4 h-4", isEnhancingPrompt && "animate-spin")}
											/>
										</button>
									</StandardTooltip>
								)}
								{/* Queue button - shown when the task is stoppable and user has typed content */}
								{!isEditMode && (isStreaming || canStop) && hasInputContent && onEnqueueMessage && (
									<StandardTooltip content={t("chat:enqueueMessage")}>
										<button
											aria-label={t("chat:enqueueMessage")}
											disabled={false}
											onClick={onEnqueueMessage}
											className={cn(
												"relative inline-flex items-center justify-center",
												"bg-transparent border-none p-1.5",
												"rounded-md min-w-[28px] min-h-[28px]",
												"text-vscode-descriptionForeground hover:text-vscode-foreground",
												"transition-all duration-200",
												"opacity-100 hover:opacity-100 pointer-events-auto",
												"hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
												"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
												"active:bg-[rgba(255,255,255,0.1)]",
												"cursor-pointer",
											)}>
											<ListEnd className="w-4 h-4" />
										</button>
									</StandardTooltip>
								)}
								{/* Send/Stop button - morphs based on streaming/stoppable state, always visible in edit mode.
								    `showStop` makes Stop available at all times while a task is active
								    (e.g. while a CLI command is running or awaiting approval), not only
								    during pure assistant streaming. */}
								{(() => {
									const showStop = isStreaming || canStop
									return (
										<StandardTooltip
											content={
												isEditMode
													? t("chat:pressToSend", { keyCombination: sendKeyCombination })
													: showStop
														? t("chat:stop.title")
														: t("chat:pressToSend", {
																keyCombination: sendKeyCombination,
															})
											}>
											<button
												aria-label={
													isEditMode
														? t("chat:pressToSend", {
																keyCombination: sendKeyCombination,
															})
														: showStop
															? t("chat:stop.title")
															: t("chat:pressToSend", {
																	keyCombination: sendKeyCombination,
																})
												}
												disabled={showStop && stopGuardRef.current}
												onClick={showStop ? handleStop : onSend}
												className={cn(
													"relative inline-flex items-center justify-center",
													"bg-transparent border-none p-1.5",
													"rounded-full min-w-[28px] min-h-[28px]",
													"text-vscode-descriptionForeground hover:text-vscode-foreground",
													"transition-all duration-200",
													isEditMode || showStop || hasInputContent
														? "opacity-100 hover:opacity-100 pointer-events-auto"
														: "opacity-0 pointer-events-none",
													(isEditMode || showStop || hasInputContent) &&
														"hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
													"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
													(isEditMode || showStop || hasInputContent) &&
														"active:bg-[rgba(255,255,255,0.1)]",
													(isEditMode || showStop || hasInputContent) && "cursor-pointer",
													showStop &&
														"bg-vscode-button-background hover:bg-vscode-button-background",
												)}>
												{showStop ? (
													<Square className="size-4 stroke-none fill-vscode-button-foreground" />
												) : (
													<SendHorizontal className="size-4" />
												)}
											</button>
										</StandardTooltip>
									)
								})()}
							</div>

							{!inputValue && (
								<div
									className={cn(
										"absolute left-2 z-30 flex items-center h-8 font-vscode-font-family text-vscode-editor-font-size leading-vscode-editor-line-height",
										isEditMode ? "pr-20" : "pr-9",
									)}
									style={{
										bottom: "0.75rem",
										color: "color-mix(in oklab, var(--vscode-input-foreground) 50%, transparent)",
										userSelect: "none",
										pointerEvents: "none",
									}}>
									{placeholderBottomText}
								</div>
							)}
						</div>
					</div>
				</div>

				{imageRejectedNotice && (
					<div
						role="status"
						className="flex items-center gap-1.5 px-3 py-1 text-xs text-vscode-descriptionForeground">
						<Image className="w-3.5 h-3.5 flex-shrink-0 opacity-70" />
						<span>{imageRejectedNotice}</span>
					</div>
				)}

				{selectedImages.length > 0 && (
					<Thumbnails
						images={selectedImages}
						setImages={setSelectedImages}
						style={{
							left: "16px",
							zIndex: 2,
							marginBottom: 0,
						}}
					/>
				)}

				<div className="flex items-center gap-2">
					<div className="flex items-center gap-2 min-w-0 overflow-clip flex-1">
						<ModeSelector
							value={mode}
							title={t("chat:selectMode")}
							onChange={handleModeChange}
							triggerClassName="text-ellipsis overflow-hidden flex-shrink-0"
							modeShortcutText={modeShortcutText}
							customModes={customModes}
							customModePrompts={customModePrompts}
						/>
						<ApiConfigSelector
							value={currentConfigId}
							displayName={displayName}
							disabled={selectApiConfigDisabled}
							title={t("chat:selectApiConfig")}
							onChange={handleApiConfigChange}
							triggerClassName="min-w-[28px] text-ellipsis overflow-hidden flex-shrink"
							listApiConfigMeta={listApiConfigMeta || []}
							pinnedApiConfigs={pinnedApiConfigs}
							togglePinnedApiConfig={togglePinnedApiConfig}
							lockApiConfigAcrossModes={!!lockApiConfigAcrossModes}
							onToggleLockApiConfig={handleToggleLockApiConfig}
						/>
						<AutoApproveDropdown triggerClassName="min-w-[28px] text-ellipsis overflow-hidden flex-shrink" />
						<CommandsButton />
						<SkillsButton />
					</div>
					<div
						className={cn(
							"flex flex-shrink-0 items-center gap-0.5 h-5 leading-none",
							!isEditMode && cloudUserInfo ? "" : "pr-2",
						)}>
						{isTtsPlaying && (
							<StandardTooltip content={t("chat:stopTts")}>
								<button
									aria-label={t("chat:stopTts")}
									onClick={() => vscode.postMessage({ type: "stopTts" })}
									className={cn(
										"relative inline-flex items-center justify-center",
										"bg-transparent border-none p-1.5",
										"rounded-md min-w-[28px] min-h-[28px]",
										"text-vscode-foreground opacity-85",
										"transition-all duration-150",
										"hover:opacity-100 hover:bg-[rgba(255,255,255,0.03)] hover:border-[rgba(255,255,255,0.15)]",
										"focus:outline-none focus-visible:ring-1 focus-visible:ring-vscode-focusBorder",
										"active:bg-[rgba(255,255,255,0.1)]",
										"cursor-pointer",
									)}>
									<VolumeX className="w-4 h-4" />
								</button>
							</StandardTooltip>
						)}
						{/* Plugin chat-input-toolbar contributions (design §6.8) — placed in the
						    right-hand indicator cluster next to IndexingStatusBadge, matching where
						    the built-in LiveMemoryStatusBadge sat. Renders nothing without a plugin. */}
						{!isEditMode ? <PluginSlot region="chat-input-toolbar" /> : null}
						{/* CloudAccountSwitcher removed */}
					</div>
				</div>
			</div>
		)
	},
)
