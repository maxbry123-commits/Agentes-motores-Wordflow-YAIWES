import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useSize } from "react-use"
import { useTranslation, Trans } from "react-i18next"
import deepEqual from "fast-deep-equal"
import { VSCodeBadge } from "@vscode/webview-ui-toolkit/react"

import type {
	ShoferMessage,
	FollowUpData,
	SuggestionItem,
	ShoferApiReqInfo,
	ShoferAskUseMcpServer,
	ShoferSayTool,
} from "@shofer/types"

import { Mode } from "@shofer/types"

import { COMMAND_OUTPUT_STRING } from "@shofer/types"
import { safeJsonParse } from "@shofer/shared/core"

import { useExtensionState } from "@src/context/ExtensionStateContext"
import { findMatchingResourceOrTemplate } from "@src/utils/mcp"
import { vscode } from "@src/utils/vscode"
import { formatPathTooltip } from "@src/utils/formatPathTooltip"

import { ToolUseBlock, ToolUseBlockHeader } from "../common/ToolUseBlock"
import UpdateTodoListToolBlock from "./UpdateTodoListToolBlock"
import { TodoChangeDisplay } from "./TodoChangeDisplay"
import CodeAccordion from "../common/CodeAccordion"
import MarkdownBlock from "../common/MarkdownBlock"
import CollapsibleMarkdown from "./CollapsibleMarkdown"
import { ReasoningBlock } from "./ReasoningBlock"
import Thumbnails from "../common/Thumbnails"
import ImageBlock from "../common/ImageBlock"
import ErrorRow from "./ErrorRow"
import WarningRow from "./WarningRow"

import McpResourceRow from "../mcp/McpResourceRow"

import { Mention } from "./Mention"
import { PluginSlot } from "../plugins/PluginSlot"
import { FollowUpSuggest } from "./FollowUpSuggest"
import { WorkflowParamForm } from "./WorkflowParamForm"
import { BatchFilePermission } from "./BatchFilePermission"
import { BatchDiffApproval } from "./BatchDiffApproval"
import { ProgressIndicator } from "./ProgressIndicator"
import { Markdown } from "./Markdown"
import { CommandExecution } from "./CommandExecution"
import { CommandExecutionError } from "./CommandExecutionError"
import { AutoApprovedRequestLimitWarning } from "./AutoApprovedRequestLimitWarning"
import { ToolInputSection, ToolOutputSection } from "./ToolInputOutput"
import { InProgressRow, CondensationResultRow, CondensationErrorRow, TruncationResultRow } from "./context-management"
import { appendImages } from "@src/utils/imageUtils"
import { McpExecution } from "./McpExecution"
import { ChatTextArea } from "./ChatTextArea"
import { MAX_IMAGES_PER_MESSAGE } from "./ChatView"
import { useSelectedModel } from "../ui/hooks/useSelectedModel"
import {
	Eye,
	FileDiff,
	ListTree,
	User,
	Edit,
	Trash2,
	MessageCircleQuestionMark,
	SquareArrowOutUpRight,
	FileCode2,
	PocketKnife,
	FolderTree,
	TerminalSquare,
	Repeat2,
	Split,
	ArrowRight,
	Check,
	Send,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { PathTooltip } from "../ui/PathTooltip"
import { StandardTooltip } from "../ui/standard-tooltip"
import { OpenMarkdownPreviewButton } from "./OpenMarkdownPreviewButton"

/**
 * Render a VS Code codicon span. Module-scoped so it can be reused by both the
 * `ask` tool renderer and the inner `say` tool renderer (and by helpers like
 * `renderGenericToolBlock`).
 */
function toolIcon(name: string) {
	return (
		<span
			className={`codicon codicon-${name}`}
			style={{ color: "var(--vscode-foreground)", marginBottom: "-1.5px" }}></span>
	)
}

/**
 * Convert a camelCase / snake_case tool identifier into a human-readable label.
 * Used by the generic tool-block fallback so unknown tools still render meaningfully.
 */
function humanizeToolName(name: string): string {
	const withSpaces = name
		.replace(/[_-]+/g, " ")
		.replace(/([a-z0-9])([A-Z])/g, "$1 $2")
		.replace(/\s+/g, " ")
		.trim()
	return withSpaces.charAt(0).toUpperCase() + withSpaces.slice(1)
}

/**
 * Generic chat-row renderer for `ShoferSayTool` payloads that don't have a
 * tool-specific block. Every tool invocation must produce some UI feedback
 * — otherwise an auto-approved tool appears to "execute silently" and the
 * user has no idea the model is acting on their workspace.
 *
 * The block is intentionally minimal: an icon, the humanized tool name with
 * "Shofer wants to use…" / "Shofer used…" prefix, and (when present) the tool's
 * `path` / `content` fields so common payload shapes display useful context.
 */
function renderGenericToolBlock(
	tool: ShoferSayTool,
	isAsk: boolean,
	headerStyle: React.CSSProperties,
	t: (key: string, opts?: Record<string, unknown>) => string,
): React.ReactNode {
	const label = humanizeToolName(tool.tool)
	const headerText = isAsk
		? t("chat:genericTool.wantsToUse", { tool: label, defaultValue: `Shofer wants to use ${label}` })
		: t("chat:genericTool.didUse", { tool: label, defaultValue: `Shofer used ${label}` })
	const detail = tool.path || tool.query || tool.regex || tool.content
	return (
		<>
			<div style={headerStyle}>
				{toolIcon("tools")}
				<span style={{ fontWeight: "bold" }}>{headerText}</span>
			</div>
			{detail && (
				<div className="pl-6 text-vscode-descriptionForeground break-words">
					{typeof detail === "string" ? detail : JSON.stringify(detail)}
				</div>
			)}
		</>
	)
}

// Helper function to get previous todos before a specific message
function getPreviousTodos(messages: ShoferMessage[], currentMessageTs: number): any[] {
	// Find the previous updateTodoList message before the current one
	const previousUpdateIndex = messages
		.slice()
		.reverse()
		.findIndex((msg) => {
			if (msg.ts >= currentMessageTs) return false
			if (msg.type === "ask" && msg.ask === "tool") {
				try {
					const tool = JSON.parse(msg.text || "{}")
					return tool.tool === "updateTodoList"
				} catch {
					return false
				}
			}
			return false
		})

	if (previousUpdateIndex !== -1) {
		const previousMessage = messages.slice().reverse()[previousUpdateIndex]
		try {
			const tool = JSON.parse(previousMessage.text || "{}")
			return tool.todos || []
		} catch {
			return []
		}
	}

	// If no previous updateTodoList message, return empty array
	return []
}

interface ChatRowProps {
	message: ShoferMessage
	lastModifiedMessage?: ShoferMessage
	isExpanded: boolean
	isLast: boolean
	isStreaming: boolean
	onToggleExpand: (ts: number) => void
	onHeightChange: (isTaller: boolean) => void
	onSuggestionClick?: (suggestion: SuggestionItem, event?: React.MouseEvent) => void
	/** Submits a workflow flow-parameter form (JSON-serialized answers). */
	onParamFormSubmit?: (json: string) => void
	onBatchFileResponse?: (response: { [key: string]: boolean }) => void
	onFollowUpUnmount?: () => void
	isFollowUpAnswered?: boolean
	isFollowUpAutoApprovalPaused?: boolean
	editable?: boolean
	isSearchHighlighted?: boolean
}

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
interface ChatRowContentProps extends Omit<ChatRowProps, "onHeightChange"> {}

const ChatRow = memo(
	(props: ChatRowProps) => {
		const { onHeightChange, message } = props
		// Store the previous height to compare with the current height
		// This allows us to detect changes without causing re-renders
		const prevHeightRef = useRef(0)

		const [chatrow, { height }] = useSize(
			<div
				data-message-ts={message.ts}
				className={`px-[15px] py-[10px] pr-[6px] ${
					props.isSearchHighlighted
						? "ring-2 ring-vscode-focusBorder bg-vscode-list-inactiveSelectionBackground/30 rounded-md"
						: ""
				}`}>
				<ChatRowContent {...props} />
			</div>,
		)

		useEffect(() => {
			const isHeightValid = height !== 0 && height !== Infinity
			// used for partials, command output, etc.
			// NOTE: it's important we don't distinguish between partial or complete here since our scroll effects in chatview need to handle height change during partial -> complete
			const isInitialRender = prevHeightRef.current === 0 // prevents scrolling when new element is added since we already scroll for that
			// height starts off at Infinity
			//
			// Cause D: report height changes for EVERY row, not just the last one.
			// A tool result expanding or an image loading in a non-last row grows
			// the list above the viewport; while the user is anchored at the bottom
			// that growth must pull the viewport down too. The scroll decision lives
			// in the hook (handleRowHeightChange), which only scrolls when at-bottom
			// or streaming and is a no-op while the user is browsing history — so
			// reporting from every row is safe.
			if (isHeightValid && height !== prevHeightRef.current) {
				if (!isInitialRender) {
					onHeightChange(height > prevHeightRef.current)
				}
				prevHeightRef.current = height
			}
		}, [height, onHeightChange, message])

		// we cannot return null as virtuoso does not support it, so we use a separate visibleMessages array to filter out messages that should not be rendered
		return chatrow
	},
	// memo does shallow comparison of props, so we need to do deep comparison of arrays/objects whose properties might change
	deepEqual,
)

export default ChatRow

export const ChatRowContent = ({
	message,
	lastModifiedMessage,
	isExpanded,
	isLast,
	isStreaming,
	onToggleExpand,
	onSuggestionClick,
	onParamFormSubmit,
	onFollowUpUnmount,
	onBatchFileResponse,
	isFollowUpAnswered,
	isFollowUpAutoApprovalPaused,
}: ChatRowContentProps) => {
	const { t, i18n } = useTranslation()

	const { mcpServers, mode, apiConfiguration, shoferMessages, currentTaskItem } = useExtensionState()
	const { info: model } = useSelectedModel(apiConfiguration)
	const [isEditing, setIsEditing] = useState(false)
	const [editedContent, setEditedContent] = useState("")
	const [editMode, setEditMode] = useState<Mode>(mode || "code")
	const [editImages, setEditImages] = useState<string[]>([])

	// Handle message events for image selection during edit mode
	useEffect(() => {
		const handleMessage = (event: MessageEvent) => {
			const msg = event.data
			if (msg.type === "selectedImages" && msg.context === "edit" && msg.messageTs === message.ts && isEditing) {
				setEditImages((prevImages) => appendImages(prevImages, msg.images, MAX_IMAGES_PER_MESSAGE))
			}
		}

		window.addEventListener("message", handleMessage)
		return () => window.removeEventListener("message", handleMessage)
	}, [isEditing, message.ts])

	// Memoized callback to prevent re-renders caused by inline arrow functions.
	const handleToggleExpand = useCallback(() => {
		onToggleExpand(message.ts)
	}, [onToggleExpand, message.ts])

	// Handle edit button click
	const handleEditClick = useCallback(() => {
		setIsEditing(true)
		setEditedContent(message.text || "")
		setEditImages(message.images || [])
		setEditMode(mode || "code")
		// Edit mode is now handled entirely in the frontend
		// No need to notify the backend
	}, [message.text, message.images, mode])

	// Handle cancel edit
	const handleCancelEdit = useCallback(() => {
		setIsEditing(false)
		setEditedContent(message.text || "")
		setEditImages(message.images || [])
		setEditMode(mode || "code")
	}, [message.text, message.images, mode])

	// Handle save edit
	const handleSaveEdit = useCallback(() => {
		setIsEditing(false)
		// Send edited message to backend
		vscode.postMessage({
			type: "submitEditedMessage",
			value: message.ts,
			editedMessageContent: editedContent,
			images: editImages,
		})
	}, [message.ts, editedContent, editImages])

	// Handle image selection for editing
	const handleSelectImages = useCallback(() => {
		vscode.postMessage({ type: "selectImages", context: "edit", messageTs: message.ts })
	}, [message.ts])

	const [cost, apiReqCancelReason, apiReqStreamingFailedMessage, apiReqMetadata] = useMemo(() => {
		if (message.text !== null && message.text !== undefined && message.say === "api_req_started") {
			const info = safeJsonParse<ShoferApiReqInfo>(message.text)
			const metadata =
				info?.actualModel ||
				info?.ttfbMs !== undefined ||
				info?.attempts !== undefined ||
				info?.tokensIn !== undefined
					? {
							actualModel: info.actualModel,
							ttfbMs: info.ttfbMs,
							ttlbMs: info.ttlbMs,
							attempts: info.attempts,
							promptTokens: info.tokensIn,
							completionTokens: info.tokensOut,
							costUsd: info.cost,
							responseError: info.responseError,
						}
					: undefined
			return [info?.cost, info?.cancelReason, info?.streamingFailedMessage, metadata]
		}

		return [undefined, undefined, undefined, undefined]
	}, [message.text, message.say])

	// When resuming task, last won't be api_req_failed but a resume_task
	// message, so api_req_started will show loading spinner. That's why we just
	// remove the last api_req_started that failed without streaming anything.
	const apiRequestFailedMessage =
		isLast && lastModifiedMessage?.ask === "api_req_failed" // if request is retried then the latest message is a api_req_retried
			? lastModifiedMessage?.text
			: undefined

	const isCommandExecuting =
		isLast && lastModifiedMessage?.ask === "command" && lastModifiedMessage?.text?.includes(COMMAND_OUTPUT_STRING)

	const isMcpServerResponding = isLast && lastModifiedMessage?.say === "mcp_server_request_started"

	const type = message.type === "ask" ? message.ask : message.say

	const normalColor = "var(--vscode-foreground)"
	const errorColor = "var(--vscode-errorForeground)"
	const successColor = "var(--vscode-charts-green)"
	const cancelledColor = "var(--vscode-descriptionForeground)"

	const [icon, title] = useMemo(() => {
		switch (type) {
			case "error":
			case "mistake_limit_reached":
				return [null, null] // These will be handled by ErrorRow component
			case "command":
				return [
					isCommandExecuting ? (
						<ProgressIndicator />
					) : (
						<TerminalSquare className="size-4" aria-label="Terminal icon" />
					),
					<span style={{ color: normalColor, fontWeight: "bold" }}>
						{t("chat:commandExecution.running")}
					</span>,
				]
			case "use_mcp_server":
				const mcpServerUse = safeJsonParse<ShoferAskUseMcpServer>(message.text)
				if (mcpServerUse === undefined) {
					return [null, null]
				}
				const isExternalLmTool = mcpServerUse.external_lm_tool === true
				return [
					isMcpServerResponding ? (
						<ProgressIndicator />
					) : (
						<span
							className={`codicon codicon-${isExternalLmTool ? "tools" : "server"}`}
							style={{ color: normalColor, marginBottom: "-1.5px" }}></span>
					),
					<span style={{ color: normalColor, fontWeight: "bold" }}>
						{mcpServerUse.type === "use_mcp_tool"
							? isExternalLmTool
								? t("chat:mcp.wantsToUseExternalTool", {
										toolName: mcpServerUse.toolName,
										serverName: mcpServerUse.serverName,
									})
								: t("chat:mcp.wantsToUseTool", { serverName: mcpServerUse.serverName })
							: t("chat:mcp.wantsToAccessResource", { serverName: mcpServerUse.serverName })}
					</span>,
				]
			case "completion_result":
				return [
					<span
						className="codicon codicon-check"
						style={{ color: successColor, marginBottom: "-1.5px" }}></span>,
					<span style={{ color: successColor, fontWeight: "bold" }}>{t("chat:taskCompleted")}</span>,
				]
			case "tool_preparing": {
				const preparingInfo = safeJsonParse<{ toolName: string; byteCount: number }>(message.text)
				return [
					<ProgressIndicator />,
					<span style={{ color: normalColor }}>
						{t("chat:toolPreparing.preparing", { toolName: preparingInfo?.toolName ?? "" })}
					</span>,
				]
			}
			case "api_req_rate_limit_wait":
				return []
			case "api_req_retry_delayed":
				return []
			case "api_req_started": {
				// On success (cost present, no cancel reason), hide the row entirely
				// to avoid cluttering the chat — same as tool_preparing dismissal.
				if (
					cost !== null &&
					cost !== undefined &&
					(apiReqCancelReason === null || apiReqCancelReason === undefined)
				) {
					return []
				}

				const getIconSpan = (iconName: string, color: string) => (
					<div
						style={{
							width: 16,
							height: 16,
							display: "flex",
							alignItems: "center",
							justifyContent: "center",
						}}>
						<span
							className={`codicon codicon-${iconName}`}
							style={{ color, fontSize: 16, marginBottom: "-1.5px" }}
						/>
					</div>
				)
				return [
					apiReqCancelReason !== null && apiReqCancelReason !== undefined ? (
						apiReqCancelReason === "user_cancelled" ? (
							getIconSpan("error", cancelledColor)
						) : (
							getIconSpan("error", errorColor)
						)
					) : apiRequestFailedMessage ? (
						getIconSpan("error", errorColor)
					) : isLast ? (
						<ProgressIndicator />
					) : (
						getIconSpan("arrow-swap", normalColor)
					),
					apiReqCancelReason !== null && apiReqCancelReason !== undefined ? (
						apiReqCancelReason === "user_cancelled" ? (
							<span style={{ color: normalColor, fontWeight: "bold" }}>
								{t("chat:apiRequest.cancelled")}
							</span>
						) : (
							<span style={{ color: errorColor, fontWeight: "bold" }}>
								{t("chat:apiRequest.streamingFailed")}
							</span>
						)
					) : apiRequestFailedMessage ? (
						<span style={{ color: errorColor }}>{t("chat:apiRequest.failed")}</span>
					) : (
						<span style={{ color: normalColor }}>{t("chat:apiRequest.streaming")}</span>
					),
				]
			}
			case "followup":
				return [
					<MessageCircleQuestionMark className="w-4 shrink-0" aria-label="Question icon" />,
					<span style={{ color: normalColor, fontWeight: "bold" }}>{t("chat:questions.hasQuestion")}</span>,
				]
			default:
				return [null, null]
		}
	}, [
		type,
		isCommandExecuting,
		message,
		isMcpServerResponding,
		apiReqCancelReason,
		cost,
		apiRequestFailedMessage,
		t,
		isLast,
	])

	const headerStyle: React.CSSProperties = {
		display: "flex",
		alignItems: "center",
		gap: "10px",
		cursor: "default",
		marginBottom: "10px",
		wordBreak: "break-word",
	}

	const tool = useMemo(
		() => (message.ask === "tool" ? safeJsonParse<ShoferSayTool>(message.text) : null),
		[message.ask, message.text],
	)

	// Unified diff content (provided by backend when relevant)
	const unifiedDiff = useMemo(() => {
		if (!tool) return undefined
		return (tool.content ?? tool.diff) as string | undefined
	}, [tool])

	const onJumpToCreatedFile = useMemo(() => {
		if (!tool || tool.tool !== "newFileCreated" || !tool.path) {
			return undefined
		}

		return () => vscode.postMessage({ type: "openFile", text: "./" + tool.path })
	}, [tool])

	const followUpData = useMemo(() => {
		if (message.type === "ask" && message.ask === "followup" && !message.partial) {
			return safeJsonParse<FollowUpData>(message.text)
		}
		return null
	}, [message.type, message.ask, message.partial, message.text])
	const [showToolInput, setShowToolInput] = useState(false)

	const handleToggleToolInput = useCallback(() => {
		setShowToolInput((prev) => !prev)
	}, [])

	// H19+H20: Memoized computations hoisted above the render switches so hooks
	// are called unconditionally (React rules-of-hooks).  Each is keyed on
	// message.text or message.ts so it re-evaluates only when the data changes,
	// skipping the JSON.parse / reverse-scan work on every parent re-render.
	const rateLimitWaitSeconds = useMemo(() => {
		if (!message.text) return undefined
		try {
			const data = JSON.parse(message.text)
			return typeof data.seconds === "number" ? data.seconds : undefined
		} catch {
			return undefined
		}
	}, [message.text])

	const previousTodos = useMemo(() => getPreviousTodos(shoferMessages, message.ts), [shoferMessages, message.ts])

	if (tool) {
		switch (tool.tool as string) {
			case "editedExistingFile":
			case "appliedDiff":
			case "newFileCreated":
			case "searchAndReplace":
			case "search_and_replace":
			case "search_replace":
			case "edit":
			case "edit_file":
			case "apply_patch":
			case "apply_diff":
				// Check if this is a batch diff request
				if (message.type === "ask" && tool.batchDiffs && Array.isArray(tool.batchDiffs)) {
					return (
						<>
							<div style={headerStyle}>
								<FileDiff className="w-4 shrink-0" aria-label="Batch diff icon" />
								<span style={{ fontWeight: "bold" }}>
									{t("chat:fileOperations.wantsToApplyBatchChanges")}
								</span>
							</div>
							<BatchDiffApproval files={tool.batchDiffs} ts={message.ts} />
						</>
					)
				}

				// Regular single file diff
				return (
					<>
						<div style={headerStyle}>
							{tool.isProtected ? (
								<span
									className="codicon codicon-lock"
									style={{ color: "var(--vscode-editorWarning-foreground)", marginBottom: "-1.5px" }}
								/>
							) : (
								toolIcon("diff")
							)}
							<span style={{ fontWeight: "bold" }}>
								{tool.isProtected
									? t("chat:fileOperations.wantsToEditProtected")
									: tool.isOutsideWorkspace
										? t("chat:fileOperations.wantsToEditOutsideWorkspace")
										: t("chat:fileOperations.wantsToEdit")}
							</span>
						</div>
						<div className="pl-6">
							<CodeAccordion
								path={tool.path}
								code={unifiedDiff ?? tool.content ?? tool.diff ?? ""}
								language="diff"
								progressStatus={message.progressStatus}
								isLoading={message.partial}
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
								onJumpToFile={onJumpToCreatedFile}
								diffStats={tool.diffStats}
							/>
						</div>
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
			case "insertContent":
				return (
					<>
						<div style={headerStyle}>
							{tool.isProtected ? (
								<span
									className="codicon codicon-lock"
									style={{ color: "var(--vscode-editorWarning-foreground)", marginBottom: "-1.5px" }}
								/>
							) : (
								toolIcon("insert")
							)}
							<span style={{ fontWeight: "bold" }}>
								{tool.isProtected
									? t("chat:fileOperations.wantsToEditProtected")
									: tool.isOutsideWorkspace
										? t("chat:fileOperations.wantsToEditOutsideWorkspace")
										: tool.lineNumber === 0
											? t("chat:fileOperations.wantsToInsertAtEnd")
											: t("chat:fileOperations.wantsToInsertWithLineNumber", {
													lineNumber: tool.lineNumber,
												})}
							</span>
						</div>
						<div className="pl-6">
							<CodeAccordion
								path={tool.path}
								code={unifiedDiff ?? tool.diff}
								language="diff"
								progressStatus={message.progressStatus}
								isLoading={message.partial}
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
								diffStats={tool.diffStats}
							/>
						</div>
					</>
				)
			case "updateTodoList" as any: {
				const todos = (tool as any).todos || []

				return <TodoChangeDisplay previousTodos={previousTodos} newTodos={todos} />
			}
			case "readFile":
				// Check if this is a batch file permission request
				const isBatchRequest = message.type === "ask" && tool.batchFiles && Array.isArray(tool.batchFiles)

				if (isBatchRequest) {
					return (
						<>
							<div style={headerStyle}>
								<Eye className="w-4 shrink-0" aria-label="View files icon" />
								<span style={{ fontWeight: "bold" }}>
									{t("chat:fileOperations.wantsToReadMultiple")}
								</span>
							</div>
							<BatchFilePermission
								files={tool.batchFiles || []}
								onPermissionResponse={(response) => {
									onBatchFileResponse?.(response)
								}}
								ts={message?.ts}
							/>
						</>
					)
				}

				// Regular single file read request
				return (
					<>
						<div style={headerStyle}>
							<FileCode2 className="w-4 shrink-0" aria-label="Read file icon" />
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask"
									? tool.isOutsideWorkspace
										? t("chat:fileOperations.wantsToReadOutsideWorkspace")
										: tool.additionalFileCount && tool.additionalFileCount > 0
											? t("chat:fileOperations.wantsToReadAndXMore", {
													count: tool.additionalFileCount,
												})
											: t("chat:fileOperations.wantsToRead")
									: t("chat:fileOperations.didRead")}
							</span>
						</div>
						<div className="pl-6">
							<ToolUseBlock>
								<ToolUseBlockHeader
									className="group"
									onClick={() =>
										vscode.postMessage({
											type: "openFile",
											text: tool.content,
											values: tool.startLine ? { line: tool.startLine } : undefined,
										})
									}>
									{tool.path?.startsWith(".") && <span>.</span>}
									<PathTooltip content={formatPathTooltip(tool.path, tool.reason)}>
										<span className="whitespace-nowrap overflow-hidden text-ellipsis text-left mr-2 rtl">
											{formatPathTooltip(tool.path, tool.reason)}
										</span>
									</PathTooltip>
									<div style={{ flexGrow: 1 }}></div>
									<SquareArrowOutUpRight
										className="w-4 shrink-0 codicon codicon-link-external opacity-0 group-hover:opacity-100 transition-opacity"
										style={{ fontSize: 13.5, margin: "1px 0" }}
									/>
								</ToolUseBlockHeader>
							</ToolUseBlock>
						</div>
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
			case "skills": {
				const skillInfo = tool
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("book")}
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask" ? t("chat:skills.wantsToLoad") : t("chat:skills.didLoad")}
							</span>
						</div>
						<div
							style={{
								marginTop: "4px",
								backgroundColor: "var(--vscode-editor-background)",
								border: "1px solid var(--vscode-editorGroup-border)",
								borderRadius: "4px",
								overflow: "hidden",
								cursor: "pointer",
							}}
							onClick={handleToggleExpand}>
							<ToolUseBlockHeader
								className="group"
								style={{
									display: "flex",
									alignItems: "center",
									justifyContent: "space-between",
									padding: "10px 12px",
								}}>
								<div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
									<span style={{ fontWeight: "500", fontSize: "var(--vscode-font-size)" }}>
										{skillInfo.skill}
									</span>
									{skillInfo.source && (
										<VSCodeBadge style={{ fontSize: "calc(var(--vscode-font-size) - 2px)" }}>
											{skillInfo.source}
										</VSCodeBadge>
									)}
								</div>
								<span
									className={`codicon codicon-chevron-${isExpanded ? "up" : "down"} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}></span>
							</ToolUseBlockHeader>
							{isExpanded && (skillInfo.args || skillInfo.description) && (
								<div
									style={{
										padding: "12px 16px",
										borderTop: "1px solid var(--vscode-editorGroup-border)",
										display: "flex",
										flexDirection: "column",
										gap: "8px",
									}}>
									{skillInfo.description && (
										<div style={{ color: "var(--vscode-descriptionForeground)" }}>
											{skillInfo.description}
										</div>
									)}
									{skillInfo.args && (
										<div>
											<span style={{ fontWeight: "500" }}>Arguments: </span>
											<span style={{ color: "var(--vscode-descriptionForeground)" }}>
												{skillInfo.args}
											</span>
										</div>
									)}
								</div>
							)}
						</div>
					</>
				)
			}
			case "listFilesTopLevel":
				return (
					<>
						<div style={headerStyle}>
							<ListTree className="w-4 shrink-0" aria-label="List files icon" />
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask"
									? tool.isOutsideWorkspace
										? t("chat:directoryOperations.wantsToViewTopLevelOutsideWorkspace")
										: t("chat:directoryOperations.wantsToViewTopLevel")
									: tool.isOutsideWorkspace
										? t("chat:directoryOperations.didViewTopLevelOutsideWorkspace")
										: t("chat:directoryOperations.didViewTopLevel")}
							</span>
						</div>
						<div className="pl-6">
							<CodeAccordion
								path={tool.path}
								code={tool.content}
								language="shell-session"
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
							/>
						</div>
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
			case "listFilesRecursive":
				return (
					<>
						<div style={headerStyle}>
							<FolderTree className="w-4 shrink-0" aria-label="Folder tree icon" />
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask"
									? tool.isOutsideWorkspace
										? t("chat:directoryOperations.wantsToViewRecursiveOutsideWorkspace")
										: t("chat:directoryOperations.wantsToViewRecursive")
									: tool.isOutsideWorkspace
										? t("chat:directoryOperations.didViewRecursiveOutsideWorkspace")
										: t("chat:directoryOperations.didViewRecursive")}
							</span>
						</div>
						<div className="pl-6">
							<CodeAccordion
								path={tool.path}
								code={tool.content}
								language="shellsession"
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
							/>
						</div>
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
			case "grepSearch":
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("search")}
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask" ? (
									<Trans
										i18nKey={
											tool.isOutsideWorkspace
												? "chat:directoryOperations.wantsToSearchOutsideWorkspace"
												: "chat:directoryOperations.wantsToSearch"
										}
										components={{ code: <code className="font-medium">{tool.regex}</code> }}
										values={{ regex: tool.regex }}
									/>
								) : (
									<Trans
										i18nKey={
											tool.isOutsideWorkspace
												? "chat:directoryOperations.didSearchOutsideWorkspace"
												: "chat:directoryOperations.didSearch"
										}
										components={{ code: <code className="font-medium">{tool.regex}</code> }}
										values={{ regex: tool.regex }}
									/>
								)}
							</span>
						</div>
						<div className="pl-6">
							<CodeAccordion
								path={tool.path! + (tool.filePattern ? `/(${tool.filePattern})` : "")}
								code={tool.content}
								language="shellsession"
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
							/>
						</div>
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
			case "switchMode":
				return (
					<>
						<div style={headerStyle}>
							<PocketKnife className="w-4 shrink-0" aria-label="Switch mode icon" />
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask" ? (
									<>
										{tool.reason ? (
											<Trans
												i18nKey="chat:modes.wantsToSwitchWithReason"
												components={{ code: <code className="font-medium">{tool.mode}</code> }}
												values={{ mode: tool.mode, reason: tool.reason }}
											/>
										) : (
											<Trans
												i18nKey="chat:modes.wantsToSwitch"
												components={{ code: <code className="font-medium">{tool.mode}</code> }}
												values={{ mode: tool.mode }}
											/>
										)}
									</>
								) : (
									<>
										{tool.reason ? (
											<Trans
												i18nKey="chat:modes.didSwitchWithReason"
												components={{ code: <code className="font-medium">{tool.mode}</code> }}
												values={{ mode: tool.mode, reason: tool.reason }}
											/>
										) : (
											<Trans
												i18nKey="chat:modes.didSwitch"
												components={{ code: <code className="font-medium">{tool.mode}</code> }}
												values={{ mode: tool.mode }}
											/>
										)}
									</>
								)}
							</span>
						</div>
					</>
				)
			case "newTask":
				// Find all newTask messages to determine which child task ID corresponds to this message
				const newTaskMessages = shoferMessages.filter((msg) => {
					if (msg.type === "ask" && msg.ask === "tool") {
						const t = safeJsonParse<ShoferSayTool>(msg.text)
						return t?.tool === "newTask"
					}
					return false
				})
				const thisNewTaskIndex = newTaskMessages.findIndex((msg) => msg.ts === message.ts)
				const childIds = currentTaskItem?.childIds || []

				// Only get the child task ID if this newTask has been approved (has a corresponding entry in childIds)
				// This prevents showing a link to a previous task when the current newTask is still awaiting approval
				// Note: We don't use delegatedToId here because it persists after child tasks complete and would
				// incorrectly point to the previous task when a new newTask is awaiting approval
				const childTaskId =
					thisNewTaskIndex >= 0 && thisNewTaskIndex < childIds.length ? childIds[thisNewTaskIndex] : undefined

				// Check if the next message is a subtask_result - if so, don't show the button
				// since the result is displayed right after this message
				const currentMessageIndex = shoferMessages.findIndex((msg) => msg.ts === message.ts)
				const nextMessage = currentMessageIndex >= 0 ? shoferMessages[currentMessageIndex + 1] : undefined
				const isFollowedBySubtaskResult = nextMessage?.type === "say" && nextMessage?.say === "subtask_result"

				return (
					<>
						<div style={headerStyle}>
							<Split className="size-4" />
							<span style={{ fontWeight: "bold" }}>
								<Trans
									i18nKey="chat:subtasks.wantsToCreate"
									components={{ code: <code>{tool.mode}</code> }}
									values={{ mode: tool.mode }}
								/>
							</span>
						</div>
						<div className="border-l border-muted-foreground/80 ml-2 pl-4 pb-1">
							<CollapsibleMarkdown markdown={tool.content} />
							{tool.todos && typeof tool.todos === "string" && (
								<div className="text-xs text-vscode-descriptionForeground mt-1">
									<span className="font-medium">{t("chat:subtasks.todos")}:</span>{" "}
									{tool.todos.slice(0, 120)}
									{tool.todos.length > 120 && "…"}
								</div>
							)}
							{tool.softResultLength !== undefined && tool.softResultLength !== null && (
								<div className="text-xs text-vscode-descriptionForeground mt-1">
									{t("chat:subtasks.softResultLength")}: {String(tool.softResultLength)}
								</div>
							)}
							{tool.softTimeoutSec !== undefined && tool.softTimeoutSec !== null && (
								<div className="text-xs text-vscode-descriptionForeground mt-1">
									{t("chat:subtasks.softTimeoutSec")}: {String(tool.softTimeoutSec)}s
								</div>
							)}
							{tool.peer_task_ids && tool.peer_task_ids.length > 0 && (
								<div className="text-xs text-vscode-descriptionForeground mt-1">
									{t("chat:subtasks.peerTaskIds")}: {tool.peer_task_ids.join(", ")}
								</div>
							)}
							<div>
								{childTaskId && !isFollowedBySubtaskResult && (
									<button
										className="cursor-pointer flex gap-1 items-center mt-2 text-vscode-descriptionForeground hover:text-vscode-descriptionForeground hover:underline font-normal"
										onClick={() =>
											vscode.postMessage({ type: "showTaskWithId", text: childTaskId })
										}>
										{t("chat:subtasks.goToSubtask")}
										<ArrowRight className="size-3" />
									</button>
								)}
							</div>
						</div>
					</>
				)
			case "finishTask":
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("check-all")}
							<span style={{ fontWeight: "bold" }}>{t("chat:subtasks.wantsToFinish")}</span>
						</div>
						<div className="text-muted-foreground pl-6">
							<MarkdownBlock markdown={t("chat:subtasks.completionInstructions")} />
						</div>
					</>
				)
			case "checkTaskStatus":
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("pulse")}
							<span style={{ fontWeight: "bold" }}>{t("chat:backgroundTasks.checkTaskStatus")}</span>
						</div>
						{(tool.task_title || tool.task_id) && (
							<div className="pl-6 text-vscode-descriptionForeground">
								{tool.task_title ?? tool.task_id}
							</div>
						)}
					</>
				)
			case "cancelTasks": {
				const results = Array.isArray(tool.results) ? tool.results : []
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("debug-stop")}
							<span style={{ fontWeight: "bold" }}>{t("chat:backgroundTasks.cancelTasks")}</span>
						</div>
						<div className="pl-6 text-vscode-descriptionForeground">
							{results.length === 0 ? (
								<div>{t("chat:backgroundTasks.noTasks")}</div>
							) : (
								<ul className="list-none p-0 m-0">
									{results.map((r: any) => (
										<li key={r.task_id} className="mb-1">
											{r.title ?? r.task_id}
											{" — "}
											{r.was_running
												? t("chat:backgroundTasks.stopped")
												: r.error
													? t("chat:backgroundTasks.error")
													: t("chat:backgroundTasks.alreadyTerminal")}
										</li>
									))}
								</ul>
							)}
						</div>
					</>
				)
			}
			case "listBackgroundTasks": {
				const bgTasks = Array.isArray(tool.tasks) ? tool.tasks : []
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("list-unordered")}
							<span style={{ fontWeight: "bold" }}>{t("chat:backgroundTasks.listBackgroundTasks")}</span>
						</div>
						<div className="pl-6 text-vscode-descriptionForeground">
							{bgTasks.length === 0 ? (
								<div>{t("chat:backgroundTasks.noTasks")}</div>
							) : (
								<ul className="list-none p-0 m-0">
									{bgTasks.map((bgTask) => (
										<li key={bgTask.task_id} className="mb-1">
											{bgTask.title ?? bgTask.task_id}
											{" — "}
											{t("chat:backgroundTasks.status")}: {bgTask.status}
										</li>
									))}
								</ul>
							)}
						</div>
					</>
				)
			}
			case "runSlashCommand": {
				const slashCommandInfo = tool
				return (
					<>
						<div style={headerStyle}>
							{toolIcon("play")}
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask"
									? t("chat:slashCommand.wantsToRun")
									: t("chat:slashCommand.didRun")}
							</span>
						</div>
						<div
							style={{
								marginTop: "4px",
								backgroundColor: "var(--vscode-editor-background)",
								border: "1px solid var(--vscode-editorGroup-border)",
								borderRadius: "4px",
								overflow: "hidden",
								cursor: "pointer",
							}}
							onClick={handleToggleExpand}>
							<ToolUseBlockHeader
								className="group"
								style={{
									display: "flex",
									alignItems: "center",
									justifyContent: "space-between",
									padding: "10px 12px",
								}}>
								<div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
									<span style={{ fontWeight: "500", fontSize: "var(--vscode-font-size)" }}>
										/{slashCommandInfo.command}
									</span>
									{slashCommandInfo.source && (
										<VSCodeBadge style={{ fontSize: "calc(var(--vscode-font-size) - 2px)" }}>
											{slashCommandInfo.source}
										</VSCodeBadge>
									)}
								</div>
								<span
									className={`codicon codicon-chevron-${isExpanded ? "up" : "down"} opacity-0 group-hover:opacity-100 transition-opacity duration-200`}></span>
							</ToolUseBlockHeader>
							{isExpanded && (slashCommandInfo.args || slashCommandInfo.description) && (
								<div
									style={{
										padding: "12px 16px",
										borderTop: "1px solid var(--vscode-editorGroup-border)",
										display: "flex",
										flexDirection: "column",
										gap: "8px",
									}}>
									{slashCommandInfo.args && (
										<div>
											<span style={{ fontWeight: "500" }}>Arguments: </span>
											<span style={{ color: "var(--vscode-descriptionForeground)" }}>
												{slashCommandInfo.args}
											</span>
										</div>
									)}
									{slashCommandInfo.description && (
										<div style={{ color: "var(--vscode-descriptionForeground)" }}>
											{slashCommandInfo.description}
										</div>
									)}
								</div>
							)}
						</div>
					</>
				)
			}
			case "generateImage":
				return (
					<>
						<div style={headerStyle}>
							{tool.isProtected ? (
								<span
									className="codicon codicon-lock"
									style={{ color: "var(--vscode-editorWarning-foreground)", marginBottom: "-1.5px" }}
								/>
							) : (
								toolIcon("file-media")
							)}
							<span style={{ fontWeight: "bold" }}>
								{message.type === "ask"
									? tool.isProtected
										? t("chat:fileOperations.wantsToGenerateImageProtected")
										: tool.isOutsideWorkspace
											? t("chat:fileOperations.wantsToGenerateImageOutsideWorkspace")
											: t("chat:fileOperations.wantsToGenerateImage")
									: t("chat:fileOperations.didGenerateImage")}
							</span>
						</div>
						{message.type === "ask" && (
							<div className="pl-6">
								<ToolUseBlock>
									<div className="p-2">
										<div className="mb-2 break-words">{tool.content}</div>
										<div className="flex items-center gap-1 text-xs text-vscode-descriptionForeground">
											{tool.path}
										</div>
									</div>
								</ToolUseBlock>
							</div>
						)}
					</>
				)
			default:
				// Generic fallback: every tool execution must show *something* in the chat UI,
				// even if no tool-specific renderer exists yet. This prevents the silent
				// `return null` UX where users see no indication that a tool was invoked
				// (or, worse, an invisible approval prompt blocking the conversation).
				return (
					<>
						{renderGenericToolBlock(tool, message.type === "ask", headerStyle, t)}
						<ToolInputSection tool={tool} isExpanded={showToolInput} onToggle={handleToggleToolInput} />
					</>
				)
		}
	}

	switch (message.type) {
		case "say":
			switch (message.say) {
				case "diff_error":
					return (
						<ErrorRow
							type="diff_error"
							message={message.text || ""}
							expandable={true}
							showCopyButton={true}
						/>
					)
				case "subtask_result":
					return (
						<div className="border-l border-muted-foreground/80 ml-2 pl-4 pt-2 pb-1 -mt-5">
							<div style={headerStyle}>
								<span style={{ fontWeight: "bold" }}>{t("chat:subtasks.resultContent")}</span>
								<Check className="size-3" />
							</div>
							<MarkdownBlock markdown={message.text} />
						</div>
					)
				case "peer_message": {
					// An INBOUND envelope, emitted by `wait` at the moment the agent read
					// it — so the human sees the other half of a conversation between
					// tasks and not only the outbound sends.
					const peer = safeJsonParse<{
						senderTaskId: string
						senderTitle: string
						message: string
						kind?: "notification" | "request" | "reply"
						subject?: string
					}>(message.text)
					if (!peer) {
						return null
					}
					return (
						<div className="border-l-2 border-[var(--vscode-charts-blue,#3b82f6)] ml-2 pl-4 pt-2 pb-1 -mt-5">
							<div style={headerStyle}>
								<Send className="size-3 text-[var(--vscode-charts-blue,#3b82f6)]" />
								<span style={{ fontWeight: "bold" }}>
									{t(
										peer.kind === "request"
											? "chat:mailbox.receivedRequest"
											: peer.kind === "reply"
												? "chat:mailbox.receivedReply"
												: "chat:mailbox.receivedNotification",
										{ sender: peer.senderTitle || peer.senderTaskId },
									)}
								</span>
							</div>
							{peer.subject && <div className="text-vscode-descriptionForeground">{peer.subject}</div>}
							<CollapsibleMarkdown markdown={peer.message} />
							{peer.senderTaskId && (
								<button
									className="cursor-pointer flex gap-1 items-center mt-2 text-vscode-descriptionForeground hover:text-vscode-descriptionForeground hover:underline font-normal"
									onClick={() =>
										vscode.postMessage({ type: "showTaskWithId", text: peer.senderTaskId })
									}>
									{t("chat:mailbox.goToSender")}
									<ArrowRight className="size-3" />
								</button>
							)}
						</div>
					)
				}
				case "reasoning":
					return (
						<ReasoningBlock
							content={message.text || ""}
							ts={message.ts}
							isStreaming={isStreaming}
							isLast={isLast}
						/>
					)
				case "tool_preparing": {
					// Inline progress row shown while tool call arguments stream in.
					// Replaces the old thinking-bubble noise ("Preparing…" + dots).
					// Multiple markers for the same tool_name are kv-updated in-place
					// via the partial-message mechanism (say(…, true)).
					const isPreparing = message.partial === true
					const preparingInfo = safeJsonParse<{ toolName: string; byteCount: number }>(message.text)

					if (!isPreparing || !preparingInfo) {
						return null // superseded by tool_call_start
					}

					const formatBytes = (bytes: number): string => {
						if (bytes >= 1024) {
							return `${(bytes / 1024).toFixed(1)} KB`
						}
						return `${bytes} B`
					}

					return (
						<div
							className="group text-sm transition-opacity opacity-100"
							style={{
								...headerStyle,
								marginBottom: 0,
								justifyContent: "space-between",
							}}>
							<div style={{ display: "flex", alignItems: "center", gap: "10px", flexGrow: 1 }}>
								<ProgressIndicator />
								<span
									style={{
										color: normalColor,
										fontWeight: 500,
										fontFamily: "var(--vscode-editor-font-family)",
									}}>
									{t("chat:toolPreparing.preparing", { toolName: preparingInfo.toolName })}
								</span>
							</div>
							<span className="text-xs font-light text-vscode-descriptionForeground">
								{formatBytes(preparingInfo.byteCount)}
							</span>
						</div>
					)
				}
				case "api_req_started": {
					// On success (cost present, no cancel reason), hide the row
					// entirely UNLESS response metadata is available — in that
					// case show a dim, minimal info-icon row so the user can
					// inspect per-request diagnostics without clutter.
					const hasMetadata = apiReqMetadata !== undefined
					if (
						!hasMetadata &&
						cost !== null &&
						cost !== undefined &&
						(apiReqCancelReason === null || apiReqCancelReason === undefined)
					) {
						return null
					}

					// Determine if the API request is in progress
					const isApiRequestInProgress =
						apiReqCancelReason === undefined && apiRequestFailedMessage === undefined && cost === undefined

					// Build a concise tooltip from the metadata fields.
					const fmtTokens = (n?: number) => (n !== undefined ? `${(n / 1000).toFixed(1)}k` : "")
					const fmtCost = (c?: number) => (c !== undefined ? `$${c.toFixed(4)}` : "")
					const metadataTooltip = hasMetadata
						? [
								apiReqMetadata.actualModel ? `model: ${apiReqMetadata.actualModel}` : "",
								apiReqMetadata.ttfbMs !== undefined ? `${apiReqMetadata.ttfbMs}ms →` : "",
								apiReqMetadata.ttlbMs !== undefined ? `${apiReqMetadata.ttlbMs}ms total` : "",
								fmtTokens(apiReqMetadata.promptTokens)
									? `${fmtTokens(apiReqMetadata.promptTokens)} in`
									: "",
								fmtTokens(apiReqMetadata.completionTokens)
									? `${fmtTokens(apiReqMetadata.completionTokens)} out`
									: "",
								fmtCost(apiReqMetadata.costUsd),
								apiReqMetadata.attempts !== undefined && apiReqMetadata.attempts > 1
									? `(${apiReqMetadata.attempts} attempts)`
									: "",
								apiReqMetadata.responseError ? `⚠ ${apiReqMetadata.responseError}` : "",
							]
								.filter(Boolean)
								.join(" · ")
						: undefined

					const opacityClass = isApiRequestInProgress
						? "opacity-100"
						: hasMetadata && cost !== null && cost !== undefined
							? "opacity-30 hover:opacity-100"
							: "opacity-40 hover:opacity-100"

					return (
						<>
							<div
								className={`group text-sm transition-opacity ${opacityClass}`}
								style={{
									...headerStyle,
									marginBottom:
										((cost === null || cost === undefined) && apiRequestFailedMessage) ||
										apiReqStreamingFailedMessage
											? 10
											: 0,
									justifyContent: "space-between",
								}}>
								<div style={{ display: "flex", alignItems: "center", gap: "6px", flexGrow: 1 }}>
									{icon}
									{title}
									{hasMetadata && (
										<StandardTooltip
											content={<span style={{ whiteSpace: "pre-wrap" }}>{metadataTooltip}</span>}
											side="top"
											align="start"
											maxWidth={320}>
											<span
												className="codicon codicon-info"
												style={{
													fontSize: 13,
													color: "var(--vscode-descriptionForeground)",
													cursor: "help",
													flexShrink: 0,
												}}
											/>
										</StandardTooltip>
									)}
								</div>
								<div
									className="text-xs text-vscode-dropdown-foreground border-vscode-dropdown-border/50 border px-1.5 py-0.5 rounded-lg"
									style={{ opacity: cost !== null && cost !== undefined && cost > 0 ? 1 : 0 }}>
									${Number(cost || 0)?.toFixed(4)}
								</div>
							</div>
							{(((cost === null || cost === undefined) && apiRequestFailedMessage) ||
								apiReqStreamingFailedMessage) && (
								<ErrorRow
									type="api_failure"
									message={apiRequestFailedMessage || apiReqStreamingFailedMessage || ""}
									docsURL={
										apiRequestFailedMessage?.toLowerCase().includes("powershell")
											? "https://github.com/shofer/shofer/wiki/TroubleShooting-%E2%80%90-%22PowerShell-is-not-recognized-as-an-internal-or-external-command%22"
											: undefined
									}
									errorDetails={apiReqStreamingFailedMessage}
								/>
							)}
						</>
					)
				}
				case "api_req_retry_delayed":
					let body = t(`chat:apiRequest.failed`)
					let retryInfo, rawError, code, docsURL
					if (message.text !== undefined) {
						// Try to show richer error message for that code, if available
						const potentialCode = parseInt(message.text.substring(0, 3))
						if (!isNaN(potentialCode) && potentialCode >= 400) {
							code = potentialCode
							const stringForError = `chat:apiRequest.errorMessage.${code}`
							if (i18n.exists(stringForError)) {
								body = t(stringForError)
								// Fill this out in upcoming PRs
								// Do not remove this
								// switch(code) {
								// 	case ERROR_CODE:
								// 		docsURL = ???
								// 		break;
								// }
							} else {
								// Non-HTTP-status-code error message - store full text as errorDetails
								body = t("chat:apiRequest.errorMessage.unknown")
								docsURL = "https://discord.gg/x39UEEQ2"
							}
						}

						// This isn't pretty, but since the retry logic happens at a lower level
						// and the message object is just a flat string, we need to extract the
						// retry information using this "tag" as a convention
						const retryTimerMatch = message.text.match(/<retry_timer>(.*?)<\/retry_timer>/)
						const retryTimer = retryTimerMatch && retryTimerMatch[1] ? parseInt(retryTimerMatch[1], 10) : 0
						rawError = message.text.replace(/<retry_timer>(.*?)<\/retry_timer>/, "").trim()
						retryInfo = retryTimer > 0 && (
							<p
								className={cn(
									"mt-2 font-light text-xs  text-vscode-descriptionForeground cursor-default flex items-center gap-1 transition-all duration-1000",
									retryTimer === 0 ? "opacity-0 max-h-0" : "max-h-2 opacity-100",
								)}>
								<Repeat2 className="size-3" strokeWidth={1.5} />
								<span>{retryTimer}s</span>
							</p>
						)
					}
					return (
						<ErrorRow
							type="api_req_retry_delayed"
							code={code}
							message={body}
							docsURL={docsURL}
							additionalContent={retryInfo}
							errorDetails={rawError}
						/>
					)
				case "api_req_rate_limit_wait": {
					const isWaiting = message.partial === true

					return isWaiting && rateLimitWaitSeconds !== undefined ? (
						<div
							className={`group text-sm transition-opacity opacity-100`}
							style={{
								...headerStyle,
								marginBottom: 0,
								justifyContent: "space-between",
							}}>
							<div style={{ display: "flex", alignItems: "center", gap: "10px", flexGrow: 1 }}>
								<ProgressIndicator />
								<span style={{ color: normalColor }}>{t("chat:apiRequest.rateLimitWait")}</span>
							</div>
							<span className="text-xs font-light text-vscode-descriptionForeground">
								{rateLimitWaitSeconds}s
							</span>
						</div>
					) : null
				}
				case "api_req_finished":
					return null // we should never see this message type
				case "text":
					return (
						<div>
							<Markdown markdown={message.text} partial={message.partial} />
							{message.images && message.images.length > 0 && (
								<div style={{ marginTop: "10px" }}>
									{message.images.map((image, index) => (
										<ImageBlock key={index} imageData={image} />
									))}
								</div>
							)}
						</div>
					)
				case "user_feedback":
					return (
						<div className="group">
							<div style={headerStyle}>
								<User className="w-4 shrink-0" aria-label="User icon" />
								<span style={{ fontWeight: "bold" }}>{t("chat:feedback.youSaid")}</span>
							</div>
							<div
								className={cn(
									"ml-6 border rounded-sm overflow-hidden whitespace-pre-wrap",
									isEditing
										? "bg-vscode-editor-background text-vscode-editor-foreground"
										: "cursor-text p-1 bg-vscode-editor-foreground/70 text-vscode-editor-background",
								)}>
								{isEditing ? (
									<div className="flex flex-col gap-2">
										<ChatTextArea
											inputValue={editedContent}
											setInputValue={setEditedContent}
											sendingDisabled={false}
											selectApiConfigDisabled={true}
											placeholderText={t("chat:editMessage.placeholder")}
											selectedImages={editImages}
											setSelectedImages={setEditImages}
											onSend={handleSaveEdit}
											onSelectImages={handleSelectImages}
											shouldDisableImages={!model?.supportsImages}
											mode={editMode}
											setMode={setEditMode}
											modeShortcutText=""
											isEditMode={true}
											onCancel={handleCancelEdit}
										/>
									</div>
								) : (
									<div className="flex justify-between">
										<div
											className="flex-grow px-2 py-1 wrap-anywhere rounded-lg transition-colors"
											onClick={(e) => {
												e.stopPropagation()
												if (!isStreaming) {
													handleEditClick()
												}
											}}
											title={t("chat:queuedMessages.clickToEdit")}>
											<Mention text={message.text} withShadow />
										</div>
										<div className="flex gap-2 pr-1">
											<div
												className="cursor-pointer shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
												style={{ visibility: isStreaming ? "hidden" : "visible" }}
												onClick={(e) => {
													e.stopPropagation()
													handleEditClick()
												}}>
												<Edit className="w-4 shrink-0" aria-label="Edit message icon" />
											</div>
											<div
												className="cursor-pointer shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
												style={{ visibility: isStreaming ? "hidden" : "visible" }}
												onClick={(e) => {
													e.stopPropagation()
													vscode.postMessage({ type: "deleteMessage", value: message.ts })
												}}>
												<Trash2 className="w-4 shrink-0" aria-label="Delete message icon" />
											</div>
										</div>
									</div>
								)}
								{!isEditing && message.images && message.images.length > 0 && (
									<Thumbnails images={message.images} style={{ marginTop: "8px" }} />
								)}
							</div>
						</div>
					)
				case "user_feedback_diff":
					const tool = safeJsonParse<ShoferSayTool>(message.text)
					return (
						<div style={{ marginTop: -10, width: "100%" }}>
							<CodeAccordion
								code={tool?.diff}
								language="diff"
								isFeedback={true}
								isExpanded={isExpanded}
								onToggleExpand={handleToggleExpand}
							/>
						</div>
					)
				case "error":
					// Check if this is a model response error based on marker strings from backend
					const isNoToolsUsedError = message.text === "MODEL_NO_TOOLS_USED"
					const isNoAssistantMessagesError = message.text === "MODEL_NO_ASSISTANT_MESSAGES"

					if (isNoToolsUsedError) {
						return (
							<ErrorRow
								type="error"
								title={t("chat:modelResponseIncomplete")}
								message={t("chat:modelResponseErrors.noToolsUsed")}
								errorDetails={t("chat:modelResponseErrors.noToolsUsedDetails")}
							/>
						)
					}

					if (isNoAssistantMessagesError) {
						return (
							<ErrorRow
								type="error"
								title={t("chat:modelResponseIncomplete")}
								message={t("chat:modelResponseErrors.noAssistantMessages")}
								errorDetails={t("chat:modelResponseErrors.noAssistantMessagesDetails")}
							/>
						)
					}

					// Fallback for generic errors
					return (
						<ErrorRow type="error" message={message.text || t("chat:error")} errorDetails={message.text} />
					)
				case "completion_result":
					return (
						<div className="group">
							<div style={headerStyle}>
								{icon}
								{title}
								<div style={{ flexGrow: 1 }} />
								<OpenMarkdownPreviewButton markdown={message.text} />
							</div>
							<div className="border-l border-green-600/30 ml-2 pl-4 pb-1">
								<Markdown markdown={message.text} />
							</div>
						</div>
					)
				case "shell_integration_warning":
					return <CommandExecutionError />
				case "plugin_marker": {
					// A plugin's own timeline row: the host renders no chrome and no
					// fallback text — the owning plugin's `chat-message-addon` component
					// is the whole row, so an unloadable component shows nothing rather
					// than a half-rendered host guess at what the marker meant.
					if (!message.marker) return null
					return (
						<PluginSlot
							region="chat-message-addon"
							pluginName={message.marker.pluginName}
							message={{
								ts: message.ts!,
								text: message.text,
								kind: message.marker.kind,
								data: message.marker.data,
								restorable: message.marker.restorable,
							}}
						/>
					)
				}
				case "condense_context":
					// In-progress state
					if (message.partial) {
						return <InProgressRow eventType="condense_context" />
					}
					// Completed state
					if (message.contextCondense) {
						return <CondensationResultRow data={message.contextCondense} />
					}
					return null
				case "condense_context_error":
					return <CondensationErrorRow errorText={message.text} />
				case "sliding_window_truncation":
					// In-progress state
					if (message.partial) {
						return <InProgressRow eventType="sliding_window_truncation" />
					}
					// Completed state
					if (message.contextTruncation) {
						return <TruncationResultRow data={message.contextTruncation} />
					}
					return null
				case "tool_result": {
					// Render raw tool output in an expandable section beneath the tool invocation.
					const resultInfo = safeJsonParse<import("@shofer/types").ShoferSayToolResult>(message.text || "{}")
					if (!resultInfo) return null
					return <ToolOutputSection tool={resultInfo.tool} output={resultInfo.output} />
				}
				case "user_edit_todos":
					return <UpdateTodoListToolBlock userEdited onChange={() => {}} />
				case "tool" as any:
					// Handle say tool messages
					const sayTool = safeJsonParse<ShoferSayTool>(message.text)
					if (!sayTool) return null

					switch (sayTool.tool) {
						case "runSlashCommand": {
							const slashCommandInfo = sayTool
							return (
								<>
									<div style={headerStyle}>
										<span
											className="codicon codicon-terminal-cmd"
											style={{
												color: "var(--vscode-foreground)",
												marginBottom: "-1.5px",
											}}></span>
										<span style={{ fontWeight: "bold" }}>{t("chat:slashCommand.didRun")}</span>
									</div>
									<div className="pl-6">
										<ToolUseBlock>
											<ToolUseBlockHeader
												style={{
													display: "flex",
													flexDirection: "column",
													alignItems: "flex-start",
													gap: "4px",
													padding: "10px 12px",
												}}>
												<div
													style={{
														display: "flex",
														alignItems: "center",
														gap: "8px",
														width: "100%",
													}}>
													<span
														style={{
															fontWeight: "500",
															fontSize: "var(--vscode-font-size)",
														}}>
														/{slashCommandInfo.command}
													</span>
													{slashCommandInfo.args && (
														<span
															style={{
																color: "var(--vscode-descriptionForeground)",
																fontSize: "var(--vscode-font-size)",
															}}>
															{slashCommandInfo.args}
														</span>
													)}
												</div>
												{slashCommandInfo.description && (
													<div
														style={{
															color: "var(--vscode-descriptionForeground)",
															fontSize: "calc(var(--vscode-font-size) - 1px)",
														}}>
														{slashCommandInfo.description}
													</div>
												)}
												{slashCommandInfo.source && (
													<div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
														<VSCodeBadge
															style={{ fontSize: "calc(var(--vscode-font-size) - 2px)" }}>
															{slashCommandInfo.source}
														</VSCodeBadge>
													</div>
												)}
											</ToolUseBlockHeader>
										</ToolUseBlock>
									</div>
									<ToolInputSection
										tool={sayTool}
										isExpanded={showToolInput}
										onToggle={handleToggleToolInput}
									/>
								</>
							)
						}
						case "readCommandOutput": {
							const formatBytes = (bytes: number) => {
								if (bytes < 1024) return `${bytes} B`
								if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
								return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
							}

							// Determine if this is a search operation
							const isSearch = sayTool.searchPattern !== undefined

							let infoText = ""
							if (isSearch) {
								// Search mode: show pattern and match count
								const matchText =
									sayTool.matchCount !== undefined
										? sayTool.matchCount === 1
											? "1 match"
											: `${sayTool.matchCount} matches`
										: ""
								infoText = `search: "${sayTool.searchPattern}"${matchText ? ` • ${matchText}` : ""}`
							} else if (
								sayTool.readStart !== undefined &&
								sayTool.readEnd !== undefined &&
								sayTool.totalBytes !== undefined
							) {
								// Read mode: show byte range
								infoText = `${formatBytes(sayTool.readStart)} - ${formatBytes(sayTool.readEnd)} of ${formatBytes(sayTool.totalBytes)}`
							} else if (sayTool.totalBytes !== undefined) {
								infoText = formatBytes(sayTool.totalBytes)
							}

							return (
								<>
									<div style={headerStyle}>
										<FileCode2 className="w-4 shrink-0" aria-label="Read command output icon" />
										<span style={{ fontWeight: "bold" }}>{t("chat:readCommandOutput.title")}</span>
										{infoText && (
											<span
												className="text-xs ml-1"
												style={{ color: "var(--vscode-descriptionForeground)" }}>
												({infoText})
											</span>
										)}
									</div>
									<ToolInputSection
										tool={sayTool}
										isExpanded={showToolInput}
										onToggle={handleToggleToolInput}
									/>
								</>
							)
						}
						case "sendMessage": {
							// An outbound envelope. `kind` is what the reader needs first —
							// a request is owed an answer and a notification is not.
							const targetTaskId = sayTool.task_id
							const targetLabel = sayTool.task_title ?? targetTaskId
							return (
								<>
									<div style={headerStyle}>
										<Send className="size-3 text-[var(--vscode-charts-blue,#3b82f6)]" />
										<span style={{ fontWeight: "bold" }}>
											{sayTool.kind === "request"
												? t("chat:mailbox.sentRequest", { target: targetLabel })
												: t("chat:mailbox.sentNotification", { target: targetLabel })}
										</span>
										{typeof sayTool.timeout_sec === "number" && (
											<span className="ml-1 text-xs text-vscode-descriptionForeground">
												{t("chat:mailbox.expiresIn", { seconds: sayTool.timeout_sec })}
											</span>
										)}
									</div>
									{sayTool.subject && (
										<div className="pl-6 text-vscode-descriptionForeground">{sayTool.subject}</div>
									)}
									{sayTool.message && (
										<div className="pl-6">
											<CollapsibleMarkdown markdown={sayTool.message} />
										</div>
									)}
									{targetTaskId && (
										<button
											className="cursor-pointer flex gap-1 items-center mt-2 pl-6 text-vscode-descriptionForeground hover:text-vscode-descriptionForeground hover:underline font-normal"
											onClick={() =>
												vscode.postMessage({ type: "showTaskWithId", text: targetTaskId })
											}>
											{t("chat:mailbox.goToTarget")}
											<ArrowRight className="size-3" />
										</button>
									)}
								</>
							)
						}
						case "reply": {
							// One row per answered request — a batch reply is still one turn.
							const replies = sayTool.replies ?? []
							return (
								<>
									<div style={headerStyle}>
										<Send className="size-3 text-[var(--vscode-charts-blue,#3b82f6)]" />
										<span style={{ fontWeight: "bold" }}>
											{t("chat:mailbox.replied", { count: replies.length })}
										</span>
									</div>
									{replies.map((item) => (
										<div key={item.message_id} className="pl-6 mt-1">
											<div className="text-xs text-vscode-descriptionForeground">
												{item.message_id}
											</div>
											<CollapsibleMarkdown markdown={item.body} />
										</div>
									))}
								</>
							)
						}
						case "wait": {
							// Parking on the mailbox. The wake condition, when there is one,
							// is the only thing worth showing: it says WHY the agent stopped.
							const seconds = typeof sayTool.timeout_sec === "number" ? sayTool.timeout_sec : undefined
							const condition = sayTool.in_reply_to
								? t("chat:mailbox.waitingForReply", { id: sayTool.in_reply_to })
								: sayTool.from_ids?.length
									? t("chat:mailbox.waitingForSenders", { senders: sayTool.from_ids.join(", ") })
									: undefined
							return (
								<>
									<div style={headerStyle}>
										{toolIcon("watch")}
										<span style={{ fontWeight: "bold" }}>
											{seconds !== undefined
												? t("chat:mailbox.waitWithTimeout", { timeout: seconds })
												: t("chat:mailbox.wait")}
										</span>
									</div>
									{condition && (
										<div className="pl-6 text-vscode-descriptionForeground">{condition}</div>
									)}
								</>
							)
						}
						default:
							return (
								<>
									{renderGenericToolBlock(sayTool, false, headerStyle, t)}
									<ToolInputSection
										tool={sayTool}
										isExpanded={showToolInput}
										onToggle={handleToggleToolInput}
									/>
								</>
							)
					}
				case "image":
					// Parse the JSON to get imageUri and imagePath
					const imageInfo = safeJsonParse<{ imageUri: string; imagePath: string }>(message.text || "{}")
					if (!imageInfo) {
						return null
					}
					return (
						<div style={{ marginTop: "10px" }}>
							<ImageBlock imageUri={imageInfo.imageUri} imagePath={imageInfo.imagePath} />
						</div>
					)
				case "too_many_tools_warning": {
					const warningData = safeJsonParse<{
						toolCount: number
						serverCount: number
						threshold: number
					}>(message.text || "{}")
					if (!warningData) return null
					const toolsPart = t("chat:tooManyTools.toolsPart", { count: warningData.toolCount })
					const serversPart = t("chat:tooManyTools.serversPart", { count: warningData.serverCount })
					return (
						<WarningRow
							title={t("chat:tooManyTools.title")}
							message={t("chat:tooManyTools.messageTemplate", {
								tools: toolsPart,
								servers: serversPart,
								threshold: warningData.threshold,
							})}
							actionText={t("chat:tooManyTools.openMcpSettings")}
							onAction={() =>
								window.postMessage(
									{ type: "action", action: "settingsButtonClicked", values: { section: "mcp" } },
									"*",
								)
							}
						/>
					)
				}
				default:
					return (
						<>
							{title && (
								<div style={headerStyle}>
									{icon}
									{title}
								</div>
							)}
							<div style={{ paddingTop: 10 }}>
								<Markdown markdown={message.text} partial={message.partial} />
							</div>
						</>
					)
			}
		case "ask":
			switch (message.ask) {
				case "mistake_limit_reached":
					return <ErrorRow type="mistake_limit" message={message.text || ""} errorDetails={message.text} />
				case "command":
					return (
						<CommandExecution
							executionId={message.ts.toString()}
							text={message.text}
							icon={icon}
							title={title}
						/>
					)
				case "use_mcp_server":
					// Parse the message text to get the MCP server request
					const messageJson = safeJsonParse<any>(message.text, {})

					// Extract the response field if it exists
					const { response, ...mcpServerRequest } = messageJson

					// Create the useMcpServer object with the response field
					const useMcpServer: ShoferAskUseMcpServer = {
						...mcpServerRequest,
						response,
					}

					if (!useMcpServer) {
						return null
					}

					const server = mcpServers.find((server) => server.name === useMcpServer.serverName)

					return (
						<>
							<div style={headerStyle}>
								{icon}
								{title}
							</div>
							<div className="w-full bg-vscode-editor-background border border-vscode-border rounded-xs p-2 mt-2">
								{useMcpServer.type === "access_mcp_resource" && (
									<McpResourceRow
										item={{
											// Use the matched resource/template details, with fallbacks
											...(findMatchingResourceOrTemplate(
												useMcpServer.uri || "",
												server?.resources,
												server?.resourceTemplates,
											) || {
												name: "",
												mimeType: "",
												description: "",
											}),
											// Always use the actual URI from the request
											uri: useMcpServer.uri || "",
										}}
									/>
								)}
								{useMcpServer.type === "use_mcp_tool" && (
									<McpExecution
										executionId={message.ts.toString()}
										text={useMcpServer.arguments !== "{}" ? useMcpServer.arguments : undefined}
										serverName={useMcpServer.serverName}
										toolName={useMcpServer.toolName}
										isArguments={true}
										server={server}
										useMcpServer={useMcpServer}
									/>
								)}
							</div>
						</>
					)
				case "completion_result":
					if (message.text) {
						return (
							<div className="group">
								<div style={headerStyle}>
									{icon}
									{title}
									<div style={{ flexGrow: 1 }} />
									<OpenMarkdownPreviewButton markdown={message.text} />
								</div>
								<div style={{ color: "var(--vscode-charts-green)", paddingTop: 10 }}>
									<Markdown markdown={message.text} partial={message.partial} />
								</div>
							</div>
						)
					} else {
						return null // Don't render anything when we get a completion_result ask without text
					}
				case "followup":
					return (
						<>
							{title && (
								<div style={headerStyle}>
									{icon}
									{title}
								</div>
							)}
							<div className="flex flex-col gap-2 ml-6">
								<Markdown
									markdown={message.partial === true ? message?.text : followUpData?.question}
								/>
								{followUpData?.paramForm && followUpData.paramForm.length > 0 ? (
									<WorkflowParamForm
										params={followUpData.paramForm}
										onSubmit={onParamFormSubmit}
										isAnswered={isFollowUpAnswered}
										answeredValues={followUpData.answeredValues}
									/>
								) : (
									<FollowUpSuggest
										suggestions={followUpData?.suggest}
										onSuggestionClick={onSuggestionClick}
										ts={message?.ts}
										onCancelAutoApproval={onFollowUpUnmount}
										isAnswered={isFollowUpAnswered}
										isFollowUpAutoApprovalPaused={isFollowUpAutoApprovalPaused}
									/>
								)}
							</div>
						</>
					)
				case "auto_approval_max_req_reached": {
					return <AutoApprovedRequestLimitWarning message={message} />
				}
				default:
					return null
			}
	}
}
