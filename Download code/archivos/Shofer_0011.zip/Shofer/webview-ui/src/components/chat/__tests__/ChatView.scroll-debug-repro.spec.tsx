import React, { useEffect, useImperativeHandle, useRef } from "react"
import { act, fireEvent, render, waitFor } from "@/utils/test-utils"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"

import type { ShoferMessage } from "@shofer/types"

import { ExtensionStateContextProvider } from "@src/context/ExtensionStateContext"

import ChatView, { type ChatViewProps } from "../ChatView"

type FollowOutput = ((isAtBottom: boolean) => "auto" | false) | "auto" | false

interface ExtensionStateMessage {
	type: "stateInit"
	state: {
		version: string
		shoferMessages: ShoferMessage[]
		taskHistory: unknown[]
		shouldShowAnnouncement: boolean
		allowedCommands: string[]
		alwaysAllowExecute: boolean
		cloudIsAuthenticated: boolean
		telemetrySetting: "enabled" | "disabled" | "unset"
	}
}

interface MockVirtuosoHandle {
	scrollToIndex: (options: {
		index: number | "LAST"
		align?: "end" | "start" | "center"
		behavior?: "auto" | "smooth"
	}) => void
}

interface MockVirtuosoProps {
	data: ShoferMessage[]
	itemContent: (index: number, item: ShoferMessage) => React.ReactNode
	atBottomStateChange?: (isAtBottom: boolean) => void
	followOutput?: FollowOutput
	className?: string
	initialTopMostItemIndex?: number
	firstItemIndex?: number
}

interface VirtuosoHarnessState {
	scrollCalls: number
	atBottomAfterCalls: number
	signalDelayMs: number
	emitFalseOnDataChange: boolean
	delayedGrowthMs: number | null
	initialTopMostItemIndex: number | undefined
	firstItemIndex: number | undefined
	followOutput: FollowOutput | undefined
	emitAtBottom: (isAtBottom: boolean) => void
	// Increments once per MockVirtuoso mount. A change to the <Virtuoso> `key`
	// prop remounts it, so this doubles as a remount detector (H24 scroll flash).
	mountCount: number
}

const harness = vi.hoisted<VirtuosoHarnessState>(() => ({
	scrollCalls: 0,
	atBottomAfterCalls: Number.POSITIVE_INFINITY,
	signalDelayMs: 20,
	emitFalseOnDataChange: true,
	delayedGrowthMs: null,
	initialTopMostItemIndex: undefined,
	firstItemIndex: undefined,
	followOutput: undefined,
	emitAtBottom: () => {},
	mountCount: 0,
}))

function nullDefaultModule() {
	return { default: () => null }
}

vi.mock("@src/utils/vscode", () => ({ vscode: { postMessage: vi.fn() } }))
vi.mock("use-sound", () => ({ default: vi.fn().mockImplementation(() => [vi.fn()]) }))
vi.mock("../common/VersionIndicator", nullDefaultModule)
vi.mock("../history/HistoryPreview", nullDefaultModule)
vi.mock("@src/components/welcome/ShoferHero", nullDefaultModule)
vi.mock("@src/components/welcome/ShoferTips", nullDefaultModule)
vi.mock("../Announcement", nullDefaultModule)
vi.mock("./TaskHeader", () => ({ default: () => <div data-testid="task-header" /> }))
vi.mock("./ProfileViolationWarning", nullDefaultModule)
vi.mock("../common/DismissibleUpsell", nullDefaultModule)

vi.mock("./CheckpointWarning", () => ({ CheckpointWarning: () => null }))
vi.mock("./QueuedMessages", () => ({ QueuedMessages: () => null }))

vi.mock("@vscode/webview-ui-toolkit/react", () => ({
	VSCodeLink: ({ children }: { children: React.ReactNode }) => <>{children}</>,
}))

vi.mock("@/components/ui", async (importOriginal) => {
	const actual = await importOriginal<typeof import("@/components/ui")>()
	return {
		...actual,
		StandardTooltip: ({ children }: { children: React.ReactNode }) => <>{children}</>,
	}
})

vi.mock("../ChatTextArea", () => {
	const MockTextArea = React.forwardRef(function MockTextArea(
		props: {
			inputValue?: string
			setInputValue?: (value: string) => void
			onSend: () => void
			sendingDisabled?: boolean
		},
		ref: React.ForwardedRef<{ focus: () => void }>,
	) {
		useImperativeHandle(ref, () => ({ focus: () => {} }))

		return (
			<input
				value={props.inputValue ?? ""}
				onChange={(event) => props.setInputValue?.(event.target.value)}
				onKeyDown={(event) => {
					if (event.key === "Enter" && !props.sendingDisabled) {
						props.onSend()
					}
				}}
			/>
		)
	})

	return { default: MockTextArea, ChatTextArea: MockTextArea }
})

vi.mock("../ChatRow", () => ({
	default: ({ message }: { message: ShoferMessage }) => <div data-testid="chat-row">{message.ts}</div>,
}))

vi.mock("react-virtuoso", () => {
	const MockVirtuoso = React.forwardRef<MockVirtuosoHandle, MockVirtuosoProps>(function MockVirtuoso(
		{ data, itemContent, atBottomStateChange, followOutput, className, initialTopMostItemIndex, firstItemIndex },
		ref,
	) {
		const atBottomRef = useRef(atBottomStateChange)
		const timeoutIdsRef = useRef<number[]>([])

		// Mount-once effect: increments when this component is freshly mounted.
		// A change to the <Virtuoso> `key` prop forces a remount, so a jump in
		// mountCount across a state push means the list remounted (H24 flash).
		useEffect(() => {
			harness.mountCount += 1
		}, [])

		harness.followOutput = followOutput
		harness.initialTopMostItemIndex = initialTopMostItemIndex
		harness.firstItemIndex = firstItemIndex
		harness.emitAtBottom = (isAtBottom: boolean) => {
			atBottomRef.current?.(isAtBottom)
		}

		useImperativeHandle(ref, () => ({
			scrollToIndex: () => {
				harness.scrollCalls += 1
				const reachedBottom = harness.scrollCalls >= harness.atBottomAfterCalls
				const timeoutId = window.setTimeout(() => {
					atBottomRef.current?.(reachedBottom)
				}, harness.signalDelayMs)
				timeoutIdsRef.current.push(timeoutId)
			},
		}))

		useEffect(() => {
			atBottomRef.current = atBottomStateChange
		}, [atBottomStateChange])

		useEffect(() => {
			if (harness.emitFalseOnDataChange) {
				atBottomStateChange?.(false)
			}

			if (harness.delayedGrowthMs !== null) {
				const timeoutId = window.setTimeout(() => {
					atBottomRef.current?.(false)
				}, harness.delayedGrowthMs)
				timeoutIdsRef.current.push(timeoutId)
			}
		}, [data.length, atBottomStateChange])

		useEffect(
			() => () => {
				timeoutIdsRef.current.forEach((id) => window.clearTimeout(id))
				timeoutIdsRef.current = []
			},
			[],
		)

		return (
			<div data-testid="virtuoso-item-list" className={className} data-count={data.length}>
				{data.map((item, index) => (
					<div key={item.ts} data-testid={`virtuoso-item-${index}`}>
						{itemContent(index, item)}
					</div>
				))}
			</div>
		)
	})

	return { Virtuoso: MockVirtuoso }
})

const props: ChatViewProps = {
	isHidden: false,
	showAnnouncement: false,
	hideAnnouncement: () => {},
}

const sleep = (ms: number) => new Promise<void>((resolve) => window.setTimeout(resolve, ms))

const buildMessages = (baseTs: number): ShoferMessage[] => [
	{ type: "say", say: "text", ts: baseTs, text: "task" },
	{ type: "say", say: "text", ts: baseTs + 1, text: "row-1" },
	{ type: "say", say: "text", ts: baseTs + 2, text: "row-2" },
]

const resolveFollowOutput = (isAtBottom: boolean): "auto" | false => {
	const followOutput = harness.followOutput
	if (typeof followOutput === "function") {
		return followOutput(isAtBottom)
	}
	return followOutput === "auto" ? "auto" : false
}

const postState = (shoferMessages: ShoferMessage[]) => {
	const message: ExtensionStateMessage = {
		type: "stateInit",
		state: {
			version: "1.0.0",
			shoferMessages,
			taskHistory: [],
			shouldShowAnnouncement: false,
			allowedCommands: [],
			alwaysAllowExecute: false,
			cloudIsAuthenticated: false,
			telemetrySetting: "enabled",
		},
	}

	window.dispatchEvent(
		new MessageEvent("message", {
			data: message,
		}),
	)
}

// Windowed cold-load: only a tail of messages is resident and
// `hasMoreShoferMessages` is true, so ChatView synthesizes the (stable) task
// header from `currentTaskItem` and the Virtuoso list holds just the tail.
const postWindowedState = (shoferMessages: ShoferMessage[], currentTaskId: string, rootTs: number) => {
	const message = {
		type: "stateInit",
		state: {
			version: "1.0.0",
			shoferMessages,
			taskHistory: [],
			shouldShowAnnouncement: false,
			allowedCommands: [],
			alwaysAllowExecute: false,
			cloudIsAuthenticated: false,
			telemetrySetting: "enabled",
			hasMoreShoferMessages: true,
			currentTaskId,
			currentTaskItem: { id: currentTaskId, ts: rootTs, task: "root prompt", number: 1 },
		},
	} as unknown as ExtensionStateMessage

	window.dispatchEvent(new MessageEvent("message", { data: message }))
}

// Simulate the host delivering an older page (the "Load older messages…"
// action), which prepends to the front of the resident array.
const prependOlder = (older: ShoferMessage[], taskId: string) => {
	window.dispatchEvent(
		new MessageEvent("message", {
			data: { type: "shoferMessagesPrepended", shoferMessages: older, taskId },
		}),
	)
}

const renderView = () =>
	render(
		<ExtensionStateContextProvider>
			<QueryClientProvider client={new QueryClient()}>
				<ChatView {...props} />
			</QueryClientProvider>
		</ExtensionStateContextProvider>,
	)

const hydrate = async (atBottomAfterCalls: number) => {
	harness.atBottomAfterCalls = atBottomAfterCalls
	renderView()
	await act(async () => {
		await Promise.resolve()
	})
	await act(async () => {
		postState(buildMessages(Date.now() - 3_000))
	})
	await waitFor(() => {
		const list = document.querySelector("[data-testid='virtuoso-item-list']")
		expect(list).toBeTruthy()
		expect(list?.getAttribute("data-count")).toBe("2")
	})
}

const waitForCalls = async (min: number, timeout = 1_500) => {
	await waitFor(() => expect(harness.scrollCalls).toBeGreaterThanOrEqual(min), { timeout })
}

const waitForCallsSettled = async (idleMs = 80, timeoutMs = 2_000) => {
	const deadline = Date.now() + timeoutMs
	let lastSeen = harness.scrollCalls

	while (Date.now() < deadline) {
		await sleep(idleMs)
		const current = harness.scrollCalls

		if (current === lastSeen) {
			await sleep(idleMs)
			if (harness.scrollCalls === current) {
				return
			}
		}

		lastSeen = current
	}

	throw new Error(`Expected scroll calls to settle within ${timeoutMs}ms, last count: ${harness.scrollCalls}`)
}

const getScrollable = (): HTMLElement => {
	const scrollable = document.querySelector(".scrollable")
	if (!(scrollable instanceof HTMLElement)) {
		throw new Error("Expected ChatView scrollable container")
	}
	return scrollable
}

const getScrollToBottomButton = (): HTMLButtonElement => {
	const icon = document.querySelector(".codicon-chevron-down")
	if (!(icon instanceof HTMLElement)) {
		throw new Error("Expected scroll-to-bottom icon")
	}

	const button = icon.closest("button")
	if (!(button instanceof HTMLButtonElement)) {
		throw new Error("Expected scroll-to-bottom button")
	}

	return button
}

describe("ChatView scroll behavior regression coverage", () => {
	beforeEach(() => {
		harness.scrollCalls = 0
		harness.atBottomAfterCalls = Number.POSITIVE_INFINITY
		harness.signalDelayMs = 20
		harness.emitFalseOnDataChange = true
		harness.delayedGrowthMs = null
		harness.initialTopMostItemIndex = undefined
		harness.firstItemIndex = undefined
		harness.followOutput = undefined
		harness.emitAtBottom = () => {}
		harness.mountCount = 0
	})

	it("existing-task entry sets initialTopMostItemIndex to the message count", async () => {
		await hydrate(2)
		// initialTopMostItemIndex is set to groupedMessages.length - 1 so the Virtuoso
		// renders the last message as the top-most visible item on task entry.
		expect(harness.initialTopMostItemIndex).toBe(1)
	})

	it("decrements firstItemIndex by the rows prepended when older messages load (H24)", async () => {
		// Regression: clicking "Load older messages…" prepends a page to the
		// front of the list. Without Virtuoso's firstItemIndex anchor decreasing
		// by the number of prepended rows, the viewport keeps its scrollTop while
		// the content slides down — the visible jump. Assert the anchor tracks the
		// prepend exactly.
		const taskId = "task-1"
		const base = Date.now() - 10_000
		// Resident windowed tail (the synthetic header is rendered separately, so
		// all three remain as list rows).
		const tail: ShoferMessage[] = [
			{ type: "say", say: "text", ts: base + 100, text: "tail-1" },
			{ type: "say", say: "text", ts: base + 101, text: "tail-2" },
			{ type: "say", say: "text", ts: base + 102, text: "tail-3" },
		]

		renderView()
		await act(async () => {
			await Promise.resolve()
		})
		await act(async () => {
			postWindowedState(tail, taskId, base)
		})

		await waitFor(() => {
			const list = document.querySelector("[data-testid='virtuoso-item-list']")
			expect(list?.getAttribute("data-count")).toBe("3")
		})
		// First windowed render: the anchor sits at the START constant.
		const startIndex = harness.firstItemIndex
		expect(startIndex).toBe(1_000_000)

		await act(async () => {
			prependOlder(
				[
					{ type: "say", say: "text", ts: base + 1, text: "older-1" },
					{ type: "say", say: "text", ts: base + 2, text: "older-2" },
				],
				taskId,
			)
		})

		await waitFor(() => {
			const list = document.querySelector("[data-testid='virtuoso-item-list']")
			expect(list?.getAttribute("data-count")).toBe("5")
		})
		// Two rows prepended → anchor drops by exactly two; a plain re-render or a
		// task-switch reset would leave it unchanged or back at START.
		expect(harness.firstItemIndex).toBe((startIndex as number) - 2)
	})

	it("does not remount Virtuoso when currentTaskItem.ts mutates during windowed streaming (H24)", async () => {
		// The host updates HistoryItem.ts (→ currentTaskItem.ts) to last-activity
		// time on every push. Pre-fix that flowed into the synthetic header's ts →
		// task.ts → the Virtuoso `key`, remounting the list (flash to top) on every
		// streamed append. The frozen-header-ts fix must keep the key stable.
		const taskId = "task-mut"
		const base = Date.now() - 10_000
		const tail: ShoferMessage[] = [
			{ type: "say", say: "text", ts: base + 100, text: "tail-1" },
			{ type: "say", say: "text", ts: base + 101, text: "tail-2" },
		]

		renderView()
		await act(async () => {
			await Promise.resolve()
		})
		await act(async () => {
			postWindowedState(tail, taskId, base)
		})
		await waitFor(() => {
			const list = document.querySelector("[data-testid='virtuoso-item-list']")
			expect(list?.getAttribute("data-count")).toBe("2")
		})
		const mountsAfterFirst = harness.mountCount
		expect(mountsAfterFirst).toBeGreaterThan(0)

		// A later push for the SAME task: one more message AND a mutated
		// currentTaskItem.ts (last-activity time advanced).
		const tail2: ShoferMessage[] = [...tail, { type: "say", say: "text", ts: base + 102, text: "tail-3" }]
		await act(async () => {
			postWindowedState(tail2, taskId, base + 5000)
		})
		await waitFor(() => {
			const list = document.querySelector("[data-testid='virtuoso-item-list']")
			expect(list?.getAttribute("data-count")).toBe("3")
		})
		// No remount: the frozen header ts keeps task.ts (the Virtuoso key) stable
		// despite currentTaskItem.ts changing. Pre-fix mountCount would increment.
		expect(harness.mountCount).toBe(mountsAfterFirst)
	})

	it("rehydration uses bounded bottom pinning", async () => {
		await hydrate(2)
		await waitForCalls(2, 1_200)
		await waitForCallsSettled()
		expect(harness.scrollCalls).toBe(2)
		expect(resolveFollowOutput(false)).toBe("auto")
		expect(document.querySelector(".codicon-chevron-down")).toBeNull()
	})

	it("transient hydration-time not-at-bottom signals do not disable sticky follow", async () => {
		await hydrate(2)
		await waitForCalls(1, 1_200)
		expect(resolveFollowOutput(false)).toBe("auto")
		expect(document.querySelector(".codicon-chevron-down")).toBeNull()

		await act(async () => {
			harness.emitAtBottom(false)
		})

		expect(resolveFollowOutput(false)).toBe("auto")
		expect(document.querySelector(".codicon-chevron-down")).toBeNull()

		await waitForCalls(2, 1_200)
		await waitForCallsSettled()
		expect(harness.scrollCalls).toBe(2)
		expect(resolveFollowOutput(false)).toBe("auto")
	})

	it("delayed last-row growth during hydration converges with bounded retries", async () => {
		harness.delayedGrowthMs = 320
		await hydrate(3)
		await waitForCalls(1, 1_200)

		await sleep(950)

		// With MAX_HYDRATION_RETRIES=3 and atBottomAfterCalls=3, the hook needs
		// 3 scroll attempts before isAtBottom becomes true.
		expect(harness.scrollCalls).toBe(3)
		expect(resolveFollowOutput(false)).toBe("auto")
		expect(document.querySelector(".codicon-chevron-down")).toBeNull()
	})

	it("user escape hatch during hydration prevents repinning", async () => {
		await hydrate(Number.POSITIVE_INFINITY)
		await waitForCalls(1, 1_200)

		await act(async () => {
			fireEvent.keyDown(window, { key: "PageUp" })
		})

		expect(resolveFollowOutput(false)).toBe(false)

		await act(async () => {
			harness.emitAtBottom(true)
		})

		expect(resolveFollowOutput(false)).toBe(false)

		await waitFor(() => expect(document.querySelector(".codicon-chevron-down")).toBeTruthy(), {
			timeout: 1_200,
		})
	})

	it("non-wheel upward intent disengages sticky follow", async () => {
		await hydrate(2)
		await waitForCalls(2)
		await waitForCallsSettled()
		expect(resolveFollowOutput(false)).toBe("auto")

		const scrollable = getScrollable()
		scrollable.scrollTop = 240

		await act(async () => {
			fireEvent.pointerDown(scrollable)
			scrollable.scrollTop = 120
			fireEvent.scroll(scrollable)
			fireEvent.pointerUp(window)
		})

		expect(resolveFollowOutput(false)).toBe(false)
	})

	it("nested scroller scroll events do not falsely disengage sticky follow", async () => {
		await hydrate(2)
		await waitForCalls(2)
		await waitForCallsSettled()
		expect(resolveFollowOutput(false)).toBe("auto")

		const scrollable = getScrollable()
		const nestedScrollable = document.createElement("div")
		nestedScrollable.style.overflowY = "auto"
		nestedScrollable.scrollTop = 0
		scrollable.appendChild(nestedScrollable)

		scrollable.scrollTop = 240

		await act(async () => {
			fireEvent.pointerDown(nestedScrollable)
			nestedScrollable.scrollTop = 120
			fireEvent.scroll(nestedScrollable)
			fireEvent.pointerUp(window)
		})

		expect(resolveFollowOutput(false)).toBe("auto")
		expect(document.querySelector(".codicon-chevron-down")).toBeNull()
	})

	it("wheel-up intent disengages sticky follow", async () => {
		await hydrate(2)
		await waitForCalls(2)
		await waitForCallsSettled()
		expect(resolveFollowOutput(false)).toBe("auto")

		const scrollable = getScrollable()

		await act(async () => {
			fireEvent.wheel(scrollable, { deltaY: -120 })
		})

		expect(resolveFollowOutput(false)).toBe(false)
		await waitFor(() => expect(document.querySelector(".codicon-chevron-down")).toBeTruthy(), {
			timeout: 1_200,
		})
	})

	it("hydration completion cannot override user escape hatch", async () => {
		await hydrate(Number.POSITIVE_INFINITY)
		await waitForCalls(1, 1_200)

		await act(async () => {
			fireEvent.keyDown(window, { key: "PageUp" })
		})

		expect(resolveFollowOutput(false)).toBe(false)

		await sleep(700)

		expect(resolveFollowOutput(false)).toBe(false)
		await waitFor(() => expect(document.querySelector(".codicon-chevron-down")).toBeTruthy(), {
			timeout: 1_200,
		})
	})

	it.skip("scroll-to-bottom CTA re-anchors with one interaction", async () => {
		await hydrate(2)
		await waitForCalls(2)
		await waitForCallsSettled()
		expect(resolveFollowOutput(false)).toBe("auto")

		await act(async () => {
			fireEvent.keyDown(window, { key: "PageUp" })
		})

		expect(resolveFollowOutput(false)).toBe(false)
		await waitFor(() => expect(document.querySelector(".codicon-chevron-down")).toBeTruthy(), {
			timeout: 1_200,
		})

		const callsBeforeClick = harness.scrollCalls
		harness.atBottomAfterCalls = callsBeforeClick + 2

		await act(async () => {
			getScrollToBottomButton().click()
		})

		expect(resolveFollowOutput(false)).toBe("auto")
		await waitFor(() => expect(harness.scrollCalls).toBe(callsBeforeClick + 2), {
			timeout: 1_200,
		})
		await waitFor(() => expect(document.querySelector(".codicon-chevron-down")).toBeNull(), { timeout: 1_200 })
	})
})
