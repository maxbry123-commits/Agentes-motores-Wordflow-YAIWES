import React, { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle } from "react"
import {
	VSCodeCheckbox,
	VSCodeRadioGroup,
	VSCodeRadio,
	VSCodeLink,
	VSCodeTextField,
} from "@vscode/webview-ui-toolkit/react"
import { Trans } from "react-i18next"
import { ChevronDown, X, Upload, Download } from "lucide-react"

import { ModeConfig, GroupEntry, PromptComponent, ToolGroup, modeConfigSchema } from "@shofer/types"

import {
	getRoleDefinition,
	getWhenToUse,
	getDescription,
	getCustomInstructions,
	getAllModes,
	findAuthoredMode,
	defaultModeSlug,
} from "@shofer/types"
import { TOOL_GROUPS } from "@shofer/types"

import { vscode } from "@src/utils/vscode"
import { buildDocLink } from "@src/utils/docLinks"
import { useAppTranslation } from "@src/i18n/TranslationContext"
import { useExtensionState } from "@src/context/ExtensionStateContext"
import { Section } from "@src/components/settings/Section"
import {
	Button,
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
	Popover,
	PopoverContent,
	PopoverTrigger,
	Command,
	CommandInput,
	CommandList,
	CommandEmpty,
	CommandItem,
	CommandGroup,
	Input,
	StandardTooltip,
} from "@src/components/ui"
import { DeleteModeDialog } from "@src/components/modes/DeleteModeDialog"
import { useEscapeKey } from "@src/hooks/useEscapeKey"

// Get all available groups that should show in prompts view
const availableGroups = Object.keys(TOOL_GROUPS) as ToolGroup[]

type ModeSource = "global" | "project"

type ImportModeResult = { type: "importModeResult"; success: boolean; slug?: string; error?: string }

// Helper to get group name regardless of format
function getGroupName(group: GroupEntry): ToolGroup {
	return (Array.isArray(group) ? group[0] : group) as ToolGroup
}

/**
 * The four per-mode text fields that the user can edit in the Modes settings tab.
 * Held as overrides until the user clicks Save in `SettingsView`.
 */
type ModeTextOverride = {
	roleDefinition?: string
	description?: string
	whenToUse?: string
	customInstructions?: string
}

/**
 * Imperative handle exposed to `SettingsView` so the Save / Discard flow can commit
 * or drop the pending text-edit buffers held inside `ModesView`.
 *
 * `commitBuffers()` posts the appropriate `updateCustomMode` / `updatePrompt` /
 * `customInstructions` messages and clears all overrides. `discardBuffers()`
 * drops all overrides without persisting.
 */
export type ModesViewRef = {
	commitBuffers: () => void
	discardBuffers: () => void
}

type ModesViewProps = {
	/**
	 * Fired the first moment any text buffer diverges from its source-of-truth.
	 * `SettingsView` wires this to `setChangeDetected(true)` so the Save button
	 * enables. The "back to clean" transition is driven explicitly by `commitBuffers`
	 * / `discardBuffers` (called from `handleSubmit` / discard-dialog), so we do
	 * not need a "dirty → clean" callback.
	 */
	onModesDirty?: () => void
}

const ModesView = forwardRef<ModesViewRef, ModesViewProps>(({ onModesDirty }, ref) => {
	const { t } = useAppTranslation()

	const {
		customModePrompts,
		listApiConfigMeta,
		modeApiConfigs,
		currentApiConfigName,
		mode,
		customInstructions,
		customModes,
		orgLockedResources,
	} = useExtensionState()

	// Whether a mode is org-locked (final by the org scope's locked.json): its
	// definition is read-only here — the host refuses mutations, so disable the
	// affordances up front instead of letting an edit fail on Save.
	const isModeOrgLocked = useCallback(
		(slug: string) => (orgLockedResources?.modes ?? []).includes(slug),
		[orgLockedResources],
	)

	// Staged per-mode API-config associations (mode slug → config id), edited via
	// the "API Configuration" dropdown. Save-gated: committed on Save via
	// `commitBuffers` (→ `setModeApiConfig`), dropped on Discard. This is the
	// PER-MODE association — the global default lives in Settings → Providers.
	const [pendingModeApiConfig, setPendingModeApiConfig] = useState<Record<string, string>>({})

	// Staged per-mode tool-group edits (custom-mode slug → GroupEntry[]), edited
	// via the "Tools" checkboxes. Save-gated: committed on Save via
	// `commitBuffers` (→ `updateCustomMode`), dropped on Discard.
	const [pendingModeGroups, setPendingModeGroups] = useState<Record<string, GroupEntry[]>>({})

	// The mode currently being EDITED in this tab. Purely local selection: per
	// the save-gating rule, nothing in Settings takes effect before Save, so
	// picking a mode here must NOT switch the globally-active mode (that is the
	// chat mode selector's job).
	const [visualMode, setVisualMode] = useState(mode)

	// Whether the user has deliberately chosen which mode to edit. Until then the
	// tab tracks the active mode (so opening Settings edits what you're using);
	// once set, the selection is PINNED — an active-mode change from chat or the
	// agent (`switch_mode`) must not yank the user onto a different mode's form
	// mid-edit. Reset on unmount only (the state re-seeds on the next open).
	const editTargetPinned = useRef(false)

	// Per-mode overrides for the four editable text fields. Keyed by mode slug.
	// Reads merge `modeOverrides[slug]` over the live extension-state chain, so
	// edits are isolated from periodic `ContextProxy` state pushes (which would
	// otherwise reset the textbox value mid-typing — see AGENTS.md
	// "Settings View Pattern").
	const [modeOverrides, setModeOverrides] = useState<Record<string, ModeTextOverride>>({})
	// Override for the global "Custom Instructions for All Modes" field. `undefined`
	// means "no edit; show live value".
	const [globalCIOverride, setGlobalCIOverride] = useState<string | undefined>(undefined)

	// "Is this an editable mode?" — everything below gates rename/delete/export and the
	// custom-vs-built-in branches on it. The list carries plugin-contributed modes too
	// (Shofer's own six come from the `builtin-config` plugin), and those are NOT
	// editable here: a plugin owns its modes, and overriding one means authoring a mode
	// of the same slug. Hoisted above the useCallbacks that reference it.
	const findModeBySlug = useCallback(
		(searchSlug: string, modes: readonly ModeConfig[] | undefined): ModeConfig | undefined => {
			return findAuthoredMode(searchSlug, modes)
		},
		[],
	)

	const markDirty = useCallback(() => {
		onModesDirty?.()
	}, [onModesDirty])

	// Merge an override field for `slug` and notify the parent that buffers are dirty.
	const setModeOverrideField = useCallback(
		<K extends keyof ModeTextOverride>(slug: string, field: K, value: ModeTextOverride[K]) => {
			setModeOverrides((prev) => {
				const next: Record<string, ModeTextOverride> = { ...prev }
				next[slug] = { ...(prev[slug] ?? {}), [field]: value }
				return next
			})
			markDirty()
		},
		[markDirty],
	)

	// Clear an override field (used by the "reset to default" buttons so the textbox
	// snaps back to the live/default value).
	const clearModeOverrideField = useCallback((slug: string, field: keyof ModeTextOverride) => {
		setModeOverrides((prev) => {
			if (!prev[slug] || prev[slug][field] === undefined) return prev
			const nextEntry: ModeTextOverride = { ...prev[slug] }
			delete nextEntry[field]
			const next: Record<string, ModeTextOverride> = { ...prev }
			if (Object.keys(nextEntry).length === 0) {
				delete next[slug]
			} else {
				next[slug] = nextEntry
			}
			return next
		})
	}, [])

	const getEffectiveRoleDefinition = useCallback(() => {
		const override = modeOverrides[visualMode]?.roleDefinition
		if (override !== undefined) return override
		const customMode = findModeBySlug(visualMode, customModes)
		const prompt = customModePrompts?.[visualMode] as PromptComponent
		return customMode?.roleDefinition ?? prompt?.roleDefinition ?? getRoleDefinition(visualMode) ?? ""
	}, [modeOverrides, visualMode, customModes, customModePrompts, findModeBySlug])

	const getEffectiveDescription = useCallback(() => {
		const override = modeOverrides[visualMode]?.description
		if (override !== undefined) return override
		const customMode = findModeBySlug(visualMode, customModes)
		const prompt = customModePrompts?.[visualMode] as PromptComponent
		return customMode?.description ?? prompt?.description ?? getDescription(visualMode) ?? ""
	}, [modeOverrides, visualMode, customModes, customModePrompts, findModeBySlug])

	const getEffectiveWhenToUse = useCallback(() => {
		const override = modeOverrides[visualMode]?.whenToUse
		if (override !== undefined) return override
		const customMode = findModeBySlug(visualMode, customModes)
		const prompt = customModePrompts?.[visualMode] as PromptComponent
		return customMode?.whenToUse ?? prompt?.whenToUse ?? getWhenToUse(visualMode) ?? ""
	}, [modeOverrides, visualMode, customModes, customModePrompts, findModeBySlug])

	const getEffectiveModeCustomInstructions = useCallback(() => {
		const override = modeOverrides[visualMode]?.customInstructions
		if (override !== undefined) return override
		const customMode = findModeBySlug(visualMode, customModes)
		const prompt = customModePrompts?.[visualMode] as PromptComponent
		return (
			customMode?.customInstructions ??
			prompt?.customInstructions ??
			getCustomInstructions(visualMode, customModes) ??
			""
		)
	}, [modeOverrides, visualMode, customModes, customModePrompts, findModeBySlug])

	const getEffectiveGlobalCustomInstructions = useCallback(() => {
		return globalCIOverride ?? customInstructions ?? ""
	}, [globalCIOverride, customInstructions])

	// Keep refs to the latest customModes / customModePrompts so the imperative
	// `commitBuffers` handle (registered once via `useImperativeHandle`) always
	// merges overrides over the freshest live state, without depending on every
	// state push to re-register the handle.
	const customModesRefForCommit = useRef(customModes)
	const customModePromptsRefForCommit = useRef(customModePrompts)
	useEffect(() => {
		customModesRefForCommit.current = customModes
	}, [customModes])
	useEffect(() => {
		customModePromptsRefForCommit.current = customModePrompts
	}, [customModePrompts])
	const modeOverridesRef = useRef(modeOverrides)
	const globalCIOverrideRef = useRef(globalCIOverride)
	const pendingModeApiConfigRef = useRef(pendingModeApiConfig)
	const pendingModeGroupsRef = useRef(pendingModeGroups)
	useEffect(() => {
		modeOverridesRef.current = modeOverrides
	}, [modeOverrides])
	useEffect(() => {
		globalCIOverrideRef.current = globalCIOverride
	}, [globalCIOverride])
	useEffect(() => {
		pendingModeApiConfigRef.current = pendingModeApiConfig
	}, [pendingModeApiConfig])
	useEffect(() => {
		pendingModeGroupsRef.current = pendingModeGroups
	}, [pendingModeGroups])

	useImperativeHandle(
		ref,
		(): ModesViewRef => ({
			commitBuffers: () => {
				const overrides = modeOverridesRef.current
				const liveModes = customModesRefForCommit.current
				const livePrompts = customModePromptsRefForCommit.current
				for (const [slug, fields] of Object.entries(overrides)) {
					const customMode = findAuthoredMode(slug, liveModes)
					if (customMode) {
						// Custom mode: persist the merged ModeConfig.
						const merged: ModeConfig = {
							...customMode,
							source: customMode.source || "global",
						}
						if (fields.roleDefinition !== undefined) {
							merged.roleDefinition = fields.roleDefinition.trim() || ""
						}
						if (fields.description !== undefined) {
							merged.description = fields.description.trim() || undefined
						}
						if (fields.whenToUse !== undefined) {
							merged.whenToUse = fields.whenToUse.trim() || undefined
						}
						if (fields.customInstructions !== undefined) {
							merged.customInstructions = fields.customInstructions || undefined
						}
						// Fold staged tool-group edits into the same post so the
						// second loop below doesn't clobber this one's text fields.
						const stagedGroups = pendingModeGroupsRef.current[slug]
						if (stagedGroups !== undefined) {
							merged.tools = stagedGroups
						}
						vscode.postMessage({ type: "updateCustomMode", slug, modeConfig: merged })
					} else {
						// Built-in mode: persist as a `customModePrompts` override.
						const existing = (livePrompts?.[slug] as PromptComponent) ?? {}
						const merged: PromptComponent = { ...existing }
						if (fields.roleDefinition !== undefined) {
							const trimmed = fields.roleDefinition.trim()
							merged.roleDefinition =
								trimmed === getRoleDefinition(slug) ? undefined : trimmed || undefined
						}
						if (fields.description !== undefined) {
							const trimmed = fields.description.trim()
							merged.description = trimmed === getDescription(slug) ? undefined : trimmed || undefined
						}
						if (fields.whenToUse !== undefined) {
							const trimmed = fields.whenToUse.trim()
							merged.whenToUse = trimmed === getWhenToUse(slug) ? undefined : trimmed || undefined
						}
						if (fields.customInstructions !== undefined) {
							merged.customInstructions = fields.customInstructions.trim() || undefined
						}
						vscode.postMessage({ type: "updatePrompt", promptMode: slug, customPrompt: merged })
					}
				}
				const gci = globalCIOverrideRef.current
				if (gci !== undefined) {
					vscode.postMessage({ type: "customInstructions", text: gci })
				}
				// Staged tool-group edits for slugs NOT already persisted by the
				// overrides loop above (which folds them into its own post).
				for (const [slug, tools] of Object.entries(pendingModeGroupsRef.current)) {
					const customMode = findAuthoredMode(slug, liveModes)
					if (!customMode || overrides[slug]) continue
					vscode.postMessage({
						type: "updateCustomMode",
						slug,
						modeConfig: { ...customMode, tools, source: customMode.source || "global" },
					})
				}
				// Per-mode API-config associations (PER MODE; not the global default).
				for (const [slug, configId] of Object.entries(pendingModeApiConfigRef.current)) {
					vscode.postMessage({ type: "setModeApiConfig", mode: slug, text: configId })
				}
				setModeOverrides({})
				setGlobalCIOverride(undefined)
				setPendingModeApiConfig({})
				setPendingModeGroups({})
			},
			discardBuffers: () => {
				setModeOverrides({})
				setGlobalCIOverride(undefined)
				setPendingModeApiConfig({})
				setPendingModeGroups({})
			},
		}),
		[],
	)

	// Build modes fresh each render so search reflects inline rename updates immediately
	const modes = getAllModes(customModes)

	const [isDialogOpen, setIsDialogOpen] = useState(false)
	const [selectedPromptContent, setSelectedPromptContent] = useState("")
	const [selectedPromptTitle, setSelectedPromptTitle] = useState("")
	const [isToolsEditMode, setIsToolsEditMode] = useState(false)
	const [showConfigMenu, setShowConfigMenu] = useState(false)
	const [isCreateModeDialogOpen, setIsCreateModeDialogOpen] = useState(false)
	const [isExporting, setIsExporting] = useState(false)
	const [isImporting, setIsImporting] = useState(false)
	const [showImportDialog, setShowImportDialog] = useState(false)
	const [importLevel, setImportLevel] = useState<"global" | "project">("project")
	const [hasRulesToExport, setHasRulesToExport] = useState<Record<string, boolean>>({})
	const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
	const [modeToDelete, setModeToDelete] = useState<{
		slug: string
		name: string
		source?: string
		rulesFolderPath?: string
	} | null>(null)

	// State for mode selection popover and search
	const [open, setOpen] = useState(false)
	const [searchValue, setSearchValue] = useState("")
	const searchInputRef = useRef<HTMLInputElement>(null)

	// removed unused local name state (replaced by inline rename UX)

	// Inline rename state for the mode dropdown row
	const [isRenamingMode, setIsRenamingMode] = useState(false)
	const [renameInputValue, setRenameInputValue] = useState("")
	const renameInputRef = useRef<any>(null)

	// Optimistic rename map so search reflects new names immediately
	const [localRenames, setLocalRenames] = useState<Record<string, string>>({})
	// Display list that overlays optimistic names
	const displayModes = (modes || []).map((m) => (localRenames[m.slug] ? { ...m, name: localRenames[m.slug] } : m))

	// Direct update functions
	const updateCustomMode = useCallback((slug: string, modeConfig: ModeConfig) => {
		const source = modeConfig.source || "global"

		vscode.postMessage({
			type: "updateCustomMode",
			slug,
			modeConfig: {
				...modeConfig,
				source, // Ensure source is set
			},
		})
	}, [])

	// Select which mode this tab edits. Local-only: does NOT post a "mode"
	// message — switching the active mode from Settings would be a settings
	// change taking effect without Save.
	const handleModeSwitch = useCallback(
		(modeConfig: ModeConfig) => {
			// Pin even on a no-op re-pick: choosing the mode you're already on is
			// still a deliberate "edit this one".
			editTargetPinned.current = true

			if (modeConfig.slug === visualMode) return // Prevent unnecessary updates

			setVisualMode(modeConfig.slug)

			// Exit tools edit mode when switching modes
			setIsToolsEditMode(false)
		},
		[visualMode],
	)

	// Refs to track latest state/functions for message handler (which has no dependencies)
	const handleModeSwitchRef = useRef(handleModeSwitch)
	const customModesRef = useRef(customModes)

	// Update refs when dependencies change
	useEffect(() => {
		handleModeSwitchRef.current = handleModeSwitch
	}, [handleModeSwitch])

	useEffect(() => {
		customModesRef.current = customModes
	}, [customModes])

	// Track the active mode until the user picks an edit target of their own.
	// After that the selection is pinned (see `editTargetPinned`).
	useEffect(() => {
		if (editTargetPinned.current) return
		setVisualMode(mode)
	}, [mode])

	// Handler for popover open state change
	const onOpenChange = useCallback((open: boolean) => {
		setOpen(open)
		// Reset search when closing the popover
		if (!open) {
			setTimeout(() => setSearchValue(""), 100)
		}
	}, [])

	// Use the shared ESC key handler hook
	useEscapeKey(open, () => setOpen(false))

	// Handler for clearing search input
	const onClearSearch = useCallback(() => {
		setSearchValue("")
		searchInputRef.current?.focus()
	}, [])

	// Focus rename input when entering rename mode
	useEffect(() => {
		if (isRenamingMode) {
			const id = setTimeout(() => renameInputRef.current?.focus(), 0)
			return () => clearTimeout(id)
		}
	}, [isRenamingMode])

	const handleStartRenameMode = useCallback(() => {
		const customMode = findModeBySlug(visualMode, customModes)
		if (customMode) {
			setIsRenamingMode(true)
			setRenameInputValue(customMode.name)
		}
	}, [visualMode, customModes, findModeBySlug])

	const handleCancelRenameMode = useCallback(() => {
		setIsRenamingMode(false)
		setRenameInputValue("")
	}, [])

	const handleSaveRenameMode = useCallback(() => {
		const customMode = findModeBySlug(visualMode, customModes)
		const trimmed = renameInputValue.trim()
		if (!customMode || !trimmed) {
			setIsRenamingMode(false)
			return
		}
		// Prevent duplicate names against other modes
		const nameTaken = modes.some(
			(m) => m.name.toLowerCase() === trimmed.toLowerCase() && m.slug !== customMode.slug,
		)
		if (nameTaken) {
			// simple guard: do nothing if taken
			return
		}
		updateCustomMode(visualMode, {
			...customMode,
			name: trimmed,
			source: customMode.source || "global",
		})
		// Optimistically reflect rename in UI/search immediately
		setLocalRenames((prev) => ({ ...prev, [visualMode]: trimmed }))
		setIsRenamingMode(false)
	}, [visualMode, customModes, renameInputValue, modes, updateCustomMode, findModeBySlug])

	// Helper function to get current mode's config
	const getCurrentMode = useCallback((): ModeConfig | undefined => {
		const findMode = (m: ModeConfig): boolean => m.slug === visualMode
		return customModes?.find(findMode) || modes.find(findMode)
	}, [visualMode, customModes, modes])

	// Check if the current mode has rules to export
	const checkRulesDirectory = useCallback((slug: string) => {
		vscode.postMessage({
			type: "checkRulesDirectory",
			slug: slug,
		})
	}, [])

	// Check rules directory when mode changes
	useEffect(() => {
		const currentMode = getCurrentMode()
		if (currentMode?.slug && hasRulesToExport[currentMode.slug] === undefined) {
			checkRulesDirectory(currentMode.slug)
		}
	}, [getCurrentMode, checkRulesDirectory, hasRulesToExport])

	// State for create mode dialog
	const [newModeName, setNewModeName] = useState("")
	const [newModeSlug, setNewModeSlug] = useState("")
	const [newModeDescription, setNewModeDescription] = useState("")
	const [newModeRoleDefinition, setNewModeRoleDefinition] = useState("")
	const [newModeWhenToUse, setNewModeWhenToUse] = useState("")
	const [newModeCustomInstructions, setNewModeCustomInstructions] = useState("")
	const [newModeGroups, setNewModeGroups] = useState<GroupEntry[]>(availableGroups)
	const [newModeSource, setNewModeSource] = useState<ModeSource>("global")

	// Field-specific error states
	const [nameError, setNameError] = useState<string>("")
	const [slugError, setSlugError] = useState<string>("")
	const [descriptionError, setDescriptionError] = useState<string>("")
	const [roleDefinitionError, setRoleDefinitionError] = useState<string>("")
	const [groupsError, setGroupsError] = useState<string>("")

	// Helper to reset form state
	const resetFormState = useCallback(() => {
		// Reset form fields
		setNewModeName("")
		setNewModeSlug("")
		setNewModeDescription("")
		setNewModeGroups(availableGroups)
		setNewModeRoleDefinition("")
		setNewModeWhenToUse("")
		setNewModeCustomInstructions("")
		setNewModeSource("global")
		// Reset error states
		setNameError("")
		setSlugError("")
		setDescriptionError("")
		setRoleDefinitionError("")
		setGroupsError("")
	}, [])

	// Reset form fields when dialog opens
	useEffect(() => {
		if (isCreateModeDialogOpen) {
			resetFormState()
		}
	}, [isCreateModeDialogOpen, resetFormState])

	// Ensure import dialog defaults to "project" each open
	useEffect(() => {
		if (showImportDialog) {
			setImportLevel("project")
		}
	}, [showImportDialog])

	// Helper function to generate a unique slug from a name
	const generateSlug = useCallback((name: string, attempt = 0): string => {
		const baseSlug = name
			.toLowerCase()
			.replace(/[^a-z0-9-]+/g, "-")
			.replace(/^-+|-+$/g, "")
		return attempt === 0 ? baseSlug : `${baseSlug}-${attempt}`
	}, [])

	// Handler for name changes
	const handleNameChange = useCallback(
		(name: string) => {
			setNewModeName(name)
			setNewModeSlug(generateSlug(name))
		},
		[generateSlug],
	)

	const handleCreateMode = useCallback(() => {
		// Clear previous errors
		setNameError("")
		setSlugError("")
		setDescriptionError("")
		setRoleDefinitionError("")
		setGroupsError("")

		const source = newModeSource
		const newMode: ModeConfig = {
			slug: newModeSlug,
			name: newModeName,
			description: newModeDescription.trim() || undefined,
			roleDefinition: newModeRoleDefinition.trim(),
			whenToUse: newModeWhenToUse.trim() || undefined,
			customInstructions: newModeCustomInstructions.trim() || undefined,
			tools: newModeGroups,
			source,
		}

		// Validate the mode against the schema
		const result = modeConfigSchema.safeParse(newMode)

		if (!result.success) {
			// Map Zod errors to specific fields
			result.error.errors.forEach((error) => {
				const field = error.path[0] as string
				const message = error.message

				switch (field) {
					case "name":
						setNameError(message)
						break
					case "slug":
						setSlugError(message)
						break
					case "description":
						setDescriptionError(message)
						break
					case "roleDefinition":
						setRoleDefinitionError(message)
						break
					case "tools":
						setGroupsError(message)
						break
				}
			})
			return
		}

		updateCustomMode(newModeSlug, newMode)
		// Immediately select the newly created mode for editing (local only —
		// creating a mode must not switch the globally-active mode), and pin it
		// so an active-mode change elsewhere can't navigate away from it.
		editTargetPinned.current = true
		setVisualMode(newModeSlug)
		setIsCreateModeDialogOpen(false)
		resetFormState()
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [
		newModeName,
		newModeSlug,
		newModeDescription,
		newModeRoleDefinition,
		newModeWhenToUse, // Add whenToUse dependency
		newModeCustomInstructions,
		newModeGroups,
		newModeSource,
		updateCustomMode,
	])

	const isNameOrSlugTaken = useCallback(
		(name: string, slug: string) => {
			return modes.some((m) => m.slug === slug || m.name === name)
		},
		[modes],
	)

	const openCreateModeDialog = useCallback(() => {
		const baseNamePrefix = "New Custom Mode"
		// Find unique name and slug
		let attempt = 0
		let name = baseNamePrefix
		let slug = generateSlug(name)
		while (isNameOrSlugTaken(name, slug)) {
			attempt++
			name = `${baseNamePrefix} ${attempt + 1}`
			slug = generateSlug(name)
		}
		setNewModeName(name)
		setNewModeSlug(slug)
		setIsCreateModeDialogOpen(true)
	}, [generateSlug, isNameOrSlugTaken])

	// Handler for group checkbox changes. Save-gated: stages the new group list
	// into `pendingModeGroups` (committed on Save via `commitBuffers`) instead of
	// posting `updateCustomMode` immediately.
	const handleGroupChange = useCallback(
		(group: ToolGroup, isCustomMode: boolean, customMode: ModeConfig | undefined) =>
			(e: Event | React.FormEvent<HTMLElement>) => {
				if (!isCustomMode || !customMode) return // Prevent changes to built-in modes
				const target = (e as CustomEvent)?.detail?.target || (e.target as HTMLInputElement)
				const checked = target.checked
				// Staged-first so consecutive toggles compound instead of each
				// starting over from the live (unsaved) group list.
				const oldGroups = pendingModeGroups[customMode.slug] ?? customMode.tools ?? []
				let newGroups: GroupEntry[]
				if (checked) {
					newGroups = [...oldGroups, group]
				} else {
					newGroups = oldGroups.filter((g) => getGroupName(g) !== group)
				}
				setPendingModeGroups((prev) => ({ ...prev, [customMode.slug]: newGroups }))
				onModesDirty?.()
			},
		[pendingModeGroups, onModesDirty],
	)

	// Handle clicks outside the config menu
	useEffect(() => {
		const handleClickOutside = () => {
			if (showConfigMenu) {
				setShowConfigMenu(false)
			}
		}

		document.addEventListener("click", handleClickOutside)
		return () => document.removeEventListener("click", handleClickOutside)
	}, [showConfigMenu])

	// Use a ref to store the current modeToDelete value
	const modeToDeleteRef = useRef(modeToDelete)

	// Update the ref whenever modeToDelete changes
	useEffect(() => {
		modeToDeleteRef.current = modeToDelete
	}, [modeToDelete])

	useEffect(() => {
		const handler = (event: MessageEvent) => {
			const message = event.data
			if (message.type === "systemPrompt") {
				if (message.text) {
					setSelectedPromptContent(message.text)
					setSelectedPromptTitle(`System Prompt (${message.mode} mode)`)
					setIsDialogOpen(true)
				}
			} else if (message.type === "exportModeResult") {
				setIsExporting(false)

				if (!message.success) {
					// Show error message
					console.error("Failed to export mode:", message.error)
				}
			} else if (message.type === "importModeResult") {
				setIsImporting(false)
				setShowImportDialog(false)

				if (message.success) {
					const { slug } = message as ImportModeResult
					if (slug) {
						// Try switching using the freshest mode list available
						const all = getAllModes(customModesRef.current)
						const importedMode = all.find((m) => m.slug === slug)
						if (importedMode) {
							handleModeSwitchRef.current(importedMode)
						} else {
							// Fallback: slug not yet in state (race condition) - select default mode
							editTargetPinned.current = true
							setVisualMode(defaultModeSlug)
						}
					}
				} else {
					// Only log error if it's not a cancellation
					if (message.error !== "cancelled") {
						console.error("Failed to import mode:", message.error)
					}
				}
				// Note: Auto-select after import will be handled by PR #9003
			} else if (message.type === "checkRulesDirectoryResult") {
				setHasRulesToExport((prev) => ({
					...prev,
					[message.slug]: message.hasContent,
				}))
			} else if (message.type === "deleteCustomModeCheck") {
				// Handle the check response
				// Use the ref to get the current modeToDelete value
				const currentModeToDelete = modeToDeleteRef.current
				if (message.slug && currentModeToDelete && currentModeToDelete.slug === message.slug) {
					setModeToDelete({
						...currentModeToDelete,
						rulesFolderPath: message.rulesFolderPath,
					})
					setShowDeleteConfirm(true)
				}
			}
		}

		window.addEventListener("message", handler)
		return () => window.removeEventListener("message", handler)
	}, [checkRulesDirectory])

	const handleAgentReset = (
		modeSlug: string,
		type: "roleDefinition" | "description" | "whenToUse" | "customInstructions",
	) => {
		// Reset is an explicit, instant action: drop any pending edit for this field
		// and tell the host to remove the override so the default reloads on next render.
		clearModeOverrideField(modeSlug, type)

		const existingPrompt = customModePrompts?.[modeSlug] as PromptComponent
		const updatedPrompt = { ...existingPrompt }
		delete updatedPrompt[type]

		vscode.postMessage({
			type: "updatePrompt",
			promptMode: modeSlug,
			customPrompt: updatedPrompt,
		})
	}

	return (
		<div>
			<Section>
				<div>
					<div onClick={(e) => e.stopPropagation()} className="flex justify-between items-center mb-3">
						<h3 className="text-[1.25em] font-semibold text-vscode-foreground mt-4 mb-2">
							{t("prompts:modes.title")}
						</h3>
						<div className="flex gap-2">
							<div className="relative inline-block">
								<StandardTooltip content={t("prompts:modes.editModesConfig")}>
									<Button
										variant="ghost"
										size="icon"
										className="flex"
										onClick={(e: React.MouseEvent) => {
											e.preventDefault()
											e.stopPropagation()
											setShowConfigMenu((prev) => !prev)
										}}
										onBlur={() => {
											// Add slight delay to allow menu item clicks to register
											setTimeout(() => setShowConfigMenu(false), 200)
										}}>
										<span className="codicon codicon-json"></span>
									</Button>
								</StandardTooltip>
								{showConfigMenu && (
									<div
										onClick={(e) => e.stopPropagation()}
										onMouseDown={(e) => e.stopPropagation()}
										className="absolute top-full right-0 w-[200px] mt-1 bg-vscode-editor-background border border-vscode-input-border rounded shadow-md z-[1000]">
										<div
											className="p-2 cursor-pointer text-vscode-foreground text-sm"
											onMouseDown={(e) => {
												e.preventDefault() // Prevent blur
												vscode.postMessage({
													type: "openCustomModesSettings",
												})
												setShowConfigMenu(false)
											}}
											onClick={(e) => e.preventDefault()}>
											{t("prompts:modes.editGlobalModes")}
										</div>
										<div
											className="p-2 cursor-pointer text-vscode-foreground text-sm border-t border-vscode-input-border"
											onMouseDown={(e) => {
												e.preventDefault() // Prevent blur
												vscode.postMessage({
													type: "openFile",
													text: "./.shofermodes",
													values: {
														create: true,
														content: JSON.stringify({ customModes: [] }, null, 2),
													},
												})
												setShowConfigMenu(false)
											}}
											onClick={(e) => e.preventDefault()}>
											{t("prompts:modes.editProjectModes")}
										</div>
									</div>
								)}
							</div>

							<StandardTooltip content={t("prompts:modes.importMode")}>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => setShowImportDialog(true)}
									disabled={isImporting}
									title={t("prompts:modes.importMode")}
									data-testid="import-mode-toolbar-button">
									<Download className="h-4 w-4" />
								</Button>
							</StandardTooltip>
						</div>
					</div>

					<div className="text-sm text-vscode-descriptionForeground mb-3">
						<Trans i18nKey="prompts:modes.createModeHelpText">
							<VSCodeLink
								href={buildDocLink("basic-usage/using-modes", "prompts_view_modes")}
								style={{ display: "inline" }}
								aria-label="Learn about using modes"></VSCodeLink>
							<VSCodeLink
								href={buildDocLink("features/custom-modes", "prompts_view_modes")}
								style={{ display: "inline" }}
								aria-label="Learn about customizing modes"></VSCodeLink>
						</Trans>
					</div>

					<div className="flex items-center gap-1 mb-3">
						{isRenamingMode ? (
							<>
								<VSCodeTextField
									ref={renameInputRef}
									value={renameInputValue}
									onInput={(e: unknown) => {
										const target = e as { target: { value: string } }
										setRenameInputValue(target.target.value)
									}}
									className="grow"
									placeholder={t("prompts:createModeDialog.name.placeholder")}
								/>
								<StandardTooltip content={t("settings:common.save")}>
									<Button
										variant="ghost"
										size="icon"
										disabled={!renameInputValue.trim()}
										onClick={handleSaveRenameMode}
										data-testid="save-mode-rename-button">
										<span className="codicon codicon-check" />
									</Button>
								</StandardTooltip>
								<StandardTooltip content={t("settings:common.cancel")}>
									<Button
										variant="ghost"
										size="icon"
										onClick={handleCancelRenameMode}
										data-testid="cancel-mode-rename-button">
										<span className="codicon codicon-close" />
									</Button>
								</StandardTooltip>
							</>
						) : (
							<>
								<Popover open={open} onOpenChange={onOpenChange}>
									<PopoverTrigger asChild>
										<Button
											variant="combobox"
											role="combobox"
											aria-expanded={open}
											className="justify-between grow"
											data-testid="mode-select-trigger">
											<div className="truncate">
												{localRenames[visualMode] ??
													getCurrentMode()?.name ??
													t("prompts:modes.selectMode")}
											</div>
											<ChevronDown className="opacity-50" />
										</Button>
									</PopoverTrigger>
									<PopoverContent className="p-0 w-[var(--radix-popover-trigger-width)]">
										<Command>
											<div className="relative">
												<CommandInput
													ref={searchInputRef}
													value={searchValue}
													onValueChange={setSearchValue}
													placeholder={t("prompts:modes.selectMode")}
													className="h-9 mr-4"
													data-testid="mode-search-input"
												/>
												{searchValue.length > 0 && (
													<div className="absolute right-2 top-0 bottom-0 flex items-center justify-center">
														<X
															className="text-vscode-input-foreground opacity-50 hover:opacity-100 size-4 p-0.5 cursor-pointer"
															onClick={onClearSearch}
														/>
													</div>
												)}
											</div>
											<CommandList>
												<CommandEmpty>
													{searchValue && (
														<div className="py-2 px-1 text-sm">
															{t("prompts:modes.noMatchFound")}
														</div>
													)}
												</CommandEmpty>
												<CommandGroup>
													{displayModes
														.filter((modeConfig) =>
															searchValue
																? modeConfig.name
																		.toLowerCase()
																		.includes(searchValue.toLowerCase())
																: true,
														)
														.map((modeConfig) => (
															<CommandItem
																key={modeConfig.slug}
																value={`${modeConfig.name} ${modeConfig.slug}`}
																onSelect={() => {
																	handleModeSwitch(modeConfig)
																	setOpen(false)
																}}
																data-testid={`mode-option-${modeConfig.slug}`}>
																<div className="flex items-center justify-between w-full">
																	<span
																		style={{
																			whiteSpace: "nowrap",
																			overflow: "hidden",
																			textOverflow: "ellipsis",
																			flex: 2,
																			minWidth: 0,
																		}}>
																		{modeConfig.name}
																	</span>
																	<span
																		className="text-foreground"
																		style={{
																			whiteSpace: "nowrap",
																			overflow: "hidden",
																			textOverflow: "ellipsis",
																			direction: "rtl",
																			textAlign: "right",
																			flex: 1,
																			minWidth: 0,
																			marginLeft: "0.5em",
																		}}>
																		{modeConfig.slug}
																	</span>
																</div>
															</CommandItem>
														))}
												</CommandGroup>
											</CommandList>
										</Command>
									</PopoverContent>
								</Popover>

								{/* New mode (+) moved here from the top bar */}
								<StandardTooltip content={t("prompts:modes.createNewMode")}>
									<Button
										variant="ghost"
										size="icon"
										onClick={openCreateModeDialog}
										data-testid="add-mode-button">
										<span className="codicon codicon-add" />
									</Button>
								</StandardTooltip>

								{/* Edit (rename) mode - only enabled for custom, non-org-locked modes */}
								<StandardTooltip content={t("settings:providers.renameProfile")}>
									<Button
										variant="ghost"
										size="icon"
										onClick={handleStartRenameMode}
										data-testid="rename-mode-button"
										disabled={
											!findModeBySlug(visualMode, customModes) || isModeOrgLocked(visualMode)
										}>
										<span className="codicon codicon-edit" />
									</Button>
								</StandardTooltip>

								{/* Delete mode - disabled for built-in modes */}
								<StandardTooltip content={t("prompts:createModeDialog.deleteMode")}>
									<Button
										variant="ghost"
										size="icon"
										onClick={() => {
											const customMode = findModeBySlug(visualMode, customModes)
											if (customMode) {
												setModeToDelete({
													slug: customMode.slug,
													name: customMode.name,
													source: customMode.source || "global",
												})
												vscode.postMessage({
													type: "deleteCustomMode",
													slug: customMode.slug,
													checkOnly: true,
												})
											}
										}}
										data-testid="delete-mode-button"
										disabled={
											!findModeBySlug(visualMode, customModes) || isModeOrgLocked(visualMode)
										}>
										<span className="codicon codicon-trash" />
									</Button>
								</StandardTooltip>

								{/* Export mode (kept here to the right of the dropdown) */}
								<StandardTooltip content={t("prompts:exportMode.title")}>
									<Button
										variant="ghost"
										size="icon"
										onClick={() => {
											const currentMode = getCurrentMode()
											if (currentMode?.slug && !isExporting) {
												setIsExporting(true)
												vscode.postMessage({
													type: "exportMode",
													slug: currentMode.slug,
												})
											}
										}}
										disabled={isExporting}
										title={t("prompts:exportMode.title")}
										data-testid="export-mode-toolbar-button">
										<Upload className="h-4 w-4" />
									</Button>
								</StandardTooltip>
							</>
						)}
					</div>

					{/* Org-locked banner: the mode's definition is final by org policy;
					    field edits below would be refused by the host on Save. */}
					{isModeOrgLocked(visualMode) && (
						<div
							className="flex items-center gap-2 mb-3 px-3 py-2 rounded border border-vscode-inputValidation-warningBorder bg-vscode-inputValidation-warningBackground text-sm"
							data-testid="mode-org-locked-banner">
							<span className="codicon codicon-lock" />
							{t("prompts:modes.orgLocked")}
						</div>
					)}

					{/* API Configuration - Moved Here */}
					<div className="mb-3">
						<div className="font-bold mb-1">{t("prompts:apiConfiguration.title")}</div>
						<div className="text-sm text-vscode-descriptionForeground mb-2">
							{t("prompts:apiConfiguration.select")}
						</div>
						<div className="mb-2">
							<Select
								// PER-MODE association for the mode being edited (`visualMode`),
								// keyed by config id. The global default is set separately in
								// Settings → Providers. Save-gated: staged in
								// `pendingModeApiConfig` and applied on Save via `commitBuffers`
								// (→ `setModeApiConfig`).
								value={pendingModeApiConfig[visualMode] ?? modeApiConfigs?.[visualMode] ?? ""}
								onValueChange={(value) => {
									setPendingModeApiConfig((prev) => ({ ...prev, [visualMode]: value }))
									onModesDirty?.()
								}}>
								<SelectTrigger className="w-full">
									<SelectValue placeholder={t("settings:common.select")} />
								</SelectTrigger>
								<SelectContent>
									{(listApiConfigMeta || []).map((config) => (
										<SelectItem key={config.id} value={config.id}>
											{config.name}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
						{/* When this mode has no per-mode association, it falls back to the
						    global default configured in Settings → Providers. */}
						{!(pendingModeApiConfig[visualMode] ?? modeApiConfigs?.[visualMode]) && (
							<div className="text-xs text-vscode-descriptionForeground italic">
								{t("prompts:apiConfiguration.usesDefault", {
									defaultValue:
										"No mode-specific configuration — uses the default ({{config}}) from Settings → Providers.",
									config: currentApiConfigName || "default",
								})}
							</div>
						)}
					</div>
				</div>

				{/* Role Definition section */}
				<div className="mb-4">
					<div className="flex justify-between items-center mb-1">
						<div className="font-bold">{t("prompts:roleDefinition.title")}</div>
						{!findModeBySlug(visualMode, customModes) && (
							<StandardTooltip content={t("prompts:roleDefinition.resetToDefault")}>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => {
										const currentMode = getCurrentMode()
										if (currentMode?.slug) {
											handleAgentReset(currentMode.slug, "roleDefinition")
										}
									}}
									data-testid="role-definition-reset">
									<span className="codicon codicon-discard"></span>
								</Button>
							</StandardTooltip>
						)}
					</div>
					<div className="text-sm text-vscode-descriptionForeground mb-2">
						{t("prompts:roleDefinition.description")}
					</div>
					<textarea
						value={getEffectiveRoleDefinition()}
						onChange={(e) => {
							setModeOverrideField(visualMode, "roleDefinition", e.target.value)
						}}
						className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
						rows={5}
						data-testid={`${getCurrentMode()?.slug || "code"}-prompt-textarea`}
					/>
				</div>

				{/* Description section */}
				<div className="mb-4">
					<div className="flex justify-between items-center mb-1">
						<div className="font-bold">{t("prompts:description.title")}</div>
						{!findModeBySlug(visualMode, customModes) && (
							<StandardTooltip content={t("prompts:description.resetToDefault")}>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => {
										const currentMode = getCurrentMode()
										if (currentMode?.slug) {
											handleAgentReset(currentMode.slug, "description")
										}
									}}
									data-testid="description-reset">
									<span className="codicon codicon-discard"></span>
								</Button>
							</StandardTooltip>
						)}
					</div>
					<div className="text-sm text-vscode-descriptionForeground mb-2">
						{t("prompts:description.description")}
					</div>
					<VSCodeTextField
						value={getEffectiveDescription()}
						onChange={(e) => {
							const value =
								(e as unknown as CustomEvent)?.detail?.target?.value ??
								((e as any).target as HTMLTextAreaElement).value
							setModeOverrideField(visualMode, "description", value)
						}}
						className="w-full"
						data-testid={`${getCurrentMode()?.slug || "code"}-description-textfield`}
					/>
				</div>

				{/* When to Use section */}
				<div className="mb-4">
					<div className="flex justify-between items-center mb-1">
						<div className="font-bold">{t("prompts:whenToUse.title")}</div>
						{!findModeBySlug(visualMode, customModes) && (
							<StandardTooltip content={t("prompts:whenToUse.resetToDefault")}>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => {
										const currentMode = getCurrentMode()
										if (currentMode?.slug) {
											handleAgentReset(currentMode.slug, "whenToUse")
										}
									}}
									data-testid="when-to-use-reset">
									<span className="codicon codicon-discard"></span>
								</Button>
							</StandardTooltip>
						)}
					</div>
					<div className="text-sm text-vscode-descriptionForeground mb-2">
						{t("prompts:whenToUse.description")}
					</div>
					<textarea
						value={getEffectiveWhenToUse()}
						onChange={(e) => {
							setModeOverrideField(visualMode, "whenToUse", e.target.value)
						}}
						className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
						rows={4}
						data-testid={`${getCurrentMode()?.slug || "code"}-when-to-use-textarea`}
					/>
				</div>

				{/* Mode settings */}
				<>
					{/* Show tools for all modes */}
					<div className="mb-4">
						<div className="flex justify-between items-center mb-1">
							<div className="font-bold">{t("prompts:tools.title")}</div>
							{findModeBySlug(visualMode, customModes) && (
								<StandardTooltip
									content={
										isToolsEditMode ? t("prompts:tools.doneEditing") : t("prompts:tools.editTools")
									}>
									<Button
										variant="ghost"
										size="icon"
										data-testid="edit-tools-button"
										onClick={() => setIsToolsEditMode(!isToolsEditMode)}>
										<span
											className={`codicon codicon-${isToolsEditMode ? "check" : "edit"}`}></span>
									</Button>
								</StandardTooltip>
							)}
						</div>
						{!findModeBySlug(visualMode, customModes) && (
							<div className="text-sm text-vscode-descriptionForeground mb-2">
								{t("prompts:tools.builtInModesText")}
							</div>
						)}
						{isToolsEditMode && findModeBySlug(visualMode, customModes) ? (
							<div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-2">
								{availableGroups.map((group) => {
									const currentMode = getCurrentMode()
									const isCustomMode = findModeBySlug(visualMode, customModes)
									const customMode = isCustomMode
									// Staged-first so unsaved checkbox toggles render.
									const effectiveTools = customMode
										? (pendingModeGroups[customMode.slug] ?? customMode.tools)
										: currentMode?.tools
									const isGroupEnabled = effectiveTools?.some((g) => getGroupName(g) === group)

									return (
										<VSCodeCheckbox
											key={group}
											data-testid={`tool-group-checkbox-${group}`}
											checked={isGroupEnabled}
											onChange={handleGroupChange(group, Boolean(isCustomMode), customMode)}
											disabled={!isCustomMode}>
											{t(`prompts:tools.toolNames.${group}`)}
											{group === "write" && (
												<div className="text-xs text-vscode-descriptionForeground mt-0.5">
													{t("prompts:tools.allowedFiles")}{" "}
													{(() => {
														const editGroup = effectiveTools?.find(
															(g) =>
																Array.isArray(g) && g[0] === "write" && g[1]?.fileRegex,
														)
														if (!Array.isArray(editGroup)) return t("prompts:allFiles")
														return editGroup[1].description || `/${editGroup[1].fileRegex}/`
													})()}
												</div>
											)}
										</VSCodeCheckbox>
									)
								})}
							</div>
						) : (
							<div className="text-sm text-vscode-foreground mb-2 leading-relaxed">
								{(() => {
									const currentMode = getCurrentMode()
									// Staged-first so unsaved checkbox toggles render.
									const enabledGroups = currentMode
										? (pendingModeGroups[currentMode.slug] ?? currentMode.tools ?? [])
										: []

									// If there are no enabled groups, display translated "None"
									if (enabledGroups.length === 0) {
										return t("prompts:tools.noTools")
									}

									return enabledGroups
										.map((group) => {
											const groupName = getGroupName(group)
											const displayName = t(`prompts:tools.toolNames.${groupName}`)
											if (Array.isArray(group) && group[1]?.fileRegex) {
												const description = group[1].description || `/${group[1].fileRegex}/`
												return `${displayName} (${description})`
											}
											return displayName
										})
										.join(", ")
								})()}
							</div>
						)}
					</div>
				</>

				{/* Role definition for both built-in and custom modes */}
				<div className="mb-2">
					<div className="flex justify-between items-center mb-1">
						<div className="font-bold">{t("prompts:customInstructions.title")}</div>
						{!findModeBySlug(visualMode, customModes) && (
							<StandardTooltip content={t("prompts:customInstructions.resetToDefault")}>
								<Button
									variant="ghost"
									size="icon"
									onClick={() => {
										const currentMode = getCurrentMode()
										if (currentMode?.slug) {
											handleAgentReset(currentMode.slug, "customInstructions")
										}
									}}
									data-testid="custom-instructions-reset">
									<span className="codicon codicon-discard"></span>
								</Button>
							</StandardTooltip>
						)}
					</div>
					<div className="text-[13px] text-vscode-descriptionForeground mb-2">
						{t("prompts:customInstructions.description", {
							modeName: getCurrentMode()?.name || "Code",
						})}
					</div>
					<textarea
						value={getEffectiveModeCustomInstructions()}
						onChange={(e) => {
							setModeOverrideField(visualMode, "customInstructions", e.target.value)
						}}
						rows={10}
						className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
						data-testid={`${getCurrentMode()?.slug || "code"}-custom-instructions-textarea`}
					/>
					<div className="text-xs text-vscode-descriptionForeground mt-1.5">
						<Trans
							i18nKey="prompts:customInstructions.loadFromFile"
							values={{
								mode: getCurrentMode()?.name || "Code",
								slug: getCurrentMode()?.slug || "code",
							}}
							components={{
								span: (
									<span
										className="text-vscode-textLink-foreground cursor-pointer underline"
										onClick={() => {
											const currentMode = getCurrentMode()
											if (!currentMode) return

											// Open or create an empty file
											vscode.postMessage({
												type: "openFile",
												text: `./.shofer/rules-${currentMode.slug}/rules.md`,
												values: {
													create: true,
													content: "",
												},
											})
										}}
									/>
								),
								"0": (
									<VSCodeLink
										href={buildDocLink(
											"features/custom-instructions#global-rules-directory",
											"prompts_mode_specific_global_rules",
										)}
										style={{ display: "inline" }}
										aria-label="Learn about global custom instructions for modes"
									/>
								),
							}}
						/>
					</div>
				</div>

				<div className="pb-4 border-b border-vscode-input-border">
					<div className="flex gap-2 mb-4">
						<Button
							variant="primary"
							onClick={() => {
								const currentMode = getCurrentMode()
								if (currentMode) {
									vscode.postMessage({
										type: "getSystemPrompt",
										mode: currentMode.slug,
									})
								}
							}}
							data-testid="preview-prompt-button">
							{t("prompts:systemPrompt.preview")}
						</Button>
						<StandardTooltip content={t("prompts:systemPrompt.copy")}>
							<Button
								variant="ghost"
								size="icon"
								onClick={() => {
									const currentMode = getCurrentMode()
									if (currentMode) {
										vscode.postMessage({
											type: "copySystemPrompt",
											mode: currentMode.slug,
										})
									}
								}}
								data-testid="copy-prompt-button">
								<span className="codicon codicon-copy"></span>
							</Button>
						</StandardTooltip>
					</div>
				</div>

				<div className="pb-5">
					<h3 className="text-vscode-foreground mb-3">{t("prompts:globalCustomInstructions.title")}</h3>

					<div className="text-sm text-vscode-descriptionForeground mb-2">
						<Trans i18nKey="prompts:globalCustomInstructions.description">
							<VSCodeLink
								href={buildDocLink(
									"features/custom-instructions#setting-up-global-rules",
									"prompts_global_custom_instructions",
								)}
								style={{ display: "inline" }}
								aria-label="Learn more about global custom instructions"></VSCodeLink>
						</Trans>
					</div>
					<textarea
						value={getEffectiveGlobalCustomInstructions()}
						onChange={(e) => {
							// Buffer the edit; commitBuffers() will persist on Save.
							setGlobalCIOverride(e.target.value)
							markDirty()
						}}
						rows={4}
						className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
						data-testid="global-custom-instructions-textarea"
					/>
					<div className="text-xs text-vscode-descriptionForeground mt-1.5">
						<Trans
							i18nKey="prompts:globalCustomInstructions.loadFromFile"
							components={{
								span: (
									<span
										className="text-vscode-textLink-foreground cursor-pointer underline"
										onClick={() =>
											vscode.postMessage({
												type: "openFile",
												text: "./.shofer/rules/rules.md",
												values: {
													create: true,
													content: "",
												},
											})
										}
									/>
								),
								"0": (
									<VSCodeLink
										href={buildDocLink(
											"features/custom-instructions#setting-up-global-rules",
											"prompts_global_rules",
										)}
										style={{ display: "inline" }}
										aria-label="Learn about setting up global custom instructions"
									/>
								),
							}}
						/>
					</div>
				</div>
			</Section>

			{isCreateModeDialogOpen && (
				<div className="fixed inset-0 flex justify-end bg-black/50 z-[1000]">
					<div className="w-[calc(100vw-100px)] h-full bg-vscode-editor-background shadow-md flex flex-col relative">
						<div className="flex-1 p-5 overflow-y-auto min-h-0">
							<Button
								variant="ghost"
								size="icon"
								onClick={() => setIsCreateModeDialogOpen(false)}
								className="absolute top-5 right-5">
								<span className="codicon codicon-close"></span>
							</Button>
							<h2 className="mb-4">{t("prompts:createModeDialog.title")}</h2>
							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.name.label")}</div>
								<Input
									type="text"
									value={newModeName}
									onChange={(e) => {
										handleNameChange(e.target.value)
									}}
									className="w-full"
								/>
								{nameError && (
									<div className="text-xs text-vscode-errorForeground mt-1">{nameError}</div>
								)}
							</div>
							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.slug.label")}</div>
								<Input
									type="text"
									value={newModeSlug}
									onChange={(e) => {
										setNewModeSlug(e.target.value)
									}}
									className="w-full"
								/>
								<div className="text-xs text-vscode-descriptionForeground mt-1">
									{t("prompts:createModeDialog.slug.description")}
								</div>
								{slugError && (
									<div className="text-xs text-vscode-errorForeground mt-1">{slugError}</div>
								)}
							</div>
							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.saveLocation.label")}</div>
								<div className="text-sm text-vscode-descriptionForeground mb-2">
									{t("prompts:createModeDialog.saveLocation.description")}
								</div>
								<VSCodeRadioGroup
									value={newModeSource}
									onChange={(e: Event | React.FormEvent<HTMLElement>) => {
										const target = ((e as CustomEvent)?.detail?.target ||
											(e.target as HTMLInputElement)) as HTMLInputElement
										setNewModeSource(target.value as ModeSource)
									}}>
									<VSCodeRadio value="global">
										{t("prompts:createModeDialog.saveLocation.global.label")}
										<div className="text-xs text-vscode-descriptionForeground mt-0.5">
											{t("prompts:createModeDialog.saveLocation.global.description")}
										</div>
									</VSCodeRadio>
									<VSCodeRadio value="project">
										{t("prompts:createModeDialog.saveLocation.project.label")}
										<div className="text-xs text-vscode-descriptionForeground mt-0.5">
											{t("prompts:createModeDialog.saveLocation.project.description")}
										</div>
									</VSCodeRadio>
								</VSCodeRadioGroup>
							</div>

							<div style={{ marginBottom: "16px" }}>
								<div style={{ fontWeight: "bold", marginBottom: "4px" }}>
									{t("prompts:createModeDialog.roleDefinition.label")}
								</div>
								<div
									style={{
										fontSize: "13px",
										color: "var(--vscode-descriptionForeground)",
										marginBottom: "8px",
									}}>
									{t("prompts:createModeDialog.roleDefinition.description")}
								</div>
								<textarea
									value={newModeRoleDefinition}
									onChange={(e) => {
										setNewModeRoleDefinition(e.target.value)
									}}
									rows={4}
									className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
								/>
								{roleDefinitionError && (
									<div className="text-xs text-vscode-errorForeground mt-1">
										{roleDefinitionError}
									</div>
								)}
							</div>

							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.description.label")}</div>
								<div className="text-[13px] text-vscode-descriptionForeground mb-2">
									{t("prompts:createModeDialog.description.description")}
								</div>
								<VSCodeTextField
									value={newModeDescription}
									onChange={(e) => {
										setNewModeDescription((e.target as HTMLInputElement).value)
									}}
									className="w-full"
								/>
								{descriptionError && (
									<div className="text-xs text-vscode-errorForeground mt-1">{descriptionError}</div>
								)}
							</div>

							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.whenToUse.label")}</div>
								<div className="text-[13px] text-vscode-descriptionForeground mb-2">
									{t("prompts:createModeDialog.whenToUse.description")}
								</div>
								<textarea
									value={newModeWhenToUse}
									onChange={(e) => {
										setNewModeWhenToUse(e.target.value)
									}}
									rows={3}
									className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
								/>
							</div>
							<div className="mb-4">
								<div className="font-bold mb-1">{t("prompts:createModeDialog.tools.label")}</div>
								<div className="text-[13px] text-vscode-descriptionForeground mb-2">
									{t("prompts:createModeDialog.tools.description")}
								</div>
								<div className="grid grid-cols-[repeat(auto-fill,minmax(200px,1fr))] gap-2">
									{availableGroups.map((group) => (
										<VSCodeCheckbox
											key={group}
											checked={newModeGroups.some((g) => getGroupName(g) === group)}
											onChange={(e: Event | React.FormEvent<HTMLElement>) => {
												const target =
													(e as CustomEvent)?.detail?.target || (e.target as HTMLInputElement)
												const checked = target.checked
												if (checked) {
													setNewModeGroups([...newModeGroups, group])
												} else {
													setNewModeGroups(
														newModeGroups.filter((g) => getGroupName(g) !== group),
													)
												}
											}}>
											{t(`prompts:tools.toolNames.${group}`)}
										</VSCodeCheckbox>
									))}
								</div>
								{groupsError && (
									<div className="text-xs text-vscode-errorForeground mt-1">{groupsError}</div>
								)}
							</div>
							<div className="mb-4">
								<div className="font-bold mb-1">
									{t("prompts:createModeDialog.customInstructions.label")}
								</div>
								<div className="text-[13px] text-vscode-descriptionForeground mb-2">
									{t("prompts:createModeDialog.customInstructions.description")}
								</div>
								<textarea
									value={newModeCustomInstructions}
									onChange={(e) => {
										setNewModeCustomInstructions(e.target.value)
									}}
									rows={4}
									className="w-full text-vscode-input-foreground bg-[var(--vscode-input-background)] border border-[var(--vscode-input-border)] rounded px-3 py-2 resize-y font-[var(--vscode-editor-font-family)] text-[13px] leading-normal"
								/>
							</div>
						</div>
						<div className="flex justify-end p-3 px-5 gap-2 border-t border-vscode-editor-lineHighlightBorder bg-vscode-editor-background">
							<Button variant="secondary" onClick={() => setIsCreateModeDialogOpen(false)}>
								{t("prompts:createModeDialog.buttons.cancel")}
							</Button>
							<Button variant="primary" onClick={handleCreateMode}>
								{t("prompts:createModeDialog.buttons.create")}
							</Button>
						</div>
					</div>
				</div>
			)}

			{isDialogOpen && (
				<div className="fixed inset-0 flex justify-end bg-black/50 z-[1000]">
					<div className="w-[calc(100vw-100px)] h-full bg-vscode-editor-background shadow-md flex flex-col relative">
						<div className="flex-1 p-5 overflow-y-auto min-h-0">
							<Button
								variant="ghost"
								size="icon"
								onClick={() => setIsDialogOpen(false)}
								className="absolute top-5 right-5">
								<span className="codicon codicon-close"></span>
							</Button>
							<h2 className="mb-4">
								{selectedPromptTitle ||
									t("prompts:systemPrompt.title", {
										modeName: getCurrentMode()?.name || "Code",
									})}
							</h2>
							<pre className="p-2 whitespace-pre-wrap break-words font-mono text-vscode-editor-font-size text-vscode-editor-foreground bg-vscode-editor-background border border-vscode-editor-lineHighlightBorder rounded overflow-y-auto">
								{selectedPromptContent}
							</pre>
						</div>
						<div className="flex justify-end p-3 px-5 border-t border-vscode-editor-lineHighlightBorder bg-vscode-editor-background">
							<Button variant="secondary" onClick={() => setIsDialogOpen(false)}>
								{t("prompts:createModeDialog.close")}
							</Button>
						</div>
					</div>
				</div>
			)}

			{/* Import Mode Dialog */}
			{showImportDialog && (
				<div className="fixed inset-0 flex items-center justify-center bg-black/50 z-[1000]">
					<div className="bg-vscode-editor-background border border-vscode-editor-lineHighlightBorder rounded-lg shadow-lg p-6 max-w-md w-full">
						<h3 className="text-lg font-semibold mb-4">{t("prompts:modes.importMode")}</h3>
						<p className="text-sm text-vscode-descriptionForeground mb-4">
							{t("prompts:importMode.selectLevel")}
						</p>
						<div className="space-y-3 mb-6">
							<label className="flex items-start gap-2 cursor-pointer">
								<input
									type="radio"
									name="importLevel"
									value="project"
									className="mt-1"
									checked={importLevel === "project"}
									onChange={() => setImportLevel("project")}
								/>
								<div>
									<div className="font-medium">{t("prompts:importMode.project.label")}</div>
									<div className="text-xs text-vscode-descriptionForeground">
										{t("prompts:importMode.project.description")}
									</div>
								</div>
							</label>
							<label className="flex items-start gap-2 cursor-pointer">
								<input
									type="radio"
									name="importLevel"
									value="global"
									className="mt-1"
									checked={importLevel === "global"}
									onChange={() => setImportLevel("global")}
								/>
								<div>
									<div className="font-medium">{t("prompts:importMode.global.label")}</div>
									<div className="text-xs text-vscode-descriptionForeground">
										{t("prompts:importMode.global.description")}
									</div>
								</div>
							</label>
						</div>
						<div className="flex justify-end gap-2">
							<Button variant="secondary" onClick={() => setShowImportDialog(false)}>
								{t("prompts:createModeDialog.buttons.cancel")}
							</Button>
							<Button
								variant="primary"
								onClick={() => {
									if (!isImporting) {
										setIsImporting(true)
										vscode.postMessage({
											type: "importMode",
											source: importLevel,
										})
									}
								}}
								disabled={isImporting}>
								{isImporting ? t("prompts:importMode.importing") : t("prompts:importMode.import")}
							</Button>
						</div>
					</div>
				</div>
			)}

			{/* Delete Mode Confirmation Dialog */}
			<DeleteModeDialog
				open={showDeleteConfirm}
				onOpenChange={setShowDeleteConfirm}
				modeToDelete={modeToDelete}
				onConfirm={() => {
					if (modeToDelete) {
						vscode.postMessage({
							type: "deleteCustomMode",
							slug: modeToDelete.slug,
						})
						setShowDeleteConfirm(false)
						setModeToDelete(null)
					}
				}}
			/>
		</div>
	)
})

ModesView.displayName = "ModesView"

export default ModesView
