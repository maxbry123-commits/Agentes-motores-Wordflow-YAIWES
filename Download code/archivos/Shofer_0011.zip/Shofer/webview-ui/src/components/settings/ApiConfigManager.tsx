import { memo, useEffect, useRef, useState } from "react"
import { VSCodeTextField } from "@vscode/webview-ui-toolkit/react"
import { AlertTriangle } from "lucide-react"

import type { ProviderSettingsEntry, OrganizationAllowList } from "@shofer/types"

import { useAppTranslation } from "@/i18n/TranslationContext"
import { useExtensionState } from "@src/context/ExtensionStateContext"
import {
	type SearchableSelectOption,
	Button,
	Input,
	Dialog,
	DialogContent,
	DialogTitle,
	StandardTooltip,
	SearchableSelect,
} from "@/components/ui"

interface ApiConfigManagerProps {
	/** The global default config name (read-only from host state). */
	currentApiConfigName?: string
	/** The config currently being edited. Drives the edit dropdown and what
	 *  ApiOptions renders. Saved back under this name via the global Save button. */
	editingConfigName: string
	listApiConfigMeta?: ProviderSettingsEntry[]
	organizationAllowList?: OrganizationAllowList
	/** Called when the edit dropdown changes — loads config settings for editing. */
	onSelectConfigForEdit: (configName: string) => void
	/** Called when the default dropdown changes — switches the global default. */
	onSelectConfigAsDefault: (configName: string) => void
	onDeleteConfig: (configName: string) => void
	onRenameConfig: (oldName: string, newName: string) => void
	onUpsertConfig: (configName: string) => void
}

const ApiConfigManager = ({
	currentApiConfigName = "",
	editingConfigName,
	listApiConfigMeta = [],
	organizationAllowList,
	onSelectConfigForEdit,
	onSelectConfigAsDefault,
	onDeleteConfig,
	onRenameConfig,
	onUpsertConfig,
}: ApiConfigManagerProps) => {
	const { t } = useAppTranslation()
	const { orgLockedResources } = useExtensionState()

	// Org-locked profiles (final by the org scope's locked.json): non-secret
	// fields are read-only and the host refuses rename/delete, so disable those
	// affordances up front. Entering a local API key stays allowed.
	const isEditingConfigLocked = (orgLockedResources?.providers ?? []).includes(editingConfigName)

	const [isRenaming, setIsRenaming] = useState(false)
	const [isCreating, setIsCreating] = useState(false)
	const [inputValue, setInputValue] = useState("")
	const [newProfileName, setNewProfileName] = useState("")
	const [error, setError] = useState<string | null>(null)
	const inputRef = useRef<any>(null)
	const newProfileInputRef = useRef<any>(null)

	// Check if a profile is valid based on the organization allow list
	const isProfileValid = (profile: ProviderSettingsEntry): boolean => {
		if (!organizationAllowList || organizationAllowList.allowAll) {
			return true
		}
		const provider = profile.apiProvider
		if (!provider) return true
		const providerConfig = organizationAllowList.providers[provider]
		if (!providerConfig) {
			return false
		}
		return !!providerConfig.allowAll || !!(providerConfig.models && providerConfig.models.length > 0)
	}

	const buildSearchableOptions = () =>
		listApiConfigMeta.map((config) => {
			const valid = isProfileValid(config)
			return {
				value: config.name,
				label: config.name,
				disabled: !valid,
				icon: !valid ? (
					<StandardTooltip content={t("settings:validation.profileInvalid")}>
						<span>
							<AlertTriangle size={16} className="mr-2 text-vscode-errorForeground" />
						</span>
					</StandardTooltip>
				) : undefined,
			} as SearchableSelectOption
		})

	const validateName = (name: string, isNewProfile: boolean): string | null => {
		const trimmed = name.trim()
		if (!trimmed) return t("settings:providers.nameEmpty")

		const nameExists = listApiConfigMeta?.some((config) => config.name.toLowerCase() === trimmed.toLowerCase())

		if (isNewProfile && nameExists) {
			return t("settings:providers.nameExists")
		}

		// For rename, only block if trying to rename to a different existing profile.
		if (!isNewProfile && nameExists && trimmed.toLowerCase() !== editingConfigName?.toLowerCase()) {
			return t("settings:providers.nameExists")
		}

		return null
	}

	const resetCreateState = () => {
		setIsCreating(false)
		setNewProfileName("")
		setError(null)
	}

	const resetRenameState = () => {
		setIsRenaming(false)
		setInputValue("")
		setError(null)
	}

	// Focus input when entering rename mode.
	useEffect(() => {
		if (isRenaming) {
			const timeoutId = setTimeout(() => inputRef.current?.focus(), 0)
			return () => clearTimeout(timeoutId)
		}
	}, [isRenaming])

	// Focus input when opening new dialog.
	useEffect(() => {
		if (isCreating) {
			const timeoutId = setTimeout(() => newProfileInputRef.current?.focus(), 0)
			return () => clearTimeout(timeoutId)
		}
	}, [isCreating])

	// Reset state when editing config changes.
	useEffect(() => {
		resetCreateState()
		resetRenameState()
	}, [editingConfigName])

	const handleSelectForEdit = (configName: string) => {
		if (!configName) return
		onSelectConfigForEdit(configName)
	}

	const handleSelectAsDefault = (configName: string) => {
		if (!configName) return
		onSelectConfigAsDefault(configName)
	}

	const handleAdd = () => {
		resetCreateState()
		setIsCreating(true)
	}

	const handleStartRename = () => {
		setIsRenaming(true)
		setInputValue(editingConfigName || "")
		setError(null)
	}

	const handleCancel = () => {
		resetRenameState()
	}

	const handleSave = () => {
		const trimmedValue = inputValue.trim()
		const err = validateName(trimmedValue, false)

		if (err) {
			setError(err)
			return
		}

		if (isRenaming && editingConfigName) {
			if (editingConfigName === trimmedValue) {
				resetRenameState()
				return
			}
			onRenameConfig(editingConfigName, trimmedValue)
		}

		resetRenameState()
	}

	const handleNewProfileSave = () => {
		const trimmedValue = newProfileName.trim()
		const err = validateName(trimmedValue, true)

		if (err) {
			setError(err)
			return
		}

		onUpsertConfig(trimmedValue)
		resetCreateState()
	}

	const handleDelete = () => {
		if (!editingConfigName || !listApiConfigMeta || listApiConfigMeta.length <= 1) return
		onDeleteConfig(editingConfigName)
	}

	const isOnlyProfile = listApiConfigMeta?.length === 1

	return (
		<div className="flex flex-col gap-3">
			{/* Default dropdown — controls the global default config */}
			<div>
				<label className="block font-medium mb-1">{t("settings:providers.defaultConfigProfile")}</label>
				<SearchableSelect
					value={currentApiConfigName}
					onValueChange={handleSelectAsDefault}
					options={buildSearchableOptions()}
					placeholder={t("settings:common.select")}
					searchPlaceholder={t("settings:providers.searchPlaceholder")}
					emptyMessage={t("settings:providers.noMatchFound")}
					className="grow"
					data-testid="default-config-select"
				/>
				<div className="text-vscode-descriptionForeground text-sm mt-1">
					{t("settings:providers.defaultDescription")}
				</div>
			</div>

			{/* Edit dropdown — selects which config to edit, no side effects besides loading settings */}
			<div>
				<label className="block font-medium mb-1">{t("settings:providers.editConfigProfile")}</label>
				<div className="flex items-center gap-1">
					<SearchableSelect
						value={editingConfigName}
						onValueChange={handleSelectForEdit}
						options={buildSearchableOptions()}
						placeholder={t("settings:common.select")}
						searchPlaceholder={t("settings:providers.searchPlaceholder")}
						emptyMessage={t("settings:providers.noMatchFound")}
						className="grow"
						data-testid="edit-config-select"
					/>
					<StandardTooltip content={t("settings:providers.addProfile")}>
						<Button variant="ghost" size="icon" onClick={handleAdd} data-testid="add-profile-button">
							<span className="codicon codicon-add" />
						</Button>
					</StandardTooltip>
					{editingConfigName && (
						<>
							<StandardTooltip
								content={
									isEditingConfigLocked
										? t("settings:providers.orgLockedProfile")
										: t("settings:providers.renameProfile")
								}>
								<Button
									variant="ghost"
									size="icon"
									onClick={handleStartRename}
									data-testid="rename-profile-button"
									disabled={isEditingConfigLocked}>
									<span className="codicon codicon-edit" />
								</Button>
							</StandardTooltip>
							<StandardTooltip
								content={
									isEditingConfigLocked
										? t("settings:providers.orgLockedProfile")
										: isOnlyProfile
											? t("settings:providers.cannotDeleteOnlyProfile")
											: t("settings:providers.deleteProfile")
								}>
								<Button
									variant="ghost"
									size="icon"
									onClick={handleDelete}
									data-testid="delete-profile-button"
									disabled={isOnlyProfile || isEditingConfigLocked}>
									<span className="codicon codicon-trash" />
								</Button>
							</StandardTooltip>
							{isEditingConfigLocked && (
								<span
									className="codicon codicon-lock text-vscode-descriptionForeground"
									title={t("settings:providers.orgLockedProfile")}
									data-testid="org-locked-profile-icon"
								/>
							)}
						</>
					)}
				</div>
				<div className="text-vscode-descriptionForeground text-sm mt-1">
					{t("settings:providers.editDescription")}
				</div>
			</div>

			{/* Rename form (overlays the edit dropdown when active) */}
			{isRenaming && (
				<div className="mt-1" data-testid="rename-form">
					<div className="flex items-center gap-1">
						<VSCodeTextField
							ref={inputRef}
							value={inputValue}
							onInput={(e: unknown) => {
								const target = e as { target: { value: string } }
								setInputValue(target.target.value)
								setError(null)
							}}
							placeholder={t("settings:providers.enterNewName")}
							onKeyDown={({ key }) => {
								if (key === "Enter" && inputValue.trim()) {
									handleSave()
								} else if (key === "Escape") {
									handleCancel()
								}
							}}
							className="grow"
						/>
						<StandardTooltip content={t("settings:common.save")}>
							<Button
								variant="ghost"
								size="icon"
								disabled={!inputValue.trim()}
								onClick={handleSave}
								data-testid="save-rename-button">
								<span className="codicon codicon-check" />
							</Button>
						</StandardTooltip>
						<StandardTooltip content={t("settings:common.cancel")}>
							<Button
								variant="ghost"
								size="icon"
								onClick={handleCancel}
								data-testid="cancel-rename-button">
								<span className="codicon codicon-close" />
							</Button>
						</StandardTooltip>
					</div>
					{error && (
						<div className="text-vscode-descriptionForeground text-sm mt-1" data-testid="error-message">
							{error}
						</div>
					)}
				</div>
			)}

			<Dialog
				open={isCreating}
				onOpenChange={(open: boolean) => {
					if (open) {
						setIsCreating(true)
						setNewProfileName("")
						setError(null)
					} else {
						resetCreateState()
					}
				}}
				aria-labelledby="new-profile-title">
				<DialogContent className="p-4 max-w-sm bg-card">
					<DialogTitle>{t("settings:providers.newProfile")}</DialogTitle>
					<Input
						ref={newProfileInputRef}
						value={newProfileName}
						onInput={(e: unknown) => {
							const target = e as { target: { value: string } }
							setNewProfileName(target.target.value)
							setError(null)
						}}
						placeholder={t("settings:providers.enterProfileName")}
						data-testid="new-profile-input"
						style={{ width: "100%" }}
						onKeyDown={(e: unknown) => {
							const event = e as { key: string }
							if (event.key === "Enter" && newProfileName.trim()) {
								handleNewProfileSave()
							} else if (event.key === "Escape") {
								resetCreateState()
							}
						}}
					/>
					{error && (
						<p className="text-vscode-errorForeground text-sm mt-2" data-testid="error-message">
							{error}
						</p>
					)}
					<div className="flex justify-end gap-2 mt-4">
						<Button variant="secondary" onClick={resetCreateState} data-testid="cancel-new-profile-button">
							{t("settings:common.cancel")}
						</Button>
						<Button
							variant="primary"
							disabled={!newProfileName.trim()}
							onClick={handleNewProfileSave}
							data-testid="create-profile-button">
							{t("settings:providers.createProfile")}
						</Button>
					</div>
				</DialogContent>
			</Dialog>
		</div>
	)
}

export default memo(ApiConfigManager)
