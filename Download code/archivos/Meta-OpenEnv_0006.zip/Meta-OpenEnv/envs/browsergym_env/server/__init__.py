"""BrowserGym environment server module."""
