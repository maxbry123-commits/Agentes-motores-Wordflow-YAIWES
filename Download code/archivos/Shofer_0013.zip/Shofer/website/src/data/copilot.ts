export interface CopilotComparison {
	aspect: string
	copilot: string
	shofer: string
}

export const copilotComparisons: CopilotComparison[] = [
	{
		aspect: "Data Processing",
		copilot: "Cloud-proxied through Microsoft/GitHub infrastructure",
		shofer: "100% local execution — no remote server processes your workspace",
	},
	{
		aspect: "Network Autonomy",
		copilot: "Requires active internet and constant telemetry handshake",
		shofer: "Fully operational in air-gapped environments with local models",
	},
	{
		aspect: "Agent Orchestration",
		copilot:
			"Parallel Cloud Agents (isolated GitHub Actions envs) + third-party agents — orchestrated via remote envs/hooks, not a developer-authored graph",
		shofer: "Spawn, monitor and converse with child agents from any task — an in-editor tree you can inspect, with per-agent tool scoping and cost caps",
	},
	{
		aspect: "Cross-Session Memory",
		copilot:
			"Copilot Memory — an automated, repo-scoped cloud memory graph that expires after ~28 days (+ a local VS Code memory tool)",
		shofer: "A persistent local Assistant Agent plus an AST/git embedding index that never expires and stays on your machine",
	},
	{
		aspect: "Async MCP",
		copilot: "Synchronous request-response — entire loop blocks on tool calls",
		shofer: "Fire-and-forget async tool calling with parallel execution",
	},
	{
		aspect: "Cost Control",
		copilot: "No per-task hard USD cap that halts an agent mid-loop",
		shofer: "Per-task / per-session hard USD caps with automatic agent halting",
	},
	{
		aspect: "Pricing",
		copilot: "Usage-based credit-drawdown billing (Free / Pro / Pro+ / Max) with metered overages",
		shofer: "Free Open Source (Apache 2.0) — pay only for your own API tokens, or $0 fully local",
	},
]

export const copilotMigration = {
	title: "Migrating from GitHub Copilot",
	description:
		"Shofer offers everything Copilot does and much more — with full privacy, model autonomy, and granular control over every aspect of your AI coding experience.",
	command: "/migrate-from-copilot",
	docsUrl: "https://github.com/shofer-dev/shofer/blob/master/docs/migration/shofer_for_copilot_users.md",
}
