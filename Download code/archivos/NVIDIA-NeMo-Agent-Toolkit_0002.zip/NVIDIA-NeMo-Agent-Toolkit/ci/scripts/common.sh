# SPDX-FileCopyrightText: Copyright (c) 2021-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

export SCRIPT_DIR=${SCRIPT_DIR:-"$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"}

export SUPPORTED_PYTHON_VERSIONS=("3.11" "3.12" "3.13")

# The root to the NAT repo
export PROJECT_ROOT=${PROJECT_ROOT:-"$(realpath ${SCRIPT_DIR}/../..)"}

export PY_ROOT="${PROJECT_ROOT}/src"
export PROJ_TOML="${PROJECT_ROOT}/pyproject.toml"
export PY_DIRS="${PY_ROOT} ${PROJECT_ROOT}/packages ${PROJECT_ROOT}/tests ${PROJECT_ROOT}/ci/scripts "

# Determine the commits to compare against. If running in CI, these will be set. Otherwise, diff with main
export NAT_LOG_LEVEL=WARNING
export CI_MERGE_REQUEST_TARGET_BRANCH_NAME=${CI_MERGE_REQUEST_TARGET_BRANCH_NAME:-"develop"}

if [[ "${GITLAB_CI}" == "true" ]]; then
   export BASE_SHA=${BASE_SHA:-${CI_MERGE_REQUEST_TARGET_BRANCH_SHA:-${CI_MERGE_REQUEST_DIFF_BASE_SHA:-$(${SCRIPT_DIR}/gitutils.py get_merge_target --current-branch=${CURRENT_BRANCH})}}}
   export COMMIT_SHA=${CI_COMMIT_SHA:-${COMMIT_SHA:-HEAD}}
else
   export BASE_SHA=${BASE_SHA:-$(${SCRIPT_DIR}/gitutils.py get_merge_target)}
   export COMMIT_SHA=${COMMIT_SHA:-${GITHUB_SHA:-HEAD}}
fi

# ensure that we use the python version in the container
export UV_PYTHON_DOWNLOADS=never

export PYTHON_FILE_REGEX='^(\.\/)?(?!\.|build|external).*\.(py|pyx|pxd)$'

# Use these options to skip any of the checks
export SKIP_COPYRIGHT=${SKIP_COPYRIGHT:-""}

function get_num_proc() {
   NPROC_TOOL=`which nproc`
   NUM_PROC=${NUM_PROC:-`${NPROC_TOOL}`}
   echo "${NUM_PROC}"
}

function set_versions() {
   # Set the version for the wheels based on GIT_TAG / SCM

   if [[ "${CI_CRON_NIGHTLY}" == "1" || "${IS_TAGGED}" == "1" ]]; then
      # For tagged releases and nightly builds, use the git tag as the version as-is
      NAT_VERSION="${GIT_TAG}"
   else
      set +e
      NAT_VERSION=$(python -m setuptools_scm)
      local SETUPTOOLS_SCM_RESULT=$?
      set -e

      if [[ ${SETUPTOOLS_SCM_RESULT} -ne 0 ]]; then
         echo "Error, setuptools_scm failed to determine the version: ${NAT_VERSION}"
         exit ${SETUPTOOLS_SCM_RESULT}
      fi
   fi

   export SETUPTOOLS_SCM_PRETEND_VERSION="${NAT_VERSION}"
   export USE_FULL_VERSION="1"
}

function build_wheel() {
    echo "Building Wheel for $1"
    uv build --wheel --no-progress --out-dir "${WHEELS_DIR}/$2" --directory $1
}

function build_package_wheel()
{
    local pkg=$1
    pkg_dir_name="${pkg#packages/}"
    pkg_dir_name="${pkg#./packages/}"
    build_wheel "${pkg}" "${pkg_dir_name}"
}

function create_env() {

    echo "Creating uv env"
    VENV_DIR="${WORKSPACE_TMP}/.venv"
    uv venv --python=${PYTHON_VERSION} --seed ${VENV_DIR}
    source ${VENV_DIR}/bin/activate

    set +e
    UV_SYNC_STDERROUT=$(uv sync --active --only-dev 2>&1)
    UV_RESULT=$?
    set -e

    if [[ ${UV_RESULT} -ne 0 ]]; then
        echo "Error, uv sync failed with exit code ${UV_RESULT}"
        echo "StdErr output:"
        echo "${UV_SYNC_STDERROUT}"
        exit ${UV_RESULT}
    fi

    # Explicitly filter the warning about multiple packages providing a tests module, work-around for issue #611
    UV_SYNC_STDERROUT=$(echo "${UV_SYNC_STDERROUT}" | grep -v "warning: The module \`tests\` is provided by more than one package")


    # Environment should have already been created in the before_script
    if [[ "${UV_SYNC_STDERROUT}" =~ "warning:" ]]; then
        echo "Error, uv sync emitted warnings. These are usually due to missing lower bound constraints."
        echo "StdErr output:"
        echo "${UV_SYNC_STDERROUT}"
        exit 1
    fi

    echo "Final Environment"
    uv pip list
}

function get_lfs_files() {
    echo "Installing git-lfs from apt"
    apt update
    apt install --no-install-recommends -y git-lfs

    if [[ "${USE_HOST_GIT}" == "1" ]]; then
        echo "Using host git, skipping git-lfs install"
    else
        echo "Calling git lfs fetch"
        git lfs fetch
        echo "Calling git lfs pull"
        git lfs pull
    fi

    echo "git lfs ls-files"
    git lfs ls-files
}

function install_python_versions() {
   # This is the version of python currently installed
   local current_python_version=$(echo ${PYTHON_VERSION} | awk '{split($0, a, "."); print a[1]"."a[2]}')

   # This is not normally needed as our containers contain the needed python version. This is only needed for CI stages
   # which need to support multiple python versions in a single stage, such as the build_wheel stage.
   for pyver in "${SUPPORTED_PYTHON_VERSIONS[@]}"; do
      if [[ "${pyver}" == "${current_python_version}" ]]; then
         continue
      fi

      set +e
      # The managed python flag is needed since the OS's copy of python does not include C headers needed to build some
      # dependencies, specifically ruamel-yaml-clibz which is needed for semantic-kernel
      uv python find --managed-python "${pyver}" &> /dev/null
      PYTHON_FIND_RESULT=$?
      set -e
      if [[ ${PYTHON_FIND_RESULT} -ne 0 ]]; then
         echo "Downloading Python version ${pyver}"

         # In common.sh we set this to never, we want to override that here
         UV_PYTHON_DOWNLOADS="manual" uv python install --managed-python ${pyver}
         echo "✓ Successfully installed Python ${pyver}"
      fi
   done
}

function cleanup {
   # Restore the original directory
   popd &> /dev/null
}


trap cleanup EXIT

# Change directory to the repo root
pushd "${PROJECT_ROOT}" &> /dev/null

THIRD_PARTY_DEPENDENCY_PROJECTS_FILE="${PROJECT_ROOT}/ci/third_party_dependency_projects.txt"
NAT_THIRD_PARTY_DEPENDENCY_PROJECTS=()
while IFS= read -r project; do
    NAT_THIRD_PARTY_DEPENDENCY_PROJECTS+=("${project}")
done < <(grep -Ev '^[[:space:]]*(#|$)' "${THIRD_PARTY_DEPENDENCY_PROJECTS_FILE}")

function is_third_party_dependency_project() {
    local project="${1#./}"
    local excluded_project
    for excluded_project in "${NAT_THIRD_PARTY_DEPENDENCY_PROJECTS[@]}"; do
        if [[ "${project}" == "${excluded_project}" ]]; then
            return 0
        fi
    done
    return 1
}

function is_third_party_dependency_wheel() {
    local wheel_name
    wheel_name="$(basename "$1")"
    local excluded_project
    for excluded_project in "${NAT_THIRD_PARTY_DEPENDENCY_PROJECTS[@]}"; do
        if [[ "${excluded_project}" == packages/* ]]; then
            local distribution_name="${excluded_project#packages/}"
            if [[ "${wheel_name}" == "${distribution_name}-"*.whl ]]; then
                return 0
            fi
        fi
    done
    return 1
}

NAT_EXAMPLES=()
while IFS= read -r example; do
    if ! is_third_party_dependency_project "${example}"; then
        NAT_EXAMPLES+=("${example}")
    fi
done < <(find ./examples/ -maxdepth 4 -name "pyproject.toml" | sort | xargs dirname)
NAT_PACKAGES=($(find ./packages/ -maxdepth 2 -name "pyproject.toml" | sort | xargs dirname))
