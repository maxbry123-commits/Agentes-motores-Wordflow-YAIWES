<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Observing a Workflow with Arize Phoenix

This guide provides a step-by-step process to enable observability in a NeMo Agent Toolkit workflow using Arize Phoenix for tracing and logging. By the end of this guide, you will have:
- Configured telemetry in your workflow.
- Started the Phoenix server locally.
- Ability to view traces in the Phoenix UI.

## Step 1: Install the Phoenix Subpackage and Phoenix Server

Install the Phoenix dependencies to enable tracing capabilities with one of the following commands, depending on whether you installed the NeMo Agent Toolkit from source or from a package.

::::{tab-set}
:sync-group: install-tool

:::{tab-item} source
:selected:
:sync: source

```bash
uv pip install -e ".[phoenix]"
```

:::

:::{tab-item} package
:sync: package

```bash
uv pip install "nvidia-nat[phoenix]"
```

:::

::::


## Step 2: Start the Phoenix Server

Run the following command to start Phoenix server locally:
```bash
docker run -it --rm -p 4317:4317 -p 6006:6006 arizephoenix/phoenix:13.22
```
Phoenix should now be accessible at `http://0.0.0.0:6006`.

## Step 3: Modify Workflow Configuration

Update your workflow configuration file to include the telemetry settings.

Example configuration:
```yaml
general:
  telemetry:
    tracing:
      phoenix:
        _type: phoenix
        endpoint: http://localhost:6006/v1/traces
        project: simple_calculator
        # Optional, for Phoenix servers with authentication enabled.
        # You can also set PHOENIX_API_KEY instead.
        api_key: ${PHOENIX_API_KEY}
```
This setup enables tracing through Phoenix at `http://localhost:6006/v1/traces`, with traces grouped into the `simple_calculator` project.

## Step 4: Run Your Workflow

From the root directory of the NeMo Agent Toolkit library, install dependencies and run the pre-configured `simple_calculator_observability` example.

**Example:**
```bash
# Install the workflow and plugins
uv pip install -e examples/observability/simple_calculator_observability/

# Run the workflow with Phoenix telemetry settings
nat run --config_file examples/observability/simple_calculator_observability/configs/config-phoenix.yml --input "What is 1*2?"
```
As the workflow runs, telemetry data will start showing up in Phoenix.

## Step 5: View Traces Data in Phoenix

- Open your browser and navigate to `http://0.0.0.0:6006`.
- Locate your workflow traces under your project name in projects.
- Inspect function execution details, latency, total tokens, request timelines and other info under Info and Attributes tab of an individual trace.

### Debugging

For more Arize-Phoenix details, view the documentation [here](https://arize.com/docs/phoenix).
