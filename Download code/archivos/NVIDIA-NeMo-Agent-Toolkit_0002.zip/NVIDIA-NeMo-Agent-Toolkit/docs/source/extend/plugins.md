<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Plugin System in NVIDIA NeMo Agent Toolkit

NeMo Agent Toolkit has a very extensible plugin system that allows you to add new [tools](../build-workflows/functions-and-function-groups/functions.md#agents-and-tools), [agents](../components/agents/index.md), [workflows](../build-workflows/about-building-workflows.md) and more to the library. The plugin system is designed to be easy to use and allow developers to extend the library to their needs.

The plugin system is designed around two main concepts:

- **Entry Points**: Python entry points allow NeMo Agent Toolkit to discover plugins from any installed distribution package in a Python environment.
- **Decorators**: Decorators allow developers register their plugins with library.

These two concepts allow the library to be extended by installing any compatible plugins from a Python package index. Once installed, the plugin will be automatically discovered and loaded by NeMo Agent Toolkit.

NeMo Agent Toolkit utilizes the this plugin system for all first party components. This allows the library to be modular and extendable by default. Plugins from external libraries are treated exactly the same as first party plugins.

External plugin packages should import public plugin-authoring APIs from `nat.plugin_api`. This module is the stable
surface for decorators, function configuration bases, function groups, and common plugin helpers. See the
[Public Plugin API](./plugin-api.md) documentation for the compatibility contract.

For guidance on partner-owned packages, repository layout, naming, testing, and documentation expectations, see
[Third-Party Plugin Packages](./third-party-plugins.md).


## Supported Plugin Types

NeMo Agent Toolkit currently supports the following plugin types:

- **CLI Commands**: CLI commands extend the `nat` command-line interface with plugin-specific commands. For example, the MCP and A2A plugins provide their own CLI commands for client operations and server management. To register a CLI command, add an entry point in the `nat.cli` group.
- **Dataset Loaders**: [Dataset loaders](../improve-workflows/evaluate.md#using-datasets) define how evaluation datasets are loaded and parsed. Built-in dataset loaders support `json`, `jsonl`, `csv`, `xls`, `parquet`, and `custom` formats. You can add support for additional dataset formats by creating a custom dataset loader plugin. To register a dataset loader, you can use the {py:deco}`nat.plugin_api.register_dataset_loader` decorator. See the [Custom Dataset Loader](./custom-components/custom-dataset-loader.md) documentation for a step-by-step guide.
- **Embedder Clients**: [Embedder](../build-workflows/embedders.md) Clients are implementations of embedder providers, which are specific to a [LLM](../build-workflows/llms/index.md) framework. For example, when using the OpenAI embedder provider with the LangChain/LangGraph framework, the LangChain/LangGraph OpenAI embedder client needs to be registered. To register an embedder client, you can use the {py:deco}`nat.plugin_api.register_embedder_client` decorator.
- **Embedder Providers**: Embedder Providers are services that provide a way to embed text. For example, OpenAI and NVIDIA NIMs are embedder providers. To register an embedder provider, you can use the {py:deco}`nat.plugin_api.register_embedder_provider` decorator.
- **Evaluators**: [Evaluators](../improve-workflows/evaluate.md) are used by the evaluation framework to evaluate the performance of NeMo Agent Toolkit workflows. To register an evaluator, you can use the {py:deco}`nat.plugin_api.register_evaluator` decorator.
- **Front Ends**: Front ends are the mechanism by which NeMo Agent Toolkit workflows are executed. Examples of front ends include a FastAPI server or a CLI. Front-end registration remains a specialized extension point and is not yet part of the stable `nat.plugin_api` facade.
- **Functions**: [Functions](../build-workflows/functions-and-function-groups/functions.md) are one of the core building blocks of NeMo Agent Toolkit. They are used to define the tools and agents that can be used in a workflow. To register a function, you can use the {py:deco}`nat.plugin_api.register_function` decorator.
- **LLM Clients**: LLM Clients are implementations of LLM providers that are specific to a LLM framework. For example, when using the NVIDIA NIMs LLM provider with the LangChain/LangGraph framework, the NVIDIA LangChain/LangGraph LLM client needs to be registered. To register an LLM client, you can use the {py:deco}`nat.plugin_api.register_llm_client` decorator.
- **LLM Providers**: An LLM provider is a service that provides a way to interact with an LLM. For example, OpenAI and NVIDIA NIMs are LLM providers. To register an LLM provider, you can use the {py:deco}`nat.plugin_api.register_llm_provider` decorator.
- **Logging Methods**: Logging methods control the destination and format of log messages. Logging method registration remains a specialized extension point and is not yet part of the stable `nat.plugin_api` facade.
- **Memory**: [Memory](../build-workflows/memory.md) plugins are used to store and retrieve information from a database to be used by an LLM. Examples of memory plugins include Zep, Mem0 or MemMachine. To register a memory plugin, you can use the {py:deco}`nat.plugin_api.register_memory` decorator.
- **Registry Handlers**: Registry handlers are used to register custom agent registries with NeMo Agent Toolkit. An agent registry is a collection of tools, agents, and workflows that can be used in a workflow. Registry handler registration remains a specialized extension point and is not yet part of the stable `nat.plugin_api` facade.
- **Retriever Clients**: [Retriever](../build-workflows/retrievers.md) clients are implementations of retriever providers, which are specific to a LLM framework. For example, when using the Milvus retriever provider with the LangChain/LangGraph framework, the LangChain/LangGraph Milvus retriever client needs to be registered. To register a retriever client, you can use the {py:deco}`nat.plugin_api.register_retriever_client` decorator.
- **Retriever Providers**: Retriever providers are services that provide a way to retrieve information from a database. Examples of retriever providers include Chroma and Milvus. To register a retriever provider, you can use the {py:deco}`nat.plugin_api.register_retriever_provider` decorator.
- **Telemetry Exporters**: [Telemetry exporters](../run-workflows/observe/observe.md) send telemetry data to a telemetry service. To register a telemetry exporter, you can use the {py:deco}`nat.plugin_api.register_telemetry_exporter` decorator.
- **Tool Wrappers**: Tool wrappers are used to wrap functions in a way that is specific to a LLM framework. For example, when using the LangChain/LangGraph framework, NeMo Agent Toolkit functions need to be wrapped in `BaseTool` class to be compatible with LangChain/LangGraph. Tool wrapper registration is available through the provisional {py:deco}`nat.plugin_api.register_tool_wrapper` decorator while the wrapper callable contract is refined.
- **API Authentication Providers**: [API authentication providers](../components/auth/api-authentication.md) are services that provide a way to authenticate requests to an API provider. Examples of authentication providers include OAuth 2.0 Authorization Code Grant and API Key. Authentication provider registration is experimental and remains a specialized extension point outside the stable `nat.plugin_api` facade.

## Anatomy of a Plugin

### Decorators

Registering a plugin with the library is done using decorators. Each plugin type has its own decorator that is used to register the plugin with the library. Once the decorator is loaded by python, it will be ready to use in the library.

The general format for a plugin decorator is:

```python
@register_<plugin_type>()
async def my_plugin_function(plugin_config: <plugin_config_type>, builder: Builder):

   # Execute any setup code needed

   # Yield the plugin which will be used by the library
   yield <plugin_type>

   # Execute any teardown code needed
```

All plugin decorators are async context managers. This allows the plugin to execute any setup and teardown code needed.

An example of a plugin decorator for the LangChain/LangGraph LLM client for OpenAI is:

```python
@register_llm_client(config_type=OpenAIModelConfig, wrapper_type=LLMFrameworkEnum.LANGCHAIN)
async def openai_langchain(llm_config: OpenAIModelConfig, builder: Builder):

    from langchain_openai import ChatOpenAI

    yield ChatOpenAI(**llm_config.model_dump(exclude={"type", "thinking"}, by_alias=True))
```

The `wrapper_type` parameter in the decorator specifies the LLM framework that the plugin is compatible with. This instruments the plugin with the appropriate telemetry hooks to enable observability, evaluation, and [profiling](../improve-workflows/profiler.md).
The `wrapper_type` argument can also be used with the library's `Builder` class to build plugins in a framework-agnostic way. This allows the library to use the same plugin across different frameworks without needing to change the code.

### Entry Point

Determining which plugins are available in a given environment is done through the use of
[python entry points](https://packaging.python.org/en/latest/specifications/entry-points/). NeMo Agent Toolkit scans the
`nat.plugins` entry point group for plugin modules and also continues to load `nat.components` entry points for
backward compatibility with existing packages. New external plugin packages should use `nat.plugins`.

For example, a new external `nemo-agent-toolkit-my-provider` distribution could specify the following entry point in its
`pyproject.toml` file:

```toml
[project.entry-points.'nat.plugins']
nat_my_provider = "nat.plugins.my_provider.register"
```

What this means is that when the `nemo-agent-toolkit-my-provider` distribution is installed, the
`nat.plugins.my_provider.register` module will be imported when the entry point is loaded. This module must contain all
the `@register_<plugin_type>` decorators which need to be loaded when the library is initialized.

:::{note}
The above syntax in the `pyproject.toml` file is specific to [uv](https://docs.astral.sh/uv/concepts/projects/config/#plugin-entry-points). Other package managers may have a different syntax for specifying entry points.
:::


#### Multiple Plugins in a Single Distribution

It is possible to have multiple plugins in a single distribution. For example, a provider distribution could contain
both an LLM client and an embedder client.

To register multiple plugins in a single distribution, there are two options:

* Register all plugins in a single module which imports all the plugins.
   * This is the preferred method as it is more readable and easier to maintain.
   * For example, if you have a `register.py` module in a package called `my_plugin`, your `register.py` module can do the following:

      ```python
      from .llm import register_llm_client
      from .embedder import register_embedder_client
      ```

* Use multiple entry points to register all the plugins.
   * This method is functionally equivalent to the first method, but requires re-installing the distribution to reflect changes to the plugins.
   * For example, you could have two entry points in the `pyproject.toml` file:`

      ```toml
      [project.entry-points.'nat.plugins']
      nat_my_provider = "nat.plugins.my_provider.register"
      nat_my_provider_tools = "nat.plugins.my_provider.tools.register"
      ```

### CLI Command Plugins

CLI command plugins allow you to extend the `nat` command-line interface with custom commands specific to your plugin. This is useful when your plugin provides functionality that users need to access directly from the command line.

#### Creating a CLI Command Plugin

To create a CLI command plugin:

1. **Create a Click command or group** in your plugin package:
<!-- path-check-skip-begin -->
   ```python
   # packages/my_plugin/src/nat/plugins/my_plugin/cli/commands.py
   import click

   @click.group(name="my-plugin", invoke_without_command=False, help="My plugin commands.")
   def my_plugin_command():
       """My plugin CLI commands."""
       return None

   @my_plugin_command.command(name="hello", help="Say hello")
   @click.option('--name', default='World', help='Name to greet')
   def hello(name: str):
       """Say hello to someone."""
       click.echo(f"Hello, {name}!")
   ```
<!-- path-check-skip-end -->

2. **Register the command via entry point** in your `pyproject.toml`:

   ```toml
   [project.entry-points.'nat.cli']
   my-plugin = "nat.plugins.my_plugin.cli.commands:my_plugin_command"
   ```

3. **Install your plugin** and the command will be automatically discovered:

   ```bash
   nat my-plugin hello --name Alice
   ```

#### CLI Plugin Discovery

When the `nat` CLI starts, it automatically discovers and loads CLI commands from all installed plugins using Python entry points. If a plugin package is not installed or has missing dependencies, the CLI will gracefully skip loading that plugin's commands without affecting other functionality.

#### Best Practices for CLI Plugins

- **Use descriptive command names** that clearly indicate their purpose
- **Provide helpful help text** for all commands and options
- **Handle errors gracefully** and provide clear error messages
- **Keep commands focused** on plugin-specific functionality
- **Follow Click conventions** for consistency with the core CLI
