<!--
SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

# Adding an LLM Provider to NVIDIA NeMo Agent Toolkit

In NeMo Agent Toolkit the set of configuration parameters needed to interact with an [LLM](../../build-workflows/llms/index.md) API (provider) is defined separately from the client which is tied to a given framework. To determine which LLM providers are included in the NeMo Agent Toolkit installation, run the following command:
```bash
nat info components -t llm_provider
```

In NeMo Agent Toolkit there are LLM providers, like NIM and OpenAI, and there are frameworks which need to use those providers, such as LangChain/LangGraph LlamaIndex with a client defined for each. To add support, we need to cover the combinations of providers to clients.

As an example, NeMo Agent Toolkit contains multiple clients for interacting with the OpenAI API with different frameworks, each sharing the same provider configuration {class}`nat.llm.openai_llm.OpenAIModelConfig`. To view the full list of clients registered for the OpenAI LLM provider, run the following command:

```bash
nat info components -t llm_client -q openai
```

## Provider Types

In NeMo Agent Toolkit, there are three provider types: `llm`, `embedder`, and `retriever`. The three provider types are defined by their respective base configuration classes: {class}`nat.plugin_api.LLMBaseConfig`, {class}`nat.plugin_api.EmbedderBaseConfig`, and {class}`nat.plugin_api.RetrieverBaseConfig`. This guide focuses on adding an LLM provider. However, the process for adding an [embedder](../../build-workflows/embedders.md) or [retriever](../../build-workflows/retrievers.md) provider is similar.


## Defining an LLM Provider
The first step to adding an LLM provider is to subclass the {class}`nat.plugin_api.LLMBaseConfig` class and add the configuration parameters needed to interact with the LLM API. Typically, this involves a `model_name` parameter and an `api_key` parameter; however, the exact parameters will depend on the API. The only requirement is a unique name for the provider.

Examine the previously mentioned {class}`nat.llm.openai_llm.OpenAIModelConfig` class:
```python
from nat.plugin_api import LLMBaseConfig

class OpenAIModelConfig(LLMBaseConfig, name="openai"):
    """An OpenAI LLM provider to be used with an LLM client."""

    model_config = ConfigDict(protected_namespaces=())

    api_key: str | None = Field(default=None, description="OpenAI API key to interact with hosted model.")
    base_url: str | None = Field(default=None, description="Base url to the hosted model.")
    model_name: str = Field(validation_alias=AliasChoices("model_name", "model"),
                            serialization_alias="model",
                            description="The OpenAI hosted model name.")
    temperature: float = Field(default=0.0, description="Sampling temperature in [0, 1].")
    top_p: float = Field(default=1.0, description="Top-p for distribution sampling.")
    seed: int | None = Field(default=None, description="Random seed to set for generation.")
    max_retries: int = Field(default=10, description="The max number of retries for the request.")
```

## Mixins

Mixins are used to add additional fields to the provider configuration without needing to subclass or add additional fields to the provider configuration explicitly. Additionally, the toolkit can use the mixins for validation and opt-in functionality.

### RetryMixin

The {class}`nat.data_models.retry_mixin.RetryMixin` is a mixin that adds a `max_retries` field to the provider config. The `max_retries` field is an integer that specifies the maximum number of retries for the request.

```python
from nat.data_models.retry_mixin import RetryMixin
from nat.plugin_api import LLMBaseConfig

class OpenAIModelConfig(LLMBaseConfig, RetryMixin, name="openai"):
    """An OpenAI LLM provider to be used with an LLM client."""

    model_config = ConfigDict(protected_namespaces=(), extra="allow")

    api_key: str | None = Field(default=None, description="OpenAI API key to interact with hosted model.")
    base_url: str | None = Field(default=None, description="Base url to the hosted model.")
    model_name: str = Field(validation_alias=AliasChoices("model_name", "model"),
                            serialization_alias="model",
                            description="The OpenAI hosted model name.")
    seed: int | None = Field(default=None, description="Random seed to set for generation.")
```

### Gated Field Mixins

Some configuration parameters are only valid for certain models or may be dependent on other parameters. The toolkit provides built-in mixins that automatically validate and default these parameters based on a specified field. For details on the mechanism, see [Gated Fields](./gated-fields.md).

- `ThinkingMixin`: adds a `thinking` field, with a default of `None` when supported by a model. If supported, the `thinking_system_prompt` property will return the system prompt to use for thinking.

:::{note}
The built-in mixins may reject certain fields for models that do not support them (for example, GPT-5 models currently reject `temperature` and `top_p`). Claude Sonnet 4.5 models currently reject `top_p`. If a gated field is explicitly set on an unsupported model, validation will fail.
:::

#### ThinkingMixin

The {class}`nat.data_models.thinking_mixin.ThinkingMixin` is a mixin that adds a `thinking` field to the provider config. The `thinking` field is a boolean that specifies whether to enable thinking for the model.

```python
from nat.data_models.thinking_mixin import ThinkingMixin
from nat.plugin_api import LLMBaseConfig

class NIMModelConfig(LLMBaseConfig, ThinkingMixin, name="nim"):
    """An NIM LLM provider to be used with an LLM client."""

    model_config = ConfigDict(protected_namespaces=(), extra="allow")

    api_key: str | None = Field(default=None, description="NIM API key to interact with hosted model.")
    base_url: str | None = Field(default=None, description="Base url to the hosted model.")
    model_name: str = Field(validation_alias=AliasChoices("model_name", "model"),
                            serialization_alias="model",
                            description="The NIM hosted model name.")

    # The following field is defined in the mixin:
    thinking: bool | None = Field(default=None, description="Whether to enable thinking for the model.")
    
    # The following property is then defined in the mixin based on the model_name:
    @property
    def thinking_system_prompt(self) -> str | None:
        ...
```

### Registering the Provider
An asynchronous function decorated with {py:deco}`nat.plugin_api.register_llm_provider` is used to register the provider with NeMo Agent Toolkit by yielding an instance of {class}`nat.plugin_api.LLMProviderInfo`.

:::{note}
Registering an embedder or retriever provider is similar; however, the function should be decorated with  {py:deco}`nat.plugin_api.register_embedder_provider` or  {py:deco}`nat.plugin_api.register_retriever_provider`.
:::


The `OpenAIModelConfig` from the previous section is registered as follows:
`packages/nvidia_nat_core/src/nat/llm/openai_llm.py`:
```python
from nat.plugin_api import Builder
from nat.plugin_api import LLMProviderInfo
from nat.plugin_api import register_llm_provider

@register_llm_provider(config_type=OpenAIModelConfig)
async def openai_llm(config: OpenAIModelConfig, builder: Builder):

    yield LLMProviderInfo(config=config, description="An OpenAI model for use with an LLM client.")
```

In the above example we didn't need to take any additional actions other than yielding the provider info. However, in some cases additional set up may be required, such as connecting to a cluster and performing validation could be performed in this method. In addition to this, any cleanup that needs to be done when the provider is no longer needed can be performed after the `yield` statement in the `finally` clause of a `try` statement. If this were needed we could update the above example as follows:
```python
from nat.plugin_api import Builder
from nat.plugin_api import LLMProviderInfo
from nat.plugin_api import register_llm_provider

@register_llm_provider(config_type=OpenAIModelConfig)
async def openai_llm(config: OpenAIModelConfig, builder: Builder):
    # Perform any setup actions here and pre-flight checks here raising an exception if needed
    try:
        yield LLMProviderInfo(config=config, description="An OpenAI model for use with an LLM client.")
    finally:
        # Perform any cleanup actions here
```

## LLM Clients
As previously mentioned, each LLM client is specific to both the LLM API and the framework being used. The LLM client is registered by defining an asynchronous function decorated with {py:deco}`nat.plugin_api.register_llm_client`. The `register_llm_client` decorator receives two required parameters: `config_type`, which is the configuration class of the provider, and `wrapper_type`, which identifies the framework being used.

:::{note}
Registering an embedder or retriever client is similar. However, the function should be decorated with {py:deco}`nat.plugin_api.register_embedder_client` or {py:deco}`nat.plugin_api.register_retriever_client`.
:::

The wrapped function in turn receives two required positional arguments: an instance of the configuration class of the provider, and an instance of {class}`nat.plugin_api.Builder`. The function should then yield a client suitable for the given provider and framework. The exact type is dictated by the framework itself and not by NeMo Agent Toolkit.

Since many frameworks provide clients for many of the common LLM APIs, in NeMo Agent Toolkit, the client registration functions are often simple factory methods. For example, the OpenAI client registration function for LangChain/LangGraph is as follows:

`packages/nvidia_nat_langchain/src/nat/plugins/langchain/llm.py`:
```python
from nat.plugin_api import Builder
from nat.plugin_api import LLMFrameworkEnum
from nat.plugin_api import register_llm_client

@register_llm_client(config_type=OpenAIModelConfig, wrapper_type=LLMFrameworkEnum.LANGCHAIN)
async def openai_langchain(llm_config: OpenAIModelConfig, builder: Builder):

    from langchain_openai import ChatOpenAI

    yield ChatOpenAI(**llm_config.model_dump(exclude={"type", "thinking"}, by_alias=True))
```

Similar to the registration function for the provider, the client registration function can perform any necessary setup actions before yielding the client, along with cleanup actions after the `yield` statement.

:::{note}
In the above example, the `ChatOpenAI` class is imported lazily, allowing for the client to be registered without importing the client class until it is needed. Thus, improving performance and startup times.
:::

## Test the Combination of LLM Provider and Client

After implementing a new LLM provider, it's important to verify that it works correctly with all existing LLM clients. This can be done by writing integration tests. Here's an example of how to test the integration between the NIM LLM provider and the LangChain/LangGraph framework:

```python
@pytest.mark.integration
@pytest.mark.usefixtures("nvidia_api_key")
async def test_nim_langchain_agent():
    """
    Test NIM LLM with LangChain/LangGraph agent. Requires NVIDIA_API_KEY to be set.
    """

    prompt = ChatPromptTemplate.from_messages([("system", "You are a helpful AI assistant."), ("human", "{input}")])

    llm_config = NIMModelConfig(model_name="meta/llama-3.1-70b-instruct", temperature=0.0)

    async with WorkflowBuilder() as builder:
        await builder.add_llm("nim_llm", llm_config)
        llm = await builder.get_llm("nim_llm", wrapper_type=LLMFrameworkEnum.LANGCHAIN)

        agent = prompt | llm

        response = await agent.ainvoke({"input": "What is 1+2?"})
        assert isinstance(response, AIMessage)
        assert response.content is not None
        assert isinstance(response.content, str)
        assert "3" in response.content.lower()
```

Note: Since this test requires an API key, it's requesting the `nvidia_api_key` fixture, which checks for the `NVIDIA_API_KEY` environment variable. If the variable is not set, the test will be skipped. Additionally, the test is marked with `@pytest.mark.integration` this indicates that the test might take longer to run and may require external resources. Tests marked with `integration` will only run when the `--run_integration` flag is provided to `pytest`, allowing the test to be excluded from CI runs. However, these tests are necessary for maintaining and verifying the functionality of LLM providers and their client integrations.

## Packaging the Provider and Client

The provider and client will need to be bundled into a Python package, which in turn will be registered with NeMo Agent Toolkit as a [plugin](../plugins.md). In the `pyproject.toml` file of the package the `project.entry-points.'nat.plugins'` section defines a Python module as the entry point of the plugin. Details on how this is defined are found in the [Entry Point](../plugins.md#entry-point) section of the plugins document. By convention, the entry point module is named `register.py`, but this is not a requirement.

In the entry point module it is important that the provider is defined first followed by the client, this ensures that the provider is added to the NeMo Agent Toolkit registry before the client is registered. A hypothetical `register.py` file could be defined as follows:
```python
# We need to ensure that the provider is registered prior to the client

import register_provider
import register_client
```
