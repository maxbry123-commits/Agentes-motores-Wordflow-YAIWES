# Adapt from https://github.com/NVIDIA/Megatron-LM/blob/b1efb3c7126ef7615e8c333432d76e08038e17ff/pretrain_gpt.py
import argparse
import inspect
import re
from contextlib import nullcontext
from typing import Literal

import torch
from megatron.core import tensor_parallel
from megatron.core.models.gpt import GPTModel
from megatron.core.models.gpt.gpt_layer_specs import (
    get_gpt_decoder_block_spec,
    get_gpt_layer_local_spec,
    get_gpt_layer_with_transformer_engine_spec,
)
from megatron.core.transformer.spec_utils import import_module
from megatron.core.transformer.transformer_config import TransformerConfig
from megatron.training.arguments import core_transformer_config_from_args

from slime.utils.misc import load_function


# Adapt from https://github.com/volcengine/verl/blob/c3b20575d2bc815fcccd84bddb4c0401fc4b632b/verl/models/llama/megatron/layers/parallel_linear.py#L82
class LinearForLastLayer(torch.nn.Linear):
    def __init__(
        self,
        input_size: int,
        output_size: int,
        *,
        config: TransformerConfig,
        bias: bool = True,
    ) -> None:
        super().__init__(in_features=input_size, out_features=output_size, bias=bias)
        self.sequence_parallel = config.sequence_parallel
        if self.sequence_parallel:
            self.weight.sequence_parallel = True
            if bias:
                self.bias.sequence_parallel = True

        self.weight.data.normal_(mean=0.0, std=0.02)
        if bias:
            self.bias.data.zero_()

    def forward(
        self,
        input_: torch.Tensor,
        weight: torch.Tensor | None = None,
        runtime_gather_output: bool | None = None,
    ) -> tuple[torch.Tensor, None]:
        logits = super().forward(input_)
        logits = logits.float()
        if self.sequence_parallel:
            logits = tensor_parallel.gather_from_sequence_parallel_region(logits, tensor_parallel_output_grad=False)
        return logits, None


def get_model_provider_func(
    args: argparse.Namespace,
    role: Literal["actor", "critic"] = "actor",
):
    # Support custom model provider path (similar to --custom-rm-path for reward models)
    if getattr(args, "custom_model_provider_path", None):

        def wrapped_model_provider(
            pre_process: bool = True, post_process: bool = True, vp_stage: int | None = None
        ) -> GPTModel:
            custom_model_provider = load_function(args.custom_model_provider_path)
            # Check if the custom provider supports vp_stage parameter
            has_vp_stage = "vp_stage" in inspect.signature(custom_model_provider).parameters
            if has_vp_stage:
                model = custom_model_provider(pre_process=pre_process, post_process=post_process, vp_stage=vp_stage)
            else:
                model = custom_model_provider(pre_process=pre_process, post_process=post_process)
            # Apply critic output layer if needed
            if post_process and role == "critic":
                model.output_layer = LinearForLastLayer(
                    input_size=model.config.hidden_size, output_size=1, config=model.config
                )
            return model

        return wrapped_model_provider

    if args.megatron_to_hf_mode == "bridge":
        bridge, hf_pretrained, is_local_bridge = load_function(
            "slime.utils.megatron_bridge_utils.build_bridge_for_hf_checkpoint"
        )(args.hf_checkpoint, load_weights=False)
        if is_local_bridge:
            provider = bridge.provider_bridge(hf_pretrained)
        else:
            provider = bridge.to_megatron_provider(load_weights=False)
        print(
            "Qwen35 bridge debug: "
            f"bridge={type(bridge).__module__}.{type(bridge).__name__} "
            f"provider={type(provider).__module__}.{type(provider).__name__} "
            f"is_local_bridge={is_local_bridge}"
        )
        # TODO: we should not manually set this...
        provider.tensor_model_parallel_size = args.tensor_model_parallel_size
        provider.pipeline_model_parallel_size = args.pipeline_model_parallel_size
        provider.expert_model_parallel_size = args.expert_model_parallel_size
        provider.expert_tensor_parallel_size = args.expert_tensor_parallel_size
        provider.sequence_parallel = args.sequence_parallel
        if getattr(args, "decoder_first_pipeline_num_layers", None) is not None:
            provider.num_layers_in_first_pipeline_stage = args.decoder_first_pipeline_num_layers
        if getattr(args, "decoder_last_pipeline_num_layers", None) is not None:
            provider.num_layers_in_last_pipeline_stage = args.decoder_last_pipeline_num_layers
        # Bridge providers are constructed from HF config and ignore most CLI flags
        # forwarded to TransformerConfig in the raw path. Activation-recompute is
        # the most consequential one: without it, full activations stay resident
        # for every layer and large-context RL runs OOM. Forward it explicitly so
        # bridge runs are at least memory-comparable to raw runs.
        # Qwen3-VL bridge providers with deepstack visual features cannot use
        # full-layer checkpointing: the upstream checkpoint path passes
        # deepstack_visual_embeds as list[Tensor] into save_for_backward().
        skip_full_recompute = (
            getattr(args, "recompute_granularity", None) == "full"
            and bool(getattr(provider, "deepstack_visual_indexes", None))
        )
        if skip_full_recompute:
            print(
                "Bridge provider: skipped full activation recompute for "
                f"{type(provider).__name__} with deepstack visual features"
            )
        elif getattr(args, "recompute_granularity", None) is not None:
            provider.recompute_granularity = args.recompute_granularity
            provider.recompute_method = args.recompute_method
            provider.recompute_num_layers = args.recompute_num_layers

        # CLI flags that materially affect train numerics/quality and per-step
        # speed but are NOT derivable from the HF config. Without these, bridge
        # mode silently keeps HF-config defaults (e.g. attention_dropout=0.1
        # for many Qwen configs), which causes train-vs-inference distribution
        # skew and biased GRPO importance sampling. Forward only attributes the
        # provider already exposes so we don't break providers that omit them.
        _BRIDGE_FORWARDED_ARGS = (
            # numerics / quality
            "attention_dropout",
            "hidden_dropout",
            "attention_softmax_in_fp32",
            
            "accumulate_allreduce_grads_in_fp32",
            "fp16_lm_cross_entropy",
            "cross_entropy_loss_fusion",
            "cross_entropy_fusion_impl",
            # kernels / fused ops (perf, occasionally numerics)
            "attention_backend",
            "apply_rope_fusion",
            "bias_swiglu_fusion",
            "bias_dropout_fusion",
            "bias_gelu_fusion",
            "masked_softmax_fusion",
            "gradient_accumulation_fusion",
            "async_tensor_model_parallel_allreduce",
            "tp_comm_overlap",
            # context-parallel / sequence-parallel related
            "context_parallel_size",
            # dtype / precision
            "params_dtype",
            "bf16",
            "fp16",
        )
        forwarded = []
        skipped = []
        for name in _BRIDGE_FORWARDED_ARGS:
            if not hasattr(args, name):
                continue
            value = getattr(args, name)
            if value is None:
                continue
            if not hasattr(provider, name):
                skipped.append(name)
                continue
            setattr(provider, name, value)
            forwarded.append((name, value))
        if forwarded:
            print(
                "Bridge provider: forwarded CLI flags -> "
                + ", ".join(f"{n}={v}" for n, v in forwarded)
            )
        if skipped:
            print(
                "Bridge provider: skipped CLI flags not exposed by provider -> "
                + ", ".join(skipped)
            )

        provider.finalize()
        return provider.provide

    def model_provider(pre_process: bool = True, post_process: bool = True, vp_stage: int | None = None) -> GPTModel:
        """Builds the model.

        If you set the use_legacy_models to True, it will return the legacy GPT model and if not the mcore GPT model.

        Args:
            pre_process (bool, optional): Set to true if you need to compute embedings. Defaults to True.
            post_process (bool, optional): Set to true if you need to want to compute output logits/loss. Defaults to True.


        Returns:
            Union[GPTModel, megatron.legacy.model.GPTModel]: The returned model
        """
        use_te = args.transformer_impl == "transformer_engine"

        # Experimental loading arguments from yaml
        config: TransformerConfig = core_transformer_config_from_args(args)

        if args.spec is not None:
            transformer_layer_spec = import_module(args.spec)
            # Allow the spec to be a function so that user can use customized Megatron easier.
            if callable(transformer_layer_spec):
                transformer_layer_spec = transformer_layer_spec(args, config, vp_stage)
        else:
            if args.num_experts:
                # Define the decoder block spec
                kwargs = {
                    "use_transformer_engine": use_te,
                }
                if vp_stage is not None:
                    kwargs["vp_stage"] = vp_stage
                transformer_layer_spec = get_gpt_decoder_block_spec(config, **kwargs)
            else:
                # Define the decoder layer spec
                if use_te:
                    transformer_layer_spec = get_gpt_layer_with_transformer_engine_spec(
                        num_experts=args.num_experts,
                        moe_grouped_gemm=args.moe_grouped_gemm,
                        qk_layernorm=args.qk_layernorm,
                        multi_latent_attention=args.multi_latent_attention,
                        moe_use_legacy_grouped_gemm=args.moe_use_legacy_grouped_gemm,
                    )
                else:
                    transformer_layer_spec = get_gpt_layer_local_spec(
                        num_experts=args.num_experts,
                        moe_grouped_gemm=args.moe_grouped_gemm,
                        qk_layernorm=args.qk_layernorm,
                        multi_latent_attention=args.multi_latent_attention,
                        moe_use_legacy_grouped_gemm=args.moe_use_legacy_grouped_gemm,
                    )

        build_model_context = nullcontext
        build_model_context_args = {}
        if args.fp8_param_gather:
            try:
                from transformer_engine.pytorch import fp8_model_init

                build_model_context = fp8_model_init
                build_model_context_args["enabled"] = True

                # Check if fp8_model_init supports preserve_high_precision_init_val
                if "preserve_high_precision_init_val" in inspect.signature(fp8_model_init).parameters:
                    build_model_context_args["preserve_high_precision_init_val"] = True
            except Exception as e:
                raise RuntimeError(
                    "--fp8-param-gather requires `fp8_model_init` from TransformerEngine, but not found."
                ) from e

        kwargs = {
            "config": config,
            "transformer_layer_spec": transformer_layer_spec,
            "vocab_size": args.padded_vocab_size,
            "max_sequence_length": args.max_position_embeddings,
            "pre_process": pre_process,
            "post_process": post_process,
            "fp16_lm_cross_entropy": args.fp16_lm_cross_entropy,
            "parallel_output": True,
            "share_embeddings_and_output_weights": not args.untie_embeddings_and_output_weights,
            "position_embedding_type": args.position_embedding_type,
            "rotary_percent": args.rotary_percent,
            "rotary_base": args.rotary_base,
            "rope_scaling": args.use_rope_scaling,
        }

        if vp_stage is not None:
            kwargs["vp_stage"] = vp_stage

        if args.mtp_num_layers:
            from megatron.core.models.gpt.gpt_layer_specs import get_gpt_mtp_block_spec

            mtp_kwargs = {
                "use_transformer_engine": use_te,
            }
            if vp_stage is not None:
                mtp_kwargs["vp_stage"] = vp_stage

            mtp_block_spec = get_gpt_mtp_block_spec(config, transformer_layer_spec, **mtp_kwargs)
            kwargs["mtp_block_spec"] = mtp_block_spec

        with build_model_context(**build_model_context_args):
            model = GPTModel(**kwargs)

        if post_process and role == "critic":
            model.output_layer = LinearForLastLayer(input_size=config.hidden_size, output_size=1, config=config)

        return model

    return model_provider


def wrap_model_provider_with_freeze(original_provider, args):
    def wrapped_provider(pre_process=True, post_process=True, vp_stage=None, **extra_kwargs):
        sig = inspect.signature(original_provider)
        provider_kwargs = {
            "pre_process": pre_process,
            "post_process": post_process,
        }
        if "vp_stage" in sig.parameters:
            provider_kwargs["vp_stage"] = vp_stage

        # Newer Megatron-LM may pass extra provider kwargs such as config.
        # Forward only the kwargs the wrapped provider actually declares.
        for name, value in extra_kwargs.items():
            if name in sig.parameters:
                provider_kwargs[name] = value

        model = original_provider(**provider_kwargs)

        freeze_model_params(model, args)

        return model

    return wrapped_provider


def freeze_model_params(model: GPTModel, args: argparse.Namespace):
    if args.only_train_params_name_list:
        for name, param in model.named_parameters():
            param.requires_grad = False
            for pattern in args.only_train_params_name_list:
                if re.search(pattern, name):
                    param.requires_grad = True
                    break

    if args.freeze_params_name_list:
        for name, param in model.named_parameters():
            for pattern in args.freeze_params_name_list:
                if re.search(pattern, name):
                    param.requires_grad = False
                    break
