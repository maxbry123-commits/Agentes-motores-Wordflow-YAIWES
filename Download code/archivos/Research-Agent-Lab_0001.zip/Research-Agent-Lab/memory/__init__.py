"""Memory stores and policies."""
