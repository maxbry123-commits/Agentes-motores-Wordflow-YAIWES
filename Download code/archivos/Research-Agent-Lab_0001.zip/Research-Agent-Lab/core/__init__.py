"""Core workflow primitives."""
