"""Tests for agent demo."""
