"""Code generation strategy implementations."""
