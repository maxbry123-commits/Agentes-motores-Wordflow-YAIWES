---
name: Feature Request
about: Suggest a new feature or improvement
title: "[Feature] "
labels: enhancement
---

**Problem**
What problem does this solve?

**Proposed Solution**
How should it work?

**Alternatives Considered**
Any other approaches you thought of?

**Additional Context**
Screenshots, links, or examples.
