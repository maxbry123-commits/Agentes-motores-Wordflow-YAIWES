"""Safari action package."""
