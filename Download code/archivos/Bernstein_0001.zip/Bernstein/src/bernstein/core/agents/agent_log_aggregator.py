"""Structured parsing and aggregation for agent session logs."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar


@dataclass(frozen=True)
class AgentLogEvent:
    """Structured event extracted from an agent log line."""

    timestamp: str
    level: str
    category: str
    message: str
    raw_line: str


@dataclass(frozen=True)
class AgentLogSummary:
    """Aggregated summary for an agent session log."""

    session_id: str
    total_lines: int
    events: list[AgentLogEvent]
    error_count: int
    warning_count: int
    files_modified: list[str]
    tests_run: bool
    tests_passed: bool
    test_summary: str
    rate_limit_hits: int
    compile_errors: int
    tool_failures: int
    first_meaningful_action_line: int
    last_activity_line: int
    dominant_failure_category: str | None


_TIMESTAMP_RE = re.compile(r"^\[?(?P<ts>\d{4}-\d{2}-\d{2}[ T][^\]\s]+)")


class AgentLogAggregator:
    """Parse and categorize agent runtime logs."""

    PATTERNS: ClassVar[list[tuple[str, re.Pattern[str]]]] = [
        ("rate_limit", re.compile(r"(?i)(rate.?limit|429|too many requests|overloaded)")),
        (
            "compile_error",
            re.compile(r"(?i)(syntax.?error|indentation.?error|name.?error|import.?error|module.?not.?found)"),
        ),
        ("test_failure", re.compile(r"(?i)(FAILED|ERROR|assert.*error|test.*fail)")),
        ("tool_failure", re.compile(r"(?i)(tool.?(call|use|execution).?fail|command.?not.?found|permission.?denied)")),
        ("git_error", re.compile(r"(?i)(merge.?conflict|rebase.?fail|cannot.?lock|worktree)")),
        ("timeout", re.compile(r"(?i)(timed?.?out|deadline.?exceeded)")),
        ("file_modified", re.compile(r"^(?:Modified|Created|Wrote|Updated):\s+\S+")),
    ]

    _ERROR_CATEGORIES: ClassVar[frozenset[str]] = frozenset(
        {"rate_limit", "compile_error", "test_failure", "tool_failure", "git_error", "timeout", "permission"}
    )
    _WARNING_PATTERN: ClassVar[re.Pattern[str]] = re.compile(r"(?i)\b(warn|warning|deprecated|retrying)\b")
    _TEST_SUMMARY_PATTERN: ClassVar[re.Pattern[str]] = re.compile(r"(?i)\b\d+\s+(?:passed|failed|skipped|error)")
    _MEANINGFUL_TOOLS: ClassVar[frozenset[str]] = frozenset({"pytest", "coverage", "ruff", "pyright"})
    _MEANINGFUL_FILE_OP: ClassVar[re.Pattern[str]] = re.compile(r"(?i)^(?:Modified|Created|Wrote|Updated):\s+\S+")
    _MEANINGFUL_TOOL_CMD: ClassVar[re.Pattern[str]] = re.compile(r"(?i)(?:uv run )?(?:pytest|coverage|ruff|pyright)\b")

    def __init__(self, workdir: Path) -> None:
        self._workdir = workdir

    def parse_log(self, session_id: str, log_path: str | Path | None = None) -> AgentLogSummary:
        """Parse a full session log into a structured summary.

        Args:
            session_id: Agent session id.
            log_path: Optional explicit log path (e.g. ``session.log_path``),
                preferred over the candidate-layout search when present and
                resolvable on disk (issue #3216).
        """
        resolved = self._resolve_log_path(session_id, log_path)
        if resolved is None:
            return self._empty_summary(session_id)
        try:
            lines = resolved.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return self._empty_summary(session_id)
        return self._summarize(session_id, lines)

    def parse_log_tail(self, session_id: str, last_line: int = 0) -> list[AgentLogEvent]:
        """Parse only new events after ``last_line`` (1-based)."""
        log_path = self._resolve_log_path(session_id)
        if log_path is None:
            return []
        try:
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return []
        events: list[AgentLogEvent] = []
        for line_no, raw_line in enumerate(lines, start=1):
            if line_no <= last_line:
                continue
            event = self._event_from_line(raw_line)
            if event is not None:
                events.append(event)
        return events

    def log_exists(self, session_id: str) -> bool:
        """Return whether the session log exists on disk."""
        log_path = self._resolve_log_path(session_id)
        return log_path is not None and log_path.exists()

    def log_age_s(self, session_id: str, now: float | None = None) -> float | None:
        """Return seconds since the session log was last written, or None.

        Uses the log file's mtime (bytes-written recency), NOT the newline
        count that ``parse_log`` tracks: a model streaming a single large turn
        (e.g. a 51k-char reasoning block with no newlines) keeps advancing the
        mtime while ``last_activity_line`` stays flat. This is the positive
        liveness signal the watchdog consults so a still-writing, non-heartbeat
        agent is not flagged stale on heartbeat age alone (issue #3012).

        Returns None when the log path cannot be resolved or is unreadable.
        """
        import time

        log_path = self._resolve_log_path(session_id)
        if log_path is None:
            return None
        try:
            mtime = log_path.stat().st_mtime
        except OSError:
            return None
        reference = time.time() if now is None else now
        return max(reference - mtime, 0.0)

    @staticmethod
    def _extract_unique_error_messages(error_events: list[AgentLogEvent], limit: int = 3) -> list[str]:
        """Extract up to *limit* unique error messages from events."""
        unique: list[str] = []
        for event in error_events:
            msg = event.message.strip()
            if msg and msg not in unique:
                unique.append(msg)
            if len(unique) >= limit:
                break
        return unique

    @staticmethod
    def _find_last_success(events: list[AgentLogEvent]) -> str:
        """Find the last successful action (file edit or passing test) in events."""
        for event in reversed(events):
            if event.category == "file_modified":
                return event.message
            if "pytest" in event.message.lower() and "passed" in event.message.lower():
                return event.message
        return ""

    def failure_context_for_retry(self, session_id: str) -> str:
        """Build a concise retry-context summary from a failed session log."""
        summary = self.parse_log(session_id)
        if not summary.events:
            return ""

        error_events = [event for event in summary.events if event.category in self._ERROR_CATEGORIES]
        if not error_events:
            return ""

        unique_messages = self._extract_unique_error_messages(error_events)
        last_success = self._find_last_success(summary.events)

        parts: list[str] = []
        if summary.dominant_failure_category:
            parts.append(f"Dominant failure: {summary.dominant_failure_category}.")
        if last_success:
            parts.append(f"Last successful action: {last_success}.")
        if unique_messages:
            parts.append("Top errors: " + " | ".join(unique_messages[:3]))

        text = " ".join(parts).strip()
        if len(text) <= 500:
            return text
        return text[:497].rstrip() + "..."

    def _resolve_log_path(self, session_id: str, log_path: str | Path | None = None) -> Path | None:
        """Resolve the most likely on-disk log path for a session.

        Prefers an explicit ``log_path`` (e.g. ``session.log_path``) when
        given and present on disk - the remote runtime bridge, container,
        and sandbox-session spawn paths all report their own log at
        ``<spawn_cwd>/.sdd/logs/<id>.log``, which no candidate layout below
        would ever find.

        Otherwise searches every worktree layout this codebase writes agent
        logs into (issue #3216), reusing
        :func:`bernstein.core.agents.agent_lifecycle._resolve_agent_worktree_dir`
        for the worktree-directory lookup - the same helper the reap tick's
        liveness probe uses - instead of reimplementing worktree-layout
        resolution.
        """
        if log_path:
            _explicit = log_path if isinstance(log_path, Path) else Path(log_path)
            if _explicit.exists():
                return _explicit

        from types import SimpleNamespace

        from bernstein.core.agents.agent_lifecycle import _resolve_agent_worktree_dir

        candidates = [
            self._workdir / ".sdd" / "runtime" / f"{session_id}.log",
            self._workdir / ".sdd" / "logs" / f"{session_id}.log",
        ]
        _wt_dir = _resolve_agent_worktree_dir(self._workdir, SimpleNamespace(id=session_id))
        if _wt_dir is not None:
            candidates.append(_wt_dir / ".sdd" / "runtime" / f"{session_id}.log")
            candidates.append(_wt_dir / ".sdd" / "logs" / f"{session_id}.log")
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return None

    def _process_log_line(
        self,
        raw_line: str,
        line_no: int,
        events: list[AgentLogEvent],
        files_modified: list[str],
        state: dict[str, Any],
    ) -> None:
        """Process a single log line, updating events and tracking state."""
        stripped = raw_line.strip()
        if stripped:
            state["last_activity_line"] = line_no
        if not state["first_action_line"] and (
            self._MEANINGFUL_FILE_OP.search(stripped) or self._MEANINGFUL_TOOL_CMD.search(stripped)
        ):
            state["first_action_line"] = line_no

        event = self._event_from_line(raw_line)
        if event is not None:
            events.append(event)
            if event.category == "file_modified":
                file_path = self._extract_modified_path(event.message)
                if file_path and file_path not in files_modified:
                    files_modified.append(file_path)

        if stripped and self._TEST_SUMMARY_PATTERN.search(stripped):
            state["test_summary"] = stripped

    @staticmethod
    def _compute_summary_stats(
        events: list[AgentLogEvent],
        error_categories: frozenset[str],
    ) -> tuple[int, int, str | None]:
        """Compute error/warning counts and dominant failure category."""
        error_events = [e for e in events if e.category in error_categories]
        warning_count = sum(1 for e in events if e.level == "warning")
        error_count = sum(1 for e in events if e.level == "error")
        dominant = None
        if error_events:
            dominant = Counter(e.category for e in error_events).most_common(1)[0][0]
        return error_count, warning_count, dominant

    def _summarize(self, session_id: str, lines: list[str]) -> AgentLogSummary:
        """Summarize raw log lines into counts and extracted events."""
        events: list[AgentLogEvent] = []
        files_modified: list[str] = []
        state: dict[str, Any] = {"test_summary": "", "first_action_line": 0, "last_activity_line": 0}

        for line_no, raw_line in enumerate(lines, start=1):
            self._process_log_line(raw_line, line_no, events, files_modified, state)

        test_summary: str = state["test_summary"]
        error_count, warning_count, dominant = self._compute_summary_stats(events, self._ERROR_CATEGORIES)
        tests_run = bool(test_summary) or any("pytest" in line.lower() for line in lines)
        tests_passed = tests_run and "failed" not in test_summary.lower() and "error" not in test_summary.lower()

        return AgentLogSummary(
            session_id=session_id,
            total_lines=len(lines),
            events=events,
            error_count=error_count,
            warning_count=warning_count,
            files_modified=files_modified,
            tests_run=tests_run,
            tests_passed=tests_passed,
            test_summary=test_summary,
            rate_limit_hits=sum(1 for e in events if e.category == "rate_limit"),
            compile_errors=sum(1 for e in events if e.category == "compile_error"),
            tool_failures=sum(1 for e in events if e.category == "tool_failure"),
            first_meaningful_action_line=state["first_action_line"],
            last_activity_line=state["last_activity_line"],
            dominant_failure_category=dominant,
        )

    def _event_from_line(self, raw_line: str) -> AgentLogEvent | None:
        """Convert one log line to a structured event when recognized."""
        stripped = raw_line.strip()
        if not stripped:
            return None

        timestamp = self._extract_timestamp(stripped)
        category = "unknown"
        for name, pattern in self.PATTERNS:
            if pattern.search(stripped):
                category = name
                break

        if category == "unknown" and not self._WARNING_PATTERN.search(stripped):
            return None

        level = self._level_for_line(stripped, category)
        return AgentLogEvent(
            timestamp=timestamp,
            level=level,
            category=category,
            message=stripped,
            raw_line=raw_line,
        )

    def _extract_timestamp(self, line: str) -> str:
        """Extract a leading timestamp when present."""
        match = _TIMESTAMP_RE.match(line)
        return match.group("ts") if match else ""

    def _level_for_line(self, line: str, category: str) -> str:
        """Map a raw line/category pair to a log level."""
        lowered = line.lower()
        if category == "file_modified":
            return "progress"
        if category in self._ERROR_CATEGORIES or "traceback" in lowered or "exception" in lowered:
            return "error"
        if self._WARNING_PATTERN.search(line):
            return "warning"
        return "info"

    def _extract_modified_path(self, message: str) -> str:
        """Extract a modified file path from a structured message."""
        if ": " not in message:
            return ""
        return message.split(": ", 1)[1].strip()

    def _empty_summary(self, session_id: str) -> AgentLogSummary:
        """Return an all-zero summary for a missing or empty log."""
        return AgentLogSummary(
            session_id=session_id,
            total_lines=0,
            events=[],
            error_count=0,
            warning_count=0,
            files_modified=[],
            tests_run=False,
            tests_passed=False,
            test_summary="",
            rate_limit_hits=0,
            compile_errors=0,
            tool_failures=0,
            first_meaningful_action_line=0,
            last_activity_line=0,
            dominant_failure_category=None,
        )
