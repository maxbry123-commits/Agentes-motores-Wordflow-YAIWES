"""Template loading and rendering."""
