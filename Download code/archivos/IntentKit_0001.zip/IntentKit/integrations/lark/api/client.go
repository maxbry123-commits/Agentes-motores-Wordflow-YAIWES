package api

import (
	"context"
	"fmt"
	"time"

	"github.com/crestalnetwork/intentkit/integrations/shared"
	"resty.dev/v3"
)

type Client struct {
	client  *resty.Client
	baseURL string
}

func NewClient(baseURL string) *Client {
	return &Client{
		client:  resty.New().SetTimeout(10 * time.Minute),
		baseURL: baseURL,
	}
}

// StreamTeamLead calls the /core/lead/stream endpoint with SSE streaming.
func (c *Client) StreamTeamLead(ctx context.Context, payload map[string]interface{}, cb shared.StreamCallback) error {
	return shared.StreamRequest(ctx, c.baseURL, "/core/lead/stream", payload, cb)
}

// SetChannelConfig upserts a team channel's config (the OAuth install result).
// createdBy attributes the install to the team admin who authorized it.
func (c *Client) SetChannelConfig(ctx context.Context, teamID, channelType string, config map[string]any, createdBy string) error {
	resp, err := c.client.R().
		SetContext(ctx).
		SetBody(map[string]interface{}{
			"team_id":      teamID,
			"channel_type": channelType,
			"config":       config,
			"created_by":   createdBy,
		}).
		Post(c.baseURL + "/core/lead/set-channel-config")
	if err != nil {
		return fmt.Errorf("set channel config: %w", err)
	}
	if resp.StatusCode() != 200 {
		return fmt.Errorf("set channel config: status %d", resp.StatusCode())
	}
	return nil
}

// SetPushChannel sets (or conditionally sets) the push channel for a team.
func (c *Client) SetPushChannel(ctx context.Context, teamID, channelType, chatID string, ifEmpty bool) error {
	resp, err := c.client.R().
		SetContext(ctx).
		SetBody(map[string]interface{}{
			"team_id":      teamID,
			"channel_type": channelType,
			"chat_id":      chatID,
			"if_empty":     ifEmpty,
		}).
		Post(c.baseURL + "/core/lead/set-push-channel")
	if err != nil {
		return fmt.Errorf("set push channel: %w", err)
	}
	if resp.StatusCode() != 200 {
		return fmt.Errorf("set push channel: status %d", resp.StatusCode())
	}
	return nil
}
