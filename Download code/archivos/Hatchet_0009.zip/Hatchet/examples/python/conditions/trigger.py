import time

from examples.conditions.worker import hatchet, task_condition_workflow

task_condition_workflow.run(wait_for_result=False)

time.sleep(5)

hatchet.event.push("skip_on_event:skip", {})
hatchet.event.push("wait_for_event:start", {})
