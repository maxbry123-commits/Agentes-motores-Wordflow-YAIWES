-- name: GetDAGData :many
WITH input AS (
    SELECT
        unnest(@dagIds::bigint[]) AS dag_id,
        unnest(@dagInsertedAts::timestamptz[]) AS dag_inserted_at
)
SELECT dd.*, d.desired_worker_labels, d.external_id
FROM v1_dag d
JOIN v1_dag_data dd ON (d.id, d.inserted_at) = (dd.dag_id, dd.dag_inserted_at)
WHERE (d.id, d.inserted_at) IN (
    SELECT dag_id, dag_inserted_at
    FROM input
);

-- name: CreateDAGs :many
WITH input AS (
    SELECT
        unnest(@tenantIds::uuid[]) AS tenant_id,
        unnest(@externalIds::uuid[]) AS external_id,
        unnest(@displayNames::text[]) AS display_name,
        unnest(@workflowIds::uuid[]) AS workflow_id,
        unnest(@workflowVersionIds::uuid[]) AS workflow_version_id,
        unnest(@parentTaskExternalIds::uuid[]) AS parent_task_external_id,
        unnest(@desiredWorkerLabels::jsonb[]) AS desired_worker_labels,
        unnest(@idempotencyKeys::text[]) AS idempotency_keys
)
INSERT INTO v1_dag (
    tenant_id,
    external_id,
    display_name,
    workflow_id,
    workflow_version_id,
    parent_task_external_id,
    desired_worker_labels,
    idempotency_key
)
SELECT
    i.tenant_id,
    i.external_id,
    i.display_name,
    i.workflow_id,
    i.workflow_version_id,
    NULLIF(i.parent_task_external_id, '00000000-0000-0000-0000-000000000000'::uuid),
    i.desired_worker_labels,
    NULLIF(i.idempotency_keys, '')
FROM
    input i
RETURNING
    *;

-- name: CreateDAGData :copyfrom
INSERT INTO v1_dag_data (
    dag_id,
    dag_inserted_at,
    input,
    additional_metadata
) VALUES (
    $1,
    $2,
    $3,
    $4
);
