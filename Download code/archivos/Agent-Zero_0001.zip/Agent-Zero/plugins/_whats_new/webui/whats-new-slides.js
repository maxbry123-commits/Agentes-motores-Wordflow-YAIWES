export const slides = [];
