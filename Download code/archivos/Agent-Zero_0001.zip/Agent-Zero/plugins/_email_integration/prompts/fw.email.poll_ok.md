email poll complete: {{result}}
