"""Chat naming API handlers."""
