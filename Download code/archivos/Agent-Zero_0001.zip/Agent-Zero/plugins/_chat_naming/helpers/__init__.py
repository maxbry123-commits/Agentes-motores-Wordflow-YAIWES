"""Chat naming helpers."""
