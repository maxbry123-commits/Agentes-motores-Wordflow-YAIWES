from helpers.tool import Tool, Response
from plugins._memory.helpers.memory import Memory

DEFAULT_THRESHOLD = 0.7
DEFAULT_LIMIT = 10


class MemoryLoad(Tool):

    async def execute(self, query="", threshold=DEFAULT_THRESHOLD, limit=DEFAULT_LIMIT, filter="", **kwargs):
        if threshold is None or threshold == "":
            threshold = DEFAULT_THRESHOLD
        if limit is None or limit == "":
            limit = DEFAULT_LIMIT
        threshold = float(threshold)
        limit = int(limit)

        db = await Memory.get(self.agent)
        docs = await db.search_similarity_threshold(query=query, limit=limit, threshold=threshold, filter=filter)

        if len(docs) == 0:
            result = self.agent.read_prompt("fw.memories_not_found.md", query=query)
        else:
            text = "\n\n".join(Memory.format_docs_plain(docs))
            result = str(text)

        return Response(message=result, break_loop=False)
