from helpers.tool import Tool, Response
from plugins._memory.helpers.memory import Memory

from plugins._memory.tools.memory_load import DEFAULT_THRESHOLD


class MemoryForget(Tool):

    async def execute(self, query="", threshold=DEFAULT_THRESHOLD, filter="", **kwargs):
        db = await Memory.get(self.agent)
        dels = await db.delete_documents_by_query(
            query=query,
            threshold=threshold,
            filter=filter,
            include_exact=True,
            cascade=True,
        )

        result = self.agent.read_prompt("fw.memories_deleted.md", memory_count=len(dels))
        return Response(message=result, break_loop=False)
