import { NextResponse } from 'next/server'
import { ensureGatewayConnected } from '@/lib/server/openclaw/gateway'
import { errorMessage } from '@/lib/shared-utils'
import { safeParseBody } from '@/lib/server/safe-parse-body'

/** POST { name, installId, timeoutMs? } — install a skill via gateway */
export async function POST(req: Request) {
  const { data: body, error } = await safeParseBody<Record<string, unknown>>(req)
  if (error) return error
  const { name, installId, timeoutMs } = body as {
    name?: string
    installId?: string
    timeoutMs?: number
  }
  if (!name) {
    return NextResponse.json({ error: 'Missing skill name' }, { status: 400 })
  }

  const gw = await ensureGatewayConnected()
  if (!gw) {
    return NextResponse.json({ error: 'Gateway not connected' }, { status: 503 })
  }

  try {
    const result = await gw.rpc('skills.install', {
      name,
      installId,
      timeoutMs: timeoutMs ?? 120_000,
    }, (timeoutMs ?? 120_000) + 5_000)
    return NextResponse.json({
      ok: true,
      result,
      audit: {
        status: 'warn',
        findings: [{
          severity: 'warning',
          code: 'gateway_managed_install',
          message: 'Install was delegated to the gateway. Local static audit is not available for this package.',
        }],
      },
    })
  } catch (err: unknown) {
    const message = errorMessage(err)
    return NextResponse.json({ error: message }, { status: 502 })
  }
}
