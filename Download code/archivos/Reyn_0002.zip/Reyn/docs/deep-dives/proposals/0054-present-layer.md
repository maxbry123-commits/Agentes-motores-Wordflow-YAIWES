# Present layer — user-facing presentation of bulk data without LLM token round-trip

**Author:** architect · **Status:** IMPLEMENTED 2026-07-08 (v1, display-only). Arc
landed: PR-A #2658 (op core), PR-B #2661 (renderer + Option-B guard), PR-C #2664
(registry + 4-stage fallback), PR-D #2665 (replay/rewind + concept/reference docs +
feature-map). Non-blocking follow-ups: #2655 (renderer width), #2656 (offload
shape-summary), #2663 (offload content_type for declared-type routing). · **Date:**
2026-07-08

## Problem

When an agent obtains external data via a tool and shows it to the user, the data today
always round-trips through LLM tokens. Splitting the cost into axes:

| Axis | Cost | Status |
|---|---|---|
| **A. Ingestion (input)** | tool result entering LLM context | **Solved** by the offload mechanism + tool-result-schema-redesign arc (`docs/deep-dives/proposals/0053-tool-result-schema-redesign.md`, IMPLEMENTED): data lands in a ref file, the LLM sees schema + preview, reads back on demand via `read_file` |
| **B. Reproduction (output)** | the LLM re-types the data as output tokens to show the user | **Unsolved — target of this proposal** |
| **C. Fidelity loss** | to fit output, the LLM summarizes/truncates; the user loses data | **Unsolved — same mechanism solves it** |

The offloaded ref file is *already* "data file + handle". What is missing is a primitive
that routes that handle plus a display template to the user-facing surface directly, so
the bulk bytes never pass through LLM output.

Two existing reyn mechanisms are each half of the answer, currently unconnected:

1. **Offload** (redesign arc, landed) — the offload refs are the data handles.
   Structured stream: an inline `structured` frontmatter field, or when offloaded
   `structured: offloaded` + `structured_ref` (a `read_file`-able path) +
   `structured_preview`. Text stream: the body text, or when offloaded a plain-text note
   `...[truncated: <N> chars total — full body: read_file(path="<ref>")]...` (no
   dedicated frontmatter field for the text ref). Saves input tokens only; presentation
   still goes through output tokens.
2. **Tool-result viewer registry + LLM template** (FP-0051,
   `docs/deep-dives/proposals/0051-tool-result-viewer-registry-llm-template.md`) —
   content-type → viewer → Rich renderable, with a safety-fenced LLM-generated template
   fallback. **Status (confirmed 2026-07-08, docs-maintainer exhaustive grep):**
   FP-0051 is **superseded** — the Textual TUI (right panel included) and the entire
   viewer-registry module (`register_viewer` / `render_tool_result` / content-type
   dispatch) were **deleted with no relocation**. The current terminal UI is the
   **inline-CUI** (`src/reyn/interfaces/inline/`), whose only tool-result rendering is
   `summarize_tool_result` — a **single-line summary with no content-type dispatch and
   no rich rendering**. FP-0051's *design* (predicate registry, template fence, escape
   idioms, fallback chain) remains the lineage this proposal draws on, but there is **no
   live rendering surface to generalize — it is rebuilt fresh.**

**This sharpens the problem.** Today bulk tool data reaches the user via exactly two
paths: a `summarize_tool_result` one-liner (maximal fidelity loss) or full LLM output
reproduction (maximal token cost). Axis B and C are not merely suboptimal — the rich
middle ground does not currently exist at all.

This proposal introduces that middle ground: a `present` op (Control IR) + a
surface-agnostic presentation model, building rich, cross-surface presentation fresh on
the inline-CUI, along the FP-0051 design lineage.

## Standards landscape (2026) and the architectural choice

The agent-UI presentation problem has crystallized into a protocol layer industry-wide.
Two fundamental approaches:

| | **MCP Apps** (Anthropic + OpenAI + MCP-UI, 2026-01) | **A2UI v1.0** (Google, Candidate) |
|---|---|---|
| Mechanism | tool declares `ui://` resource → host renders bundled HTML/JS in sandboxed iframe; tool-result data flows to the iframe directly, bypassing LLM tokens | agent emits a **declarative component blueprint** (no code); data bound by **JSON Pointer (RFC 6901)** paths; `updateComponents` (structure) and `updateDataModel` (data) are separate messages |
| Security | executable-but-sandboxed (iframe + JSON-RPC audit) | **non-executable by construction** — catalog components + path bindings only |
| Terminal-renderable | ❌ impossible (no iframe in a terminal) | ✅ abstract components map to any surface |

Related: AG-UI (CopilotKit) is the transport pipe (typed SSE events), complementary to
either. Vercel Generative UI routes `toolName → pre-built component`; the model never
generates UI code.

**Decision (owner-approved): approach = declarative blueprint, architecture = hub-and-spoke
"option C".** The internal model is reyn-native but **structurally isomorphic to A2UI**
(declarative component tree · path-based data binding · vetted non-executable catalog).
Rationale:

1. The terminal (inline-CUI) is reyn's first-class surface; the iframe-webapp approach
   cannot reach it.
2. "Non-executable by construction" is the same philosophy as reyn's structural
   write-gate: safety from the primitive's *shape*, not from policy layered on top.
   FP-0051's template fence (LLM picks labels + key names only, allowlist + double
   escape) is already this shape.
3. Isomorphism keeps future wire adapters thin — external A2UI / MCP Apps emit
   (`reyn mcp serve` / A2A producer side) and ingest (reyn-as-MCP-host consumer side)
   become boundary adapters — while keeping internal contracts sovereign and insulated
   from a still-Candidate external spec.

```
   internal surfaces            hub                       boundary adapters (future)
  inline-CUI / web / A2A ◀── present op + declarative ──▶  A2UI / MCP-Apps emit (producer)
  (know nothing of A2UI)      model + renderers        ──▶  A2UI / MCP-UI ingest (consumer)
```

Wire-level protocol conformance is explicitly deferred until the standards stabilize;
only the internal *shape* is aligned now.

## Design principles (invariants)

1. **LLM sees shape, not content; the user sees everything.** The LLM works from the
   offload schema + preview and binds paths; the renderer joins the template against the
   full data the LLM never ingested. This asymmetry is the designed contract, not a
   defect.
2. **Display is free; computation costs.** Presenting N rows costs ~0 LLM tokens. The
   moment the agent must *transform* the data (sort, filter, answer questions about it),
   it pays to read the ref. Documented so the asymmetry is never mistaken for a bug.
3. **Declarative, never executable.** Templates are catalog components + path bindings.
   No markup, no HTML, no code ever crosses from LLM to renderer.
4. **Degrade, don't fail; degradation is audited.** Binding misses soft-skip per
   binding; drops are recorded in the audit event; full miss falls back to the generic
   viewer. A broken template can never lose the user's access to the data (the ref
   remains readable).
5. **Audit-first.** Every presentation emits a P6 event carrying refs and stats — never
   content bytes (data is already durable in the ref file; events stay light).

## Design

### 1. `present` op (Control IR)

```yaml
present:
  data_ref: <path>            # XOR data_inline; any zone-readable file
  data_inline: <small dict>   # optional convenience for small already-in-context data
  template: <registered name> # XOR blueprint
  blueprint: <inline declarative component tree with path bindings>
```

- **Tier 0** (`ask_user`'s sibling): presenting to the user is not an exfiltration
  channel — the user is the trust root. The only gate: **`data_ref` read authority is
  resolved identically to `file.read`** — `present` can never read more than the agent's
  file ops can. Not limited to tool-result refs: artifacts, agent-written files, any
  zone-readable path qualifies (works even with `offload.enabled: false`).
- **`data_ref` resolution seam (junction with the tool-result arc).** A `data_ref` may
  be a plain workspace path *or* an offload ref (e.g. a `structured_ref` produced by the
  arc). `present` resolves it by loading the **full value** through the same file-read /
  offload-store access the arc established (`read_file(path=<ref>)` semantics), under
  the `file.read` authority check above — i.e. present re-hydrates offloaded structured
  data from `structured_ref` rather than from the LLM-visible preview. The resolver is a
  single explicit seam (`resolve_present_source(data_ref) -> bytes|obj`), so the two arcs
  meet at exactly one point and offloaded vs inline data is transparent to the renderer.
- **Fire-and-continue**: unlike `ask_user`, does not pause the run.
- **Op result (ack)** — the LLM's only feedback, deliberately compact **and high-signal**
  (same principle as the tool-result arc): each drop carries a *reason category* so the
  next-turn LLM can act, not just a bare path list.
  ```yaml
  ok: true
  bindings_resolved: 3
  rows: 500
  bindings_dropped:
    - {path: "/results/0/author", reason: path_not_found}   # template/data shape mismatch
    # reason ∈ {path_not_found, type_mismatch, guard_stripped}
  ```
  This closes the self-correction loop for blind presentation: `path_not_found` across
  many rows reads as "template doesn't match this data shape → re-check"; `type_mismatch`
  as "right path, wrong component"; `guard_stripped` as "content neutralized by the
  presentation-guard, not a template bug". The LLM corrects for tens of tokens without
  ingesting the data.
- New op kind ⇒ **`OP_KIND_MODEL_MAP` + `docs/reference/runtime/control-ir.md` section
  in the same PR** (CLAUDE.md hard rule #1983).

### 2. Declarative UI model (v1 catalog — display-only)

Component catalog, all read-only:

| Component | Binding slots |
|---|---|
| `text` / `markdown` | `text` (bind or literal) |
| `code` | `text`, `language?` |
| `diff` | `text` |
| `keyvalue` (card) | `rows: [{label, value: bind}]` |
| `table` | `rows: <bind → array>`, `columns: [{header, path (row-relative)}]` |
| `list` | `items: <bind → array>`, optional per-item template |
| `image` | routes to the existing multimodal delivery path |

- Bindings are **JSON Pointer (RFC 6901)**; table/list column paths resolve relative to
  the iterated row. Structured refs → pointer bindings; plain-text refs → whole-body
  binding into text-family components (`text`/`code`/`diff`/`markdown`) only.
- **v1 is display-only: no interactive components** (no buttons, no forms). UI-spoofing
  (fake consent dialogs etc.) only becomes harmful with interactivity; MCP Apps spends
  its sandbox complexity there. reyn avoids the class structurally. Interactivity is v2,
  and must route through the existing intervention bus (the consent path) when it comes.
  **← the one headline owner decision this doc requests.**

### 3. Template sources — 4-stage fallback

```
registered template (operator-owned) → inline blueprint (LLM-authored, catalog-constrained)
  → default blueprint synthesized from data shape → generic (always renders)
```

- Named templates live in **`.reyn/config/presentations.yaml`** — same registration +
  hot-reload-seam pattern as `skills.entries` / `pipelines.entries`. Registering named
  templates is an **operator/config action**; the LLM authors inline blueprints only
  (write-gate culture).
- Inline blueprints are structurally gated at op validation: catalog components only,
  path-expression bindings only. Leaf safety is the single guard seam + markup-inert
  renderer discipline (§ 5) — **not** parse-time escaping (removed in the PR-A/PR-B
  Option-B revision).
- **Stage 3 (default synthesis).** Build a **default declarative blueprint from the
  resolved data** and run the **same** validate → resolve-bindings → render path — reusing
  the guard, caps, and non-executable rails (better than a bespoke per-type viewer; the
  FP-0051 registry is deleted). Component-choice precedence (FP-0051 order: explicit type
  first, sniff/shape last):
  1. **Declared content-type — only when available from inline data / explicit op args,
     NOT from an offload ref.** The canonical mapper drops `content_type`/`mimeType` as
     transport (high-signal-only frontmatter — authoritatively confirmed by the mapper's
     author). When present: `text/x-diff`\|`text/x-patch`→`diff`, declared language→`code`,
     `text/markdown`→`markdown`.
  2. **Cheap diff content-sniff** (FP-0051 heuristic: `diff --git` / `--- `+`+++ ` / `@@ `)
     → `diff`. Makes the `diff` component default-reachable without a declared type.
  3. **Structural shape**: `list[dict]`→`table` (columns = union over the first K rows),
     `list[scalar]`→`list`, `dict`→`keyvalue` (row per top-level key), `str`/scalar→**`text`**
     (**not** `markdown` — faithful display; `markdown` reinterprets `#`/`*`/`[]()` and
     mangles plain output), binary→`image` (image mimetype) or a `text` placeholder.
- **Stage 4 (generic)** is the final catch that **always renders** — structured → YAML into
  a `text`/`code` component, text → as-is — so data always reaches the user.
- **Fallback triggers**: all-bindings-missed **or** unknown-template-name (never a hard
  error). The ack reports the **requested** stage's stats plus a `note` naming the stage
  that actually rendered, so the LLM self-corrects; the `presented` event shape is
  unchanged (§§ 1, 7).
- **Follow-up (non-blocking, sibling of #2656)**: preserving `content_type` for offloaded
  data would give present declared-type routing for free — enabling default
  markdown-rendering and code-highlighting that shape + diff-sniff cannot infer. Deferred;
  PR-C completes with sniff + shape. Design nuance for whoever takes it: `content_type` is
  *renderer* signal, not LLM-next-action signal, so it should reach present without
  bloating the LLM-visible high-signal frontmatter.

### 4. Binding semantics

- Path hit → bind (escape at render, per surface).
- Path miss → **soft-skip that binding/component**, record in `bindings_dropped`.
- Type mismatch → renderer coercion rules (scalar into table binding → 1 row; etc.).
- All bindings miss → fall back to generic viewer; never a hard failure.

### 5. Presentation-guard (output seam)

Mirror of the input-side content-guard, at the output boundary:

Two responsibilities, at two layers (the split that empirical Rich testing forced — a
uniform "escape everything" guard corrupts markup-inert sinks):

- **Guard (surface-universal, sink threat) — the output seam.** Neutralize the threats
  that are dangerous to a surface regardless of which render component receives the
  content. Runs **unconditionally**, including (and especially) for never-ingested data,
  and applies to **every** render-leaf string (label, literal, and bound value) at one
  seam — never split "escape labels at parse / neutralize bound values at bind", which
  leaves literal strings unguarded.
  - **Terminal (v1, inline-CUI / Rich):** *strip* control / ESC sequences — the real,
    sink-level terminal threat (OSC / CSI, notably OSC-52 clipboard). That is the guard's
    **whole** terminal job. **No HTML-escaping** (a `<div>` is inert literal text in a
    terminal; HTML-escaping would corrupt `<`/`>`/`&` in `code`/`diff`, a category
    error), and **no Rich-markup escaping** (see the renderer layer below — it is not a
    surface-universal threat).
  - **Web (future):** HTML/JS escaping is *this* surface's guard neutralizer, shipped
    with the web renderer — never applied on the terminal path. Structuring the guard
    per-surface (even with one surface in v1) lets the web strategy plug in without
    touching the core (§ 6 per-surface boundary; structural write-gate).
- **Renderer discipline (per-component, render-API safety) — PR-B.** Rich console markup
  (`[red]…[/]`) is **not** a surface-universal threat: it is a Rich-library concept, and
  only `console.print(markup=True)` interprets it — `Text` and `Syntax` are markup-inert,
  and `Markdown` treats `[red]` as inert literal text (CommonMark). So Rich-markup-safety
  is the **renderer's** responsibility, achieved *structurally* rather than by escaping:
  the renderer routes every untrusted leaf to a markup-inert sink (`Text` / `Syntax`) or
  to `Markdown`, and **never** calls `console.print(markup=True)` on leaf content. Rich-
  markup injection is then structurally impossible with **no escape/unescape anywhere** —
  which also removes the fragile guard-regex coupling and the corner case where data
  containing a literal `\[red]` would be mangled by an unescape pass. (Empirically
  verified by tui-coder; corrects an earlier draft that escaped Rich markup in the guard.)
- **Per-binding size caps** — prevents `/` (root) bound into a `text` component from
  dumping an entire file.
- **Default output cap (present-specific — not a scrollback pager).** The inline-CUI
  convention (confirmed with tui-coder) is that conversation output flows freely into
  terminal scrollback *uncapped*, because normal output is already bounded by LLM
  *output tokens*. `present` is unbounded by construction (that is the whole point), so
  it must carry its **own** default cap: render head-N rows/lines + a
  `…N more — full data: <ref>` tail. **Cap before render, not after** (tui-coder review) —
  for `code`/`diff`, Rich syntax highlighting is costly, so truncate the source to the
  row/line budget first and highlight only the survivors. There is no pager in the
  inline-CUI; the **ref is the full-fidelity escape hatch** (re-present with a
  filter/higher cap, or `read_file`).
  This bound is orthogonal to the inline-CUI's live-region caps
  (`_ABOVE_REGION_MAX_HEIGHT` / `_MENU_REGION_MAX_HEIGHT` = 12), which govern persistent
  UI regions, not one-shot conversation output.

### 6. Renderers and surfaces

- `PresentationRenderer` protocol — **built fresh** (the FP-0051 registry was deleted,
  not relocated; its design is the lineage, not a base to extend). Terminal (inline-CUI)
  = **Rich** (confirmed with tui-coder); web = native components; A2A = structured
  message part.
- **Terminal note (confirmed with tui-coder 2026-07-08).** The terminal UI is the
  inline-CUI (`src/reyn/interfaces/inline/`, prompt_toolkit + Rich) — the Textual TUI and
  right panel were deleted in `eff08169`; there is no side panel (the model is elastic
  Regions above / below the input bar). Its only tool-result rendering today is
  `summarize_tool_result` (a one-liner). `present` renders as a **one-shot inline block
  in the conversation scrollback**, riding the existing `repl/renderer.py` pattern: Rich
  `Console` → `StringIO` → `prompt_toolkit.run_in_terminal()` print. This axis is
  separate from the live-region line caps; the present-specific default output cap (§ 5)
  applies instead.
- **Explicit render width (tui-coder review).** Rich's `Console` cannot auto-detect
  terminal width when writing to a `StringIO`; it silently falls back to 80 columns — a
  latent bug already in `repl/renderer.py`'s two existing render sites, and more visible
  for `present` tables. The renderer must read `get_app().output.get_size().columns` and
  pass it explicitly to `Console(width=...)` per render. (Fixing the two existing sites
  is a worthwhile fast-follow, tracked as issue #2655 — not in this proposal's scope.)
- **Remote surfaces (web/A2A)**: remote clients cannot read local refs. Data delivery is
  the surface adapter's responsibility: materialize via the gateway (size-capped inline
  embed or a served endpoint). v1 ships the terminal (inline-CUI) surface only; the hub
  model records this contract
  now so remote phases don't warp the core.

### 7. Audit — `presented` event (P6)

```yaml
presented:
  data_ref: <path>            # or inline-data marker
  template: <name | inline blueprint hash>
  surface: [inline-cui]
  ingested: none | partial | full   # OS-COMPUTED, not LLM-self-reported
  bindings_resolved: 3
  bindings_dropped: [{path: "/results/0/author", reason: path_not_found}]
```

**Blind-routing is not a permission mode — it is an audit annotation.** Whether the LLM
read the data before presenting is a fact the OS can compute (result was inline, or a
`read_file(ref)` appears earlier in the session). No config gate in v1; the guard runs
regardless; audit records the fact. (The standards world routes blind as the norm; reyn's
differentiator is making blindness *auditable*, not forbidding it.)

### 8. Lifetime, replay, rewind

- `present` does **not** pin `data_ref` into any retention window. Refs keep their
  existing lifecycle class.
- Replay/rewind re-renders best-effort from the `presented` event; a GC'd ref renders as
  an expiry placeholder pointing at the audit event. Presentation is a cache; the event
  is the truth.
- **Recovery-feature PR gate — explicit answer (per lead-coder):** PR-D introduces **no
  reconstructed state**. It re-renders a projection from a durable event + an
  already-durable ref, or shows a placeholder; nothing derives recoverable state from
  WAL events, and `present` never writes recovery-core state. ⇒ the CLAUDE.md
  recovery-feature truncate-falsify gate **does not apply**. If a future revision ever
  reconstructs state from `presented` events, that PR must carry the truncate-falsify
  test in-arc.
- Conversation history never contains the presented bytes ⇒ nothing new for compaction.

## Relationship to the tool-result-schema-redesign arc

- **Consumer, not competitor**: `present` consumes the arc's offload refs — the
  `structured` / `structured_ref` / `structured_preview` frontmatter fields, plus the
  text-side ref carried inline in the truncation note — i.e. the text/structured stream
  split from the canonical mappers. Pipeline `ctx.<name>.text` / `ctx.<name>.structured`
  (PR-2) expose the same split (no size gate, full value).
- **Zero blocking asks — dependency fully met (arc CLOSED 2026-07-08)**: every arc PR is
  merged — PR-0 #2647, PR-1 #2648 (canonical mappers + legacy deletion), PR-2 #2652
  (pipeline ctx), PR-3 #2651 (`offload:` opt-out), PR-4 #2654 (design doc →
  `docs/deep-dives/proposals/0053-tool-result-schema-redesign.md`, IMPLEMENTED stamp).
  The offload output shape is landed and fixed; nothing gates this proposal.
- **Follow-up (additive, post-arc)**: enrich offload frontmatter with a shape summary
  (key names / types / array lengths) instead of only a head-N-chars preview — improves
  blind template authoring. Filed and implemented as #2656 (`structured_shape` in
  `seam.py`'s `build_offload_body`, additive alongside `structured_preview`).

## Out of scope (v1)

- Interactive components (v2; via intervention bus).
- Live-updating presentations (A2UI `updateDataModel` diffs) — presentations are
  immutable snapshots; revisit if dashboard-like demand appears (hooks/events could
  drive it).
- Pipelines (`tool:`/`agent:` step surfaces) and CodeAct observation path — same scoping
  as the redesign arc.
- Remote-surface materialization implementation (design contract recorded, § 6).
- Wire-level A2UI / MCP Apps adapters (emit + ingest) — enabled by isomorphism, deferred
  until the specs stabilize.

## Suggested PR sequencing (post owner-GO, post arc PR-1)

- **PR-A** — `present` op + declarative model + binding resolution + presentation-guard
  core (no UI yet; op returns ack against a null renderer). Includes `OP_KIND_MODEL_MAP`
  + control-ir.md section (hard rule), `presented` event type.
- **PR-B** — inline-CUI renderer: conversation inline block + `PresentationRenderer`
  protocol (FP-0051 design lineage), height caps + expand affordance.
- **PR-C** — `presentations.yaml` registration + hot-reload seam + the 4-stage fallback
  chain (built fresh — FP-0051's registry is deleted; §§ 3, 6).
- **PR-D** — replay/rewind placeholder rendering + docs (concepts page + reference).
  **The PR-D description must restate the § 8 recovery-gate answer** (pure re-render /
  placeholder, no authoritative state reconstructed from `presented` events ⇒
  truncate-falsify gate N/A) so a future reviewer does not re-flag it — and must
  re-trigger the gate in-arc if the implementation ever reconstructs state from
  `presented` events.

## Test plan (per testing.ja.md tiers)

- **Tier 1 (contract)**: binding resolution (hit / miss soft-skip / coercion / row-relative
  paths); ack shape (drops reported); blueprint structural gate (non-catalog component
  rejected, non-path binding rejected); guard (escape survival asserted via literal
  bracket, per FP-0051 test idiom); `presented` event field presence incl. OS-computed
  `ingested`; read-authority equivalence (`present` denied ⇔ `file.read` denied).
- **Tier 2 (OS invariant)**: fire-and-continue (run not paused); no content bytes in
  event payloads; ref-expiry placeholder path.
- **No Tier-4 pins**: no exact-render/whitespace assertions; assert content presence and
  drop lists, not layout.

## Owner decisions (resolved)

1. **v1 catalog is display-only — RATIFIED 2026-07-08.** Interactivity deferred to v2 via
   the intervention bus. Owner additionally confirmed markdown + templates are in scope
   (already covered: markdown = § 2 catalog; templates = § 3 4-stage fallback;
   display-only means non-interactive, not content-limited).
2. Naming: `present` (op), `presentations.yaml` (registry) — defaults stand (no override
   requested).

## Sources

- MCP Apps announcement (MCP blog, 2026-01-26) — https://blog.modelcontextprotocol.io/posts/2026-01-26-mcp-apps/
- A2UI v1.0 specification — https://a2ui.org/specification/v1.0-a2ui/
- Google Developers: Introducing A2UI — https://developers.googleblog.com/introducing-a2ui-an-open-project-for-agent-driven-interfaces/
- CopilotKit: The State of Agentic UI (AG-UI / MCP-UI / A2UI) — https://www.copilotkit.ai/blog/the-state-of-agentic-ui-comparing-ag-ui-mcp-ui-and-a2ui-protocols
- The New Stack: Agent UI Standards Multiply — https://thenewstack.io/agent-ui-standards-multiply-mcp-apps-and-googles-a2ui/
- Vercel AI SDK 3.0 Generative UI — https://vercel.com/blog/ai-sdk-3-generative-ui
- FP-0051 viewer registry (superseded — TUI + registry deleted 2026-07, design lineage only) — `docs/deep-dives/proposals/0051-tool-result-viewer-registry-llm-template.md`
- Tool-result schema redesign (IMPLEMENTED) — `docs/deep-dives/proposals/0053-tool-result-schema-redesign.md`
