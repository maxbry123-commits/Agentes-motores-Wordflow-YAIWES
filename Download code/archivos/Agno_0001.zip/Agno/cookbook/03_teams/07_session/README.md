# session

Examples for team workflows in session.

## Prerequisites

- Load environment variables (for example, OPENAI_API_KEY) via direnv allow.
- Use .venvs/demo/bin/python to run cookbook examples.
- Some examples require additional services (for example PostgreSQL, LanceDB, or Infinity server) as noted in file docstrings.

## Files

- chat_history.py - Demonstrates chat history.
- nested_team_history_to_members.py - Nested sub-team receives its own history via add_team_history_to_members.
- persistent_session.py - Demonstrates persistent session.
- search_past_sessions.py - Search and read previous team sessions (two-step pattern).
- custom_session_summary.py - Demonstrates session_summary_manager and summary context.
- session_options.py - Demonstrates session options.
- session_summary.py - Demonstrates session summary.
- share_session_with_agent.py - Demonstrates share session with agent.
