"""
Knowledge Tools
===============

Demonstrates this reasoning cookbook example.
"""

from agno.agent import Agent
from agno.knowledge.embedder.openai import OpenAIEmbedder
from agno.knowledge.knowledge import Knowledge
from agno.models.openai import OpenAIChat
from agno.tools.knowledge import KnowledgeTools
from agno.vectordb.lancedb import LanceDb, SearchType


# ---------------------------------------------------------------------------
# Create Example
# ---------------------------------------------------------------------------
def run_example() -> None:
    # Create a knowledge containing information from a URL
    agno_docs = Knowledge(
        # Use LanceDB as the vector database and store embeddings in the `agno_docs` table
        vector_db=LanceDb(
            uri="tmp/lancedb",
            table_name="agno_docs",
            search_type=SearchType.hybrid,
            embedder=OpenAIEmbedder(id="text-embedding-3-small"),
        ),
    )
    # Add content to the knowledge
    agno_docs.insert(url="https://docs.agno.com/llms-full.txt")

    knowledge_tools = KnowledgeTools(
        knowledge=agno_docs,
        enable_think=True,
        enable_search=True,
        enable_analyze=True,
        add_few_shot=True,
    )

    agent = Agent(
        model=OpenAIChat(id="gpt-5.6-luna"),
        tools=[knowledge_tools],
        markdown=True,
    )

    if __name__ == "__main__":
        agent.print_response(
            "How do I build a team of agents in agno?",
            markdown=True,
            stream=True,
        )


# ---------------------------------------------------------------------------
# Run Example
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    run_example()
