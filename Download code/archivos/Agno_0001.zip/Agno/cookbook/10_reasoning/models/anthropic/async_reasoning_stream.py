"""
Async Reasoning Stream
======================

Demonstrates this reasoning cookbook example.
"""

import asyncio

from agno.agent import Agent
from agno.models.anthropic import Claude
from agno.run.agent import RunEvent  # noqa


# ---------------------------------------------------------------------------
# Create Example
# ---------------------------------------------------------------------------
def run_example() -> None:
    async def streaming_reasoning():
        """Test streaming reasoning with an OpenAI model."""
        # Create an agent with reasoning enabled
        agent = Agent(
            reasoning_model=Claude(
                id="claude-sonnet-4-5",
                thinking={"type": "enabled", "budget_tokens": 1024},
            ),
            instructions="Think step by step about the problem.",
        )

        prompt = "What is 25 * 37? Show your reasoning."

        await agent.aprint_response(prompt, stream=True, stream_events=True)

        # # or you can capture the event using
        # async for run_output_event in agent.arun(
        #     prompt,
        #     stream=True,
        #     stream_events=True,
        # ):
        #     if run_output_event.event == RunEvent.run_started:
        #         print(f"\nEVENT: {run_output_event.event}")

        #     elif run_output_event.event == RunEvent.reasoning_started:
        #         print(f"\nEVENT: {run_output_event.event}")
        #         print("Reasoning started...\n")

        #     elif run_output_event.event == RunEvent.reasoning_content_delta:
        #         # This is the NEW streaming event for reasoning content
        #         # It streams the raw content as it's being generated
        #         print(run_output_event.reasoning_content, end="", flush=True)

        #     elif run_output_event.event == RunEvent.run_content:
        #         if run_output_event.content:
        #             print(run_output_event.content, end="", flush=True)

        #     elif run_output_event.event == RunEvent.run_completed:
        #         print(f"\n\nEVENT: {run_output_event.event}")

    if __name__ == "__main__":
        asyncio.run(streaming_reasoning())


# ---------------------------------------------------------------------------
# Run Example
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    run_example()
