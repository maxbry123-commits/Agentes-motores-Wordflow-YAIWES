// npx vitest core/ignore/__tests__/ShoferIgnoreController.spec.ts

import type { Mock } from "vitest"

import { describe, it, expect, beforeEach, vi } from "vitest"

import { ShoferIgnoreController, LOCK_TEXT_SYMBOL } from "../ShoferIgnoreController.js"
import { setHost, createInMemoryHost } from "@shofer/types"
import * as path from "path"
import * as fs from "fs/promises"
import * as fsSync from "fs"
import { fileExistsAtPath } from "../../fs/fs.js"

// Mock dependencies
vi.mock("fs/promises")
vi.mock("fs")
vi.mock("../../fs/fs.js", () => ({ fileExistsAtPath: vi.fn() }))

// A host whose file watcher is spyable, so we can assert the .shoferignore watcher wiring
// (the controller calls getHost().watcher.watch(...) then registers onChange/onCreate/onDelete).
const fileWatcher = {
	onChange: vi.fn((_h: (path: string) => void) => ({ dispose: vi.fn() })),
	onCreate: vi.fn((_h: (path: string) => void) => ({ dispose: vi.fn() })),
	onDelete: vi.fn((_h: (path: string) => void) => ({ dispose: vi.fn() })),
	dispose: vi.fn(),
}
const mockWatch = vi.fn(() => fileWatcher)

describe("ShoferIgnoreController", () => {
	const TEST_CWD = "/test/path"
	let controller: ShoferIgnoreController
	let mockFileExists: Mock<typeof fileExistsAtPath>
	let mockReadFile: Mock<typeof fs.readFile>

	beforeEach(() => {
		// Reset mocks
		vi.clearAllMocks()
		setHost({ ...createInMemoryHost(), watcher: { watch: mockWatch } })

		// Setup fs mocks
		mockFileExists = fileExistsAtPath as Mock<typeof fileExistsAtPath>
		mockReadFile = fs.readFile as Mock<typeof fs.readFile>

		// Setup fsSync mocks with default behavior (return path as-is, like regular files)
		const mockRealpathSync = vi.mocked(fsSync.realpathSync)
		mockRealpathSync.mockImplementation((filePath) => filePath.toString())

		// Create controller
		controller = new ShoferIgnoreController(TEST_CWD)
	})

	describe("initialization", () => {
		/**
		 * Tests the controller initialization when .shofer/shoferignore exists
		 */
		it("should load .shofer/shoferignore patterns on initialization when file exists", async () => {
			// Setup mocks to simulate existing .shofer/shoferignore file
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets.json")

			// Initialize controller
			await controller.initialize()

			// Verify file was checked and read
			expect(mockFileExists).toHaveBeenCalledWith(path.join(TEST_CWD, ".shofer/shoferignore"))
			expect(mockReadFile).toHaveBeenCalledWith(path.join(TEST_CWD, ".shofer/shoferignore"), "utf8")

			// Verify content was stored
			expect(controller.shoferIgnoreContent).toBe("node_modules\n.git\nsecrets.json")

			// Test that ignore patterns were applied
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)
			expect(controller.validateAccess("src/app.ts")).toBe(true)
			expect(controller.validateAccess(".git/config")).toBe(false)
			expect(controller.validateAccess("secrets.json")).toBe(false)
		})

		/**
		 * Tests the controller behavior when .shofer/shoferignore doesn't exist
		 */
		it("should allow all access when .shofer/shoferignore doesn't exist", async () => {
			// Setup mocks to simulate missing .shofer/shoferignore file
			mockFileExists.mockResolvedValue(false)

			// Initialize controller
			await controller.initialize()

			// Verify no content was stored
			expect(controller.shoferIgnoreContent).toBeUndefined()

			// All files should be accessible
			expect(controller.validateAccess("node_modules/package.json")).toBe(true)
			expect(controller.validateAccess("secrets.json")).toBe(true)
		})

		/**
		 * Tests the file watcher setup
		 */
		it("should set up file watcher for .shofer/shoferignore changes", async () => {
			// Check that the host watcher was created with the correct base + pattern
			expect(mockWatch).toHaveBeenCalledWith(path.join(TEST_CWD, ".shofer"), "shoferignore")

			// Verify event handlers were registered
			expect(fileWatcher.onCreate).toHaveBeenCalled()
			expect(fileWatcher.onChange).toHaveBeenCalled()
			expect(fileWatcher.onDelete).toHaveBeenCalled()
		})

		/**
		 * Tests error handling during initialization
		 */
		it("should handle errors when loading .shofer/shoferignore", async () => {
			// Setup mocks to simulate error
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockRejectedValue(new Error("Test file read error"))

			// Spy on console.error
			// Initialize controller - shouldn't throw
			await controller.initialize()
		})
	})

	describe("validateAccess", () => {
		beforeEach(async () => {
			// Setup .shofer/shoferignore content
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets/**\n*.log")
			await controller.initialize()
		})

		/**
		 * Tests basic path validation
		 */
		it("should correctly validate file access based on ignore patterns", () => {
			// Test different path patterns
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)
			expect(controller.validateAccess("node_modules")).toBe(false)
			expect(controller.validateAccess("src/node_modules/file.js")).toBe(false)
			expect(controller.validateAccess(".git/HEAD")).toBe(false)
			expect(controller.validateAccess("secrets/api-keys.json")).toBe(false)
			expect(controller.validateAccess("logs/app.log")).toBe(false)

			// These should be allowed
			expect(controller.validateAccess("src/app.ts")).toBe(true)
			expect(controller.validateAccess("package.json")).toBe(true)
			expect(controller.validateAccess("secret-file.json")).toBe(true)
		})

		/**
		 * Tests handling of absolute paths
		 */
		it("should handle absolute paths correctly", () => {
			// Test with absolute paths
			const absolutePath = path.join(TEST_CWD, "node_modules/package.json")
			expect(controller.validateAccess(absolutePath)).toBe(false)

			const allowedAbsolutePath = path.join(TEST_CWD, "src/app.ts")
			expect(controller.validateAccess(allowedAbsolutePath)).toBe(true)
		})

		/**
		 * Tests handling of paths outside cwd
		 */
		it("should allow access to paths outside cwd", () => {
			// Path traversal outside cwd
			expect(controller.validateAccess("../outside-project/file.txt")).toBe(true)

			// Completely different path
			expect(controller.validateAccess("/etc/hosts")).toBe(true)
		})

		/**
		 * Tests the default behavior when no .shofer/shoferignore exists
		 */
		it("should allow all access when no .shofer/shoferignore content", async () => {
			// Create a new controller with no .shofer/shoferignore
			mockFileExists.mockResolvedValue(false)
			const emptyController = new ShoferIgnoreController(TEST_CWD)
			await emptyController.initialize()

			// All paths should be allowed
			expect(emptyController.validateAccess("node_modules/package.json")).toBe(true)
			expect(emptyController.validateAccess("secrets/api-keys.json")).toBe(true)
			expect(emptyController.validateAccess(".git/HEAD")).toBe(true)
		})

		/**
		 * Tests symlink resolution
		 */
		it("should block symlinks pointing to ignored files", () => {
			// Mock fsSync.realpathSync to simulate symlink resolution
			const mockRealpathSync = vi.mocked(fsSync.realpathSync)
			mockRealpathSync.mockImplementation((filePath) => {
				// Simulate "config.json" being a symlink to "node_modules/package.json"
				if (filePath.toString().endsWith("config.json")) {
					return path.join(TEST_CWD, "node_modules/package.json")
				}
				return filePath.toString()
			})

			// Direct access to ignored file should be blocked
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)

			// Symlink to ignored file should also be blocked
			expect(controller.validateAccess("config.json")).toBe(false)
		})
	})

	describe("validateCommand", () => {
		beforeEach(async () => {
			// Setup .shofer/shoferignore content
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets/**\n*.log")
			await controller.initialize()
		})

		/**
		 * Tests validation of file reading commands
		 */
		it("should block file reading commands accessing ignored files", () => {
			// Cat command accessing ignored file
			expect(controller.validateCommand("cat node_modules/package.json")).toBe("node_modules/package.json")

			// Grep command accessing ignored file
			expect(controller.validateCommand("grep pattern .git/config")).toBe(".git/config")

			// Commands accessing allowed files should return undefined
			expect(controller.validateCommand("cat src/app.ts")).toBeUndefined()
			expect(controller.validateCommand("less README.md")).toBeUndefined()
		})

		/**
		 * Tests commands with various arguments and flags
		 */
		it("should handle command arguments and flags correctly", () => {
			// Command with flags
			expect(controller.validateCommand("cat -n node_modules/package.json")).toBe("node_modules/package.json")

			// Command with multiple files (only first ignored file is returned)
			expect(controller.validateCommand("grep pattern src/app.ts node_modules/index.js")).toBe(
				"node_modules/index.js",
			)

			// Command with PowerShell parameter style
			expect(controller.validateCommand("Get-Content -Path secrets/api-keys.json")).toBe("secrets/api-keys.json")

			// Arguments with colons are skipped due to the implementation
			// Adjust test to match actual implementation which skips arguments with colons
			expect(controller.validateCommand("Select-String -Path secrets/api-keys.json -Pattern key")).toBe(
				"secrets/api-keys.json",
			)
		})

		/**
		 * Tests validation of non-file-reading commands
		 */
		it("should allow non-file-reading commands", () => {
			// Commands that don't access files directly
			expect(controller.validateCommand("ls -la")).toBeUndefined()
			expect(controller.validateCommand("echo 'Hello'")).toBeUndefined()
			expect(controller.validateCommand("cd node_modules")).toBeUndefined()
			expect(controller.validateCommand("npm install")).toBeUndefined()
		})

		/**
		 * Tests behavior when no .shofer/shoferignore exists
		 */
		it("should allow all commands when no .shofer/shoferignore exists", async () => {
			// Create a new controller with no .shofer/shoferignore
			mockFileExists.mockResolvedValue(false)
			const emptyController = new ShoferIgnoreController(TEST_CWD)
			await emptyController.initialize()

			// All commands should be allowed
			expect(emptyController.validateCommand("cat node_modules/package.json")).toBeUndefined()
			expect(emptyController.validateCommand("grep pattern .git/config")).toBeUndefined()
		})
	})

	describe("filterPaths", () => {
		beforeEach(async () => {
			// Setup .shofer/shoferignore content
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets/**\n*.log")
			await controller.initialize()
		})

		/**
		 * Tests filtering an array of paths
		 */
		it("should filter out ignored paths from an array", () => {
			const paths = [
				"src/app.ts",
				"node_modules/package.json",
				"README.md",
				".git/HEAD",
				"secrets/keys.json",
				"build/app.js",
				"logs/error.log",
			]

			const filtered = controller.filterPaths(paths)

			// Expected filtered result
			expect(filtered).toEqual(["src/app.ts", "README.md", "build/app.js"])

			// Length should be reduced
			expect(filtered.length).toBe(3)
		})

		/**
		 * Tests error handling in filterPaths
		 */
		it("should handle errors in filterPaths and fail closed", () => {
			// Mock validateAccess to throw an error
			vi.spyOn(controller, "validateAccess").mockImplementation(() => {
				throw new Error("Test error")
			})

			// Should return empty array on error (fail closed)
			const result = controller.filterPaths(["file1.txt", "file2.txt"])
			expect(result).toEqual([])
		})

		/**
		 * Tests empty array handling
		 */
		it("should handle empty arrays", () => {
			const result = controller.filterPaths([])
			expect(result).toEqual([])
		})
	})

	describe("getInstructions", () => {
		/**
		 * Tests instructions generation with .shofer/shoferignore
		 */
		it("should generate formatted instructions when .shofer/shoferignore exists", async () => {
			// Setup .shofer/shoferignore content
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules\n.git\nsecrets/**")
			await controller.initialize()

			const instructions = controller.getInstructions()

			// Verify instruction format
			expect(instructions).toContain("# .shoferignore")
			expect(instructions).toContain(LOCK_TEXT_SYMBOL)
			expect(instructions).toContain("node_modules")
			expect(instructions).toContain(".git")
			expect(instructions).toContain("secrets/**")
		})

		/**
		 * Tests behavior when no .shofer/shoferignore exists
		 */
		it("should return undefined when no .shofer/shoferignore exists", async () => {
			// Setup no .shofer/shoferignore
			mockFileExists.mockResolvedValue(false)
			await controller.initialize()

			const instructions = controller.getInstructions()
			expect(instructions).toBeUndefined()
		})
	})

	describe("dispose", () => {
		/**
		 * Tests proper cleanup of resources
		 */
		it("should dispose all registered disposables", () => {
			// Create spy for dispose methods
			const disposeSpy = vi.fn()

			// Manually add disposables to test
			controller["disposables"] = [{ dispose: disposeSpy }, { dispose: disposeSpy }, { dispose: disposeSpy }]

			// Call dispose
			controller.dispose()

			// Verify all disposables were disposed
			expect(disposeSpy).toHaveBeenCalledTimes(3)

			// Verify disposables array was cleared
			expect(controller["disposables"]).toEqual([])
		})
	})

	describe("file watcher", () => {
		/**
		 * Tests behavior when .shofer/shoferignore is created
		 */
		it("should reload .shofer/shoferignore when file is created", async () => {
			// Setup initial state without .shofer/shoferignore
			mockFileExists.mockResolvedValue(false)
			await controller.initialize()

			// Verify initial state
			expect(controller.shoferIgnoreContent).toBeUndefined()
			expect(controller.validateAccess("node_modules/package.json")).toBe(true)

			// Setup for the test
			mockFileExists.mockResolvedValue(false) // Initially no file exists

			// Create and initialize controller with no .shofer/shoferignore
			controller = new ShoferIgnoreController(TEST_CWD)
			await controller.initialize()

			// Initial state check
			expect(controller.shoferIgnoreContent).toBeUndefined()

			// Now simulate file creation
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules")

			// Force reload of .shofer/shoferignore content manually
			await controller.initialize()

			// Now verify content was updated
			expect(controller.shoferIgnoreContent).toBe("node_modules")

			// Verify access validation changed
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)
		})

		/**
		 * Tests behavior when .shofer/shoferignore is changed
		 */
		it("should reload .shofer/shoferignore when file is changed", async () => {
			// Setup initial state with .shofer/shoferignore
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules")
			await controller.initialize()

			// Verify initial state
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)
			expect(controller.validateAccess(".git/config")).toBe(true)

			// Simulate file change
			mockReadFile.mockResolvedValue("node_modules\n.git")

			// Instead of relying on the onChange handler, manually reload
			// This is because the mock watcher doesn't actually trigger the reload in tests
			await controller.initialize()

			// Verify content was updated
			expect(controller.shoferIgnoreContent).toBe("node_modules\n.git")

			// Verify access validation changed
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)
			expect(controller.validateAccess(".git/config")).toBe(false)
		})

		/**
		 * Tests behavior when .shofer/shoferignore is deleted
		 */
		it("should reset when .shofer/shoferignore is deleted", async () => {
			// Setup initial state with .shofer/shoferignore
			mockFileExists.mockResolvedValue(true)
			mockReadFile.mockResolvedValue("node_modules")
			await controller.initialize()

			// Verify initial state
			expect(controller.validateAccess("node_modules/package.json")).toBe(false)

			// Simulate file deletion
			mockFileExists.mockResolvedValue(false)

			// Find and trigger the onDelete handler
			const onDeleteHandler = fileWatcher.onDelete.mock.calls[0]![0]
			await onDeleteHandler("/workspace/.shofer/shoferignore")

			// Verify content was reset
			expect(controller.shoferIgnoreContent).toBeUndefined()

			// Verify access validation changed
			expect(controller.validateAccess("node_modules/package.json")).toBe(true)
		})
	})
})
