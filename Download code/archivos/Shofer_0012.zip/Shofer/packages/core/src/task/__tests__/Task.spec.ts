import { BUILTIN_MODES } from "../../__fixtures__/builtin-config.js"
// npx vitest run src/task/__tests__/Task.spec.ts

import * as os from "os"
import * as path from "path"

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest"
import { Anthropic } from "@anthropic-ai/sdk"

import type { ProviderSettings, ModelInfo, TaskProviderLike } from "@shofer/types"
import { setHost, createInMemoryHost } from "@shofer/types"
import { TelemetryService } from "@shofer/telemetry"

// Task and its deps all live in @shofer/core and call each other via intra-package
// RELATIVE imports, so a barrel `vi.mock("@shofer/core")` cannot intercept them.
// We stub Task's concrete relative-imported deps instead.

// Noop ignore controller so constructing a Task doesn't spin up the real file watcher.
vi.mock("../../ignore/ShoferIgnoreController.js", () => ({
	ShoferIgnoreController: class {
		validateAccess() {
			return true
		}
		validateCommand() {
			return undefined
		}
		filterPaths(paths: string[]) {
			return paths
		}
		getInstructions() {
			return undefined
		}
		async initialize() {}
		dispose() {}
	},
}))

// Storage path helpers (relocated into @shofer/core/utils/storage).
vi.mock("../../utils/storage.js", async (importOriginal) => ({
	...((await importOriginal()) as Record<string, unknown>),
	getTaskDirectoryPath: vi
		.fn()
		.mockImplementation((globalStoragePath, taskId) => Promise.resolve(`${globalStoragePath}/tasks/${taskId}`)),
	getSettingsDirectoryPath: vi
		.fn()
		.mockImplementation((globalStoragePath) => Promise.resolve(`${globalStoragePath}/settings`)),
}))

// Condense summarization (imported by Task from ../condense/index.js).
vi.mock("../../condense/index.js", async (importOriginal) => ({
	...((await importOriginal()) as Record<string, unknown>),
	summarizeConversation: vi.fn().mockResolvedValue({
		messages: [{ role: "user", content: [{ type: "text", text: "continued" }], ts: Date.now() }],
		summary: "summary",
		cost: 0,
		newContextTokens: 1,
	}),
}))

import { Task } from "../Task.js"
import type { ApiStreamChunk } from "../../api/transform/stream.js"
import { processUserContentMentions } from "../../mentions/processUserContentMentions.js"
import { MultiSearchReplaceDiffStrategy } from "../../diff/strategies/multi-search-replace.js"

// Mock delay before any imports that might use it
vi.mock("delay", () => ({
	__esModule: true,
	default: vi.fn().mockResolvedValue(undefined),
}))

import delay from "delay"

vi.mock("uuid", async (importOriginal) => {
	const actual = await importOriginal<typeof import("uuid")>()
	return {
		...actual,
		v7: vi.fn(() => "00000000-0000-7000-8000-000000000000"),
	}
})

vi.mock("execa", () => ({
	execa: vi.fn(),
}))

vi.mock("fs/promises", async (importOriginal) => {
	const actual = (await importOriginal()) as Record<string, any>
	const mockFunctions = {
		mkdir: vi.fn().mockResolvedValue(undefined),
		writeFile: vi.fn().mockResolvedValue(undefined),
		appendFile: vi.fn().mockResolvedValue(undefined),
		rename: vi.fn().mockResolvedValue(undefined),
		readFile: vi.fn().mockImplementation((filePath) => {
			if (filePath.includes("ui_messages.jsonl") || filePath.includes("ui_messages.json")) {
				// JSONL format: one record per line. The legacy .json branch is
				// here only as a defensive default — production code unlinks it.
				return Promise.resolve(mockMessages.map((m) => JSON.stringify(m)).join("\n") + "\n")
			}
			if (
				filePath.includes("api_conversation_history.jsonl") ||
				filePath.includes("api_conversation_history.json")
			) {
				const msgs = [
					{ role: "user", content: [{ type: "text", text: "historical task" }], ts: Date.now() },
					{
						role: "assistant",
						content: [{ type: "text", text: "I'll help you with that task." }],
						ts: Date.now(),
					},
				]
				return Promise.resolve(msgs.map((m) => JSON.stringify(m)).join("\n") + "\n")
			}
			return Promise.resolve("[]")
		}),
		unlink: vi.fn().mockResolvedValue(undefined),
		rmdir: vi.fn().mockResolvedValue(undefined),
		stat: vi.fn().mockRejectedValue({ code: "ENOENT" }),
		readdir: vi.fn().mockResolvedValue([]),
	}

	return {
		...actual,
		...mockFunctions,
		default: mockFunctions,
	}
})

vi.mock("p-wait-for", () => ({
	default: vi.fn().mockImplementation(async () => Promise.resolve()),
}))

vi.mock("vscode", () => {
	const mockDisposable = { dispose: vi.fn() }
	const mockEventEmitter = { event: vi.fn(), fire: vi.fn() }
	const mockTextDocument = { uri: { fsPath: "/mock/workspace/path/file.ts" } }
	const mockTextEditor = { document: mockTextDocument }
	const mockTab = { input: { uri: { fsPath: "/mock/workspace/path/file.ts" } } }
	const mockTabGroup = { tabs: [mockTab] }

	return {
		TabInputTextDiff: vi.fn(),
		CodeActionKind: {
			QuickFix: { value: "quickfix" },
			RefactorRewrite: { value: "refactor.rewrite" },
		},
		window: {
			createTextEditorDecorationType: vi.fn().mockReturnValue({
				dispose: vi.fn(),
			}),
			visibleTextEditors: [mockTextEditor],
			tabGroups: {
				all: [mockTabGroup],
				close: vi.fn(),
				onDidChangeTabs: vi.fn(() => ({ dispose: vi.fn() })),
			},
			showErrorMessage: vi.fn(),
		},
		workspace: {
			workspaceFolders: [
				{
					uri: { fsPath: "/mock/workspace/path" },
					name: "mock-workspace",
					index: 0,
				},
			],
			createFileSystemWatcher: vi.fn(() => ({
				onDidCreate: vi.fn(() => mockDisposable),
				onDidDelete: vi.fn(() => mockDisposable),
				onDidChange: vi.fn(() => mockDisposable),
				dispose: vi.fn(),
			})),
			fs: {
				stat: vi.fn().mockResolvedValue({ type: 1 }), // FileType.File = 1
			},
			onDidSaveTextDocument: vi.fn(() => mockDisposable),
			getConfiguration: vi.fn(() => ({ get: (key: string, defaultValue: any) => defaultValue })),
		},
		env: {
			uriScheme: "vscode",
			language: "en",
		},
		EventEmitter: vi.fn().mockImplementation(() => mockEventEmitter),
		Disposable: {
			from: vi.fn(),
		},
		TabInputText: vi.fn(),
	}
})

// Override only parseMentions (so processUserContentMentions yields "processed:")
// while preserving the real processUserContentMentions re-export from the barrel.
vi.mock("../../mentions", async (importOriginal) => ({
	...((await importOriginal()) as Record<string, unknown>),
	parseMentions: vi.fn().mockImplementation((text) => {
		return Promise.resolve({ text: `processed: ${text}`, mode: undefined, contentBlocks: [] })
	}),
	openMention: vi.fn(),
	getLatestTerminalOutput: vi.fn(),
}))

vi.mock("../../environment/getEnvironmentDetails", () => ({
	getEnvironmentDetails: vi.fn().mockResolvedValue(""),
}))

const mockMessages = [
	{
		ts: Date.now(),
		type: "say",
		say: "text",
		text: "historical task",
	},
]

describe("Shofer", () => {
	let mockProvider: any
	let mockApiConfig: ProviderSettings

	beforeEach(() => {
		setHost(createInMemoryHost())
		if (!TelemetryService.hasInstance()) {
			TelemetryService.createInstance([])
		}

		// Setup mock extension context
		const storageUri = {
			fsPath: path.join(os.tmpdir(), "test-storage"),
		}

		// Plain provider stub typed as TaskProviderLike — never import concrete
		// src classes (ShoferProvider/ContextProxy) into a core test.
		mockProvider = {
			context: {
				globalStorageUri: storageUri,
				extensionUri: { fsPath: "/mock/extension/path" },
				extension: { packageJSON: { version: "1.0.0" } },
			},
			getState: vi.fn().mockResolvedValue({ mode: "code", experiments: {}, customModes: BUILTIN_MODES }),
			log: vi.fn(),
			on: vi.fn(),
			off: vi.fn(),
			postTaskStateUpdate: vi.fn(),
			getCurrentTask: vi.fn().mockReturnValue(undefined),
			updateTaskHistory: vi.fn().mockResolvedValue(undefined),
			getSkillsManager: vi.fn().mockReturnValue(undefined),
			getMcpHub: vi.fn().mockReturnValue(undefined),
			taskManager: { getFocusedTaskId: vi.fn().mockReturnValue(undefined) },
			say: vi.fn(),
		} as unknown as TaskProviderLike

		// Setup mock API configuration
		mockApiConfig = {
			apiProvider: "anthropic",
			apiModelId: "claude-3-5-sonnet-20241022",
			apiKey: "test-api-key", // Add API key to mock config
		}

		// Mock provider methods
		mockProvider.postMessageToWebview = vi.fn().mockResolvedValue(undefined)
		mockProvider.getTaskWithId = vi.fn().mockImplementation(async (id) => ({
			historyItem: {
				id,
				ts: Date.now(),
				task: "historical task",
				tokensIn: 100,
				tokensOut: 200,
				cacheWrites: 0,
				cacheReads: 0,
				totalCost: 0.001,
			},
			taskDirPath: "/mock/storage/path/tasks/123",
			apiConversationHistoryFilePath: "/mock/storage/path/tasks/123/api_conversation_history.jsonl",
			uiMessagesFilePath: "/mock/storage/path/tasks/123/ui_messages.jsonl",
			apiConversationHistory: [
				{
					role: "user",
					content: [{ type: "text", text: "historical task" }],
					ts: Date.now(),
				},
				{
					role: "assistant",
					content: [{ type: "text", text: "I'll help you with that task." }],
					ts: Date.now(),
				},
			],
		}))
	})

	describe("constructor", () => {
		it("should always have diff strategy defined", async () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Diff is always enabled - diffStrategy should be defined
			expect(shofer.diffStrategy).toBeDefined()
		})

		it("should use default consecutiveMistakeLimit when not provided", () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			expect(shofer.consecutiveMistakeLimit).toBe(3)
		})

		it("should respect provided consecutiveMistakeLimit", () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				consecutiveMistakeLimit: 5,
				task: "test task",
				startTask: false,
			})

			expect(shofer.consecutiveMistakeLimit).toBe(5)
		})

		it("should keep consecutiveMistakeLimit of 0 as 0 for unlimited", () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				consecutiveMistakeLimit: 0,
				task: "test task",
				startTask: false,
			})

			expect(shofer.consecutiveMistakeLimit).toBe(0)
		})

		it("should pass 0 to ToolRepetitionDetector for unlimited mode", () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				consecutiveMistakeLimit: 0,
				task: "test task",
				startTask: false,
			})

			// The toolRepetitionDetector should be initialized with 0 for unlimited mode
			expect(shofer.toolRepetitionDetector).toBeDefined()
			// Verify the limit remains as 0
			expect(shofer.consecutiveMistakeLimit).toBe(0)
		})

		it("should pass consecutiveMistakeLimit to ToolRepetitionDetector", () => {
			const shofer = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				consecutiveMistakeLimit: 5,
				task: "test task",
				startTask: false,
			})

			// The toolRepetitionDetector should be initialized with the same limit
			expect(shofer.toolRepetitionDetector).toBeDefined()
			expect(shofer.consecutiveMistakeLimit).toBe(5)
		})

		it("should require either task or historyItem", () => {
			expect(() => {
				new Task({ provider: mockProvider, apiConfiguration: mockApiConfig })
			}).toThrow("Either historyItem or task/images must be provided")
		})
	})

	describe("getEnvironmentDetails", () => {
		describe("API conversation handling", () => {
			it("should clean conversation history before sending to API", async () => {
				// Create task without starting it so mocks can be applied before any API call.
				const shofer = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(shofer as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Set up mock stream.
				const mockStreamForClean = (async function* () {
					yield { type: "text", text: "test response" }
				})() as AsyncGenerator<ApiStreamChunk>

				// Set up spy.
				const cleanMessageSpy = vi.fn().mockReturnValue(mockStreamForClean)
				vi.spyOn(shofer.api, "createMessage").mockImplementation(cleanMessageSpy)

				// Add a message with extra properties to the conversation history.
				const messageWithExtra = {
					role: "user" as const,
					content: [{ type: "text" as const, text: "test message" }],
					ts: Date.now(),
					extraProp: "should be removed",
				}
				shofer.apiConversationHistory = [messageWithExtra]

				// Trigger an API request directly via the generator.
				const iterator = shofer.attemptApiRequest(0)
				await iterator.next()

				// Get the conversation history from the first API call.
				expect(cleanMessageSpy.mock.calls.length).toBeGreaterThan(0)
				const history = cleanMessageSpy.mock.calls[0]?.[1]
				expect(history).toBeDefined()
				expect(history.length).toBeGreaterThan(0)

				// Find our test message.
				const cleanedMessage = history.find((msg: { content?: Array<{ text: string }> }) =>
					msg.content?.some((content) => content.text === "test message"),
				)
				expect(cleanedMessage).toBeDefined()
				expect(cleanedMessage).toEqual({
					role: "user",
					content: [{ type: "text", text: "test message" }],
				})

				// Verify extra properties were removed.
				expect(Object.keys(cleanedMessage!)).toEqual(["role", "content"])
			})

			it("should handle image blocks based on model capabilities", async () => {
				// Create two configurations - one with image support, one without
				const configWithImages = {
					...mockApiConfig,
					apiModelId: "claude-3-sonnet",
				}
				const configWithoutImages = {
					...mockApiConfig,
					apiModelId: "gpt-3.5-turbo",
				}

				// Test with model that supports images.
				const clineWithImages = new Task({
					provider: mockProvider,
					apiConfiguration: configWithImages,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(clineWithImages as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the model info to indicate image support
				vi.spyOn(clineWithImages.api, "getModel").mockReturnValue({
					id: "claude-3-sonnet",
					info: {
						supportsImages: true,
						supportsPromptCache: true,
						contextWindow: 200000,
						maxTokens: 4096,
						inputPrice: 0.25,
						outputPrice: 0.75,
					} as ModelInfo,
				})

				// Test with model that doesn't support images.
				const clineWithoutImages = new Task({
					provider: mockProvider,
					apiConfiguration: configWithoutImages,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(clineWithoutImages as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the model info to indicate no image support
				vi.spyOn(clineWithoutImages.api, "getModel").mockReturnValue({
					id: "gpt-3.5-turbo",
					info: {
						supportsImages: false,
						supportsPromptCache: false,
						contextWindow: 16000,
						maxTokens: 2048,
						inputPrice: 0.1,
						outputPrice: 0.2,
					} as ModelInfo,
				})

				// Set up mock streams.
				const mockStreamWithImages = (async function* () {
					yield { type: "text", text: "test response" }
				})() as AsyncGenerator<ApiStreamChunk>

				const mockStreamWithoutImages = (async function* () {
					yield { type: "text", text: "test response" }
				})() as AsyncGenerator<ApiStreamChunk>

				// Set up spies.
				const imagesSpy = vi.fn().mockReturnValue(mockStreamWithImages)
				const noImagesSpy = vi.fn().mockReturnValue(mockStreamWithoutImages)

				vi.spyOn(clineWithImages.api, "createMessage").mockImplementation(imagesSpy)
				vi.spyOn(clineWithoutImages.api, "createMessage").mockImplementation(noImagesSpy)

				// Populate conversation history with mixed image+text content.
				clineWithImages.apiConversationHistory = [
					{
						role: "user",
						content: [
							{ type: "text", text: "Here is an image" },
							{ type: "image", source: { type: "base64", media_type: "image/jpeg", data: "base64data" } },
						],
					},
				]

				clineWithoutImages.apiConversationHistory = [
					{
						role: "user",
						content: [
							{ type: "text", text: "Here is an image" },
							{ type: "image", source: { type: "base64", media_type: "image/jpeg", data: "base64data" } },
						],
					},
				]

				// Trigger API requests directly via the generator.
				const iteratorWithImages = clineWithImages.attemptApiRequest(0)
				await iteratorWithImages.next()

				const iteratorWithoutImages = clineWithoutImages.attemptApiRequest(0)
				await iteratorWithoutImages.next()

				// Get the calls
				const imagesCalls = imagesSpy.mock.calls
				const noImagesCalls = noImagesSpy.mock.calls

				// Verify model with image support preserves image blocks
				expect(imagesCalls.length).toBeGreaterThan(0)
				if (imagesCalls[0]?.[1]?.[0]?.content) {
					expect(imagesCalls[0][1][0].content).toHaveLength(2)
					expect(imagesCalls[0][1][0].content[0]).toEqual({ type: "text", text: "Here is an image" })
					expect(imagesCalls[0][1][0].content[1]).toHaveProperty("type", "image")
				}

				// Verify model without image support converts image blocks to text
				expect(noImagesCalls.length).toBeGreaterThan(0)
				if (noImagesCalls[0]?.[1]?.[0]?.content) {
					expect(noImagesCalls[0][1][0].content).toHaveLength(2)
					expect(noImagesCalls[0][1][0].content[0]).toEqual({ type: "text", text: "Here is an image" })
					expect(noImagesCalls[0][1][0].content[1]).toEqual({
						type: "text",
						text: "[Referenced image in conversation]",
					})
				}
			})

			it("should handle API retry with countdown", async () => {
				// Create task without starting it so mocks are applied before any API call.
				const shofer = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(shofer as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock delay to track countdown timing
				const mockDelay = vi.fn().mockResolvedValue(undefined)
				vi.spyOn(await import("delay"), "default").mockImplementation(mockDelay)

				// Mock say to track messages
				const saySpy = vi.spyOn(shofer, "say")

				// Create a stream that fails on first chunk
				const mockError = new Error("API Error")
				const mockFailedStream = {
					// eslint-disable-next-line require-yield
					async *[Symbol.asyncIterator]() {
						throw mockError
					},
					async next() {
						throw mockError
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					async [Symbol.asyncDispose]() {
						// Cleanup
					},
				} as AsyncGenerator<ApiStreamChunk>

				// Create a successful stream for retry
				const mockSuccessStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "Success" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "Success" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					async [Symbol.asyncDispose]() {
						// Cleanup
					},
				} as AsyncGenerator<ApiStreamChunk>

				// Mock createMessage to fail first then succeed
				let firstAttempt = true
				vi.spyOn(shofer.api, "createMessage").mockImplementation(() => {
					if (firstAttempt) {
						firstAttempt = false
						return mockFailedStream
					}
					return mockSuccessStream
				})

				// Enable auto-approval so the retry uses backoffAndAnnounce instead of
				// prompting the user. Set requestDelaySeconds to control countdown length.
				const baseDelay = 3
				mockProvider.getState = vi.fn().mockResolvedValue({
					autoApprovalEnabled: true,
					requestDelaySeconds: baseDelay,
					mcpEnabled: false,
					apiConfiguration: mockApiConfig,
					customModes: BUILTIN_MODES,
				})

				// Trigger API request
				const iterator = shofer.attemptApiRequest(0)
				await iterator.next()

				// Verify countdown messages — new format uses <retry_timer> tags
				for (let i = baseDelay; i > 0; i--) {
					expect(saySpy).toHaveBeenCalledWith(
						"api_req_retry_delayed",
						expect.stringContaining(`<retry_timer>${i}</retry_timer>`),
						undefined,
						true,
					)
				}

				// Verify the final "retrying now" message (just the header text, no timer tag)
				expect(saySpy).toHaveBeenCalledWith(
					"api_req_retry_delayed",
					expect.stringContaining(mockError.message),
					undefined,
					false,
				)

				// Calculate expected delay calls for countdown
				const totalExpectedDelays = baseDelay // One delay per second for countdown
				expect(mockDelay).toHaveBeenCalledTimes(totalExpectedDelays)
				expect(mockDelay).toHaveBeenCalledWith(1000)
			})

			it("should not apply retry delay twice", async () => {
				// Create task without starting it so mocks are applied before any API call.
				const shofer = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(shofer as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock delay to track countdown timing
				const mockDelay = vi.fn().mockResolvedValue(undefined)
				vi.spyOn(await import("delay"), "default").mockImplementation(mockDelay)

				// Mock say to track messages
				const saySpy = vi.spyOn(shofer, "say")

				// Create a stream that fails on first chunk
				const mockError = new Error("API Error")
				const mockFailedStream = {
					// eslint-disable-next-line require-yield
					async *[Symbol.asyncIterator]() {
						throw mockError
					},
					async next() {
						throw mockError
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					async [Symbol.asyncDispose]() {
						// Cleanup
					},
				} as AsyncGenerator<ApiStreamChunk>

				// Create a successful stream for retry
				const mockSuccessStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "Success" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "Success" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					async [Symbol.asyncDispose]() {
						// Cleanup
					},
				} as AsyncGenerator<ApiStreamChunk>

				// Mock createMessage to fail first then succeed
				let firstAttempt = true
				vi.spyOn(shofer.api, "createMessage").mockImplementation(() => {
					if (firstAttempt) {
						firstAttempt = false
						return mockFailedStream
					}
					return mockSuccessStream
				})

				// Enable auto-approval so the retry uses backoffAndAnnounce instead of
				// prompting the user. Set requestDelaySeconds to control countdown length.
				const baseDelay = 3
				mockProvider.getState = vi.fn().mockResolvedValue({
					autoApprovalEnabled: true,
					requestDelaySeconds: baseDelay,
					mcpEnabled: false,
					apiConfiguration: mockApiConfig,
					customModes: BUILTIN_MODES,
				})

				// Trigger API request
				const iterator = shofer.attemptApiRequest(0)
				await iterator.next()

				// Verify delay is only applied for the countdown (not duplicated)
				const expectedDelayCount = baseDelay // One delay per second for countdown
				expect(mockDelay).toHaveBeenCalledTimes(expectedDelayCount)
				expect(mockDelay).toHaveBeenCalledWith(1000) // Each delay should be 1 second

				// Verify countdown messages were only shown once — new format uses <retry_timer> tags
				const retryMessages = saySpy.mock.calls.filter(
					(call) => call[0] === "api_req_retry_delayed" && call[1]?.includes("<retry_timer>"),
				)
				expect(retryMessages).toHaveLength(baseDelay)

				// Verify the retry message sequence
				for (let i = baseDelay; i > 0; i--) {
					expect(saySpy).toHaveBeenCalledWith(
						"api_req_retry_delayed",
						expect.stringContaining(`<retry_timer>${i}</retry_timer>`),
						undefined,
						true,
					)
				}

				// Verify final retry message (just the header text, no timer tag)
				expect(saySpy).toHaveBeenCalledWith(
					"api_req_retry_delayed",
					expect.stringContaining(mockError.message),
					undefined,
					false,
				)
			})

			describe("consecutive API failure bound", () => {
				/**
				 * The defect these cover: a provider the worker cannot reach fails
				 * with a status-less connection error, which the classifier cannot
				 * call permanent, so the auto-approval retry loop backs off
				 * exponentially and retries forever — a hang, not a failure.
				 *
				 * The bound counts consecutive failures and gives up loudly. The
				 * classifier (fast path) still short-circuits the shapes it knows,
				 * on the FIRST attempt.
				 */
				const failingStream = (error: Error) =>
					// eslint-disable-next-line require-yield
					(async function* (): AsyncGenerator<ApiStreamChunk> {
						throw error
					})()

				const succeedingStream = () =>
					(async function* (): AsyncGenerator<ApiStreamChunk> {
						yield { type: "text", text: "ok" }
					})()

				const makeTask = (maxConsecutiveApiFailures: number) => {
					const shofer = new Task({
						provider: mockProvider,
						apiConfiguration: mockApiConfig,
						task: "test task",
						startTask: false,
					})
					vi.spyOn(shofer as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

					mockProvider.getState = vi.fn().mockResolvedValue({
						autoApprovalEnabled: true,
						requestDelaySeconds: 1,
						maxConsecutiveApiFailures,
						mcpEnabled: false,
						apiConfiguration: mockApiConfig,
						customModes: BUILTIN_MODES,
					})

					return shofer
				}

				const drain = async (stream: AsyncGenerator<ApiStreamChunk>) => {
					const chunks: ApiStreamChunk[] = []
					for await (const chunk of stream) {
						chunks.push(chunk)
					}
					return chunks
				}

				it("gives up after the configured number of consecutive connection failures, quoting the provider error", async () => {
					const shofer = makeTask(3)

					// The exact wrapper text a provider produces for an unreachable
					// model endpoint — no status field anywhere on it.
					const connectionError = new Error("OpenRouter completion error: Connection error.")
					const createMessageSpy = vi
						.spyOn(shofer.api, "createMessage")
						.mockImplementation(() => failingStream(connectionError))

					await expect(drain(shofer.attemptApiRequest(0))).rejects.toThrow(
						/failed 3 times in a row \(limit 3\); giving up/,
					)

					// The provider's own error is quoted, not swallowed: a headless
					// controller has to be able to see WHY.
					await expect(drain(shofer.attemptApiRequest(0))).rejects.toThrow(
						/Last error: OpenRouter completion error: Connection error\./,
					)

					// Three attempts for the first give-up; the second call starts
					// from an already-exhausted streak and stops immediately.
					expect(createMessageSpy).toHaveBeenCalledTimes(4)
				})

				it("resets the streak when a request completes successfully", async () => {
					const shofer = makeTask(3)

					const connectionError = new Error("OpenRouter completion error: Connection error.")
					let call = 0
					// fail, fail, succeed | fail, fail, succeed — with the limit at 3
					// this only survives if the successful request cleared the count.
					const createMessageSpy = vi.spyOn(shofer.api, "createMessage").mockImplementation(() => {
						call++
						return call === 3 || call === 6 ? succeedingStream() : failingStream(connectionError)
					})

					expect(await drain(shofer.attemptApiRequest(0))).toEqual([{ type: "text", text: "ok" }])
					expect(await drain(shofer.attemptApiRequest(0))).toEqual([{ type: "text", text: "ok" }])
					expect(createMessageSpy).toHaveBeenCalledTimes(6)
				})

				it("fails a 401 on the FIRST attempt, without consuming the budget", async () => {
					const shofer = makeTask(3)

					const authError = Object.assign(new Error("OpenRouter completion error: No auth credentials"), {
						status: 401,
					})
					const createMessageSpy = vi
						.spyOn(shofer.api, "createMessage")
						.mockImplementation(() => failingStream(authError))
					const saySpy = vi.spyOn(shofer, "say")

					await expect(drain(shofer.attemptApiRequest(0))).rejects.toThrow(/No auth credentials/)

					expect(createMessageSpy).toHaveBeenCalledTimes(1)
					// No backoff countdown was announced — it never entered the loop.
					expect(saySpy.mock.calls.filter((c) => c[0] === "api_req_retry_delayed")).toHaveLength(0)
				})

				it("fails a proxy-denied CONNECT on the FIRST attempt (classifier, not bound)", async () => {
					const shofer = makeTask(3)

					// The squid-refusal chain: status-less at the top, the 403 only
					// in undici's message three `cause` hops down.
					const undiciAborted = Object.assign(new Error("Proxy response (403) !== 200 when HTTP Tunneling"), {
						name: "AbortError",
						code: "UND_ERR_ABORTED",
					})
					const proxyRefusal = Object.assign(new Error("OpenRouter completion error: Connection error."), {
						cause: new TypeError("fetch failed", { cause: undiciAborted }),
					})
					const createMessageSpy = vi
						.spyOn(shofer.api, "createMessage")
						.mockImplementation(() => failingStream(proxyRefusal))

					await expect(drain(shofer.attemptApiRequest(0))).rejects.toThrow(/Connection error/)
					expect(createMessageSpy).toHaveBeenCalledTimes(1)
				})
			})

			describe("processUserContentMentions", () => {
				it("should process mentions in user_message tags", async () => {
					const [shofer, task] = Task.create({
						provider: mockProvider,
						apiConfiguration: mockApiConfig,
						task: "test task",
					})

					const userContent = [
						{
							type: "text",
							text: "Regular text with 'some/path' (see below for file content)",
						} as const,
						{
							type: "text",
							text: "<user_message>Text with 'some/path' (see below for file content) in user_message tags</user_message>",
						} as const,
						{
							type: "tool_result",
							tool_use_id: "test-id",
							content: [
								{
									type: "text",
									text: "<user_message>Check 'some/path' (see below for file content)</user_message>",
								},
							],
						} as Anthropic.ToolResultBlockParam,
						{
							type: "tool_result",
							tool_use_id: "test-id-2",
							content: [
								{
									type: "text",
									text: "Regular tool result with 'path' (see below for file content)",
								},
							],
						} as Anthropic.ToolResultBlockParam,
					]

					const { content: processedContent } = await processUserContentMentions({
						userContent,
						cwd: shofer.cwd,
						fileContextTracker: shofer.fileContextTracker,
					})

					// Regular text should not be processed
					expect((processedContent[0] as Anthropic.TextBlockParam).text).toBe(
						"Regular text with 'some/path' (see below for file content)",
					)

					// Text within user_message tags should be processed
					expect((processedContent[1] as Anthropic.TextBlockParam).text).toContain("processed:")
					expect((processedContent[1] as Anthropic.TextBlockParam).text).toContain(
						"<user_message>Text with 'some/path' (see below for file content) in user_message tags</user_message>",
					)

					// user_message tag content should be processed
					const toolResult1 = processedContent[2] as Anthropic.ToolResultBlockParam
					const content1 = Array.isArray(toolResult1.content) ? toolResult1.content[0] : toolResult1.content
					expect((content1 as Anthropic.TextBlockParam).text).toContain("processed:")
					expect((content1 as Anthropic.TextBlockParam).text).toContain(
						"<user_message>Check 'some/path' (see below for file content)</user_message>",
					)

					// Regular tool result should not be processed
					const toolResult2 = processedContent[3] as Anthropic.ToolResultBlockParam
					const content2 = Array.isArray(toolResult2.content) ? toolResult2.content[0] : toolResult2.content
					expect((content2 as Anthropic.TextBlockParam).text).toBe(
						"Regular tool result with 'path' (see below for file content)",
					)

					await shofer.abortTask(true)
					await task.catch(() => {})
				})
			})
		})

		describe("Subtask Rate Limiting", () => {
			let mockProvider: any
			let mockApiConfig: any
			let mockDelay: ReturnType<typeof vi.fn>

			beforeEach(() => {
				vi.clearAllMocks()
				// Reset the global timestamp before each test
				Task.resetGlobalApiRequestTime()

				mockApiConfig = {
					apiProvider: "anthropic",
					apiKey: "test-key",
					rateLimitSeconds: 5,
				}

				mockProvider = {
					context: {
						globalStorageUri: { fsPath: "/test/storage" },
						globalState: {
							get: vi.fn().mockImplementation(() => undefined),
							update: vi.fn().mockResolvedValue(undefined),
							keys: vi.fn().mockReturnValue([]),
						},
					},
					getState: vi.fn().mockResolvedValue({
						apiConfiguration: mockApiConfig,
						mcpEnabled: false,
						customModes: BUILTIN_MODES,
					}),
					getMcpHub: vi.fn().mockReturnValue(undefined),
					getSkillsManager: vi.fn().mockReturnValue(undefined),
					getCurrentTask: vi.fn().mockReturnValue(undefined),
					taskManager: { getFocusedTaskId: vi.fn().mockReturnValue(undefined) },
					say: vi.fn(),
					postMessageToWebview: vi.fn().mockResolvedValue(undefined),
					updateTaskHistory: vi.fn().mockResolvedValue(undefined),
				}

				// Get the mocked delay function
				mockDelay = delay as ReturnType<typeof vi.fn>
				mockDelay.mockClear()
			})

			afterEach(() => {
				// Clean up the global state after each test
				Task.resetGlobalApiRequestTime()
			})

			it("should enforce rate limiting across parent and subtask", async () => {
				// Add a spy to track getState calls
				const getStateSpy = vi.spyOn(mockProvider, "getState")

				// Create parent task
				const parent = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "parent task",
					startTask: false,
				})
				vi.spyOn(parent as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the API stream response
				const mockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "parent response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "parent response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(parent.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the parent task
				const parentIterator = parent.attemptApiRequest(0)
				await parentIterator.next()

				// Verify no delay was applied for the first request
				expect(mockDelay).not.toHaveBeenCalled()

				// Create a subtask immediately after
				const child = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "child task",
					parentTask: parent,
					rootTask: parent,
					startTask: false,
				})
				vi.spyOn(child as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Spy on child.say to verify the emitted message type
				const saySpy = vi.spyOn(child, "say")

				// Mock the child's API stream
				const childMockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "child response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "child response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(child.api, "createMessage").mockReturnValue(childMockStream)

				// Make an API request with the child task
				const childIterator = child.attemptApiRequest(0)
				await childIterator.next()

				// Verify rate limiting was applied
				expect(mockDelay).toHaveBeenCalledTimes(mockApiConfig.rateLimitSeconds)
				expect(mockDelay).toHaveBeenCalledWith(1000)

				// Verify we used the non-error rate-limit wait message type (JSON format)
				expect(saySpy).toHaveBeenCalledWith(
					"api_req_rate_limit_wait",
					expect.stringMatching(/\{"seconds":\d+\}/),
					undefined,
					true,
				)

				// Verify the wait message was finalized
				expect(saySpy).toHaveBeenCalledWith("api_req_rate_limit_wait", undefined, undefined, false)
			}, 10000) // Increase timeout to 10 seconds

			it("should not apply rate limiting if enough time has passed", async () => {
				// Create parent task
				const parent = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "parent task",
					startTask: false,
				})
				vi.spyOn(parent as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the API stream response
				const mockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(parent.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the parent task
				const parentIterator = parent.attemptApiRequest(0)
				await parentIterator.next()

				// Simulate time passing (more than rate limit)
				const originalPerformanceNow = performance.now
				const mockTime = performance.now() + (mockApiConfig.rateLimitSeconds + 1) * 1000
				performance.now = vi.fn(() => mockTime)

				// Create a subtask after time has passed
				const child = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "child task",
					parentTask: parent,
					rootTask: parent,
					startTask: false,
				})
				vi.spyOn(child as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				vi.spyOn(child.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the child task
				const childIterator = child.attemptApiRequest(0)
				await childIterator.next()

				// Verify no rate limiting was applied
				expect(mockDelay).not.toHaveBeenCalled()

				// Restore performance.now
				performance.now = originalPerformanceNow
			})

			it("should share rate limiting across multiple subtasks", async () => {
				// Create parent task
				const parent = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "parent task",
					startTask: false,
				})
				vi.spyOn(parent as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the API stream response
				const mockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(parent.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the parent task
				const parentIterator = parent.attemptApiRequest(0)
				await parentIterator.next()

				// Create first subtask
				const child1 = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "child task 1",
					parentTask: parent,
					rootTask: parent,
					startTask: false,
				})
				vi.spyOn(child1 as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				vi.spyOn(child1.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the first child task
				const child1Iterator = child1.attemptApiRequest(0)
				await child1Iterator.next()

				// Verify rate limiting was applied
				const firstDelayCount = mockDelay.mock.calls.length
				expect(firstDelayCount).toBe(mockApiConfig.rateLimitSeconds)

				// Clear the mock to count new delays
				mockDelay.mockClear()

				// Create second subtask immediately after
				const child2 = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "child task 2",
					parentTask: parent,
					rootTask: parent,
					startTask: false,
				})
				vi.spyOn(child2 as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				vi.spyOn(child2.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the second child task
				const child2Iterator = child2.attemptApiRequest(0)
				await child2Iterator.next()

				// Verify rate limiting was applied again
				expect(mockDelay).toHaveBeenCalledTimes(mockApiConfig.rateLimitSeconds)
			}, 15000) // Increase timeout to 15 seconds

			it("should handle rate limiting with zero rate limit", async () => {
				// Update config to have zero rate limit
				mockApiConfig.rateLimitSeconds = 0
				mockProvider.getState.mockResolvedValue({
					apiConfiguration: mockApiConfig,
					mcpEnabled: false,
					customModes: BUILTIN_MODES,
				})

				// Create parent task
				const parent = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "parent task",
					startTask: false,
				})
				vi.spyOn(parent as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the API stream response
				const mockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(parent.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the parent task
				const parentIterator = parent.attemptApiRequest(0)
				await parentIterator.next()

				// Create a subtask
				const child = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "child task",
					parentTask: parent,
					rootTask: parent,
					startTask: false,
				})
				vi.spyOn(child as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				vi.spyOn(child.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request with the child task
				const childIterator = child.attemptApiRequest(0)
				await childIterator.next()

				// Verify no delay was applied
				expect(mockDelay).not.toHaveBeenCalled()
			})

			it("should update global timestamp even when no rate limiting is needed", async () => {
				// Create task
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})
				vi.spyOn(task as any, "getSystemPrompt").mockResolvedValue("mock system prompt")

				// Mock the API stream response
				const mockStream = {
					async *[Symbol.asyncIterator]() {
						yield { type: "text", text: "response" }
					},
					async next() {
						return { done: true, value: { type: "text", text: "response" } }
					},
					async return() {
						return { done: true, value: undefined }
					},
					async throw(e: any) {
						throw e
					},
					[Symbol.asyncDispose]: async () => {},
				} as AsyncGenerator<ApiStreamChunk>

				vi.spyOn(task.api, "createMessage").mockReturnValue(mockStream)

				// Make an API request
				const iterator = task.attemptApiRequest(0)
				await iterator.next()

				// Access the private static property via reflection for testing
				const globalTimestamp = (Task as any).lastGlobalApiRequestTime
				expect(globalTimestamp).toBeDefined()
				expect(globalTimestamp).toBeGreaterThan(0)
			})
		})

		describe("Dynamic Strategy Selection", () => {
			let mockProvider: any
			let mockApiConfig: any

			beforeEach(() => {
				vi.clearAllMocks()

				mockApiConfig = {
					apiProvider: "anthropic",
					apiKey: "test-key",
				}

				mockProvider = {
					context: {
						globalStorageUri: { fsPath: "/test/storage" },
					},
					getState: vi.fn(),
				}
			})

			it("should use MultiSearchReplaceDiffStrategy by default", async () => {
				mockProvider.getState.mockResolvedValue({})

				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Should be MultiSearchReplaceDiffStrategy
				expect(task.diffStrategy).toBeInstanceOf(MultiSearchReplaceDiffStrategy)
				expect(task.diffStrategy?.getName()).toBe("MultiSearchReplace")
			})

			it("should keep MultiSearchReplaceDiffStrategy when experiments are undefined", async () => {
				mockProvider.getState.mockResolvedValue({})

				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Initially should be MultiSearchReplaceDiffStrategy
				expect(task.diffStrategy).toBeInstanceOf(MultiSearchReplaceDiffStrategy)

				// Wait for async strategy update
				await new Promise((resolve) => setTimeout(resolve, 10))

				// Should still be MultiSearchReplaceDiffStrategy
				expect(task.diffStrategy).toBeInstanceOf(MultiSearchReplaceDiffStrategy)
				expect(task.diffStrategy?.getName()).toBe("MultiSearchReplace")
			})
		})

		describe("getApiProtocol", () => {
			it("should determine API protocol based on provider and model", async () => {
				// Test with Anthropic provider
				const anthropicConfig = {
					...mockApiConfig,
					apiProvider: "anthropic" as const,
					apiModelId: "gpt-4",
				}
				const anthropicTask = new Task({
					provider: mockProvider,
					apiConfiguration: anthropicConfig,
					task: "test task",
					startTask: false,
				})
				// Should use anthropic protocol even with non-claude model
				expect(anthropicTask.apiConfiguration.apiProvider).toBe("anthropic")

				// Test with OpenRouter provider and Claude model
				const openrouterClaudeConfig = {
					apiProvider: "openrouter" as const,
					openRouterModelId: "anthropic/claude-3-opus",
				}
				const openrouterClaudeTask = new Task({
					provider: mockProvider,
					apiConfiguration: openrouterClaudeConfig,
					task: "test task",
					startTask: false,
				})
				expect(openrouterClaudeTask.apiConfiguration.apiProvider).toBe("openrouter")

				// Test with OpenRouter provider and non-Claude model
				const openrouterGptConfig = {
					apiProvider: "openrouter" as const,
					openRouterModelId: "openai/gpt-4",
				}
				const openrouterGptTask = new Task({
					provider: mockProvider,
					apiConfiguration: openrouterGptConfig,
					task: "test task",
					startTask: false,
				})
				expect(openrouterGptTask.apiConfiguration.apiProvider).toBe("openrouter")

				// Test with various Claude model formats
				const claudeModelFormats = [
					"claude-3-opus",
					"Claude-3-Sonnet",
					"CLAUDE-instant",
					"anthropic/claude-3-haiku",
					"some-provider/claude-model",
				]

				for (const modelId of claudeModelFormats) {
					const config = {
						apiProvider: "openai" as const,
						openAiModelId: modelId,
					}
					const task = new Task({
						provider: mockProvider,
						apiConfiguration: config,
						task: "test task",
						startTask: false,
					})
					// Verify the model ID contains claude (case-insensitive)
					expect(modelId.toLowerCase()).toContain("claude")
				}
			})

			it("should handle edge cases for API protocol detection", async () => {
				// Test with undefined provider
				const undefinedProviderConfig = {
					apiModelId: "claude-3-opus",
				}
				const undefinedProviderTask = new Task({
					provider: mockProvider,
					apiConfiguration: undefinedProviderConfig,
					task: "test task",
					startTask: false,
				})
				expect(undefinedProviderTask.apiConfiguration.apiProvider).toBeUndefined()

				// Test with no model ID
				const noModelConfig = {
					apiProvider: "openai" as const,
				}
				const noModelTask = new Task({
					provider: mockProvider,
					apiConfiguration: noModelConfig,
					task: "test task",
					startTask: false,
				})
				expect(noModelTask.apiConfiguration.apiProvider).toBe("openai")
			})
		})

		describe("submitUserMessage", () => {
			it("should call handleWebviewAskResponse directly", async () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "initial task",
					startTask: false,
				})

				// Spy on handleWebviewAskResponse
				const handleResponseSpy = vi.spyOn(task, "handleWebviewAskResponse")

				// Set up some existing messages to simulate an ongoing conversation
				task.shoferMessages = [
					{
						ts: Date.now(),
						type: "say",
						say: "text",
						text: "Initial message",
					},
				]

				// Clear any calls made during provider/task initialization (e.g. McpServerManager
				// resolves between beforeEach and the test, posting mcpServers to the webview).
				mockProvider.postMessageToWebview.mockClear()

				// Call submitUserMessage
				task.submitUserMessage("test message", ["image1.png"])

				// Verify handleWebviewAskResponse was called directly (not webview)
				expect(handleResponseSpy).toHaveBeenCalledWith(
					"messageResponse",
					"test message",
					["image1.png"],
					undefined,
					undefined,
				)
				// Should NOT route through webview anymore
				expect(mockProvider.postMessageToWebview).not.toHaveBeenCalled()
			})

			it("should handle empty messages gracefully", async () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "initial task",
					startTask: false,
				})

				// Spy on handleWebviewAskResponse
				const handleResponseSpy = vi.spyOn(task, "handleWebviewAskResponse")

				// Call with empty text and no images
				task.submitUserMessage("", [])

				// Should not call handleWebviewAskResponse for empty messages
				expect(handleResponseSpy).not.toHaveBeenCalled()

				// Call with whitespace only
				task.submitUserMessage("   ", [])
				expect(handleResponseSpy).not.toHaveBeenCalled()
			})

			it("should call handleWebviewAskResponse for both new and existing task states", async () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "initial task",
					startTask: false,
				})

				// Spy on handleWebviewAskResponse
				const handleResponseSpy = vi.spyOn(task, "handleWebviewAskResponse")

				// Test with no messages (new task scenario)
				task.shoferMessages = []
				task.submitUserMessage("new task", ["image1.png"])

				expect(handleResponseSpy).toHaveBeenCalledWith(
					"messageResponse",
					"new task",
					["image1.png"],
					undefined,
					undefined,
				)

				// Clear mock
				handleResponseSpy.mockClear()

				// Test with existing messages (ongoing task scenario)
				task.shoferMessages = [
					{
						ts: Date.now(),
						type: "say",
						say: "text",
						text: "Initial message",
					},
				]
				task.submitUserMessage("follow-up message", ["image2.png"])

				expect(handleResponseSpy).toHaveBeenCalledWith(
					"messageResponse",
					"follow-up message",
					["image2.png"],
					undefined,
					undefined,
				)
			})

			it("should handle undefined provider gracefully", async () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "initial task",
					startTask: false,
				})

				// Spy on handleWebviewAskResponse
				const handleResponseSpy = vi.spyOn(task, "handleWebviewAskResponse")

				// Simulate weakref returning undefined
				Object.defineProperty(task, "providerRef", {
					value: { deref: () => undefined },
					writable: false,
					configurable: true,
				})

				// Should log error but not throw
				task.submitUserMessage("test message")

				expect(handleResponseSpy).not.toHaveBeenCalled()
			})
		})
	})

	describe("abortTask", () => {
		it("should set abort flag and emit TaskAborted event", async () => {
			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Spy on emit method
			const emitSpy = vi.spyOn(task, "emit")

			// Mock the dispose method to avoid actual cleanup
			vi.spyOn(task, "dispose").mockImplementation(() => {})

			// Call abortTask
			await task.abortTask()

			// Verify abort flag is set
			expect(task.abort).toBe(true)

			// Verify TaskAborted event was emitted with a reason payload
			expect(emitSpy).toHaveBeenCalledWith("taskAborted", expect.objectContaining({ reason: expect.any(String) }))
		})

		it("should be equivalent to clicking Cancel button functionality", async () => {
			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Mock the dispose method to track cleanup
			const disposeSpy = vi.spyOn(task, "dispose").mockImplementation(() => {})

			// Call abortTask
			await task.abortTask()

			// Verify the same behavior as Cancel button
			expect(task.abort).toBe(true)
			expect(disposeSpy).toHaveBeenCalled()
		})

		it("should work with TaskLike interface", async () => {
			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Cast to TaskLike to ensure interface compliance
			const taskLike = task as any // TaskLike interface from types package

			// Verify abortTask method exists and is callable
			expect(typeof taskLike.abortTask).toBe("function")

			// Mock the dispose method to avoid actual cleanup
			vi.spyOn(task, "dispose").mockImplementation(() => {})

			// Call abortTask through interface
			await taskLike.abortTask()

			// Verify it works
			expect(task.abort).toBe(true)
		})

		it("should handle errors during disposal gracefully", async () => {
			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Mock dispose to throw an error
			const mockError = new Error("Disposal failed")
			vi.spyOn(task, "dispose").mockImplementation(() => {
				throw mockError
			})

			// abortTask should not throw even if dispose fails
			await expect(task.abortTask()).resolves.not.toThrow()

			// Verify abort flag is still set
			expect(task.abort).toBe(true)
		})
		describe("Stream Failure Retry", () => {
			it("should not abort task on stream failure, only on user cancellation", async () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Spy on abortTask to verify it's NOT called for stream failures
				const abortTaskSpy = vi.spyOn(task, "abortTask").mockResolvedValue(undefined)

				// Test Case 1: Stream failure should NOT abort task
				task.abort = false
				task.abandoned = false

				// Simulate the catch block behavior for stream failure
				const streamFailureError = new Error("Stream failed mid-execution")

				// The key assertion: verify that when abort=false, abortTask is NOT called
				const shouldAbort = task.abort
				expect(shouldAbort).toBe(false)

				// Verify abortTask was NOT called
				expect(abortTaskSpy).not.toHaveBeenCalled()

				// Test Case 2: User cancellation SHOULD abort task
				task.abort = true

				// For user cancellation, abortTask SHOULD be called
				if (task.abort) {
					await task.abortTask()
				}

				expect(abortTaskSpy).toHaveBeenCalled()
			})
		})

		describe("cancelCurrentRequest", () => {
			it("should cancel the current HTTP request via AbortController", () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Create a real AbortController and spy on its abort method
				const mockAbortController = new AbortController()
				const abortSpy = vi.spyOn(mockAbortController, "abort")
				task.currentRequestAbortController = mockAbortController

				// Call cancelCurrentRequest
				task.cancelCurrentRequest()

				// Verify abort was called on the controller
				expect(abortSpy).toHaveBeenCalled()

				// Verify the controller was cleared
				expect(task.currentRequestAbortController).toBeUndefined()

				// Verify logging
			})

			it("should handle missing AbortController gracefully", () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Ensure no controller exists
				task.currentRequestAbortController = undefined

				// Should not throw when called with no controller
				expect(() => task.cancelCurrentRequest()).not.toThrow()
			})

			it("should be called during dispose", () => {
				const task = new Task({
					provider: mockProvider,
					apiConfiguration: mockApiConfig,
					task: "test task",
					startTask: false,
				})

				// Spy on cancelCurrentRequest
				const cancelSpy = vi.spyOn(task, "cancelCurrentRequest")

				// Mock other dispose operations
				vi.spyOn(task.messageQueueService, "removeListener").mockImplementation(
					() => task.messageQueueService as any,
				)
				vi.spyOn(task.messageQueueService, "dispose").mockImplementation(() => {})
				vi.spyOn(task, "removeAllListeners").mockImplementation(() => task as any)

				// Call dispose
				task.dispose()

				// Verify cancelCurrentRequest was called
				expect(cancelSpy).toHaveBeenCalled()
			})
		})
	})

	describe("start()", () => {
		it("should be a no-op if the task was already started in the constructor", () => {
			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: false,
			})

			// Manually trigger start
			const startTaskSpy = vi.spyOn(task as any, "startTask").mockImplementation(async () => {})
			task.start()

			expect(startTaskSpy).toHaveBeenCalledTimes(1)

			// Calling start() again should be a no-op
			task.start()
			expect(startTaskSpy).toHaveBeenCalledTimes(1)
		})

		it("should not call startTask if already started via constructor", () => {
			// Create a task that starts immediately (startTask defaults to true)
			// but mock startTask to prevent actual execution
			const startTaskSpy = vi.spyOn(Task.prototype as any, "startTask").mockImplementation(async () => {})

			const task = new Task({
				provider: mockProvider,
				apiConfiguration: mockApiConfig,
				task: "test task",
				startTask: true,
			})

			// startTask was called by the constructor
			expect(startTaskSpy).toHaveBeenCalledTimes(1)

			// Calling start() should be a no-op since _started is already true
			task.start()
			expect(startTaskSpy).toHaveBeenCalledTimes(1)

			startTaskSpy.mockRestore()
		})
	})
})

describe("Queued message processing after condense", () => {
	function createProvider(): any {
		const storageUri = { fsPath: path.join(os.tmpdir(), "test-storage") }
		return {
			context: {
				globalStorageUri: storageUri,
				extensionUri: { fsPath: "/mock/extension/path" },
				extension: { packageJSON: { version: "1.0.0" } },
			},
			getState: vi.fn().mockResolvedValue({ customModes: BUILTIN_MODES }),
			log: vi.fn(),
			on: vi.fn(),
			off: vi.fn(),
			postTaskStateUpdate: vi.fn(),
			getCurrentTask: vi.fn().mockReturnValue(undefined),
			updateTaskHistory: vi.fn().mockResolvedValue(undefined),
			postMessageToWebview: vi.fn().mockResolvedValue(undefined),
			getSkillsManager: vi.fn().mockReturnValue(undefined),
			getMcpHub: vi.fn().mockReturnValue(undefined),
			taskManager: { getFocusedTaskId: vi.fn().mockReturnValue(undefined) },
			say: vi.fn(),
		}
	}

	const apiConfig: ProviderSettings = {
		apiProvider: "anthropic",
		apiModelId: "claude-3-5-sonnet-20241022",
		apiKey: "test-api-key",
	} as any

	it("processes queued message after condense completes", async () => {
		const provider = createProvider()
		const task = new Task({
			provider,
			apiConfiguration: apiConfig,
			task: "initial task",
			startTask: false,
		})

		// Make condense fast + deterministic
		vi.spyOn(task as any, "getSystemPrompt").mockResolvedValue("system")
		const submitSpy = vi.spyOn(task, "submitUserMessage").mockResolvedValue(undefined)

		// Queue a message during condensing
		task.messageQueueService.addMessage("queued text", ["img1.png"])

		// Use fake timers to capture setTimeout(0) in processQueuedMessages
		vi.useFakeTimers()
		await task.condenseContext()

		// Flush the microtask that submits the queued message
		vi.runAllTimers()
		vi.useRealTimers()

		expect(submitSpy).toHaveBeenCalledWith("queued text", ["img1.png"])
		expect(task.messageQueueService.isEmpty()).toBe(true)
	})

	it("does not cross-drain queues between separate tasks", async () => {
		const providerA = createProvider()
		const providerB = createProvider()

		const taskA = new Task({
			provider: providerA,
			apiConfiguration: apiConfig,
			task: "task A",
			startTask: false,
		})
		const taskB = new Task({
			provider: providerB,
			apiConfiguration: apiConfig,
			task: "task B",
			startTask: false,
		})

		vi.spyOn(taskA as any, "getSystemPrompt").mockResolvedValue("system")
		vi.spyOn(taskB as any, "getSystemPrompt").mockResolvedValue("system")

		const spyA = vi.spyOn(taskA, "submitUserMessage").mockResolvedValue(undefined)
		const spyB = vi.spyOn(taskB, "submitUserMessage").mockResolvedValue(undefined)

		taskA.messageQueueService.addMessage("A message")
		taskB.messageQueueService.addMessage("B message")

		// Condense in task A should only drain A's queue
		vi.useFakeTimers()
		await taskA.condenseContext()
		vi.runAllTimers()
		vi.useRealTimers()

		expect(spyA).toHaveBeenCalledWith("A message", undefined)
		expect(spyB).not.toHaveBeenCalled()
		expect(taskB.messageQueueService.isEmpty()).toBe(false)

		// Now condense in task B should drain B's queue
		vi.useFakeTimers()
		await taskB.condenseContext()
		vi.runAllTimers()
		vi.useRealTimers()

		expect(spyB).toHaveBeenCalledWith("B message", undefined)
		expect(taskB.messageQueueService.isEmpty()).toBe(true)
	})
})

describe("pushToolResultToUserContent", () => {
	let mockProvider: any
	let mockApiConfig: ProviderSettings

	beforeEach(() => {
		mockApiConfig = {
			apiProvider: "anthropic",
			apiModelId: "claude-3-5-sonnet-20241022",
			apiKey: "test-api-key",
		}

		const storageUri = { fsPath: path.join(os.tmpdir(), "test-storage") }
		mockProvider = {
			context: {
				globalStorageUri: storageUri,
				extensionUri: { fsPath: "/mock/extension/path" },
				extension: { packageJSON: { version: "1.0.0" } },
			},
			getState: vi.fn().mockResolvedValue({ mode: "code", experiments: {}, customModes: BUILTIN_MODES }),
			log: vi.fn(),
			on: vi.fn(),
			off: vi.fn(),
			postTaskStateUpdate: vi.fn(),
			getCurrentTask: vi.fn().mockReturnValue(undefined),
			updateTaskHistory: vi.fn().mockResolvedValue(undefined),
			postMessageToWebview: vi.fn().mockResolvedValue(undefined),
			getSkillsManager: vi.fn().mockReturnValue(undefined),
			getMcpHub: vi.fn().mockReturnValue(undefined),
			taskManager: { getFocusedTaskId: vi.fn().mockReturnValue(undefined) },
			say: vi.fn(),
		}
	})

	it("should add tool_result when not a duplicate", () => {
		const task = new Task({
			provider: mockProvider,
			apiConfiguration: mockApiConfig,
			task: "test task",
			startTask: false,
		})

		const toolResult: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "test-id-1",
			content: "Test result",
		}

		const added = task.pushToolResultToUserContent(toolResult)

		expect(added).toBe(true)
		expect(task.userMessageContent).toHaveLength(1)
		expect(task.userMessageContent[0]).toEqual(toolResult)
	})

	it("should prevent duplicate tool_result with same tool_use_id", () => {
		const task = new Task({
			provider: mockProvider,
			apiConfiguration: mockApiConfig,
			task: "test task",
			startTask: false,
		})

		const toolResult1: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "duplicate-id",
			content: "First result",
		}

		const toolResult2: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "duplicate-id",
			content: "Second result (should be skipped)",
		}

		// Add first result - should succeed
		const added1 = task.pushToolResultToUserContent(toolResult1)
		expect(added1).toBe(true)
		expect(task.userMessageContent).toHaveLength(1)

		// Add second result with same ID - should be skipped
		const added2 = task.pushToolResultToUserContent(toolResult2)
		expect(added2).toBe(false)
		expect(task.userMessageContent).toHaveLength(1)

		// Verify only the first result is in the array
		expect(task.userMessageContent[0]).toEqual(toolResult1)
	})

	it("should allow different tool_use_ids to be added", () => {
		const task = new Task({
			provider: mockProvider,
			apiConfiguration: mockApiConfig,
			task: "test task",
			startTask: false,
		})

		const toolResult1: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "id-1",
			content: "Result 1",
		}

		const toolResult2: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "id-2",
			content: "Result 2",
		}

		const added1 = task.pushToolResultToUserContent(toolResult1)
		const added2 = task.pushToolResultToUserContent(toolResult2)

		expect(added1).toBe(true)
		expect(added2).toBe(true)
		expect(task.userMessageContent).toHaveLength(2)
		expect(task.userMessageContent[0]).toEqual(toolResult1)
		expect(task.userMessageContent[1]).toEqual(toolResult2)
	})

	it("should handle tool_result with is_error flag", () => {
		const task = new Task({
			provider: mockProvider,
			apiConfiguration: mockApiConfig,
			task: "test task",
			startTask: false,
		})

		const errorResult: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "error-id",
			content: "Error message",
			is_error: true,
		}

		const added = task.pushToolResultToUserContent(errorResult)

		expect(added).toBe(true)
		expect(task.userMessageContent).toHaveLength(1)
		expect(task.userMessageContent[0]).toEqual(errorResult)
	})

	it("should not interfere with other content types in userMessageContent", () => {
		const task = new Task({
			provider: mockProvider,
			apiConfiguration: mockApiConfig,
			task: "test task",
			startTask: false,
		})

		// Add text and image blocks manually
		task.userMessageContent.push(
			{ type: "text", text: "Some text" },
			{ type: "image", source: { type: "base64", media_type: "image/png", data: "base64data" } },
		)

		const toolResult: Anthropic.ToolResultBlockParam = {
			type: "tool_result",
			tool_use_id: "test-id",
			content: "Result",
		}

		const added = task.pushToolResultToUserContent(toolResult)

		expect(added).toBe(true)
		expect(task.userMessageContent).toHaveLength(3)
		expect(task.userMessageContent[0]!.type).toBe("text")
		expect(task.userMessageContent[1]!.type).toBe("image")
		expect(task.userMessageContent[2]).toEqual(toolResult)
	})
})
