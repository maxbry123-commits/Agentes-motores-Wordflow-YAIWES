import { describe, it, expect, vi, beforeEach } from "vitest"
import type { ProviderSettings, ModelInfo, TaskProviderLike } from "@shofer/types"
import { setHost, createInMemoryHost } from "@shofer/types"
import { TelemetryService } from "@shofer/telemetry"

// All vi.mock() calls are hoisted to the top of the file by Vitest
// and are applied before any imports are resolved.
//
// Task and its deps all live in @shofer/core and call each other via intra-package
// RELATIVE imports, so a barrel `vi.mock("@shofer/core")` cannot intercept them.
// We stub Task's concrete relative-imported deps instead.

// Noop ignore controller so constructing a Task doesn't spin up the real file watcher.
vi.mock("../../ignore/ShoferIgnoreController.js", () => ({
	ShoferIgnoreController: class {
		validateAccess() {
			return true
		}
		validateCommand() {
			return undefined
		}
		filterPaths(paths: string[]) {
			return paths
		}
		getInstructions() {
			return undefined
		}
		async initialize() {}
		dispose() {}
	},
}))

// Storage path helpers (relocated into @shofer/core/utils/storage).
vi.mock("../../utils/storage.js", async (importOriginal) => ({
	...((await importOriginal()) as Record<string, unknown>),
	getTaskDirectoryPath: vi
		.fn()
		.mockImplementation((globalStoragePath, taskId) => Promise.resolve(`${globalStoragePath}/tasks/${taskId}`)),
	getSettingsDirectoryPath: vi
		.fn()
		.mockImplementation((globalStoragePath) => Promise.resolve(`${globalStoragePath}/settings`)),
}))

// Mock delay to prevent actual delays
vi.mock("delay", () => ({
	__esModule: true,
	default: vi.fn().mockResolvedValue(undefined),
}))

// Mock p-wait-for to prevent hanging on async conditions
vi.mock("p-wait-for", () => ({
	default: vi.fn().mockResolvedValue(undefined),
}))

// Mock execa
vi.mock("execa", () => ({
	execa: vi.fn(),
}))

// Mock fs/promises
vi.mock("fs/promises", () => ({
	mkdir: vi.fn().mockResolvedValue(undefined),
	writeFile: vi.fn().mockResolvedValue(undefined),
	appendFile: vi.fn().mockResolvedValue(undefined),
	rename: vi.fn().mockResolvedValue(undefined),
	readFile: vi.fn().mockResolvedValue("[]"),
	unlink: vi.fn().mockResolvedValue(undefined),
	rmdir: vi.fn().mockResolvedValue(undefined),
	// H13: jsonlLog.ts uses fs.open for long-lived append handles.
	open: vi.fn().mockResolvedValue({
		write: vi.fn().mockResolvedValue(undefined),
		close: vi.fn().mockResolvedValue(undefined),
	}),
}))

// Import Task AFTER all vi.mock() calls - Vitest hoists mocks so this works
import { Task } from "../Task.js"

describe("Task reasoning preservation", () => {
	let mockProvider: any
	let mockApiConfiguration: ProviderSettings

	beforeEach(() => {
		setHost(createInMemoryHost())
		if (!TelemetryService.hasInstance()) {
			TelemetryService.createInstance([])
		}

		// Plain provider stub typed as TaskProviderLike — never import concrete
		// src classes (ShoferProvider) into a core test.
		mockProvider = {
			postInitState: vi.fn().mockResolvedValue(undefined),
			postConfigUpdate: vi.fn(),
			postTaskStateUpdate: vi.fn(),
			getState: vi.fn().mockResolvedValue({
				mode: "code",
				experiments: {},
			}),
			context: {
				globalStorageUri: { fsPath: "/test/storage" },
				extensionPath: "/test/extension",
			} as any,
			log: vi.fn(),
			updateTaskHistory: vi.fn().mockResolvedValue(undefined),
			postMessageToWebview: vi.fn().mockResolvedValue(undefined),
		}

		mockApiConfiguration = {
			apiProvider: "anthropic",
			apiKey: "test-key",
		} as ProviderSettings
	})

	it("should append reasoning to assistant message when preserveReasoning is true", async () => {
		// Create a task instance
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Mock the API to return a model with preserveReasoning enabled
		const mockModelInfo: ModelInfo = {
			contextWindow: 16000,
			supportsPromptCache: true,
			preserveReasoning: true,
		}

		task.api = {
			getModel: vi.fn().mockReturnValue({
				id: "test-model",
				info: mockModelInfo,
			}),
		} as any

		// Mock the API conversation history
		task.apiConversationHistory = []

		// Simulate adding an assistant message with reasoning
		const assistantMessage = "Here is my response to your question."
		const reasoningMessage = "Let me think about this step by step. First, I need to..."

		// Spy on addToApiConversationHistory
		const addToApiHistorySpy = vi.spyOn(task as any, "addToApiConversationHistory")

		// Simulate what happens in the streaming loop when preserveReasoning is true
		let finalAssistantMessage = assistantMessage
		if (reasoningMessage && task.api.getModel().info.preserveReasoning) {
			finalAssistantMessage = `<think>${reasoningMessage}</think>\n${assistantMessage}`
		}

		await (task as any).addToApiConversationHistory({
			role: "assistant",
			content: [{ type: "text", text: finalAssistantMessage }],
		})

		// Verify that reasoning was prepended in <think> tags to the assistant message
		expect(addToApiHistorySpy).toHaveBeenCalledWith({
			role: "assistant",
			content: [
				{
					type: "text",
					text: "<think>Let me think about this step by step. First, I need to...</think>\nHere is my response to your question.",
				},
			],
		})

		// Verify the API conversation history contains the message with reasoning
		expect(task.apiConversationHistory).toHaveLength(1)
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toContain("<think>")
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toContain("</think>")
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toContain(
			"Here is my response to your question.",
		)
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toContain(
			"Let me think about this step by step. First, I need to...",
		)
	})

	it("should NOT append reasoning to assistant message when preserveReasoning is false", async () => {
		// Create a task instance
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Mock the API to return a model with preserveReasoning disabled (or undefined)
		const mockModelInfo: ModelInfo = {
			contextWindow: 16000,
			supportsPromptCache: true,
			preserveReasoning: false,
		}

		task.api = {
			getModel: vi.fn().mockReturnValue({
				id: "test-model",
				info: mockModelInfo,
			}),
		} as any

		// Mock the API conversation history
		task.apiConversationHistory = []

		// Simulate adding an assistant message with reasoning
		const assistantMessage = "Here is my response to your question."
		const reasoningMessage = "Let me think about this step by step. First, I need to..."

		// Spy on addToApiConversationHistory
		const addToApiHistorySpy = vi.spyOn(task as any, "addToApiConversationHistory")

		// Simulate what happens in the streaming loop when preserveReasoning is false
		let finalAssistantMessage = assistantMessage
		if (reasoningMessage && task.api.getModel().info.preserveReasoning) {
			finalAssistantMessage = `<think>${reasoningMessage}</think>\n${assistantMessage}`
		}

		await (task as any).addToApiConversationHistory({
			role: "assistant",
			content: [{ type: "text", text: finalAssistantMessage }],
		})

		// Verify that reasoning was NOT appended to the assistant message
		expect(addToApiHistorySpy).toHaveBeenCalledWith({
			role: "assistant",
			content: [{ type: "text", text: "Here is my response to your question." }],
		})

		// Verify the API conversation history does NOT contain reasoning
		expect(task.apiConversationHistory).toHaveLength(1)
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toBe(
			"Here is my response to your question.",
		)
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).not.toContain("<think>")
	})

	it("should handle empty reasoning message gracefully when preserveReasoning is true", async () => {
		// Create a task instance
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Mock the API to return a model with preserveReasoning enabled
		const mockModelInfo: ModelInfo = {
			contextWindow: 16000,
			supportsPromptCache: true,
			preserveReasoning: true,
		}

		task.api = {
			getModel: vi.fn().mockReturnValue({
				id: "test-model",
				info: mockModelInfo,
			}),
		} as any

		// Mock the API conversation history
		task.apiConversationHistory = []

		const assistantMessage = "Here is my response."
		const reasoningMessage = "" // Empty reasoning

		// Spy on addToApiConversationHistory
		const addToApiHistorySpy = vi.spyOn(task as any, "addToApiConversationHistory")

		// Simulate what happens in the streaming loop
		let finalAssistantMessage = assistantMessage
		if (reasoningMessage && task.api.getModel().info.preserveReasoning) {
			finalAssistantMessage = `<think>${reasoningMessage}</think>\n${assistantMessage}`
		}

		await (task as any).addToApiConversationHistory({
			role: "assistant",
			content: [{ type: "text", text: finalAssistantMessage }],
		})

		// Verify that no reasoning tags were added when reasoning is empty
		expect(addToApiHistorySpy).toHaveBeenCalledWith({
			role: "assistant",
			content: [{ type: "text", text: "Here is my response." }],
		})

		// Verify the message doesn't contain reasoning tags
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toBe("Here is my response.")
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).not.toContain("<think>")
	})

	it("should handle undefined preserveReasoning (defaults to false)", async () => {
		// Create a task instance
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Mock the API to return a model without preserveReasoning field (undefined)
		const mockModelInfo: ModelInfo = {
			contextWindow: 16000,
			supportsPromptCache: true,
			// preserveReasoning is undefined
		}

		task.api = {
			getModel: vi.fn().mockReturnValue({
				id: "test-model",
				info: mockModelInfo,
			}),
		} as any

		// Mock the API conversation history
		task.apiConversationHistory = []

		const assistantMessage = "Here is my response."
		const reasoningMessage = "Some reasoning here."

		// Simulate what happens in the streaming loop
		let finalAssistantMessage = assistantMessage
		if (reasoningMessage && task.api.getModel().info.preserveReasoning) {
			finalAssistantMessage = `<think>${reasoningMessage}</think>\n${assistantMessage}`
		}

		await (task as any).addToApiConversationHistory({
			role: "assistant",
			content: [{ type: "text", text: finalAssistantMessage }],
		})

		// Verify reasoning was NOT prepended (undefined defaults to false)
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).toBe("Here is my response.")
		expect((task.apiConversationHistory[0]!.content[0] as { text: string }).text).not.toContain("<think>")
	})

	it("should embed encrypted reasoning as first assistant content block", async () => {
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Avoid disk writes in this test
		;(task as any).saveApiConversationHistory = vi.fn().mockResolvedValue(undefined)

		// Mock API handler to provide encrypted reasoning data and response id
		task.api = {
			getEncryptedContent: vi.fn().mockReturnValue({
				encrypted_content: "encrypted_payload",
				id: "rs_test",
			}),
			getResponseId: vi.fn().mockReturnValue("resp_test"),
		} as any

		await (task as any).addToApiConversationHistory({
			role: "assistant",
			content: [{ type: "text", text: "Here is my response." }],
		})

		expect(task.apiConversationHistory).toHaveLength(1)
		const stored = task.apiConversationHistory[0] as any

		expect(stored.role).toBe("assistant")
		expect(Array.isArray(stored.content)).toBe(true)
		expect(stored.id).toBe("resp_test")

		const [reasoningBlock, textBlock] = stored.content

		expect(reasoningBlock).toMatchObject({
			type: "reasoning",
			encrypted_content: "encrypted_payload",
			id: "rs_test",
		})

		expect(textBlock).toMatchObject({
			type: "text",
			text: "Here is my response.",
		})
	})

	it("should store plain text reasoning from streaming for all providers", async () => {
		const task = new Task({
			provider: mockProvider as any,
			apiConfiguration: mockApiConfiguration,
			task: "Test task",
			startTask: false,
		})

		// Avoid disk writes in this test
		;(task as any).saveApiConversationHistory = vi.fn().mockResolvedValue(undefined)

		// Mock API handler without getEncryptedContent (like Anthropic, Gemini, etc.)
		task.api = {
			getModel: vi.fn().mockReturnValue({
				id: "test-model",
				info: {
					contextWindow: 16000,
					supportsPromptCache: true,
				},
			}),
		} as any

		// Simulate the new path: passing reasoning as a parameter
		const reasoningText = "Let me analyze this carefully. First, I'll consider the requirements..."
		const assistantText = "Here is my response."

		await (task as any).addToApiConversationHistory(
			{
				role: "assistant",
				content: [{ type: "text", text: assistantText }],
			},
			reasoningText,
		)

		expect(task.apiConversationHistory).toHaveLength(1)
		const stored = task.apiConversationHistory[0] as any

		expect(stored.role).toBe("assistant")
		expect(Array.isArray(stored.content)).toBe(true)

		const [reasoningBlock, textBlock] = stored.content

		// Verify reasoning is stored with plain text, not encrypted
		expect(reasoningBlock).toMatchObject({
			type: "reasoning",
			text: reasoningText,
			summary: [],
		})

		// Verify there's no encrypted_content field (that's only for OpenAI Native)
		expect(reasoningBlock.encrypted_content).toBeUndefined()

		expect(textBlock).toMatchObject({
			type: "text",
			text: assistantText,
		})
	})
})
