import * as fs from "fs/promises"
import * as fsSync from "fs"
import * as path from "path"
import * as lockfile from "proper-lockfile"
import { JsonStreamStringify } from "json-stream-stringify"

import { fsLog } from "../logging/subsystems.js"

/**
 * Options for safeWriteJson function
 */
export interface SafeWriteJsonOptions {
	/**
	 * Whether to pretty-print the JSON output with indentation.
	 * When true, uses tab characters for indentation.
	 * When false or undefined, outputs compact JSON.
	 * @default false
	 */
	prettyPrint?: boolean
	/**
	 * Pre-serialized JSON string. When provided, the writer skips the
	 * streaming serializer entirely and writes this string verbatim to the
	 * tmp file. Use this when the caller has already produced a synchronous
	 * snapshot of the data (e.g. via `JSON.stringify`) to avoid an extra
	 * O(n) traversal/clone of the in-memory object across an async boundary.
	 *
	 * H6: replaces the `structuredClone` defensive snapshot in
	 * `Task.saveShoferMessages`. The caller is responsible for ensuring the
	 * string is valid JSON; `data` is ignored when this is set but is still
	 * required by the signature for type safety / future-proofing.
	 */
	preSerialized?: string
}
// Module-level per-file write queue. Serializes same-file writes within this process
// so we never race on proper-lockfile from concurrent async callers. The lockfile's
// retry budget (~3.5 s total with default config) is easily exhausted under CPU
// pressure when a write takes longer than expected.
const writeQueues = new Map<string, Promise<void>>()
/**
 * Safely writes JSON data to a file.
 * - Creates parent directories if they don't exist
 * - Uses 'proper-lockfile' for inter-process advisory locking to prevent concurrent writes to the same path.
 * - Writes to a temporary file first.
 * - If the target file exists, it's backed up before being replaced.
 * - Attempts to roll back and clean up in case of errors.
 * - Supports pretty-printing with indentation while maintaining streaming efficiency.
 *
 * @param {string} filePath - The absolute path to the target file.
 * @param {any} data - The data to serialize to JSON and write.
 * @param {SafeWriteJsonOptions} options - Optional configuration for JSON formatting.
 * @returns {Promise<void>}
 */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function safeWriteJson(filePath: string, data: any, options?: SafeWriteJsonOptions): Promise<void> {
	const absoluteFilePath = path.resolve(filePath)

	// Serialize same-file writes within this process. Each caller chains onto the
	// previous promise for that file path so at most one write is executing per path
	// at a time. The proper-lockfile below still handles cross-process protection.
	const prev = writeQueues.get(absoluteFilePath) ?? Promise.resolve()
	let resolver!: () => void
	const next = new Promise<void>((r) => {
		resolver = r
	})
	writeQueues.set(absoluteFilePath, next)

	try {
		await prev
		await _safeWriteJsonLocked(absoluteFilePath, data, options)
	} finally {
		resolver()
		if (writeQueues.get(absoluteFilePath) === next) {
			writeQueues.delete(absoluteFilePath)
		}
	}
}

/** Inner implementation — called only by safeWriteJson after the per-file queue gate. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function _safeWriteJsonLocked(filePath: string, data: any, options?: SafeWriteJsonOptions): Promise<void> {
	const absoluteFilePath = path.resolve(filePath)
	let releaseLock = async () => {} // Initialized to a no-op

	// For directory creation
	const dirPath = path.dirname(absoluteFilePath)

	// Ensure directory structure exists with improved reliability
	try {
		// Create directory with recursive option
		await fs.mkdir(dirPath, { recursive: true })

		// Verify directory exists after creation attempt
		await fs.access(dirPath)
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
	} catch (dirError: any) {
		fsLog.error(`Failed to create or access directory for ${absoluteFilePath}:`, { error: String(dirError) })
		throw dirError
	}

	// Acquire the lock before any file operations
	try {
		releaseLock = await lockfile.lock(absoluteFilePath, {
			stale: 31000, // Stale after 31 seconds
			update: 10000, // Update mtime every 10 seconds to prevent staleness if operation is long
			realpath: false, // the file may not exist yet, which is acceptable
			retries: {
				// Configuration for retrying lock acquisition
				retries: 5, // Number of retries after the initial attempt
				factor: 2, // Exponential backoff factor (e.g., 100ms, 200ms, 400ms, ...)
				minTimeout: 100, // Minimum time to wait before the first retry (in ms)
				maxTimeout: 1000, // Maximum time to wait for any single retry (in ms)
			},
			onCompromised: (err) => {
				fsLog.error(`Lock at ${absoluteFilePath} was compromised:`, { error: String(err) })
				throw err
			},
		})
	} catch (lockError) {
		// If lock acquisition fails, we throw immediately.
		// The releaseLock remains a no-op, so the finally block in the main file operations
		// try-catch-finally won't try to release an unacquired lock if this path is taken.
		fsLog.error(`Failed to acquire lock for ${absoluteFilePath}:`, { error: String(lockError) })
		// Propagate the lock acquisition error
		throw lockError
	}

	// Variables to hold the actual paths of temp files if they are created.
	let actualTempNewFilePath: string | null = null
	let actualTempBackupFilePath: string | null = null

	try {
		// Step 1: Write data to a new temporary file.
		actualTempNewFilePath = path.join(
			path.dirname(absoluteFilePath),
			`.${path.basename(absoluteFilePath)}.new_${Date.now()}_${Math.random().toString(36).substring(2)}.tmp`,
		)

		await _streamDataToFile(actualTempNewFilePath, data, options?.prettyPrint, options?.preSerialized)

		// Step 2: Check if the target file exists. If so, rename it to a backup path.
		try {
			// Check for target file existence
			await fs.access(absoluteFilePath)
			// Target exists, create a backup path and rename.
			actualTempBackupFilePath = path.join(
				path.dirname(absoluteFilePath),
				`.${path.basename(absoluteFilePath)}.bak_${Date.now()}_${Math.random().toString(36).substring(2)}.tmp`,
			)
			await fs.rename(absoluteFilePath, actualTempBackupFilePath)
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
		} catch (accessError: any) {
			// Explicitly type accessError
			if (accessError.code !== "ENOENT") {
				// An error other than "file not found" occurred during access check.
				throw accessError
			}
			// Target file does not exist, so no backup is made. actualTempBackupFilePath remains null.
		}

		// Step 3: Rename the new temporary file to the target file path.
		// This is the main "commit" step.
		await fs.rename(actualTempNewFilePath, absoluteFilePath)

		// If we reach here, the new file is successfully in place.
		// The original actualTempNewFilePath is now the main file, so we shouldn't try to clean it up as "temp".
		// Mark as "used" or "committed"
		actualTempNewFilePath = null

		// Step 4: If a backup was created, attempt to delete it.
		if (actualTempBackupFilePath) {
			try {
				await fs.unlink(actualTempBackupFilePath)
				// Mark backup as handled
				actualTempBackupFilePath = null
			} catch (unlinkBackupError) {
				// Log this error, but do not re-throw. The main operation was successful.
				// actualTempBackupFilePath remains set, indicating an orphaned backup.
				fsLog.error(
					`Successfully wrote ${absoluteFilePath}, but failed to clean up backup ${actualTempBackupFilePath}:`,
					{ error: String(unlinkBackupError) },
				)
			}
		}
	} catch (originalError) {
		fsLog.error(`Operation failed for ${absoluteFilePath}: [Original Error Caught]`, {
			error: String(originalError),
		})

		const newFileToCleanupWithinCatch = actualTempNewFilePath
		const backupFileToRollbackOrCleanupWithinCatch = actualTempBackupFilePath

		// Attempt rollback if a backup was made
		if (backupFileToRollbackOrCleanupWithinCatch) {
			try {
				await fs.rename(backupFileToRollbackOrCleanupWithinCatch, absoluteFilePath)
				// Mark as handled, prevent later unlink of this path
				actualTempBackupFilePath = null
			} catch (rollbackError) {
				// actualTempBackupFilePath (outer scope) remains pointing to backupFileToRollbackOrCleanupWithinCatch
				fsLog.error(
					`[Catch] Failed to restore backup ${backupFileToRollbackOrCleanupWithinCatch} to ${absoluteFilePath}:`,
					{ error: String(rollbackError) },
				)
			}
		}

		// Cleanup the .new file if it exists
		if (newFileToCleanupWithinCatch) {
			try {
				await fs.unlink(newFileToCleanupWithinCatch)
			} catch (cleanupError) {
				fsLog.error(`[Catch] Failed to clean up temporary new file ${newFileToCleanupWithinCatch}:`, {
					error: String(cleanupError),
				})
			}
		}

		// Cleanup the .bak file if it still needs to be (i.e., wasn't successfully restored)
		if (actualTempBackupFilePath) {
			try {
				await fs.unlink(actualTempBackupFilePath)
			} catch (cleanupError) {
				fsLog.error(`[Catch] Failed to clean up temporary backup file ${actualTempBackupFilePath}:`, {
					error: String(cleanupError),
				})
			}
		}
		throw originalError // This MUST be the error that rejects the promise.
	} finally {
		// Release the lock in the main finally block.
		try {
			// releaseLock will be the actual unlock function if lock was acquired,
			// or the initial no-op if acquisition failed.
			await releaseLock()
		} catch (unlockError) {
			// Do not re-throw here, as the originalError from the try/catch (if any) is more important.
			fsLog.error(`Failed to release lock for ${absoluteFilePath}:`, { error: String(unlockError) })
		}
	}
}

/**
 * Helper function to stream JSON data to a file.
 * @param targetPath The path to write the stream to.
 * @param data The data to stream (ignored when `preSerialized` is provided).
 * @param prettyPrint Whether to format the JSON with indentation.
 * @param preSerialized Optional pre-serialized JSON string; when provided
 *   the function writes this string verbatim instead of streaming `data`
 *   through `JsonStreamStringify`. See `SafeWriteJsonOptions.preSerialized`.
 * @returns Promise<void>
 */
async function _streamDataToFile(
	targetPath: string,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	data: any,
	prettyPrint = false,
	preSerialized?: string,
): Promise<void> {
	// Stream data to avoid high memory usage for large JSON objects.
	const fileWriteStream = fsSync.createWriteStream(targetPath, { encoding: "utf8" })

	// Fast path: caller already produced a JSON snapshot synchronously, so
	// there is nothing to traverse — just push the string and close the
	// stream. This avoids the O(n) walk inside JsonStreamStringify and the
	// per-token write overhead for large arrays of small objects (the shape
	// of `ui_messages.json`).
	if (preSerialized !== undefined) {
		return new Promise<void>((resolve, reject) => {
			fileWriteStream.on("error", reject)
			fileWriteStream.on("finish", resolve)
			fileWriteStream.end(preSerialized)
		})
	}

	// JsonStreamStringify traverses the object and streams tokens directly
	// The 'spaces' parameter adds indentation during streaming, not via a separate pass
	// Convert undefined to null for valid JSON serialization (undefined is not valid JSON)
	const stringifyStream = new JsonStreamStringify(
		data === undefined ? null : data,
		undefined, // replacer
		prettyPrint ? "\t" : undefined, // spaces for indentation
	)

	return new Promise<void>((resolve, reject) => {
		stringifyStream.on("error", reject)
		fileWriteStream.on("error", reject)
		fileWriteStream.on("finish", resolve)
		stringifyStream.pipe(fileWriteStream)
	})
}

export { safeWriteJson }
