import type { CommandId, CodeActionId, TerminalActionId } from "@shofer/types"

import { Package } from "../shared/package.js"

export const getCommand = (id: CommandId) => `${Package.name}.${id}`

export const getCodeActionCommand = (id: CodeActionId) => `${Package.name}.${id}`

export const getTerminalCommand = (id: TerminalActionId) => `${Package.name}.${id}`
