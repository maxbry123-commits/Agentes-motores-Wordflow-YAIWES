// npx vitest run src/core/tools/__tests__/validateToolUse.spec.ts

import { describe, it, expect } from "vitest"
import type { ModeConfig } from "@shofer/types"

import { TOOL_GROUPS } from "@shofer/types"

import { BUILTIN_MODES } from "../../__fixtures__/builtin-config.js"

import { validateToolUse, isToolAllowedForMode } from "../validateToolUse.js"

// The mode list every `isToolAllowedForMode` call below resolves against — a default
// install's modes, contributed by the bundled `builtin-config` plugin.
const codeMode = "code"
const architectMode = "architect"
const debugMode = "debug"

describe("mode-validator", () => {
	describe("isToolAllowedForMode", () => {
		describe("code mode", () => {
			it("allows all code mode tools", () => {
				// Code mode has all groups
				Object.entries(TOOL_GROUPS).forEach(([_, config]) => {
					config.tools.forEach((tool: string) => {
						expect(isToolAllowedForMode(tool, codeMode, BUILTIN_MODES)).toBe(true)
					})
				})
			})

			it("disallows unknown tools", () => {
				expect(isToolAllowedForMode("unknown_tool" as any, codeMode, BUILTIN_MODES)).toBe(false)
			})
		})

		describe("architect mode", () => {
			it("allows configured tools", () => {
				// Architect mode has read and mcp groups
				const architectTools = [...TOOL_GROUPS.read.tools, ...TOOL_GROUPS.mcp.tools]
				architectTools.forEach((tool) => {
					expect(isToolAllowedForMode(tool, architectMode, BUILTIN_MODES)).toBe(true)
				})
			})
		})

		describe("debug mode", () => {
			it("allows configured tools", () => {
				// Debug mode has read and mcp groups
				const debugTools = [...TOOL_GROUPS.read.tools, ...TOOL_GROUPS.mcp.tools]
				debugTools.forEach((tool) => {
					expect(isToolAllowedForMode(tool, debugMode, BUILTIN_MODES)).toBe(true)
				})
			})
		})

		describe("custom modes", () => {
			it("allows tools from custom mode configuration", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "custom-mode",
						name: "Custom Mode",
						roleDefinition: "Custom role",
						tools: ["read", "write"] as const,
					},
				]
				// Should allow tools from read and edit groups
				expect(isToolAllowedForMode("read_file", "custom-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("write_to_file", "custom-mode", customModes)).toBe(true)
				// Should not allow tools from other groups
				expect(isToolAllowedForMode("execute_command", "custom-mode", customModes)).toBe(false)
			})

			it("allows custom mode to override built-in mode", () => {
				const customModes: ModeConfig[] = [
					{
						slug: codeMode,
						name: "Custom Code Mode",
						roleDefinition: "Custom role",
						tools: ["read"] as const,
					},
				]
				// Should allow tools from read group
				expect(isToolAllowedForMode("read_file", codeMode, customModes)).toBe(true)
				// Should not allow tools from other groups
				expect(isToolAllowedForMode("write_to_file", codeMode, customModes)).toBe(false)
			})

			it("respects tool requirements in custom modes", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "custom-mode",
						name: "Custom Mode",
						roleDefinition: "Custom role",
						tools: ["write"] as const,
					},
				]
				const requirements = { apply_diff: false }

				// Should respect disabled requirement even if tool group is allowed
				expect(isToolAllowedForMode("apply_diff", "custom-mode", customModes, requirements)).toBe(false)

				// Should allow other edit tools
				expect(isToolAllowedForMode("write_to_file", "custom-mode", customModes, requirements)).toBe(true)
			})

			it("allows tools from mode.tools_allowed whitelist", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "tools-only-mode",
						name: "Tools Only Mode",
						roleDefinition: "Custom role",
						tools: [],
						tools_allowed: ["read_file", "grep_search"],
					},
				]
				// Should allow tools from the explicit tools list
				expect(isToolAllowedForMode("read_file", "tools-only-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("grep_search", "tools-only-mode", customModes)).toBe(true)
				// Should not allow tools not in the list
				expect(isToolAllowedForMode("write_to_file", "tools-only-mode", customModes)).toBe(false)
				expect(isToolAllowedForMode("execute_command", "tools-only-mode", customModes)).toBe(false)
			})

			it("allows tools from mode.tools_allowed whitelist alone (no groups)", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "tools-alone-mode",
						name: "Tools Alone Mode",
						roleDefinition: "Custom role",
						tools_allowed: ["read_file"],
					} as ModeConfig,
				]
				// Should allow the whitelisted tool
				expect(isToolAllowedForMode("read_file", "tools-alone-mode", customModes)).toBe(true)
				// Should not allow tools not in the list
				expect(isToolAllowedForMode("grep_search", "tools-alone-mode", customModes)).toBe(false)
			})

			it("allows tools when both tools and tools_allowed are present (OR semantics)", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "or-mode",
						name: "OR Mode",
						roleDefinition: "Custom role",
						tools: ["read"],
						tools_allowed: ["execute_command", "read_command_output"],
					} as ModeConfig,
				]
				// Should allow tools from groups
				expect(isToolAllowedForMode("read_file", "or-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("grep_search", "or-mode", customModes)).toBe(true)
				// Should allow tools from tools_allowed whitelist (even though not in groups)
				expect(isToolAllowedForMode("execute_command", "or-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("read_command_output", "or-mode", customModes)).toBe(true)
				// Should not allow tools in neither
				expect(isToolAllowedForMode("write_to_file", "or-mode", customModes)).toBe(false)
			})

			it("allows always-available tools even in tools-only mode", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "minimal-tools-mode",
						name: "Minimal Tools Mode",
						roleDefinition: "Custom role",
						tools_allowed: ["read_file"],
					} as ModeConfig,
				]
				// Always-available tools should still be allowed
				expect(isToolAllowedForMode("attempt_completion", "minimal-tools-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("update_todo_list", "minimal-tools-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("set_task_title", "minimal-tools-mode", customModes)).toBe(true)
			})

			it("tools_denied blocks tools even when allowed by groups", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "deny-mode",
						name: "Deny Mode",
						roleDefinition: "Custom role",
						tools: ["read", "execute"],
						tools_denied: ["execute_command", "write_to_file"],
					} as ModeConfig,
				]
				// Tools in tools should be allowed
				expect(isToolAllowedForMode("read_file", "deny-mode", customModes)).toBe(true)
				expect(isToolAllowedForMode("grep_search", "deny-mode", customModes)).toBe(true)
				// Denied tools should be blocked even if group allows them
				expect(isToolAllowedForMode("execute_command", "deny-mode", customModes)).toBe(false)
				// Non-group tools should still be blocked
				expect(isToolAllowedForMode("write_to_file", "deny-mode", customModes)).toBe(false)
			})

			it("tools_denied takes priority over tools_allowed", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "deny-override-mode",
						name: "Deny Override Mode",
						roleDefinition: "Custom role",
						tools_allowed: ["execute_command", "read_command_output"],
						tools_denied: ["execute_command"],
					} as ModeConfig,
				]
				// Allowed tool should work
				expect(isToolAllowedForMode("read_command_output", "deny-override-mode", customModes)).toBe(true)
				// Denied tool should be blocked even though also in tools_allowed
				expect(isToolAllowedForMode("execute_command", "deny-override-mode", customModes)).toBe(false)
			})
		})

		describe("dynamic MCP tools", () => {
			it("allows dynamic MCP tools when mcp group is in mode groups", () => {
				// Code mode has mcp group, so dynamic MCP tools should be allowed
				expect(isToolAllowedForMode("mcp_context7_resolve-library-id", codeMode, BUILTIN_MODES)).toBe(true)
				expect(isToolAllowedForMode("mcp_serverName_toolName", codeMode, BUILTIN_MODES)).toBe(true)
			})

			it("disallows dynamic MCP tools when mcp group is not in mode groups", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "no-mcp-mode",
						name: "No MCP Mode",
						roleDefinition: "Custom role",
						tools: ["read", "write"] as const,
					},
				]
				// Custom mode without mcp group should not allow dynamic MCP tools
				expect(isToolAllowedForMode("mcp_context7_resolve-library-id", "no-mcp-mode", customModes)).toBe(false)
				expect(isToolAllowedForMode("mcp_serverName_toolName", "no-mcp-mode", customModes)).toBe(false)
			})

			it("allows dynamic MCP tools in custom mode with mcp group", () => {
				const customModes: ModeConfig[] = [
					{
						slug: "custom-mcp-mode",
						name: "Custom MCP Mode",
						roleDefinition: "Custom role",
						tools: ["read", "mcp"] as const,
					},
				]
				expect(isToolAllowedForMode("mcp_context7_resolve-library-id", "custom-mcp-mode", customModes)).toBe(
					true,
				)
			})
		})

		describe("tool requirements", () => {
			it("respects tool requirements when provided", () => {
				const requirements = { apply_diff: false }
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, requirements)).toBe(false)

				const enabledRequirements = { apply_diff: true }
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, enabledRequirements)).toBe(true)
			})

			it("allows tools when their requirements are not specified", () => {
				const requirements = { some_other_tool: true }
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, requirements)).toBe(true)
			})

			it("handles undefined and empty requirements", () => {
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, undefined)).toBe(true)
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, {})).toBe(true)
			})

			it("prioritizes requirements over mode configuration", () => {
				const requirements = { apply_diff: false }
				// Even in code mode which allows all tools, disabled requirement should take precedence
				expect(isToolAllowedForMode("apply_diff", codeMode, BUILTIN_MODES, requirements)).toBe(false)
			})

			it("prioritizes requirements over ALWAYS_AVAILABLE_TOOLS", () => {
				// Tools in ALWAYS_AVAILABLE_TOOLS (switch_mode, new_task, etc.) should still
				// be blockable via toolRequirements / disabledTools
				const requirements = { switch_mode: false, new_task: false, attempt_completion: false }
				expect(isToolAllowedForMode("switch_mode", codeMode, BUILTIN_MODES, requirements)).toBe(false)
				expect(isToolAllowedForMode("new_task", codeMode, BUILTIN_MODES, requirements)).toBe(false)
				expect(isToolAllowedForMode("attempt_completion", codeMode, BUILTIN_MODES, requirements)).toBe(false)
			})
		})
	})

	describe("validateToolUse", () => {
		it("throws error for unknown/invalid tools", () => {
			// Unknown tools should throw with a specific "Unknown tool" error
			expect(() => validateToolUse("unknown_tool" as any, "architect", BUILTIN_MODES)).toThrow(
				'Unknown tool "unknown_tool". This tool does not exist.',
			)
		})

		it("throws error for disallowed tools in architect mode", () => {
			// execute_command is a valid tool but not allowed in architect mode
			expect(() => validateToolUse("execute_command", "architect", BUILTIN_MODES)).toThrow(
				'Tool "execute_command" is not allowed in architect mode.',
			)
		})

		it("does not throw for allowed tools in architect mode", () => {
			expect(() => validateToolUse("read_file", "architect", BUILTIN_MODES)).not.toThrow()
		})

		it("throws error when tool requirement is not met", () => {
			const requirements = { apply_diff: false }
			expect(() => validateToolUse("apply_diff", codeMode, BUILTIN_MODES, requirements)).toThrow(
				'Tool "apply_diff" has been disabled',
			)
		})

		it("does not throw when tool requirement is met", () => {
			const requirements = { apply_diff: true }
			expect(() => validateToolUse("apply_diff", codeMode, BUILTIN_MODES, requirements)).not.toThrow()
		})

		it("handles undefined requirements gracefully", () => {
			expect(() => validateToolUse("apply_diff", codeMode, BUILTIN_MODES, undefined)).not.toThrow()
		})

		it("blocks tool when disabledTools is converted to toolRequirements", () => {
			const disabledTools = ["execute_command", "grep_search"]
			const toolRequirements = disabledTools.reduce(
				(acc: Record<string, boolean>, tool: string) => {
					acc[tool] = false
					return acc
				},
				{} as Record<string, boolean>,
			)

			expect(() => validateToolUse("execute_command", codeMode, BUILTIN_MODES, toolRequirements)).toThrow(
				'Tool "execute_command" has been disabled',
			)
			expect(() => validateToolUse("grep_search", codeMode, BUILTIN_MODES, toolRequirements)).toThrow(
				'Tool "grep_search" has been disabled',
			)
		})

		it("allows non-disabled tools when disabledTools is converted to toolRequirements", () => {
			const disabledTools = ["execute_command"]
			const toolRequirements = disabledTools.reduce(
				(acc: Record<string, boolean>, tool: string) => {
					acc[tool] = false
					return acc
				},
				{} as Record<string, boolean>,
			)

			expect(() => validateToolUse("read_file", codeMode, BUILTIN_MODES, toolRequirements)).not.toThrow()
			expect(() => validateToolUse("write_to_file", codeMode, BUILTIN_MODES, toolRequirements)).not.toThrow()
		})

		it("handles empty disabledTools array converted to toolRequirements", () => {
			const disabledTools: string[] = []
			const toolRequirements = disabledTools.reduce(
				(acc: Record<string, boolean>, tool: string) => {
					acc[tool] = false
					return acc
				},
				{} as Record<string, boolean>,
			)

			expect(() => validateToolUse("execute_command", codeMode, BUILTIN_MODES, toolRequirements)).not.toThrow()
		})
	})
})
