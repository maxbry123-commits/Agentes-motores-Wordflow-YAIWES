import os from "os"
import osName from "os-name"

import { getShell } from "../../utils/shell.js"
import { type SubmoduleEntry, formatSubmoduleBlock } from "../../utils/git-submodules.js"

/**
 * Generate the SYSTEM INFORMATION section of the system prompt.
 *
 * When `submoduleInfos` is provided and non-empty, a WORKSPACE SUBMODULES
 * block is appended listing each submodule's path, URL, and optional branch.
 */
export function getSystemInfoSection(cwd: string, submoduleInfos?: SubmoduleEntry[]): string {
	// Try to get detailed OS name, fall back to basic info if it fails
	let osInfo: string
	try {
		osInfo = osName()
	} catch {
		// Fallback when os-name fails (e.g., PowerShell not available on Windows)
		const platform = os.platform()
		const release = os.release()
		osInfo = `${platform} ${release}`
	}

	let details = `====

SYSTEM INFORMATION

Operating System: ${osInfo}
Default Shell: ${getShell()}
Home Directory: ${os.homedir().toPosix()}
Current Workspace Directory: ${cwd.toPosix()}

The Current Workspace Directory is the active VS Code project directory, and is therefore the default directory for all tool operations. New terminals will be created in the current workspace directory, however if you change directories in a terminal it will then have a different working directory; changing directories in a terminal does not modify the workspace directory, because you do not have access to change the workspace directory. When the user initially gives you a task, a recursive list of all filepaths in the current workspace directory ('/test/path') will be included in environment_details. This provides an overview of the project's file structure, offering key insights into the project from directory/file names (how developers conceptualize and organize their code) and file extensions (the language used). This can also guide decision-making on which files to explore further. If you need to further explore directories such as outside the current workspace directory, you can use the list_files tool. If you pass 'true' for the recursive parameter, it will list files recursively. Otherwise, it will list files at the top level, which is better suited for generic directories where you don't necessarily need the nested structure, like the Desktop.`

	const submoduleBlock = formatSubmoduleBlock(submoduleInfos)
	if (submoduleBlock) {
		details += "\n\n"
		details += "===="
		details += submoduleBlock
	}

	return details
}
