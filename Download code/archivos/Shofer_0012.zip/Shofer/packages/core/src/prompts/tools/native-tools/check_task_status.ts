import { parametersSchema as z } from "@shofer/types"

import { defineNativeTool } from "../../../tools/defineNativeTool.js"

const CHECK_TASK_STATUS_DESCRIPTION = `Check the current status of a child task you started with new_task, or of a peer task sharing your root task. Returns the task's status and, if it has completed/errored/cancelled, its result or error message. If the task is waiting on an answer from you (it called ask_followup_question), the question is named here — it is also already in your mailbox as a request, and reply is what answers it. Set include_activity to true to also see what the task is currently doing (last few tool calls or messages).`

const TASK_ID_PARAMETER_DESCRIPTION = `The task ID returned when the background task was started.`

const INCLUDE_ACTIVITY_PARAMETER_DESCRIPTION = `When true, include the child's most recent tool calls and messages in the response so you can see what it is currently working on.`

export default defineNativeTool({
	name: "check_task_status",
	description: CHECK_TASK_STATUS_DESCRIPTION,
	schema: z.object({
		task_id: z.string().describe(TASK_ID_PARAMETER_DESCRIPTION),
		include_activity: z.boolean().describe(INCLUDE_ACTIVITY_PARAMETER_DESCRIPTION).optional(),
	}),
})
