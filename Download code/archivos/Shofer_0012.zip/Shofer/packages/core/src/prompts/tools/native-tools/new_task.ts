import { parametersSchema as z } from "@shofer/types"

import { defineNativeTool } from "../../../tools/defineNativeTool.js"

const NEW_TASK_DESCRIPTION = `Create a new task instance in the chosen mode using your provided message and initial todo list (if required).

The child ALWAYS runs concurrently. This tool returns as soon as the child has started, with its task_id; you are never blocked and you may spawn several children in the same turn.

How you get the result: when the child finishes, its result is delivered to YOUR MAILBOX as a notification. Call wait(from=["<child task_id>"]) when you need it before you can continue, or simply end your turn — the delivery wakes you. check_task_status inspects a child at any time, and cancel_tasks stops one you no longer need.

Because you keep running, you are also the child's audience: if it asks a question, it arrives in your mailbox as a request and you answer it with reply.`

const MODE_PARAMETER_DESCRIPTION = `Slug of the mode to begin the new task in (e.g., code, debug, architect)`

const MESSAGE_PARAMETER_DESCRIPTION = `Initial user instructions or context for the new task`

const TODOS_PARAMETER_DESCRIPTION = `Optional initial todo list written as a markdown checklist; required when the workspace mandates todos. IMPORTANT: Do NOT copy the parent task's todo list — each child/subtask manages its own independent todo list starting fresh.`

const SOFT_RESULT_LENGTH_PARAMETER_DESCRIPTION = `Soft suggestion for how many characters the parent is willing to accept as the completion result. The subtask should aim to keep its attempt_completion result within this budget by summarizing concisely, but it is not a hard limit — the parent may handle longer results. Defaults to 2000. Hard safety cap: 100000 characters.`

const SOFT_TIMEOUT_SEC_PARAMETER_DESCRIPTION = `Soft guidance (in seconds) for how long the parent expects this subtask to take. Not a hard deadline; the child may take longer. Defaults to 300 (5 minutes). Use this to pace your work accordingly.`

const PEER_TASK_IDS_PARAMETER_DESCRIPTION = `Least-privilege peer scope: the spawned child's baseline knownPeers is parent-only. If provided, these task IDs are added (must share rootTaskId). If omitted/null, the child can only communicate with its parent and its own children — sibling access is denied. Validated against rootTaskId at spawn time — unknown IDs are rejected.`

const TITLE_PARAMETER_DESCRIPTION = `Optional short, descriptive display title for the child task (max 60 characters; longer is truncated). When set, this becomes the child's title AND locks it — the child cannot rename itself via set_task_title. Omit to let the child name itself.`

export default defineNativeTool({
	name: "new_task",
	description: NEW_TASK_DESCRIPTION,
	schema: z.object({
		mode: z.string().describe(MODE_PARAMETER_DESCRIPTION),
		message: z.string().describe(MESSAGE_PARAMETER_DESCRIPTION),
		todos: z.string().describe(TODOS_PARAMETER_DESCRIPTION).optional(),
		softResultLength: z.number().describe(SOFT_RESULT_LENGTH_PARAMETER_DESCRIPTION).optional(),
		softTimeoutSec: z.number().describe(SOFT_TIMEOUT_SEC_PARAMETER_DESCRIPTION).optional(),
		peer_task_ids: z.array(z.string()).describe(PEER_TASK_IDS_PARAMETER_DESCRIPTION).optional(),
		title: z.string().describe(TITLE_PARAMETER_DESCRIPTION).optional(),
	}),
})
