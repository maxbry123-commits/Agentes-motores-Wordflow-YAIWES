import type OpenAI from "openai"
import type { ModeConfig, ToolName, ToolGroup, ModelInfo, McpTool } from "@shofer/types"
import {
	DESCRIBE_TOOLS_TOOL_NAME,
	getGroupName,
	getModeBySlug,
	getToolsForMode,
	modeStubsToolSchemas,
	resolveModeConfig,
} from "@shofer/types"
import { TOOL_GROUPS, ALWAYS_AVAILABLE_TOOLS, TOOL_ALIASES } from "@shofer/types"
import { defaultModeSlug } from "@shofer/types"
import { resolveToolAlias } from "../../tools/tool-aliases.js"
import { buildMcpToolName } from "../../utils/mcp-name.js"
import type { McpHub } from "../../services/mcp/McpHub.js"
import { isToolAllowedForMode } from "../../tools/validateToolUse.js"

/**
 * Canonical to aliases map - maps canonical tool name to array of alias names.
 * Built once at module load from the central TOOL_ALIASES constant.
 */
const CANONICAL_TO_ALIASES: Map<string, string[]> = new Map()

// Build the reverse mapping (canonical -> aliases)
for (const [alias, canonical] of Object.entries(TOOL_ALIASES)) {
	const existing = CANONICAL_TO_ALIASES.get(canonical) ?? []
	existing.push(alias)
	CANONICAL_TO_ALIASES.set(canonical, existing)
}

/**
 * Pre-computed alias groups map - maps any tool name (canonical or alias) to its full group.
 * Built once at module load for O(1) lookup.
 */
const ALIAS_GROUPS: Map<string, readonly string[]> = new Map()

// Build alias groups for all tools
for (const [canonical, aliases] of CANONICAL_TO_ALIASES.entries()) {
	const group = Object.freeze([canonical, ...aliases])
	// Map canonical to group
	ALIAS_GROUPS.set(canonical, group)
	// Map each alias to the same group
	for (const alias of aliases) {
		ALIAS_GROUPS.set(alias, group)
	}
}

/**
 * Cache for renamed tool definitions.
 * Maps "canonicalName:aliasName" to the pre-built tool definition.
 * This avoids creating new objects via spread operators on every assistant message.
 */
const RENAMED_TOOL_CACHE: Map<string, OpenAI.Chat.ChatCompletionTool> = new Map()

/**
 * Gets or creates a renamed tool definition with the alias name.
 * Uses RENAMED_TOOL_CACHE to avoid repeated object allocation.
 *
 * @param tool - The original tool definition
 * @param aliasName - The alias name to use
 * @returns Cached or newly created renamed tool definition
 */
function getOrCreateRenamedTool(
	tool: OpenAI.Chat.ChatCompletionTool,
	aliasName: string,
): OpenAI.Chat.ChatCompletionTool {
	if (!("function" in tool) || !tool.function) {
		return tool
	}

	const cacheKey = `${tool.function.name}:${aliasName}`
	let renamedTool = RENAMED_TOOL_CACHE.get(cacheKey)

	if (!renamedTool) {
		renamedTool = {
			...tool,
			function: {
				...tool.function,
				name: aliasName,
			},
		}
		RENAMED_TOOL_CACHE.set(cacheKey, renamedTool)
	}

	return renamedTool
}

/**
 * Gets all tools in an alias group (including the canonical tool).
 * Uses pre-computed ALIAS_GROUPS map for O(1) lookup.
 *
 * @param toolName - Any tool name in the alias group
 * @returns Array of all tool names in the alias group, or just the tool if not aliased
 */
export function getToolAliasGroup(toolName: string): readonly string[] {
	return ALIAS_GROUPS.get(toolName) ?? [toolName]
}

/**
 * Apply model-specific tool customization to a set of allowed tools.
 *
 * This function filters tools based on model configuration:
 * 1. Removes tools specified in modelInfo.excludedTools
 * 2. Adds tools from modelInfo.includedTools (only if they belong to allowed groups)
 *
 * @param allowedTools - Set of tools already allowed by mode configuration
 * @param modeConfig - Current mode configuration to check tool groups
 * @param modelInfo - Model configuration with tool customization
 * @returns Modified set of tools after applying model customization
 */
/**
 * Result of applying model tool customization.
 * Contains the set of allowed tools and any alias renames to apply.
 */
interface ModelToolCustomizationResult {
	allowedTools: Set<string>
	/** Maps canonical tool name to alias name for tools that should be renamed */
	aliasRenames: Map<string, string>
}

export function applyModelToolCustomization(
	allowedTools: Set<string>,
	modeConfig: ModeConfig,
	modelInfo?: ModelInfo,
): ModelToolCustomizationResult {
	if (!modelInfo) {
		return { allowedTools, aliasRenames: new Map() }
	}

	const result = new Set(allowedTools)
	const aliasRenames = new Map<string, string>()

	// Apply excluded tools (remove from allowed set)
	if (modelInfo.excludedTools && modelInfo.excludedTools.length > 0) {
		modelInfo.excludedTools.forEach((tool) => {
			const resolvedTool = resolveToolAlias(tool)
			result.delete(resolvedTool)
		})
	}

	// Apply included tools (add to allowed set, but only if they belong to an allowed group)
	if (modelInfo.includedTools && modelInfo.includedTools.length > 0) {
		// Build a map of tool -> group for all tools in TOOL_GROUPS (including customTools)
		const toolToGroup = new Map<string, ToolGroup>()
		for (const [groupName, groupConfig] of Object.entries(TOOL_GROUPS)) {
			// Add regular tools
			groupConfig.tools.forEach((tool) => {
				toolToGroup.set(tool, groupName as ToolGroup)
			})
			// Add customTools (opt-in only tools)
			if (groupConfig.customTools) {
				groupConfig.customTools.forEach((tool) => {
					toolToGroup.set(tool, groupName as ToolGroup)
				})
			}
		}

		// Get the list of allowed groups for this mode
		const allowedGroups = new Set((modeConfig.tools ?? []).map((groupEntry) => getGroupName(groupEntry)))

		// Add included tools only if they belong to an allowed group
		// If the tool was specified as an alias, track the rename
		modelInfo.includedTools.forEach((tool) => {
			const resolvedTool = resolveToolAlias(tool)
			const toolGroup = toolToGroup.get(resolvedTool)
			if (toolGroup && allowedGroups.has(toolGroup)) {
				result.add(resolvedTool)
				// If the tool was specified as an alias, rename it in the API
				if (tool !== resolvedTool) {
					aliasRenames.set(resolvedTool, tool)
				}
			}
		})
	}

	return { allowedTools: result, aliasRenames }
}

/**
 * Feature-gated tools (v3 architecture §4): each tool here is
 * available only when its gate is on. Declaring them in one table replaces the
 * row of hand-written `allowedToolNames.delete(...)` branches that previously
 * lived inline in `filterNativeToolsForMode` — a single place to see which tools
 * are conditional and why.
 */
export const FEATURE_GATED_TOOLS = {
	generate_image: "generateImage",
	run_slash_command: "runSlashCommand",
	access_mcp_resource: "accessMcpResource",
	update_todo_list: "todoList",
} as const

export type ToolAccessGate = (typeof FEATURE_GATED_TOOLS)[keyof typeof FEATURE_GATED_TOOLS]
export type ToolAccessGates = Record<ToolAccessGate, boolean>

export interface ToolAccessParams {
	modeSlug: string
	modeConfig: ModeConfig
	customModes: ModeConfig[]
	experiments: Record<string, boolean>
	modelInfo?: ModelInfo
	/** Resolved availability of each feature-gated tool (see FEATURE_GATED_TOOLS). */
	gates: ToolAccessGates
	disabledTools?: string[]
}

/**
 * Compute the set of native tool names available for a (mode, model, feature)
 * combination — the single source of truth for tool *access* (§4). It composes
 * the three historically-separate systems as one ordered decision:
 *   1. mode → enabled groups → tools (+ always-available), gated by `isToolAllowedForMode`;
 *   2. per-model preferences (`applyModelToolCustomization`: exclude/include);
 *   3. feature gates (`FEATURE_GATED_TOOLS`) and user-disabled tools — removals.
 *
 * Pure and manager-free (callers resolve the `gates` booleans), so it is unit
 * testable without VS Code services.
 */
export function computeToolAccess(params: ToolAccessParams): {
	allowedTools: Set<string>
	aliasRenames: Map<string, string>
} {
	const { modeSlug, modeConfig, customModes, experiments, modelInfo, gates, disabledTools } = params

	// 1. Mode → allowed tools (includes always-available), gated per-tool.
	const allToolsForMode = getToolsForMode(modeConfig.tools, modeConfig.tools_allowed, modeConfig.tools_denied)
	const modeAllowed = new Set(
		allToolsForMode.filter((tool) =>
			isToolAllowedForMode(tool as ToolName, modeSlug, customModes, undefined, undefined, experiments),
		),
	)

	// 2. Per-model preferences (exclude/include + alias renames).
	const { allowedTools, aliasRenames } = applyModelToolCustomization(modeAllowed, modeConfig, modelInfo)

	// 3a. Feature gates — remove tools whose gate is off.
	for (const [tool, gate] of Object.entries(FEATURE_GATED_TOOLS)) {
		if (!gates[gate]) allowedTools.delete(tool)
	}

	// 3b. User-disabled tools (normalize aliases so disabling a legacy alias also
	// disables the canonical tool).
	if (disabledTools?.length) {
		for (const toolName of disabledTools) {
			allowedTools.delete(resolveToolAlias(toolName))
		}
	}

	// 3c. `describe_tools` is always-available so that a mode which tiers its tool
	// schemas gets it for free — but a mode that declares no tiering has no stub
	// to describe, and offering the tool there would change the surface of every
	// existing mode. So it is admitted exactly where stubs exist.
	if (!modeStubsToolSchemas(modeConfig)) {
		allowedTools.delete(DESCRIBE_TOOLS_TOOL_NAME)
	}

	return { allowedTools, aliasRenames }
}

/**
 * Filters native tools based on mode restrictions and model customization.
 * This ensures native tools are filtered consistently with mode/tool permissions.
 *
 * @param nativeTools - Array of all available native tools
 * @param mode - Current mode slug
 * @param customModes - Custom mode configurations
 * @param experiments - Experiment flags
 * @param settings - Additional settings for tool filtering (includes modelInfo for model-specific customization)
 * @param mcpHub - MCP hub for checking available resources
 * @returns Filtered array of tools allowed for the mode
 */
export function filterNativeToolsForMode(
	nativeTools: OpenAI.Chat.ChatCompletionTool[],
	mode: string | undefined,
	customModes: ModeConfig[] | undefined,
	experiments: Record<string, boolean> | undefined,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- settings is an open-ended bag of host-provided flags
	settings?: Record<string, any>,
	mcpHub?: McpHub,
): OpenAI.Chat.ChatCompletionTool[] {
	// Get mode configuration and all tools for this mode
	// Falls back to the default mode, then to any mode that exists, so the agent keeps
	// functional tools even if the mode it was started in has since been deleted.
	const modeConfig = resolveModeConfig(mode ?? defaultModeSlug, customModes)
	const modeSlug = modeConfig.slug

	// Resolve the feature-gate booleans from the runtime flags, then delegate the access
	// decision to the single computeToolAccess source of truth. Semantic search is NOT
	// here: it is a plugin's tool now, registered only when its index can answer.
	const gates: ToolAccessGates = {
		generateImage: !!experiments?.imageGeneration,
		runSlashCommand: !!experiments?.runSlashCommand,
		accessMcpResource: !!mcpHub && hasAnyMcpResources(mcpHub),
		todoList: settings?.todoListEnabled !== false,
	}

	const { allowedTools: allowedToolNames, aliasRenames } = computeToolAccess({
		modeSlug,
		modeConfig,
		customModes: customModes ?? [],
		experiments: experiments ?? {},
		modelInfo: settings?.modelInfo as ModelInfo | undefined,
		gates,
		disabledTools: settings?.disabledTools,
	})

	// Filter native tools based on allowed tool names and apply alias renames
	const filteredTools: OpenAI.Chat.ChatCompletionTool[] = []

	for (const tool of nativeTools) {
		// Handle both ChatCompletionTool and ChatCompletionCustomTool
		if ("function" in tool && tool.function) {
			const toolName = tool.function.name
			if (allowedToolNames.has(toolName)) {
				// Check if this tool should be renamed to an alias
				const aliasName = aliasRenames.get(toolName)
				if (aliasName) {
					// Use cached renamed tool definition to avoid per-message object allocation
					filteredTools.push(getOrCreateRenamedTool(tool, aliasName))
				} else {
					filteredTools.push(tool)
				}
			}
		}
	}

	return filteredTools
}

/**
 * Helper function to check if any MCP server has resources available
 */
function hasAnyMcpResources(mcpHub: McpHub): boolean {
	const servers = mcpHub.getServers()
	return servers.some((server) => server.resources && server.resources.length > 0)
}

/**
 * Checks if a specific tool is allowed in the current mode.
 * This is useful for dynamically filtering system prompt content.
 *
 * @param toolName - Name of the tool to check
 * @param mode - Current mode slug
 * @param customModes - Custom mode configurations
 * @param experiments - Experiment flags
 * @param settings - Additional settings for tool filtering
 * @returns true if the tool is allowed in the mode, false otherwise
 */
export function isToolAllowedInMode(
	toolName: ToolName,
	mode: string | undefined,
	customModes: ModeConfig[] | undefined,
	experiments: Record<string, boolean> | undefined,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- settings is an open-ended bag of host-provided flags
	settings?: Record<string, any>,
): boolean {
	const modeSlug = mode ?? defaultModeSlug

	// Check if it's an always-available tool
	if (ALWAYS_AVAILABLE_TOOLS.includes(toolName)) {
		// But still check for conditional exclusions
		if (toolName === "update_todo_list") {
			return settings?.todoListEnabled !== false
		}
		if (toolName === "generate_image") {
			return experiments?.imageGeneration === true
		}
		if (toolName === "run_slash_command") {
			return experiments?.runSlashCommand === true
		}
		return true
	}

	// Check if the tool is allowed by the mode's groups
	// Resolve to canonical name and check that single value
	const canonicalTool = resolveToolAlias(toolName)
	return isToolAllowedForMode(
		canonicalTool as ToolName,
		modeSlug,
		customModes ?? [],
		undefined,
		undefined,
		experiments ?? {},
	)
}

/**
 * Gets the list of available tools from a specific tool group for the current mode.
 * This is useful for dynamically building system prompt content based on available tools.
 *
 * @param groupName - Name of the tool group to check
 * @param mode - Current mode slug
 * @param customModes - Custom mode configurations
 * @param experiments - Experiment flags
 * @param settings - Additional settings for tool filtering
 * @returns Array of tool names that are available from the group
 */
export function getAvailableToolsInGroup(
	groupName: ToolGroup,
	mode: string | undefined,
	customModes: ModeConfig[] | undefined,
	experiments: Record<string, boolean> | undefined,
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- settings is an open-ended bag of host-provided flags
	settings?: Record<string, any>,
): ToolName[] {
	const toolGroup = TOOL_GROUPS[groupName]
	if (!toolGroup) {
		return []
	}

	return toolGroup.tools.filter((tool) =>
		isToolAllowedInMode(tool as ToolName, mode, customModes, experiments, settings),
	) as ToolName[]
}

/**
 * Filters MCP tools for a given mode using per-group visibility.
 *
 * The `mcp` group is a **gateway**: if the mode does not include `mcp`, no MCP
 * tools are exposed. Once the gateway is open, each MCP tool's resolved group
 * (user override in `mcp.json` → server-declared → default `"uncategorized"`) is
 * checked against the mode's declared groups — a tool is only visible when the
 * mode carries both `mcp` AND the tool's own group. This mirrors the per-group
 * control applied to native tools, so a mode with `tools: ["read", "mcp"]`
 * exposes only the MCP tools classified as `read`.
 *
 * Ungrouped tools resolve to `"uncategorized"`, which is an ORDINARY group
 * here — exactly as `filterPrivateToolsForMode` treats it: visible only when
 * the mode lists it. (The `mcp` gateway used to imply it; that special case
 * let an ungrouped tool ride into every mode that opened the gateway, saying
 * nothing about whether the tool mutates.) Auto-approval is gated separately
 * by `alwaysAllowUncategorized` either way — visibility ≠ auto-execution.
 *
 * Tools whose metadata has `enabledForPrompt === false` (the user-facing
 * "include in prompt" toggle) are filtered out regardless of mode.
 *
 * @param mcpTools - Array of MCP tools (ChatCompletionTool definitions whose
 *   function names follow the `mcp--<server>--<tool>` convention)
 * @param mcpToolMeta - Per-tool metadata including server name, group, and
 *   `enabledForPrompt`
 * @param mode - Current mode slug
 * @param customModes - Custom mode configurations
 * @param _experiments - Experiment flags (currently unused; kept for API symmetry)
 * @returns Filtered array of MCP tools allowed for the mode
 */
export function filterMcpToolsForMode(
	mcpTools: OpenAI.Chat.ChatCompletionTool[],
	mcpToolMeta: Array<McpTool & { serverName: string }>,
	mode: string | undefined,
	customModes: ModeConfig[] | undefined,
	_experiments: Record<string, boolean> | undefined,
): OpenAI.Chat.ChatCompletionTool[] {
	const modeSlug = mode ?? defaultModeSlug
	const modeConfig = getModeBySlug(modeSlug, customModes)

	if (!modeConfig) {
		return []
	}

	// The `mcp` group is a gateway: if the mode does not include it, no MCP
	// tools are exposed at all.
	const allowedGroups = new Set<string>((modeConfig.tools ?? []).map((g) => getGroupName(g)))
	if (!allowedGroups.has("mcp")) {
		return []
	}

	// `uncategorized` is an ORDINARY group: an ungrouped MCP tool resolves to it
	// (see McpHub.fetchToolsList) and is visible only when the mode lists it —
	// the same rule filterPrivateToolsForMode applies, one vocabulary in both
	// filters. Auto-approval is gated separately by `alwaysAllowUncategorized`
	// (see getMcpToolGroup / MCP_GROUP_APPROVAL_GATE), so visibility here never
	// loosens the approval requirement.

	// Build a per-tool lookup keyed by the canonical OpenAI function name
	// (`buildMcpToolName(serverName, name)`) so that name sanitization/
	// truncation matches exactly and tools sharing a name across different
	// servers are not conflated.
	const metaByFunctionName = new Map<string, McpTool & { serverName: string }>()
	for (const meta of mcpToolMeta) {
		const functionName = buildMcpToolName(meta.serverName, meta.name)
		metaByFunctionName.set(functionName, meta)
	}

	return mcpTools.filter((tool) => {
		if (!("function" in tool)) {
			return false
		}

		const meta = metaByFunctionName.get(tool.function.name)

		// Per-tool prompt inclusion is the user-facing kill switch for
		// individual tools — independent of mode/group filtering.
		if (meta?.enabledForPrompt === false) {
			return false
		}

		// Per-group visibility: a tool is only visible when the mode carries
		// the tool's resolved group (user override → server-declared → default
		// "uncategorized"). Ungrouped tools resolve to "uncategorized", which is
		// implied by the `mcp` gateway above, so they stay visible in any mode
		// with mcp. Tools explicitly reassigned to another group (e.g. "browser",
		// "read", "write") are gated by that group's inclusion in the mode.
		const toolGroup: ToolGroup = meta?.group ?? "uncategorized"
		return allowedGroups.has(toolGroup)
	})
}
