//! Native-Wayland agent-cursor overlay via `zwlr_layer_shell_v1`.
//!
//! Replaces the X11-only `overlay.rs` render loop on wlroots compositors
//! (sway, labwc, kwin 5.27+, hyprland) by creating a full-screen,
//! click-through, always-on-top `wl_surface` anchored to the first output
//! via `zwlr_layer_shell_v1`. The surface renders the same gradient-arrow
//! cursor as the X11 path by sharing `cursor_overlay::RenderStateCore` —
//! bloom, click-pulse, idle-fade, and motion all work identically.
//!
//! GNOME mutter does not expose `zwlr_layer_shell_v1` — those sessions
//! either fall through to the X11 path (XWayland) or the nested-compositor
//! mode that spawns labwc internally.
//!
//! Architecture mirrors the existing `wayland/persistent_vptr.rs`: one
//! owner thread (`cua-overlay-wl`) holds the wayland Connection +
//! EventQueue + layer surface; commands flow in over a `crossbeam-channel`.
//! The render core wakes at frame cadence only while pixels can change;
//! stable or hidden state blocks on the command channel without polling.

use std::collections::HashMap;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    OnceLock,
};
use std::thread;
use std::time::{Duration, Instant};

use crossbeam_channel::{bounded, Receiver, Sender};
use cursor_overlay::{CursorConfig, OverlayCommand, OverlayMsg, RenderStateCore};
use wayland_client::{
    protocol::{
        wl_buffer::WlBuffer,
        wl_compositor::WlCompositor,
        wl_output::WlOutput,
        wl_region::WlRegion,
        wl_registry,
        wl_shm::{self, WlShm},
        wl_shm_pool::WlShmPool,
        wl_surface::WlSurface,
    },
    Connection, Dispatch, Proxy, QueueHandle,
};
use wayland_protocols_wlr::layer_shell::v1::client::{
    zwlr_layer_shell_v1::{Layer, ZwlrLayerShellV1},
    zwlr_layer_surface_v1::{self, Anchor, KeyboardInteractivity, ZwlrLayerSurfaceV1},
};

/// Commands the overlay owner thread accepts. The richer commands the
/// cross-platform [`RenderStateCore`] understands (MoveTo, ClickPulse,
/// SetPressed) are forwarded as-is so the layer-shell overlay matches the
/// X11 visual: bloom + animated arrow + click pulse + press ring.
enum WlOverlayCmd {
    Cmd { cmd: OverlayCommand },
    Remove,
    Shutdown,
}

static TX: OnceLock<Sender<WlOverlayCmd>> = OnceLock::new();
// Starts false deliberately: the platform registration path must explicitly
// opt the native Wayland overlay in with the daemon's CursorConfig. This keeps
// lazy forwarding from bypassing --no-overlay before any window exists.
static CONFIG_ENABLED: AtomicBool = AtomicBool::new(false);

pub fn set_config_enabled(enabled: bool) {
    CONFIG_ENABLED.store(enabled, Ordering::Release);
}

fn tx() -> Option<&'static Sender<WlOverlayCmd>> {
    TX.get()
}

/// Lazily start the owner thread. Idempotent — safe to call from every
/// MCP tool invocation; subsequent calls are no-ops.
pub fn ensure_started() -> bool {
    if !CONFIG_ENABLED.load(Ordering::Acquire) {
        return false;
    }
    TX.get_or_init(|| {
        let (tx, rx) = bounded::<WlOverlayCmd>(64);
        thread::Builder::new()
            .name("cua-overlay-wl".into())
            .spawn(move || {
                if let Err(e) = owner_thread(rx) {
                    tracing::warn!("cua-overlay-wl thread exited with error: {e}");
                }
            })
            .expect("spawn cua-overlay-wl thread");
        tx
    });
    true
}

/// Translate a generic [`OverlayMsg`] (the cross-platform command shape)
/// to the layer-shell owner thread. The owner-thread render core consumes
/// every variant the X11 path handles; only `ShowFocusRect` (macOS-only)
/// is silently dropped here.
pub fn forward(msg: &OverlayMsg) -> bool {
    if !should_forward(CONFIG_ENABLED.load(Ordering::Acquire), msg) {
        return false;
    }
    // The native Wayland path owns one cursor and does not keep keyed session
    // tombstones. Accept revival without starting the compositor thread.
    if matches!(msg, OverlayMsg::Revive(_)) {
        return true;
    }
    // Lazy startup: spawning the layer-shell owner thread + connecting to
    // the Wayland compositor takes 100-300ms. Doing that at cua-driver mcp
    // boot (the old eager-init path) was tipping the borderline CI
    // cursor-click-gif test over its 20s budget. ensure_started is
    // idempotent so calling it on every forward is fine — the OnceLock
    // bypasses the spawn after the first call.
    if !ensure_started() {
        return false;
    }
    let Some(tx) = tx() else { return false };
    match msg {
        OverlayMsg::Remove(k) => {
            let _ = k;
            let _ = tx.try_send(WlOverlayCmd::Remove);
            true
        }
        OverlayMsg::Cmd(kc) => {
            if matches!(&kc.cmd, OverlayCommand::ShowFocusRect(_)) {
                return false;
            }
            let _ = tx.try_send(WlOverlayCmd::Cmd {
                cmd: kc.cmd.clone(),
            });
            true
        }
        OverlayMsg::Revive(_) => true,
    }
}

fn should_forward(config_enabled: bool, msg: &OverlayMsg) -> bool {
    config_enabled
        && !matches!(
            msg,
            OverlayMsg::Cmd(kc) if matches!(&kc.cmd, OverlayCommand::ShowFocusRect(_))
        )
}

/// Cleanly stop the owner thread. Tests use this; production code typically
/// lets the thread die at process exit.
pub fn shutdown() {
    if let Some(tx) = tx() {
        let _ = tx.send(WlOverlayCmd::Shutdown);
    }
}

// ── owner thread ─────────────────────────────────────────────────────────

struct OverlayState {
    compositor: Option<WlCompositor>,
    shm: Option<WlShm>,
    layer_shell: Option<ZwlrLayerShellV1>,
    output: Option<WlOutput>,
    output_w: u32,
    output_h: u32,
    surface: Option<WlSurface>,
    layer_surface: Option<ZwlrLayerSurfaceV1>,
    configured: bool,
    /// Cross-platform render core: position, animation, gradient arrow,
    /// bloom, click pulse, idle-fade. Shared verbatim with the X11 path.
    core: RenderStateCore,
    /// In-flight wl_shm buffers awaiting `wl_buffer.release` from the
    /// compositor. Keyed by `WlBuffer` object id; value is the
    /// `(mmap ptr, mmap size, memfd fd)` triple that must be unmapped +
    /// closed once the compositor signals it's done with the buffer.
    /// Replaces the per-redraw `mem::forget` leak: the previous frame's
    /// memory is reclaimed as soon as the compositor releases it.
    pending_buffers: HashMap<u32, (*mut libc::c_void, usize, i32)>,
}

// SAFETY: the raw pointers in pending_buffers point at mmap regions owned
// exclusively by this thread (the owner thread). OverlayState is never
// shared across threads — wayland-client's EventQueue<State> is !Send so
// it stays pinned to the owner thread. The Send/Sync bounds wayland-client
// requires for State types apply to the struct as a whole, hence the
// explicit assertion.
unsafe impl Send for OverlayState {}

impl Default for OverlayState {
    fn default() -> Self {
        Self {
            compositor: None,
            shm: None,
            layer_shell: None,
            output: None,
            output_w: 0,
            output_h: 0,
            surface: None,
            layer_surface: None,
            configured: false,
            core: RenderStateCore::new(CursorConfig::default()),
            pending_buffers: HashMap::new(),
        }
    }
}

fn dbg(msg: &str) {
    if std::env::var_os("CUA_OVERLAY_DEBUG").is_some() {
        eprintln!("[cua-overlay-wl] {msg}");
    }
}

fn owner_thread(rx: Receiver<WlOverlayCmd>) -> anyhow::Result<()> {
    let conn = Connection::connect_to_env()?;
    let mut queue = conn.new_event_queue::<OverlayState>();
    let qh = queue.handle();
    let _registry = conn.display().get_registry(&qh, ());

    let mut state = OverlayState::default();
    queue.roundtrip(&mut state)?;
    for _ in 0..3 {
        queue.roundtrip(&mut state)?;
    }

    let compositor = state
        .compositor
        .clone()
        .ok_or_else(|| anyhow::anyhow!("compositor does not expose wl_compositor"))?;
    let shm = state
        .shm
        .clone()
        .ok_or_else(|| anyhow::anyhow!("compositor does not expose wl_shm"))?;
    let layer_shell = state
        .layer_shell
        .clone()
        .ok_or_else(|| anyhow::anyhow!("compositor does not expose zwlr_layer_shell_v1"))?;
    let output = state
        .output
        .clone()
        .ok_or_else(|| anyhow::anyhow!("compositor exposed no wl_output"))?;

    // Build the layer surface: fullscreen, overlay layer, click-through.
    let surface = compositor.create_surface(&qh, ());
    let layer_surface = layer_shell.get_layer_surface(
        &surface,
        Some(&output),
        Layer::Overlay,
        "cua-agent-cursor".to_string(),
        &qh,
        (),
    );
    // Anchor to all four edges = full screen.
    layer_surface.set_anchor(Anchor::Top | Anchor::Bottom | Anchor::Left | Anchor::Right);
    layer_surface.set_size(0, 0);
    layer_surface.set_exclusive_zone(-1);
    layer_surface.set_keyboard_interactivity(KeyboardInteractivity::None);

    // Click-through: empty input region. Standard Wayland intentionally does
    // not expose another client's global pointer position, so this surface
    // cannot implement the macOS/Windows/X11 badge-hover reveal without a
    // compositor-owned adapter. Giving it an input region would steal the
    // user's pointer events instead of observing them.
    let region: WlRegion = compositor.create_region(&qh, ());
    surface.set_input_region(Some(&region));
    region.destroy();

    state.surface = Some(surface);
    state.layer_surface = Some(layer_surface);

    // First commit kicks off the configure handshake.
    if let Some(s) = state.surface.as_ref() {
        s.commit();
    }

    // Wait for the first configure event so we know the output dimensions
    // before drawing.
    for _ in 0..10 {
        queue.roundtrip(&mut state)?;
        if state.configured && state.output_w > 0 && state.output_h > 0 {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(50));
    }

    if !state.configured {
        anyhow::bail!("layer surface never received configure event");
    }
    dbg(&format!(
        "configured: w={} h={}",
        state.output_w, state.output_h
    ));

    // Demand-driven main loop. A stable cursor blocks on the command channel;
    // only active motion, click/fade animation, or the exact idle-fade
    // deadline schedules a wake. This avoids display-sized SHM allocation and
    // conversion at 60Hz when no pixel can change while preserving immediate
    // command wakeups.
    let mut last_tick = Instant::now();
    let mut frame_tick_needed = false;
    loop {
        let wait = next_wait(&state.core, frame_tick_needed);
        let (first_cmd, timed_out) = match wait_for_work(&rx, wait) {
            WlWake::Command(cmd) => (Some(cmd), None),
            WlWake::Timeout => (None, Some(wait)),
            WlWake::Disconnected => break,
        };

        let now = Instant::now();
        let elapsed = now.duration_since(last_tick).as_secs_f64();
        last_tick = now;

        let mut dirty = false;
        let mut shutdown = false;
        let mut pending = first_cmd;
        loop {
            let received = pending.take().map(Ok).unwrap_or_else(|| rx.try_recv());
            match received {
                Ok(WlOverlayCmd::Shutdown) => {
                    shutdown = true;
                    break;
                }
                Ok(WlOverlayCmd::Cmd { cmd }) => {
                    // Seed: if the cursor is still at the off-screen sentinel
                    // `(-200, -200)` from `RenderStateCore::new`, snap to a
                    // point near the MoveTo / SnapTo target so the spring
                    // animation starts on-screen. Mirrors X11 overlay.rs's
                    // `seed_start_if_sentinel` helper — without it, the
                    // spring oscillates around the sentinel and the cursor
                    // never reaches the screen.
                    let seed_target = match &cmd {
                        OverlayCommand::MoveTo { x, y, .. }
                        | OverlayCommand::SnapTo { x, y, .. }
                        | OverlayCommand::ClickPulse { x, y } => Some((*x, *y)),
                        _ => None,
                    };
                    if let Some((tx, ty)) = seed_target {
                        if state.core.pos.0 < -50.0 {
                            const SEED_OFFSET: f64 = 16.0;
                            let sx = (tx - SEED_OFFSET).max(2.0);
                            let sy = (ty - SEED_OFFSET).max(2.0);
                            state.core.pos = (sx, sy);
                        }
                    }
                    // apply_command_base consumes every variant the X11
                    // path handles. `move_to_snap_sentinel` / `click_pulse
                    // _sentinel_only` are both `false` here — same as X11.
                    let disabling = matches!(&cmd, OverlayCommand::SetEnabled(false));
                    dirty |= state.core.apply_command_base(cmd, false, false);
                    if disabling {
                        quiesce_hidden(&mut state.core);
                    }
                }
                Ok(WlOverlayCmd::Remove) => {
                    // Single-cursor overlay: removing the active cursor
                    // hides it. Multi-cursor wlroots support can layer on
                    // top of this in a follow-up if needed.
                    dirty |= state.core.visible || state.core.pos.0 >= -100.0;
                    state.core.visible = false;
                    quiesce_hidden(&mut state.core);
                }
                Err(crossbeam_channel::TryRecvError::Empty) => break,
                Err(crossbeam_channel::TryRecvError::Disconnected) => {
                    shutdown = true;
                    break;
                }
            }
        }
        if shutdown {
            break;
        }

        // Advance only on a scheduled animation/fade wake. A command wake
        // applies the new state at dt=0, avoiding a jump proportional to how
        // long the loop was parked.
        if let Some(timeout_kind) = timed_out {
            let dt = match timeout_kind {
                WlWait::Frame => elapsed.min(0.05),
                WlWait::Deadline(_) => elapsed,
                WlWait::Block => unreachable!("a blocking receive cannot time out"),
            };
            state.core.tick_motion(dt);
            dirty = true;
        }
        let next_frame_tick_needed = needs_frame_tick(&state.core);
        if state.configured && (dirty || frame_tick_needed || next_frame_tick_needed) {
            redraw(&mut state, &shm, &qh)?;
            // Flush the committed frame and dispatch wl_buffer.release before
            // parking. The buffer map remains authoritative until release, so
            // no mmap/fd can be reclaimed while the compositor still uses it.
            queue.roundtrip(&mut state)?;
        }
        frame_tick_needed = next_frame_tick_needed;
    }

    if let Some(ls) = state.layer_surface.take() {
        ls.destroy();
    }
    if let Some(s) = state.surface.take() {
        s.destroy();
    }
    queue.roundtrip(&mut state)?;
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum WlWait {
    Block,
    Frame,
    Deadline(Duration),
}

enum WlWake {
    Command(WlOverlayCmd),
    Timeout,
    Disconnected,
}

fn wait_for_work(rx: &Receiver<WlOverlayCmd>, wait: WlWait) -> WlWake {
    match wait {
        WlWait::Block => match rx.recv() {
            Ok(cmd) => WlWake::Command(cmd),
            Err(_) => WlWake::Disconnected,
        },
        WlWait::Frame => match rx.recv_timeout(Duration::from_millis(16)) {
            Ok(cmd) => WlWake::Command(cmd),
            Err(crossbeam_channel::RecvTimeoutError::Timeout) => WlWake::Timeout,
            Err(crossbeam_channel::RecvTimeoutError::Disconnected) => WlWake::Disconnected,
        },
        WlWait::Deadline(timeout) => match rx.recv_timeout(timeout) {
            Ok(cmd) => WlWake::Command(cmd),
            Err(crossbeam_channel::RecvTimeoutError::Timeout) => WlWake::Timeout,
            Err(crossbeam_channel::RecvTimeoutError::Disconnected) => WlWake::Disconnected,
        },
    }
}

fn next_wait(core: &RenderStateCore, frame_tick_needed: bool) -> WlWait {
    if frame_tick_needed || needs_frame_tick(core) {
        return WlWait::Frame;
    }
    idle_fade_wait(core)
        .map(WlWait::Deadline)
        .unwrap_or(WlWait::Block)
}

fn needs_frame_tick(core: &RenderStateCore) -> bool {
    if !core.visible || core.pos.0 < -100.0 {
        return false;
    }
    let fade_start = core.motion.idle_hide_ms / 1000.0;
    core.path.is_some()
        || core.spring.is_some()
        || core.click_t.is_some()
        || core.session_badge_needs_frame_tick()
        || (core.motion.idle_hide_ms > 0.0
            && core.idle_secs >= fade_start
            && core.idle_alpha >= 0.004)
}

fn idle_fade_wait(core: &RenderStateCore) -> Option<Duration> {
    if !core.visible
        || core.pos.0 < -100.0
        || core.motion.idle_hide_ms <= 0.0
        || core.path.is_some()
        || core.spring.is_some()
        || core.click_t.is_some()
    {
        return None;
    }
    let remaining = core.motion.idle_hide_ms / 1000.0 - core.idle_secs;
    (remaining.is_finite() && remaining > 0.0).then(|| Duration::from_secs_f64(remaining))
}

fn quiesce_hidden(core: &mut RenderStateCore) {
    core.path = None;
    core.spring = None;
    core.spring_tgt = None;
    core.click_t = None;
}

/// Render one cursor frame into a fresh wl_shm ARGB8888 buffer and attach
/// it to the layer surface.
///
/// Pipeline:
/// 1. Allocate a memfd-backed wl_shm pool sized at output_w × output_h.
/// 2. Paint the cross-platform cursor (bloom + click pulse + gradient
///    arrow) into a `tiny_skia::Pixmap` via `cursor_overlay::paint_cursor`
///    — same call the X11 path uses.
/// 3. Channel-swap RGBA → BGRA into the wl_shm buffer (wl_shm Argb8888
///    is little-endian BGRA in memory). This is the inverse of the swap
///    in `ext_screencopy::encode_buffer_to_png`.
/// 4. Attach + damage + commit on the layer surface.
///
/// When the cursor is hidden (`core.visible == false`, idle-faded, or
/// off-screen sentinel) the pixmap is all zeros — the surface remains
/// transparent and click-through.
fn redraw(
    state: &mut OverlayState,
    shm: &WlShm,
    qh: &QueueHandle<OverlayState>,
) -> anyhow::Result<()> {
    let Some(surface) = state.surface.as_ref() else {
        return Ok(());
    };
    let w = state.output_w.max(1);
    let h = state.output_h.max(1);
    let stride = w as i32 * 4;
    let size = (stride as usize) * (h as usize);

    // Reuses the same anon_shm pattern as the screencopy path in mod.rs.
    let (fd, ptr) =
        super::anon_shm(size).map_err(|e| anyhow::anyhow!("overlay shm allocation failed: {e}"))?;

    // SAFETY: ptr came from mmap of `size` bytes, lifetime bounded to this
    // function.
    let pixels: &mut [u8] = unsafe { std::slice::from_raw_parts_mut(ptr as *mut u8, size) };

    // Paint the cursor into a tiny_skia pixmap. paint_cursor early-returns
    // when the cursor is hidden / off-screen / idle-faded, so the pixmap
    // is left fully transparent in those cases (which is also what we want
    // for the click-through layer surface).
    let pm_result = tiny_skia::Pixmap::new(w, h);
    let mut pm = match pm_result {
        Some(p) => p,
        // tiny_skia::Pixmap::new only fails on OOM at sizes that fit u32.
        // We refuse to fall back to a 1x1 pixmap because the subsequent
        // RGBA → BGRA loop indexes `src[i+3]` over the full `size` range —
        // a 1x1 source would crash. Surface the allocation failure
        // properly instead.
        None => anyhow::bail!(
            "tiny_skia::Pixmap::new({w}, {h}) failed — out of memory for the overlay buffer"
        ),
    };
    // backing_scale=1.0 matches the X11 path; per-output Wayland scale is
    // a follow-up (would consume `wl_output.scale` and `preferred_buffer
    // _scale` from wl_surface v6).
    cursor_overlay::paint_cursor(&mut pm, &state.core, 0.0, 0.0, None, 1.0);

    // CUA_OVERLAY_DEBUG=1 paints a 60x60 magenta square at the cursor's
    // current pos on top of the gradient arrow. Useful when validating
    // layer-shell visibility on a new compositor — the gradient arrow is
    // small at native scale and easy to miss in a screenshot, while the
    // magenta block is impossible to miss.
    if std::env::var_os("CUA_OVERLAY_DEBUG").is_some() {
        let (cx, cy) = state.core.pos;
        let cx = cx as i32;
        let cy = cy as i32;
        let half = 30i32;
        for dy in -half..half {
            for dx in -half..half {
                let px = cx + dx;
                let py = cy + dy;
                if px < 0 || py < 0 || px >= w as i32 || py >= h as i32 {
                    continue;
                }
                let off = ((py as usize) * (w as usize) + (px as usize)) * 4;
                pm.data_mut()[off] = 0xFF; // R
                pm.data_mut()[off + 1] = 0x00; // G
                pm.data_mut()[off + 2] = 0xFF; // B
                pm.data_mut()[off + 3] = 0xFF; // A
            }
        }
    }

    // RGBA → BGRA channel swap. tiny_skia stores pixels as RGBA8888
    // (premultiplied); wl_shm Argb8888 is little-endian = BGRA in memory.
    // Mirrors the inverse swap in ext_screencopy::encode_buffer_to_png.
    let src = pm.data();
    for i in (0..size).step_by(4) {
        // pm.data() is already RGBA premultiplied; just swap R↔B.
        pixels[i] = src[i + 2]; // B ← R
        pixels[i + 1] = src[i + 1]; // G
        pixels[i + 2] = src[i]; // R ← B
        pixels[i + 3] = src[i + 3]; // A
    }

    use std::os::fd::AsFd as _;
    let pool_fd = unsafe { super::borrowed_fd(fd) };
    let pool: WlShmPool = shm.create_pool(pool_fd.as_fd(), size as i32, qh, ());
    let buffer: WlBuffer = pool.create_buffer(
        0,
        w as i32,
        h as i32,
        stride,
        wl_shm::Format::Argb8888,
        qh,
        (),
    );

    // Track the (mmap, fd) by buffer object id so the wl_buffer.release
    // event Dispatch handler can clean up exactly when the compositor is
    // done with the underlying memory — no leak, no use-after-free.
    let buffer_id = buffer.id().protocol_id();
    state.pending_buffers.insert(buffer_id, (ptr, size, fd));

    dbg(&format!(
        "redraw w={w} h={h} stride={stride} buf_id={buffer_id} pos=({:.1},{:.1}) visible={}",
        state.core.pos.0, state.core.pos.1, state.core.visible
    ));
    surface.attach(Some(&buffer), 0, 0);
    surface.damage_buffer(0, 0, w as i32, h as i32);
    surface.commit();
    pool.destroy();
    Ok(())
}

// ── Wayland Dispatch impls ───────────────────────────────────────────────

impl Dispatch<wl_registry::WlRegistry, ()> for OverlayState {
    fn event(
        state: &mut Self,
        registry: &wl_registry::WlRegistry,
        event: wl_registry::Event,
        _data: &(),
        _conn: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        if let wl_registry::Event::Global {
            name,
            interface,
            version,
        } = event
        {
            match interface.as_str() {
                "wl_compositor" => {
                    state.compositor =
                        Some(registry.bind::<WlCompositor, _, _>(name, version.min(6), qh, ()));
                }
                "wl_shm" => {
                    state.shm = Some(registry.bind::<WlShm, _, _>(name, version.min(1), qh, ()));
                }
                "wl_output" => {
                    if state.output.is_none() {
                        state.output =
                            Some(registry.bind::<WlOutput, _, _>(name, version.min(4), qh, ()));
                    }
                }
                "zwlr_layer_shell_v1" => {
                    state.layer_shell =
                        Some(registry.bind::<ZwlrLayerShellV1, _, _>(name, version.min(4), qh, ()));
                }
                _ => {}
            }
        }
    }
}

impl Dispatch<WlCompositor, ()> for OverlayState {
    fn event(
        _state: &mut Self,
        _: &WlCompositor,
        _: <WlCompositor as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<WlShm, ()> for OverlayState {
    fn event(
        _state: &mut Self,
        _: &WlShm,
        _: <WlShm as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<WlOutput, ()> for OverlayState {
    fn event(
        state: &mut Self,
        _: &WlOutput,
        event: <WlOutput as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        use wayland_client::protocol::wl_output;
        if let wl_output::Event::Mode { width, height, .. } = event {
            if width > 0 && height > 0 {
                state.output_w = width as u32;
                state.output_h = height as u32;
            }
        }
    }
}

impl Dispatch<ZwlrLayerShellV1, ()> for OverlayState {
    fn event(
        _state: &mut Self,
        _: &ZwlrLayerShellV1,
        _: <ZwlrLayerShellV1 as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<ZwlrLayerSurfaceV1, ()> for OverlayState {
    fn event(
        state: &mut Self,
        layer: &ZwlrLayerSurfaceV1,
        event: <ZwlrLayerSurfaceV1 as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let zwlr_layer_surface_v1::Event::Configure {
            serial,
            width,
            height,
        } = event
        {
            layer.ack_configure(serial);
            if width > 0 {
                state.output_w = width;
            }
            if height > 0 {
                state.output_h = height;
            }
            state.configured = true;
        }
    }
}

impl Dispatch<WlSurface, ()> for OverlayState {
    fn event(
        _: &mut Self,
        _: &WlSurface,
        _: <WlSurface as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<WlShmPool, ()> for OverlayState {
    fn event(
        _: &mut Self,
        _: &WlShmPool,
        _: <WlShmPool as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<WlBuffer, ()> for OverlayState {
    fn event(
        state: &mut Self,
        buffer: &WlBuffer,
        event: <WlBuffer as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        use wayland_client::protocol::wl_buffer;
        if matches!(event, wl_buffer::Event::Release) {
            // Compositor is done with the underlying mmap. Free it +
            // close the memfd + destroy the wayland object.
            let id = buffer.id().protocol_id();
            if let Some((ptr, size, fd)) = state.pending_buffers.remove(&id) {
                super::cleanup_mmap(ptr, size, fd);
            }
            buffer.destroy();
        }
    }
}

impl Dispatch<WlRegion, ()> for OverlayState {
    fn event(
        _: &mut Self,
        _: &WlRegion,
        _: <WlRegion as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cursor_overlay::KeyedOverlayCommand;

    fn message(cmd: OverlayCommand) -> OverlayMsg {
        OverlayMsg::Cmd(KeyedOverlayCommand {
            key: "test".to_owned(),
            cmd,
        })
    }

    fn positioned_core() -> RenderStateCore {
        let mut core = RenderStateCore::new(CursorConfig::default());
        core.pos = (100.0, 100.0);
        core.motion.idle_hide_ms = 1_000.0;
        core
    }

    #[test]
    fn fresh_sentinel_overlay_blocks_without_frame_polling() {
        let core = RenderStateCore::new(CursorConfig::default());
        assert_eq!(next_wait(&core, false), WlWait::Block);
        assert!(!needs_frame_tick(&core));
    }

    #[test]
    fn stable_visible_overlay_sleeps_until_idle_fade_deadline() {
        let mut core = positioned_core();
        core.idle_secs = 0.25;
        assert_eq!(
            next_wait(&core, false),
            WlWait::Deadline(Duration::from_millis(750))
        );
        assert!(!needs_frame_tick(&core));
    }

    #[test]
    fn animation_and_fade_use_frame_cadence() {
        let mut core = positioned_core();
        core.click_t = Some(0.0);
        assert!(needs_frame_tick(&core));
        assert_eq!(next_wait(&core, false), WlWait::Frame);

        core.click_t = None;
        core.idle_secs = 1.0;
        core.idle_alpha = 1.0;
        assert!(needs_frame_tick(&core));
        assert_eq!(next_wait(&core, false), WlWait::Frame);
    }

    #[test]
    fn hidden_and_disabled_state_quiesces_deterministically() {
        let mut core = positioned_core();
        core.click_t = Some(0.25);
        core.visible = false;
        quiesce_hidden(&mut core);
        assert!(core.click_t.is_none());
        assert!(core.path.is_none());
        assert!(core.spring.is_none());
        assert_eq!(next_wait(&core, false), WlWait::Block);
    }

    #[test]
    fn blocked_scheduler_wakes_on_command_arrival() {
        let (tx, rx) = bounded(1);
        tx.send(WlOverlayCmd::Remove).unwrap();
        assert!(matches!(
            wait_for_work(&rx, WlWait::Block),
            WlWake::Command(WlOverlayCmd::Remove)
        ));
    }

    #[test]
    fn disabled_config_refuses_forwarding_and_thread_startup() {
        set_config_enabled(false);
        let msg = message(OverlayCommand::SnapTo {
            x: 10.0,
            y: 20.0,
            heading_radians: None,
        });
        let had_thread = TX.get().is_some();
        assert!(!should_forward(false, &msg));
        assert!(!ensure_started());
        assert_eq!(TX.get().is_some(), had_thread);
    }
}
