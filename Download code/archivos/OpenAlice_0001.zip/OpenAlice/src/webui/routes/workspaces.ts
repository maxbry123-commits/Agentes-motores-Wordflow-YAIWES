/**
 * Hono routes for the Workspaces feature, mounted at /api/workspaces.
 *
 * Thin adapter over WorkspaceService — each handler dispatches to the same
 * launcher domain modules (registry / pool / creator / sessionRegistry) that
 * the original `server/src/index.ts` `handleHttp` switch did.
 */

import { Hono } from 'hono';
import { existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { join, resolve as resolvePath } from 'node:path';
import { z } from 'zod';

import { probeByWireShape } from '../../workspaces/agent-probe.js';
import type { WireShape } from '../../ai-providers/preset-catalog.js';

/** A workspace agent's default wire shape when the credential/form doesn't say. */
const DEFAULT_WIRE_BY_AGENT: Record<string, WireShape> = {
  claude: 'anthropic',
  codex: 'openai-responses',
  cursor: 'openai-chat',
  agy: 'google-generative-ai',
  grok: 'openai-chat',
  omp: 'openai-chat',
  opencode: 'openai-chat',
  pi: 'openai-chat',
};

import { listDir, PathTraversal, readWorkspaceFile } from '../../workspaces/file-service.js';
import { gitLog, gitStatus } from '../../workspaces/git-service.js';
import { logger as launcherLogger } from '../../workspaces/logger.js';
import { readWorkspaceMetadata, workspaceMetadataSchema, writeWorkspaceMetadata } from '../../workspaces/workspace-metadata.js';
import {
  normalizeSessionTitle,
  sessionPreferredTitle,
  type SessionRecord,
} from '../../workspaces/session-registry.js';
import { projectPublicSession, projectPublicSessionRuntime, type PublicSession } from '../../workspaces/public-session.js';
import type { WorkspaceMeta } from '../../workspaces/workspace-registry.js';
import { HeadlessCapacityError, HeadlessResumeError, resumeFromRecord, type SessionFactoryContext, type WorkspaceService } from '../../workspaces/service.js';
import {
  parseSessionPresence,
  ResumePresenceError,
  sessionPresence,
} from '../../workspaces/resume-registry.js';
import { SessionDisplayNameError } from '../../workspaces/session-runtime-store.js';
import {
  isAgentRuntime,
  prepareAgentRuntimeWorkspace,
  type CliAdapter,
  type ResolvedSessionRuntimeBinding,
  type WorkspaceAiCred,
} from '../../workspaces/cli-adapter.js';
import { addCredential, readCredentials, readWorkspaceDefaultAgent, setCredentialLastModel, credentialWires, credentialWireShapeEnum, type Credential } from '../../core/config.js';
import { inferCredentialVendor, resolveAnthropicAuthMode } from '../../core/credential-inference.js';
import {
  applyRegisteredModelSemantics,
  compatibleCredentials,
  credentialToWorkspaceAiCred,
  matchCredentialByApiKey,
  resolveInjectionModel,
} from '../../workspaces/credential-injection.js';
import {
  isModelReasoningEffort,
  resolveModelSemantics,
  type ModelReasoningEffort,
  type ModelReasoningMode,
} from '../../ai-providers/model-semantics.js';
import {
  createNativeSessionRuntimeBinding,
  createSessionRuntimeBinding,
  resolveSessionRuntimeBinding,
  SessionRuntimeBindingError,
} from '../../workspaces/session-runtime-binding.js';
import type { SessionCreatedBy } from '../../workspaces/session-metadata.js';
import { sessionMetadata } from '../../workspaces/session-metadata.js';
import {
  readWorkspaceRuntimeSettings,
  rememberWorkspaceRuntimeBinding,
  replaceWorkspaceRuntimeDefaults,
  resolveWorkspaceRuntimeAgent,
  resolveWorkspaceRuntimeSelection,
  workspaceRuntimePreferenceSchema,
} from '../../workspaces/workspace-runtime-settings.js';

import {
  AgentCredentialError,
  getAgentCredentialReadiness,
} from '../../workspaces/agent-credential-readiness.js';
import { validateTerminalViewAttributes } from '../../workspaces/terminal-view-attributes.js';
import {
  readAutoPredictionPreferences,
  readAutoQuantPreferences,
  readHarnessPreferences,
  readQuickChatPreferences,
  rememberAutoPredictionDefaultWorkspace,
  rememberAutoQuantDefaultWorkspace,
  rememberRecentChatWorkspace,
  type AutoPredictionPreferences,
  type AutoQuantPreferences,
  type HarnessPreferences,
  type QuickChatPreferences,
} from '../../core/preferences.js';
import {
  AUTO_PREDICTION_WORKSPACE_TEMPLATE,
  AUTO_QUANT_WORKSPACE_TEMPLATE,
  CHAT_WORKSPACE_TEMPLATE,
} from '../../workspaces/chat-workspace-resolver.js';
import { TemplateUpgradeError } from '../../workspaces/template-upgrade.js';
import { HarnessSourceUpgradeError } from '../../workspaces/harness-source-upgrade.js';
import { WorkspaceAbsorbError } from '../../workspaces/workspace-absorb.js';
import {
  MANAGER_WORKSPACE_ID,
  MANAGER_SYSTEM_PROMPT,
  managerTerminalPrompt,
  managerSkillPath,
} from '../../workspaces/manager-workspace.js';

const workspaceRuntimeModeDefaultsRequestSchema = z.object({
  defaultAgent: z.string().trim().min(1).max(64).nullable(),
  agents: z.record(
    z.string().trim().min(1).max(64),
    workspaceRuntimePreferenceSchema,
  ),
}).strict();

const workspaceRuntimeDefaultsRequestSchema = z.object({
  interactive: workspaceRuntimeModeDefaultsRequestSchema,
  headless: workspaceRuntimeModeDefaultsRequestSchema,
}).strict();

const pausedSessionRuntimeRequestSchema = z.object({
  credentialSource: z.enum(['native', 'vault']),
  credentialSlug: z.string().trim().min(1).max(128).nullable().optional(),
  model: z.string().trim().min(1).max(256).nullable().optional(),
  reasoningEffort: z.enum(['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max', 'ultra']).nullable().optional(),
}).strict().superRefine((value, ctx) => {
  if (value.credentialSource === 'vault' && !value.credentialSlug) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['credentialSlug'],
      message: 'credentialSlug is required for a vault credential',
    });
  }
  if (value.credentialSource === 'native' && value.credentialSlug) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['credentialSlug'],
      message: 'credentialSlug cannot be combined with native runtime authentication',
    });
  }
});

// The spawn body's `resume` value is an AGENT-side session id, whose shape is
// adapter-native: uuid for claude/codex/pi, `ses_<base62>` for opencode. This
// looser shape applies ONLY to the resume intent passed through to the adapter's
// own resume flag; launcher-side record ids use `validId`.
const AGENT_SESSION_ID_RE = /^[A-Za-z0-9_.-]{8,128}$/;

/** Upper bound on a quick-chat seed prompt — matches the headless-dispatch cap. */
const MAX_SEED_PROMPT = 16000;

// In-flight resume coalescing, keyed `${wsId}::${recordId}`. A frontend
// double-fire (two POST /resume within ms — ANG-120) would otherwise both pass
// the "already running?" gate while the session is still paused and each call
// pool.spawn() → two agent processes racing on one transcript. Later callers
// await the in-flight resume; the in-lock pool.get() re-check then yields
// alreadyRunning instead of a second spawn.
const resumeInFlight = new Map<string, Promise<unknown>>();

/** The template quick-chat reuses-or-creates its workspace from. */
interface QuickChatWorkspacePreferenceDeps {
  readQuickChatPreferences(): Promise<QuickChatPreferences>;
  rememberRecentChatWorkspace(workspaceId: string | null): Promise<QuickChatPreferences>;
  readAutoQuantPreferences?(): Promise<AutoQuantPreferences>;
  rememberAutoQuantDefaultWorkspace?(workspaceId: string | null): Promise<AutoQuantPreferences>;
  readAutoPredictionPreferences?(): Promise<AutoPredictionPreferences>;
  rememberAutoPredictionDefaultWorkspace?(workspaceId: string | null): Promise<AutoPredictionPreferences>;
  readHarnessPreferences?(): Promise<HarnessPreferences>;
}

const defaultQuickChatWorkspacePreferenceDeps: QuickChatWorkspacePreferenceDeps = {
  readQuickChatPreferences: () => readQuickChatPreferences(),
  rememberRecentChatWorkspace: (workspaceId) => rememberRecentChatWorkspace(workspaceId),
  readAutoQuantPreferences: () => readAutoQuantPreferences(),
  rememberAutoQuantDefaultWorkspace: (workspaceId) =>
    rememberAutoQuantDefaultWorkspace(workspaceId),
  readAutoPredictionPreferences: () => readAutoPredictionPreferences(),
  rememberAutoPredictionDefaultWorkspace: (workspaceId) =>
    rememberAutoPredictionDefaultWorkspace(workspaceId),
  readHarnessPreferences: () => readHarnessPreferences(),
};

/**
 * Validate an optional quick-chat seed prompt (the first message a fresh
 * interactive TUI opens already working on). Returns the trimmed prompt, `null`
 * when absent/blank (→ a normal unseeded fresh spawn), or a `{error}` to surface
 * as a 400. Mirrors the headless-dispatch validation so the interactive-seed and
 * one-shot paths agree on shape + cap.
 */
function parseSeedPrompt(
  raw: unknown,
): { prompt: string } | { error: string; message: string } | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== 'string') {
    return { error: 'bad_request', message: 'initialPrompt must be a string' };
  }
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  if (trimmed.length > MAX_SEED_PROMPT) {
    return { error: 'prompt_too_long', message: `max ${MAX_SEED_PROMPT} chars` };
  }
  return { prompt: trimmed };
}

function redactLaunchCommand(argv: readonly string[]): readonly string[] {
  const sensitiveName = /(?:api[-_]?key|(?:^|[-_])key(?:[-_]|$)|auth|credential|password|secret|token)/i;
  const out: string[] = [];
  let redactNext = false;
  for (const part of argv) {
    if (redactNext) {
      out.push('<redacted>');
      redactNext = false;
      continue;
    }
    const assignment = /^([^=]+)=(.*)$/.exec(part);
    if (assignment && sensitiveName.test(assignment[1] ?? '')) {
      out.push(`${assignment[1]}=<redacted>`);
      continue;
    }
    out.push(part);
    if (sensitiveName.test(part) && /^--?/.test(part)) {
      redactNext = true;
    }
  }
  return out;
}

/** The 201 body both `/:id/sessions/spawn` and `/quick-chat` return. */
interface SpawnedSessionBody {
  readonly sessionId: string;
  readonly wsId: string;
  readonly name: string;
  readonly pid: number;
  readonly agent: string;
  readonly resumeId: string;
  readonly startedAt: number;
  /** Native Session title, falling back to the launch-time prompt. */
  readonly title: string | null;
}

type OpenHeadlessSessionResult =
  | { readonly ok: true; readonly created: boolean; readonly session: PublicSession }
  | { readonly ok: false; readonly status: 400 | 404 | 409 | 500; readonly body: { error: string; message?: string } };

type SpawnSessionResult =
  | { readonly ok: true; readonly session: SpawnedSessionBody }
  | { readonly ok: false; readonly status: number; readonly body: { error: string; message?: string } };

export function createWorkspaceRoutes(
  svc: WorkspaceService,
  quickChatPreferences: QuickChatWorkspacePreferenceDeps = defaultQuickChatWorkspacePreferenceDeps,
): Hono {
  const app = new Hono();
  const headlessSessionInFlight = new Map<string, Promise<OpenHeadlessSessionResult>>();
  const readAutoQuantPreference = () =>
    (quickChatPreferences.readAutoQuantPreferences ?? readAutoQuantPreferences)();
  const rememberAutoQuantWorkspace = (workspaceId: string | null) =>
    (quickChatPreferences.rememberAutoQuantDefaultWorkspace
      ?? rememberAutoQuantDefaultWorkspace)(workspaceId);
  const resolveAutoQuantDefaultWorkspace = async (): Promise<WorkspaceMeta | undefined> => {
    const preference = await readAutoQuantPreference();
    const workspace = preference.defaultWorkspaceId
      ? svc.registry.get(preference.defaultWorkspaceId)
      : undefined;
    return workspace?.template === AUTO_QUANT_WORKSPACE_TEMPLATE ? workspace : undefined;
  };
  const readAutoPredictionPreference = () =>
    (quickChatPreferences.readAutoPredictionPreferences ?? readAutoPredictionPreferences)();
  const rememberAutoPredictionWorkspace = (workspaceId: string | null) =>
    (quickChatPreferences.rememberAutoPredictionDefaultWorkspace
      ?? rememberAutoPredictionDefaultWorkspace)(workspaceId);
  const resolveAutoPredictionDefaultWorkspace = async (): Promise<WorkspaceMeta | undefined> => {
    const preference = await readAutoPredictionPreference();
    const workspace = preference.defaultWorkspaceId
      ? svc.registry.get(preference.defaultWorkspaceId)
      : undefined;
    return workspace?.template === AUTO_PREDICTION_WORKSPACE_TEMPLATE ? workspace : undefined;
  };
  const readHarnessPreference = () =>
    (quickChatPreferences.readHarnessPreferences ?? readHarnessPreferences)();

  // Renderer truth for hidden/headless terminal color queries. App-global,
  // matching Orca's terminal-view-attribute bridge rather than a spawn env.
  app.put('/terminal-view-attributes', async (c) => {
    const attributes = validateTerminalViewAttributes(await safeJson(c).catch(() => null));
    if (!attributes) {
      return c.json({ error: 'bad_request', message: 'invalid terminal view attributes' }, 400);
    }
    return c.json({ ok: true, changed: svc.pool.setTerminalViewAttributes(attributes) });
  });

  const resolveDefaultAgentId = async (meta: WorkspaceMeta): Promise<string | undefined> => {
    const metadata = await readWorkspaceMetadata(meta.dir);
    if (metadata.ok && metadata.metadata.defaultAgent) {
      const adapter = svc.adapters.get(metadata.metadata.defaultAgent);
      if (adapter && isAgentRuntime(adapter)) return metadata.metadata.defaultAgent;
    }
    const configured = await readWorkspaceDefaultAgent().catch(() => null);
    if (configured) {
      const adapter = svc.adapters.get(configured);
      if (adapter && isAgentRuntime(adapter)) return configured;
    }
    return svc.adapters.list().find(isAgentRuntime)?.id;
  };

  /**
   * Spawn one interactive PTY session in an existing workspace — the shared
   * core of `POST /:id/sessions/spawn` and `POST /quick-chat` (so the two never
   * drift on bootstrap / record-creation / pool-spawn). Resolves the adapter,
   * runs its bootstrap, pre-allocates the SessionRecord, and hands the
   * SessionFactoryContext (incl. the optional fresh-spawn `initialPrompt`) to
   * the pool. Returns the SpawnedSession body or an HTTP-mappable error.
   */
  async function spawnInteractiveSession(
    meta: WorkspaceMeta,
    opts: {
      readonly agentId?: string;
      readonly resume?: SessionFactoryContext['resume'];
      /** Product-level conversation id. Resolved to a native id only here. */
      readonly resumeId?: string;
      readonly initialPrompt?: string;
      readonly title?: string;
      readonly sourceRunId?: string;
      readonly credentialSource?: 'native';
      readonly credentialSlug?: string;
      readonly model?: string;
      readonly reasoningEffort?: ModelReasoningEffort;
      /** Birth stamp when allocating a new product Session (omit when resuming). */
      readonly createdBy?: SessionCreatedBy;
    },
  ): Promise<SpawnSessionResult> {
    const id = meta.id;
    const operationLease = svc.operationGuard?.acquire(id, 'interactive-session-start') ?? null;
    if (svc.operationGuard && !operationLease) {
      return {
        ok: false,
        status: 409,
        body: {
          error: 'workspace_busy',
          message: `workspace is busy with ${svc.operationGuard.current(id) ?? 'another operation'}`,
        },
      };
    }
    try {
    const initialPrompt = opts.initialPrompt;
    let resume = opts.resume;
    const requestedIdentity = opts.resumeId ? svc.resumeRegistry.get(opts.resumeId) : null;
    if (opts.resumeId && !requestedIdentity) {
      return { ok: false, status: 404, body: { error: 'resume_not_found' } };
    }
    if (requestedIdentity && requestedIdentity.wsId !== id) {
      return { ok: false, status: 400, body: { error: 'resume_wrong_workspace' } };
    }
    if (requestedIdentity?.lifecycle === 'retired') {
      return { ok: false, status: 409, body: { error: 'resume_retired', message: 'this Session retired with its Workspace' } };
    }
    if (requestedIdentity && !requestedIdentity.agentSessionId) {
      return { ok: false, status: 409, body: { error: 'resume_not_ready', message: 'runtime session id has not been captured yet' } };
    }
    if (opts.resumeId && svc.isResumeActive?.(opts.resumeId)) {
      return { ok: false, status: 409, body: { error: 'resume_busy', message: 'this conversation already has a running turn' } };
    }
    if (requestedIdentity?.agentSessionId) resume = { sessionId: requestedIdentity.agentSessionId };
    const freshProductSession = !requestedIdentity && meta.id !== MANAGER_WORKSPACE_ID;
    const runtimeSettings = freshProductSession
      ? await readWorkspaceRuntimeSettings(meta.dir)
      : null;
    if (runtimeSettings && !runtimeSettings.ok && runtimeSettings.reason === 'invalid') {
      return {
        ok: false,
        status: 400,
        body: { error: 'workspace_runtime_settings_invalid', message: runtimeSettings.error },
      };
    }
    const preferredAskAliceAgent = runtimeSettings?.ok
      ? resolveWorkspaceRuntimeAgent(runtimeSettings.settings, 'interactive')
      : undefined;
    const preferredAskAliceAdapter = preferredAskAliceAgent
      ? svc.adapters.get(preferredAskAliceAgent)
      : undefined;
    const validPreferredAskAliceAgent = preferredAskAliceAgent && preferredAskAliceAdapter &&
      isAgentRuntime(preferredAskAliceAdapter)
      ? preferredAskAliceAgent
      : undefined;
    const agentId = opts.agentId ?? requestedIdentity?.agent ?? validPreferredAskAliceAgent ?? await resolveDefaultAgentId(meta);
    if (!agentId) {
      return { ok: false, status: 400, body: { error: 'no_agent_runtime', message: 'no agent runtime is registered' } };
    }
    if (!svc.adapters.get(agentId)) {
      return { ok: false, status: 400, body: { error: 'unknown_agent', message: `no adapter: ${agentId}` } };
    }
    const adapter = svc.resolveAdapter(meta, agentId);
    if (requestedIdentity && requestedIdentity.agent !== adapter.id) {
      return { ok: false, status: 400, body: { error: 'resume_wrong_agent' } };
    }
    if (requestedIdentity && (opts.credentialSource || opts.credentialSlug || opts.model || opts.reasoningEffort)) {
      return {
        ok: false,
        status: 400,
        body: {
          error: 'resume_binding_conflict',
          message: 'A resumed Session reuses its persisted credential, model, and effort',
        },
      };
    }
    let sessionRuntime: ResolvedSessionRuntimeBinding | undefined;
    if (isAgentRuntime(adapter)) {
      try {
        const explicitSelection = {
          ...(opts.credentialSource ? { credentialSource: opts.credentialSource } : {}),
          ...(opts.credentialSlug ? { credentialSlug: opts.credentialSlug } : {}),
          ...(opts.model ? { model: opts.model } : {}),
          ...(opts.reasoningEffort ? { reasoningEffort: opts.reasoningEffort } : {}),
        };
        const selection = (freshProductSession
          ? resolveWorkspaceRuntimeSelection(
              runtimeSettings?.ok ? runtimeSettings.settings : null,
              'interactive',
              adapter.id,
              explicitSelection,
            )
          : explicitSelection) ?? {};
        sessionRuntime = requestedIdentity
          ? requestedIdentity.runtimeBinding
            ? await resolveSessionRuntimeBinding({
                adapter,
                cwd: meta.dir,
                binding: requestedIdentity.runtimeBinding,
              })
            : createNativeSessionRuntimeBinding({ adapter })
          : await createSessionRuntimeBinding({
              adapter,
              cwd: meta.dir,
              selection,
              // Read once at the route boundary so credential resolution and
              // the launch request share one vault snapshot. Native runtime
              // auth deliberately avoids touching the vault.
              ...(selection.credentialSlug ? { credentials: await readCredentials() } : {}),
            });
      } catch (err) {
        if (err instanceof SessionRuntimeBindingError) {
          return { ok: false, status: 400, body: { error: err.code, message: err.message } };
        }
        launcherLogger.warn('session_runtime.resolve_failed', { id, agent: adapter.id, err });
        return { ok: false, status: 500, body: { error: 'session_runtime_failed', message: (err as Error).message } };
      }
    } else if (opts.credentialSource || opts.credentialSlug || opts.model || opts.reasoningEffort) {
      return { ok: false, status: 400, body: { error: 'runtime_selection_unsupported' } };
    }
    try {
      await prepareAgentRuntimeWorkspace(adapter, {
        wsId: id,
        cwd: meta.dir,
        launcherRepoRoot: svc.config.launcherRepoRoot,
      });
    } catch (err) {
      launcherLogger.error('adapter.prepare_workspace_failed', { id, agent: adapter.id, err });
      return { ok: false, status: 500, body: { error: 'bootstrap_failed', message: (err as Error).message } };
    }
    await svc.sessionRegistry.ensureLoaded(id);
    const prefix = adapter.namePrefix ?? adapter.id[0] ?? 's';
    const fallbackTitle = normalizeSessionTitle(opts.title) ?? normalizeSessionTitle(initialPrompt);
    const claimedResume = opts.resumeId
      ? (svc.claimResume?.(opts.resumeId) ?? true)
      : false;
    if (opts.resumeId && !claimedResume) {
      return { ok: false, status: 409, body: { error: 'resume_busy', message: 'this conversation already has a running turn' } };
    }
    const releaseClaim = () => {
      if (claimedResume && opts.resumeId) svc.releaseResume?.(opts.resumeId);
    };
    let productSession: Awaited<ReturnType<typeof svc.sessionCoordinator.ensure>>;
    try {
      productSession = await svc.sessionCoordinator.ensure({
        ...(opts.resumeId ? { resumeId: opts.resumeId } : {}),
        wsId: id,
        agent: adapter.id,
        namePrefix: prefix,
        ...(resume && resume !== 'last' ? { agentSessionId: resume.sessionId } : {}),
        ...(sessionRuntime ? { runtimeBinding: sessionRuntime.binding } : {}),
        // Birth is first-write-wins; only stamp when allocating a new identity.
        ...(!opts.resumeId && opts.createdBy
          ? { metadata: sessionMetadata(opts.createdBy) }
          : {}),
        state: 'running',
        surface: 'terminal',
        ...(fallbackTitle ? { fallbackTitle } : {}),
        ...(opts.sourceRunId ? { sourceRunId: opts.sourceRunId } : {}),
      });
    } catch (err) {
      releaseClaim();
      return { ok: false, status: 500, body: { error: 'resume_registry_failed', message: (err as Error).message } };
    }
    const identity = productSession.identity;
    const record = productSession.session;
    const recordId = record.id;
    const recordName = record.name;
    try {
      if (productSession.created) {
        await svc.recordAgentRuntime?.('session.born', {
          workspaceId: id,
          resumeId: identity.resumeId,
          agent: adapter.id,
          sessionRecordId: record.id,
        })
      }
      const ctx: SessionFactoryContext = {
        ...(resume !== undefined ? { resume } : {}),
        agentId,
        ...(initialPrompt !== undefined ? { initialPrompt } : {}),
        recordId,
        recordName,
        ...(sessionRuntime ? { sessionRuntime } : {}),
      };
      const session = svc.pool.spawn(id, ctx);
      if (freshProductSession && sessionRuntime && existsSync(meta.dir)) {
        await rememberWorkspaceRuntimeBinding({
          wsDir: meta.dir,
          mode: 'interactive',
          agent: adapter.id,
          runtime: sessionRuntime,
        }).catch((err) => launcherLogger.warn('workspace.runtime_preference_write_failed', {
          wsId: id,
          mode: 'interactive',
          agent: adapter.id,
          err,
        }));
      }
      launcherLogger.info('workspace.session_spawned', {
        id,
        sessionId: session.recordId,
        name: session.name,
        pid: session.pid,
        agent: adapter.id,
        resume: resume === undefined ? null : resume === 'last' ? 'last' : resume.sessionId,
        seeded: resume === undefined && !!initialPrompt,
      });
      await svc.recordAgentRuntime?.('runtime.started', {
        workspaceId: id,
        resumeId: identity.resumeId,
        agent: adapter.id,
        sessionRecordId: record.id,
        surface: 'terminal',
        cause: { kind: 'ui' },
      })
      releaseClaim();
      return {
        ok: true,
        session: {
          sessionId: session.recordId,
          wsId: session.wsId,
          name: session.name,
          pid: session.pid,
          agent: adapter.id,
          resumeId: identity.resumeId,
          startedAt: session.startedAt,
          title: sessionPreferredTitle(record) ?? null,
        },
      };
    } catch (err) {
      releaseClaim();
      await svc.sessionCoordinator.transition({
        wsId: id,
        resumeId: record.resumeId,
        state: 'paused',
        surface: 'terminal',
      }).catch(() => undefined);
      launcherLogger.error('workspace.session_spawn_failed', { id, err });
      await svc.recordAgentRuntime?.('runtime.spawn_failed', {
        workspaceId: id,
        resumeId: record.resumeId,
        agent: adapter.id,
        sessionRecordId: record.id,
        surface: 'terminal',
        cause: { kind: 'ui' },
        error: (err as Error).message,
      })
      return { ok: false, status: 500, body: { error: 'spawn_failed', message: (err as Error).message } };
    }
    } finally {
      operationLease?.release();
    }
  }

  const publicSession = (record: SessionRecord): PublicSession => {
    const terminal = svc.pool.get(record.id);
    const browser = svc.webPi?.get(record.id) ?? null;
    const identity = svc.resumeRegistry.get(record.resumeId);
    const binding = identity?.runtimeBinding;
    return projectPublicSession(record, {
      terminal,
      webPi: browser,
      headless: svc.isResumeActive(record.resumeId),
      runtimeBinding: binding,
      ...(identity?.displayName ? { displayName: identity.displayName } : {}),
      ...(identity ? { presence: sessionPresence(identity) } : {}),
    });
  };

  const mappedResumeForRecord = (
    record: SessionRecord,
    adapter: CliAdapter,
  ): SessionFactoryContext['resume'] => {
    const nativeId = svc.resumeRegistry.get(record.resumeId)?.agentSessionId;
    return nativeId && adapter.capabilities.resumeById
      ? { sessionId: nativeId }
      : resumeFromRecord(record, adapter);
  };

  const openResumeAsSession = async (
    meta: WorkspaceMeta,
    resumeId: string,
    title?: string,
  ): Promise<OpenHeadlessSessionResult> => {
    await svc.sessionRegistry.ensureLoaded(meta.id);
    const existing = svc.sessionRegistry.findByResumeId(meta.id, resumeId);
    if (existing && (svc.pool.get(existing.id) || svc.webPi.get(existing.id))) {
      return { ok: true, created: false, session: publicSession(existing) };
    }
    const identity = svc.resumeRegistry.get(resumeId);
    if (!identity || identity.wsId !== meta.id) return { ok: false, status: 404, body: { error: 'resume_not_found' } };
    if (identity.lifecycle === 'retired') {
      return { ok: false, status: 409, body: { error: 'resume_retired', message: 'this Session retired with its Workspace' } };
    }
    const task = identity.latestTaskId ? svc.headlessTasks.get(identity.latestTaskId) : null;
    if (task?.status === 'running') {
      return {
        ok: false,
        status: 409,
        body: { error: 'run_still_running', message: 'wait for the headless run to finish before continuing it interactively' },
      };
    }

    if (!identity.agentSessionId) {
      return {
        ok: false,
        status: 409,
        body: { error: 'session_unavailable', message: 'this run did not capture a resumable agent session id' },
      };
    }
    const adapter = svc.adapters.get(identity.agent);
    if (!adapter || !adapter.capabilities.resumeById) {
      return {
        ok: false,
        status: 409,
        body: { error: 'resume_unsupported', message: `${identity.agent} cannot resume this conversation` },
      };
    }

    const spawned = await spawnInteractiveSession(meta, {
      agentId: identity.agent,
      resumeId,
      title: task?.prompt ?? title ?? `Conversation ${resumeId}`,
      ...(task ? { sourceRunId: task.taskId } : {}),
    });
    if (!spawned.ok) {
      return {
        ok: false,
        status: spawned.status === 400 ? 400 : 500,
        body: spawned.body,
      };
    }
    const record = svc.sessionRegistry.get(meta.id, spawned.session.sessionId);
    if (!record) {
      return { ok: false, status: 500, body: { error: 'registry_failed', message: 'spawned session record is missing' } };
    }
    return { ok: true, created: true, session: publicSession(record) };
  };

  const rememberRecentChat = async (meta: WorkspaceMeta): Promise<void> => {
    if (meta.template !== CHAT_WORKSPACE_TEMPLATE) return;
    try {
      await quickChatPreferences.rememberRecentChatWorkspace(meta.id);
    } catch (err) {
      launcherLogger.warn('quick_chat.preference_write_failed', { id: meta.id, err });
    }
  };

  const managerWebPiOptions = {
    appendSystemPrompt: MANAGER_SYSTEM_PROMPT,
    skills: [managerSkillPath(svc.config.launcherRepoRoot)],
    // WebPi has no TUI in which it could render Pi's trust prompt. Entering the
    // explicit manager surface is the user's approval for its launcher-owned
    // skill and active-office-floor cwd.
    approveProject: true,
  } as const;

  const publicManager = async () => {
    const meta = svc.managerWorkspace;
    await svc.sessionRegistry.ensureLoaded(meta.id);
    void svc.refreshSessionTitles?.(meta);
    return {
      id: meta.id,
      tag: meta.tag,
      activeWorkspaceCount: svc.registry.list().length,
      sessions: svc.sessionRegistry
        .listFor(meta.id)
        .filter((record) => {
          const identity = svc.resumeRegistry.get(record.resumeId);
          return identity?.lifecycle !== 'retired' && sessionPresence(identity) !== 'deleted';
        })
        .map(publicSession)
        .sort((a, b) => b.lastActiveAt.localeCompare(a.lastActiveAt)),
    };
  };

  // ── launcher-owned Workspace manager ───────────────────────────────────
  // The manager's cwd is the active office floor, but it is intentionally not
  // inserted into the business Workspace registry. Its sessions live in the
  // same durable Session/Resume registries. Pi opens through WebPi; the other
  // supported agent runtimes keep their native TUI surface.
  app.get('/manager', async (c) => c.json({ manager: await publicManager() }));

  app.post('/manager/quick-start', async (c) => {
    let prompt: string;
    let agentId: string | undefined;
    let credentialSource: 'native' | undefined;
    let credentialSlug: string | undefined;
    let model: string | undefined;
    let reasoningEffort: ModelReasoningEffort | undefined;
    try {
      const body = await safeJson(c);
      const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
      const seed = parseSeedPrompt(fields['prompt']);
      if (seed === null) return c.json({ error: 'prompt_required' }, 400);
      if ('error' in seed) return c.json(seed, 400);
      prompt = seed.prompt;
      if (typeof fields['agent'] === 'string' && fields['agent'].length > 0) {
        agentId = fields['agent'];
      }
      if (typeof fields['credentialSlug'] === 'string' && fields['credentialSlug'].length > 0) {
        credentialSlug = fields['credentialSlug'];
      }
      if (fields['credentialSource'] === 'native') credentialSource = 'native';
      const rawModel = fields['model'];
      if (typeof rawModel === 'string' && rawModel.trim().length > 0) model = rawModel.trim();
      const rawEffort = fields['reasoningEffort'];
      if (isModelReasoningEffort(rawEffort)) reasoningEffort = rawEffort;
    } catch (error) {
      return c.json({ error: 'bad_request', message: (error as Error).message }, 400);
    }

    const meta = svc.managerWorkspace;
    const resolvedAgentId = agentId ?? await resolveDefaultAgentId(meta);
    if (!resolvedAgentId) {
      return c.json({ error: 'no_agent_runtime', message: 'no agent runtime is registered' }, 400);
    }
    const resolvedAdapter = svc.adapters.get(resolvedAgentId);
    if (!resolvedAdapter) {
      return c.json({ error: 'unknown_agent', message: `no adapter: ${resolvedAgentId}` }, 400);
    }
    if (!isAgentRuntime(resolvedAdapter)) {
      return c.json({
        error: 'unsupported_agent_runtime',
        message: `${resolvedAgentId} is not an agent runtime`,
      }, 400);
    }
    const spawned = await spawnInteractiveSession(meta, {
      agentId: resolvedAgentId,
      ...(credentialSource ? { credentialSource } : {}),
      ...(credentialSlug ? { credentialSlug } : {}),
      ...(model ? { model } : {}),
      ...(reasoningEffort ? { reasoningEffort } : {}),
      ...(resolvedAgentId === 'pi' ? {} : { initialPrompt: managerTerminalPrompt(prompt) }),
      title: prompt,
      createdBy: { kind: 'interactive', surface: 'manager' },
    });
    if (!spawned.ok) return c.json(spawned.body, spawned.status as 400 | 409 | 500);

    const record = svc.sessionRegistry.get(meta.id, spawned.session.sessionId);
    if (!record) return c.json({ error: 'registry_failed', message: 'manager Session record is missing' }, 500);

    if (record.agent !== 'pi') {
      return c.json({
        manager: await publicManager(),
        session: publicSession(record),
        snapshot: null,
      }, 201);
    }

    try {
      // A fresh native Pi id is allocated by the ordinary interactive spawn
      // seam. Stop its unused TUI immediately, then reopen that exact native
      // conversation in RPC mode and submit the visible user prompt.
      svc.pool.disposeToken(record.id, 'switch fresh manager Session to WebPi');
      await svc.startWebPiSession(meta, record, managerWebPiOptions);
      const snapshot = await svc.webPi.prompt(record.id, prompt);
      return c.json({
        manager: await publicManager(),
        session: publicSession(record),
        snapshot,
      }, 201);
    } catch (error) {
      await svc.sessionRegistry.update(meta.id, record.id, {
        state: 'paused',
        surface: 'webpi',
        lastActiveAt: new Date().toISOString(),
      }).catch(() => undefined);
      launcherLogger.error('workspace_manager.quick_start_failed', { recordId: record.id, error });
      return c.json({ error: 'manager_start_failed', message: (error as Error).message }, 500);
    }
  });

  // Deprecated compatibility inspection for native project config. Managed
  // launch surfaces use `.alice/settings.json` and do not call this helper.
  const detectWorkspaceCred = async (
    meta: WorkspaceMeta,
    agentId: string,
    credentials: Record<string, Credential>,
  ): Promise<{
    slug: string | null;
    model: string | null;
    contextWindow: number | null;
    wireShape: WireShape | null;
    reasoning: boolean | null;
    reasoningEffort: WorkspaceAiCred['reasoningEffort'];
    reasoningMode: ModelReasoningMode | null;
    reasoningDefaultEnabled: boolean | null;
  } | null> => {
    const adapter = svc.adapters.get(agentId);
    if (!adapter?.readAiConfig) return null;
    const cfg = await adapter.readAiConfig(meta.dir).catch(() => null);
    if (!cfg) return null;
    const slug = matchCredentialByApiKey(credentials, cfg.apiKey);
    const vendor = slug
      ? credentials[slug]?.vendor
      : inferCredentialVendor({
          agent: agentId,
          baseUrl: cfg.baseUrl ?? undefined,
          wireShape: cfg.wireShape ?? undefined,
        });
    const reasoningSemantics = resolveModelSemantics(vendor, cfg.model)?.reasoning;
    return {
      slug,
      model: cfg.model ?? null,
      contextWindow: cfg.contextWindow ?? null,
      wireShape: cfg.wireShape ?? null,
      reasoning: cfg.reasoning ?? null,
      reasoningEffort: cfg.reasoningEffort ?? null,
      reasoningMode: reasoningSemantics?.mode ?? null,
      reasoningDefaultEnabled: reasoningSemantics?.defaultEnabled ?? null,
    };
  };

  // ── templates / agents ───────────────────────────────────────────────────

  app.get('/templates', (c) => {
    return c.json({
      templates: svc.templates.list().map((t) => ({
        name: t.name,
        ...(t.description !== undefined ? { description: t.description } : {}),
        ...(t.displayName !== undefined ? { displayName: t.displayName } : {}),
        ...(t.groupOrder !== undefined ? { groupOrder: t.groupOrder } : {}),
        ...(t.community !== undefined ? { community: t.community } : {}),
        defaultAgents: t.defaultAgents,
        version: t.version,
        hasReadme: t.readmePath !== undefined,
        ...(t.source ? { source: t.source } : {}),
      })),
    });
  });

  // Raw README markdown (frontmatter included — the client strips it before
  // rendering). 404 when the template doesn't ship a README yet; we don't
  // synthesize a placeholder. Cheap on-demand disk read, no cache.
  app.get('/templates/:name/readme', async (c) => {
    const name = c.req.param('name');
    const tpl = svc.templates.get(name);
    if (!tpl) return c.json({ error: 'unknown_template' }, 404);
    if (!tpl.readmePath) return c.json({ error: 'no_readme' }, 404);
    try {
      const raw = await readFile(tpl.readmePath, 'utf8');
      return c.body(raw, 200, { 'content-type': 'text/markdown; charset=utf-8' });
    } catch (err) {
      launcherLogger.warn('template.readme_read_failed', { name, err });
      return c.json({ error: 'read_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/agents', (c) => {
    // Probe the host PATH so the frontend can mark missing runtimes and guide
    // the user to install them — registration ≠ installed (see agent-detect.ts).
    const availability = svc.detectAgents();
    return c.json({
      agents: svc.adapters.list().map((a) => {
        const av = availability[a.id];
        return {
          id: a.id,
          displayName: a.displayName,
          kind: isAgentRuntime(a) ? 'agent' : 'utility',
          capabilities: a.capabilities,
          installed: av?.installed ?? true,
          binPath: av?.path ?? null,
        };
      }),
    });
  });

  app.get('/:id/launch-plan', (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);

    const agentId = c.req.query('agent')?.trim();
    if (!agentId) {
      return c.json({ error: 'agent_required', message: 'agent query parameter is required' }, 400);
    }
    const adapter = svc.adapters.get(agentId);
    if (!adapter) return c.json({ error: 'unknown_agent' }, 400);

    const availability = svc.detectAgents()[agentId];
    const plan = svc.computeSpawnPlan(meta, adapter, undefined);
    return c.json({
      workspace: {
        id: meta.id,
        tag: meta.tag,
        dir: meta.dir,
      },
      agent: {
        id: adapter.id,
        displayName: adapter.displayName,
        kind: isAgentRuntime(adapter) ? 'agent' : 'utility',
        installed: availability?.installed ?? true,
        binPath: availability?.path ?? null,
        capabilities: adapter.capabilities,
      },
      launch: {
        intent: 'fresh',
        mode: plan.launchMode,
        composedCommand: redactLaunchCommand(plan.composedCommand),
        resolvedCommand: redactLaunchCommand(plan.resolvedCommand),
        cwd: plan.spawnCwd,
        envPWD: plan.envPWD,
        environment: plan.environment,
        transcriptDir: plan.transcriptDir,
      },
    });
  });

  app.get('/agent-runtime-readiness', (c) => {
    return c.json(svc.getAgentRuntimeReadiness());
  });

  app.post('/agent-runtime-readiness/probe', async (c) => {
    const body = await safeJson(c).catch(() => null);
    const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
    const rawAgent = fields['agent'];
    let agent: string | undefined;
    if (rawAgent !== undefined) {
      if (typeof rawAgent !== 'string' || rawAgent.length === 0) {
        return c.json({ error: 'bad_request', message: 'agent must be a non-empty string' }, 400);
      }
      const adapter = svc.adapters.get(rawAgent);
      if (!adapter || !isAgentRuntime(adapter)) {
        return c.json({ error: 'unknown_agent', message: `no agent runtime: ${rawAgent}` }, 400);
      }
      agent = rawAgent;
    }
    try {
      return c.json(await svc.probeAgentRuntimeReadiness(agent));
    } catch (err) {
      launcherLogger.warn('agent_runtime_readiness.probe_failed', { agent, err });
      return c.json(
        { error: 'runtime_readiness_probe_failed', message: (err as Error).message },
        500,
      );
    }
  });

  // ── workspaces collection ────────────────────────────────────────────────

  app.get('/', async (c) => {
    const workspaces = await Promise.all(svc.registry.list().map((w) => svc.publicMeta(w)));
    return c.json({ workspaces });
  });

  app.get('/departed', (c) => {
    return c.json({ workspaces: svc.lifecycle.listDeparted() });
  });

  app.post('/departed/:id/restore', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    try {
      const result = await svc.lifecycle.restore(id);
      if (result.ok) return c.json(result);
      const status = result.code === 'not_found' ? 404 : 409;
      return c.json({ error: result.code, message: result.message }, status);
    } catch (err) {
      launcherLogger.error('workspace.restore_failed', { id, err });
      return c.json({ error: 'restore_failed', message: (err as Error).message }, 500);
    }
  });

  app.delete('/departed/:id', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    try {
      const result = await svc.lifecycle.purge(id);
      if (result.ok) return c.json(result);
      const status = result.code === 'not_found' ? 404 : 409;
      return c.json({ error: result.code, message: result.message }, status);
    } catch (err) {
      launcherLogger.error('workspace.purge_failed', { id, err });
      return c.json({ error: 'purge_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/auto-quant/default-workspace', async (c) => {
    try {
      const preference = await readAutoQuantPreference();
      const configured = preference.defaultWorkspaceId;
      const workspace = configured ? svc.registry.get(configured) : undefined;
      const valid = workspace?.template === AUTO_QUANT_WORKSPACE_TEMPLATE;
      return c.json({
        defaultWorkspaceId: valid ? workspace.id : null,
        configuredWorkspaceId: configured,
        ready: valid,
      });
    } catch (err) {
      launcherLogger.warn('auto_quant.preference_read_failed', { err });
      return c.json({ error: 'preferences_read_failed', message: (err as Error).message }, 500);
    }
  });

  app.put('/auto-quant/default-workspace', async (c) => {
    const body = await safeJson(c).catch(() => null);
    const workspaceId = body && typeof body === 'object'
      ? (body as Record<string, unknown>)['workspaceId']
      : undefined;
    if (typeof workspaceId !== 'string' || !validId(workspaceId)) {
      return c.json({ error: 'invalid_workspace_id' }, 400);
    }
    const workspace = svc.registry.get(workspaceId);
    if (!workspace) return c.json({ error: 'workspace_not_found' }, 404);
    if (workspace.template !== AUTO_QUANT_WORKSPACE_TEMPLATE) {
      return c.json({ error: 'workspace_template_mismatch' }, 400);
    }
    try {
      await rememberAutoQuantWorkspace(workspace.id);
      return c.json({ defaultWorkspaceId: workspace.id, ready: true });
    } catch (err) {
      launcherLogger.warn('auto_quant.preference_write_failed', { id: workspace.id, err });
      return c.json({ error: 'preferences_write_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/chat/initialize', async (c) => {
    try {
      const preference = await quickChatPreferences.readQuickChatPreferences();
      const existed = svc.registry.list().some(
        (workspace) => workspace.template === CHAT_WORKSPACE_TEMPLATE,
      );
      const result = await svc.resolveOrCreateChatWorkspace(preference.recentChatWorkspaceId);
      if (!result.ok) {
        const status =
          result.code === 'tag_in_use' ? 409
          : result.code === 'unknown_template' ? 400
          : result.code === 'unknown_source_version' ? 400
          : result.code === 'invalid_tag' ? 400
          : 500;
        return c.json({ error: result.code, message: result.message }, status as 400 | 409 | 500);
      }
      await quickChatPreferences.rememberRecentChatWorkspace(result.workspace.id);
      return c.json(
        { workspace: await svc.publicMeta(result.workspace) },
        existed ? 200 : 201,
      );
    } catch (err) {
      launcherLogger.error('chat.initialize_failed', { err });
      return c.json({ error: 'chat_initialize_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/auto-quant/initialize', async (c) => {
    try {
      const preference = await readAutoQuantPreference();
      const configured = preference.defaultWorkspaceId
        ? svc.registry.get(preference.defaultWorkspaceId)
        : undefined;
      if (configured?.template === AUTO_QUANT_WORKSPACE_TEMPLATE) {
        return c.json({ workspace: await svc.publicMeta(configured) });
      }
      if (svc.registry.list().some((workspace) =>
        workspace.template === AUTO_QUANT_WORKSPACE_TEMPLATE)) {
        return c.json({
          error: 'auto_quant_workspace_selection_required',
          message: 'select an existing AutoQuant Workspace before continuing',
        }, 409);
      }

      const result = await svc.resolveOrCreateAutoQuantWorkspace();
      if (!result.ok) {
        const status =
          result.code === 'tag_in_use' ? 409
          : result.code === 'unknown_template' ? 400
          : result.code === 'unknown_source_version' ? 400
          : result.code === 'invalid_tag' ? 400
          : 500;
        return c.json({ error: result.code, message: result.message }, status as 400 | 409 | 500);
      }
      await rememberAutoQuantWorkspace(result.workspace.id);
      return c.json({ workspace: await svc.publicMeta(result.workspace) }, 201);
    } catch (err) {
      launcherLogger.error('auto_quant.initialize_failed', { err });
      return c.json({ error: 'auto_quant_initialize_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/auto-prediction/default-workspace', async (c) => {
    try {
      const preference = await readAutoPredictionPreference();
      const configured = preference.defaultWorkspaceId;
      const workspace = configured ? svc.registry.get(configured) : undefined;
      const valid = workspace?.template === AUTO_PREDICTION_WORKSPACE_TEMPLATE;
      return c.json({
        defaultWorkspaceId: valid ? workspace.id : null,
        configuredWorkspaceId: configured,
        ready: valid,
      });
    } catch (err) {
      launcherLogger.warn('auto_prediction.preference_read_failed', { err });
      return c.json({ error: 'preferences_read_failed', message: (err as Error).message }, 500);
    }
  });

  app.put('/auto-prediction/default-workspace', async (c) => {
    const body = await safeJson(c).catch(() => null);
    const workspaceId = body && typeof body === 'object'
      ? (body as Record<string, unknown>)['workspaceId']
      : undefined;
    if (typeof workspaceId !== 'string' || !validId(workspaceId)) {
      return c.json({ error: 'invalid_workspace_id' }, 400);
    }
    const workspace = svc.registry.get(workspaceId);
    if (!workspace) return c.json({ error: 'workspace_not_found' }, 404);
    if (workspace.template !== AUTO_PREDICTION_WORKSPACE_TEMPLATE) {
      return c.json({ error: 'workspace_template_mismatch' }, 400);
    }
    try {
      await rememberAutoPredictionWorkspace(workspace.id);
      return c.json({ defaultWorkspaceId: workspace.id, ready: true });
    } catch (err) {
      launcherLogger.warn('auto_prediction.preference_write_failed', { id: workspace.id, err });
      return c.json({ error: 'preferences_write_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/auto-prediction/initialize', async (c) => {
    try {
      const preference = await readAutoPredictionPreference();
      const configured = preference.defaultWorkspaceId
        ? svc.registry.get(preference.defaultWorkspaceId)
        : undefined;
      if (configured?.template === AUTO_PREDICTION_WORKSPACE_TEMPLATE) {
        return c.json({ workspace: await svc.publicMeta(configured) });
      }
      if (svc.registry.list().some((workspace) =>
        workspace.template === AUTO_PREDICTION_WORKSPACE_TEMPLATE)) {
        return c.json({
          error: 'auto_prediction_workspace_selection_required',
          message: 'select an existing Auto Prediction Workspace before continuing',
        }, 409);
      }

      const result = await svc.resolveOrCreateAutoPredictionWorkspace();
      if (!result.ok) {
        const status =
          result.code === 'tag_in_use' ? 409
          : result.code === 'unknown_template' ? 400
          : result.code === 'unknown_source_version' ? 400
          : result.code === 'invalid_tag' ? 400
          : 500;
        return c.json({ error: result.code, message: result.message }, status as 400 | 409 | 500);
      }
      await rememberAutoPredictionWorkspace(result.workspace.id);
      return c.json({ workspace: await svc.publicMeta(result.workspace) }, 201);
    } catch (err) {
      launcherLogger.error('auto_prediction.initialize_failed', { err });
      return c.json({ error: 'auto_prediction_initialize_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/', async (c) => {
    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
    const tag = fields['tag'];
    if (typeof tag !== 'string') {
      return c.json({ error: 'tag_required' }, 400);
    }
    const rawTemplate = fields['template'];
    let templateName: string;
    if (typeof rawTemplate === 'string' && rawTemplate.length > 0) {
      templateName = rawTemplate;
    } else {
      const def = svc.templates.defaultName();
      if (!def) {
        return c.json({
          error: 'no_templates_configured',
          message: 'no templates discovered; set AQ_TEMPLATES_DIR or AQ_BOOTSTRAP_SCRIPT',
        }, 500);
      }
      templateName = def;
    }
    const rawSourceVersion = fields['sourceVersion'];
    const sourceVersion = typeof rawSourceVersion === 'string' && rawSourceVersion.length > 0
      ? rawSourceVersion
      : undefined;
    const result = await svc.creator.create(
      tag,
      templateName,
      sourceVersion,
    );
    if (!result.ok) {
      const status =
        result.code === 'invalid_tag' ? 400
        : result.code === 'unknown_template' ? 400
        : result.code === 'unknown_source_version' ? 400
        : result.code === 'tag_in_use' ? 409
        : result.code === 'insufficient_storage' ? 507
        : 500;
      return c.json({
        error: result.code,
        message: result.message,
        stderr: 'stderr' in result && result.stderr ? result.stderr.slice(-4000) : undefined,
      }, status);
    }
    return c.json({ workspace: await svc.publicMeta(result.workspace) }, 201);
  });

  app.patch('/:id/metadata', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);

    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
    const current = await readWorkspaceMetadata(meta.dir);
    const nextObj: Record<string, unknown> = current.ok ? { ...current.metadata } : {};
    if ('displayName' in fields) {
      const v = fields['displayName'];
      if (v === null) delete nextObj['displayName'];
      else nextObj['displayName'] = v;
    }
    if ('description' in fields) {
      const v = fields['description'];
      if (v === null) delete nextObj['description'];
      else nextObj['description'] = v;
    }
    if ('defaultAgent' in fields) {
      const v = fields['defaultAgent'];
      if (v === null) {
        delete nextObj['defaultAgent'];
      } else if (typeof v === 'string') {
        const adapter = svc.adapters.get(v);
        if (!adapter || !isAgentRuntime(adapter)) {
          return c.json({ error: 'invalid_agent', message: `unknown agent runtime: ${v}` }, 400);
        }
        nextObj['defaultAgent'] = v;
      } else {
        return c.json({ error: 'invalid_agent', message: 'defaultAgent must be a runtime id or null' }, 400);
      }
    }
    const next = workspaceMetadataSchema.safeParse(nextObj);
    if (!next.success) {
      return c.json({
        error: 'invalid_metadata',
        message: next.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; '),
      }, 400);
    }
    try {
      await writeWorkspaceMetadata(meta.dir, next.data);
      launcherLogger.info('workspace.metadata_saved', { id });
      return c.json({ workspace: await svc.publicMeta(meta) });
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('workspace.metadata_write_failed', { id, err });
      return c.json({ error: 'write_failed', message: (err as Error).message }, 500);
    }
  });

  app.put('/:id/runtime-settings', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    const parsed = workspaceRuntimeDefaultsRequestSchema.safeParse(await safeJson(c));
    if (!parsed.success) {
      return c.json({
        error: 'invalid_runtime_settings',
        message: parsed.error.issues.map((issue) => `${issue.path.join('.')}: ${issue.message}`).join('; '),
      }, 400);
    }
    const validateAgent = (mode: 'interactive' | 'headless', agent: string): string | null => {
      const adapter = svc.adapters.get(agent);
      if (!adapter || !isAgentRuntime(adapter)) return `unknown agent runtime: ${agent}`;
      if (mode === 'headless' && (!adapter.capabilities.headless || !adapter.composeHeadlessCommand)) {
        return `agent runtime does not support headless launches: ${agent}`;
      }
      return null;
    };
    const credentials: Record<string, Credential> = await readCredentials().catch(() => ({}));
    for (const mode of ['interactive', 'headless'] as const) {
      const modeDefaults = parsed.data[mode];
      if (modeDefaults.defaultAgent) {
        const error = validateAgent(mode, modeDefaults.defaultAgent);
        if (error) return c.json({ error: 'invalid_agent', message: error }, 400);
      }
      for (const [agent, preference] of Object.entries(modeDefaults.agents)) {
        const error = validateAgent(mode, agent);
        if (error) return c.json({ error: 'invalid_agent', message: error }, 400);
        if (preference.accessMode === 'vault') {
          const credential = credentials[preference.credentialSlug];
          if (!credential) {
            return c.json({
              error: 'credential_not_found',
              message: `credential not found: ${preference.credentialSlug}`,
            }, 400);
          }
          const adapter = svc.adapters.get(agent)!;
          if (!compatibleCredentials(credentials, adapter).some(([slug]) => slug === preference.credentialSlug)) {
            return c.json({
              error: 'credential_incompatible',
              message: `credential ${preference.credentialSlug} is not compatible with ${agent}`,
            }, 400);
          }
        }
      }
    }
    try {
      const settings = await replaceWorkspaceRuntimeDefaults({
        wsDir: meta.dir,
        runtime: parsed.data,
      });
      launcherLogger.info('workspace.runtime_defaults_saved', { id });
      return c.json({ settings, workspace: await svc.publicMeta(meta) });
    } catch (err) {
      launcherLogger.warn('workspace.runtime_defaults_write_failed', { id, err });
      return c.json({ error: 'write_failed', message: (err as Error).message }, 500);
    }
  });

  // ── single workspace (offboarding + git/files sub-resources) ─────────────

  app.get('/:id/offboarding', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const assessment = await svc.lifecycle.assess(id);
    return assessment ? c.json({ assessment }) : c.json({ error: 'not_found' }, 404);
  });

  app.post('/:id/offboard', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    const successors = fields['successors'] && typeof fields['successors'] === 'object' && !Array.isArray(fields['successors'])
      ? Object.fromEntries(Object.entries(fields['successors'] as Record<string, unknown>)
          .filter((entry): entry is [string, string] => typeof entry[1] === 'string'))
      : undefined;
    try {
      await svc.harnessSurfaces.stopWorkspace(id);
      const result = await svc.lifecycle.offboard({
        id,
        ...(typeof fields['reason'] === 'string' ? { reason: fields['reason'] } : {}),
        ...(typeof fields['notes'] === 'string' ? { notes: fields['notes'] } : {}),
        ...(successors ? { successors } : {}),
      });
      if (result.ok) return c.json(result);
      const status = result.code === 'not_found' ? 404 : 409;
      return c.json({ error: result.code, message: result.message, assessment: result.assessment }, status);
    } catch (err) {
      launcherLogger.error('workspace.offboard_failed', { id, err });
      return c.json({ error: 'offboard_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/template-upgrade', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    try {
      return c.json({ plan: await svc.templateUpgrades.plan(id) });
    } catch (err) {
      if (err instanceof TemplateUpgradeError) {
        const status = err.code === 'not_found' ? 404
          : err.code === 'unsupported' || err.code === 'busy' ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.template_upgrade_plan_failed', { id, err });
      return c.json({ error: 'upgrade_plan_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/:id/template-upgrade', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    if (typeof fields['planDigest'] !== 'string') {
      return c.json({ error: 'bad_request', message: 'planDigest is required' }, 400);
    }
    const rawResolutions = fields['resolutions'];
    const resolutions = rawResolutions && typeof rawResolutions === 'object' && !Array.isArray(rawResolutions)
      ? Object.fromEntries(Object.entries(rawResolutions as Record<string, unknown>)
          .filter((entry): entry is [string, 'workspace' | 'template'] =>
            entry[1] === 'workspace' || entry[1] === 'template'))
      : undefined;
    try {
      const result = await svc.templateUpgrades.apply(id, {
        planDigest: fields['planDigest'],
        ...(resolutions ? { resolutions } : {}),
      });
      return c.json({ result, workspace: await svc.publicMeta(svc.registry.get(id)!) });
    } catch (err) {
      if (err instanceof TemplateUpgradeError) {
        const status = err.code === 'not_found' ? 404
          : err.code === 'busy' || err.code === 'staged_changes' || err.code === 'stale_plan'
            ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.template_upgrade_apply_failed', { id, err });
      return c.json({ error: 'upgrade_apply_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/source-upgrade', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    try {
      const preferences = await readHarnessPreference();
      const targetVersion = c.req.query('targetVersion');
      return c.json({
        plan: await svc.sourceUpgrades.plan(
          id,
          preferences.showUnverifiedHarnessReleases,
          targetVersion || undefined,
        ),
      });
    } catch (err) {
      if (err instanceof HarnessSourceUpgradeError) {
        const status = err.code === 'not_found' ? 404
          : err.code === 'busy' || err.code === 'working_tree_changes' ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.source_upgrade_plan_failed', { id, err });
      return c.json({ error: 'upgrade_plan_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/:id/source-upgrade', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    if (typeof fields['planDigest'] !== 'string' || typeof fields['targetVersion'] !== 'string') {
      return c.json({ error: 'bad_request', message: 'planDigest and targetVersion are required' }, 400);
    }
    try {
      const preferences = await readHarnessPreference();
      const result = await svc.sourceUpgrades.apply(
        id,
        preferences.showUnverifiedHarnessReleases,
        { planDigest: fields['planDigest'], targetVersion: fields['targetVersion'] },
      );
      return c.json({ result, workspace: await svc.publicMeta(svc.registry.get(id)!) });
    } catch (err) {
      if (err instanceof HarnessSourceUpgradeError) {
        const status = err.code === 'not_found' ? 404
          : ['busy', 'working_tree_changes', 'stale_plan'].includes(err.code) ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.source_upgrade_apply_failed', { id, err });
      return c.json({ error: 'upgrade_apply_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/absorb/:sourceId', async (c) => {
    const targetWorkspaceId = c.req.param('id');
    const sourceWorkspaceId = c.req.param('sourceId');
    if (!validId(targetWorkspaceId) || !validId(sourceWorkspaceId)) {
      return c.json({ error: 'not_found' }, 404);
    }
    try {
      return c.json({ plan: await svc.workspaceAbsorbs.plan(targetWorkspaceId, sourceWorkspaceId) });
    } catch (err) {
      if (err instanceof WorkspaceAbsorbError) {
        const status = err.code === 'not_found' ? 404
          : err.code === 'busy' || err.code === 'staged_changes' ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.absorb_plan_failed', { targetWorkspaceId, sourceWorkspaceId, err });
      return c.json({ error: 'absorb_plan_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/:id/absorb/:sourceId', async (c) => {
    const targetWorkspaceId = c.req.param('id');
    const sourceWorkspaceId = c.req.param('sourceId');
    if (!validId(targetWorkspaceId) || !validId(sourceWorkspaceId)) {
      return c.json({ error: 'not_found' }, 404);
    }
    const body = await safeJson(c);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    if (typeof fields['planDigest'] !== 'string') {
      return c.json({ error: 'bad_request', message: 'planDigest is required' }, 400);
    }
    const rawResolutions = fields['resolutions'];
    const resolutions = rawResolutions && typeof rawResolutions === 'object' && !Array.isArray(rawResolutions)
      ? Object.fromEntries(Object.entries(rawResolutions as Record<string, unknown>)
          .filter((entry): entry is [string, 'target' | 'source' | 'both'] =>
            entry[1] === 'target' || entry[1] === 'source' || entry[1] === 'both'))
      : undefined;
    try {
      const result = await svc.workspaceAbsorbs.apply({
        targetWorkspaceId,
        sourceWorkspaceId,
        planDigest: fields['planDigest'],
        ...(resolutions ? { resolutions } : {}),
      });
      const target = svc.registry.get(targetWorkspaceId);
      return c.json({
        result,
        ...(target ? { workspace: await svc.publicMeta(target) } : {}),
      });
    } catch (err) {
      if (err instanceof WorkspaceAbsorbError) {
        const status = err.code === 'not_found' ? 404
          : err.code === 'busy' || err.code === 'staged_changes' || err.code === 'stale_plan' || err.code === 'offboard_failed'
            ? 409
            : 400;
        return c.json({ error: err.code, message: err.message, plan: err.plan }, status);
      }
      launcherLogger.error('workspace.absorb_apply_failed', { targetWorkspaceId, sourceWorkspaceId, err });
      return c.json({ error: 'absorb_apply_failed', message: (err as Error).message }, 500);
    }
  });

  /** Backwards-compatible surface: Delete now means offboard, never orphan. */
  app.delete('/:id', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const result = await svc.lifecycle.offboard({ id });
    if (result.ok) return c.json(result);
    const status = result.code === 'not_found' ? 404 : 409;
    return c.json({ error: result.code, message: result.message, assessment: result.assessment }, status);
  });

  app.get('/:id/git/log', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    const limitRaw = Number.parseInt(c.req.query('limit') ?? '30', 10);
    const limit = Number.isFinite(limitRaw) ? limitRaw : 30;
    try {
      const entries = await gitLog(meta.dir, limit);
      return c.json({ entries });
    } catch (err) {
      launcherLogger.warn('git.log_failed', { id, err });
      return c.json({ error: 'git_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/git/status', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    try {
      const status = await gitStatus(meta.dir);
      return c.json(status);
    } catch (err) {
      launcherLogger.warn('git.status_failed', { id, err });
      return c.json({ error: 'git_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/files', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    const p = c.req.query('path') ?? '';
    try {
      const listing = await listDir(meta.dir, p);
      return c.json(listing);
    } catch (err) {
      if (err instanceof PathTraversal) {
        return c.json({ error: 'invalid_path', message: err.message }, 400);
      }
      launcherLogger.warn('files.list_failed', { id, path: p, err });
      return c.json({ error: 'list_failed', message: (err as Error).message }, 500);
    }
  });

  /**
   * Read a single UTF-8 text file from inside a workspace. Used by the
   * Inbox detail pane to render `docs` pointers live (no snapshot — the
   * workspace folder is the source of truth, see InboxStore doc).
   *
   * 404 when the workspace or the file is missing — callers (Inbox UI)
   * use this to render tombstone states. Larger than 1 MiB returns 413
   * so the inbox can't be weaponised into a large-file viewer.
   */
  app.get('/signatures/:resumeId', (c) => {
    const resumeId = c.req.param('resumeId');
    if (!validId(resumeId)) return c.json({ error: 'not_found' }, 404);
    const identity = svc.resumeRegistry.get(resumeId);
    if (!identity) return c.json({ error: 'not_found' }, 404);
    return c.json({
      signature: `@${identity.resumeId}`,
      resumeId: identity.resumeId,
      workspaceId: identity.wsId,
      agent: identity.agent,
      ...(identity.lifecycle === 'retired' ? {
        lifecycle: 'retired',
        ...(identity.successorResumeId ? { successorResumeId: identity.successorResumeId } : {}),
      } : {}),
      resumable: identity.lifecycle !== 'retired' && Boolean(identity.agentSessionId),
    });
  });

  app.get('/:id/file', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    const p = c.req.query('path') ?? '';
    if (!p) return c.json({ error: 'path required' }, 400);
    try {
      const content = await readWorkspaceFile(meta.dir, p);
      if (content === null) return c.json({ error: 'file_not_found' }, 404);
      if (content.length > 1024 * 1024) {
        return c.json({ error: 'file_too_large', sizeBytes: content.length }, 413);
      }
      return c.json({ path: p, content });
    } catch (err) {
      if (err instanceof PathTraversal) {
        return c.json({ error: 'invalid_path', message: err.message }, 400);
      }
      launcherLogger.warn('files.read_failed', { id, path: p, err });
      return c.json({ error: 'read_failed', message: (err as Error).message }, 500);
    }
  });

  // ── sessions ─────────────────────────────────────────────────────────────

  // Safe product Session directory for attribution/ownership pickers. Native
  // runtime ids and launcher record ids stay inside WorkspaceService.
  app.get('/:id/resumes', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const directory = await svc.sessionDirectory(id, 100);
    if (!directory) return c.json({ error: 'workspace_not_found' }, 404);
    return c.json(directory);
  });

  app.patch('/:id/resumes/:resumeId', async (c) => {
    const id = c.req.param('id');
    const resumeId = c.req.param('resumeId');
    if (!validId(id) || !validId(resumeId)) return c.json({ error: 'not_found' }, 404);
    if (!svc.registry.get(id)) return c.json({ error: 'workspace_not_found' }, 404);
    const body = await safeJson(c).catch(() => null);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    const presence = parseSessionPresence(fields['presence']);
    if (!presence) {
      return c.json({ error: 'invalid_presence', message: 'presence must be active, archived, or deleted' }, 400);
    }
    try {
      const identity = await svc.setSessionPresence({ wsId: id, resumeId, presence });
      return c.json({
        resumeId: identity.resumeId,
        presence: sessionPresence(identity),
        lifecycle: identity.lifecycle,
      });
    } catch (err) {
      if (err instanceof ResumePresenceError) {
        const error = err.code === 'not_found' ? 'resume_not_found'
          : err.code === 'retired' ? 'resume_retired'
            : err.code === 'wrong_workspace' ? 'resume_wrong_workspace'
              : 'invalid_presence_transition';
        return c.json({ error, message: err.message }, err.code === 'not_found' ? 404 : 409);
      }
      if (err instanceof HeadlessResumeError) {
        return c.json(
          { error: `resume_${err.code}`, message: err.message },
          err.code === 'not_found' ? 404 : 409,
        );
      }
      throw err;
    }
  });

  app.patch('/:id/resumes/:resumeId/metadata', async (c) => {
    const id = c.req.param('id');
    const resumeId = c.req.param('resumeId');
    if (!validId(id) || !validId(resumeId)) return c.json({ error: 'not_found' }, 404);
    if (!svc.registry.get(id)) return c.json({ error: 'workspace_not_found' }, 404);
    const body = await safeJson(c).catch(() => null);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    if (!Object.prototype.hasOwnProperty.call(fields, 'displayName')) {
      return c.json({ error: 'invalid_display_name', message: 'displayName must be a string or null' }, 400);
    }
    const raw = fields['displayName'];
    if (raw !== null && typeof raw !== 'string') {
      return c.json({ error: 'invalid_display_name', message: 'displayName must be a string or null' }, 400);
    }
    try {
      const identity = await svc.setSessionDisplayName({ wsId: id, resumeId, displayName: raw });
      return c.json({
        resumeId: identity.resumeId,
        ...(identity.displayName ? { displayName: identity.displayName } : {}),
      });
    } catch (err) {
      if (err instanceof SessionDisplayNameError) {
        return c.json({ error: 'invalid_display_name', message: err.message }, 400);
      }
      if (err instanceof ResumePresenceError) {
        const error = err.code === 'not_found' ? 'resume_not_found'
          : err.code === 'retired' ? 'resume_retired'
            : err.code === 'wrong_workspace' ? 'resume_wrong_workspace'
              : 'invalid_display_name';
        return c.json({ error, message: err.message }, err.code === 'not_found' ? 404 : 409);
      }
      throw err;
    }
  });

  // Replace credential/model/effort on a product Session. Agent runtime stays
  // frozen. The Issue page and other resumeId surfaces use this because the
  // Session directory never exposes launcher record ids.
  app.put('/:id/resumes/:resumeId/runtime', async (c) => {
    const id = c.req.param('id');
    const resumeId = c.req.param('resumeId');
    if (!validId(id) || !validId(resumeId)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    const identity = svc.resumeRegistry.get(resumeId);
    if (!identity || identity.wsId !== id) {
      return c.json({ error: 'resume_not_found', message: 'Assigned Session does not exist' }, 404);
    }
    if (identity.lifecycle === 'retired') {
      return c.json({ error: 'resume_retired', message: 'this Session retired with its Workspace' }, 409);
    }
    if (sessionPresence(identity) === 'deleted') {
      return c.json({
        error: 'resume_deleted',
        message: 'This Session is no longer available',
      }, 409);
    }
    const interactive = svc.sessionRegistry.findByResumeId(id, resumeId);
    if (
      interactive
      && (
        interactive.state === 'running'
        || svc.pool.get(interactive.id)
        || svc.webPi?.has(interactive.id)
      )
    ) {
      return c.json({
        error: 'session_busy',
        message: 'Wait for the current turn to finish before changing credential, model, or effort',
      }, 409);
    }
    const latest = svc.headlessTasks?.latestForResumeId(resumeId);
    if (latest?.status === 'running') {
      return c.json({
        error: 'session_busy',
        message: 'Wait for the current turn to finish before changing credential, model, or effort',
      }, 409);
    }
    const adapter = svc.adapters.get(identity.agent);
    if (!adapter || !isAgentRuntime(adapter)) {
      return c.json({
        error: 'runtime_selection_unsupported',
        message: `Session runtime "${identity.agent}" does not support managed AI configuration`,
      }, 400);
    }
    const parsed = pausedSessionRuntimeRequestSchema.safeParse(
      await safeJson(c).catch(() => null),
    );
    if (!parsed.success) {
      return c.json({
        error: 'bad_request',
        message: parsed.error.issues[0]?.message ?? 'invalid Session AI configuration',
      }, 400);
    }
    try {
      const resolved = await createSessionRuntimeBinding({
        adapter,
        cwd: meta.dir,
        selection: {
          ...(parsed.data.credentialSource === 'native'
            ? { credentialSource: 'native' as const }
            : { credentialSlug: parsed.data.credentialSlug! }),
          ...(parsed.data.model ? { model: parsed.data.model } : {}),
          ...(parsed.data.reasoningEffort
            ? { reasoningEffort: parsed.data.reasoningEffort }
            : {}),
        },
      });
      await svc.resumeRegistry.replaceRuntimeBinding({
        resumeId: identity.resumeId,
        wsId: identity.wsId,
        agent: identity.agent,
        runtimeBinding: resolved.binding,
      });
      return c.json({
        resumeId: identity.resumeId,
        agent: identity.agent,
        runtime: projectPublicSessionRuntime(resolved.binding),
      });
    } catch (err) {
      if (err instanceof SessionRuntimeBindingError) {
        return c.json({ error: err.code, message: err.message }, 400);
      }
      launcherLogger.warn('resume_runtime.replace_failed', {
        id, resumeId, agent: identity.agent, err,
      });
      return c.json({
        error: 'session_runtime_update_failed',
        message: (err as Error).message,
      }, 500);
    }
  });

  // Materialize one product-owned conversation as a stable interactive
  // Session. The frontend supplies only resumeId; native CLI ids stay in the
  // backend ResumeRegistry.
  app.post('/:id/resumes/:resumeId/session', async (c) => {
    const id = c.req.param('id');
    const resumeId = c.req.param('resumeId');
    if (!validId(id) || !validId(resumeId)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    const body = await safeJson(c).catch(() => null);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    const title = typeof fields['title'] === 'string' ? fields['title'] : undefined;
    const key = `${id}::${resumeId}`;
    let run = headlessSessionInFlight.get(key);
    if (!run) {
      run = openResumeAsSession(meta, resumeId, title);
      headlessSessionInFlight.set(key, run);
    }
    try {
      const result = await run;
      if (!result.ok) return c.json(result.body, result.status);
      return c.json({ session: result.session, created: result.created }, result.created ? 201 : 200);
    } finally {
      if (headlessSessionInFlight.get(key) === run) headlessSessionInFlight.delete(key);
    }
  });

  // Compatibility route for bookmarked task links. It resolves taskId to the
  // product resumeId server-side and never accepts a native session id.
  app.post('/:id/headless/:taskId/session', async (c) => {
    const id = c.req.param('id');
    const taskId = c.req.param('taskId');
    if (!validId(id) || !validId(taskId)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);

    const task = svc.headlessTasks.get(taskId);
    if (!task || task.wsId !== id) return c.json({ error: 'run_not_found' }, 404);
    const body = await safeJson(c).catch(() => null);
    const fields = body && typeof body === 'object' ? body as Record<string, unknown> : {};
    const title = typeof fields['title'] === 'string' ? fields['title'] : undefined;

    const key = `${id}::${taskId}`;
    let run = headlessSessionInFlight.get(key);
    if (!run) {
      run = openResumeAsSession(meta, task.resumeId, title);
      headlessSessionInFlight.set(key, run);
    }
    try {
      const result = await run;
      if (!result.ok) return c.json(result.body, result.status);
      return c.json(
        { session: result.session, created: result.created },
        result.created ? 201 : 200,
      );
    } finally {
      if (headlessSessionInFlight.get(key) === run) headlessSessionInFlight.delete(key);
    }
  });

  app.post('/:id/sessions/spawn', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);

    let resumeId: string | undefined;
    let agentId: string | undefined;
    let initialPrompt: string | undefined;
    let credentialSource: 'native' | undefined;
    let credentialSlug: string | undefined;
    let model: string | undefined;
    let reasoningEffort: ModelReasoningEffort | undefined;
    try {
      const body = await safeJson(c);
      const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
      const rawResumeId = fields['resumeId'];
      if (typeof rawResumeId === 'string' && validId(rawResumeId)) resumeId = rawResumeId;
      const rawAgent = fields['agent'];
      if (typeof rawAgent === 'string' && rawAgent.length > 0) agentId = rawAgent;
      const rawSlug = fields['credentialSlug'];
      if (typeof rawSlug === 'string' && rawSlug.length > 0) credentialSlug = rawSlug;
      if (fields['credentialSource'] === 'native') credentialSource = 'native';
      const rawModel = fields['model'];
      if (typeof rawModel === 'string' && rawModel.trim().length > 0) model = rawModel.trim();
      const rawEffort = fields['reasoningEffort'];
      if (isModelReasoningEffort(rawEffort)) reasoningEffort = rawEffort;
      // Quick-chat seed (fresh-only): a first message the TUI opens already
      // working on. Ignored when resuming — seeding + resume is ambiguous on
      // codex's `resume <id>` / pi's `--session-id`.
      const seed = parseSeedPrompt(fields['initialPrompt']);
      if (seed && 'error' in seed) return c.json(seed, 400);
      if (seed && resumeId === undefined) initialPrompt = seed.prompt;
    } catch (err) {
      return c.json({ error: 'bad_request', message: (err as Error).message }, 400);
    }
    const result = await spawnInteractiveSession(meta, {
      ...(agentId !== undefined ? { agentId } : {}),
      ...(resumeId !== undefined ? { resumeId } : {}),
      ...(initialPrompt !== undefined ? { initialPrompt } : {}),
      ...(credentialSource !== undefined ? { credentialSource } : {}),
      ...(credentialSlug !== undefined ? { credentialSlug } : {}),
      ...(model !== undefined ? { model } : {}),
      ...(reasoningEffort !== undefined ? { reasoningEffort } : {}),
      // Resume reuses an existing product Session; only fresh spawns stamp birth.
      ...(resumeId === undefined
        ? { createdBy: { kind: 'interactive' as const, surface: 'spawn' as const } }
        : {}),
    });
    if (!result.ok) return c.json(result.body, result.status as 400 | 500);
    return c.json(result.session, 201);
  });

  // Conversational harness launch — the "type a message → you're in" front
  // door shared by Ask Alice and AutoQuant. The harness chooses only the
  // Workspace template; the native Coding Agent remains the worker.
  // Body: { prompt, agent?, targetWsId?, template? }
  app.post('/quick-chat', async (c) => {
    let prompt: string;
    let agentId: string | undefined;
    let credentialSource: 'native' | undefined;
    let credentialSlug: string | undefined;
    let model: string | undefined;
    let reasoningEffort: ModelReasoningEffort | undefined;
    let targetWsId: string | undefined;
    let templateName = 'chat';
    try {
      const body = await safeJson(c);
      const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
      const seed = parseSeedPrompt(fields['prompt']);
      if (seed === null) return c.json({ error: 'prompt_required' }, 400);
      if ('error' in seed) return c.json(seed, 400);
      prompt = seed.prompt;
      const rawAgent = fields['agent'];
      if (typeof rawAgent === 'string' && rawAgent.length > 0) agentId = rawAgent;
      // Optional Session-only vault override. Every Agent adapter owns how it
      // projects the selected credential. Omission keeps normal Workspace /
      // runtime resolution; credentialSource=native explicitly bypasses it.
      const rawSlug = fields['credentialSlug'];
      if (typeof rawSlug === 'string' && rawSlug.length > 0) credentialSlug = rawSlug;
      if (fields['credentialSource'] === 'native') credentialSource = 'native';
      const rawModel = fields['model'];
      if (typeof rawModel === 'string' && rawModel.trim().length > 0) model = rawModel.trim();
      const rawEffort = fields['reasoningEffort'];
      if (isModelReasoningEffort(rawEffort)) reasoningEffort = rawEffort;
      // Optional: spawn into THIS existing workspace instead of today's. The
      // chat sidebar's per-workspace "+" ("Ask Alice, but in this workspace").
      const rawTarget = fields['targetWsId'];
      if (typeof rawTarget === 'string' && rawTarget.length > 0) targetWsId = rawTarget;
      const rawTemplate = fields['template'];
      if (rawTemplate !== undefined) {
        if (rawTemplate !== 'chat' && rawTemplate !== 'auto-quant-v2' && rawTemplate !== 'auto-prediction') {
          return c.json({ error: 'unknown_template' }, 400);
        }
        templateName = rawTemplate;
      }
    } catch (err) {
      return c.json({ error: 'bad_request', message: (err as Error).message }, 400);
    }

    // Each send is a new Session in a durable Chat Workspace. The explicit
    // target wins; otherwise the resolver uses recentChatWorkspaceId, falls back
    // to the most recently active Chat workspace, and creates only when none
    // exists. The gate prevents concurrent first launches from double-bootstrap.
    let meta: WorkspaceMeta;
    if (targetWsId) {
      // Targeted: spawn a new session into the given existing workspace.
      const found = svc.registry.list().find((w) => w.id === targetWsId);
      if (!found) return c.json({ error: 'workspace_not_found' }, 404);
      if (templateName !== 'chat' && found.template !== templateName) {
        return c.json({ error: 'workspace_template_mismatch' }, 400);
      }
      if (templateName === 'auto-quant-v2') {
        const defaultWorkspace = await resolveAutoQuantDefaultWorkspace().catch((err) => {
          launcherLogger.warn('auto_quant.preference_read_failed', { err });
          return undefined;
        });
        if (!defaultWorkspace) {
          return c.json({ error: 'auto_quant_not_initialized' }, 409);
        }
        if (defaultWorkspace.id !== found.id) {
          return c.json({ error: 'auto_quant_workspace_not_default' }, 400);
        }
      }
      if (templateName === 'auto-prediction') {
        const defaultWorkspace = await resolveAutoPredictionDefaultWorkspace().catch((err) => {
          launcherLogger.warn('auto_prediction.preference_read_failed', { err });
          return undefined;
        });
        if (!defaultWorkspace) return c.json({ error: 'auto_prediction_not_initialized' }, 409);
        if (defaultWorkspace.id !== found.id) {
          return c.json({ error: 'auto_prediction_workspace_not_default' }, 400);
        }
      }
      meta = found;
      if (templateName === 'chat') await rememberRecentChat(meta);
    } else {
      const target = templateName === 'auto-quant-v2'
        ? await (async () => {
            const workspace = await resolveAutoQuantDefaultWorkspace().catch((err) => {
              launcherLogger.warn('auto_quant.preference_read_failed', { err });
              return undefined;
            });
            return workspace
              ? { ok: true as const, workspace }
              : {
                  ok: false as const,
                  code: 'auto_quant_not_initialized' as const,
                  message: 'AutoQuant needs a default Workspace before research can start',
                };
          })()
        : templateName === 'auto-prediction'
          ? await (async () => {
              const workspace = await resolveAutoPredictionDefaultWorkspace().catch((err) => {
                launcherLogger.warn('auto_prediction.preference_read_failed', { err });
                return undefined;
              });
              return workspace
                ? { ok: true as const, workspace }
                : {
                    ok: false as const,
                    code: 'auto_prediction_not_initialized' as const,
                    message: 'Auto Prediction needs a default Workspace before research can start',
                  };
            })()
          : await (async () => {
            const preference = await quickChatPreferences.readQuickChatPreferences().catch((err) => {
              launcherLogger.warn('quick_chat.preference_read_failed', { err });
              return null;
            });
            return svc.resolveOrCreateChatWorkspace(preference?.recentChatWorkspaceId);
          })();
      if (!target.ok) {
        const status =
          target.code === 'tag_in_use' ? 409
          : target.code === 'unknown_template' ? 400
          : target.code === 'unknown_source_version' ? 400
          : target.code === 'invalid_tag' ? 400
          : target.code === 'auto_quant_not_initialized' ? 409
          : target.code === 'auto_prediction_not_initialized' ? 409
          : 500;
        launcherLogger.error('quick_chat.create_failed', {
          code: target.code,
          message: target.message,
        });
        return c.json(
          { error: target.code, message: target.message },
          status as 400 | 409 | 500,
        );
      }
      meta = target.workspace;
      if (templateName === 'chat') await rememberRecentChat(meta);
    }

    const spawn = await spawnInteractiveSession(meta, {
      ...(agentId !== undefined ? { agentId } : {}),
      ...(credentialSource !== undefined ? { credentialSource } : {}),
      ...(credentialSlug !== undefined ? { credentialSlug } : {}),
      ...(model !== undefined ? { model } : {}),
      ...(reasoningEffort !== undefined ? { reasoningEffort } : {}),
      initialPrompt: prompt,
      createdBy: {
        kind: 'interactive',
        surface: templateName === 'auto-quant-v2'
          ? 'auto-quant'
          : templateName === 'auto-prediction' ? 'prediction' : 'quick-chat',
      },
    });
    if (!spawn.ok) return c.json(spawn.body, spawn.status as 400 | 500);
    return c.json({ workspace: await svc.publicMeta(meta), session: spawn.session }, 201);
  });

  // pause / stop (alias)
  for (const action of ['pause', 'stop'] as const) {
    app.post(`/:id/sessions/:sid/${action}`, async (c) => {
      const id = c.req.param('id');
      const token = c.req.param('sid');
      if (!validId(id) || !validId(token)) {
        return c.json({ error: 'not_found' }, 404);
      }
      const record = svc.sessionRegistry.get(id, token);
      const live = svc.pool.get(token);
      if (!record && !live) return c.json({ error: 'not_found' }, 404);

      let scrollbackRel: string | null = null;
      if (record?.agent === 'shell' && live) {
        try {
          const dump = live.dumpReplayBuffer();
          if (dump.length > 0) {
            scrollbackRel = await svc.scrollbackStore.dump(id, token, dump);
          }
        } catch (err) {
          launcherLogger.warn('scrollback.dump_failed', { id, token, err });
        }
      }
      const wasTerminalRunning = svc.pool.disposeToken(token, action === 'pause' ? 'paused' : 'tab stop');
      const wasWebPiRunning = await svc.webPi?.stop(token, action === 'pause' ? 'paused' : 'tab stop') ?? false;
      const wasRunning = wasTerminalRunning || wasWebPiRunning;
      if (record) {
        const patch: Partial<SessionRecord> = {
          state: 'paused',
          lastActiveAt: new Date().toISOString(),
        };
        if (scrollbackRel) patch.scrollbackFile = scrollbackRel;
        await svc.sessionRegistry
          .update(id, token, patch)
          .catch((err) =>
            launcherLogger.warn('session_registry.pause_update_failed', { id, token, err }),
          );
      }
      launcherLogger.info('workspace.session_paused', {
        id,
        sessionId: token,
        wasRunning,
        via: action,
        scrollback: scrollbackRel ?? null,
      });
      if (wasRunning && record) {
        await svc.recordAgentRuntime?.('runtime.stopped', {
          workspaceId: record.wsId,
          resumeId: record.resumeId,
          agent: record.agent,
          sessionRecordId: record.id,
          surface: wasWebPiRunning && !wasTerminalRunning ? 'webpi' : 'terminal',
          status: 'paused',
        })
      }
      return c.json({ ok: true, wasRunning });
    });
  }

  app.put('/:id/sessions/:sid/runtime', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    const record = svc.sessionRegistry.get(id, token);
    if (!record) return c.json({ error: 'not_found' }, 404);
    if (
      record.state !== 'paused'
      || svc.pool.get(token)
      || svc.webPi?.has(token)
    ) {
      return c.json({
        error: 'session_not_paused',
        message: 'Pause this Session before changing its credential, model, or effort',
      }, 409);
    }
    const identity = svc.resumeRegistry.get(record.resumeId);
    if (!identity) {
      return c.json({
        error: 'session_identity_missing',
        message: 'This Session has no durable resume identity',
      }, 409);
    }
    if (identity.lifecycle === 'retired') {
      return c.json({ error: 'resume_retired', message: 'this Session retired with its Workspace' }, 409);
    }
    const adapter = svc.adapters.get(record.agent);
    if (!adapter || !isAgentRuntime(adapter)) {
      return c.json({
        error: 'runtime_selection_unsupported',
        message: `Session runtime "${record.agent}" does not support managed AI configuration`,
      }, 400);
    }
    const parsed = pausedSessionRuntimeRequestSchema.safeParse(
      await safeJson(c).catch(() => null),
    );
    if (!parsed.success) {
      return c.json({
        error: 'bad_request',
        message: parsed.error.issues[0]?.message ?? 'invalid Session AI configuration',
      }, 400);
    }
    try {
      const resolved = await createSessionRuntimeBinding({
        adapter,
        cwd: meta.dir,
        selection: {
          ...(parsed.data.credentialSource === 'native'
            ? { credentialSource: 'native' as const }
            : { credentialSlug: parsed.data.credentialSlug! }),
          ...(parsed.data.model ? { model: parsed.data.model } : {}),
          ...(parsed.data.reasoningEffort
            ? { reasoningEffort: parsed.data.reasoningEffort }
            : {}),
        },
      });
      await svc.resumeRegistry.replaceRuntimeBinding({
        resumeId: record.resumeId,
        wsId: record.wsId,
        agent: record.agent,
        runtimeBinding: resolved.binding,
      });
      const identity = svc.resumeRegistry.get(record.resumeId);
      return c.json({
        session: projectPublicSession(record, {
          runtimeBinding: resolved.binding,
          ...(identity?.displayName ? { displayName: identity.displayName } : {}),
          ...(identity ? { presence: sessionPresence(identity) } : {}),
        }),
      });
    } catch (err) {
      if (err instanceof SessionRuntimeBindingError) {
        return c.json({ error: err.code, message: err.message }, 400);
      }
      launcherLogger.warn('session_runtime.replace_failed', {
        id, sessionId: token, agent: record.agent, err,
      });
      return c.json({
        error: 'session_runtime_update_failed',
        message: (err as Error).message,
      }, 500);
    }
  });

  app.post('/:id/sessions/:sid/resume', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) {
      return c.json({ error: 'not_found' }, 404);
    }
    // Serialize concurrent resumes of this record (ANG-120 — see resumeInFlight).
    // A later double-fire awaits the in-flight resume, then doResume()'s in-lock
    // pool.get() re-check short-circuits it to alreadyRunning instead of spawning
    // a second agent on the same transcript.
    const lockKey = `${id}::${token}`;
    const inFlight = resumeInFlight.get(lockKey);
    if (inFlight) await inFlight.catch(() => undefined);
    const run = doResume();
    resumeInFlight.set(lockKey, run);
    try {
      return await run;
    } finally {
      if (resumeInFlight.get(lockKey) === run) resumeInFlight.delete(lockKey);
    }

    async function doResume() {
      const record = svc.sessionRegistry.get(id, token);
      if (!record) return c.json({ error: 'not_found' }, 404);
      const identity = svc.resumeRegistry.get(record.resumeId);
      if (identity?.lifecycle === 'retired') {
        return c.json({ error: 'resume_retired', message: 'this Session retired with its Workspace' }, 409);
      }
      if (svc.isResumeActive?.(record.resumeId)) {
        return c.json({ error: 'resume_busy', message: 'this conversation already has a running headless turn' }, 409);
      }
      // Re-check INSIDE the lock: a concurrent resume that just settled may have
      // already spawned this session.
      if (svc.pool.get(token)) {
        return c.json({ ok: true, alreadyRunning: true });
      }
      // Choosing the terminal surface is an explicit handoff. Never leave Pi's
      // RPC host and PTY alive against the same native session file.
      if (svc.webPi?.has(token)) await svc.webPi.stop(token, 'switch to terminal');
      const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
      if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
      const adapter = svc.adapters.get(record.agent);
      if (!adapter) {
        return c.json({
          error: 'unknown_agent',
          message: `record references unknown adapter: ${record.agent}`,
        }, 500);
      }
      let sessionRuntime: ResolvedSessionRuntimeBinding | undefined;
      if (isAgentRuntime(adapter)) {
        try {
          sessionRuntime = identity?.runtimeBinding
            ? await resolveSessionRuntimeBinding({
                adapter,
                cwd: meta.dir,
                binding: identity.runtimeBinding,
              })
            : createNativeSessionRuntimeBinding({ adapter });
          if (!identity?.runtimeBinding) {
            await svc.resumeRegistry.ensure({
              resumeId: record.resumeId,
              wsId: record.wsId,
              agent: record.agent,
              runtimeBinding: sessionRuntime.binding,
            });
          }
        } catch (err) {
          if (err instanceof SessionRuntimeBindingError) {
            return c.json({ error: err.code, message: err.message }, 400);
          }
          launcherLogger.warn('session_runtime.resolve_failed_on_resume', { id, agent: adapter.id, err });
          return c.json({ error: 'session_runtime_failed', message: (err as Error).message }, 500);
        }
      }
      const resume = mappedResumeForRecord(record, adapter);
      const plan = svc.computeSpawnPlan(meta, adapter, resume);
      // path.trace at the moment the resume decision is taken — captures what
      // we're ABOUT to do, before bootstrap or spawn. If a downstream step
      // diverges (e.g. claude CLI writes jsonl to a different projectKey),
      // we compare this against the transcript.watch.register trace.
      launcherLogger.event('path.trace', {
        where: 'resume.attempt',
        wsId: id,
        recordId: token,
        agent: adapter.id,
        wsDir: meta.dir,
        spawnCwd: plan.spawnCwd,
        envPWD: plan.envPWD,
        transcriptDir: plan.transcriptDir,
        projectKey: plan.projectKey,
        composedCommand: plan.composedCommand,
        resumeMode: plan.resumeMode,
        resumeId: record.resumeId,
        nativeSessionId: plan.nativeSessionId,
        resumeHintInRecord: record.resumeHint ?? null,
      });
      try {
        await prepareAgentRuntimeWorkspace(adapter, {
          wsId: id,
          cwd: meta.dir,
          launcherRepoRoot: svc.config.launcherRepoRoot,
        });
      } catch (err) {
        launcherLogger.error('adapter.prepare_workspace_failed_on_resume', { id, agent: adapter.id, err });
        return c.json({ error: 'bootstrap_failed', message: (err as Error).message }, 500);
      }
      let initialReplayBytes: Buffer | null = null;
      if (record.agent === 'shell' && record.scrollbackFile) {
        initialReplayBytes = await svc.scrollbackStore.read(record.scrollbackFile);
      }
      const claimedResume = svc.claimResume?.(record.resumeId) ?? true;
      if (!claimedResume) {
        return c.json({ error: 'resume_busy', message: 'this conversation already has a running turn' }, 409);
      }
      try {
        const ctx: SessionFactoryContext = {
          ...(resume !== undefined ? { resume } : {}),
          agentId: record.agent,
          recordId: record.id,
          recordName: record.name,
          ...(sessionRuntime ? { sessionRuntime } : {}),
          ...(initialReplayBytes ? { initialReplayBytes } : {}),
        };
        const session = svc.pool.spawn(id, ctx);
        // Give the child a brief window to prove it stays up. If it exits
        // within ~800ms (claude --continue against a stale projectKey, broken
        // .mcp.json, missing trust, etc.) we'd otherwise return 200 OK while
        // the pool respawn-loops itself into a circuit breaker behind the
        // user's back. Surface the failure so the caller knows resume failed.
        const earlyExit = await session.waitForFirstExit(800);
        if (earlyExit) {
          svc.pool.disposeToken(token, 'resume_early_exit');
          await svc.sessionRegistry
            .update(id, token, { state: 'paused', lastActiveAt: new Date().toISOString() })
            .catch(() => undefined);
          launcherLogger.warn('workspace.session_resume_early_exit', {
            id,
            sessionId: token,
            agent: adapter.id,
            code: earlyExit.code,
            signal: earlyExit.signal,
          });
          await svc.recordAgentRuntime?.('runtime.spawn_failed', {
            workspaceId: record.wsId,
            resumeId: record.resumeId,
            agent: adapter.id,
            sessionRecordId: record.id,
            surface: 'terminal',
            cause: { kind: 'ui' },
            error: `agent exited within startup window (code=${earlyExit.code})`,
          });
          return c.json({
            error: 'spawn_died',
            message: `agent exited within startup window (code=${earlyExit.code})`,
            exitCode: earlyExit.code,
            signal: earlyExit.signal,
          }, 500);
        }
        if (record.scrollbackFile) {
          await svc.scrollbackStore.remove(record.scrollbackFile);
          delete (record as { scrollbackFile?: string }).scrollbackFile;
        }
        await svc.sessionRegistry
          .update(id, token, { state: 'running', surface: 'terminal', lastActiveAt: new Date().toISOString() })
          .catch((err) =>
            launcherLogger.warn('session_registry.resume_update_failed', { id, token, err }),
          );
        launcherLogger.info('workspace.session_resumed', {
          id,
          sessionId: token,
          name: session.name,
          pid: session.pid,
          agent: adapter.id,
          resume: resume === undefined ? null : resume === 'last' ? 'last' : resume.sessionId,
          scrollbackBytes: initialReplayBytes?.length ?? 0,
        });
        await svc.recordAgentRuntime?.('runtime.started', {
          workspaceId: record.wsId,
          resumeId: record.resumeId,
          agent: adapter.id,
          sessionRecordId: record.id,
          surface: 'terminal',
          cause: { kind: 'ui' },
        });
        return c.json({
          ok: true,
          sessionId: session.recordId,
          resumeId: record.resumeId,
          wsId: session.wsId,
          name: session.name,
          pid: session.pid,
          agent: adapter.id,
          startedAt: session.startedAt,
          title: sessionPreferredTitle(record) ?? null,
        });
      } catch (err) {
        launcherLogger.error('workspace.session_resume_failed', { id, token, err });
        await svc.recordAgentRuntime?.('runtime.spawn_failed', {
          workspaceId: record.wsId,
          resumeId: record.resumeId,
          agent: record.agent,
          sessionRecordId: record.id,
          surface: 'terminal',
          cause: { kind: 'ui' },
          error: (err as Error).message,
        });
        return c.json({ error: 'resume_failed', message: (err as Error).message }, 500);
      } finally {
        if (claimedResume) svc.releaseResume?.(record.resumeId);
      }
    }
  });

  // WebPi is a presentation of an existing Pi Session, not another runtime.
  // The four routes below expose Pi's own RPC state/messages without adapting
  // them into OpenAlice message blocks.
  app.post('/:id/sessions/:sid/webpi/open', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) return c.json({ error: 'not_found' }, 404);
    // Older embedders/tests may provide only the business registry. Keep the
    // ordinary Workspace path compatible while the launcher-owned manager is
    // resolved through the newer service seam.
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    const record = svc.sessionRegistry.get(id, token);
    if (!meta || !record) return c.json({ error: 'not_found' }, 404);
    if (record.agent !== 'pi') {
      return c.json({ error: 'unsupported_surface', message: 'WebPi is available only for Pi Sessions' }, 409);
    }
    if (svc.isResumeActive(record.resumeId)) {
      return c.json({ error: 'resume_busy', message: 'this conversation has a running headless turn' }, 409);
    }
    const adapter = svc.adapters.get('pi');
    if (!adapter) return c.json({ error: 'unknown_agent' }, 500);
    try {
      await prepareAgentRuntimeWorkspace(adapter, {
        wsId: id,
        cwd: meta.dir,
        launcherRepoRoot: svc.config.launcherRepoRoot,
      });
      if (svc.pool.get(token)) svc.pool.disposeToken(token, 'switch to WebPi');
      const snapshot = await svc.startWebPiSession(
        meta,
        record,
        id === svc.managerWorkspace?.id ? managerWebPiOptions : undefined,
      );
      return c.json({ ok: true, snapshot, session: publicSession(record) });
    } catch (err) {
      await svc.sessionRegistry.update(id, token, {
        state: 'paused',
        surface: 'webpi',
        lastActiveAt: new Date().toISOString(),
      }).catch(() => undefined);
      if (err instanceof AgentCredentialError) return c.json(err.toBody(), 400);
      launcherLogger.error('webpi.open_failed', { id, token, err });
      return c.json({ error: 'webpi_open_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/sessions/:sid/webpi', (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) return c.json({ error: 'not_found' }, 404);
    const record = svc.sessionRegistry.get(id, token);
    if (!record) return c.json({ error: 'not_found' }, 404);
    const snapshot = svc.webPi.get(token);
    if (!snapshot) return c.json({ error: 'webpi_not_running' }, 409);
    const knownRevision = Number.parseInt(c.req.query('revision') ?? '', 10);
    if (Number.isSafeInteger(knownRevision) && knownRevision === snapshot.revision) {
      return c.json({ unchanged: true, revision: snapshot.revision });
    }
    return c.json({ snapshot });
  });

  app.post('/:id/sessions/:sid/webpi/prompt', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) return c.json({ error: 'not_found' }, 404);
    const record = svc.sessionRegistry.get(id, token);
    if (!record || record.agent !== 'pi') return c.json({ error: 'not_found' }, 404);
    const body = await safeJson(c).catch(() => null);
    const message = body && typeof body === 'object' ? (body as Record<string, unknown>)['message'] : null;
    if (typeof message !== 'string' || !message.trim()) {
      return c.json({ error: 'bad_request', message: 'message is required' }, 400);
    }
    try {
      const snapshot = await svc.webPi.prompt(token, message);
      await svc.sessionRegistry.update(id, token, { lastActiveAt: new Date().toISOString() });
      return c.json({ ok: true, snapshot });
    } catch (err) {
      return c.json({ error: 'webpi_prompt_failed', message: (err as Error).message }, 409);
    }
  });

  app.post('/:id/sessions/:sid/webpi/abort', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) return c.json({ error: 'not_found' }, 404);
    const record = svc.sessionRegistry.get(id, token);
    if (!record || record.agent !== 'pi') return c.json({ error: 'not_found' }, 404);
    try {
      return c.json({ ok: true, snapshot: await svc.webPi.abort(token) });
    } catch (err) {
      return c.json({ error: 'webpi_abort_failed', message: (err as Error).message }, 409);
    }
  });

  // Read-only introspection for a single session. Returns the full set of
  // path-related fields a spawn / resume would compute (via the same
  // `computeSpawnPlan` the pool uses), plus an on-disk snapshot of the
  // transcript dir the adapter is watching. Lets us curl against a stuck
  // workspace and immediately see whether the projectKey / cwd / PWD /
  // transcriptDir / watched dir contents are internally consistent —
  // without having to spawn or read 50k lines of backend stdout.
  app.get('/:id/sessions/:sid/diagnostics', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) {
      return c.json({ error: 'not_found' }, 404);
    }
    // The launcher-owned Manager is a runtime Workspace but deliberately does
    // not live in the business registry. Use the same resolver as spawn/resume
    // so its terminal diagnostics do not report workspace_not_found.
    const meta = svc.resolveRuntimeWorkspace(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    await svc.sessionRegistry.ensureLoaded(id).catch(() => undefined);
    const record = svc.sessionRegistry.get(id, token);
    if (!record) return c.json({ error: 'session_not_found' }, 404);
    const adapter = svc.adapters.get(record.agent);
    if (!adapter) {
      return c.json({
        error: 'unknown_agent',
        message: `record references unknown adapter: ${record.agent}`,
      }, 500);
    }

    const resume = mappedResumeForRecord(record, adapter);
    const plan = svc.computeSpawnPlan(meta, adapter, resume);

    let transcriptFiles: { name: string; size: number; mtime: string }[] = [];
    let transcriptExists = false;
    if (plan.transcriptDir) {
      try {
        const { readdir, stat } = await import('node:fs/promises');
        const names = await readdir(plan.transcriptDir);
        transcriptExists = true;
        const results = await Promise.all(
          names.map(async (name) => {
            try {
              const st = await stat(join(plan.transcriptDir as string, name));
              return { name, size: st.size, mtime: st.mtime.toISOString() };
            } catch {
              return null;
            }
          }),
        );
        transcriptFiles = results.filter((r): r is { name: string; size: number; mtime: string } => r !== null);
      } catch {
        transcriptExists = false;
      }
    }

    const liveSessions = svc.pool.liveSessionsFor(id);
    const live = liveSessions.find((s) => s.id === token) ?? null;

    return c.json({
      workspace: {
        id: meta.id,
        dir: meta.dir,
      },
      record: {
        id: record.id,
        state: record.state,
        agent: record.agent,
        resumeHint: record.resumeHint ?? null,
        lastActiveAt: record.lastActiveAt,
        createdAt: record.createdAt,
      },
      live: live === null ? null : {
        pid: live.pid,
        startedAt: live.startedAt,
        agentSessionId: live.agentSessionId,
      },
      adapter: {
        id: adapter.id,
        capabilities: adapter.capabilities,
      },
      transcript: {
        projectKey: plan.projectKey,
        dir: plan.transcriptDir,
        exists: transcriptExists,
        files: transcriptFiles,
      },
      wouldResume: {
        mode: plan.resumeMode,
        resumeId: record.resumeId,
        nativeSessionId: plan.nativeSessionId,
        composedCommand: plan.composedCommand,
        spawnCwd: plan.spawnCwd,
        envPWD: plan.envPWD,
      },
    });
  });

  // Headless probe: spawn the adapter's CLI against the workspace with a
  // positional prompt appended, run in a temporary PTY (no pool, no record
  // mutation), kill on timeout, return the PTY-output tail + a jsonl-delta
  // snapshot of the transcript dir. Lets an AI / curl caller verify the
  // full wiring (PWD, MCP, trust, resume) end-to-end without going through
  // the UI. Refuses when a live PTY exists for the same record — they'd
  // collide on the same transcript and the result would be misleading.
  app.post('/:id/sessions/:sid/probe', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) {
      return c.json({ error: 'not_found' }, 404);
    }
    let prompt: string;
    let timeoutMs: number;
    let resumeOverride: 'none' | 'last' | { sessionId: string } | undefined;
    try {
      const body = await safeJson(c);
      const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
      const rawPrompt = fields['prompt'];
      if (typeof rawPrompt !== 'string' || rawPrompt.length === 0) {
        return c.json({ error: 'prompt_required' }, 400);
      }
      if (rawPrompt.length > 8000) {
        return c.json({ error: 'prompt_too_long', message: 'max 8000 chars' }, 400);
      }
      prompt = rawPrompt;
      const rawTimeout = fields['timeoutMs'];
      timeoutMs = typeof rawTimeout === 'number' && rawTimeout > 0
        ? Math.min(rawTimeout, 120_000)
        : 20_000;
      // resume override: 'auto' (default — follow record's resumeHint),
      // 'fresh' (no resume flag), 'last' (force --continue), or an adapter-
      // native session id string (force --resume/--session <id>). Lets the
      // probe seed a brand-new session before any real interaction has produced
      // a transcript.
      const rawResume = fields['resume'];
      if (rawResume !== undefined && rawResume !== 'auto') {
        if (rawResume === 'fresh') resumeOverride = 'none';
        else if (rawResume === 'last') resumeOverride = 'last';
        else if (typeof rawResume === 'string' && AGENT_SESSION_ID_RE.test(rawResume)) {
          resumeOverride = { sessionId: rawResume };
        } else {
          return c.json({ error: 'bad_request', message: 'resume must be "auto", "fresh", "last", or an agent session id' }, 400);
        }
      }
    } catch (err) {
      return c.json({ error: 'bad_request', message: (err as Error).message }, 400);
    }
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    await svc.sessionRegistry.ensureLoaded(id).catch(() => undefined);
    const record = svc.sessionRegistry.get(id, token);
    if (!record) return c.json({ error: 'session_not_found' }, 404);
    if (svc.pool.get(token)) {
      return c.json({
        error: 'session_live',
        message: 'pause the live PTY before probing — they would race on the transcript',
      }, 409);
    }
    const adapter = svc.adapters.get(record.agent);
    if (!adapter) {
      return c.json({
        error: 'unknown_agent',
        message: `record references unknown adapter: ${record.agent}`,
      }, 500);
    }
    const resume: SessionFactoryContext['resume'] =
      resumeOverride === 'none'
        ? undefined
        : resumeOverride === 'last'
          ? 'last'
          : resumeOverride !== undefined
            ? resumeOverride
            : mappedResumeForRecord(record, adapter);
    launcherLogger.info('workspace.probe_started', {
      id, sessionId: token, agent: adapter.id, promptLen: prompt.length, timeoutMs,
      resumeMode: resume === undefined ? 'fresh' : resume === 'last' ? 'last' : 'by-id',
    });
    try {
      const result = await svc.runHeadlessProbe(meta, adapter, resume, prompt, timeoutMs);
      return c.json(result);
    } catch (err) {
      if (err instanceof AgentCredentialError) {
        return c.json(err.toBody(), 400);
      }
      launcherLogger.error('workspace.probe_failed', { id, token, err });
      return c.json({ error: 'probe_failed', message: (err as Error).message }, 500);
    }
  });

  // Headless task dispatch — the standard automation API. Spawns the
  // workspace's agent CLI in one-shot headless mode with a positional prompt,
  // runs to natural exit, returns exit/duration, a normalized reply/tool
  // timeline, and bounded output tails. `inbox_push` remains the durable
  // user-delivery channel; structured output powers readiness, Automation, and
  // orchestration. No session/PTY — a fresh one-shot clone each call (no
  // respawn, not pooled). Synchronous: the request stays
  // open until the task exits (the cron/automation trigger calls
  // `svc.runHeadlessTask` directly instead). Body: { prompt, agent?, timeoutMs? }.
  //   curl -XPOST .../:id/headless -d '{"prompt":"...","agent":"claude"}'
  app.post('/:id/headless', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    let prompt: string;
    let timeoutMs: number | undefined;
    let agentId: string | undefined;
    let resumeId: string | undefined;
    let wait = false;
    try {
      const body = await safeJson(c);
      const fields = body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
      const rawPrompt = fields['prompt'];
      // Gate on trimmed length so a whitespace-only prompt can't spawn a no-op
      // agent run; pass the original prompt through unchanged.
      if (typeof rawPrompt !== 'string' || rawPrompt.trim().length === 0) {
        return c.json({ error: 'prompt_required' }, 400);
      }
      if (rawPrompt.length > 16000) {
        return c.json({ error: 'prompt_too_long', message: 'max 16000 chars' }, 400);
      }
      prompt = rawPrompt;
      const rawTimeout = fields['timeoutMs'];
      timeoutMs = typeof rawTimeout === 'number' && rawTimeout > 0
        ? Math.min(rawTimeout, 2_147_478_647)
        : undefined;
      const rawAgent = fields['agent'];
      if (typeof rawAgent === 'string' && rawAgent.length > 0) agentId = rawAgent;
      const rawResumeId = fields['resumeId'];
      if (typeof rawResumeId === 'string' && validId(rawResumeId)) resumeId = rawResumeId;
      wait = fields['wait'] === true;
    } catch (err) {
      return c.json({ error: 'bad_request', message: (err as Error).message }, 400);
    }
    const meta = svc.registry.get(id);
    if (!meta) return c.json({ error: 'workspace_not_found' }, 404);
    const resumeIdentity = resumeId ? svc.resumeRegistry.get(resumeId) : null;
    if (resumeId && !resumeIdentity) return c.json({ error: 'resume_not_found' }, 404);
    if (resumeIdentity && resumeIdentity.wsId !== id) {
      return c.json({ error: 'resume_wrong_workspace' }, 409);
    }
    if (wait && resumeId) {
      return c.json({ error: 'resume_requires_async', message: 'resumed turns are recorded runs; omit wait:true' }, 400);
    }
    if (agentId && !svc.adapters.get(agentId)) {
      return c.json({ error: 'unknown_agent', message: `no adapter: ${agentId}` }, 400);
    }
    const runtimeSettings = !resumeIdentity
      ? await readWorkspaceRuntimeSettings(meta.dir)
      : null;
    if (runtimeSettings && !runtimeSettings.ok && runtimeSettings.reason === 'invalid') {
      return c.json({ error: 'workspace_runtime_settings_invalid', message: runtimeSettings.error }, 400);
    }
    const preferredIssuesAgent = runtimeSettings?.ok
      ? resolveWorkspaceRuntimeAgent(runtimeSettings.settings, 'headless')
      : undefined;
    const preferredIssuesAdapter = preferredIssuesAgent
      ? svc.adapters.get(preferredIssuesAgent)
      : undefined;
    const validPreferredIssuesAgent = preferredIssuesAgent && preferredIssuesAdapter &&
      isAgentRuntime(preferredIssuesAdapter)
      ? preferredIssuesAgent
      : undefined;
    const effectiveAgentId = agentId ?? resumeIdentity?.agent ?? validPreferredIssuesAgent ?? await resolveDefaultAgentId(meta);
    if (!effectiveAgentId) {
      return c.json({ error: 'no_agent_runtime', message: 'no agent runtime is registered' }, 400);
    }
    const adapter = svc.resolveAdapter(meta, effectiveAgentId);
    if (!adapter.capabilities.headless || !adapter.composeHeadlessCommand) {
      return c.json({ error: 'no_headless', message: `adapter "${adapter.id}" has no headless mode` }, 400);
    }
    launcherLogger.info('workspace.headless_started', {
      id,
      agent: adapter.id,
      promptLen: prompt.length,
      ...(timeoutMs !== undefined ? { timeoutMs } : {}),
      wait,
    });
    // `wait:true` → run synchronously and return the full result (curl/tests).
    if (wait) {
      try {
        const result = await svc.runHeadlessTask(meta, adapter, prompt, timeoutMs);
        return c.json(result);
      } catch (err) {
        if (err instanceof AgentCredentialError) {
          return c.json(err.toBody(), 400);
        }
        launcherLogger.error('workspace.headless_failed', { id, agent: adapter.id, err });
        return c.json({ error: 'headless_failed', message: (err as Error).message }, 500);
      }
    }
    // Default → async: record + spawn in the background, return the taskId. The
    // run's status and normalized output are queryable under /api/headless;
    // the agent can additionally publish durable user-facing work to Inbox.
    try {
      const dispatched = resumeId
        ? await svc.dispatchHeadlessTask(meta, adapter, prompt, timeoutMs, undefined, resumeId)
        : await svc.dispatchHeadlessTask(
            meta,
            adapter,
            prompt,
            timeoutMs,
            undefined,
            undefined,
            undefined,
            undefined,
            undefined,
            { kind: 'headless', surface: 'api' },
          );
      return c.json({ ...dispatched, status: 'running' }, 202);
    } catch (err) {
      if (err instanceof HeadlessCapacityError) {
        return c.json({ error: 'capacity', message: err.message }, 429);
      }
      if (err instanceof HeadlessResumeError) {
        return c.json(
          { error: `resume_${err.code}`, message: err.message },
          err.code === 'not_found' ? 404 : 409,
        );
      }
      if (err instanceof AgentCredentialError) {
        return c.json(err.toBody(), 400);
      }
      launcherLogger.error('workspace.headless_failed', { id, agent: adapter.id, err });
      return c.json({ error: 'headless_failed', message: (err as Error).message }, 500);
    }
  });

  app.delete('/:id/sessions/:sid', async (c) => {
    const id = c.req.param('id');
    const token = c.req.param('sid');
    if (!validId(id) || !validId(token)) {
      return c.json({ error: 'not_found' }, 404);
    }
    const record = svc.sessionRegistry.get(id, token);
    if (!record) return c.json({ error: 'not_found' }, 404);
    const wasTerminalRunning = svc.pool.disposeToken(token, 'session deleted');
    const wasWebPiRunning = await svc.webPi?.stop(token, 'session deleted') ?? false;
    const wasRunning = wasTerminalRunning || wasWebPiRunning;
    if (record.scrollbackFile) {
      await svc.scrollbackStore.remove(record.scrollbackFile);
    }
    await svc.sessionRegistry.update(id, token, {
      state: 'paused',
      lastActiveAt: new Date().toISOString(),
    });
    await svc.deleteSessionPresence({ wsId: id, resumeId: record.resumeId });
    launcherLogger.info('workspace.session_deleted', { id, sessionId: token, wasRunning });
    if (wasRunning) {
      await svc.recordAgentRuntime?.('runtime.stopped', {
        workspaceId: record.wsId,
        resumeId: record.resumeId,
        agent: record.agent,
        sessionRecordId: record.id,
        surface: wasWebPiRunning && !wasTerminalRunning ? 'webpi' : 'terminal',
        status: 'interrupted',
      });
    }
    return c.json({ ok: true, wasRunning });
  });

  // ── deprecated native-project compatibility export ─────────────────────
  // These routes operate on CLI-native files discovered by the runtimes via
  // cwd/CODEX_HOME. Managed Session defaults live in `.alice/settings.json`;
  // this file-IO surface remains only for users who deliberately run a CLI
  // directly inside the Workspace.


  // Central credential store, surfaced to the workspace AI-config modal. The
  // "Load from saved credential" picker reads this list; the "Save to Alice"
  // dialog POSTs here so a hand-entered provider becomes reusable. apiKey is
  // returned so the picker can flash it into the form (same exposure as the
  // legacy agent-profiles route; both are behind the admin-token gate).
  app.get('/credentials', async (c) => {
    try {
      const credentials = await readCredentials();
      // `?agent=<id>` filters to the credentials that agent can actually be
      // driven by (its wire shapes) — the quick-chat runtime dropdown uses this
      // so it never offers a cred the agent can't speak. apiKey omitted in this
      // mode; the dropdown receives only presentation/injection metadata, while
      // the unfiltered Workspace modal keeps the key-bearing response.
      const agent = c.req.query('agent');
      const adapter = agent ? svc.adapters.get(agent) : undefined;
      const entries = agent
        ? adapter ? compatibleCredentials(credentials, adapter) : []
        : Object.entries(credentials);
      const list = entries.map(([slug, cred]) => {
        const resolvedModel = resolveInjectionModel(cred);
        const projected = adapter && resolvedModel
          ? credentialToWorkspaceAiCred(cred, adapter, { model: resolvedModel })
          : null;
        const reasoningMode = resolveModelSemantics(cred.vendor, resolvedModel)?.reasoning?.mode;
        return {
          slug,
          vendor: cred.vendor,
          ...(cred.label ? { label: cred.label } : {}),
          authType: cred.authType,
          wires: credentialWires(cred), // shape → endpoint; the modal picks one per agent
          ...(cred.lastModel ? { lastModel: cred.lastModel } : {}),
          ...(resolvedModel ? { resolvedModel } : {}),
          ...(typeof projected?.contextWindow === 'number'
            ? { resolvedContextWindow: projected.contextWindow }
            : {}),
          ...(typeof projected?.reasoning === 'boolean'
            ? { resolvedReasoning: projected.reasoning }
            : {}),
          ...(projected?.reasoningEffort
            ? { resolvedReasoningEffort: projected.reasoningEffort }
            : {}),
          ...(reasoningMode ? { resolvedReasoningMode: reasoningMode } : {}),
          ...(agent ? {} : { apiKey: cred.apiKey ?? null }),
        };
      });
      return c.json({ credentials: list });
    } catch (err) {
      launcherLogger.warn('credentials.read_failed', { err });
      return c.json({ error: 'credentials_read_failed', message: (err as Error).message }, 500);
    }
  });

  app.post('/credentials', async (c) => {
    const body = (await safeJson(c)) as
      | { apiKey?: string; baseUrl?: string; agent?: string; vendor?: string; label?: string; wireShape?: string }
      | null;
    const apiKey = body?.apiKey?.trim();
    if (!apiKey) return c.json({ error: 'apiKey_required' }, 400);
    const baseUrl = body?.baseUrl?.trim() || undefined;
    const label = body?.label?.trim();
    const wireParse = credentialWireShapeEnum.safeParse(body?.wireShape);
    // The workspace modal saves a single hand-entered shape; capture it as a
    // one-entry wires map (the vault can later add more shapes for the same key —
    // dedup-by-key upgrades in place). Subscriptions never flow through here.
    const cred: Credential = {
      vendor: inferCredentialVendor({
        agent: body?.agent,
        baseUrl,
        ...(wireParse.success ? { wireShape: wireParse.data } : {}),
      }),
      ...(label ? { label } : {}),
      authType: 'api-key',
      apiKey,
      ...(wireParse.success ? { wires: { [wireParse.data]: baseUrl ?? '' } } : (baseUrl ? { wires: {} } : {})),
    };
    try {
      const slug = await addCredential(cred);
      launcherLogger.info('credentials.saved', { slug, vendor: cred.vendor });
      return c.json({ slug, vendor: cred.vendor }, 201);
    } catch (err) {
      launcherLogger.warn('credentials.write_failed', { err });
      return c.json({ error: 'credentials_write_failed', message: (err as Error).message }, 500);
    }
  });

  // Deprecated compatibility export API. Managed Sessions do not consult
  // these native project files for fresh launch defaults.
  app.get('/:id/agent-config', async (c) => {
    c.header('Deprecation', 'true');
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    try {
      const configurable = svc.adapters.list().filter(
        (adapter) => adapter.capabilities.aiProvider && adapter.readAiConfig,
      );
      const entries = await Promise.all(configurable.map(async (adapter) => [
        adapter.id,
        await adapter.readAiConfig!(meta.dir),
      ] as const));
      return c.json(Object.fromEntries(entries));
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('agent_config.read_failed', { id, err });
      return c.json({ error: 'read_failed', message: (err as Error).message }, 500);
    }
  });

  // Which vault credential the deprecated native project export currently contains
  // (slug + effective model/protocol/context), plus any native pre-prompt setup
  // gate the adapter can inspect without changing runtime-owned state.
  // Ordinary detection does not overwrite config. The Pi adapter may perform
  // its one-time legacy `.pi-agent` layout migration before reading.
  app.get('/:id/agent-config/:agent/credential', async (c) => {
    c.header('Deprecation', 'true');
    const id = c.req.param('id');
    const agent = c.req.param('agent');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    try {
      const adapter = svc.adapters.get(agent);
      const [detected, interactiveSetupStatus] = await Promise.all([
        detectWorkspaceCred(meta, agent, await readCredentials()),
        adapter?.readInteractiveSetupStatus?.(meta.dir).catch(() => 'unknown' as const) ?? null,
      ]);
      return c.json({
        configured: detected !== null,
        slug: detected?.slug ?? null,
        model: detected?.model ?? null,
        contextWindow: detected?.contextWindow ?? null,
        wireShape: detected?.wireShape ?? null,
        ...(typeof detected?.reasoning === 'boolean' ? { reasoning: detected.reasoning } : {}),
        ...(detected?.reasoningEffort ? { reasoningEffort: detected.reasoningEffort } : {}),
        ...(detected?.reasoningMode ? { reasoningMode: detected.reasoningMode } : {}),
        ...(typeof detected?.reasoningDefaultEnabled === 'boolean'
          ? { reasoningDefaultEnabled: detected.reasoningDefaultEnabled }
          : {}),
        ...(interactiveSetupStatus !== null ? { interactiveSetupStatus } : {}),
      });
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('agent_config.detect_cred_failed', { id, agent, err });
      return c.json({ configured: false, slug: null, model: null, contextWindow: null, wireShape: null });
    }
  });

  app.get('/:id/agent-readiness', async (c) => {
    const id = c.req.param('id');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    try {
      const credentials = await readCredentials();
      const rows = await Promise.all(
        svc.adapters.list()
          .filter(isAgentRuntime)
          .map((adapter) => ({ agentId: adapter.id, adapter }))
          .map(({ agentId, adapter }) =>
            getAgentCredentialReadiness({ meta, agentId, adapter, credentials }),
          ),
      );
      return c.json({ agents: Object.fromEntries(rows.map((row) => [row.agent, row])) });
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('agent_readiness.failed', { id, err });
      return c.json({ error: 'readiness_failed', message: (err as Error).message }, 500);
    }
  });

  app.get('/:id/agent-readiness/:agent', async (c) => {
    const id = c.req.param('id');
    const agent = c.req.param('agent');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);
    try {
      const row = await getAgentCredentialReadiness({
        meta,
        agentId: agent,
        adapter: svc.adapters.get(agent),
      });
      return c.json(row);
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('agent_readiness.failed', { id, agent, err });
      return c.json({ error: 'readiness_failed', message: (err as Error).message }, 500);
    }
  });

  app.put('/:id/agent-config/:agent', async (c) => {
    c.header('Deprecation', 'true');
    const id = c.req.param('id');
    const agent = c.req.param('agent');
    if (!validId(id)) return c.json({ error: 'not_found' }, 404);
    const adapter = svc.adapters.get(agent);
    if (!adapter?.capabilities.aiProvider || !adapter.writeAiConfig) {
      return c.json({ error: 'unknown_agent' }, 400);
    }
    const meta = svc.resolveRuntimeWorkspace?.(id) ?? svc.registry.get(id);
    if (!meta) return c.json({ error: 'not_found' }, 404);

    const body = (await safeJson(c)) as WorkspaceAiCred | null;
    const cfg = body && typeof body === 'object' ? body : {};
    try {
      const credentials = cfg.apiKey ? await readCredentials() : {};
      const slug = matchCredentialByApiKey(credentials, cfg.apiKey);
      const vendor = slug
        ? credentials[slug]?.vendor
        : inferCredentialVendor({
            agent,
            baseUrl: cfg.baseUrl ?? undefined,
            wireShape: cfg.wireShape ?? undefined,
          });
      const projected = applyRegisteredModelSemantics(
        cfg,
        adapter.capabilities.aiProvider,
        vendor,
      );
      await adapter.writeAiConfig(meta.dir, projected);
      // Remember an explicit model choice on the originating vault credential
      // (matched by apiKey) so quick-chat can reuse it without re-prompting.
      // Best-effort: the config was already written; a miss here is cosmetic.
      if (projected.apiKey && projected.model) {
        try {
          const modelSlug = slug ?? matchCredentialByApiKey(await readCredentials(), projected.apiKey);
          if (modelSlug) await setCredentialLastModel(modelSlug, projected.model);
        } catch (err) {
          launcherLogger.warn('agent_config.last_model_record_failed', { id, agent, err });
        }
      }
      launcherLogger.info('agent_config.saved', { id, agent });
      return c.json({ ok: true });
    } catch (err) {
      if (err instanceof PathTraversal) return c.json({ error: 'invalid_path' }, 400);
      launcherLogger.warn('agent_config.write_failed', { id, agent, err });
      return c.json({ error: 'write_failed', message: (err as Error).message }, 500);
    }
  });

  // Probe live provider with the form state (does NOT touch workspace files —
  // tests exactly what the user sees in the modal, before they hit Save).
  app.post('/:id/agent-config/:agent/test', async (c) => {
    c.header('Deprecation', 'true');
    const id = c.req.param('id');
    const agent = c.req.param('agent');
    if (!validId(id)) return c.json({ ok: false, error: 'invalid_id' }, 400);
    if (!svc.adapters.get(agent)?.capabilities.aiProvider) {
      return c.json({ ok: false, error: 'unknown_agent' }, 400);
    }

    const body = (await safeJson(c)) as WorkspaceAiCred | null;
    const baseUrl = typeof body?.baseUrl === 'string' ? body.baseUrl.trim() : '';
    const apiKey = typeof body?.apiKey === 'string' ? body.apiKey.trim() : '';
    const model = typeof body?.model === 'string' ? body.model.trim() : '';
    // baseUrl may be empty (official endpoint); probeByWireShape defaults it.
    if (!apiKey || !model) {
      return c.json({ ok: false, error: 'apiKey and model are required' }, 400);
    }

    try {
      // Same dispatcher as the credential vault — Test means the same thing
      // everywhere. The shape comes from the credential's wireShape (threaded by
      // the modal), defaulting to the agent's native shape.
      const wireShape: WireShape = body?.wireShape ?? DEFAULT_WIRE_BY_AGENT[agent] ?? 'openai-chat';
      const result = await probeByWireShape(wireShape, {
        baseUrl,
        apiKey,
        model,
        // Resolve the anthropic auth header by baseUrl (api.minimax.io → bearer),
        // same as the vault — the modal only sends authMode on the claude tab, so
        // an anthropic-shape cred on an opencode/pi tab needs the baseUrl heuristic.
        authMode: resolveAnthropicAuthMode({ authMode: body?.authMode, baseUrl }),
      });
      return c.json({ ok: true, response: result.text });
    } catch (err) {
      const e = err as { status?: number; message?: string };
      const msg = e.status ? `${e.status} ${e.message ?? 'error'}` : (e.message ?? String(err));
      launcherLogger.info('agent_config.test_failed', { id, agent, msg });
      return c.json({ ok: false, error: msg });
    }
  });

  return app;
}

// ── Agent config helpers ────────────────────────────────────────────────────

// Deprecated native-config export IO lives in the CLI adapters (writeAiConfig /
// readAiConfig). The compatibility routes above dispatch through svc.adapters
// so each CLI continues to own its native file format.

function validId(id: string | undefined): id is string {
  return typeof id === 'string' && /^[a-zA-Z0-9_-]+$/.test(id);
}

async function safeJson(c: import('hono').Context): Promise<unknown> {
  try {
    const body = await c.req.json();
    return body;
  } catch {
    return null;
  }
}
