import { Hono } from 'hono'
import {
  loadConfig, writeConfigSection, validSections,
  readCredentials, addCredential, deleteCredential, writeCredential, resolveCredential,
  credentialWires,
  readWorkspaceCredentialDefaults, writeWorkspaceCreationDefaults,
  readIssueDefaultAgent, writeIssueDefaultAgent,
  readWorkspaceDefaultAgent, writeWorkspaceDefaultAgent,
  credentialVendorEnum, credentialWireShapeEnum,
  type ConfigSection, type Credential, type CredentialWireShape,
  type WorkspaceCredentialDefault,
} from '../../core/config.js'
import { compatibleCredentials, pickAgentWire, resolveInjectionModel } from '../../workspaces/credential-injection.js'

/** Validate a `{ [wireShape]: baseUrl }` body into a typed wires map. */
function parseWires(raw: unknown): Partial<Record<CredentialWireShape, string>> {
  if (!raw || typeof raw !== 'object') return {}
  const out: Partial<Record<CredentialWireShape, string>> = {}
  for (const [shape, url] of Object.entries(raw as Record<string, unknown>)) {
    const parsed = credentialWireShapeEnum.safeParse(shape)
    if (parsed.success && typeof url === 'string') out[parsed.data] = url.trim()
  }
  return out
}
import type { EngineContext } from '../../core/types.js'
import { triggerUTARestart } from '../../services/uta-supervisor/restart-trigger.js'
import { BUILTIN_PRESETS } from '../../ai-providers/presets.js'
import type { WireShape } from '../../ai-providers/preset-catalog.js'
import { resolveModelSemantics } from '../../ai-providers/model-semantics.js'
import { resolveAnthropicAuthMode } from '../../core/credential-inference.js'
import { probeByWireShape } from '../../workspaces/agent-probe.js'
import { createBuiltinAdapterRegistry } from '../../workspaces/adapters/index.js'
import {
  isAgentRuntime,
  type AdapterRegistry,
  type CliAdapter,
} from '../../workspaces/cli-adapter.js'

interface ConfigRouteOpts {
  ctx?: EngineContext
  adapterRegistry?: AdapterRegistry
}

export const ONBOARDING_TEST_CREDENTIAL = {
  apiKey: 'oa_test_ok',
  model: 'openalice-onboarding-test',
  baseUrl: 'http://127.0.0.1:0/v1',
  wireShape: 'openai-chat' as const satisfies WireShape,
}

function onboardingTestCredential(env: NodeJS.ProcessEnv = process.env) {
  return {
    ...ONBOARDING_TEST_CREDENTIAL,
    baseUrl: env['OPENALICE_ONBOARDING_AI_BASE_URL']?.trim()
      || ONBOARDING_TEST_CREDENTIAL.baseUrl,
  }
}

function onboardingMockCredentialTestEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return env['OPENALICE_ONBOARDING_TEST'] === '1' && env['OPENALICE_CREDENTIAL_TEST_MODE'] === 'mock'
}

function maybeHandleOnboardingMockCredentialTest(body: {
  wireShape: WireShape
  baseUrl?: string
  apiKey: string
  model: string
}): { ok: boolean; response?: string; error?: string } | null {
  if (!onboardingMockCredentialTestEnabled()) return null
  const credential = onboardingTestCredential()
  const isMockEndpoint =
    body.wireShape === credential.wireShape &&
    body.baseUrl?.trim() === credential.baseUrl &&
    body.model.trim() === credential.model
  if (!isMockEndpoint) return null
  if (body.apiKey.trim() !== credential.apiKey) {
    return { ok: false, error: `Use the onboarding test key "${credential.apiKey}".` }
  }
  return { ok: true, response: 'OpenAlice onboarding mock credential is ready.' }
}

/** Config routes: GET /, PUT /:section, profile CRUD, presets, test */
export function createConfigRoutes(opts?: ConfigRouteOpts) {
  const app = new Hono()
  const adapters = opts?.adapterRegistry ?? createBuiltinAdapterRegistry()
  const runtimeAdapters = adapters.list().filter(isAgentRuntime)
  const providerAdapters = runtimeAdapters.filter(
    (adapter): adapter is CliAdapter & {
      capabilities: CliAdapter['capabilities'] & {
        aiProvider: NonNullable<CliAdapter['capabilities']['aiProvider']>
      }
    } => adapter.capabilities.aiProvider !== undefined,
  )

  app.get('/', async (c) => {
    try {
      const config = await loadConfig()
      return c.json(config)
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  // ==================== Presets ====================

  /** GET /presets — built-in preset suggestions for the credential vault form */
  app.get('/presets', (c) => c.json({ presets: BUILTIN_PRESETS }))

  // ==================== Credential Vault ====================
  //
  // Alice's central api-key credentials — resolved into per-process Session
  // bindings when a Workspace launch explicitly selects one.
  // Subscription logins (claude login / codex login) are NOT stored here; they
  // live in the CLI's own auth. The list never returns the raw key (only
  // whether one is set); Test runs the lightweight probe, not the in-process
  // provider stack.

  /**
   * GET /credentials — list central credentials. Returns the apiKey so the edit
   * form can round-trip it (same exposure as /api/workspaces/credentials and the
   * legacy agent-profiles route; all behind the admin-token gate). `hasApiKey`
   * kept for callers that only need presence.
   */
  app.get('/credentials', async (c) => {
    try {
      const creds = await readCredentials()
      const list = Object.entries(creds).map(([slug, cred]) => ({
        slug,
        vendor: cred.vendor,
        ...(cred.label ? { label: cred.label } : {}),
        authType: cred.authType,
        wires: credentialWires(cred), // derives from legacy {baseUrl,wireShape} too
        ...(cred.baseUrl ? { baseUrl: cred.baseUrl } : {}),
        apiKey: cred.apiKey ?? null,
        hasApiKey: !!cred.apiKey,
        ...(cred.lastModel ? { lastModel: cred.lastModel } : {}),
      }))
      return c.json({ credentials: list })
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  /** POST /credentials — add an api-key credential (deduped by key). Returns slug. */
  app.post('/credentials', async (c) => {
    try {
      const body = await c.req.json<{ vendor?: string; label?: string; wires?: unknown; baseUrl?: string; apiKey?: string; lastModel?: string }>()
      const apiKey = body.apiKey?.trim()
      if (!apiKey) return c.json({ error: 'apiKey is required' }, 400)
      const vendorParse = credentialVendorEnum.safeParse(body.vendor)
      const label = body.label?.trim()
      const lastModel = body.lastModel?.trim()
      const wires = parseWires(body.wires)
      const baseUrl = body.baseUrl?.trim()
      const cred: Credential = {
        vendor: vendorParse.success ? vendorParse.data : 'custom',
        ...(label ? { label } : {}),
        authType: 'api-key',
        apiKey,
        ...(Object.keys(wires).length ? { wires } : {}),
        ...(baseUrl ? { baseUrl } : {}),
        ...(lastModel ? { lastModel } : {}),
      }
      const slug = await addCredential(cred)
      return c.json({ slug, vendor: cred.vendor }, 201)
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  /** PUT /credentials/:slug — update a credential. Empty apiKey keeps the existing key. */
  app.put('/credentials/:slug', async (c) => {
    try {
      const slug = c.req.param('slug')
      const body = await c.req.json<{ vendor?: string; label?: string; wires?: unknown; baseUrl?: string; apiKey?: string; lastModel?: string }>()
      const existing = await resolveCredential(slug)
      const apiKey = body.apiKey?.trim() || existing.apiKey
      const vendorParse = credentialVendorEnum.safeParse(body.vendor)
      const hasLabel = Object.prototype.hasOwnProperty.call(body, 'label')
      const label = typeof body.label === 'string' ? body.label.trim() : undefined
      const lastModel = body.lastModel?.trim() || existing.lastModel
      const wires = parseWires(body.wires)
      const hasBaseUrl = Object.prototype.hasOwnProperty.call(body, 'baseUrl')
      const baseUrl = hasBaseUrl ? body.baseUrl?.trim() : existing.baseUrl
      const cred: Credential = {
        vendor: vendorParse.success ? vendorParse.data : existing.vendor,
        ...(hasLabel
          ? (label ? { label } : {})
          : (existing.label ? { label: existing.label } : {})),
        authType: 'api-key',
        ...(apiKey ? { apiKey } : {}),
        ...(Object.keys(wires).length ? { wires } : { ...(existing.wires ? { wires: existing.wires } : {}) }),
        ...(baseUrl ? { baseUrl } : {}),
        ...(lastModel ? { lastModel } : {}),
      }
      const defaults = await readWorkspaceCredentialDefaults()
      for (const [agentId, def] of Object.entries(defaults)) {
        if (def.credentialSlug !== slug) continue
        const adapter = adapters.get(agentId)
        const capabilities = adapter?.capabilities.aiProvider
        const remainsCompatible = capabilities && (
          def.wireShape
            ? pickAgentWire(credentialWires(cred), capabilities, def.wireShape) !== null
            : compatibleCredentials({ [slug]: cred }, adapter).length > 0
        )
        if (!remainsCompatible) {
          return c.json({
            error: `This credential is the ${agentId} Workspace default. Choose a compatible default protocol before removing its current wire.`,
          }, 400)
        }
      }
      await writeCredential(slug, cred)
      return c.json({ slug })
    } catch (err) {
      return c.json({ error: String(err) }, 400)
    }
  })

  /** DELETE /credentials/:slug — remove (errors if a profile still references it). */
  app.delete('/credentials/:slug', async (c) => {
    try {
      await deleteCredential(c.req.param('slug'))
      return c.json({ success: true })
    } catch (err) {
      return c.json({ error: String(err) }, 400)
    }
  })

  /**
   * POST /credentials/test — probe a credential via the shared
   * `probeByWireShape` dispatcher (same logic as the per-workspace test). For
   * the anthropic shape the auth header is auto-resolved from the baseUrl.
   */
  app.post('/credentials/test', async (c) => {
    try {
      const body = await c.req.json<{
        wireShape: WireShape
        baseUrl?: string
        apiKey: string
        model: string
        authMode?: 'x-api-key' | 'bearer'
      }>()
      if (!body.apiKey || !body.model) {
        return c.json({ ok: false, error: 'apiKey and model are required' })
      }
      const mockResult = maybeHandleOnboardingMockCredentialTest(body)
      if (mockResult) return c.json(mockResult)
      const authMode = resolveAnthropicAuthMode({ authMode: body.authMode, baseUrl: body.baseUrl })
      const r = await probeByWireShape(body.wireShape, {
        baseUrl: body.baseUrl, apiKey: body.apiKey, model: body.model, authMode,
      })
      return c.json({ ok: true, response: r.text })
    } catch (err) {
      return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
    }
  })

  // ============ Default Workspace Credentials (per-agent) ============
  //
  // Deprecated installation-level creation seeds. The Workspace creator
  // translates this per-agent map into secret-free `.alice/settings.json`
  // preferences; it no longer writes native CLI project configuration.

  /**
   * GET /workspace-credential-defaults — the current per-agent defaults plus,
   * for the picker, the vault slugs each agent can actually be driven by (the
   * wire-shape funnel computed server-side, so the UI stays dumb).
   */
  app.get('/workspace-credential-defaults', async (c) => {
    try {
      const [defaults, creds] = await Promise.all([
        readWorkspaceCredentialDefaults(),
        readCredentials(),
      ])
      const compatibleByAgent: Record<string, string[]> = {}
      for (const adapter of providerAdapters) {
        compatibleByAgent[adapter.id] = compatibleCredentials(creds, adapter).map(([slug]) => slug)
      }
      return c.json({ defaults, compatibleByAgent })
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  /**
   * PUT /workspace-credential-defaults — replace the whole per-agent map. Body:
   * `{ defaults: { [agentId]: { credentialSlug, model? } } }`. An empty/absent
   * `credentialSlug` for an agent clears its default (handled in the writer).
   */
  app.put('/workspace-credential-defaults', async (c) => {
    try {
      const body = await c.req.json<{
        defaults?: Record<string, WorkspaceCredentialDefault>
      }>()
      const credentials = await readCredentials()
      const incoming = body.defaults ?? {}
      const next: Record<string, WorkspaceCredentialDefault> = {}
      for (const adapter of providerAdapters) {
        const agent = adapter.id
        const capabilities = adapter.capabilities.aiProvider
        const registration = capabilities.modelRegistration
        const def = incoming[agent]
        if (def && typeof def.credentialSlug === 'string' && def.credentialSlug) {
          const credential = credentials[def.credentialSlug]
          if (!credential || !compatibleCredentials({ [def.credentialSlug]: credential }, adapter).length) {
            return c.json({ error: `${agent} cannot use ${def.credentialSlug}` }, 400)
          }
          const parsedWire = credentialWireShapeEnum.safeParse(def.wireShape)
          if (def.wireShape !== undefined && !parsedWire.success) {
            return c.json({ error: `Invalid protocol for ${agent}` }, 400)
          }
          if (parsedWire.success) {
            if (
              !pickAgentWire(credentialWires(credential), capabilities, parsedWire.data)
            ) {
              return c.json({ error: `${agent} cannot use ${parsedWire.data} from ${def.credentialSlug}` }, 400)
            }
          }
          const selectedModel = typeof def.model === 'string' && def.model
            ? def.model
            : credential ? resolveInjectionModel(credential) : null
          const reasoningIsRegistered = !!resolveModelSemantics(
            credential?.vendor,
            selectedModel,
          )?.reasoning
          if (def.contextWindow !== undefined && (
            typeof def.contextWindow !== 'number' ||
            !Number.isFinite(def.contextWindow) ||
            def.contextWindow <= 0
          )) {
            return c.json({ error: `Invalid context window for ${agent}` }, 400)
          }
          next[agent] = {
            credentialSlug: def.credentialSlug,
            ...(typeof def.model === 'string' && def.model ? { model: def.model } : {}),
            ...(parsedWire.success ? { wireShape: parsedWire.data } : {}),
            ...(registration?.contextWindow && def.contextWindow !== undefined
              ? { contextWindow: def.contextWindow }
              : {}),
            ...(registration?.reasoning &&
              !reasoningIsRegistered &&
              typeof selectedModel === 'string' &&
              typeof def.reasoning === 'boolean'
              ? { reasoning: def.reasoning, reasoningModel: selectedModel }
              : {}),
          }
        }
      }
      await writeWorkspaceCreationDefaults(next)
      return c.json({ defaults: next })
    } catch (err) {
      return c.json({ error: String(err) }, 400)
    }
  })

  app.get('/workspace-default-agent', async (c) => {
    try {
      return c.json({ agent: await readWorkspaceDefaultAgent() })
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  app.put('/workspace-default-agent', async (c) => {
    try {
      const body = await c.req.json<{ agent?: string | null }>()
      const agent = typeof body.agent === 'string' &&
        runtimeAdapters.some((adapter) => adapter.id === body.agent)
          ? body.agent
          : null
      await writeWorkspaceDefaultAgent(agent)
      return c.json({ agent })
    } catch (err) {
      return c.json({ error: String(err) }, 400)
    }
  })

  app.get('/issue-default-agent', async (c) => {
    try {
      return c.json({ agent: await readIssueDefaultAgent() })
    } catch (err) {
      return c.json({ error: String(err) }, 500)
    }
  })

  app.put('/issue-default-agent', async (c) => {
    try {
      const body = await c.req.json<{ agent?: string | null }>()
      const agent = typeof body.agent === 'string' &&
        runtimeAdapters.some((adapter) => adapter.id === body.agent)
          ? body.agent
          : null
      await writeIssueDefaultAgent(agent)
      return c.json({ agent })
    } catch (err) {
      return c.json({ error: String(err) }, 400)
    }
  })

  // ==================== Generic Section Writer ====================

  app.put('/:section', async (c) => {
    try {
      const section = c.req.param('section') as ConfigSection
      if (!validSections.includes(section)) {
        return c.json({ error: `Invalid section "${section}". Valid: ${validSections.join(', ')}` }, 400)
      }
      const body = await c.req.json()
      const validated = await writeConfigSection(section, body)
      // Keep the in-memory ctx.config in sync with disk so any code path
      // reading it (provider resolver, market-data helpers, …) picks up
      // edits without a restart. Object.assign preserves ctx.config's
      // object identity — we just swap its contents.
      if (opts?.ctx) {
        const fresh = await loadConfig()
        Object.assign(opts.ctx.config, fresh)
      }
      // trading.json and snapshot.json are consumed by the UTA process at
      // boot (order-sync and snapshot pump cadence) — bounce UTA via the
      // Guardian flag protocol, same as broker config edits.
      // Fire-and-forget: progress is visible through the health badges.
      if (section === 'trading' || section === 'snapshot') {
        triggerUTARestart().catch(() => { /* surfaced via health badges */ })
      }
      // marketData edits are picked up lazily by the provider resolver
      // (it reads ctx.config per request), so no explicit hot-reload hook
      // is needed. Connector Service owns its own restart flag and API.
      return c.json(validated)
    } catch (err) {
      if (err instanceof Error && err.name === 'ZodError') {
        return c.json({ error: 'Validation failed', details: JSON.parse(err.message) }, 400)
      }
      return c.json({ error: String(err) }, 500)
    }
  })

  return app
}

/** Market data routes: POST /test-provider, GET /hub-status */
export function createMarketDataRoutes(ctx: EngineContext) {
  const TEST_ENDPOINTS: Record<string, { credField: string; provider: string; model: string; params: Record<string, unknown> }> = {
    fred:             { credField: 'federal_reserve_api_key',  provider: 'federal_reserve', model: 'FredSearch',              params: { query: 'GDP' } },
    bls:              { credField: 'bls_api_key',              provider: 'bls',              model: 'BlsSearch',               params: { query: 'unemployment' } },
    eia:              { credField: 'eia_api_key',              provider: 'eia',              model: 'ShortTermEnergyOutlook',  params: {} },
    econdb:           { credField: 'econdb_api_key',           provider: 'econdb',           model: 'AvailableIndicators',     params: {} },
    fmp:              { credField: 'fmp_api_key',              provider: 'fmp',              model: 'EquityScreener',          params: { limit: 1 } },
    intrinio:         { credField: 'intrinio_api_key',         provider: 'intrinio',         model: 'EquitySearch',            params: { query: 'AAPL', limit: 1 } },
  }

  const app = new Hono()

  // Liveness ping for the settings page's hub status dot. Hits the hub's
  // cheapest parameterless endpoint (fx-rates, Redis-cached hourly) and
  // shape-checks the envelope — mirrors the trust boundary in
  // domain/market-data/reference/hub.ts: hub responses are data, never
  // configuration. `baseUrl` query override lets the UI probe an edited
  // URL before the debounced config save lands.
  app.get('/hub-status', async (c) => {
    const hub = ctx.config.marketData.hub
    const baseUrl = (c.req.query('baseUrl') || hub.baseUrl).replace(/\/+$/, '')
    if (!hub.enabled) return c.json({ enabled: false, baseUrl, reachable: false })
    try {
      const res = await fetch(`${baseUrl}/api/data/fx-rates`, {
        signal: AbortSignal.timeout(3000),
        headers: { accept: 'application/json' },
      })
      if (!res.ok) return c.json({ enabled: true, baseUrl, reachable: false })
      const data: unknown = await res.json().catch(() => null)
      const reachable = typeof data === 'object' && data !== null && 'meta' in data
      return c.json({ enabled: true, baseUrl, reachable })
    } catch {
      return c.json({ enabled: true, baseUrl, reachable: false })
    }
  })

  app.post('/test-provider', async (c) => {
    try {
      const { provider, key } = await c.req.json<{ provider: string; key: string }>()
      const endpoint = TEST_ENDPOINTS[provider]
      if (!endpoint) return c.json({ ok: false, error: `Unknown provider: ${provider}` }, 400)
      if (!key) return c.json({ ok: false, error: 'No API key provided' }, 400)

      const result = await ctx.bbEngine.execute(
        endpoint.provider, endpoint.model, endpoint.params,
        { [endpoint.credField]: key },
      )
      const data = result as unknown[]
      if (data && data.length > 0) return c.json({ ok: true })
      return c.json({ ok: false, error: 'API returned empty data — key may be invalid or endpoint restricted' })
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      return c.json({ ok: false, error: msg })
    }
  })

  return app
}
