/**
 * Workspace-declared ISSUES — one markdown file per issue at
 * `<wsDir>/.alice/issues/<id>.md` inside a workspace's own checkout.
 *
 * This is the keystone data model behind the global Issue board (a Linear-style
 * human+AI surface that aggregates issues across ALL workspaces by SCANNING,
 * never via a central store) AND behind workspace self-scheduling. The two are
 * one object: an issue is a tracked work item; if it additionally carries a
 * `when`, it self-schedules exactly like the old schedule task. An issue WITHOUT
 * `when` is a pure board item — the scanner ignores it.
 *
 * The agent WRITES these files (a coding task; the self-scheduling skill teaches
 * the format) and the launcher READS them live each scan. The agent can edit any
 * file in its checkout, so a read is NEVER trusted: every file is re-validated,
 * size-capped, and isolated — one bad file is reported (not propagated), and one
 * bad workspace can't break the whole scan. Nothing here ever throws.
 *
 * File shape — YAML frontmatter + canonical markdown What:
 *   ---
 *   title: <required, short human title>
 *   status: backlog | todo | in_progress | done | canceled   (optional → 'todo')
 *   priority: urgent | high | medium | low | none             (optional → 'none')
 *   assignee: "@new-each-run" | "@new-then-resume" | "@human" |
 *             "@unassigned" | "@<resumeId>"
 *             (optional → scheduled '@new-then-resume', otherwise '@unassigned')
 *   when: { kind: at, at } | { kind: every, every } |
 *         { kind: cron, cron, timezone?: local | IANA zone }  (OPTIONAL — present iff scheduled)
 *   what: <legacy fire prompt; migrated into the markdown What body>
 *   agent: <optional adapter id for the scheduled run>
 *   credential: <optional OpenAlice vault slug for one scheduled Session>
 *   credentialSource: native <optional explicit Agent-runtime login>
 *   model: <optional native model id for one scheduled run>
 *   effort: none | minimal | low | medium | high | xhigh | max
 *   timeout: 15m | 30m | 45m | 60m  (optional run budget; omit = no watchdog)
 *   commentPrompt: <optional template for the comment-reply Input Prompt>
 *   connectorDesk: telegram   (optional; at most one live desk per connector)
 *   ---
 *   <markdown What — the exact work definition and scheduled prompt>
 *
 * `id` is the filename stem (kebab-case slug), stable; it keys the scanner's
 * last-fired marker for scheduled issues.
 */

import { readFile, readdir, stat } from 'node:fs/promises'
import { join } from 'node:path'

import { parse as parseYaml } from 'yaml'
import { z } from 'zod'

import { isValidScheduleTimezone, type Schedule } from '../../core/schedule-expr.js'
import {
  isModelReasoningEffort,
  type ModelReasoningEffort,
} from '../../ai-providers/model-semantics.js'
import {
  DEPRECATED_NEW_ASSIGNEE,
  DEPRECATED_WORKSPACE_ASSIGNEE,
  HUMAN_ASSIGNEE,
  NEW_EACH_RUN_ASSIGNEE,
  NEW_THEN_RESUME_ASSIGNEE,
  UNASSIGNED_ASSIGNEE,
  resumeIdFromSignature,
} from '../session-signature.js'
import { parseIssueCommentPrompt } from './comment-prompt.js'

/** Directory of per-issue markdown files, relative to a workspace's `dir`. */
export const ISSUES_DIR_REL = join('.alice', 'issues')

/** The retired single-file declaration. Used only to turn a silent "no issues"
 *  into a loud, actionable error when a workspace still has the old file. */
export const LEGACY_ISSUE_FILE_REL = join('.alice', 'issue.json')

/** Hard cap — an agent-authored issue should be tiny; refuse to parse a blob. */
const MAX_BYTES = 64 * 1024

export const ISSUE_STATUSES = ['backlog', 'todo', 'in_progress', 'done', 'canceled'] as const
export const ISSUE_PRIORITIES = ['urgent', 'high', 'medium', 'low', 'none'] as const
/** Optional scheduled-run watchdog. Omission means the agent may run until it exits. */
export const ISSUE_TIMEOUTS = ['15m', '30m', '45m', '60m'] as const
export type IssueStatus = (typeof ISSUE_STATUSES)[number]
export type IssuePriority = (typeof ISSUE_PRIORITIES)[number]
export type IssueTimeout = (typeof ISSUE_TIMEOUTS)[number]

const ISSUE_TIMEOUT_SET: ReadonlySet<string> = new Set(ISSUE_TIMEOUTS)
const ISSUE_TIMEOUT_MS: Record<IssueTimeout, number> = {
  '15m': 15 * 60_000,
  '30m': 30 * 60_000,
  '45m': 45 * 60_000,
  '60m': 60 * 60_000,
}

export function isIssueTimeout(value: unknown): value is IssueTimeout {
  return typeof value === 'string' && ISSUE_TIMEOUT_SET.has(value)
}

/** Convert a declared Issue timeout into the headless watchdog budget.
 *  `undefined` means do not arm a watchdog. */
export function issueTimeoutMs(timeout?: IssueTimeout): number | undefined {
  return timeout === undefined ? undefined : ISSUE_TIMEOUT_MS[timeout]
}

/** Statuses at which a scheduled issue stops firing (it's resolved/abandoned).
 *  This is how a schedule is turned off under the board model — there is no
 *  separate `enabled` flag; mark the issue done/canceled to stop it. */
const TERMINAL_STATUSES: ReadonlySet<IssueStatus> = new Set<IssueStatus>(['done', 'canceled'])
export function isTerminalStatus(status: IssueStatus): boolean {
  return TERMINAL_STATUSES.has(status)
}

/** `when` — the shared Schedule shape (at / every / cron). Present iff scheduled.
 *  Exported so the agent-facing `issue_create` tool reuses the exact same shape
 *  (no parallel re-declaration that could drift from what the reader validates). */
export const issueWhenSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('at'), at: z.string().min(1) }),
  z.object({ kind: z.literal('every'), every: z.string().min(1) }),
  z.object({
    kind: z.literal('cron'),
    cron: z.string().min(1),
    /** Omitted is legacy machine-local time; explicit `local` is recommended
     * for personal reminders, while market clocks should use an IANA zone. */
    timezone: z.string().min(1).refine(isValidScheduleTimezone, 'timezone must be `local` or a valid IANA timezone').optional(),
    /** Omit/`true` retries a missed slot. `false` waits for the next calendar time. */
    catchUp: z.boolean().optional(),
  }),
])

/** Canonical writable assignees. Deprecated aliases live only in the file
 * reader below; every product/API/CLI writer uses this strict schema. */
export const issueAssigneeSchema = z.union([
  z.literal(NEW_EACH_RUN_ASSIGNEE),
  z.literal(NEW_THEN_RESUME_ASSIGNEE),
  z.literal(HUMAN_ASSIGNEE),
  z.literal(UNASSIGNED_ASSIGNEE),
  z.string().regex(/^@resume-[^\s]+$/, 'Session assignee must be @<resumeId>'),
])

/** Deprecated files remain readable, but aliases are deliberately excluded
 * from `issueAssigneeSchema` so no writer can keep producing that vocabulary. */
const issueAssigneeFileSchema = z.union([
  issueAssigneeSchema,
  z.literal(DEPRECATED_WORKSPACE_ASSIGNEE),
  z.literal(DEPRECATED_NEW_ASSIGNEE),
])

/** Exact product Session owner encoded by the single assignee contract. */
export function issueAssigneeResumeId(assignee: string): string | null {
  return resumeIdFromSignature(assignee)
}

/** Transitional ownership: the first dispatch claims one durable Session. */
export function issueAssigneeClaimsFirstSession(assignee: string): boolean {
  return assignee === NEW_THEN_RESUME_ASSIGNEE
}

/**
 * The validated frontmatter of one issue. `id` and `what` are NOT here — `id`
 * comes from the filename, What from below the frontmatter (see IssueRecord).
 * Optional fields carry their board defaults so every read yields a complete row.
 */
const issueFrontmatterObjectSchema = z.object({
  /** Short human title — required; an issue without a title has no board row. */
  title: z.string().min(1),
  status: z.enum(ISSUE_STATUSES).default('todo'),
  priority: z.enum(ISSUE_PRIORITIES).default('none'),
  assignee: issueAssigneeFileSchema.optional(),
  /** Present iff the issue self-schedules. Absent ⇒ pure board work item. */
  when: issueWhenSchema.optional(),
  /** Deprecated read compatibility only. New files keep What in the markdown
   * document below frontmatter so the human-visible work definition and runtime
   * prompt cannot drift. */
  what: z.string().min(1).optional(),
  /** Runtime override for Workspace-owned scheduled work. A Session owner
   * already carries its runtime identity and therefore cannot set this. */
  agent: z.string().min(1).optional(),
  /** Secret-free vault reference frozen into a fresh Session binding. */
  credential: z.string().min(1).optional(),
  /** Explicitly use the Agent runtime's own login for a fresh Session. When
   * omitted with `credential`, the Issue inherits the Workspace headless
   * preference instead. */
  credentialSource: z.literal('native').optional(),
  /** One-run model selection for the selected credential/runtime source. */
  model: z.string().min(1).optional(),
  /** One-run reasoning effort, projected through the selected native CLI. */
  effort: z.custom<ModelReasoningEffort>(isModelReasoningEffort, {
    message: 'effort must be none, minimal, low, medium, high, xhigh, or max',
  }).optional(),
  /** Optional headless watchdog for a scheduled fire. Omission means no limit.
   * This is a run budget, not Session birth, so an exact `@resumeId` may set it. */
  timeout: z.enum(ISSUE_TIMEOUTS).optional(),
  /** Optional template for the comment-reply Input Prompt. Omission keeps the
   *  historical wrapper. Must include `{comment}`. */
  commentPrompt: z.string().min(1).optional(),
  /** Adapter id of the connector that owns this phone-desk Issue.
   *  Omission is a normal Issue. At most one live desk per connector. */
  connectorDesk: z.string().regex(/^[a-z][a-z0-9-]*$/, 'connectorDesk must be a connector id').max(64).optional(),
  /** Dual-read of the 0.89.4-beta Telegram-only flag. Transformed to connectorDesk. */
  telegramConnector: z.literal(true).optional(),
  /** The former parallel ownership field is outside the baseline. Keeping a
   * `never` key makes stale files fail loudly instead of being silently read. */
  execution: z.never().optional(),
})

export const issueFrontmatterSchema = issueFrontmatterObjectSchema
  .superRefine((value, ctx) => {
    if (value.telegramConnector && value.connectorDesk && value.connectorDesk !== 'telegram') {
      ctx.addIssue({
        code: 'custom',
        path: ['connectorDesk'],
        message: 'telegramConnector cannot combine with a different connectorDesk',
      })
    }
  })
  .transform((value) => {
    const { telegramConnector: _legacyDesk, ...rest } = value
    const connectorDesk = rest.connectorDesk ?? (value.telegramConnector ? 'telegram' : undefined)
    return {
      ...rest,
      ...(connectorDesk ? { connectorDesk } : {}),
      assignee:
        value.assignee === DEPRECATED_WORKSPACE_ASSIGNEE
          ? value.when ? NEW_EACH_RUN_ASSIGNEE : UNASSIGNED_ASSIGNEE
          : value.assignee === DEPRECATED_NEW_ASSIGNEE
            ? NEW_THEN_RESUME_ASSIGNEE
            : value.assignee ?? (value.when ? NEW_THEN_RESUME_ASSIGNEE : UNASSIGNED_ASSIGNEE),
    }
  })
  .superRefine((value, ctx) => {
    if (value.credential && value.credentialSource) {
      ctx.addIssue({
        code: 'custom',
        path: ['credentialSource'],
        message: 'credential and credentialSource are mutually exclusive',
      })
    }
    if (value.when && (value.assignee === HUMAN_ASSIGNEE || value.assignee === UNASSIGNED_ASSIGNEE)) {
      ctx.addIssue({
        code: 'custom',
        path: ['assignee'],
        message: 'scheduled issues must use @new-each-run, @new-then-resume, or an exact @resumeId',
      })
    }
    if (!value.when && (
      value.assignee === NEW_EACH_RUN_ASSIGNEE
      || value.assignee === NEW_THEN_RESUME_ASSIGNEE
    )) {
      ctx.addIssue({
        code: 'custom',
        path: ['assignee'],
        message: `${value.assignee} needs a schedule`,
      })
    }
    if (issueAssigneeResumeId(value.assignee)) {
      for (const field of ['agent', 'credential', 'credentialSource', 'model', 'effort'] as const) {
        if (!value[field]) continue
        ctx.addIssue({
          code: 'custom',
          path: [field],
          message: `session assignee owns its runtime; remove the ${field} override`,
        })
      }
    }
    if (value.commentPrompt !== undefined) {
      const parsed = parseIssueCommentPrompt(value.commentPrompt)
      if (!parsed.ok) {
        ctx.addIssue({
          code: 'custom',
          path: ['commentPrompt'],
          message: parsed.error,
        })
      }
    }
  })
type IssueFrontmatterFile = z.infer<typeof issueFrontmatterSchema>
export type IssueFrontmatter = Omit<IssueFrontmatterFile, 'what' | 'execution'>

/** A fully read issue: validated frontmatter + filename id + markdown What. */
export interface IssueRecord extends IssueFrontmatter {
  /** Filename stem (kebab-case slug) — stable; keys the scanner's marker. */
  id: string
  /** Markdown work definition below frontmatter. For a scheduled Issue this is
   * the exact prompt sent to the Agent Runtime. */
  what: string
}

/** A file that could not be read/validated — reported, never propagated. */
export interface InvalidIssue {
  /** Filename stem of the offending file. */
  id: string
  error: string
}

export type ReadIssuesResult =
  | { ok: true; issues: IssueRecord[]; invalid: InvalidIssue[] }
  | { ok: false; reason: 'absent' }
  | { ok: false; reason: 'invalid'; error: string }

/** Does an issue self-schedule AND is it still live (non-terminal)? */
export function isFireable(issue: IssueRecord): issue is IssueRecord & { when: Schedule } {
  return issue.when !== undefined && !isTerminalStatus(issue.status)
}

export function isConnectorDeskIssue(
  issue: Pick<IssueRecord, 'connectorDesk'>,
): issue is Pick<IssueRecord, 'connectorDesk'> & { connectorDesk: string } {
  return typeof issue.connectorDesk === 'string' && issue.connectorDesk.length > 0
}

/** @deprecated Use {@link isConnectorDeskIssue}. */
export function isTelegramConnectorIssue(
  issue: Pick<IssueRecord, 'connectorDesk'>,
): issue is Pick<IssueRecord, 'connectorDesk'> & { connectorDesk: string } {
  return issue.connectorDesk === 'telegram'
}

/** Same-workspace extras after the first id for each connector (sorted). */
export function extraConnectorDeskIssueIds(issues: readonly IssueRecord[]): Set<string> {
  const extras = new Set<string>()
  const seen = new Map<string, string>()
  for (const issue of [...issues].sort((left, right) => left.id.localeCompare(right.id))) {
    if (!isConnectorDeskIssue(issue)) continue
    const first = seen.get(issue.connectorDesk)
    if (first) extras.add(issue.id)
    else seen.set(issue.connectorDesk, issue.id)
  }
  return extras
}

/** @deprecated Use {@link extraConnectorDeskIssueIds}. */
export function extraTelegramConnectorIssueIds(issues: readonly IssueRecord[]): Set<string> {
  return extraConnectorDeskIssueIds(issues)
}

/** The prompt a scheduled fire hands to the headless run. `what` is already the
 * canonical, human-visible markdown work definition; there is no second hidden
 * prompt field for it to disagree with. */
export function issueFirePrompt(issue: IssueRecord): string {
  return issue.what
}

/**
 * Read + validate every issue in a workspace's `.alice/issues/` directory from
 * its live working tree. Never throws. Per-file isolation: a bad file lands in
 * `invalid` and the rest still load. The legacy single-file declaration is
 * surfaced as a loud, actionable error rather than a silent "no issues".
 */
export async function readWorkspaceIssues(wsDir: string): Promise<ReadIssuesResult> {
  const dir = join(wsDir, ISSUES_DIR_REL)

  let entries: string[]
  try {
    entries = await readdir(dir)
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
      // Loud over silent: a workspace still carrying the retired single file gets
      // an actionable rename hint, not a bland "no issues" that hides the file.
      try {
        await stat(join(wsDir, LEGACY_ISSUE_FILE_REL))
        return {
          ok: false,
          reason: 'invalid',
          error:
            '`.alice/issue.json` is retired — split each issue into its own `.alice/issues/<id>.md` (one markdown file per issue, see the self-scheduling skill)',
        }
      } catch {
        return { ok: false, reason: 'absent' }
      }
    }
    return { ok: false, reason: 'invalid', error: err instanceof Error ? err.message : String(err) }
  }

  const files = entries.filter((f) => f.toLowerCase().endsWith('.md')).sort()
  const issues: IssueRecord[] = []
  const invalid: InvalidIssue[] = []
  for (const file of files) {
    const id = file.slice(0, -'.md'.length)
    const one = await readOneIssue(join(dir, file), id)
    if (one.ok) issues.push(one.issue)
    else invalid.push({ id, error: one.error })
  }
  const extras = extraConnectorDeskIssueIds(issues)
  if (extras.size > 0) {
    const kept: IssueRecord[] = []
    for (const issue of issues) {
      if (extras.has(issue.id)) {
        invalid.push({
          id: issue.id,
          error: `connectorDesk: only one ${issue.connectorDesk} phone-desk Issue is allowed in this Alice Project`,
        })
      } else {
        kept.push(issue)
      }
    }
    issues.length = 0
    issues.push(...kept)
  }
  return { ok: true, issues, invalid }
}

async function readOneIssue(
  path: string,
  id: string,
): Promise<{ ok: true; issue: IssueRecord } | { ok: false; error: string }> {
  let raw: string
  try {
    const info = await stat(path)
    if (info.size > MAX_BYTES) return { ok: false, error: `issue file too large (${info.size} bytes)` }
    raw = await readFile(path, 'utf8')
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }

  return parseIssueContent(id, raw)
}

/**
 * Pure parse of one issue's file content (frontmatter + markdown What) into a validated
 * IssueRecord — no disk IO, no size cap. The shared validation seam: the reader
 * (`readOneIssue`) calls it after the file read + size check, and the mutation
 * helper (`./mutate.ts`) calls it to re-validate the content it just wrote so
 * both paths agree on the exact schema + error shape. Never throws.
 */
export function parseIssueContent(
  id: string,
  raw: string,
): { ok: true; issue: IssueRecord } | { ok: false; error: string } {
  const split = splitFrontmatter(raw)
  if (!split) return { ok: false, error: 'missing YAML frontmatter (expected a leading `---` block)' }

  let data: unknown
  try {
    data = parseYaml(split.frontmatter)
  } catch (err) {
    return { ok: false, error: `invalid YAML frontmatter: ${err instanceof Error ? err.message : String(err)}` }
  }
  if (data === null || typeof data !== 'object' || Array.isArray(data)) {
    return { ok: false, error: 'frontmatter is not a mapping' }
  }
  const parsed = issueFrontmatterSchema.safeParse(data)
  if (!parsed.success) {
    return { ok: false, error: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') }
  }

  const { what: legacyWhat, execution: _retiredExecution, ...frontmatter } = parsed.data
  const document = splitLegacyIssueDocument(split.body)
  return {
    ok: true,
    issue: {
      id,
      ...frontmatter,
      what: mergeLegacyWhat(legacyWhat, document.what, frontmatter.title),
    },
  }
}

/**
 * Before comments moved to `<id>.comments.json`, the mutation helper appended
 * them under a reserved `## Comments` heading in the Issue markdown. Keep this
 * small compatibility splitter until every live Workspace has crossed migration
 * 0017: legacy comments must never leak into the scheduled prompt.
 */
export function splitLegacyIssueDocument(body: string): { what: string; legacyComments: string } {
  const lines = body.split(/\r?\n/)
  const index = lines.findIndex((line) => /^##\s+Comments\s*$/.test(line.trim()))
  if (index < 0) return { what: body.trim(), legacyComments: '' }
  return {
    what: lines.slice(0, index).join('\n').trim(),
    legacyComments: lines.slice(index + 1).join('\n').trim(),
  }
}

/** Merge the two historical work-definition locations without dropping either.
 * The old frontmatter `what` remains the primary instruction; a distinct body
 * becomes explicit Context. Empty legacy Issues materialize their title so the
 * UI and runtime still agree on the exact prompt. */
export function mergeLegacyWhat(legacyWhat: string | undefined, markdownWhat: string, title: string): string {
  const explicit = legacyWhat?.trim() ?? ''
  const markdown = markdownWhat.trim()
  if (explicit && markdown && explicit !== markdown) return `${explicit}\n\n## Context\n\n${markdown}`
  return explicit || markdown || title.trim()
}

/** Split a `---\n<yaml>\n---\n<body>` document. Line-based so a `---` inside the
 *  body (e.g. a markdown horizontal rule) never confuses the close fence. Returns
 *  null when there is no leading frontmatter block. */
export function splitFrontmatter(raw: string): { frontmatter: string; body: string } | null {
  const text = raw.replace(/^\uFEFF/, '')
  const lines = text.split(/\r?\n/)
  if (lines[0]?.trim() !== '---') return null
  let end = -1
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].trim() === '---') {
      end = i
      break
    }
  }
  if (end === -1) return null
  return {
    frontmatter: lines.slice(1, end).join('\n'),
    body: lines.slice(end + 1).join('\n').trim(),
  }
}
