import { describe, expect, it } from 'vitest';

import {
  classifyRuntimeReadinessFailure,
  failedRuntimeReadinessRow,
  runtimeProbeSucceeded,
  snapshotRuntimeReadiness,
  type AgentRuntimeReadinessRow,
} from './agent-runtime-readiness.js';
import { emptyAgentSessionRuntime, type CliAdapter } from './cli-adapter.js';
import type { HeadlessTaskResult } from './headless-task.js';

const piAdapter: CliAdapter = {
  id: 'pi',
  displayName: 'Pi',
  sessionRuntime: emptyAgentSessionRuntime,
  kind: 'agent',
  binary: 'pi',
  capabilities: {
    parallelPerCwd: true,
    resumeLast: false,
    resumeById: true,
    transcriptDiscovery: 'none',
    headless: true,
    aiProvider: {
      credentialSource: 'runtime-or-workspace',
      wirePreference: ['openai-chat'],
    },
  },
  composeCommand: () => ['pi'],
  composeHeadlessCommand: () => ['pi', '-p', 'hi'],
};

function result(overrides: Partial<HeadlessTaskResult>): HeadlessTaskResult {
  return {
    command: ['agent'],
    cwd: '/tmp/openalice-runtime-probe',
    exitCode: 1,
    signal: null,
    killed: false,
    durationMs: 12,
    stdoutTail: '',
    stderrTail: '',
    agentSessionId: null,
    assistantText: null,
    structured: {
      schemaVersion: 1,
      assistantText: null,
      blocks: [],
      metrics: { textBlocks: 0, toolCalls: 0, toolFailures: 0 },
      truncated: false,
    },
    ...overrides,
  };
}

describe('agent runtime readiness helpers', () => {
  it('classifies timeout, auth, provider, and generic failures', () => {
    expect(classifyRuntimeReadinessFailure(result({ killed: true }))).toBe('timeout');
    expect(
      classifyRuntimeReadinessFailure(result({ stderrTail: '401 unauthorized: login required' })),
    ).toBe('auth_required');
    expect(
      classifyRuntimeReadinessFailure(result({ stderrTail: 'missing API key provider config' })),
    ).toBe('provider_required');
    expect(
      classifyRuntimeReadinessFailure(result({
        stderrTail: 'WARN plugin config ignored; model gpt-next is unsupported by this CLI version',
      })),
    ).toBe('failed');
    expect(classifyRuntimeReadinessFailure(result({ stderrTail: 'boom' }))).toBe('failed');
  });

  it('routes missing native provider state to CLI login for a login-capable runtime', () => {
    expect(failedRuntimeReadinessRow({
      adapter: piAdapter,
      availability: { installed: true, path: '/usr/bin/pi' },
      result: result({ stderrTail: 'missing API key provider config' }),
      source: 'global-login',
    })).toMatchObject({
      status: 'provider_required',
      repairTarget: 'cli-login',
    });
  });

  it('requires a clean exit with a decoded assistant reply to count as ready', () => {
    expect(runtimeProbeSucceeded(result({ exitCode: 0, assistantText: 'Hello!' }))).toBe(true);
    expect(runtimeProbeSucceeded(result({ exitCode: 0, stdoutTail: '{"type":"system"}' }))).toBe(false);
    expect(runtimeProbeSucceeded(result({ exitCode: 1, assistantText: 'Hello!' }))).toBe(false);
  });

  it('distinguishes clean output OpenAlice cannot decode from a real reply', () => {
    expect(classifyRuntimeReadinessFailure(result({
      exitCode: 0,
      stdoutTail: '{"type":"future_event","message":"started"}',
    }))).toBe('output_unrecognized');
  });

  it('preserves an in-band provider error instead of calling it unrecognized output', () => {
    const providerError = result({
      exitCode: 0,
      stdoutTail: '{"type":"message_end","message":{"stopReason":"error"}}',
      structured: {
        schemaVersion: 1,
        assistantText: null,
        blocks: [{
          type: 'error',
          message: '429: 余额不足或无可用资源包，请充值。',
        }],
        metrics: { textBlocks: 0, toolCalls: 0, toolFailures: 0 },
        truncated: false,
      },
    });

    expect(classifyRuntimeReadinessFailure(providerError)).toBe('failed');
    expect(failedRuntimeReadinessRow({
      adapter: piAdapter,
      availability: { installed: true, path: '/usr/bin/pi' },
      result: providerError,
      source: 'launcher-vault',
    })).toMatchObject({
      status: 'failed',
      ready: false,
      repairTarget: 'retry',
      message: 'The runtime reported an error: 429: 余额不足或无可用资源包，请充值。',
    });
  });

  it('GET snapshot uses cached rows without inventing readiness', () => {
    const cache = new Map<string, AgentRuntimeReadinessRow>();
    const unknown = snapshotRuntimeReadiness(
      [piAdapter],
      { pi: { installed: true, path: '/usr/bin/pi' } },
      cache,
    );

    expect(unknown.overallReady).toBe(false);
    expect(unknown.agents.pi?.status).toBe('unknown');

    cache.set('pi', {
      agent: 'pi',
      displayName: 'Pi',
      installed: true,
      binPath: '/usr/bin/pi',
      status: 'ready',
      ready: true,
      source: 'global-config',
      checkedAt: '2026-07-08T00:00:00.000Z',
      durationMs: 25,
    });

    const ready = snapshotRuntimeReadiness(
      [piAdapter],
      { pi: { installed: true, path: '/usr/bin/pi' } },
      cache,
    );

    expect(ready.overallReady).toBe(true);
    expect(ready.checkedAt).toBe('2026-07-08T00:00:00.000Z');
    expect(ready.agents.pi?.source).toBe('global-config');
  });
});
