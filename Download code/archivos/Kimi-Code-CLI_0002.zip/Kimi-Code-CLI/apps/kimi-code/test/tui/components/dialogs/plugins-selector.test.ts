import { describe, expect, it, vi } from 'vitest';
import chalk from 'chalk';
import type { CapabilityStatus, PluginSummary } from '@moonshot-ai/kimi-code-sdk';

import {
  PluginInstallTrustConfirmComponent,
  PluginMcpSelectorComponent,
  PluginRemoveConfirmComponent,
  PluginsPanelComponent,
  type PluginInstallTrustConfirmResult,
  type PluginMcpSelection,
  type PluginRemoveConfirmResult,
  type PluginsPanelSelection,
} from '#/tui/components/dialogs/plugins-selector';
import { currentTheme } from '#/tui/theme';
import { darkColors, lightColors } from '#/tui/theme/colors';
import { isOfficialPluginInstall, isOfficialPluginSource, pluginTrustLabel } from '#/tui/utils/plugin-source-label';

const ANSI_SGR = /\u001B\[[0-9;]*m/g;

function strip(text: string): string {
  return text.replaceAll(ANSI_SGR, '').replaceAll('\u276F', '?');
}

function withAnsiColors<T>(fn: () => T): T {
  const previousChalkLevel = chalk.level;
  chalk.level = 3;
  try {
    return fn();
  } finally {
    chalk.level = previousChalkLevel;
  }
}

function renderRaw(component: { render(width: number): string[] }, width = 120): string {
  return withAnsiColors(() => component.render(width).join('\n'));
}

function dangerShortcut(text: string): string {
  return withAnsiColors(() => chalk.hex(darkColors.error).bold(text));
}

function warningMark(): string {
  // Opening ANSI escape for the warning color; the install-trust notice is the
  // only element in that dialog using it, so its presence confirms the tone.
  return withAnsiColors(() => chalk.hex(darkColors.warning)('\u0001').split('\u0001')[0]!);
}

const superpowers = {
  id: 'superpowers',
  displayName: 'Superpowers',
  version: '5.1.0',
  enabled: true,
  state: 'ok' as const,
  skillCount: 14,
  mcpServerCount: 0,
  enabledMcpServerCount: 0,
  hookCount: 0,
  commandCount: 0,
  hasErrors: false,
  source: 'local-path' as const,
};

const officialEntries = [
  {
    id: 'kimi-datasource',
    tier: 'official' as const,
    displayName: 'Kimi Datasource',
    description: 'Query supported data sources',
    version: '3.1.1',
    source: 'https://x/d.zip',
    keywords: ['data'],
  },
];
const thirdPartyEntries = [
  { id: 'superpowers', tier: 'curated' as const, displayName: 'Superpowers', source: 'https://x/s.zip' },
];
const marketplaceEntries = [...officialEntries, ...thirdPartyEntries];

function makePanel(opts: {
  installed?: readonly PluginSummary[];
  capabilities?: readonly CapabilityStatus[];
  catalogIsDefault?: boolean;
  initialTab?: 'installed' | 'official' | 'third-party' | 'custom';
  selectedId?: string;
  pluginHint?: { id: string; text: string };
}) {
  const installed = opts.installed ?? [];
  const onSelect = vi.fn<(s: PluginsPanelSelection) => void>();
  const onRequestMarketplace = vi.fn();
  const panel = new PluginsPanelComponent({
    installed,
    installedIds: new Set(installed.map((p) => p.id)),
    capabilities: opts.capabilities,
    catalogIsDefault: opts.catalogIsDefault,
    initialTab: opts.initialTab,
    selectedId: opts.selectedId,
    pluginHint: opts.pluginHint,
    onSelect,
    onCancel: vi.fn(),
    onRequestMarketplace,
  });
  return { panel, onSelect, onRequestMarketplace };
}

function makeCapability(overrides: Partial<CapabilityStatus> = {}): CapabilityStatus {
  return {
    id: 'kimi-cu',
    displayName: 'Kimi Computer Use',
    description: 'Background GUI automation',
    supported: true,
    state: 'partial',
    steps: [
      { id: 'plugin', state: 'ok' },
      { id: 'app', state: 'ok' },
      { id: 'service', state: 'ok' },
      { id: 'permissions', state: 'missing', detail: 'screenRecording' },
    ],
    install: { running: false },
    ...overrides,
  };
}

describe('plugins selector dialogs', () => {
  it('trusts only built-in Kimi CDN plugin paths', () => {
    expect(pluginTrustLabel({
      id: 'kimi-datasource',
      displayName: 'Kimi Datasource',
      enabled: true,
      state: 'ok',
      skillCount: 0,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
      source: 'zip-url',
      originalSource: 'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
    })).toBe('official');
    expect(pluginTrustLabel({
      id: 'superpowers',
      displayName: 'Superpowers',
      enabled: true,
      state: 'ok',
      skillCount: 0,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
      source: 'zip-url',
      originalSource: 'https://code.kimi.com/kimi-code/plugins/curated/superpowers.zip',
    })).toBe('curated');
    expect(pluginTrustLabel({
      id: 'kimi-cu',
      displayName: 'Kimi Computer Use',
      enabled: true,
      state: 'ok',
      skillCount: 1,
      mcpServerCount: 1,
      enabledMcpServerCount: 1,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
      source: 'zip-url',
      originalSource: 'https://cdn.kimi.com/kimi-computer-use/latest/kimi-cu-plugin.zip',
    })).toBe('official');
    expect(pluginTrustLabel({
      id: 'demo',
      displayName: 'Demo',
      enabled: true,
      state: 'ok',
      skillCount: 0,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
      source: 'zip-url',
      originalSource: 'https://code.kimi.com/demo.zip',
    })).toBe('third-party');
    expect(pluginTrustLabel({
      id: 'local',
      displayName: 'Local',
      enabled: true,
      state: 'ok',
      skillCount: 0,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
      source: 'local-path',
      originalSource: 'https://code.kimi.com/kimi-code/plugins/official/local',
    })).toBe('third-party');
  });

  it('trusts the .ai Kimi plugin hosts with the same path rules', () => {
    const labelFor = (originalSource: string) =>
      pluginTrustLabel({
        id: 'demo',
        displayName: 'Demo',
        enabled: true,
        state: 'ok',
        skillCount: 0,
        mcpServerCount: 0,
        enabledMcpServerCount: 0,
        hookCount: 0,
        commandCount: 0,
        hasErrors: false,
        source: 'zip-url',
        originalSource,
      });
    // code.kimi.ai mirrors the cdnBase rules; cdn.kimi.ai the content-CDN ones.
    expect(labelFor('https://code.kimi.ai/kimi-code/plugins/official/kimi-datasource.zip')).toBe('official');
    expect(labelFor('https://code.kimi.ai/kimi-code/plugins/curated/superpowers.zip')).toBe('curated');
    expect(labelFor('https://cdn.kimi.ai/kimi-computer-use/latest/kimi-cu-plugin.zip')).toBe('official');
    expect(labelFor('https://cdn.kimi.ai/kimi-computer-use-windows/latest/kimi-cu-win-plugin.zip')).toBe('official');
    // Non-plugin paths on the .ai hosts, and lookalike hosts, stay third-party.
    expect(labelFor('https://code.kimi.ai/demo.zip')).toBe('third-party');
    expect(labelFor('https://cdn.kimi.ai/unrelated/plugin.zip')).toBe('third-party');
    expect(labelFor('https://code.kimi.ai.example.test/kimi-code/plugins/official/x.zip')).toBe('third-party');
  });

  it('recognizes installed plugins by official provenance', () => {
    const base = {
      id: 'kimi-datasource',
      displayName: 'Kimi Datasource',
      enabled: true,
      state: 'ok' as const,
      skillCount: 0,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hookCount: 0,
      commandCount: 0,
      hasErrors: false,
    };
    // Zip installs from the official CDN path.
    expect(isOfficialPluginInstall({
      ...base,
      source: 'zip-url',
      originalSource: 'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
    })).toBe(true);
    expect(isOfficialPluginInstall({
      ...base,
      source: 'zip-url',
      originalSource: 'https://code.kimi.ai/kimi-code/plugins/official/kimi-datasource.zip',
    })).toBe(true);
    expect(isOfficialPluginInstall({
      ...base,
      id: 'kimi-cu',
      displayName: 'Kimi Computer Use',
      source: 'zip-url',
      originalSource: 'https://cdn.kimi.com/kimi-computer-use/latest/kimi-cu-plugin.zip',
    })).toBe(true);
    // Same manifest id from a local path, GitHub, a loopback URL, or a
    // third-party URL is not the official build.
    expect(isOfficialPluginInstall({ ...base, source: 'local-path' })).toBe(false);
    expect(isOfficialPluginInstall({ ...base, source: 'github' })).toBe(false);
    expect(isOfficialPluginInstall({
      ...base,
      source: 'zip-url',
      originalSource: 'http://127.0.0.1:58627/kimi-code/plugins/official/kimi-datasource.zip',
    })).toBe(false);
    expect(isOfficialPluginInstall({
      ...base,
      source: 'zip-url',
      originalSource: 'https://example.test/kimi-code/plugins/official/kimi-datasource.zip',
    })).toBe(false);
  });

  it('shows installed Kimi Computer Use and WebBridge plugins as official', () => {
    const installed: PluginSummary[] = [
      {
        ...superpowers,
        id: 'kimi-cu',
        displayName: 'Kimi Computer Use',
        source: 'zip-url',
        originalSource: 'https://cdn.kimi.com/kimi-computer-use/latest/kimi-cu-plugin.zip',
      },
      {
        ...superpowers,
        id: 'kimi-webbridge',
        displayName: 'Kimi WebBridge',
        source: 'zip-url',
        originalSource: 'https://code.kimi.com/kimi-code/plugins/official/kimi-webbridge.zip',
      },
    ];

    const { panel } = makePanel({ installed });
    const out = strip(renderRaw(panel));

    expect(out).toContain('id kimi-cu');
    expect(out).toContain('via cdn.kimi.com · official');
    expect(out).toContain('id kimi-webbridge');
    expect(out).toContain('via code.kimi.com · official');
  });

  it('treats only the official Kimi CDN path as a trusted install source', () => {
    expect(isOfficialPluginSource('https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip')).toBe(true);
    expect(isOfficialPluginSource('https://cdn.kimi.com/kimi-computer-use/latest/kimi-cu-plugin.zip')).toBe(true);
    expect(
      isOfficialPluginSource(
        'https://cdn.kimi.com/kimi-computer-use-windows/latest/kimi-cu-win-plugin.zip',
      ),
    ).toBe(true);
    // The .ai region family follows the same path rules.
    expect(isOfficialPluginSource('https://code.kimi.ai/kimi-code/plugins/official/kimi-datasource.zip')).toBe(true);
    expect(isOfficialPluginSource('https://cdn.kimi.ai/kimi-computer-use/latest/kimi-cu-plugin.zip')).toBe(true);
    expect(
      isOfficialPluginSource(
        'https://cdn.kimi.ai/kimi-computer-use-windows/latest/kimi-cu-win-plugin.zip',
      ),
    ).toBe(true);
    expect(isOfficialPluginSource('https://code.kimi.ai/kimi-code/plugins/curated/superpowers.zip')).toBe(false);
    expect(isOfficialPluginSource('https://cdn.kimi.ai/unrelated/plugin.zip')).toBe(false);
    // Curated and other Kimi CDN paths are not "official" for the install gate.
    expect(isOfficialPluginSource('https://code.kimi.com/kimi-code/plugins/curated/superpowers.zip')).toBe(false);
    expect(isOfficialPluginSource('https://code.kimi.com/kimi-code/plugins/foo.zip')).toBe(false);
    expect(isOfficialPluginSource('https://cdn.kimi.com/unrelated/plugin.zip')).toBe(false);
    // Non-Kimi hosts (loopback included), non-https schemes, local paths, and
    // GitHub sources are unofficial.
    expect(isOfficialPluginSource('https://example.test/kimi-code/plugins/official/x.zip')).toBe(false);
    expect(isOfficialPluginSource('http://code.kimi.com/kimi-code/plugins/official/x.zip')).toBe(false);
    expect(isOfficialPluginSource('http://127.0.0.1:58627/kimi-code/plugins/official/x.zip')).toBe(false);
    expect(isOfficialPluginSource('./plugins/kimi-datasource')).toBe(false);
    expect(isOfficialPluginSource('/abs/path/to/plugin')).toBe(false);
    expect(isOfficialPluginSource('github.com/owner/repo')).toBe(false);
    expect(isOfficialPluginSource('not a url')).toBe(false);
  });

  it('opens on the Installed tab with the four panel tabs', () => {
    const { panel } = makePanel({ installed: [superpowers] });
    const out = strip(renderRaw(panel));
    expect(out).toContain('Plugins');
    expect(out).toContain('Installed');
    expect(out).toContain('Official');
    expect(out).toContain('Curated');
    expect(out).toContain('Custom');
    expect(out).toContain('? Superpowers  enabled');
    expect(out).toContain('Space toggle');
    expect(out).toContain('1 installed');
  });

  it('repaints from the current theme palette without remounting', () => {
    const { panel } = makePanel({ installed: [superpowers] });
    const previous = currentTheme.palette;
    try {
      currentTheme.setPalette(darkColors);
      const darkOut = renderRaw(panel);
      currentTheme.setPalette(lightColors);
      const lightOut = renderRaw(panel);
      // A palette snapshot cached at construction would render identically
      // after the switch; reading currentTheme.palette at render time must
      // produce different ANSI output for the same panel instance.
      expect(darkOut).not.toBe(lightOut);
    } finally {
      currentTheme.setPalette(previous);
    }
  });

  it('toggles an installed plugin with Space', () => {
    const { panel, onSelect } = makePanel({ installed: [superpowers] });
    panel.handleInput(' ');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'toggle', id: 'superpowers', enabled: false });
  });

  it('routes D / M / R / Enter to remove / mcp / reload / details on the Installed tab', () => {
    const { panel, onSelect } = makePanel({ installed: [superpowers] });
    panel.handleInput('d');
    panel.handleInput('m');
    panel.handleInput('r');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'remove', id: 'superpowers' });
    expect(onSelect).toHaveBeenCalledWith({ kind: 'mcp', id: 'superpowers' });
    expect(onSelect).toHaveBeenCalledWith({ kind: 'reload' });
    expect(onSelect).toHaveBeenCalledWith({ kind: 'details', id: 'superpowers' });
  });

  it('Enter on an installed plugin with an available update installs it', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '4.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel, onSelect } = makePanel({ installed });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'superpowers' }),
    });
  });

  it('Enter on an up-to-date installed plugin opens details', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '5.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel, onSelect } = makePanel({ installed });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'details', id: 'superpowers' });
  });

  it('I on an installed plugin opens details even when an update is available', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '4.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel, onSelect } = makePanel({ installed });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    panel.handleInput('i');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'details', id: 'superpowers' });
  });

  it('renders the inline plugin hint on the installed row', () => {
    const datasource = { ...superpowers, id: 'kimi-datasource', displayName: 'Kimi Datasource', skillCount: 1 };
    const { panel } = makePanel({
      installed: [datasource],
      selectedId: 'kimi-datasource',
      pluginHint: { id: 'kimi-datasource', text: 'pending /new' },
    });
    const out = strip(renderRaw(panel));
    expect(out).toContain('? Kimi Datasource  enabled  pending /new');
  });

  it('lazily loads the Official catalog, then lists installed entries first', () => {
    const { panel, onRequestMarketplace } = makePanel({ installed: [superpowers] });
    panel.handleInput('\t'); // → Official
    expect(onRequestMarketplace).toHaveBeenCalledTimes(1);
    expect(strip(renderRaw(panel))).toContain('Loading marketplace');

    panel.setMarketplace(marketplaceEntries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi Datasource  install');
    expect(out).toContain('Query supported data sources');
    expect(out).not.toContain('Query supported data sources · v3.1.1');
    expect(out).not.toContain('id kimi-datasource');
    expect(out).not.toContain('Official plugin');
    expect(out).not.toContain('· data');
    expect(out).toContain('0 installed · 1 available');
  });

  it('renders the hardcoded Web Bridge entry on the Official tab while loading', () => {
    const { panel } = makePanel({ initialTab: 'official' });
    // The catalog is still loading, but the built-in Web Bridge entry is shown
    // immediately because it is baked into the TUI, not fetched.
    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi WebBridge  open in browser');
    expect(out).toContain('Loading marketplace');
  });

  it('keeps the Web Bridge entry visible when the Official catalog errors', () => {
    const { panel } = makePanel({ initialTab: 'official' });
    panel.setMarketplaceError('fetch failed');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi WebBridge  open in browser');
    expect(out).toContain('Marketplace unavailable: fetch failed');
  });

  it('renders a same-id custom catalog row as a normal plugin, without capability state', () => {
    // A custom marketplace may legitimately list an entry reusing the
    // kimi-webbridge id: without the capability: marker it must render and
    // install as a plain plugin, not borrow capability status.
    const capabilities = [makeCapability({ id: 'kimi-webbridge', displayName: 'Kimi WebBridge' })];
    const entries = [
      {
        id: 'kimi-webbridge',
        tier: 'official' as const,
        displayName: 'Kimi WebBridge (fork)',
        source: 'https://x/fork.zip',
      },
    ];
    const { panel, onSelect } = makePanel({ initialTab: 'official', capabilities });
    panel.setMarketplace(entries, '/tmp/marketplace.json');

    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi WebBridge (fork)  install');

    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-webbridge', source: 'https://x/fork.zip' }),
    });
  });

  it('renders capability rows from the engine while the catalog is still loading', () => {
    const capabilities = [
      makeCapability(),
      makeCapability({
        id: 'kimi-webbridge',
        displayName: 'Kimi WebBridge',
        state: 'not_installed',
        steps: [],
      }),
    ];
    const { panel, onSelect } = makePanel({ initialTab: 'official', capabilities });

    // No setMarketplace yet — built-in runtime setup must not wait on the
    // remote catalog: the engine-known rows render (and the promo is
    // suppressed by the real webbridge row).
    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi Computer Use  install');
    expect(out).toContain('Kimi WebBridge  install');
    expect(out).toContain('Background GUI automation');
    expect(out).not.toContain('id kimi-cu');
    expect(out).not.toContain('Official plugin');
    expect(out).not.toContain('open in browser');
    expect(out).toContain('Loading marketplace');

    panel.handleInput('\r'); // index 0 → kimi-cu routes to capability install
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-cu', source: 'capability:kimi-cu' }),
    });
    panel.handleInput('[B');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-webbridge', source: 'capability:kimi-webbridge' }),
    });
  });

  it('keeps built-in rows out while the overridden marketplace is loading', () => {
    // /plugins marketplace <url> or the env override must be able to fully
    // replace the Official tab — fallback capability rows stay out too.
    const capabilities = [makeCapability()];
    const { panel } = makePanel({ initialTab: 'official', capabilities, catalogIsDefault: false });

    const out = strip(renderRaw(panel));
    expect(out).not.toContain('Kimi Computer Use');
    expect(out).toContain('Kimi WebBridge  open in browser');
    expect(out).toContain('Loading marketplace');
  });

  it('opens the Web Bridge webpage on Enter instead of installing', () => {
    const { panel, onSelect } = makePanel({ initialTab: 'official' });
    panel.setMarketplace(marketplaceEntries, '/tmp/marketplace.json');
    // Web Bridge is pinned at index 0, so Enter selects it directly.
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'open-url',
      url: 'https://www.kimi.com/features/webbridge#local-agent',
      label: 'Kimi WebBridge',
    });
  });

  it('installs a catalog official entry after navigating past Web Bridge', () => {
    const { panel, onSelect } = makePanel({ initialTab: 'official' });
    panel.setMarketplace(marketplaceEntries, '/tmp/marketplace.json');
    panel.handleInput('\u001B[B'); // ↓ → kimi-datasource
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-datasource' }),
    });
  });

  it('lets the real catalog entry win over the pinned Web Bridge promo', () => {
    const entries = [
      {
        id: 'kimi-webbridge',
        tier: 'official' as const,
        displayName: 'Kimi WebBridge',
        source: 'capability:kimi-webbridge',
      },
      ...officialEntries,
    ];
    const { panel, onSelect } = makePanel({ initialTab: 'official' });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    // Exactly one row, and it is the installable catalog copy — the hardcoded
    // open-in-browser promo is suppressed.
    expect(out.split('Kimi WebBridge').length - 1).toBe(1);
    expect(out).not.toContain('open in browser');
    panel.handleInput('\r'); // index 0 → the real entry installs
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-webbridge', source: 'capability:kimi-webbridge' }),
    });
  });

  it('installs a Curated entry whose id matches the pinned WebBridge', () => {
    // A curated/custom marketplace entry can legitimately reuse the
    // kimi-webbridge id; on the Curated tab it must install normally, not
    // open the WebBridge page (that shortcut is reserved for the pinned row).
    const entries = [
      {
        id: 'kimi-webbridge',
        tier: 'curated' as const,
        displayName: 'Kimi WebBridge',
        source: 'capability:kimi-webbridge',
      },
    ];
    const { panel, onSelect } = makePanel({ initialTab: 'third-party' });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Curated');
    expect(out).toContain('Third-party plugins from our partners.');
    expect(out).toContain('Kimi WebBridge  install');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'kimi-webbridge', source: 'capability:kimi-webbridge' }),
    });
  });

  it('installs the selected Curated entry on Enter', () => {
    const { panel, onSelect } = makePanel({ installed: [superpowers], initialTab: 'third-party' });
    panel.setMarketplace(marketplaceEntries, '/tmp/marketplace.json');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'superpowers' }),
    });
  });

  it('renders an installing state while an install is in progress', () => {
    const { panel } = makePanel({ installed: [superpowers] });
    panel.setInstalling('Superpowers');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Installing Superpowers…');
  });

  it('keeps a valid selection if ↓ is pressed while the catalog is loading', () => {
    const { panel, onSelect } = makePanel({ initialTab: 'third-party' });
    // Catalog still loading (entries empty); pressing ↓ must not drive the
    // selection negative, or the later Enter would read entries[-1].
    panel.handleInput('\u001B[B'); // ↓
    panel.setMarketplace(marketplaceEntries, '/tmp/marketplace.json');
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install',
      entry: expect.objectContaining({ id: 'superpowers' }),
    });
  });

  it('shows untiered custom marketplace entries without the partner description', () => {
    const untiered = [
      { id: 'custom-plugin', displayName: 'Custom Plugin', source: 'https://x/c.zip' },
    ];
    const { panel } = makePanel({ initialTab: 'third-party', catalogIsDefault: false });
    panel.setMarketplace(untiered, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Custom Plugin  install');
    expect(out).not.toContain('Third-party plugins from our partners.');
  });

  it('shows an update badge when the marketplace version is newer than installed', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '4.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel } = makePanel({ installed, initialTab: 'third-party' });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Superpowers  update 4.0.0 → 5.0.0');
  });

  it('shows an update badge on the Installed tab when the marketplace version is newer', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '4.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel } = makePanel({ installed });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Superpowers  enabled  update 4.0.0 → 5.0.0');
  });

  it('updates the Windows backing plugin through its capability entry', () => {
    const installed = [
      {
        ...superpowers,
        id: 'kimi-cu-win',
        displayName: 'Kimi Computer Use for Windows',
        version: '0.2.13',
      },
    ];
    const capability = makeCapability({ pluginId: 'kimi-cu-win' });
    const entry = {
      id: 'kimi-cu',
      tier: 'official' as const,
      displayName: 'Kimi Computer Use',
      version: '0.2.14',
      source: 'capability:kimi-cu',
      builtIn: true,
    };
    const { panel, onSelect } = makePanel({ installed, capabilities: [capability] });
    panel.setMarketplace([entry], '/tmp/marketplace.json');

    expect(strip(renderRaw(panel))).toContain(
      'Kimi Computer Use for Windows  enabled  update 0.2.13 → 0.2.14',
    );
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'install', entry });
  });

  it('keeps installation state separate from capability readiness', () => {
    const installed = [
      { ...superpowers, id: 'kimi-cu', displayName: 'Kimi Computer Use', version: '0.5.4' },
    ];
    const capabilities = [makeCapability()];
    const entries = [
      {
        id: 'kimi-cu',
        tier: 'official' as const,
        displayName: 'Kimi Computer Use',
        version: '0.5.4',
        source: 'capability:kimi-cu',
        builtIn: true,
      },
    ];
    const { panel } = makePanel({ installed, capabilities });
    panel.setMarketplace(entries, '/tmp/marketplace.json');

    const installedOut = strip(renderRaw(panel));
    expect(installedOut).toContain('Kimi Computer Use  enabled');
    expect(installedOut).not.toContain('setup incomplete');
    expect(installedOut).not.toContain('needs permissions');

    panel.handleInput('\t');
    const officialOut = strip(renderRaw(panel));
    expect(officialOut).toContain('Kimi Computer Use  installed · v0.5.4');
    expect(officialOut).toContain('1 installed · 0 available');
    expect(officialOut).not.toContain('needs permissions');
  });

  it('uses the Windows backing plugin id for Official installation state', () => {
    const installed = [
      {
        ...superpowers,
        id: 'kimi-cu-win',
        displayName: 'Kimi Computer Use for Windows',
        version: '0.2.14',
      },
    ];
    const capabilities = [makeCapability({ pluginId: 'kimi-cu-win' })];
    const entries = [
      {
        id: 'kimi-cu',
        tier: 'official' as const,
        displayName: 'Kimi Computer Use',
        version: '0.2.14',
        source: 'capability:kimi-cu',
        builtIn: true,
      },
    ];
    const { panel } = makePanel({ installed, capabilities, initialTab: 'official' });
    panel.setMarketplace(entries, '/tmp/marketplace.json');

    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi Computer Use  installed · v0.2.14');
    expect(out).toContain('1 installed · 0 available');
  });

  it('keeps Enter on the Installed tab consistent with other plugins', () => {
    const installed = [
      { ...superpowers, id: 'kimi-cu', displayName: 'Kimi Computer Use', version: '0.5.4' },
    ];
    const { panel, onSelect } = makePanel({ installed, capabilities: [makeCapability()] });

    panel.handleInput('\r');

    expect(onSelect).toHaveBeenCalledWith({ kind: 'details', id: 'kimi-cu' });
  });

  it('keeps unsupported capability diagnostics out of the Installed list', () => {
    const installed = [
      { ...superpowers, id: 'kimi-cu', displayName: 'Kimi Computer Use', version: '0.5.4' },
    ];
    const capabilities = [
      makeCapability({ supported: false, state: 'unsupported', steps: [] }),
    ];
    const { panel, onSelect } = makePanel({ installed, capabilities });

    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi Computer Use  enabled');
    expect(out).not.toContain('unsupported');

    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({ kind: 'details', id: 'kimi-cu' });
  });

  it('does not expose capability readiness, version, or optional issues in the marketplace', () => {
    const capabilities = [
      makeCapability({
        id: 'kimi-webbridge',
        displayName: 'Kimi WebBridge',
        state: 'ready',
        version: 'v1.11.5',
        steps: [
          { id: 'daemon-binary', state: 'ok' },
          { id: 'daemon', state: 'ok' },
          { id: 'skill', state: 'ok' },
          { id: 'extension', state: 'missing', optional: true },
        ],
      }),
    ];
    const installed = [
      { ...superpowers, id: 'kimi-webbridge', displayName: 'Kimi WebBridge', version: '1.11.3' },
    ];
    const { panel } = makePanel({ installed, capabilities, initialTab: 'official' });
    panel.setMarketplace(
      [{ id: 'kimi-webbridge', displayName: 'Kimi WebBridge', source: 'capability:kimi-webbridge', tier: 'official', builtIn: true }],
      '/tmp/marketplace.json',
    );

    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi WebBridge  installed');
    expect(out).not.toContain('ready');
    expect(out).not.toContain('v1.11.5');
    expect(out).not.toContain('browser extension');
  });

  it('keeps capability repair details out of marketplace rows', () => {
    const capabilities = [
      makeCapability({
        id: 'kimi-webbridge',
        displayName: 'Kimi WebBridge',
        state: 'partial',
        steps: [
          { id: 'daemon-binary', state: 'ok' },
          { id: 'daemon', state: 'ok' },
          { id: 'skill', state: 'missing' },
          { id: 'skill-shadow', state: 'failed', optional: true },
        ],
      }),
    ];
    const { panel } = makePanel({ capabilities, initialTab: 'official' });
    panel.setMarketplace(
      [{ id: 'kimi-webbridge', displayName: 'Kimi WebBridge', source: 'capability:kimi-webbridge', tier: 'official', builtIn: true }],
      '/tmp/marketplace.json',
    );

    const out = strip(renderRaw(panel));
    expect(out).toContain('Kimi WebBridge  install');
    expect(out).not.toContain('agent skill');
    expect(out).not.toContain('skill shadows');
  });

  it('does not show an update badge on the Installed tab before the marketplace loads', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '4.0.0' }];
    const { panel } = makePanel({ installed });
    // The marketplace has not been loaded yet, so the badge stays hidden rather
    // than guessing.
    const out = strip(renderRaw(panel));
    expect(out).not.toContain('update');
  });

  it('shows installed · v<version> when the installed plugin is up to date', () => {
    const installed = [{ ...superpowers, id: 'superpowers', version: '5.0.0' }];
    const entries = [
      {
        id: 'superpowers',
        tier: 'curated' as const,
        displayName: 'Superpowers',
        version: '5.0.0',
        source: 'https://x/s.zip',
      },
    ];
    const { panel } = makePanel({ installed, initialTab: 'third-party' });
    panel.setMarketplace(entries, '/tmp/marketplace.json');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Superpowers  installed · v5.0.0');
  });

  it('shows an inline error when the Official catalog fails', () => {
    const { panel } = makePanel({ installed: [superpowers] });
    panel.handleInput('\t'); // → Official
    panel.setMarketplaceError('fetch failed');
    const out = strip(renderRaw(panel));
    expect(out).toContain('Marketplace unavailable: fetch failed');
    expect(out).toContain('Use the Custom tab');
  });

  it('installs from a URL typed on the Custom tab', () => {
    const { panel, onSelect } = makePanel({ initialTab: 'custom' });
    const out = strip(renderRaw(panel));
    expect(out).toContain('Install from a GitHub URL');
    expect(out).toContain('╭');

    for (const ch of 'https://github.com/owner/repo') {
      panel.handleInput(ch);
    }
    panel.handleInput('\r');
    expect(onSelect).toHaveBeenCalledWith({
      kind: 'install-source',
      source: 'https://github.com/owner/repo',
    });
  });

  it('toggles MCP servers from the MCP selector', () => {
    const selections: PluginMcpSelection[] = [];
    const picker = new PluginMcpSelectorComponent({
      info: {
        id: 'kimi-datasource',
        displayName: 'Kimi Datasource',
        version: '1.0.0',
        enabled: true,
        state: 'ok',
        skillCount: 1,
        mcpServerCount: 1,
        enabledMcpServerCount: 1,
        hookCount: 0,
      commandCount: 0,
        hasErrors: false,
        source: 'local-path',
        installedAt: '2026-05-29T00:00:00.000Z',
        root: '/plugins/kimi-datasource',
        manifest: undefined,
        mcpServers: [
          {
            name: 'data',
            runtimeName: 'plugin-kimi-datasource-data',
            enabled: true,
            transport: 'stdio',
            command: 'node',
            args: ['./bin/kimi-datasource.mjs'],
            cwd: '/plugins/kimi-datasource',
          },
        ],
        diagnostics: [],
      },
      onSelect: (selection) => {
        selections.push(selection);
      },
      onCancel: vi.fn(),
    });

    const raw = renderRaw(picker);
    const out = strip(raw);
    expect(out).toContain('MCP servers (1/1 enabled)');
    expect(out).toContain('? data  enabled');
    expect(out).toContain('Enter/Space enable/disable');

    picker.handleInput(' ');

    expect(selections).toEqual([
      { kind: 'toggle', pluginId: 'kimi-datasource', server: 'data', enabled: false },
    ]);
  });

  it('defaults plugin removal confirmation to cancel', () => {
    const results: PluginRemoveConfirmResult[] = [];
    const picker = new PluginRemoveConfirmComponent({
      id: 'kimi-datasource',
      displayName: 'Kimi Datasource',
      onDone: (result) => {
        results.push(result);
      },
    });

    const out = picker.render(120).map(strip);
    expect(out).toContain(' Remove Kimi Datasource (kimi-datasource)?');
    expect(out).toContain('  ? Cancel');
    expect(out).toContain('    Keep this plugin installed.');
    expect(out).toContain('    Remove only the install record; plugin files are left in place.');

    picker.handleInput('\r');
    expect(results).toEqual([{ kind: 'cancel' }]);
  });

  it('confirms plugin removal only after choosing remove', () => {
    const results: PluginRemoveConfirmResult[] = [];
    const picker = new PluginRemoveConfirmComponent({
      id: 'kimi-datasource',
      displayName: 'Kimi Datasource',
      onDone: (result) => {
        results.push(result);
      },
    });

    picker.handleInput('\u001B[B');
    const raw = renderRaw(picker);
    expect(strip(raw)).toContain('Enter/Space select');
    // The destructive option label keeps its danger styling (error + bold).
    expect(raw).toContain(dangerShortcut('Remove plugin'));

    picker.handleInput('\r');

    expect(results).toEqual([{ kind: 'confirm' }]);
  });

  it('defaults the third-party install trust prompt to exit', () => {
    const results: PluginInstallTrustConfirmResult[] = [];
    const picker = new PluginInstallTrustConfirmComponent({
      label: 'Superpowers',
      onDone: (result) => {
        results.push(result);
      },
    });

    const raw = renderRaw(picker);
    const out = raw.split('\n').map(strip);
    expect(out).toContain(' Install third-party plugin Superpowers?');
    expect(out).toContain('  ? Exit');
    expect(out).toContain('    Cancel the installation.');
    expect(out).toContain('    Install this third-party plugin anyway.');
    // The warning explains why confirmation is required and uses the
    // design-system warning color rather than muted/default text.
    expect(out.some((line) => line.includes('Kimi has not reviewed'))).toBe(true);
    expect(out.some((line) => line.includes('trust the source'))).toBe(true);
    expect(raw).toContain(warningMark());

    picker.handleInput('\r');
    expect(results).toEqual([{ kind: 'cancel' }]);
  });

  it('installs a third-party plugin only after switching to trust', () => {
    const results: PluginInstallTrustConfirmResult[] = [];
    const picker = new PluginInstallTrustConfirmComponent({
      label: 'Superpowers',
      onDone: (result) => {
        results.push(result);
      },
    });

    picker.handleInput('\u001B[B');
    const raw = renderRaw(picker);
    expect(strip(raw)).toContain('Enter/Space select');
    // The opt-in option keeps its danger styling (error + bold).
    expect(raw).toContain(dangerShortcut('Trust and install'));

    picker.handleInput('\r');

    expect(results).toEqual([{ kind: 'confirm' }]);
  });
});
