import { AsyncLocalStorage } from 'node:async_hooks';
import { existsSync } from 'node:fs';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

import {
  deleteAllKittyImages,
  resetCapabilitiesCache,
  setCapabilities,
} from '@moonshot-ai/pi-tui';
import type {
  ApprovalRequest,
  ApprovalResponse,
  Event,
  GoalSnapshot,
  Session,
} from '@moonshot-ai/kimi-code-sdk';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { ApprovalPanelComponent } from '#/tui/components/dialogs/approval-panel';
import { EffortSelectorComponent } from '#/tui/components/dialogs/effort-selector';
import { kimiCodePluginMarketplaceUrl } from '#/constant/app';
import { MOON_SPINNER_FRAMES } from '#/tui/constant/rendering';
import {
  AgentSwarmProgressComponent,
  agentSwarmGridHeightForTerminalRows,
} from '#/tui/components/messages/agent-swarm-progress';
import { AssistantMessageComponent } from '#/tui/components/messages/assistant-message';
import { StepSummaryComponent } from '#/tui/components/messages/step-summary';
import { ToolCallComponent } from '#/tui/components/messages/tool-call';
import {
  groupTurns,
  TRANSCRIPT_KEEP_RECENT_ASSISTANT,
  TRANSCRIPT_KEEP_RECENT_ASSISTANT_COMPLETED,
  TRANSCRIPT_KEEP_RECENT_STEPS,
} from '#/tui/utils/transcript-window';
import { BtwPanelComponent } from '#/tui/components/panes/btw-panel';
import { ThinkingComponent } from '#/tui/components/messages/thinking';
import { WelcomeComponent } from '#/tui/components/chrome/welcome';
import { ModelSelectorComponent } from '#/tui/components/dialogs/model-selector';
import { TabbedModelSelectorComponent } from '#/tui/components/dialogs/tabbed-model-selector';
import { UndoSelectorComponent } from '#/tui/components/dialogs/undo-selector';
import {
  PluginInstallTrustConfirmComponent,
  PluginMcpSelectorComponent,
  PluginRemoveConfirmComponent,
  PluginsPanelComponent,
} from '#/tui/components/dialogs/plugins-selector';
import { KimiTUI, type KimiTUIStartupInput, type TUIState } from '#/tui/kimi-tui';
import type { SessionReplayRenderer } from '#/tui/controllers/session-replay';
import type { StreamingUIController } from '#/tui/controllers/streaming-ui';
import { handleFeedbackCommand } from '#/tui/commands/info';
import { copyTextToClipboard } from '#/utils/clipboard/clipboard-text';
import { openUrl } from '#/utils/open-url';
import { createFeedbackArchivePath } from '../../src/feedback/archive';
import { packageCodebase, scanCodebase } from '../../src/feedback/codebase';
import { uploadArchive } from '../../src/feedback/upload';
import {
  promptFeedbackAttachment,
  promptFeedbackInput,
  runModelSelector,
  type FeedbackPromptResult,
} from '#/tui/commands/prompts';
import type { QueuedMessage, TranscriptEntry } from '#/tui/types';
import type { ImageAttachmentStore } from '#/tui/utils/image-attachment-store';
import {
  extractMediaAttachments,
  type ExtractionResult,
} from '#/tui/utils/image-placeholder';

vi.mock('#/tui/commands/prompts', async (importOriginal) => {
  const actual = await importOriginal<typeof import('#/tui/commands/prompts')>();
  return {
    ...actual,
    promptFeedbackInput: vi.fn(),
    promptFeedbackAttachment: vi.fn(),
  };
});

vi.mock('../../src/feedback/codebase', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/feedback/codebase')>();
  return {
    ...actual,
    scanCodebase: vi.fn().mockResolvedValue(undefined),
    packageCodebase: vi.fn(),
  };
});

vi.mock('../../src/feedback/upload', () => ({
  uploadArchive: vi.fn(),
}));

vi.mock('../../src/feedback/archive', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/feedback/archive')>();
  return {
    ...actual,
    // Wrap the real implementation so archive packaging keeps working in the
    // other tests; individual tests can reject it to simulate an unwritable
    // cache dir.
    createFeedbackArchivePath: vi.fn(actual.createFeedbackArchivePath),
  };
});

// /feedback opens GitHub Issues in a browser when submission fails — stub it
// out so the test suite never spawns a browser window.
vi.mock('#/utils/open-url', () => ({ openUrl: vi.fn() }));

// Clipboard access spawns platform tools (pbcopy/wl-copy …) and emits OSC 52 —
// stub it out so the suite never touches the real clipboard or stdout.
vi.mock('#/utils/clipboard/clipboard-text', () => ({
  copyTextToClipboard: vi.fn(async () => 'native'),
}));

const ESC = String.fromCodePoint(0x1b);
const BEL = String.fromCodePoint(0x07);

function stripSgr(text: string): string {
  return text
    .replaceAll(/\u001B\[[0-9;]*m/g, '')
    .replaceAll(new RegExp(`${ESC}\\]8;;[^${BEL}]*${BEL}`, 'g'), '');
}

interface MessageDriver {
  state: TUIState;
  streamingUI: StreamingUIController;
  sessionReplay: SessionReplayRenderer;
  pluginCommandMap: Map<string, string>;
  sessionEventHandler: {
    startSubscription(): void;
    handleEvent(event: Event, sendQueued: (item: QueuedMessage) => void): void;
  };
  init(): Promise<boolean>;
  handleUserInput(text: string): void;
  appendTranscriptEntry(entry: TranscriptEntry): void;
  persistInputHistory(text: string): Promise<void>;
  sendQueuedMessage(session: unknown, item: QueuedMessage): void;
  recallLastQueued(): QueuedMessage | undefined;
  recallStashedMedia(extraction: ExtractionResult | undefined): void;
  clearQueuedMessages(): void;
  closeSession(reason: string): Promise<void>;
  setSession(session: unknown): Promise<void>;
  getCurrentSessionId(): string;
}

interface FeedbackDriver extends MessageDriver {
  handleFeedbackCommand(): Promise<void>;
  promptFeedbackInput(): Promise<FeedbackPromptResult | undefined>;
}

interface ModelSelectorDriver extends MessageDriver {
  runModelSelector(
    models: Record<
      string,
      {
        provider: string;
        model: string;
        maxContextSize: number;
        displayName?: string;
        capabilities?: string[];
      }
    >,
  ): Promise<{ alias: string; thinking: boolean } | undefined>;
}

function makeStartupInput(): KimiTUIStartupInput {
  return {
    cliOptions: {
      session: undefined,
      continue: false,
      yolo: false,
      auto: false,
      plan: false,
      model: undefined,
      outputFormat: undefined,
      prompt: undefined,
      skillsDirs: [],
      agent: undefined,
      agentFiles: [],
    },
    tuiConfig: {
      theme: 'dark',
      disablePasteBurst: false,
      editorCommand: null,
      notifications: { enabled: true, condition: 'unfocused' },
      upgrade: { autoInstall: true },
      statusLine: { items: null, command: null },
    },
    version: '0.0.0-test',
    workDir: '/tmp/proj-a',
  };
}

function makeSession(overrides: Record<string, unknown> = {}) {
  let model = 'k2';
  let thinkingEffort = 'off';
  return {
    id: 'ses-1',
    model: 'k2',
    summary: { title: null },
    prompt: vi.fn(async (_input: unknown) => {}),
    compact: vi.fn(async () => {}),
    steer: vi.fn(async () => {}),
    init: vi.fn(async () => {}),
    startBtw: vi.fn(async () => 'agent-btw'),
    undoHistory: vi.fn(async () => {}),
    cancel: vi.fn(async () => {}),
    cancelCompaction: vi.fn(async () => {}),
    getStatus: vi.fn(async () => ({
      model,
      thinkingEffort,
      permission: 'manual',
      planMode: false,
      contextTokens: 0,
      maxContextTokens: 100,
      contextUsage: 0,
    })),
    getGoal: vi.fn(async () => ({ goal: null })),
    setApprovalHandler: vi.fn(),
    setQuestionHandler: vi.fn(),
    setModel: vi.fn(async (alias: string) => {
      model = alias;
    }),
    setThinking: vi.fn(async (effort: string) => {
      thinkingEffort = effort;
    }),
    setPermission: vi.fn(async () => {}),
    setPlanMode: vi.fn(async () => {}),
    setSwarmMode: vi.fn(async () => {}),
    onEvent: vi.fn(() => vi.fn()),
    listMcpServers: vi.fn(async () => []),
    listSkills: vi.fn(async () => []),
    getResumeState: vi.fn(() => ({
      sessionMetadata: {},
      agents: {
        main: {
          status: {
            model: 'k2',
            thinkingEffort: 'off',
            permission: 'manual',
            planMode: false,
            contextTokens: 0,
            maxContextTokens: 100,
            contextUsage: 0,
          },
          context: { history: [] },
          replay: [],
        },
      },
    })),
    close: vi.fn(async () => {}),
    listPlugins: vi.fn(async () => []),
    installPlugin: vi.fn(async () => ({
      id: 'demo',
      displayName: 'Demo',
      version: '1.0.0',
      enabled: true,
      state: 'ok',
      skillCount: 1,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hasErrors: false,
      source: 'local-path',
    })),
    setPluginEnabled: vi.fn(async () => {}),
    setPluginMcpServerEnabled: vi.fn(async () => {}),
    removePlugin: vi.fn(async () => {}),
    reloadPlugins: vi.fn(async () => ({ added: [], removed: [], errors: [] })),
    reloadSession: vi.fn(async () => ({})),
    activateSkill: vi.fn(async () => {}),
    promptWithSkills: vi.fn(async () => {}),
    getPluginInfo: vi.fn(async (id: string) => ({
      id,
      displayName: id,
      version: '1.0.0',
      enabled: true,
      state: 'ok',
      skillCount: 1,
      mcpServerCount: 0,
      enabledMcpServerCount: 0,
      hasErrors: false,
      source: 'local-path',
      root: `/plugins/${id}`,
      manifest: undefined,
      mcpServers: [],
      diagnostics: [],
    })),
    ...overrides,
  };
}

function makeHarness(session = makeSession(), overrides: Record<string, unknown> = {}) {
  const interactiveAgentScope = new AsyncLocalStorage<string>();
  const harness = {
    getConfig: vi.fn(async () => ({
      models: {
        k2: { model: 'moonshot-v1', maxContextSize: 100 },
      },
    })),
    setConfig: vi.fn(async () => ({ providers: {} })),
    createSession: vi.fn(async () => session),
    resumeSession: vi.fn(async () => session),
    forkSession: vi.fn(async () => session),
    listSessions: vi.fn(async () => []),
    exportSession: vi.fn(async () => ({
      zipPath: '/tmp/fake-session.zip',
      entries: ['manifest.json', 'state.json'],
      sessionDir: '/tmp/session-a',
      manifest: {},
    })),
    deleteFile: vi.fn(async () => {}),
    close: vi.fn(async () => {}),
    track: vi.fn(),
    setTelemetryContext: vi.fn(),
    get interactiveAgentId() {
      return interactiveAgentScope.getStore() ?? 'main';
    },
    withInteractiveAgent: vi.fn((agentId: string, fn: () => unknown) => {
      return interactiveAgentScope.run(agentId, fn);
    }),
    getExperimentalFeatures: vi.fn(async () => []),
    auth: {
      // /feedback gates on the OAuth token rather than the active model, so
      // the default mock is a signed-in user; signed-out cases override this.
      status: vi.fn(async () => ({
        providers: [{ providerName: 'managed:kimi-code', hasToken: true }],
      })),
      login: vi.fn(),
      logout: vi.fn(),
      getManagedUsage: vi.fn(),
      submitFeedback: vi.fn(
        async (): Promise<
          { kind: 'ok'; feedbackId: number } | { kind: 'error'; status?: number; message: string }
        > => ({
          kind: 'ok',
          feedbackId: 3,
        }),
      ),
    },
    ...overrides,
  };
  // The TUI lists sessions through keyset pages; derive the page mock from
  // the (possibly overridden) full-list mock unless a test overrides paging.
  if (!('listSessionsPage' in harness)) {
    const listSessions = harness.listSessions as (input?: {
      workDir?: string;
      sessionId?: string;
    }) => Promise<unknown[]>;
    Object.assign(harness, {
      listSessionsPage: vi.fn(
        async (input: { workDir?: string; sessionId?: string } = {}) => ({
          items: await listSessions({ workDir: input.workDir, sessionId: input.sessionId }),
          nextCursor: undefined,
        }),
      ),
    });
  }
  return harness;
}

async function makeDriver(
  session = makeSession(),
  harnessOverrides: Record<string, unknown> = {},
  startupInput: KimiTUIStartupInput = makeStartupInput(),
): Promise<{
  driver: MessageDriver;
  session: ReturnType<typeof makeSession>;
  harness: ReturnType<typeof makeHarness>;
}> {
  const harness = makeHarness(session, harnessOverrides);
  const driver = new KimiTUI(harness as never, startupInput) as unknown as MessageDriver;
  vi.spyOn(driver.state.ui, 'requestRender').mockImplementation(() => {});
  vi.spyOn(driver.state.terminal, 'setProgress').mockImplementation(() => {});
  driver.persistInputHistory = vi.fn(async () => {});
  await driver.init();
  return { driver, session, harness };
}

function makeActiveGoalSnapshot(): GoalSnapshot {
  return {
    goalId: 'g1',
    objective: 'Ship the feature',
    status: 'active',
    turnsUsed: 3,
    tokensUsed: 100,
    wallClockMs: 1000,
    budget: {
      tokenBudget: null,
      turnBudget: null,
      wallClockBudgetMs: null,
      remainingTokens: null,
      remainingTurns: null,
      remainingWallClockMs: null,
      tokenBudgetReached: false,
      turnBudgetReached: false,
      wallClockBudgetReached: false,
      overBudget: false,
    },
  };
}

function renderTranscript(driver: MessageDriver): string {
  return driver.state.transcriptContainer.render(120).join('\n');
}

async function confirmUndoSelection(driver: MessageDriver): Promise<void> {
  await vi.waitFor(() => {
    expect(driver.state.editorContainer.children[0]).toBeInstanceOf(UndoSelectorComponent);
  });
  (driver.state.editorContainer.children[0] as UndoSelectorComponent).handleInput('\r');
}

function renderActivity(driver: MessageDriver): string {
  return driver.state.activityContainer.render(120).join('\n');
}

function renderBtwPanel(driver: MessageDriver): string {
  return driver.state.btwPanelContainer.render(120).join('\n');
}

function getMountedBtwPanel(driver: MessageDriver): BtwPanelComponent {
  const panel = driver.state.btwPanelContainer.children.find(
    (child) => child instanceof BtwPanelComponent,
  );
  if (panel === undefined) throw new Error('Expected a mounted /btw panel.');
  return panel;
}

async function openBtwPanel(
  driver: MessageDriver,
  session: ReturnType<typeof makeSession>,
  prompt = 'side question',
): Promise<void> {
  driver.handleUserInput(`/btw ${prompt}`);
  await vi.waitFor(() => {
    expect(session.startBtw).toHaveBeenCalled();
    expect(driver.state.btwPanelContainer.children).toHaveLength(2);
  });
}

function setTerminalRows(driver: MessageDriver, rows: number): void {
  Object.defineProperty(driver.state.terminal, 'rows', {
    configurable: true,
    get: () => rows,
  });
}

function setTerminalColumns(driver: MessageDriver, columns: number): void {
  Object.defineProperty(driver.state.terminal, 'columns', {
    configurable: true,
    get: () => columns,
  });
}

function countOccurrences(haystack: string, needle: string): number {
  return haystack.split(needle).length - 1;
}

const tempDirs: string[] = [];
const originalKimiCodeHome = process.env['KIMI_CODE_HOME'];
const originalPluginMarketplaceUrl = process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'];
const originalVisual = process.env['VISUAL'];
const originalEditor = process.env['EDITOR'];

async function makeTempHome(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'kimi-code-tui-'));
  tempDirs.push(dir);
  return dir;
}

function stagedImage(imageStore: ImageAttachmentStore, fileId: string) {
  return imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1, undefined, fileId);
}

/**
 * Emits the turn.started/turn.ended pair that claims and then releases a
 * staged-media lease; `between` runs assertions after the claim.
 */
function emitTurn(driver: MessageDriver, turnId: number, between?: () => void): void {
  driver.sessionEventHandler.handleEvent(
    { type: 'turn.started', agentId: 'main', turnId, origin: { kind: 'user' } } as Event,
    () => {},
  );
  between?.();
  driver.sessionEventHandler.handleEvent(
    { type: 'turn.ended', agentId: 'main', turnId, reason: 'completed' } as Event,
    () => {},
  );
}

async function makeExportedSessionZip(content = 'session zip'): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'kimi-code-feedback-export-'));
  tempDirs.push(dir);
  const zipPath = join(dir, 'session.zip');
  await writeFile(zipPath, content);
  return zipPath;
}

afterEach(async () => {
  resetCapabilitiesCache();
  for (const dir of tempDirs.splice(0)) {
    await rm(dir, { recursive: true, force: true });
  }
  if (originalKimiCodeHome === undefined) {
    delete process.env['KIMI_CODE_HOME'];
  } else {
    process.env['KIMI_CODE_HOME'] = originalKimiCodeHome;
  }
  if (originalVisual === undefined) {
    delete process.env['VISUAL'];
  } else {
    process.env['VISUAL'] = originalVisual;
  }
  if (originalPluginMarketplaceUrl === undefined) {
    delete process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'];
  } else {
    process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'] = originalPluginMarketplaceUrl;
  }
  if (originalEditor === undefined) {
    delete process.env['EDITOR'];
  } else {
    process.env['EDITOR'] = originalEditor;
  }
});

describe('KimiTUI message flow', () => {
  it('tracks editor shortcut and paste hooks', async () => {
    const { driver, harness } = await makeDriver();
    harness.track.mockClear();

    driver.state.editor.handleInput('\u001F');
    delete process.env['VISUAL'];
    delete process.env['EDITOR'];
    driver.state.editor.onOpenExternalEditor?.();
    driver.state.editor.onToggleToolExpand?.();
    driver.state.editor.onTextPaste?.();

    expect(harness.track).toHaveBeenCalledWith('undo', undefined);
    expect(harness.track).toHaveBeenCalledWith('shortcut_editor', undefined);
    expect(harness.track).toHaveBeenCalledWith('shortcut_expand', undefined);
    expect(harness.track).toHaveBeenCalledWith('shortcut_paste', { kind: 'text' });
  });

  it('lazily creates the session on the first message (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    // Startup stays session-less on the v2 engine.
    expect(harness.createSession).not.toHaveBeenCalled();
    expect(driver.state.appState.sessionId).toBe('');
    expect(driver.state.appState.model).toBe('k2');

    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledTimes(1);
    expect(harness.createSession).toHaveBeenCalledWith({
      workDir: '/tmp/proj-a',
      model: 'k2',
      thinking: undefined,
      permission: 'manual',
      planMode: undefined,
    });
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  it('lazily creates the session for session-requiring slash commands (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    expect(harness.createSession).not.toHaveBeenCalled();

    driver.handleUserInput('/compact');

    await vi.waitFor(() => {
      expect(session.compact).toHaveBeenCalledWith({ instruction: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledTimes(1);
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  it('lazily creates the session for skill commands (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy', activateSkill: vi.fn(async () => {}) });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          {
            name: 'my-skill',
            description: 'A test skill',
            path: '/tmp/my-skill',
            source: 'user',
          },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    // `makeDriver` stops after init(); the skill command list is refreshed in
    // finishStartup, so resolve it here to exercise the workspace-level path.
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    // Startup resolves skill commands from the workspace, no session needed.
    expect(harness.createSession).not.toHaveBeenCalled();

    driver.handleUserInput('/skill:my-skill');

    await vi.waitFor(() => {
      expect(session.activateSkill).toHaveBeenCalledWith('my-skill', '');
    });
    expect(harness.createSession).toHaveBeenCalledTimes(1);
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  it('submits inline skill tokens with the prompt as one grouped submission (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('please /skill:review and /skill:security this change');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith(
        'please /skill:review and /skill:security this change',
        [{ name: 'review' }, { name: 'security' }],
      );
    });
    expect(session.prompt).not.toHaveBeenCalled();
    expect(session.activateSkill).not.toHaveBeenCalled();
  });

  it('combines a leading skill command with later inline skills into one submission (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/skill:review check this /skill:security');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith(
        '/skill:review check this /skill:security',
        [{ name: 'review' }, { name: 'security' }],
      );
    });
    expect(session.activateSkill).not.toHaveBeenCalled();
  });

  it('bundles a repeated leading skill as one bundled submission (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/skill:review check /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith('/skill:review check /skill:review', [
        { name: 'review' },
      ]);
    });
    expect(session.activateSkill).not.toHaveBeenCalled();
  });

  it('passes no args in a bundle while media rides the prompt parts (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);

    driver.handleUserInput(`/skill:review inspect ${attachment.placeholder} /skill:security`);

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith(
        [
          { type: 'text', text: '/skill:review inspect ' },
          { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
          { type: 'text', text: ' /skill:security' },
        ],
        [{ name: 'review' }, { name: 'security' }],
      );
    });
  });

  it('bundles newline-separated skills with the leading one included (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/skill:review\ncheck this /skill:security');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith(
        '/skill:review\ncheck this /skill:security',
        [{ name: 'review' }, { name: 'security' }],
      );
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('scans inline skills in messages that start with an unknown slash token (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/dance please use /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith(
        '/dance please use /skill:review',
        [{ name: 'review' }],
      );
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('keeps inline skill tokens as plain text on the legacy engine', async () => {
    const session = makeSession({ id: 'ses-1' });
    const { driver } = await makeDriver(session, {
      listSkills: undefined,
      listPluginCommands: vi.fn(async () => []),
    });
    (
      driver as unknown as { skillCommandMap: Map<string, string> }
    ).skillCommandMap.set('skill:review', 'review');

    driver.handleUserInput('please /skill:review this');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('please /skill:review this', { promptId: undefined });
    });
    expect(session.promptWithSkills).not.toHaveBeenCalled();
  });

  it('queues an inline-skill prompt while a goal is active (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();
    // Materialize the lazy session first: an active goal only exists inside a
    // live session, and lazy creation would refresh (and clear) the goal
    // snapshot set up below.
    await (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession();
    driver.state.appState.goal = makeActiveGoalSnapshot();

    driver.handleUserInput('check /skill:review');

    expect(session.promptWithSkills).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      expect.objectContaining({
        text: 'check /skill:review',
        inlineSkillActivations: [{ skillName: 'review' }],
      }),
    ]);
  });

  it('queues a leading-combo bundle while busy instead of rejecting it (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession();
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();
    driver.state.appState.goal = makeActiveGoalSnapshot();

    driver.handleUserInput('/skill:review check this /skill:security');

    expect(session.promptWithSkills).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      expect.objectContaining({
        text: '/skill:review check this /skill:security',
        inlineSkillActivations: [{ skillName: 'review' }, { skillName: 'security' }],
      }),
    ]);
  });

  it('does not append a user entry when the grouped submission is rejected (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
      promptWithSkills: vi.fn(async () => {
        throw new Error('Skill "review" was not found');
      }),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('please /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalled();
    });
    await vi.waitFor(() => {
      expect(driver.state.appState.streamingPhase).toBe('idle');
    });
    // A rejected group leaves no local undo anchor the engine never recorded.
    expect(driver.state.transcriptEntries.filter((entry) => entry.kind === 'user')).toHaveLength(0);
  });

  it('renders a bundled replay submission as a single turn', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(session, {}, startupInput);
    (session.getResumeState as ReturnType<typeof vi.fn>).mockReturnValue({
      sessionMetadata: {},
      agents: {
        main: {
          config: { modelCapabilities: { max_context_tokens: 100 }, modelAlias: 'k2' },
          plan: null,
          permission: { mode: 'manual' },
          swarmMode: false,
          context: { history: [], tokenCount: 0 },
          background: [],
          toolStore: {},
          replay: [
            {
              type: 'message',
              time: 1,
              message: {
                role: 'user',
                content: [{ type: 'text', text: 'earlier question' }],
                toolCalls: [],
                origin: { kind: 'user' },
              },
            },
            {
              type: 'message',
              time: 2,
              message: {
                role: 'assistant',
                content: [{ type: 'text', text: 'earlier answer' }],
                toolCalls: [],
              },
            },
            {
              type: 'message',
              time: 3,
              message: {
                role: 'user',
                content: [{ type: 'text', text: 'hook note' }],
                toolCalls: [],
                origin: { kind: 'hook_result', event: 'UserPromptSubmit' },
              },
            },
            {
              type: 'message',
              time: 4,
              message: {
                role: 'user',
                content: [
                  { type: 'text', text: 'skill card A body' },
                  { type: 'text', text: 'skill card B body' },
                  { type: 'text', text: 'please /skill:review and /skill:security' },
                ],
                toolCalls: [],
                origin: {
                  kind: 'user',
                  skillActivations: [
                    { activationId: 'act-1', skillName: 'review' },
                    { activationId: 'act-2', skillName: 'security' },
                  ],
                },
              },
            },
            {
              type: 'message',
              time: 5,
              message: {
                role: 'assistant',
                content: [{ type: 'text', text: 'bundled answer' }],
                toolCalls: [],
              },
            },
            {
              type: 'message',
              time: 6,
              message: {
                role: 'user',
                content: [
                  { type: 'text', text: 'skill card C body' },
                  { type: 'text', text: 'please /commit' },
                ],
                toolCalls: [],
                origin: {
                  kind: 'user',
                  skillActivations: [{ activationId: 'act-3', skillName: 'commit' }],
                },
              },
            },
          ],
        },
      },
    });

    const replayed = await driver.sessionReplay.hydrateFromReplay(session as unknown as Session);
    expect(replayed).toBe(true);

    const turns = groupTurns(driver.state.transcriptEntries);
    expect(turns).toHaveLength(3);
    // The hook result is projected inside the bundle's window (after the
    // skill cards, before the prompt), matching the live event order.
    expect(turns[1]!.entries.map((entry) => entry.kind)).toEqual([
      'skill_activation',
      'skill_activation',
      'assistant',
      'user',
      'assistant',
    ]);
    expect(turns[1]!.entries[2]!.hookResult).toBe(true);
    // The user entry shows only the caller's own text — the rendered skill
    // blocks the engine prepended to the content are stripped.
    expect(turns[1]!.entries[3]!.content).toBe('please /skill:review and /skill:security');
    expect(
      turns[1]!.entries.slice(0, 2).map((entry) => entry.bundledWithPrompt),
    ).toEqual([true, true]);
    expect(turns[2]!.entries.map((entry) => entry.kind)).toEqual(['skill_activation', 'user']);
    expect(turns[2]!.entries[1]!.content).toBe('please /commit');
  });

  it('keeps hook results recorded before the oldest retained bundle within the replay limit', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(session, {}, startupInput);
    const plainTurn = (index: number) => [
      {
        type: 'message',
        time: index * 2,
        message: {
          role: 'user',
          content: [{ type: 'text', text: `question ${index}` }],
          toolCalls: [],
          origin: { kind: 'user' },
        },
      },
      {
        type: 'message',
        time: index * 2 + 1,
        message: {
          role: 'assistant',
          content: [{ type: 'text', text: `answer ${index}` }],
          toolCalls: [],
        },
      },
    ];
    (session.getResumeState as ReturnType<typeof vi.fn>).mockReturnValue({
      sessionMetadata: {},
      agents: {
        main: {
          config: { modelCapabilities: { max_context_tokens: 100 }, modelAlias: 'k2' },
          plan: null,
          permission: { mode: 'manual' },
          swarmMode: false,
          context: { history: [], tokenCount: 0 },
          background: [],
          toolStore: {},
          replay: [
            ...plainTurn(0),
            {
              type: 'message',
              time: 1,
              message: {
                role: 'user',
                content: [{ type: 'text', text: 'hook note' }],
                toolCalls: [],
                origin: { kind: 'hook_result', event: 'UserPromptSubmit' },
              },
            },
            {
              type: 'message',
              time: 2,
              message: {
                role: 'user',
                content: [
                  { type: 'text', text: 'review body' },
                  { type: 'text', text: 'bundled question' },
                ],
                toolCalls: [],
                origin: {
                  kind: 'user',
                  skillActivations: [{ activationId: 'act-1', skillName: 'review' }],
                },
              },
            },
            {
              type: 'message',
              time: 3,
              message: {
                role: 'assistant',
                content: [{ type: 'text', text: 'bundled answer' }],
                toolCalls: [],
              },
            },
            ...Array.from({ length: 9 }, (_, i) => plainTurn(i + 10)).flat(),
          ],
        },
      },
    });

    const replayed = await driver.sessionReplay.hydrateFromReplay(session as unknown as Session);
    expect(replayed).toBe(true);

    const entries = driver.state.transcriptEntries;
    const hookIndex = entries.findIndex((entry) => entry.hookResult === true);
    expect(hookIndex).toBeGreaterThan(-1);
    expect(entries[hookIndex]!.content).toContain('hook note');
    const contents = entries.map((entry) => entry.content);
    expect(contents.indexOf('Activated skill: review')).toBeLessThan(hookIndex);
    expect(contents.indexOf('bundled question')).toBeGreaterThan(hookIndex);
    expect(contents).not.toContain('question 0');
  });

  it('appends the user entry after the skill cards for a bundled submission (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    // Hold the RPC open so the skill.activated event can land mid-flight,
    // exactly how the in-process wiring delivers it during the call.
    let release!: () => void;
    const heldPrompt = new Promise<void>((resolve) => {
      release = resolve;
    });
    (session.promptWithSkills as ReturnType<typeof vi.fn>).mockReturnValue(heldPrompt);

    driver.handleUserInput('please /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalled();
    });
    driver.sessionEventHandler.handleEvent(
      {
        type: 'skill.activated',
        sessionId: 'ses-lazy',
        agentId: 'main',
        activationId: 'act-1',
        skillName: 'review',
        trigger: 'user-slash',
      } as Event,
      () => {},
    );
    release();

    await vi.waitFor(() => {
      expect(driver.state.transcriptEntries.map((entry) => entry.kind)).toEqual([
        'skill_activation',
        'user',
      ]);
    });
    expect(driver.state.transcriptEntries[0]!.bundledWithPrompt).toBe(true);
  });

  it('serializes concurrent lazy session creation (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    // Hold the first createSession open so both triggers land inside the
    // in-flight window.
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession.mockImplementationOnce(
      () => new Promise((resolve) => { resolveCreate = resolve; }),
    );

    const ensure = (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession;
    const first = ensure.call(driver);
    const second = ensure.call(driver);
    resolveCreate(session);
    await Promise.all([first, second]);

    expect(harness.createSession).toHaveBeenCalledTimes(1);
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  it('waits out the in-flight lazy creation before /new (v2 engine)', async () => {
    const lazySession = makeSession({ id: 'ses-lazy' });
    const newSession = makeSession({ id: 'ses-new' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(lazySession, {}, startupInput);

    // Hold the lazy createSession open so it is still in flight when /new
    // arrives (triggered directly, without a prompt starting a turn).
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession
      .mockImplementationOnce(
        () => new Promise((resolve) => { resolveCreate = resolve; }),
      )
      .mockResolvedValueOnce(newSession);
    const ensure = (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession;
    const pending = ensure.call(driver);
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });

    driver.handleUserInput('/new');
    // /new must not race a second createSession while the lazy one is held.
    await new Promise((resolve) => setImmediate(resolve));
    expect(harness.createSession).toHaveBeenCalledTimes(1);

    resolveCreate(lazySession);
    await pending;
    // No turn started, so /new proceeds after the wait.
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(2);
      expect(driver.getCurrentSessionId()).toBe('ses-new');
    });
  });

  it('blocks /new while the waited-out first prompt starts a turn (v2 engine)', async () => {
    const lazySession = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(lazySession, {}, startupInput);

    // Hold the lazy createSession open so the first prompt is still pending
    // when /new arrives.
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession.mockImplementationOnce(
      () => new Promise((resolve) => { resolveCreate = resolve; }),
    );

    driver.handleUserInput('hello');
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });
    driver.handleUserInput('/new');

    resolveCreate(lazySession);
    // The prompt continuation starts its turn first; /new (idle-only) must
    // then be blocked instead of switching away from the active session.
    await vi.waitFor(() => {
      expect(lazySession.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
      expect(stripSgr(renderTranscript(driver))).toContain('Cannot /new while streaming');
    });
    expect(harness.createSession).toHaveBeenCalledTimes(1);
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  const thinkingModelsConfig = () => ({
    models: {
      k2: {
        provider: 'managed:kimi-code',
        model: 'kimi-k2',
        maxContextSize: 100,
        capabilities: ['thinking'],
        supportEfforts: ['low', 'high', 'max'],
        defaultEffort: 'high',
      },
    },
    defaultModel: 'k2',
    thinking: { enabled: true },
  });

  it('blocks an effort switch once the waited-out first prompt starts a turn (v2 engine)', async () => {
    const lazySession = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      lazySession,
      { getConfig: vi.fn(async () => thinkingModelsConfig()) },
      startupInput,
    );

    // Hold the lazy createSession open so the first prompt is still pending
    // when the effort switch arrives.
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession.mockImplementationOnce(
      () => new Promise((resolve) => { resolveCreate = resolve; }),
    );

    driver.handleUserInput('hello');
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });
    driver.handleUserInput('/effort low');

    resolveCreate(lazySession);
    // The prompt starts its turn first; the switch must then be rejected
    // instead of being silently overwritten by the session assembly.
    await vi.waitFor(() => {
      expect(lazySession.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
      expect(stripSgr(renderTranscript(driver))).toContain('Cannot switch models while streaming');
    });
    expect(lazySession.setThinking).not.toHaveBeenCalled();
  });

  it('applies an effort switch after waiting out an in-flight lazy creation (v2 engine)', async () => {
    const lazySession = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      lazySession,
      {
        getConfig: vi.fn(async () => thinkingModelsConfig()),
        setConfig: vi.fn(async () => ({ providers: {} })),
      },
      startupInput,
    );

    // Trigger the lazy creation directly, without a prompt starting a turn.
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession.mockImplementationOnce(
      () => new Promise((resolve) => { resolveCreate = resolve; }),
    );
    const ensure = (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession;
    const pending = ensure.call(driver);
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });

    driver.handleUserInput('/effort low');
    // While the creation is held the switch must wait, not write pending
    // state that the assembly would overwrite.
    await new Promise((resolve) => setImmediate(resolve));
    expect(driver.state.appState.thinkingEffort).toBe('high');

    resolveCreate(lazySession);
    await pending;
    await vi.waitFor(() => {
      expect(lazySession.setThinking).toHaveBeenCalledWith('low');
    });
  });

  it('blocks a session-picker switch once the waited-out first prompt starts a turn (v2 engine)', async () => {
    const lazySession = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      lazySession,
      {
        listSessions: vi.fn(async () => [
          { id: 'ses-old', title: 'Old session', workDir: '/tmp/proj-a', updatedAt: Date.now() },
        ]),
      },
      startupInput,
    );

    // Hold the lazy createSession open so the first prompt is still pending
    // when the picker selection arrives.
    let resolveCreate!: (s: ReturnType<typeof makeSession>) => void;
    harness.createSession.mockImplementationOnce(
      () => new Promise((resolve) => { resolveCreate = resolve; }),
    );

    driver.handleUserInput('hello');
    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });

    await (driver as unknown as { showSessionPicker(): Promise<void> }).showSessionPicker();
    const picker = driver.state.editorContainer.children[0] as { handleInput(data: string): void };
    picker.handleInput('\r');

    resolveCreate(lazySession);
    // The prompt starts its turn first; the switch must then be rejected
    // instead of being overwritten when the lazy creation completes.
    await vi.waitFor(() => {
      expect(lazySession.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
      expect(stripSgr(renderTranscript(driver))).toContain('Cannot switch sessions while streaming');
    });
    expect(harness.resumeSession).not.toHaveBeenCalled();
    expect(driver.getCurrentSessionId()).toBe('ses-lazy');
  });

  it('carries a session-only thinking choice into the lazy-created session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    // Alt+S session-only thinking before any session exists.
    await (
      driver as unknown as {
        authFlow: { activateModelAfterLogin(model: string, effort?: string): Promise<void> };
      }
    ).authFlow.activateModelAfterLogin('k2', 'high');

    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledWith(
      expect.objectContaining({ model: 'k2', thinking: 'high' }),
    );
    expect(driver.state.appState.lazySessionThinking).toBeUndefined();
  });

  it('does not pass the config default plan mode into the lazy-created session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      session,
      {
        getConfig: vi.fn(async () => ({
          models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
          defaultModel: 'k2',
          defaultPlanMode: true,
        })),
      },
      startupInput,
    );

    // The footer shows the config default…
    expect(driver.state.appState.planMode).toBe(true);

    // …but the create call must not repeat it: the v2 engine applies
    // defaultPlanMode at create time, and re-entering plan mode throws.
    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledWith(
      expect.objectContaining({ planMode: undefined }),
    );
  });

  it('passes the explicit --plan flag into the lazy-created session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2', plan: true },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledWith(
      expect.objectContaining({ planMode: true }),
    );
  });

  it('queues a bash command submitted while the lazy session is being created (v2 engine)', async () => {
    const runShellCommand = vi.fn(async () => ({ stdout: '', stderr: '', isError: false }));
    const session = makeSession({ id: 'ses-lazy', runShellCommand });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(session, {}, startupInput);

    // A prompt and a bash command both trigger the same in-flight creation.
    driver.handleUserInput('hello');
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';
    driver.handleUserInput('ls');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    // The shell command must be queued, not run concurrently with the prompt.
    expect(runShellCommand).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'ls', agentId: 'main', mode: 'bash' },
    ]);
  });

  it('opens /settings without creating a session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      // No model configured: /settings must still open so the user can fix
      // local editor/theme/update settings before picking a model.
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('/settings');

    expect(harness.createSession).not.toHaveBeenCalled();
    expect(driver.state.appState.sessionId).toBe('');
  });

  it('blocks a skill command submitted while the lazy session is being created (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy', activateSkill: vi.fn(async () => {}) });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          {
            name: 'my-skill',
            description: 'A test skill',
            path: '/tmp/my-skill',
            source: 'user',
          },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    // A prompt and a skill command both trigger the same in-flight creation.
    driver.handleUserInput('hello');
    driver.handleUserInput('/skill:my-skill');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    // The skill activation must be blocked, not run concurrently with the
    // prompt's turn.
    expect(session.activateSkill).not.toHaveBeenCalled();
    expect(harness.createSession).toHaveBeenCalledTimes(1);
  });

  it('manages plugins without creating a session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const listPlugins = vi.fn(async () => []);
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      // No model configured: /plugins must still work via the app-global API.
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, { listPlugins }, startupInput);

    driver.handleUserInput('/plugins list');

    await vi.waitFor(() => {
      expect(listPlugins).toHaveBeenCalled();
    });
    expect(harness.createSession).not.toHaveBeenCalled();
    expect(driver.state.appState.sessionId).toBe('');
  });

  it('lists additional directories without creating a session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      // No model configured: the read-only form must still work.
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('/add-dir list');

    expect(harness.createSession).not.toHaveBeenCalled();
    expect(driver.state.appState.sessionId).toBe('');
  });

  it('lazily creates the session when adding a directory (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('/add-dir /tmp/extra');

    await vi.waitFor(() => {
      expect(driver.getCurrentSessionId()).toBe('ses-lazy');
    });
    expect(harness.createSession).toHaveBeenCalledTimes(1);
  });

  it('shows pending startup directories in /add-dir list before the lazy session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      additionalDirs: ['/tmp/extra'],
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);
    const showStatus = vi.spyOn(
      driver as unknown as { showStatus: (msg: string) => void },
      'showStatus',
    );

    driver.handleUserInput('/add-dir list');

    await vi.waitFor(() => {
      expect(showStatus).toHaveBeenCalledWith(expect.stringContaining('/tmp/extra'));
    });
    expect(harness.createSession).not.toHaveBeenCalled();
  });

  it('refreshes plugin slash commands after a sessionless /plugins reload (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const listPluginCommands = vi.fn(async () => [
      {
        pluginId: 'my-plugin',
        name: 'my-command',
        body: 'do things',
        description: 'A plugin command',
      },
    ]);
    const reloadPlugins = vi.fn(async () => ({ added: [], removed: [], errors: [] }));
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(
      session,
      { listPluginCommands, reloadPlugins },
      startupInput,
    );

    driver.handleUserInput('/plugins reload');

    await vi.waitFor(() => {
      expect(reloadPlugins).toHaveBeenCalled();
      expect(listPluginCommands).toHaveBeenCalled();
      expect(driver.pluginCommandMap.get('my-plugin:my-command')).toBe('do things');
    });
    expect(harness.createSession).not.toHaveBeenCalled();
  });

  it('hydrates lazy config defaults on a sessionless /reload (v2 engine)', async () => {
    const homeDir = await makeTempHome();
    process.env['KIMI_CODE_HOME'] = homeDir;
    const session = makeSession({ id: 'ses-lazy' });
    const getConfig = vi.fn(
      async (): Promise<{ models: Record<string, unknown>; defaultModel?: string }> => ({
        models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
        // Initially no default model configured.
      }),
    );
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, { getConfig }, startupInput);
    expect(driver.state.appState.model).toBe('');

    // A default model is added externally, then /reload runs before the first
    // prompt — the lazy defaults must be refreshed, not left stale.
    getConfig.mockResolvedValue({
      models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
      defaultModel: 'k2',
    });
    driver.handleUserInput('/reload');

    await vi.waitFor(() => {
      expect(driver.state.appState.model).toBe('k2');
    });
    expect(harness.createSession).not.toHaveBeenCalled();
  });

  it('clears stale lazy defaults when the default model is removed (v2 engine)', async () => {
    const homeDir = await makeTempHome();
    process.env['KIMI_CODE_HOME'] = homeDir;
    const session = makeSession({ id: 'ses-lazy' });
    const getConfig = vi.fn(
      async (): Promise<{ models: Record<string, unknown>; defaultModel?: string }> => ({
        models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
        defaultModel: 'k2',
      }),
    );
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver } = await makeDriver(session, { getConfig }, startupInput);
    expect(driver.state.appState.model).toBe('k2');
    expect(driver.state.appState.maxContextTokens).toBe(100);

    // The default model is removed externally, then /reload runs — the
    // hydrated value must not survive as a stale explicit model.
    getConfig.mockResolvedValue({
      models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
    });
    driver.handleUserInput('/reload');

    await vi.waitFor(() => {
      expect(driver.state.appState.model).toBe('');
    });
    expect(driver.state.appState.maxContextTokens).toBe(0);
  });

  it('does not re-enter plan mode on /plan on when config already applied it (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: 'off',
        permission: 'manual',
        planMode: true,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(
      session,
      {
        getConfig: vi.fn(async () => ({
          models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
          defaultModel: 'k2',
          defaultPlanMode: true,
        })),
      },
      startupInput,
    );

    driver.handleUserInput('/plan on');

    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(1);
    });
    // The engine already applied defaultPlanMode at create; the command must
    // notice the active plan mode instead of re-entering (which would throw).
    expect(session.setPlanMode).not.toHaveBeenCalled();
    expect(driver.state.appState.planMode).toBe(true);
  });

  it('clears the stale permission default when it is removed from config (v2 engine)', async () => {
    const homeDir = await makeTempHome();
    process.env['KIMI_CODE_HOME'] = homeDir;
    const session = makeSession({ id: 'ses-lazy' });
    const getConfig = vi.fn(
      async (): Promise<{
        models: Record<string, unknown>;
        defaultModel?: string;
        defaultPermissionMode?: string;
      }> => ({
        models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
        defaultModel: 'k2',
        defaultPermissionMode: 'auto',
      }),
    );
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver } = await makeDriver(session, { getConfig }, startupInput);
    expect(driver.state.appState.permissionMode).toBe('auto');

    // The elevated default is removed externally, then /reload runs — a stale
    // elevated mode must not reach the first lazy-created session.
    getConfig.mockResolvedValue({
      models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
      defaultModel: 'k2',
    });
    driver.handleUserInput('/reload');

    await vi.waitFor(() => {
      expect(driver.state.appState.permissionMode).toBe('manual');
    });
  });

  it('does not pass --plan when config already applies default plan mode (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      // The engine applied the config default at create.
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: 'off',
        permission: 'manual',
        planMode: true,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2', plan: true },
    };
    const { driver, harness } = await makeDriver(
      session,
      {
        getConfig: vi.fn(async () => ({
          models: { k2: { model: 'moonshot-v1', maxContextSize: 100 } },
          defaultModel: 'k2',
          defaultPlanMode: true,
        })),
      },
      startupInput,
    );

    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    // The engine applies the config default at create; repeating --plan would
    // re-enter plan mode and throw, so it must not be passed again.
    expect(harness.createSession).toHaveBeenCalledWith(
      expect.objectContaining({ planMode: undefined }),
    );
    expect(driver.state.appState.planMode).toBe(true);
  });

  it('opens read-only status commands without creating a session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      // No model configured: read-only views must still open.
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('/status');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain('Status');
    });
    expect(harness.createSession).not.toHaveBeenCalled();
    expect(driver.state.appState.sessionId).toBe('');
  });

  it('applies /yolo on session-less and passes the mode to the lazy session (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    driver.handleUserInput('/yolo on');

    await vi.waitFor(() => {
      expect(driver.state.appState.permissionMode).toBe('yolo');
    });
    expect(harness.createSession).not.toHaveBeenCalled();
    expect(session.setPermission).not.toHaveBeenCalled();

    driver.handleUserInput('hello');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    });
    expect(harness.createSession).toHaveBeenCalledWith(
      expect.objectContaining({ permission: 'yolo' }),
    );
  });

  it('waits for lazy session assembly before dispatching further input (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);

    // Hold the post-create assembly open inside setPermission: the session is
    // assigned but setup is not finished yet.
    let resolvePermission!: () => void;
    session.setPermission.mockImplementationOnce(
      () => new Promise<void>((resolve) => { resolvePermission = resolve; }),
    );

    const ensure = (driver as unknown as { ensureSession(): Promise<unknown> }).ensureSession;
    const first = ensure.call(driver);
    await vi.waitFor(() => {
      expect(session.setPermission).toHaveBeenCalled();
    });

    // A second trigger must wait for the assembly instead of dispatching
    // against the half-initialized session.
    const second = ensure.call(driver);
    let secondResolved = false;
    void second.then(() => {
      secondResolved = true;
    });
    await Promise.resolve();
    expect(secondResolved).toBe(false);

    resolvePermission();
    await Promise.all([first, second]);
    expect(secondResolved).toBe(true);
    expect(harness.createSession).toHaveBeenCalledTimes(1);
  });

  it('lists MCP servers before the lazy session via the workspace view (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const listWorkspaceMcpServers = vi.fn(async () => [
      { name: 'my-mcp', status: 'connected', transport: 'stdio', tools: [] },
    ]);
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions },
    };
    const { driver, harness } = await makeDriver(
      session,
      { listWorkspaceMcpServers },
      startupInput,
    );

    driver.handleUserInput('/mcp');

    await vi.waitFor(() => {
      expect(listWorkspaceMcpServers).toHaveBeenCalledWith('/tmp/proj-a');
    });
    expect(harness.createSession).not.toHaveBeenCalled();
    expect(session.listMcpServers).not.toHaveBeenCalled();
  });

  it('tracks /clear as the clear alias for /new', async () => {
    const { driver, harness } = await makeDriver(makeSession({ id: 'ses-1' }));
    const nextSession = makeSession({ id: 'ses-2' });
    harness.createSession.mockResolvedValueOnce(nextSession);
    harness.track.mockClear();

    driver.handleUserInput('/clear');

    await vi.waitFor(() => {
      expect(driver.getCurrentSessionId()).toBe('ses-2');
    });
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'new' });
    expect(harness.track).toHaveBeenCalledWith('clear', undefined);
  });

  it('tracks theme changes from slash commands', async () => {
    process.env['KIMI_CODE_HOME'] = await makeTempHome();
    const { driver, harness } = await makeDriver();
    harness.track.mockClear();

    driver.handleUserInput('/theme light');

    await vi.waitFor(() => {
      expect(driver.state.appState.theme).toBe('light');
    });
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'theme' });
    expect(harness.track).toHaveBeenCalledWith('theme_switch', { theme: 'light' });
  });

  it('dispatches /reload-tui without reloading the active session', async () => {
    const homeDir = await makeTempHome();
    process.env['KIMI_CODE_HOME'] = homeDir;
    await writeFile(
      join(homeDir, 'tui.toml'),
      `
theme = "light"

[editor]
command = "vim"
`,
      'utf-8',
    );
    const { driver, session, harness } = await makeDriver();
    harness.track.mockClear();
    session.reloadSession.mockClear();

    driver.handleUserInput('/reload-tui');

    await vi.waitFor(() => {
      expect(driver.state.appState.theme).toBe('light');
    });
    expect(driver.state.appState.editorCommand).toBe('vim');
    expect(session.reloadSession).not.toHaveBeenCalled();
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'reload-tui' });
  });

  it('dispatches /reload through session reload and applies tui.toml', async () => {
    const homeDir = await makeTempHome();
    process.env['KIMI_CODE_HOME'] = homeDir;
    await writeFile(join(homeDir, 'tui.toml'), 'theme = "light"\n', 'utf-8');
    const { driver, session, harness } = await makeDriver();
    harness.track.mockClear();
    session.reloadSession.mockClear();
    driver.handleUserInput('hello before reload');
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/reload');

    await vi.waitFor(() => {
      expect(session.reloadSession).toHaveBeenCalledOnce();
    });
    await vi.waitFor(() => {
      expect(driver.state.appState.theme).toBe('light');
    });
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'reload' });
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('hello before reload');
    expect(transcript).toContain('Session reloaded.');
  });

  it('prints the sign-up page and GitHub Issues links when not signed in', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    harness.auth.status.mockResolvedValueOnce({
      providers: [{ providerName: 'managed:kimi-code', hasToken: false }],
    });
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(openUrl).mockClear();

    await handleFeedbackCommand(feedbackDriver as any);

    expect(openUrl).not.toHaveBeenCalled();
    expect(promptFeedbackInput).not.toHaveBeenCalled();
    expect(harness.auth.submitFeedback).not.toHaveBeenCalled();
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain("You're not signed in");
    expect(transcript).toContain('https://www.kimi.com/code');
    expect(transcript).toContain('https://github.com/MoonshotAI/kimi-code/issues');
  });

  it('falls back to GitHub Issues when the sign-in status cannot be read', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    harness.auth.status.mockRejectedValueOnce(new Error('token storage unavailable'));
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockClear();
    vi.mocked(openUrl).mockClear();

    await handleFeedbackCommand(feedbackDriver as any);

    expect(openUrl).toHaveBeenCalledTimes(1);
    expect(openUrl).toHaveBeenCalledWith('https://github.com/MoonshotAI/kimi-code/issues');
    expect(promptFeedbackInput).not.toHaveBeenCalled();
    expect(harness.auth.submitFeedback).not.toHaveBeenCalled();
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Opening GitHub Issues as fallback');
  });

  it('submits feedback via OAuth for a signed-in user on an API-key model', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    driver.state.appState.availableModels = {
      k2: {
        provider: 'openai',
        model: 'gpt-x',
        maxContextSize: 100,
        displayName: 'GPT X',
        capabilities: [],
      },
    };
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'none');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 7 });

    await handleFeedbackCommand(feedbackDriver as any);

    expect(harness.auth.submitFeedback).toHaveBeenCalledOnce();
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback ID: 7');
  });

  it('tracks successful feedback submissions only after the request succeeds', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'none');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.track.mockClear();

    await handleFeedbackCommand(feedbackDriver as any);

    expect(harness.auth.submitFeedback).toHaveBeenCalledWith(
      expect.objectContaining({
        content: 'useful feedback',
        sessionId: 'ses-1',
        version: 'kimi-code-0.0.0-test',
        model: 'k2',
      }),
    );
    expect(harness.track).toHaveBeenCalledWith('feedback_submitted', undefined);
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback ID: 3');
  });

  it('submits text feedback before preparing requested attachments', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.listSessions.mockResolvedValueOnce([{ id: 'ses-1', sessionDir: '/tmp/session-a' }] as never);

    const zipPath = await makeExportedSessionZip();
    let resolveExport!: () => void;
    const exportBlocked = new Promise<{
      zipPath: string;
      entries: string[];
      sessionDir: string;
      manifest: Record<string, never>;
    }>((resolve) => {
      resolveExport = () => {
        resolve({
          zipPath,
          entries: ['manifest.json', 'state.json'],
          sessionDir: '/tmp/session-a',
          manifest: {},
        });
      };
    });
    harness.exportSession.mockImplementationOnce(() => exportBlocked);

    let settled = false;
    const command = handleFeedbackCommand(feedbackDriver as any).then(() => {
      settled = true;
    });

    await vi.waitFor(() => {
      expect(harness.exportSession).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'ses-1',
          includeGlobalLog: true,
          version: '0.0.0-test',
        }),
      );
    });
    expect(harness.auth.submitFeedback).toHaveBeenCalledWith(
      expect.objectContaining({ content: 'useful feedback' }),
    );
    expect(harness.auth.submitFeedback.mock.invocationCallOrder[0]).toBeLessThan(
      harness.exportSession.mock.invocationCallOrder[0]!,
    );
    expect(settled).toBe(false);

    resolveExport();
    await command;
  });

  it('waits for the codebase upload to finish before returning', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(scanCodebase).mockReset();
    harness.exportSession.mockReset();
    vi.mocked(packageCodebase).mockReset();
    vi.mocked(uploadArchive).mockReset();
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs+codebase');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.listSessions.mockResolvedValueOnce([
      { id: 'ses-1', sessionDir: '/tmp/session-a' },
    ] as never);

    vi.mocked(scanCodebase).mockResolvedValueOnce({
      root: '/tmp/proj-a',
      files: [{ path: 'keep.ts', size: 4 }],
      fingerprint: 'fp-123',
      usedGitIgnore: false,
    } as any);
    const sessionZipPath = await makeExportedSessionZip();
    harness.exportSession.mockResolvedValueOnce({
      zipPath: sessionZipPath,
      entries: ['manifest.json', 'state.json'],
      sessionDir: '/tmp/session-a',
      manifest: {},
    });
    vi.mocked(packageCodebase).mockResolvedValueOnce({
      path: '/tmp/fake-codebase.zip',
      size: 4,
      sha256: 'hash-123',
      fingerprint: 'fp-123',
      fileCount: 1,
    });

    let resolveCodebaseUpload!: () => void;
    const codebaseUploadBlocked = new Promise<void>((resolve) => {
      resolveCodebaseUpload = resolve;
    });
    vi.mocked(uploadArchive).mockImplementation((_api, archive) => {
      if (archive.path === sessionZipPath) return Promise.resolve();
      return codebaseUploadBlocked;
    });

    let settled = false;
    const command = handleFeedbackCommand(feedbackDriver as any).then(() => {
      settled = true;
    });

    await vi.waitFor(() => {
      expect(uploadArchive).toHaveBeenCalledTimes(2);
    });
    expect(settled).toBe(false);

    resolveCodebaseUpload();
    await command;
    expect(settled).toBe(true);
    expect(uploadArchive).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({ path: sessionZipPath }),
      3,
      { filename: 'session.zip' },
    );
    expect(uploadArchive).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({ path: '/tmp/fake-codebase.zip' }),
      3,
      { filename: 'repo.zip' },
    );
    expect(harness.auth.submitFeedback).toHaveBeenCalledWith(
      expect.not.objectContaining({ info: expect.anything() }),
    );
  });

  it('uploads session logs when codebase scanning fails but the session directory is available', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(scanCodebase).mockReset();
    harness.exportSession.mockReset();
    vi.mocked(packageCodebase).mockReset();
    vi.mocked(uploadArchive).mockReset();
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs+codebase');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.listSessions.mockResolvedValueOnce([{ id: 'ses-1', sessionDir: '/tmp/session-a' }] as never);
    const sessionZipPath = await makeExportedSessionZip();
    vi.mocked(scanCodebase).mockRejectedValueOnce(new Error('scan failed'));
    harness.exportSession.mockResolvedValueOnce({
      zipPath: sessionZipPath,
      entries: ['manifest.json', 'state.json'],
      sessionDir: '/tmp/session-a',
      manifest: {},
    });

    await handleFeedbackCommand(feedbackDriver as any);

    expect(harness.exportSession).toHaveBeenCalledWith(
      expect.objectContaining({ id: 'ses-1', includeGlobalLog: true }),
    );
    expect(packageCodebase).not.toHaveBeenCalled();
    expect(uploadArchive).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({ path: sessionZipPath }),
      3,
      { filename: 'session.zip' },
    );
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback ID: 3');
    expect(transcript).toContain('attachment upload failed');
  });

  it('keeps archive-path creation failures as partial failures without the GitHub fallback', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.listSessions.mockResolvedValueOnce([{ id: 'ses-1', sessionDir: '/tmp/session-a' }] as never);
    vi.mocked(createFeedbackArchivePath).mockRejectedValueOnce(new Error('cache dir not writable'));
    vi.mocked(openUrl).mockClear();

    await handleFeedbackCommand(feedbackDriver as any);

    expect(openUrl).not.toHaveBeenCalled();
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback submitted, thank you!');
    expect(transcript).toContain('Feedback ID: 3');
    expect(transcript).toContain('attachment upload failed');
  });

  it('tells the user when feedback is sent but codebase packaging fails', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(scanCodebase).mockReset();
    vi.mocked(packageCodebase).mockReset();
    harness.exportSession.mockReset();
    vi.mocked(uploadArchive).mockReset();
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs+codebase');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });
    harness.listSessions.mockResolvedValueOnce([{ id: 'ses-1', sessionDir: '/tmp/session-a' }] as never);
    const sessionZipPath = await makeExportedSessionZip();

    vi.mocked(scanCodebase).mockResolvedValueOnce({
      root: '/tmp/proj-a',
      files: [{ path: 'keep.ts', size: 4 }],
      fingerprint: 'fp-123',
      usedGitIgnore: false,
    } as any);
    harness.exportSession.mockResolvedValueOnce({
      zipPath: sessionZipPath,
      entries: ['manifest.json', 'state.json'],
      sessionDir: '/tmp/session-a',
      manifest: {},
    });
    vi.mocked(packageCodebase).mockRejectedValueOnce(new Error('zip failed'));

    await handleFeedbackCommand(feedbackDriver as any);

    const calls = harness.auth.submitFeedback.mock.calls as unknown as Array<[Record<string, unknown>]>;
    expect(calls[0]?.[0]?.['info']).toBeUndefined();
    expect(uploadArchive).toHaveBeenCalledWith(
      expect.any(Object),
      expect.objectContaining({ path: sessionZipPath }),
      3,
      { filename: 'session.zip' },
    );
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback ID: 3');
    expect(transcript).toContain('attachment upload failed');
  });

  it('tells the user when the codebase upload fails', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'logs+codebase');
    harness.auth.submitFeedback.mockResolvedValueOnce({ kind: 'ok', feedbackId: 3 });

    vi.mocked(scanCodebase).mockResolvedValueOnce({
      root: '/tmp/proj-a',
      files: [{ path: 'keep.ts', size: 4 }],
      fingerprint: 'fp-123',
      usedGitIgnore: false,
    } as any);
    vi.mocked(packageCodebase).mockResolvedValueOnce({
      path: '/tmp/fake-codebase.zip',
      size: 4,
      sha256: 'hash-123',
      fingerprint: 'fp-123',
      fileCount: 1,
    });
    vi.mocked(uploadArchive).mockRejectedValueOnce(new Error('upload failed'));

    await handleFeedbackCommand(feedbackDriver as any);

    expect(harness.auth.submitFeedback).toHaveBeenCalledOnce();
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Feedback ID: 3');
    expect(transcript).toContain('attachment upload failed');
  });

  it('shows feedback API error messages without replacing them with HTTP status text', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'none');
    harness.auth.submitFeedback.mockResolvedValueOnce({
      kind: 'error',
      status: 500,
      message: 'backend says no',
    });

    await handleFeedbackCommand(feedbackDriver as any);

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('backend says no');
    expect(transcript).toContain('Opening GitHub Issues as fallback');
    expect(transcript).not.toContain('Failed to submit feedback (HTTP 500).');
  });

  it('falls back to GitHub Issues when the submission request rejects', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => ({ value: 'useful feedback' }));
    vi.mocked(promptFeedbackAttachment).mockImplementation(async () => 'none');
    harness.auth.submitFeedback.mockRejectedValueOnce(new Error('socket hangup'));
    vi.mocked(openUrl).mockClear();

    await expect(handleFeedbackCommand(feedbackDriver as any)).rejects.toThrow('socket hangup');

    expect(openUrl).toHaveBeenCalledWith('https://github.com/MoonshotAI/kimi-code/issues');
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Opening GitHub Issues as fallback');
  });

  it('does not track feedback when the dialog is cancelled', async () => {
    const { driver, harness } = await makeDriver(makeSession());
    const feedbackDriver = driver as unknown as FeedbackDriver;
    vi.mocked(promptFeedbackInput).mockImplementation(async () => undefined);
    harness.track.mockClear();

    await handleFeedbackCommand(feedbackDriver as any);

    expect(harness.auth.submitFeedback).not.toHaveBeenCalled();
    expect(harness.track).not.toHaveBeenCalledWith('feedback_submitted', undefined);
  });

  it('tracks blocked slash commands as invalid without counting them as executed commands', async () => {
    const { driver, harness } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';

    for (const command of ['/new', '/sessions']) {
      harness.track.mockClear();

      driver.handleUserInput(command);
      await Promise.resolve();

      expect(harness.track).toHaveBeenCalledWith('input_command_invalid', {
        reason: 'blocked',
        command: command.slice(1),
      });
      expect(harness.track).not.toHaveBeenCalledWith('input_command', {
        command: command.slice(1),
      });
    }
  });

  it('does not re-enter plan mode after creating a plan-mode session', async () => {
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: 'off',
        permission: 'manual',
        planMode: true,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
      setPlanMode: vi.fn(async () => {
        throw new Error('Already in plan mode');
      }),
    });
    const { driver, harness } = await makeDriver(session);
    harness.createSession.mockClear();
    session.setPlanMode.mockClear();
    driver.state.appState.planMode = true;

    driver.handleUserInput('/new');

    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledWith({
        workDir: '/tmp/proj-a',
        model: 'k2',
        thinking: 'off',
        permission: 'manual',
        planMode: true,
      });
    });
    expect(session.setPlanMode).not.toHaveBeenCalled();
    expect(stripSgr(renderTranscript(driver))).not.toContain('Post-create setup failed');
  });

  it('keeps the new session subscribed when post-create setup fails', async () => {
    const initialSession = makeSession({ id: 'ses-initial' });
    const failedSession = makeSession({
      id: 'ses-failed',
      setPermission: vi.fn(async () => {
        throw new Error('permission setup failed');
      }),
    });
    const createSession = vi
      .fn()
      .mockResolvedValueOnce(initialSession)
      .mockResolvedValueOnce(failedSession);
    const { driver } = await makeDriver(initialSession, { createSession });
    vi.mocked(failedSession.onEvent).mockClear();

    driver.handleUserInput('/new');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain(
        'Post-create setup failed: permission setup failed',
      );
    });
    expect(failedSession.onEvent).toHaveBeenCalledOnce();
  });

  it('tracks Shift-Tab mode switches through the editor handler', async () => {
    const { driver, session, harness } = await makeDriver();
    harness.track.mockClear();

    driver.state.editor.onShiftTab?.();

    await vi.waitFor(() => {
      expect(session.setPlanMode).toHaveBeenCalledWith(true);
    });
    expect(harness.track).toHaveBeenCalledWith('shortcut_plan_toggle', { enabled: true });
    expect(harness.track).toHaveBeenCalledWith('shortcut_mode_switch', { to_mode: 'plan' });
  });

  it('routes /yolo through session permission state without app-layer telemetry duplication', async () => {
    const { driver, session, harness } = await makeDriver();
    harness.track.mockClear();

    driver.handleUserInput('/yolo on');

    await vi.waitFor(() => {
      expect(session.setPermission).toHaveBeenCalledWith('yolo');
    });
    expect(driver.state.appState).toMatchObject({
      permissionMode: 'yolo',
    });
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'yolo' });
    expect(harness.track).not.toHaveBeenCalledWith('yolo_toggle', expect.anything());
  });

  it('hydrates MCP server status after subscribing to session events', async () => {
    const session = makeSession({
      listMcpServers: vi.fn(async () => [
        {
          name: 'local-tools',
          transport: 'stdio',
          status: 'connected',
          toolCount: 2,
        },
        {
          name: 'remote-tools',
          transport: 'http',
          status: 'failed',
          toolCount: 0,
          error: 'connection refused',
        },
      ]),
    });
    const { driver } = await makeDriver(session);

    driver.sessionEventHandler.startSubscription();
    await Promise.resolve();

    expect(session.onEvent).toHaveBeenCalledOnce();
    expect(session.listMcpServers).toHaveBeenCalledOnce();
    const subscribeOrder = session.onEvent.mock.invocationCallOrder[0];
    const snapshotOrder = session.listMcpServers.mock.invocationCallOrder[0];
    if (subscribeOrder === undefined || snapshotOrder === undefined) {
      throw new Error('Expected MCP status sync to subscribe and fetch a snapshot.');
    }
    expect(subscribeOrder).toBeLessThan(snapshotOrder);
    const transcript = renderTranscript(driver);
    expect(transcript).toContain('MCP server "local-tools" connected');
    expect(transcript).toContain('2 tools (stdio)');
    expect(transcript).toContain('MCP server "remote-tools" failed: connection refused');
  });

  it('deduplicates identical MCP status updates while allowing reconnect transitions', async () => {
    const eventListeners: Array<(event: Event) => void> = [];
    const connectedServer = {
      name: 'local-tools',
      transport: 'stdio',
      status: 'connected',
      toolCount: 2,
    };
    const session = makeSession({
      onEvent: vi.fn((listener: (event: Event) => void) => {
        eventListeners.push(listener);
        return vi.fn();
      }),
      listMcpServers: vi.fn(async () => [connectedServer]),
    });
    const { driver } = await makeDriver(session);

    driver.sessionEventHandler.startSubscription();
    await Promise.resolve();
    eventListeners[0]?.({
      type: 'mcp.server.status',
      agentId: 'main',
      sessionId: 'ses-1',
      server: connectedServer,
    } as Event);

    expect(countOccurrences(renderTranscript(driver), 'MCP server "local-tools" connected')).toBe(
      1,
    );

    eventListeners[0]?.({
      type: 'mcp.server.status',
      agentId: 'main',
      sessionId: 'ses-1',
      server: {
        ...connectedServer,
        status: 'pending',
        toolCount: 0,
      },
    } as Event);
    eventListeners[0]?.({
      type: 'mcp.server.status',
      agentId: 'main',
      sessionId: 'ses-1',
      server: connectedServer,
    } as Event);

    expect(countOccurrences(renderTranscript(driver), 'MCP server "local-tools" connected')).toBe(
      2,
    );
  });

  it('does not let a late MCP snapshot overwrite a live status event', async () => {
    const eventListeners: Array<(event: Event) => void> = [];
    let resolveSnapshot: (
      servers: Array<{
        name: string;
        transport: 'stdio' | 'http' | 'sse';
        status: 'pending' | 'connected' | 'failed' | 'disabled';
        toolCount: number;
        error?: string;
      }>,
    ) => void = () => {};
    const snapshot = new Promise((resolve) => {
      resolveSnapshot = resolve;
    });
    const session = makeSession({
      onEvent: vi.fn((listener: (event: Event) => void) => {
        eventListeners.push(listener);
        return vi.fn();
      }),
      listMcpServers: vi.fn(() => snapshot),
    });
    const { driver } = await makeDriver(session);

    driver.sessionEventHandler.startSubscription();
    eventListeners[0]?.({
      type: 'mcp.server.status',
      agentId: 'main',
      sessionId: 'ses-1',
      server: {
        name: 'local-tools',
        transport: 'stdio',
        status: 'connected',
        toolCount: 2,
      },
    } as Event);
    resolveSnapshot([
      {
        name: 'local-tools',
        transport: 'stdio',
        status: 'failed',
        toolCount: 0,
        error: 'stale failure',
      },
    ]);
    await Promise.resolve();

    const transcript = renderTranscript(driver);
    expect(transcript).toContain('MCP server "local-tools" connected');
    expect(transcript).not.toContain('stale failure');
  });

  it('sends normal editor input to the active session and marks the turn as waiting', async () => {
    const { driver, session } = await makeDriver();

    driver.handleUserInput('hello');

    expect(session.prompt).toHaveBeenCalledWith('hello', { promptId: undefined });
    expect(driver.state.appState.streamingPhase).not.toBe('idle');
    expect(driver.state.appState.streamingPhase).toBe('waiting');
    expect(driver.state.livePane.mode).toBe('waiting');
    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'hello',
      }),
    ]);
  });

  it('keeps the transcript intact when undo RPC fails', async () => {
    const session = makeSession({
      undoHistory: vi.fn(async () => {
        throw new Error('core rpc unavailable');
      }),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(1);
    });
    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain(
        'Error: Failed to undo: core rpc unavailable',
      );
    });

    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'hello',
      }),
    ]);
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('hello');
  });

  it('does not duplicate welcome after undoing the only turn', async () => {
    const { driver } = await makeDriver();

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(driver.state.transcriptEntries).toEqual([]);
    });

    expect(
      driver.state.transcriptContainer.children.filter(
        (child) => child instanceof WelcomeComponent,
      ),
    ).toHaveLength(1);
  });

  it('keeps command notices that are not part of the undone context', async () => {
    const { driver, session } = await makeDriver();

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';
    driver.handleUserInput('/auto on');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain('Auto mode: ON');
    });

    driver.handleUserInput('/undo 10');
    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain(
        'Cannot undo 10 prompts; only 1 prompt can be undone in the active context.',
      );
    });

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(1);
    });

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('hello');
    expect(transcript).not.toContain('Cannot undo 10 prompts');
    expect(transcript).toContain('Auto mode: ON');
    expect(driver.state.appState.permissionMode).toBe('auto');
  });

  it('removes turn-scoped background status entries and restores welcome', async () => {
    const { driver, session } = await makeDriver();

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';
    driver.sessionEventHandler.handleEvent(
      {
        type: 'background.task.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        info: {
          kind: 'process',
          taskId: 'bash-bg123456',
          command: 'npm test',
          description: 'Run tests in background',
          status: 'running',
          pid: 1234,
          exitCode: null,
          startedAt: Date.now(),
          endedAt: null,
        },
      } as Event,
      () => {},
    );

    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('bash task started in background');
      expect(transcript).toContain('Run tests in background');
    });

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(1);
    });

    const transcript = stripSgr(renderTranscript(driver));
    expect(driver.state.transcriptEntries).toEqual([]);
    expect(transcript).not.toContain('hello');
    expect(transcript).not.toContain('bash task started in background');
    expect(transcript).not.toContain('Run tests in background');
    expect(
      driver.state.transcriptContainer.children.filter(
        (child) => child instanceof WelcomeComponent,
      ),
    ).toHaveLength(1);
  });

  it('removes AgentSwarm progress from undone turns', async () => {
    const { driver, session } = await makeDriver();
    const sendQueued = vi.fn();

    driver.handleUserInput('launch swarm');
    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts'],
        },
      } as Event,
      sendQueued,
    );

    let transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('launch swarm');
    expect(transcript).toContain('Agent Swarm');
    expect(transcript).toContain('Review changed files');

    driver.state.appState.streamingPhase = 'idle';
    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(1);
    });

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('launch swarm');
    expect(transcript).not.toContain('Agent Swarm');
    expect(transcript).not.toContain('Review changed files');
  });

  it('removes approval notices from undone turns', async () => {
    const { driver, session } = await makeDriver();
    const approvalHandler = vi.mocked(session.setApprovalHandler).mock.calls[0]?.[0] as
      | ((request: ApprovalRequest) => Promise<ApprovalResponse>)
      | undefined;
    if (approvalHandler === undefined) throw new Error('expected approval handler');

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';
    const response = approvalHandler({
      turnId: 1,
      toolCallId: 'call_bash',
      toolName: 'Bash',
      action: 'Run shell command',
      display: {
        kind: 'generic',
        summary: 'Run shell command',
        detail: { command: 'echo ok', description: 'Run a shell command' },
      },
    });

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(ApprovalPanelComponent);
    });
    (driver.state.editorContainer.children[0] as ApprovalPanelComponent).handleInput('1');
    await expect(response).resolves.toMatchObject({ decision: 'approved' });

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain('Approved: Run shell command');
    });

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(1);
    });

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('hello');
    expect(transcript).not.toContain('Approved: Run shell command');
  });

  it('removes debug timing status from undone turns', async () => {
    const { driver, session } = await makeDriver();
    const previousDebug = process.env['KIMI_CODE_DEBUG'];
    process.env['KIMI_CODE_DEBUG'] = '1';
    try {
      driver.handleUserInput('hello');
      driver.sessionEventHandler.handleEvent(
        {
          type: 'turn.step.completed',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          step: 1,
          llmFirstTokenLatencyMs: 120,
          llmStreamDurationMs: 800,
        } as Event,
        () => {},
      );

      await vi.waitFor(() => {
        expect(stripSgr(renderTranscript(driver))).toContain('[Debug]');
      });

      driver.state.appState.streamingPhase = 'idle';
      driver.handleUserInput('/undo');
      await confirmUndoSelection(driver);

      await vi.waitFor(() => {
        expect(session.undoHistory).toHaveBeenCalledWith(1);
      });

      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).not.toContain('hello');
      expect(transcript).not.toContain('[Debug]');
    } finally {
      if (previousDebug === undefined) {
        delete process.env['KIMI_CODE_DEBUG'];
      } else {
        process.env['KIMI_CODE_DEBUG'] = previousDebug;
      }
    }
  });

  it('undoes multiple turns when a count is provided', async () => {
    const { driver, session } = await makeDriver();

    driver.handleUserInput('first');
    driver.state.appState.streamingPhase = 'idle';
    driver.handleUserInput('second');
    driver.state.appState.streamingPhase = 'idle';
    driver.handleUserInput('third');
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo 2');

    await vi.waitFor(() => {
      expect(session.undoHistory).toHaveBeenCalledWith(2);
    });

    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'first',
      }),
    ]);
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('first');
    expect(transcript).not.toContain('second');
    expect(transcript).not.toContain('third');
  });

  it('rejects invalid undo counts without changing context', async () => {
    const { driver, session } = await makeDriver();

    driver.handleUserInput('hello');
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo 0');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain(
        'Error: Usage: /undo [count], where count is a positive integer.',
      );
    });

    expect(session.undoHistory).not.toHaveBeenCalled();
    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'hello',
      }),
    ]);
  });

  it('undoes from the real user turn when the last skill activation came from the model', async () => {
    const { driver } = await makeDriver();

    driver.handleUserInput('hello');
    driver.sessionEventHandler.handleEvent(
      {
        type: 'skill.activated',
        agentId: 'main',
        activationId: 'act-model',
        skillName: 'review',
        trigger: 'model-tool',
      } as Event,
      () => {},
    );
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(driver.state.transcriptEntries).toEqual([]);
    });

    expect(driver.state.transcriptEntries).toEqual([]);
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('hello');
    expect(transcript).not.toContain('review');
  });

  it('keeps user-slash skill activations as undo anchors', async () => {
    const { driver } = await makeDriver();

    driver.handleUserInput('hello');
    driver.sessionEventHandler.handleEvent(
      {
        type: 'skill.activated',
        agentId: 'main',
        activationId: 'act-user',
        skillName: 'review',
        trigger: 'user-slash',
      } as Event,
      () => {},
    );
    driver.state.appState.streamingPhase = 'idle';

    driver.handleUserInput('/undo');
    await confirmUndoSelection(driver);

    await vi.waitFor(() => {
      expect(driver.state.transcriptEntries).toEqual([
        expect.objectContaining({
          kind: 'user',
          content: 'hello',
        }),
      ]);
    });

    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'hello',
      }),
    ]);
    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('hello');
    expect(transcript).not.toContain('review');
  });

  it('deletes a pasted video’s daemon upload when the consuming turn ends', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addVideo('video/mp4', '/tmp/clip.mp4');
    imageStore.completeVideo(attachment, { fileId: 'file-v1' });

    // The paste was uploaded to the daemon file store, so the submission
    // carries a bare `kimi-file://` reference — no local cache copy.
    driver.handleUserInput(`watch ${attachment.placeholder}`);

    const parts = vi.mocked(session.prompt).mock.calls[0]?.[0] as
      | Array<{
          type: string;
          text?: string;
          videoUrl?: { url: string };
        }>
      | undefined;
    expect(parts?.[0]).toEqual({ type: 'text', text: 'watch ' });
    expect(parts?.[1]).toEqual({ type: 'video_url', videoUrl: { url: 'kimi-file://file-v1' } });
    expect(harness.deleteFile).not.toHaveBeenCalled();

    emitTurn(driver, 1);

    // The engine materialized its own session copy at intake, so the staged
    // upload is garbage once the consuming turn ends.
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-v1');
    });
    expect(attachment.fileId).toBeUndefined();
  });

  it('queues a pasted video (kimi-file part) while a turn is streaming', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addVideo('video/mp4', '/tmp/clip.mp4');
    imageStore.completeVideo(attachment, { fileId: 'file-v1' });
    driver.state.appState.streamingPhase = 'waiting';

    driver.handleUserInput(`describe ${attachment.placeholder}`);

    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toHaveLength(1);
    const queued = driver.state.queuedMessages[0];
    const parts = queued?.parts as Array<{ type: string; text?: string; videoUrl?: { url: string } }>;
    expect(parts?.[0]).toEqual({ type: 'text', text: 'describe ' });
    expect(parts?.[1]).toEqual({ type: 'video_url', videoUrl: { url: 'kimi-file://file-v1' } });
    expect(queued?.videoAttachmentIds).toEqual([attachment.id]);

    driver.sendQueuedMessage(session, queued!);
    expect(vi.mocked(session.prompt).mock.calls[0]?.[0]).toEqual(parts);
  });

  it('falls back to retained bytes when a queued image upload expires before dispatch', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(
      new Uint8Array([0xaa, 0xbb]),
      'image/png',
      1,
      1,
      undefined,
      'file-expired',
      1,
    );

    driver.sendQueuedMessage(session, {
      text: `describe ${attachment.placeholder}`,
      parts: [
        { type: 'image_url', imageUrl: { url: 'kimi-file://file-expired' } },
      ],
      imageAttachmentIds: [attachment.id],
    });

    expect(session.prompt).toHaveBeenCalledWith(
      [{ type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } }],
      { promptId: expect.any(String) },
    );
  });

  it('sends pasted image placeholders as image content parts', async () => {
    const { driver, session } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);

    driver.handleUserInput(`describe ${attachment.placeholder}`);

    expect(session.prompt).toHaveBeenCalledWith(
      [
        { type: 'text', text: 'describe ' },
        { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
      ],
      // Staged media rides with a client-chosen prompt id so the consuming
      // turn's `turn.started` can bind the lease exactly.
      { promptId: expect.any(String) },
    );
    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: `describe ${attachment.placeholder}`,
        imageAttachmentIds: [attachment.id],
      }),
    ]);
  });

  it('keeps an image staging upload until the consuming turn ends', async () => {
    const { driver, session, harness } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-1');

    driver.handleUserInput(attachment.placeholder);

    expect(session.prompt).toHaveBeenCalledOnce();
    emitTurn(driver, 1, () => {
      expect(harness.deleteFile).not.toHaveBeenCalled();
    });
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-1');
    });
    expect(attachment.fileId).toBeUndefined();
    expect(attachment.bytes).toEqual(new Uint8Array([0xaa, 0xbb]));
  });

  it('keeps an image staging upload across lazy session creation (v2 engine)', async () => {
    const session = makeSession({ id: 'ses-lazy' });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver, harness } = await makeDriver(session, {}, startupInput);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-lazy');

    driver.handleUserInput(attachment.placeholder);

    // The lease is created at extraction, before the session exists: lazy
    // creation runs setSession mid-dispatch, and the first prompt's lease
    // must survive it — the engine's intake only reads the upload once the
    // prompt lands.
    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith(
        [{ type: 'image_url', imageUrl: { url: 'kimi-file://file-lazy' } }],
        { promptId: expect.any(String) },
      );
    });
    expect(harness.deleteFile).not.toHaveBeenCalled();
    emitTurn(driver, 1, () => {
      expect(harness.deleteFile).not.toHaveBeenCalled();
    });
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-lazy');
    });
  });

  it('still deletes the staging upload when a cache-hint dismissal precedes the resend', async () => {
    const { driver, session, harness } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-dismissed');
    const text = `describe ${attachment.placeholder}`;

    // Simulate a cache-hint interception dismissed back into the editor: the
    // submit's extraction is stashed, then restored with recall semantics
    // (retain consumed, staged upload kept for the restored draft).
    const extraction = extractMediaAttachments(text, imageStore);
    driver.recallStashedMedia(extraction);

    // The restored draft resubmits and re-retains; the consuming turn must
    // still delete the daemon upload — a retain leaked by the dismissal would
    // keep the count above zero and pin the upload until its TTL.
    driver.handleUserInput(text);

    expect(session.prompt).toHaveBeenCalledOnce();
    emitTurn(driver, 1, () => {
      expect(harness.deleteFile).not.toHaveBeenCalled();
    });
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-dismissed');
    });
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
  });

  it('waits briefly for a pending paste ingestion so the submit uses the daemon-ref form', async () => {
    const { driver, session } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    // Simulate a paste whose background ingestion is still uploading when the
    // user hits Enter: the send path waits for it instead of dispatching the
    // inline fallback.
    let finishIngestion!: () => void;
    attachment.pending = new Promise<void>((resolve) => {
      finishIngestion = () => {
        attachment.fileId = 'file-late';
        attachment.fileExpiresAt = Date.now() + 60 * 60 * 1000;
        attachment.pending = undefined;
        resolve();
      };
    });

    driver.handleUserInput(`describe ${attachment.placeholder}`);
    expect(session.prompt).not.toHaveBeenCalled();

    finishIngestion();
    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith(
        [
          { type: 'text', text: 'describe ' },
          { type: 'image_url', imageUrl: { url: 'kimi-file://file-late' } },
        ],
        { promptId: expect.any(String) },
      );
    });
  });

  it('releases staged media exactly once when the prompt dispatch rejects', async () => {
    const session = makeSession({
      prompt: vi.fn(async () => {
        throw new Error('session closed');
      }),
    });
    const { driver, harness } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-reject');

    driver.handleUserInput(attachment.placeholder);

    await vi.waitFor(() => {
      expect(driver.state.appState.streamingPhase).toBe('idle');
    });
    expect(stripSgr(renderTranscript(driver))).toContain('Failed to send: session closed');
    expect(harness.deleteFile).toHaveBeenCalledWith('file-reject');

    // The released lease must not be claimed or deleted again by later turn
    // events or by session close.
    emitTurn(driver, 1);
    await driver.closeSession('test');
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
  });

  it('releases goal-steered staging media when the running goal turn ends', async () => {
    const { driver, session, harness } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-goal');
    // The goal driver's continuation turn (origin system_trigger — it never
    // claims leases through handleTurnStarted) is streaming when the queued
    // steer dispatch lands.
    driver.state.appState.goal = makeActiveGoalSnapshot();
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('7');

    driver.sendQueuedMessage(session, {
      text: attachment.placeholder,
      agentId: 'main',
      parts: [{ type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } }],
      imageAttachmentIds: [attachment.id],
    });

    expect(session.steer).toHaveBeenCalledOnce();
    expect(harness.deleteFile).not.toHaveBeenCalled();
    driver.sessionEventHandler.handleEvent(
      { type: 'turn.ended', agentId: 'main', turnId: 7, reason: 'completed' } as Event,
      () => {},
    );
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-goal');
    });
    expect(attachment.fileId).toBeUndefined();
  });

  it('releases every queued use of shared media when the queue is discarded', async () => {
    process.env['KIMI_CODE_HOME'] = await makeTempHome();
    const { driver, harness } = await makeDriver();
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-queued');
    driver.state.appState.streamingPhase = 'waiting';

    driver.handleUserInput(`first ${attachment.placeholder}`);
    driver.handleUserInput(`second ${attachment.placeholder}`);
    expect(driver.state.queuedMessages).toHaveLength(2);

    driver.clearQueuedMessages();

    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-queued');
    });
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
    expect(attachment.fileId).toBeUndefined();
  });

  it('does not delete shared daemon media while another turn still uses it', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-shared-turn');

    driver.handleUserInput(`first ${attachment.placeholder}`);
    driver.sessionEventHandler.handleEvent(
      { type: 'turn.started', agentId: 'main', turnId: 1, origin: { kind: 'user' } } as Event,
      () => {},
    );
    driver.state.appState.streamingPhase = 'waiting';
    driver.handleUserInput(`second ${attachment.placeholder}`);
    driver.clearQueuedMessages();

    await Promise.resolve();
    expect(harness.deleteFile).not.toHaveBeenCalled();

    driver.sessionEventHandler.handleEvent(
      { type: 'turn.ended', agentId: 'main', turnId: 1, reason: 'completed' } as Event,
      () => {},
    );
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-shared-turn');
    });
  });

  it('queues editor input instead of prompting while a turn is already streaming', async () => {
    const { driver, session, harness } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    harness.track.mockClear();

    driver.handleUserInput('queued message');

    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([{ text: 'queued message', agentId: 'main' }]);
    expect(driver.state.queueContainer.children.length).toBeGreaterThan(0);
    expect(harness.track).toHaveBeenCalledWith('input_queue', undefined);
  });

  it('queues a slash-skill activation while a turn is streaming (like any other input) and activates on drain', async () => {
    const session = makeSession({
      listSkills: vi.fn(async () => [
        {
          name: 'demo',
          description: 'demo skill',
          path: 'builtin://demo',
          source: 'builtin',
          type: 'inline',
        },
      ]),
    });
    const { driver, harness } = await makeDriver(session);
    await (
      driver as unknown as { refreshSkillCommands(s: unknown): Promise<void> }
    ).refreshSkillCommands(session);
    driver.state.appState.streamingPhase = 'waiting';
    harness.track.mockClear();

    driver.handleUserInput('/demo refactor auth and ui');

    expect(session.activateSkill).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      {
        text: '/demo refactor auth and ui',
        agentId: 'main',
        mode: 'skill',
        skillName: 'demo',
        skillArgs: 'refactor auth and ui',
      },
    ]);
    expect(harness.track).toHaveBeenCalledWith('input_queue', undefined);

    // Turn ends: the drain re-enters sendSkillActivation, which now fires.
    driver.state.appState.streamingPhase = 'idle';
    const queued = driver.state.queuedMessages[0]!;
    driver.state.queuedMessages = [];
    driver.sendQueuedMessage(session, queued);

    expect(session.activateSkill).toHaveBeenCalledWith('demo', 'refactor auth and ui');
  });

  it('queues a slash-skill activation while compacting and activates it on drain', async () => {
    const session = makeSession({
      listSkills: vi.fn(async () => [
        {
          name: 'demo',
          description: 'demo skill',
          path: 'builtin://demo',
          source: 'builtin',
          type: 'inline',
        },
      ]),
    });
    const { driver, harness } = await makeDriver(session);
    await (
      driver as unknown as { refreshSkillCommands(s: unknown): Promise<void> }
    ).refreshSkillCommands(session);
    driver.state.appState.isCompacting = true;
    harness.track.mockClear();

    driver.handleUserInput('/demo refactor auth and ui');

    expect(session.activateSkill).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      {
        text: '/demo refactor auth and ui',
        agentId: 'main',
        mode: 'skill',
        skillName: 'demo',
        skillArgs: 'refactor auth and ui',
      },
    ]);
    expect(driver.state.queueContainer.children.length).toBeGreaterThan(0);
    expect(harness.track).toHaveBeenCalledWith('input_queue', undefined);

    driver.state.appState.isCompacting = false;
    const queued = driver.state.queuedMessages[0]!;
    driver.state.queuedMessages = [];
    driver.sendQueuedMessage(session, queued);

    expect(session.activateSkill).toHaveBeenCalledWith('demo', 'refactor auth and ui');
  });

  it('steers fresh input while a goal is active even when the streaming phase is idle', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.goal = makeActiveGoalSnapshot();

    driver.handleUserInput('hello mid-goal');

    expect(session.steer).toHaveBeenCalledWith('hello mid-goal');
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({
        kind: 'user',
        content: 'hello mid-goal',
      }),
    ]);
  });

  it('steers fresh input into the running turn while tower mode is active', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;
    driver.state.appState.streamingPhase = 'waiting';

    driver.handleUserInput('second objective');

    expect(session.steer).toHaveBeenCalledWith('second objective');
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([]);
    expect(driver.state.transcriptEntries).toEqual([
      expect.objectContaining({ kind: 'user', content: 'second objective' }),
    ]);
  });

  it('prompts immediately while tower mode is active and the session is idle', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;

    driver.handleUserInput('first objective');

    expect(session.prompt).toHaveBeenCalledWith('first objective', { promptId: undefined });
    expect(session.steer).not.toHaveBeenCalled();
  });

  it('queues input while tower mode is active but a foreground shell command is running', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;
    driver.state.appState.streamingPhase = 'shell';

    driver.handleUserInput('objective during shell');

    expect(session.steer).not.toHaveBeenCalled();
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'objective during shell', agentId: 'main' },
    ]);
  });

  it('queues input while tower mode is active but compaction is running', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.appState.isCompacting = true;

    driver.handleUserInput('objective during compaction');

    expect(session.steer).not.toHaveBeenCalled();
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'objective during compaction', agentId: 'main' },
    ]);
  });

  it('steers the compaction backlog ahead of fresh input once compaction ends mid-turn', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.appState.isCompacting = true;
    driver.handleUserInput('objective one');
    expect(driver.state.queuedMessages).toHaveLength(1);

    driver.state.appState.isCompacting = false;
    driver.handleUserInput('objective two');

    expect(session.steer).toHaveBeenCalledWith('objective one\n\nobjective two');
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('queues fresh input behind a non-steerable backlog instead of jumping ahead', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.towerMode = true;
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.queuedMessages = [{ text: 'make build', agentId: 'main', mode: 'bash' }];

    driver.handleUserInput('objective two');

    expect(session.steer).not.toHaveBeenCalled();
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'make build', agentId: 'main', mode: 'bash' },
      { text: 'objective two', agentId: 'main' },
    ]);
  });

  it('resets the streaming phase when steering mid-goal input fails', async () => {
    const session = makeSession({
      steer: vi.fn(async () => {
        throw new Error('session closed');
      }),
    });
    const { driver } = await makeDriver(session);
    driver.state.appState.goal = makeActiveGoalSnapshot();

    driver.handleUserInput('hello mid-goal');

    expect(driver.state.appState.streamingPhase).toBe('waiting');
    await vi.waitFor(() => {
      expect(driver.state.appState.streamingPhase).toBe('idle');
    });
    expect(stripSgr(renderTranscript(driver))).toContain('Failed to steer: session closed');
  });

  it('steers a queued message at a turn boundary while a goal is active', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.goal = makeActiveGoalSnapshot();
    driver.state.appState.streamingPhase = 'waiting';
    driver.handleUserInput('mid-goal note');
    expect(driver.state.queuedMessages).toEqual([{ text: 'mid-goal note', agentId: 'main' }]);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      (item) => {
        driver.sendQueuedMessage(session, item);
      },
    );

    await vi.waitFor(() => {
      expect(session.steer).toHaveBeenCalledWith('mid-goal note');
    });
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('prompts the queued message as a new turn when no goal is active', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    driver.handleUserInput('after the turn');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      (item) => {
        driver.sendQueuedMessage(session, item);
      },
    );

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('after the turn', { promptId: undefined });
    });
    expect(session.steer).not.toHaveBeenCalled();
  });

  it('cancels active streaming from Escape and Ctrl-C editor shortcuts', async () => {
    const { driver, session } = await makeDriver();

    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.setText('draft while streaming');
    driver.state.editor.onEscape?.();

    expect(session.cancel).toHaveBeenCalledTimes(1);
    expect(driver.state.editor.getText()).toBe('draft while streaming');

    session.cancel.mockClear();
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.setText('');
    driver.state.editor.onCtrlC?.();

    expect(session.cancel).toHaveBeenCalledTimes(1);
  });

  it('clears streaming editor text before cancelling the active turn on Ctrl-C', async () => {
    const { driver, session } = await makeDriver();

    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.setText('draft while streaming');

    driver.state.editor.onCtrlC?.();

    expect(driver.state.editor.getText()).toBe('');
    expect(session.cancel).not.toHaveBeenCalled();
    expect(driver.state.appState.streamingPhase).toBe('waiting');

    driver.state.editor.onCtrlC?.();

    expect(session.cancel).toHaveBeenCalledTimes(1);
  });

  it('dispatches the next queued message after the active turn ends', async () => {
    vi.useFakeTimers();
    try {
      const { driver } = await makeDriver();
      const sendQueued = vi.fn();
      driver.state.appState.streamingPhase = 'waiting';
      driver.state.appState.streamingStartTime = 1;
      driver.streamingUI.setTurnId('1');
      driver.state.queuedMessages = [{ text: 'next' }];

      driver.sessionEventHandler.handleEvent(
        {
          type: 'turn.ended',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          reason: 'completed',
        } as Event,
        sendQueued,
      );
      await vi.runAllTimersAsync();

      expect(sendQueued).toHaveBeenCalledWith({ text: 'next' });
      expect(driver.state.queuedMessages).toEqual([]);
      expect(driver.state.appState.streamingPhase).toBe('idle');
    } finally {
      vi.useRealTimers();
    }
  });

  it('queues bash input with mode bash while a turn is streaming', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';

    driver.handleUserInput('ls');

    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'ls', agentId: 'main', mode: 'bash' },
    ]);
  });

  it('dispatches a queued bash item to runShellCommand instead of prompt', async () => {
    const runShellCommand = vi.fn(async () => ({ stdout: '', stderr: '', isError: false }));
    const session = makeSession({ runShellCommand });
    const { driver } = await makeDriver(session);

    driver.sendQueuedMessage(session, { text: 'ls', mode: 'bash' });
    await Promise.resolve();

    expect(runShellCommand).toHaveBeenCalledWith(
      'ls',
      expect.objectContaining({ commandId: expect.any(String) }),
    );
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('persists bash input to input history with a leading !', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';

    driver.handleUserInput('ls');

    expect(driver.persistInputHistory).toHaveBeenCalledWith('!ls');
  });

  it('persists normal input to input history', async () => {
    const { driver } = await makeDriver();

    driver.handleUserInput('hello');

    expect(driver.persistInputHistory).toHaveBeenCalledWith('hello');
  });

  it('does not steer queued bash commands, keeping them queued', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.queuedMessages = [
      { text: 'ls', agentId: 'main', mode: 'bash' },
      { text: 'focus on tests', agentId: 'main' },
    ];

    driver.state.editor.onCtrlS?.();

    expect(session.steer).toHaveBeenCalledWith('focus on tests');
    expect(driver.state.queuedMessages).toEqual([
      { text: 'ls', agentId: 'main', mode: 'bash' },
    ]);
  });

  it('does not steer while a shell command is running', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'shell';
    driver.state.queuedMessages = [{ text: 'summarize the output', agentId: 'main' }];

    driver.state.editor.onCtrlS?.();

    expect(session.steer).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([
      { text: 'summarize the output', agentId: 'main' },
    ]);
  });

  it('does not steer the editor draft while it is in bash mode', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.inputMode = 'bash';
    driver.state.editor.setText('ls');

    driver.state.editor.onCtrlS?.();

    expect(session.steer).not.toHaveBeenCalled();
    expect(driver.state.editor.getText()).toBe('ls');
  });

  it('drains a queued image message with its media parts', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    driver.state.appState.streamingPhase = 'waiting';

    driver.handleUserInput(`describe ${attachment.placeholder}`);

    expect(session.prompt).not.toHaveBeenCalled();
    const queued = driver.state.queuedMessages[0];
    expect(queued?.parts).toEqual([
      { type: 'text', text: 'describe ' },
      { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
    ]);

    driver.sendQueuedMessage(session, queued!);

    expect(session.prompt).toHaveBeenCalledWith(
      [
        { type: 'text', text: 'describe ' },
        { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
      ],
      // Staged media rides with a client-chosen prompt id so the consuming
      // turn's `turn.started` can bind the lease exactly.
      { promptId: expect.any(String) },
    );
  });

  it('steers editor image input as media parts', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    driver.state.editor.setText(`check ${attachment.placeholder}`);

    driver.state.editor.onCtrlS?.();

    expect(session.steer).toHaveBeenCalledWith([
      { type: 'text', text: 'check ' },
      { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
    ]);
  });

  it('steers queued image messages with their media parts', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    driver.state.queuedMessages = [
      {
        text: `look ${attachment.placeholder}`,
        agentId: 'main',
        parts: [
          { type: 'text', text: 'look ' },
          { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
        ],
        imageAttachmentIds: [attachment.id],
      },
    ];

    driver.state.editor.onCtrlS?.();

    expect(session.steer).toHaveBeenCalledWith([
      { type: 'text', text: 'look ' },
      { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
    ]);
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('releases every queued use of shared media after a batched steer', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-batched');
    driver.handleUserInput(`first ${attachment.placeholder}`);
    driver.handleUserInput(`second ${attachment.placeholder}`);
    expect(driver.state.queuedMessages).toHaveLength(2);

    driver.state.editor.onCtrlS?.();

    expect(session.steer).toHaveBeenCalledOnce();
    driver.sessionEventHandler.handleEvent(
      { type: 'turn.ended', agentId: 'main', turnId: 1, reason: 'completed' } as Event,
      () => {},
    );
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-batched');
    });
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
    expect(attachment.fileId).toBeUndefined();
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('keeps a shared staged upload alive while another submission still holds it', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-shared');

    // One message referencing the same image twice retains it once; a second
    // queued message retains it again — two retains total.
    driver.handleUserInput(`compare ${attachment.placeholder} with ${attachment.placeholder}`);
    driver.handleUserInput(`and ${attachment.placeholder}`);
    const [first, second] = driver.state.queuedMessages;

    driver.sendQueuedMessage(session, first!);
    emitTurn(driver, 1);
    await new Promise((resolve) => setTimeout(resolve, 0));
    // The first turn consumed the only retain its submission held; the second
    // queued message's retain keeps the upload alive.
    expect(harness.deleteFile).not.toHaveBeenCalled();

    driver.sendQueuedMessage(session, second!);
    emitTurn(driver, 2);
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-shared');
    });
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
  });

  it('keeps staged media when a queued message is recalled into the editor', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = stagedImage(imageStore, 'file-recall');

    driver.handleUserInput(`look ${attachment.placeholder}`);
    expect(driver.state.queuedMessages).toHaveLength(1);

    const recalled = driver.recallLastQueued();
    expect(recalled?.text).toContain(attachment.placeholder);
    await new Promise((resolve) => setTimeout(resolve, 0));
    // Recalled, not discarded: the daemon upload stays staged for the
    // restored draft.
    expect(harness.deleteFile).not.toHaveBeenCalled();
    expect(attachment.fileId).toBe('file-recall');

    // Re-queueing the restored draft reuses the daemon-ref form, and the
    // consuming turn's end releases the upload exactly once.
    driver.handleUserInput(recalled!.text);
    const requeued = driver.state.queuedMessages[0]!;
    expect(requeued.parts).toContainEqual({
      type: 'image_url',
      imageUrl: { url: 'kimi-file://file-recall' },
    });

    driver.sendQueuedMessage(session, requeued);
    emitTurn(driver, 1);
    await vi.waitFor(() => {
      expect(harness.deleteFile).toHaveBeenCalledWith('file-recall');
    });
    expect(harness.deleteFile).toHaveBeenCalledTimes(1);
  });

  it('keeps a recalled video’s daemon upload alive for the restored draft', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addVideo('video/mp4', '/tmp/clip.mp4');
    imageStore.completeVideo(attachment, { fileId: 'file-v1' });
    driver.state.appState.streamingPhase = 'waiting';

    driver.handleUserInput(`describe ${attachment.placeholder}`);
    expect(driver.state.queuedMessages).toHaveLength(1);

    const recalled = driver.recallLastQueued();
    expect(recalled?.text).toContain(attachment.placeholder);
    // The recall consumed the retain but kept the upload, so resubmitting
    // the restored draft re-extracts the same daemon reference — a vanished
    // original source cannot lose the media.
    expect(attachment.fileId).toBe('file-v1');
    expect(harness.deleteFile).not.toHaveBeenCalled();

    driver.handleUserInput(recalled!.text);
    const queued = driver.state.queuedMessages[0];
    const parts = queued?.parts as Array<{ type: string; videoUrl?: { url: string } }>;
    expect(parts?.[1]).toEqual({ type: 'video_url', videoUrl: { url: 'kimi-file://file-v1' } });
    expect(queued?.videoAttachmentIds).toEqual([attachment.id]);
  });

  it('steers consecutive image-only messages without a whitespace-only separator part', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const first = imageStore.addImage(new Uint8Array([0xaa]), 'image/png', 1, 1);
    const second = imageStore.addImage(new Uint8Array([0xbb]), 'image/png', 1, 1);
    const imagePart = (bytes: Uint8Array) => ({
      type: 'image_url' as const,
      imageUrl: { url: `data:image/png;base64,${Buffer.from(bytes).toString('base64')}` },
    });
    driver.state.queuedMessages = [
      {
        text: first.placeholder,
        agentId: 'main',
        parts: [imagePart(first.bytes)],
        imageAttachmentIds: [first.id],
      },
      {
        text: second.placeholder,
        agentId: 'main',
        parts: [imagePart(second.bytes)],
        imageAttachmentIds: [second.id],
      },
    ];

    driver.state.editor.onCtrlS?.();

    // normalizePromptInput rejects whitespace-only text parts, so the
    // item separator must not become a standalone `{type:'text',text:'\n\n'}`
    // between two image parts.
    expect(session.steer).toHaveBeenCalledWith([imagePart(first.bytes), imagePart(second.bytes)]);
  });

  it('steers a media item followed by plain text with a blank-line separator', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    driver.state.queuedMessages = [
      {
        text: `look ${attachment.placeholder}`,
        agentId: 'main',
        parts: [
          { type: 'text', text: 'look ' },
          { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
        ],
        imageAttachmentIds: [attachment.id],
      },
      { text: 'focus on tests', agentId: 'main' },
    ];

    driver.state.editor.onCtrlS?.();

    // The historical '\n\n' item separator merges into the following text
    // part (legal for normalizePromptInput) instead of vanishing after a
    // media part.
    expect(session.steer).toHaveBeenCalledWith([
      { type: 'text', text: 'look ' },
      { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
      { type: 'text', text: '\n\nfocus on tests' },
    ]);
  });

  it('steers plain text followed by a media item with a blank-line separator', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    driver.streamingUI.setTurnId('1');
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const attachment = imageStore.addImage(new Uint8Array([0xaa, 0xbb]), 'image/png', 1, 1);
    driver.state.queuedMessages = [
      { text: 'hello', agentId: 'main' },
      {
        text: attachment.placeholder,
        agentId: 'main',
        parts: [{ type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } }],
        imageAttachmentIds: [attachment.id],
      },
    ];

    driver.state.editor.onCtrlS?.();

    expect(session.steer).toHaveBeenCalledWith([
      { type: 'text', text: 'hello\n\n' },
      { type: 'image_url', imageUrl: { url: 'data:image/png;base64,qrs=' } },
    ]);
  });

  it('shows an error instead of throwing when skill media materialization fails', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    // The pasted video's source file vanished before submit — the cache copy
    // throws, and it must surface as a TUI error, not an unhandled rejection.
    const missing = imageStore.addVideo('video/quicktime', '/tmp/kimi-missing-source.mov');

    (
      driver as unknown as {
        sendSkillActivation(s: unknown, name: string, args: string): void;
      }
    ).sendSkillActivation(session, 'test', `look ${missing.placeholder}`);

    expect(session.activateSkill).not.toHaveBeenCalled();
    expect(stripSgr(renderTranscript(driver))).toContain('Failed to prepare media attachment');
  });

  it('shows an error instead of throwing when plugin command media materialization fails', async () => {
    const activatePluginCommand = vi.fn(async () => {});
    const session = makeSession({ activatePluginCommand });
    const { driver } = await makeDriver(session);
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const missing = imageStore.addVideo('video/mp4', '/tmp/kimi-missing-source.mp4');

    (
      driver as unknown as {
        activatePluginCommand(s: unknown, pluginId: string, command: string, args: string): void;
      }
    ).activatePluginCommand(session, 'plug', 'cmd', missing.placeholder);

    expect(activatePluginCommand).not.toHaveBeenCalled();
    expect(stripSgr(renderTranscript(driver))).toContain('Failed to prepare media attachment');
  });

  it('keeps the queue and draft intact when steer media extraction fails', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    driver.state.appState.model = 'k2';
    driver.state.appState.streamingPhase = 'waiting';
    const imageStore = (driver as unknown as { imageStore: ImageAttachmentStore }).imageStore;
    const missing = imageStore.addVideo('video/quicktime', '/tmp/kimi-missing-source.mov');
    driver.state.queuedMessages = [{ text: 'queued note', agentId: 'main' }];
    driver.state.editor.setText(`look ${missing.placeholder}`);

    driver.state.editor.onCtrlS?.();

    expect(session.steer).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([{ text: 'queued note', agentId: 'main' }]);
    expect(driver.state.editor.getText()).toBe(`look ${missing.placeholder}`);
    expect(stripSgr(renderTranscript(driver))).toContain('Failed to prepare media attachment');
  });

  it('recalls a queued bash command back into bash mode on Up', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.queuedMessages = [{ text: 'ls', agentId: 'main', mode: 'bash' }];
    // After a bash command is queued the editor is reset to prompt mode.
    driver.state.editor.inputMode = 'prompt';
    driver.state.appState.inputMode = 'prompt';

    const handled = driver.state.editor.onUpArrowEmpty?.();

    expect(handled).toBe(true);
    expect(driver.state.editor.getText()).toBe('ls');
    expect(driver.state.editor.inputMode).toBe('bash');
    expect(driver.state.appState.inputMode).toBe('bash');
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('recalls a queued prompt message in prompt mode on Up', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.queuedMessages = [{ text: 'hello', agentId: 'main' }];
    driver.state.editor.inputMode = 'bash';
    driver.state.appState.inputMode = 'bash';

    const handled = driver.state.editor.onUpArrowEmpty?.();

    expect(handled).toBe(true);
    expect(driver.state.editor.getText()).toBe('hello');
    expect(driver.state.editor.inputMode).toBe('prompt');
    expect(driver.state.appState.inputMode).toBe('prompt');
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('echoes a bash command with a $ prompt in the transcript', async () => {
    const runShellCommand = vi.fn(async () => ({ stdout: '', stderr: '', isError: false }));
    const session = makeSession({ runShellCommand });
    const { driver, harness } = await makeDriver(session);
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';

    driver.handleUserInput('ls');
    await Promise.resolve();

    expect(harness.track).toHaveBeenCalledWith('shell_command', undefined);

    const transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('$ ls');
    expect(transcript).not.toContain('! ls');
  });

  it('collapses long ! output to its first 10 rows and expands it with ctrl+o', async () => {
    const stdout = Array.from({ length: 30 }, (_, i) => `row-${String(i + 1).padStart(2, '0')}`).join(
      '\n',
    );
    const runShellCommand = vi.fn(async () => ({ stdout, stderr: '', isError: false }));
    const session = makeSession({ runShellCommand });
    const { driver } = await makeDriver(session);
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';

    driver.handleUserInput('seq 30');
    await vi.waitFor(() => {
      const transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
      expect(transcript).toContain('… (20 more lines, ctrl+o to expand)');
    });

    let transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('row-01');
    expect(transcript).not.toContain('row-11');

    driver.state.editor.onToggleToolExpand?.();
    transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('row-30');
    expect(transcript).not.toContain('more lines');

    driver.state.editor.onToggleToolExpand?.();
    transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('… (20 more lines, ctrl+o to expand)');
    expect(transcript).not.toContain('row-11');
  });

  it('a new ! card inherits an already-on ctrl+o expand state', async () => {
    const stdout = Array.from({ length: 30 }, (_, i) => `row-${String(i + 1).padStart(2, '0')}`).join(
      '\n',
    );
    let resolveCmd!: (value: { stdout: string; stderr: string; isError: boolean }) => void;
    const runShellCommand = vi.fn(
      () =>
        new Promise<{ stdout: string; stderr: string; isError: boolean }>((resolve) => {
          resolveCmd = resolve;
        }),
    );
    const session = makeSession({ runShellCommand });
    const { driver } = await makeDriver(session);
    driver.state.toolOutputExpanded = true;
    driver.state.appState.inputMode = 'bash';
    driver.state.editor.inputMode = 'bash';

    driver.handleUserInput('seq 30');
    await Promise.resolve();
    const outputEntry = driver.state.transcriptEntries.at(-1);
    expect(outputEntry).toBeDefined();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'shell.output',
        agentId: 'main',
        sessionId: 'ses-1',
        commandId: outputEntry!.id,
        update: { kind: 'stdout', text: stdout },
      } as Event,
      vi.fn(),
    );
    let transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('row-01');
    expect(transcript).not.toContain('+25 lines');

    resolveCmd({ stdout, stderr: '', isError: false });
    await vi.waitFor(() => {
      const finished = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
      expect(finished).toContain('row-30');
    });
    transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('row-01');
    expect(transcript).not.toContain('more lines');
  });

  it('renders cron fired events as distinct transcript entries', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'cron.fired',
        agentId: 'main',
        sessionId: 'ses-1',
        origin: {
          kind: 'cron_job',
          jobId: 'deadbeef',
          cron: '* * * * *',
          recurring: true,
          coalescedCount: 1,
          stale: false,
        },
        prompt: 'Remind the user: this is a once-per-minute reminder',
      } as Event,
      vi.fn(),
    );

    const entry = driver.state.transcriptEntries.at(-1);
    expect(entry).toMatchObject({
      kind: 'cron',
      content: 'Remind the user: this is a once-per-minute reminder',
      cronData: {
        jobId: 'deadbeef',
        cron: '* * * * *',
        coalescedCount: 1,
        stale: false,
      },
    });

    const transcript = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
    expect(transcript).toContain('Scheduled reminder fired');
    expect(transcript).toContain('* * * * *');
    expect(transcript).toContain('Remind the user: this is a once-per-minute reminder');
    expect(transcript).not.toContain('<cron-fire');
  });

  it('keeps the previous turn’s final answer mounted when a cron turn completes', async () => {
    const { driver } = await makeDriver();
    const emit = (event: Event) => driver.sessionEventHandler.handleEvent(event, () => {});
    let entrySeq = 0;
    const entry = (kind: 'user' | 'assistant', content: string, turnId?: string) => {
      entrySeq += 1;
      driver.appendTranscriptEntry({
        id: `cron-fold-${entrySeq}`,
        kind,
        turnId,
        renderMode: kind === 'assistant' ? 'markdown' : 'plain',
        content,
      });
    };

    entry('user', 'what is the answer?');
    emit({ type: 'turn.started', agentId: 'main', turnId: 1, origin: { kind: 'user' } } as Event);
    entry('assistant', 'working on it', '1');
    entry('assistant', 'FINAL-ANSWER', '1');
    emit({ type: 'turn.ended', agentId: 'main', turnId: 1, reason: 'completed' } as Event);

    expect(stripSgr(renderTranscript(driver))).toContain('FINAL-ANSWER');

    const cronOrigin = {
      kind: 'cron_job',
      jobId: 'job-42',
      cron: '*/5 * * * *',
      recurring: true,
      coalescedCount: 1,
      stale: false,
    };
    emit({ type: 'turn.started', agentId: 'main', turnId: 2, origin: cronOrigin } as Event);
    emit({ type: 'cron.fired', agentId: 'main', origin: cronOrigin, prompt: 'inspect the fleet' } as Event);
    entry('assistant', 'cron report part one', '2');
    entry('assistant', 'cron report final', '2');
    emit({ type: 'turn.ended', agentId: 'main', turnId: 2, reason: 'completed' } as Event);

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('cron report final');
    expect(transcript).toContain('FINAL-ANSWER');
  });

  it('keeps the in-flight answer mounted when a cron fires mid-turn', async () => {
    const { driver } = await makeDriver();
    const emit = (event: Event) => driver.sessionEventHandler.handleEvent(event, () => {});
    let entrySeq = 0;
    const entry = (kind: 'user' | 'assistant', content: string, turnId?: string) => {
      entrySeq += 1;
      driver.appendTranscriptEntry({
        id: `cron-buffered-${entrySeq}`,
        kind,
        turnId,
        renderMode: kind === 'assistant' ? 'markdown' : 'plain',
        content,
      });
    };

    entry('user', 'what is the answer?');
    emit({ type: 'turn.started', agentId: 'main', turnId: 1, origin: { kind: 'user' } } as Event);
    entry('assistant', 'FINAL-ANSWER', '1');

    const cronOrigin = {
      kind: 'cron_job',
      jobId: 'job-42',
      cron: '*/5 * * * *',
      recurring: true,
      coalescedCount: 1,
      stale: false,
    };
    emit({ type: 'cron.fired', agentId: 'main', origin: cronOrigin, prompt: 'inspect the fleet' } as Event);
    entry('assistant', 'cron report part one', '1');
    entry('assistant', 'cron report final', '1');
    emit({ type: 'turn.ended', agentId: 'main', turnId: 1, reason: 'completed' } as Event);

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('FINAL-ANSWER');
    expect(transcript).toContain('cron report final');
  });

  it('coalesces assistant delta component updates', async () => {
    vi.useFakeTimers();
    try {
      const { driver } = await makeDriver();
      vi.mocked(driver.state.ui.requestRender).mockClear();

      driver.sessionEventHandler.handleEvent(
        {
          type: 'assistant.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          delta: 'a',
        } as Event,
        vi.fn(),
      );
      const component = driver.streamingUI.getStreamingBlockComponent();
      if (component === undefined) throw new Error('expected streaming component');
      const updateSpy = vi.spyOn(component, 'updateContent');

      driver.sessionEventHandler.handleEvent(
        {
          type: 'assistant.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          delta: 'b',
        } as Event,
        vi.fn(),
      );
      driver.sessionEventHandler.handleEvent(
        {
          type: 'assistant.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          delta: 'c',
        } as Event,
        vi.fn(),
      );

      expect(updateSpy).not.toHaveBeenCalled();
      await vi.runOnlyPendingTimersAsync();

      expect(updateSpy).toHaveBeenCalledTimes(1);
      expect(updateSpy).toHaveBeenLastCalledWith('abc', { transient: true });
    } finally {
      vi.useRealTimers();
    }
  });

  it('flushes pending assistant deltas before turn completion', async () => {
    vi.useFakeTimers();
    try {
      const { driver } = await makeDriver();
      const sendQueued = vi.fn();
      driver.state.appState.streamingPhase = 'waiting';

      driver.sessionEventHandler.handleEvent(
        {
          type: 'assistant.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          delta: 'done',
        } as Event,
        sendQueued,
      );
      driver.sessionEventHandler.handleEvent(
        {
          type: 'turn.ended',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          reason: 'completed',
        } as Event,
        sendQueued,
      );

      expect(stripSgr(renderTranscript(driver))).toContain('done');
    } finally {
      vi.useRealTimers();
    }
  });

  it('coalesces streaming tool-call argument preview updates', async () => {
    vi.useFakeTimers();
    try {
      const { driver } = await makeDriver();
      driver.streamingUI.setTurnId('1');
      driver.streamingUI.setStep(1);

      driver.sessionEventHandler.handleEvent(
        {
          type: 'tool.call.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          toolCallId: 'call_bash',
          name: 'Bash',
          argumentsPart: '{"command":"echo hi"}',
        } as Event,
        vi.fn(),
      );

      expect(driver.streamingUI.getToolComponent('call_bash')).toBeUndefined();
      expect(driver.streamingUI.hasActiveToolCall('call_bash')).toBe(false);

      await vi.runOnlyPendingTimersAsync();

      expect(driver.streamingUI.getToolComponent('call_bash')).toBeDefined();
      expect(driver.streamingUI.getActiveToolCall('call_bash')?.args).toMatchObject({
        command: 'echo hi',
      });
    } finally {
      vi.useRealTimers();
    }
  });

  it('cancels manual compaction from the editor', async () => {
    const { driver, session } = await makeDriver();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.started',
        agentId: 'main',
        sessionId: 'ses-1',
        trigger: 'manual',
      } as Event,
      vi.fn(),
    );

    driver.state.editor.onEscape?.();

    expect(session.cancelCompaction).toHaveBeenCalledTimes(1);

    session.cancelCompaction.mockClear();
    driver.state.appState.isCompacting = true;
    driver.state.editor.onCtrlC?.();

    expect(session.cancelCompaction).toHaveBeenCalledTimes(1);
  });

  it('clears editor text before cancelling compaction on Ctrl-C', async () => {
    const { driver, session } = await makeDriver();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.started',
        agentId: 'main',
        sessionId: 'ses-1',
        trigger: 'manual',
      } as Event,
      vi.fn(),
    );
    driver.state.editor.setText('draft while compacting');

    driver.state.editor.onCtrlC?.();

    expect(driver.state.editor.getText()).toBe('');
    expect(session.cancelCompaction).not.toHaveBeenCalled();
    expect(driver.state.appState.isCompacting).toBe(true);

    driver.state.editor.onCtrlC?.();

    expect(session.cancelCompaction).toHaveBeenCalledTimes(1);
  });

  it('dispatches the next queued message after compaction is cancelled', async () => {
    vi.useFakeTimers();
    try {
      const { driver } = await makeDriver();
      const sendQueued = vi.fn();
      driver.sessionEventHandler.handleEvent(
        {
          type: 'compaction.started',
          agentId: 'main',
          sessionId: 'ses-1',
          trigger: 'manual',
        } as Event,
        sendQueued,
      );
      driver.state.queuedMessages = [{ text: 'next' }];

      driver.sessionEventHandler.handleEvent(
        {
          type: 'compaction.cancelled',
          agentId: 'main',
          sessionId: 'ses-1',
        } as Event,
        sendQueued,
      );
      await vi.runAllTimersAsync();

      expect(driver.state.appState.isCompacting).toBe(false);
      expect(driver.state.appState.streamingPhase).toBe('idle');
      expect(driver.state.queuedMessages).toEqual([]);
      expect(sendQueued).toHaveBeenCalledWith({ text: 'next' });
      expect(driver.state.transcriptContainer.render(120).map(stripSgr).join('\n')).toContain(
        'Compaction cancelled',
      );
    } finally {
      vi.useRealTimers();
    }
  });

  it('stores the live compaction summary and expands it with tool output expansion', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.started',
        agentId: 'main',
        sessionId: 'ses-1',
        trigger: 'manual',
      } as Event,
      sendQueued,
    );

    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.completed',
        agentId: 'main',
        sessionId: 'ses-1',
        result: {
          summary: 'Keep the src/tui compaction notes.',
          compactedCount: 4,
          tokensBefore: 120,
          tokensAfter: 24,
        },
      } as Event,
      sendQueued,
    );

    const collapsed = driver.state.transcriptContainer.render(120).map(stripSgr).join('\n');
    expect(collapsed).toContain('Compaction complete');
    expect(collapsed).not.toContain('Keep the src/tui compaction notes.');

    driver.state.editor.onToggleToolExpand?.();

    const expanded = driver.state.transcriptContainer.render(120).map(stripSgr).join('\n');
    expect(driver.state.toolOutputExpanded).toBe(true);
    expect(expanded).toContain('Keep the src/tui compaction notes.');
  });

  it('honors existing tool output expansion when a compaction block is created', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.state.editor.onToggleToolExpand?.();
    expect(driver.state.toolOutputExpanded).toBe(true);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.started',
        agentId: 'main',
        sessionId: 'ses-1',
        trigger: 'manual',
      } as Event,
      sendQueued,
    );

    driver.sessionEventHandler.handleEvent(
      {
        type: 'compaction.completed',
        agentId: 'main',
        sessionId: 'ses-1',
        result: {
          summary: 'Keep the src/tui compaction notes.',
          compactedCount: 4,
          tokensBefore: 120,
          tokensAfter: 24,
        },
      } as Event,
      sendQueued,
    );

    const transcript = driver.state.transcriptContainer.render(120).map(stripSgr).join('\n');
    expect(transcript).toContain('Compaction complete');
    expect(transcript).toContain('Keep the src/tui compaction notes.');
  });

  it('renders an error instead of prompting when no model is selected', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.model = '';

    driver.handleUserInput('hello');

    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.transcriptContainer.render(120).join('\n')).toContain('LLM not set');
  });

  it('dispatches /init to the active session and clears busy state after completion', async () => {
    let resolveInit: (() => void) | undefined;
    const session = makeSession({
      init: vi.fn(
        () =>
          new Promise<void>((resolve) => {
            resolveInit = resolve;
          }),
      ),
    });
    const { driver, harness } = await makeDriver(session);
    harness.track.mockClear();

    driver.handleUserInput('/init');

    await vi.waitFor(() => {
      expect(session.init).toHaveBeenCalledTimes(1);
    });
    expect(session.prompt).not.toHaveBeenCalled();
    expect(driver.state.appState.streamingPhase).not.toBe('idle');
    expect(driver.state.livePane.mode).toBe('waiting');

    resolveInit?.();

    await vi.waitFor(() => {
      expect(driver.state.appState.streamingPhase).toBe('idle');
    });
    expect(driver.state.livePane.mode).toBe('idle');
    expect(harness.track).toHaveBeenCalledWith('init_complete', undefined);
  });

  it('starts /btw through a forked side agent without changing the main busy state', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    harness.track.mockClear();
    driver.state.appState.streamingPhase = 'composing';
    driver.state.livePane.mode = 'thinking';

    driver.handleUserInput('/btw What are you working on right now?');

    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledWith();
    });
    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('What are you working on right now?');
    });
    expect(session.steer).not.toHaveBeenCalled();
    expect(driver.state.appState.streamingPhase).toBe('composing');
    expect(driver.state.livePane.mode).toBe('thinking');
    expect(harness.track).toHaveBeenCalledWith('input_command', { command: 'btw' });
  });

  it('opens /btw without a question and sends the first panel input to a side agent', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/btw');

    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledWith();
    });
    expect(session.prompt).not.toHaveBeenCalled();
    expect(stripSgr(renderBtwPanel(driver))).toContain('Ready for a side question…');

    driver.handleUserInput('What are you working on right now?');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('What are you working on right now?');
    });
    expect(session.steer).not.toHaveBeenCalled();
    expect(stripSgr(renderBtwPanel(driver))).toContain('Q: What are you working on right now?');
  });

  it('sends /btw panel input with inline skills via promptWithSkills (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/btw');
    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledWith();
    });
    expect(stripSgr(renderBtwPanel(driver))).toContain('Ready for a side question…');

    driver.handleUserInput('check /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith('check /skill:review', [
        { name: 'review' },
      ]);
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('activates inline skills in the initial /btw prompt (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/btw check this /skill:review');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith('check this /skill:review', [
        { name: 'review' },
      ]);
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('activates a leading skill token in the initial /btw prompt (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/btw /skill:review check this');

    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith('/skill:review check this', [
        { name: 'review' },
      ]);
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('keeps /btw as the leading command when its prompt mentions multiple skills (v2 engine)', async () => {
    const session = makeSession({
      id: 'ses-lazy',
      listSkills: vi.fn(async () => [
        { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
        { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
      ]),
    });
    const startupInput: KimiTUIStartupInput = {
      ...makeStartupInput(),
      engineV2: true,
      cliOptions: { ...makeStartupInput().cliOptions, model: 'k2' },
    };
    const { driver } = await makeDriver(
      session,
      {
        listWorkspaceSkills: vi.fn(async () => [
          { name: 'review', description: 'Review skill', path: '/tmp/review', source: 'user' },
          { name: 'security', description: 'Security skill', path: '/tmp/security', source: 'user' },
        ]),
        listPluginCommands: vi.fn(async () => []),
      },
      startupInput,
    );
    await (
      driver as unknown as { refreshSkillCommands(): Promise<void> }
    ).refreshSkillCommands();

    driver.handleUserInput('/btw check /skill:review /skill:security');

    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledWith();
    });
    await vi.waitFor(() => {
      expect(session.promptWithSkills).toHaveBeenCalledWith('check /skill:review /skill:security', [
        { name: 'review' },
        { name: 'security' },
      ]);
    });
    expect(session.prompt).not.toHaveBeenCalled();
  });

  it('cancels an unused /btw side agent when closing an empty panel', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/btw');

    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledWith();
    });
    driver.state.editor.onEscape?.();

    expect(session.cancel).toHaveBeenCalledOnce();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
  });

  it('renders /btw output in a dedicated panel instead of an Agent tool card', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session, 'What are you working on right now?');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'I am implementing the dedicated /btw panel.',
      } as Event,
      () => {},
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    expect(driver.state.btwPanelContainer.children).toHaveLength(2);
    expect(driver.state.btwPanelContainer.render(120)[0]?.trim()).toBe('');
    expect(getMountedBtwPanel(driver).isRunning()).toBe(false);
    expect(driver.state.editor.focused).toBe(true);

    const transcript = stripSgr(renderTranscript(driver));
    const panel = stripSgr(renderBtwPanel(driver));
    const editorTopBorder = stripSgr(driver.state.editor.render(80)[0] ?? '');
    expect(panel).toContain('BTW ─ Esc close');
    expect(panel).not.toContain('ctrl+o expand');
    expect(editorTopBorder.startsWith('├')).toBe(true);
    expect(editorTopBorder.endsWith('┤')).toBe(true);

    driver.state.editor.handleInput('/');
    const highlightedEditorTopBorder = stripSgr(driver.state.editor.render(80)[0] ?? '');
    expect(highlightedEditorTopBorder.startsWith('╭')).toBe(true);
    expect(highlightedEditorTopBorder.endsWith('╮')).toBe(true);
    expect(panel).not.toContain('BTW done');
    expect(panel).not.toContain('BTW running');
    expect(panel).not.toContain('BTW failed');
    expect(panel).not.toContain('Ask:');
    expect(panel).not.toContain('Type follow-up');
    expect(panel).toContain('Q: What are you working on right now?');
    expect(panel).toContain('I am implementing the dedicated /btw panel.');
    expect(panel).not.toContain('Agent');
    expect(transcript).not.toContain('BTW');
    expect(transcript).not.toContain('Esc close');
    expect(transcript).not.toContain('I am implementing the dedicated /btw panel.');
  });

  it('keeps the /btw panel closest to the input after later transcript output', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'side answer',
      } as Event,
      () => {},
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        origin: { kind: 'user' },
      } as Event,
      () => {},
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        delta: 'main answer after btw',
      } as Event,
      () => {},
    );
    driver.streamingUI.flushNow();

    const transcript = stripSgr(renderTranscript(driver));
    const panel = stripSgr(renderBtwPanel(driver));
    const rootChildren = driver.state.ui.children;
    expect(rootChildren.indexOf(driver.state.btwPanelContainer)).toBe(
      rootChildren.indexOf(driver.state.editorContainer) - 1,
    );
    expect(transcript).toContain('main answer after btw');
    expect(transcript).not.toContain('side answer');
    expect(panel).toContain('BTW');
    expect(panel).not.toContain('BTW done');
    expect(panel).not.toContain('BTW running');
    expect(panel).not.toContain('BTW failed');
    expect(panel).toContain('side answer');
    expect(panel).not.toContain('main answer after btw');
  });

  it('renders only the tail of /btw thinking output', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: ['line1', 'line2', 'line3', 'line4', 'line5', 'line6', 'line7'].join('\n'),
      } as Event,
      () => {},
    );

    const transcript = stripSgr(renderTranscript(driver));
    const panel = stripSgr(renderBtwPanel(driver));
    expect(transcript).not.toContain('line7');
    expect(panel).not.toContain('line1');
    expect(panel).not.toContain('line5');
    expect(panel).toContain('line6');
    expect(panel).toContain('line7');
  });

  it('renders /btw body at its actual content height when under the cap', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    const lines = getMountedBtwPanel(driver).render(80).map(stripSgr);
    expect(lines).toHaveLength(3);
    expect(lines.join('\n')).toContain('Q: side question');
    expect(lines.join('\n')).toContain('Waiting for answer…');
  });

  it('keeps /btw panel height stable when final output is shorter than thinking', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'thinking line 1\nthinking line 2',
      } as Event,
      () => {},
    );

    const mountedPanel = getMountedBtwPanel(driver);
    const thinkingLines = mountedPanel.render(80).map(stripSgr);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'final answer',
      } as Event,
      () => {},
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    const finalLines = mountedPanel.render(80).map(stripSgr);
    expect(finalLines).toHaveLength(thinkingLines.length);
    expect(finalLines.join('\n')).toContain('final answer');
    expect(finalLines.at(-1)).toMatch(/^│\s+│$/);
  });

  it('caps /btw height to one-third of the terminal and supports scrolling', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    setTerminalRows(driver, 15);
    await openBtwPanel(driver, session, 'question 1');

    const panel = getMountedBtwPanel(driver);
    panel.appendAnswer('answer 1');
    panel.markDone();
    for (let i = 2; i <= 8; i++) {
      panel.submit(`question ${String(i)}`);
      panel.appendAnswer(`answer ${String(i)}`);
      panel.markDone();
    }

    const collapsed = panel.render(80).map(stripSgr);
    expect(collapsed).toHaveLength(5);
    expect(collapsed.join('\n')).toContain('BTW ─ Esc close · ↑↓ scroll');
    expect(collapsed.join('\n')).not.toContain('ctrl+o expand');
    expect(collapsed.join('\n')).toContain('question 8');
    expect(collapsed.join('\n')).toContain('answer 8');
    expect(collapsed.join('\n')).not.toContain('question 1');

    driver.state.editor.setText('draft main input');
    const collapsedWithInput = panel.render(80).map(stripSgr);
    expect(collapsedWithInput.join('\n')).toContain('BTW ─ Esc close');
    expect(collapsedWithInput.join('\n')).not.toContain('↑↓ scroll');
    driver.state.editor.setText('');

    const requestRender = vi.mocked(driver.state.ui.requestRender);
    requestRender.mockClear();
    for (let i = 0; i < 20; i++) {
      driver.state.editor.handleInput('\u001B[A');
    }
    const scrolledUp = panel.render(80).map(stripSgr);
    expect(requestRender).toHaveBeenCalled();
    expect(scrolledUp.join('\n')).toContain('question 1');
    expect(scrolledUp.join('\n')).not.toContain('answer 8');

    panel.appendAnswer('\nstreamed tail while scrolled');
    expect(panel.render(80).map(stripSgr)).toEqual(scrolledUp);

    requestRender.mockClear();
    for (let i = 0; i < 20; i++) {
      driver.state.editor.handleInput('\u001B[B');
    }
    const scrolledDown = panel.render(80).map(stripSgr);
    expect(requestRender).toHaveBeenCalled();
    expect(scrolledDown.join('\n')).toContain('question 8');
    expect(scrolledDown.join('\n')).toContain('answer 8');
    expect(scrolledDown.join('\n')).toContain('streamed tail while scrolled');

    setTerminalRows(driver, 4);
    const tiny = panel.render(80).map(stripSgr);
    expect(tiny).toHaveLength(3);
    expect(tiny.join('\n')).not.toContain('ctrl+o expand');
    expect(tiny.join('\n')).toContain('answer 8');

    requestRender.mockClear();
    driver.state.editor.onToggleToolExpand?.();
    expect(driver.state.toolOutputExpanded).toBe(true);
    expect(panel.render(80).map(stripSgr)).toEqual(tiny);
  });

  it('cancels and closes a running /btw panel on Escape', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    const panel = getMountedBtwPanel(driver);
    expect(panel.isRunning()).toBe(true);
    expect(driver.state.editor.focused).toBe(true);

    const requestRender = vi.mocked(driver.state.ui.requestRender);
    requestRender.mockClear();
    driver.state.editor.onEscape?.();

    expect(session.cancel).toHaveBeenCalledOnce();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
    expect(requestRender.mock.calls.at(-1)).toEqual([true]);
    const editorTopBorder = stripSgr(driver.state.editor.render(80)[0] ?? '');
    expect(editorTopBorder.startsWith('╭')).toBe(true);
    expect(editorTopBorder.endsWith('╮')).toBe(true);
    expect(driver.state.editor.focused).toBe(true);
  });

  it('cancels a running /btw panel on Ctrl-C without closing it or cancelling main streaming', async () => {
    const session = makeSession();
    const { driver, harness } = await makeDriver(session);
    const cancelledAgentIds: string[] = [];
    session.cancel.mockImplementation(async () => {
      cancelledAgentIds.push(harness.interactiveAgentId);
    });
    await openBtwPanel(driver, session);
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.setText('draft main input');

    const panel = getMountedBtwPanel(driver);
    expect(panel.isRunning()).toBe(true);

    driver.state.editor.onCtrlC?.();

    expect(session.cancel).toHaveBeenCalledOnce();
    expect(cancelledAgentIds).toEqual(['agent-btw']);
    expect(getMountedBtwPanel(driver)).toBe(panel);
    expect(driver.state.btwPanelContainer.children).toHaveLength(2);
    expect(driver.state.editor.focused).toBe(true);
    expect(driver.state.editor.getText()).toBe('draft main input');
    expect(driver.state.appState.streamingPhase).toBe('waiting');
  });

  it('preserves rendered /btw output when a running panel is cancelled', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);
    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'partial side answer',
      } as Event,
      () => {},
    );

    driver.state.editor.onCtrlC?.();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'cancelled',
      } as Event,
      () => {},
    );

    const panel = stripSgr(renderBtwPanel(driver));
    expect(panel).toContain('partial side answer');
    expect(panel).toContain('Interrupted by user');
  });

  it('cancels a running /btw panel when starting a new session clears it', async () => {
    const initialSession = makeSession({ id: 'ses-initial' });
    const nextSession = makeSession({ id: 'ses-next' });
    const createSession = vi
      .fn()
      .mockResolvedValueOnce(initialSession)
      .mockResolvedValueOnce(nextSession);
    const { driver, harness } = await makeDriver(initialSession, { createSession });
    const cancelledAgentIds: string[] = [];
    initialSession.cancel.mockImplementation(async () => {
      cancelledAgentIds.push(harness.interactiveAgentId);
    });
    await openBtwPanel(driver, initialSession);

    driver.handleUserInput('/new');

    await vi.waitFor(() => {
      expect(driver.getCurrentSessionId()).toBe('ses-next');
    });
    expect(initialSession.cancel).toHaveBeenCalledOnce();
    expect(cancelledAgentIds).toEqual(['agent-btw']);
    expect(nextSession.cancel).not.toHaveBeenCalled();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
  });

  it('closes a completed /btw panel on Ctrl-C without cancelling main streaming', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );
    driver.state.appState.streamingPhase = 'waiting';
    driver.state.editor.setText('draft main input');

    expect(getMountedBtwPanel(driver).isRunning()).toBe(false);

    driver.state.editor.onCtrlC?.();

    expect(session.cancel).not.toHaveBeenCalled();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
    expect(driver.state.editor.focused).toBe(true);
    expect(driver.state.editor.getText()).toBe('draft main input');
    expect(driver.state.appState.streamingPhase).toBe('waiting');
  });

  it('closes a completed /btw panel on Escape without cancelling it', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    const panel = getMountedBtwPanel(driver);
    expect(panel.isRunning()).toBe(false);
    expect(driver.state.editor.focused).toBe(true);

    driver.state.editor.onEscape?.();

    expect(session.cancel).not.toHaveBeenCalled();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
    expect(driver.state.editor.focused).toBe(true);
  });

  it('sends follow-up /btw input through ordinary prompt on the same side agent', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session, 'first question');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    const panel = getMountedBtwPanel(driver);
    expect(panel.isRunning()).toBe(false);
    driver.handleUserInput('follow up');

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('follow up');
    });
    expect(session.prompt).toHaveBeenCalledTimes(2);
    expect(driver.state.btwPanelContainer.children).toHaveLength(2);
    expect(driver.state.editor.focused).toBe(true);
  });

  it('keeps main input pointed at /btw while the panel is open', async () => {
    let resolveBtwPrompt: (() => void) | undefined;
    const session = makeSession({
      prompt: vi.fn(
        () =>
          new Promise<void>((resolve) => {
            resolveBtwPrompt = resolve;
          }),
      ),
    });
    const { driver, harness } = await makeDriver(session);

    await openBtwPanel(driver, session, 'slow side question');

    expect(harness.interactiveAgentId).toBe('main');
    driver.handleUserInput('follow-up while btw prompt is pending');
    driver.handleUserInput('another follow-up while btw prompt is pending');

    expect(session.prompt).toHaveBeenCalledTimes(1);
    expect(driver.state.queuedMessages).toEqual([]);
    expect(driver.state.editor.getText()).toBe('another follow-up while btw prompt is pending');
    expect(stripSgr(renderTranscript(driver))).not.toContain(
      'Wait for /btw to finish before sending another question.',
    );
    expect(
      countOccurrences(
        stripSgr(renderBtwPanel(driver)),
        'Wait for /btw to finish before sending another question.',
      ),
    ).toBe(2);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-btw',
        sessionId: 'ses-1',
        turnId: 0,
        reason: 'completed',
      } as Event,
      () => {},
    );

    expect(stripSgr(renderBtwPanel(driver))).not.toContain(
      'Wait for /btw to finish before sending another question.',
    );

    resolveBtwPrompt?.();
  });

  it('replaces a running /btw panel when another /btw command is submitted', async () => {
    const session = makeSession({
      startBtw: vi.fn()
        .mockResolvedValueOnce('agent-btw-1')
        .mockResolvedValueOnce('agent-btw-2'),
    });
    const { driver } = await makeDriver(session);
    await openBtwPanel(driver, session, 'first question');

    const firstPanel = getMountedBtwPanel(driver);
    expect(firstPanel.isRunning()).toBe(true);

    driver.handleUserInput('/btw second question');

    await vi.waitFor(() => {
      expect(session.startBtw).toHaveBeenCalledTimes(2);
    });
    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('second question');
    });

    const secondPanel = getMountedBtwPanel(driver);
    expect(secondPanel).not.toBe(firstPanel);
    expect(session.cancel).toHaveBeenCalledTimes(1);
    expect(session.prompt).toHaveBeenCalledTimes(2);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw-1',
        sessionId: 'ses-1',
        turnId: 0,
        delta: 'answer from old side agent',
      } as Event,
      () => {},
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-btw-2',
        sessionId: 'ses-1',
        turnId: 1,
        delta: 'answer from new side agent',
      } as Event,
      () => {},
    );

    const renderedPanel = stripSgr(renderBtwPanel(driver));
    expect(renderedPanel).not.toContain('answer from old side agent');
    expect(renderedPanel).toContain('answer from new side agent');
  });

  it('does not run /btw without a selected model', async () => {
    const { driver, session } = await makeDriver();

    driver.state.appState.model = '';
    driver.handleUserInput('/btw');
    expect(session.startBtw).not.toHaveBeenCalled();
    expect(driver.state.btwPanelContainer.children).toHaveLength(0);
    expect(stripSgr(renderTranscript(driver))).toContain('LLM not set');

    driver.handleUserInput('/btw What are you doing now?');

    expect(session.startBtw).not.toHaveBeenCalled();
    expect(stripSgr(renderTranscript(driver))).toContain('LLM not set');
  });

  it('recomputes contextUsage when a status update carries contextTokens without it', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.contextTokens = 0;
    driver.state.appState.maxContextTokens = 1_000_000;
    driver.state.appState.contextUsage = 0.74;

    // v2 token-counting events carry contextTokens only; the ratio must be
    // recomputed or the footer and /usage bar keep showing the stale value.
    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        contextTokens: 180_000,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.contextTokens).toBe(180_000);
    expect(driver.state.appState.contextUsage).toBeCloseTo(0.18);
  });

  it('recomputes contextUsage when a status update carries maxContextTokens without it', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.contextTokens = 180_000;
    driver.state.appState.maxContextTokens = 256_000;
    driver.state.appState.contextUsage = 180_000 / 256_000;

    // v2 profile events carry maxContextTokens only (e.g. a model switch).
    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        maxContextTokens: 1_000_000,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.maxContextTokens).toBe(1_000_000);
    expect(driver.state.appState.contextUsage).toBeCloseTo(0.18);
  });

  it('keeps an explicit contextUsage from status updates instead of recomputing', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.contextTokens = 100;
    driver.state.appState.maxContextTokens = 1_000_000;
    driver.state.appState.contextUsage = 0;

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        contextTokens: 180_000,
        maxContextTokens: 1_000_000,
        contextUsage: 0.42,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.contextUsage).toBe(0.42);
  });

  it('zeroes contextUsage when a recomputation has no known context window', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.contextTokens = 180_000;
    driver.state.appState.maxContextTokens = 0;
    driver.state.appState.contextUsage = 0.74;

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        contextTokens: 190_000,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.contextUsage).toBe(0);
  });

  it('applies the effective thinking effort from status updates', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        model: 'turbo',
        thinkingEffort: 'mid',
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.model).toBe('turbo');
    expect(driver.state.appState.thinkingEffort).toBe('mid');
  });

  it('applies tower mode from status updates', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        towerMode: true,
      } as Event,
      vi.fn(),
    );
    expect(driver.state.appState.towerMode).toBe(true);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        towerMode: false,
      } as Event,
      vi.fn(),
    );
    expect(driver.state.appState.towerMode).toBe(false);
  });

  it('renders swarm mode markers from /swarm commands, not tool-triggered status updates', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        swarmMode: true,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.swarmMode).toBe(true);
    expect(stripSgr(renderTranscript(driver))).not.toContain('Swarm activated');

    let transcript = stripSgr(renderTranscript(driver));
    expect(countOccurrences(transcript, 'Swarm activated')).toBe(0);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        swarmMode: false,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.swarmMode).toBe(false);
    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('Swarm deactivated');
    expect(transcript).not.toContain('Swarm ended');

    expect(countOccurrences(transcript, 'Swarm activated')).toBe(0);
    expect(countOccurrences(transcript, 'Swarm deactivated')).toBe(0);
    expect(countOccurrences(transcript, 'Swarm ended')).toBe(0);
  });

  it('renders an ended marker when a one-shot /swarm task exits', async () => {
    const { driver, session } = await makeDriver(undefined);
    driver.state.appState.permissionMode = 'auto';

    driver.handleUserInput('/swarm Ship feature X');

    await vi.waitFor(() => {
      expect(session.setSwarmMode).toHaveBeenCalledWith(true, 'task');
    });
    await vi.waitFor(() => {
      expect(countOccurrences(stripSgr(renderTranscript(driver)), 'Swarm activated')).toBe(1);
    });
    let transcript = stripSgr(renderTranscript(driver));
    expect(countOccurrences(transcript, 'Swarm activated')).toBe(1);
    expect(transcript).not.toContain('Swarm ended');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'main',
        sessionId: 'ses-1',
        swarmMode: false,
      } as Event,
      vi.fn(),
    );

    expect(driver.state.appState.swarmMode).toBe(false);
    transcript = stripSgr(renderTranscript(driver));
    expect(countOccurrences(transcript, 'Swarm activated')).toBe(1);
    expect(countOccurrences(transcript, 'Swarm ended')).toBe(1);
    expect(transcript).not.toContain('Swarm deactivated');
  });

  it('queues Ctrl-S input instead of steering while /init is running', async () => {
    let resolveInit: (() => void) | undefined;
    const session = makeSession({
      init: vi.fn(
        () =>
          new Promise<void>((resolve) => {
            resolveInit = resolve;
          }),
      ),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/init');
    await vi.waitFor(() => {
      expect(session.init).toHaveBeenCalledTimes(1);
    });

    driver.state.editor.setText('apply after init');
    driver.state.editor.onCtrlS?.();

    expect(session.steer).not.toHaveBeenCalled();
    expect(driver.state.queuedMessages).toEqual([{ text: 'apply after init', agentId: 'main' }]);
    expect(stripSgr(driver.state.queueContainer.render(120).join('\n'))).not.toContain(
      'ctrl-s to steer immediately',
    );

    resolveInit?.();

    await vi.waitFor(() => {
      expect(session.prompt).toHaveBeenCalledWith('apply after init', { promptId: undefined });
    });
    expect(driver.state.queuedMessages).toEqual([]);
  });

  it('cancels the active /init request through the session', async () => {
    let resolveInit: (() => void) | undefined;
    const session = makeSession({
      init: vi.fn(
        () =>
          new Promise<void>((resolve) => {
            resolveInit = resolve;
          }),
      ),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/init');
    await vi.waitFor(() => {
      expect(session.init).toHaveBeenCalledTimes(1);
    });

    driver.state.editor.onEscape?.();

    await vi.waitFor(() => {
      expect(session.cancel).toHaveBeenCalledTimes(1);
    });

    resolveInit?.();
  });

  it('does not run /init when no model is selected', async () => {
    const { driver, session } = await makeDriver();
    driver.state.appState.model = '';

    driver.handleUserInput('/init');

    expect(session.init).not.toHaveBeenCalled();
    expect(driver.state.transcriptContainer.render(120).join('\n')).toContain('LLM not set');
  });

  it('shows the login prompt for auth.login_required session errors', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'error',
        agentId: 'main',
        sessionId: 'ses-1',
        code: 'auth.login_required',
        message: 'OAuth provider credentials were rejected.',
        retryable: false,
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('OAuth login expired. Send /login to login.');
    expect(transcript).not.toContain('[auth.login_required]');
    expect(transcript).not.toContain('/export-debug-zip');
  });

  it('shows a programmatic abort reason instead of reporting a user interruption', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.step.interrupted',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        step: 1,
        reason: 'aborted',
        message: 'Tool execution timed out',
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Error: Tool execution timed out');
    expect(transcript).not.toContain('Interrupted by user');
  });

  it('keeps unmessaged aborted events compatible with user interruptions', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.step.interrupted',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        step: 1,
        reason: 'aborted',
      } as Event,
      vi.fn(),
    );

    expect(stripSgr(renderTranscript(driver))).toContain('Interrupted by user');
  });

  it('appends the /export-debug-zip hint beneath session error messages', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'error',
        agentId: 'main',
        sessionId: 'ses-1',
        code: 'compaction.failed',
        message: "APIStatusError: 400 the message at position 82 with role 'assistant' must not be empty",
        retryable: false,
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(driver.state.transcriptContainer.render(200).join('\n'));
    expect(transcript).toContain('Error: [compaction.failed]');
    expect(transcript).toContain('If this persists, run `/export-debug-zip`');
    expect(transcript).toContain("Please don't share it publicly");
    expect(transcript).not.toContain('kimi export');
  });

  it('shows concise provider filter text for filtered session errors', async () => {
    const { driver } = await makeDriver();
    const verboseMessage =
      'The API returned a response containing only thinking content without any text or tool calls. ' +
      'This usually indicates the stream was interrupted or the output token budget was exhausted ' +
      'during reasoning. Provider stop details: finishReason=filtered, rawFinishReason=content_filter. ' +
      'The provider filtered the response before visible output was emitted. Provider: example-provider, model: example-model';

    driver.sessionEventHandler.handleEvent(
      {
        type: 'error',
        agentId: 'main',
        sessionId: 'ses-1',
        code: 'provider.api_error',
        message: verboseMessage,
        details: {
          finishReason: 'filtered',
          rawFinishReason: 'content_filter',
        },
        retryable: true,
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(driver.state.transcriptContainer.render(200).join('\n'));
    expect(transcript).toContain(
      'Error: [provider.api_error] Provider filtered the response before visible output',
    );
    expect(transcript).toContain('finishReason=filtered');
    expect(transcript).toContain('rawFinishReason=content_filter');
    expect(transcript).not.toContain('only thinking content');
    expect(transcript).not.toContain('token budget');
    expect(transcript).not.toContain('stream was interrupted');
  });

  it('skips the /export-debug-zip hint when no active session id is set', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.sessionId = '';

    driver.sessionEventHandler.handleEvent(
      {
        type: 'error',
        agentId: 'main',
        sessionId: '',
        code: 'compaction.failed',
        message: 'boom',
        retryable: false,
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Error: [compaction.failed]');
    expect(transcript).not.toContain('/export-debug-zip');
  });

  it('shows ExitPlanMode plan only in the current-plan card during approval', async () => {
    const planContent = '# No Duplicate Plan\n\n- Do the non-duplicated plan work';
    const session = makeSession({
      getPlan: vi.fn(async () => ({
        id: 'no-duplicate-plan',
        content: planContent,
        path: '/tmp/no-duplicate-plan.md',
      })),
    });
    const { driver } = await makeDriver(session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_exit_plan',
        name: 'ExitPlanMode',
        args: {},
      } as Event,
      vi.fn(),
    );

    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('Current plan');
      expect(countOccurrences(transcript, 'non-duplicated plan work')).toBe(1);
    });

    const approvalHandler = vi.mocked(session.setApprovalHandler).mock.calls[0]?.[0] as
      | ((request: ApprovalRequest) => Promise<ApprovalResponse>)
      | undefined;
    if (approvalHandler === undefined) throw new Error('expected approval handler');
    void approvalHandler({
      turnId: 1,
      toolCallId: 'call_exit_plan',
      toolName: 'ExitPlanMode',
      action: 'Review plan',
      display: {
        kind: 'plan_review',
        plan: planContent,
        path: '/tmp/no-duplicate-plan.md',
      },
    });

    await vi.waitFor(() => {
      const approval = stripSgr(driver.state.editorContainer.render(120).join('\n'));
      expect(approval).toContain('Ready to build with this plan?');
      expect(approval).not.toContain('non-duplicated plan work');
      expect(approval).not.toContain('/tmp/no-duplicate-plan.md');
    });
  });

  it('renders AgentSwarm progress in the transcript instead of the tool-card body', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts'],
        },
      } as Event,
      sendQueued,
    );

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_swarm',
        subagentId: 'agent-1',
        subagentName: 'coder',
        description: 'Review changed files #1 (coder)',
        swarmIndex: 1,
        runInBackground: false,
      } as Event,
      sendQueued,
    );

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_swarm',
        subagentId: 'agent-2',
        subagentName: 'coder',
        description: 'Review changed files #2 (coder)',
        swarmIndex: 2,
        runInBackground: false,
      } as Event,
      sendQueued,
    );

    vi.mocked(driver.state.ui.requestRender).mockClear();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'agent-1',
        sessionId: 'ses-1',
        turnId: 2,
        toolCallId: 'call_read',
        name: 'Read',
        args: { path: 'src/a.ts' },
      } as Event,
      sendQueued,
    );
    expect(driver.state.ui.requestRender).toHaveBeenCalled();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'agent-1',
        sessionId: 'ses-1',
        turnId: 2,
        delta: 'Reviewing src/a.ts and checking imports for regressions in detail',
      } as Event,
      sendQueued,
    );
    let transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('01 [');
    expect(transcript).toContain('Reviewing src/a.ts');

    vi.mocked(driver.state.ui.requestRender).mockClear();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.suspended',
        agentId: 'main',
        sessionId: 'ses-1',
        subagentId: 'agent-1',
        reason: 'Provider rate limit; subagent requeued for retry.',
      } as Event,
      sendQueued,
    );
    expect(driver.state.ui.requestRender).toHaveBeenCalled();

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('001 [');
    expect(transcript).toContain('Queued…');
    expect(transcript).not.toContain('Provider rate limit');
    expect(transcript).not.toContain('Failed');

    vi.mocked(driver.state.ui.requestRender).mockClear();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.started',
        agentId: 'main',
        sessionId: 'ses-1',
        subagentId: 'agent-1',
      } as Event,
      sendQueued,
    );
    expect(driver.state.ui.requestRender).toHaveBeenCalled();

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('01 [');
    expect(transcript).not.toContain('Suspended');

    vi.mocked(driver.state.ui.requestRender).mockClear();
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'agent-1',
        sessionId: 'ses-1',
        turnId: 2,
        reason: 'completed',
      } as Event,
      sendQueued,
    );
    expect(driver.state.ui.requestRender).toHaveBeenCalled();

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Agent Swarm');
    expect(transcript).toContain('Review changed files');
    expect(transcript).toContain('001 [');
    expect(transcript).toContain('Reviewing src/a.ts');
    expect(transcript).not.toContain('Completed');
    expect(transcript).toContain('002 Queued…');
    expect(transcript).not.toContain('002 [');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.completed',
        agentId: 'main',
        sessionId: 'ses-1',
        subagentId: 'agent-1',
        resultSummary: 'Imports are stable',
      } as Event,
      sendQueued,
    );

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('✓ Imports are stable');
    expect(transcript).not.toContain('Completed');
  });

  it('marks only core user-cancellation subagent failures as cancelled', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts'],
        },
      } as Event,
      sendQueued,
    );

    for (const [index, subagentId] of ['agent-1', 'agent-2'].entries()) {
      driver.sessionEventHandler.handleEvent(
        {
          type: 'subagent.spawned',
          agentId: 'main',
          sessionId: 'ses-1',
          parentToolCallId: 'call_swarm',
          subagentId,
          subagentName: 'coder',
          description: `Review changed files #${String(index + 1)} (coder)`,
          swarmIndex: index + 1,
          runInBackground: false,
        } as Event,
        sendQueued,
      );
    }

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.failed',
        agentId: 'main',
        sessionId: 'ses-1',
        subagentId: 'agent-1',
        error: 'Aborted by the user',
      } as Event,
      sendQueued,
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.failed',
        agentId: 'main',
        sessionId: 'ses-1',
        subagentId: 'agent-2',
        error: 'The user manually interrupted this subagent x.',
      } as Event,
      sendQueued,
    );

    const transcript = stripSgr(driver.state.transcriptContainer.render(200).join('\n'));
    expect(transcript).toContain('⊘ Cancelled.');
    expect(transcript).toContain('✗ The user manually interrupted this subagent x.');
  });

  it('shows the spawned model on the subagent card at spawn, mapped through the model catalog', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();
    driver.state.appState.availableModels = {
      'k2-cheap': {
        provider: 'managed:kimi-code',
        model: 'kimi-k2-cheap',
        maxContextSize: 100_000,
        displayName: 'Kimi K2 Cheap',
        capabilities: [],
      },
    };

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_agent',
        subagentId: 'agent-1',
        subagentName: 'explore',
        description: 'explore project',
        runInBackground: false,
        model: 'k2-cheap',
      } as Event,
      sendQueued,
    );

    expect(stripSgr(renderTranscript(driver))).toContain('Kimi K2 Cheap');
  });

  it('falls back to the raw alias when the spawned model is missing from the catalog', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_agent',
        subagentId: 'agent-1',
        subagentName: 'explore',
        description: 'explore project',
        runInBackground: false,
        model: 'k2-cheap',
      } as Event,
      sendQueued,
    );

    expect(stripSgr(renderTranscript(driver))).toContain('k2-cheap');
  });

  it('shows any concrete spawned effort, same as the session or not', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();
    driver.state.appState.thinkingEffort = 'high';

    // Same level as the main session — still shown (level info is level info).
    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_agent',
        subagentId: 'agent-1',
        subagentName: 'explore',
        description: 'explore project',
        runInBackground: false,
        model: 'k2-cheap',
        thinkingEffort: 'high',
      } as Event,
      sendQueued,
    );
    expect(stripSgr(renderTranscript(driver))).toContain('· high');
  });

  it('hides the boolean effort states on and off', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    for (const effort of ['on', 'off']) {
      driver.sessionEventHandler.handleEvent(
        {
          type: 'subagent.spawned',
          agentId: 'main',
          sessionId: 'ses-1',
          parentToolCallId: `call_agent_${effort}`,
          subagentId: `agent-${effort}`,
          subagentName: 'explore',
          description: `explore ${effort}`,
          runInBackground: false,
          model: 'k2-cheap',
          thinkingEffort: effort,
        } as Event,
        sendQueued,
      );
    }

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).not.toContain('· on');
    expect(transcript).not.toContain('· off');
  });

  it('keeps the child status update as the model fallback when spawned omits it', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_agent',
        subagentId: 'agent-1',
        subagentName: 'explore',
        description: 'explore project',
        runInBackground: false,
      } as Event,
      sendQueued,
    );
    expect(stripSgr(renderTranscript(driver))).not.toContain('k2-cheap');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'agent.status.updated',
        agentId: 'agent-1',
        sessionId: 'ses-1',
        model: 'k2-cheap',
      } as Event,
      sendQueued,
    );
    expect(stripSgr(renderTranscript(driver))).toContain('k2-cheap');
  });

  it('shows the spawned model in the swarm panel header at spawn', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts'],
        },
      } as Event,
      sendQueued,
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_swarm',
        subagentId: 'agent-1',
        subagentName: 'coder',
        description: 'Review changed files #1 (coder)',
        swarmIndex: 1,
        runInBackground: false,
        model: 'k2-cheap',
      } as Event,
      sendQueued,
    );

    const progress = driver.state.transcriptContainer.children.find(
      (child): child is AgentSwarmProgressComponent => child instanceof AgentSwarmProgressComponent,
    );
    if (progress === undefined) throw new Error('expected AgentSwarm progress');
    expect(stripSgr(progress.render(118).join('\n'))).toContain('k2-cheap');
  });

  it('includes the spawned model in the background-agent transcript entry', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_agent',
        subagentId: 'agent-1',
        subagentName: 'explore',
        description: 'explore project',
        runInBackground: true,
        model: 'k2-cheap',
      } as Event,
      sendQueued,
    );

    expect(stripSgr(renderTranscript(driver))).toContain('k2-cheap');
  });

  it('does not let later transcript entries reduce the AgentSwarm grid height', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();
    const terminalColumns = 80;
    setTerminalColumns(driver, terminalColumns);
    const outerChildren = driver.state.ui.children;
    const transcriptIndex = outerChildren.indexOf(driver.state.transcriptContainer);
    const rowsAfterTranscript = outerChildren
      .slice(transcriptIndex + 1)
      .reduce((sum, child) => sum + child.render(terminalColumns).length, 0);
    const nonGridRows = 20 - (agentSwarmGridHeightForTerminalRows(20) ?? 0);
    setTerminalRows(driver, rowsAfterTranscript + nonGridRows + 2);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts', 'src/c.ts', 'src/d.ts'],
        },
      } as Event,
      sendQueued,
    );

    const swarmProgress = driver.state.transcriptContainer.children.find(
      (child): child is AgentSwarmProgressComponent => child instanceof AgentSwarmProgressComponent,
    );
    if (swarmProgress === undefined) throw new Error('expected AgentSwarm progress');

    const transcriptWidth = Math.max(1, terminalColumns - 2);
    const renderSwarm = (): string =>
      stripSgr(swarmProgress.render(transcriptWidth).join('\n'));

    expect(renderSwarm()).toContain('001 Queued…');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_read',
        name: 'Read',
        args: { path: 'src/after.ts' },
      } as Event,
      sendQueued,
    );

    const transcriptChildren = driver.state.transcriptContainer.children;
    const swarmIndex = transcriptChildren.indexOf(
      swarmProgress as (typeof transcriptChildren)[number],
    );
    expect(swarmIndex).toBeGreaterThanOrEqual(0);

    const rowsAfterSwarmInTranscript = transcriptChildren
      .slice(swarmIndex + 1)
      .reduce((sum, child) => sum + child.render(transcriptWidth).length, 0);
    expect(rowsAfterSwarmInTranscript).toBeGreaterThan(0);

    expect(renderSwarm()).toContain('001 Queued…');
    const transcript = stripSgr(
      driver.state.transcriptContainer.render(terminalColumns).join('\n'),
    );
    expect(transcript).toContain('Using Read (src/after.ts)');
  });

  it('shows AgentSwarm as completed when only some subagents fail', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts'],
        },
      } as Event,
      sendQueued,
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.result',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        output: [
          '<agent_swarm_result>',
          '<summary>completed: 1, failed: 1</summary>',
          '<subagent index="1" agent_id="agent-1" outcome="completed">Imports are stable.</subagent>',
          '<subagent index="2" agent_id="agent-2" outcome="failed">Agent timed out after 30s.</subagent>',
          '</agent_swarm_result>',
        ].join('\n'),
        isError: undefined,
      } as Event,
      sendQueued,
    );

    const transcript = stripSgr(renderTranscript(driver));
    const totalStatusLine = transcript.split('\n').find((line) => line.includes('Completed.'));
    expect(totalStatusLine).toBeDefined();
    expect(totalStatusLine).not.toContain('Failed.');
    expect(transcript).toContain('✓ Imports are stable.');
    expect(transcript).toContain('✗ Agent timed out after 30s.');
  });

  it('renders AgentSwarm progress while tool args are still streaming', async () => {
    const { driver } = await makeDriver();
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        argumentsPart: '{"description":"Review changed files',
      } as Event,
      sendQueued,
    );

    let transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Agent Swarm');
    expect(transcript).toContain('Orchestrating…');
    expect(transcript).not.toContain('01');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        argumentsPart: '","items":["src/a.ts","src/b',
      } as Event,
      sendQueued,
    );

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('Agent Swarm');
    expect(transcript).toContain('Review changed files');
    expect(transcript).toContain('001 src/a.ts');
    expect(transcript).toContain('002 src/b');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'subagent.spawned',
        agentId: 'main',
        sessionId: 'ses-1',
        parentToolCallId: 'call_swarm',
        subagentId: 'agent-1',
        subagentName: 'coder',
        description: 'Review changed files #1 (coder)',
        swarmIndex: 1,
        runInBackground: false,
      } as Event,
      sendQueued,
    );

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('001 Queued…');
    expect(transcript).not.toContain('001 [');
    expect(transcript).toContain('002 src/b');

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_swarm',
        name: 'AgentSwarm',
        args: {
          description: 'Review changed files',
          prompt_template: 'Review {{item}}',
          items: ['src/a.ts', 'src/b.ts'],
        },
      } as Event,
      sendQueued,
    );

    transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('001 Queued…');
    expect(transcript).toContain('002 Queued…');
    expect(transcript).not.toContain('001 [');
    expect(transcript).not.toContain('002 [');
  });

  it('shows plan review reject on the plan card without an approval notice', async () => {
    const planContent = '# Reject Plan\n\n- keep this plan visible after reject';
    const session = makeSession({
      getPlan: vi.fn(async () => ({
        id: 'reject-plan',
        content: planContent,
        path: '/tmp/reject-plan.md',
      })),
    });
    const { driver } = await makeDriver(session);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.call.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_exit_reject_plan',
        name: 'ExitPlanMode',
        args: {},
      } as Event,
      vi.fn(),
    );

    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('Reject Plan');
      expect(countOccurrences(transcript, 'keep this plan visible after reject')).toBe(1);
    });

    const approvalHandler = vi.mocked(session.setApprovalHandler).mock.calls[0]?.[0] as
      | ((request: ApprovalRequest) => Promise<ApprovalResponse>)
      | undefined;
    if (approvalHandler === undefined) throw new Error('expected approval handler');
    const response = approvalHandler({
      turnId: 1,
      toolCallId: 'call_exit_reject_plan',
      toolName: 'ExitPlanMode',
      action: 'Review plan',
      display: {
        kind: 'plan_review',
        plan: planContent,
        path: '/tmp/reject-plan.md',
      },
    });

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(ApprovalPanelComponent);
    });
    (driver.state.editorContainer.children[0] as ApprovalPanelComponent).handleInput('2');
    await expect(response).resolves.toMatchObject({ decision: 'rejected' });

    driver.sessionEventHandler.handleEvent(
      {
        type: 'tool.result',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        toolCallId: 'call_exit_reject_plan',
        output: 'Plan rejected by user. Plan mode remains active.',
        isError: true,
      } as Event,
      vi.fn(),
    );

    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('plan: reject-plan.md · Rejected');
      expect(transcript).toContain('Reject Plan');
      expect(countOccurrences(transcript, 'keep this plan visible after reject')).toBe(1);
      expect(transcript).not.toContain('Rejected: Review plan');
      expect(transcript).not.toContain('Plan rejected by user.');
      expect(transcript).not.toContain('Plan mode remains active.');
    });
  });

  it('renders /status using the active session runtime status', async () => {
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: 'high',
        permission: 'auto',
        planMode: true,
        contextTokens: 25,
        maxContextTokens: 100,
        contextUsage: 0.25,
      })),
    });
    const { driver } = await makeDriver(session);
    const getStatus = vi.mocked(session.getStatus);
    const previousStatusCalls = getStatus.mock.calls.length;

    driver.handleUserInput('/status');

    await vi.waitFor(() => {
      expect(getStatus).toHaveBeenCalledTimes(previousStatusCalls + 1);
      const output = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
      expect(output).toContain(' Status ');
      expect(output).toContain('>_ Kimi Code');
      expect(output).toContain('Model');
      expect(output).toContain('thinking high');
      expect(output).toContain('Permissions  auto');
      expect(output).toContain('Plan mode    on');
      expect(output).toContain('Context window');
      expect(output).toContain('25%');
    });
  });

  it('renders /mcp using a fresh MCP server snapshot', async () => {
    const session = makeSession({
      listMcpServers: vi.fn(async () => [
        {
          name: 'local-tools',
          transport: 'stdio',
          status: 'connected',
          toolCount: 2,
        },
        {
          name: 'remote-tools',
          transport: 'http',
          status: 'failed',
          toolCount: 0,
          error: 'connection refused',
        },
        {
          name: 'linear',
          transport: 'http',
          status: 'needs-auth',
          toolCount: 0,
        },
        {
          name: 'disabled-tools',
          transport: 'stdio',
          status: 'disabled',
          toolCount: 0,
        },
      ]),
    });
    const { driver } = await makeDriver(session);
    const listMcpServers = vi.mocked(session.listMcpServers);
    const previousCalls = listMcpServers.mock.calls.length;

    driver.handleUserInput('/mcp');

    await vi.waitFor(() => {
      expect(listMcpServers).toHaveBeenCalledTimes(previousCalls + 1);
      const output = stripSgr(driver.state.transcriptContainer.render(140).join('\n'));
      expect(output).toContain(' MCP (4) ');
      expect(output).toContain('Servers');
      expect(output).toContain('local-tools');
      expect(output).toContain('connected');
      expect(output).toContain('stdio');
      expect(output).toContain('2 tools');
      expect(output).toContain('remote-tools');
      expect(output).toContain('failed');
      expect(output).toContain('connection refused');
      expect(output).toContain('linear');
      expect(output).toContain('needs auth');
      expect(output).toContain('/mcp-config login linear');
      expect(output).toContain('disabled-tools');
      expect(output).toContain('disabled');
      expect(output).toContain('1 connected · 1 needs auth · 1 failed · 1 disabled · 2 tools available');
    });
  });

  it('renders an empty /mcp state when no MCP servers are configured', async () => {
    const session = makeSession({
      listMcpServers: vi.fn(async () => []),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/mcp');

    await vi.waitFor(() => {
      const output = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
      expect(output).toContain('No MCP servers configured. Run /mcp-config to add one.');
    });
  });

  it('renders /mcp list failures as command boundary errors', async () => {
    const session = makeSession({
      listMcpServers: vi.fn(async () => {
        throw new Error('rpc unavailable');
      }),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/mcp');

    await vi.waitFor(() => {
      const output = stripSgr(driver.state.transcriptContainer.render(120).join('\n'));
      expect(output).toContain('Error: Failed to load MCP servers: rpc unavailable');
    });
  });

  it('toggles plugin MCP servers from the text command', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins mcp enable kimi-datasource data');

    await vi.waitFor(() => {
      expect(session.setPluginMcpServerEnabled).toHaveBeenCalledWith(
        'kimi-datasource',
        'data',
        true,
      );
    });
  });

  it('errors when /plugins install has no argument', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins install');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain(
        'Usage: /plugins install <local-path-or-zip-url>',
      );
    });
    expect(session.installPlugin).not.toHaveBeenCalled();
  });

  it('installs from a positional source on /plugins install after trusting it', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins install ./plugins/kimi-datasource');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginInstallTrustConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginInstallTrustConfirmComponent;
    confirm.handleInput('\u001B[B'); // switch from "Exit" to "Trust and install"
    confirm.handleInput('\r');

    await vi.waitFor(() => {
      expect(session.installPlugin).toHaveBeenCalledWith(
        resolve('/tmp/proj-a', './plugins/kimi-datasource'),
      );
    });
  });

  it('shows a quota note after installing a quota-consuming official plugin', async () => {
    const session = makeSession({
      installPlugin: vi.fn(async () => ({
        id: 'kimi-datasource',
        displayName: 'Kimi Datasource',
        version: '3.3.0',
        enabled: true,
        state: 'ok',
        skillCount: 0,
        mcpServerCount: 1,
        enabledMcpServerCount: 1,
        hasErrors: false,
        source: 'zip-url',
        originalSource: 'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
      })),
    });
    const { driver } = await makeDriver(session);

    // Official sources skip the trust prompt, so the install runs immediately.
    driver.handleUserInput(
      '/plugins install https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
    );

    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('Run /new or /reload to apply plugin changes.');
      expect(transcript).toContain('Note: This plugin consumes your quota.');
    });
  });

  it('does not show the quota note for a same-id fork installed from a local path', async () => {
    const session = makeSession({
      installPlugin: vi.fn(async () => ({
        id: 'kimi-datasource',
        displayName: 'Kimi Datasource',
        version: '3.3.0',
        enabled: true,
        state: 'ok',
        skillCount: 0,
        mcpServerCount: 1,
        enabledMcpServerCount: 1,
        hasErrors: false,
        source: 'local-path',
      })),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins install ./plugins/kimi-datasource-fork');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginInstallTrustConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginInstallTrustConfirmComponent;
    confirm.handleInput('\u001B[B'); // switch from "Exit" to "Trust and install"
    confirm.handleInput('\r');

    // The manifest id matches a billed plugin, but a local-path install is
    // not the official quota-consuming build.
    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('Installed Kimi Datasource');
    });
    expect(stripSgr(renderTranscript(driver))).not.toContain(
      'Note: This plugin consumes your quota.',
    );
  });

  it('does not install when the third-party trust prompt is dismissed', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins install ./plugins/kimi-datasource');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginInstallTrustConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginInstallTrustConfirmComponent;
    confirm.handleInput('\r'); // default option is "Exit"

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBe(driver.state.editor);
    });
    expect(session.installPlugin).not.toHaveBeenCalled();
  });

  it('loads a local plugin marketplace file and installs from it', async () => {
    const marketplaceDir = await makeTempHome();
    const marketplacePath = join(marketplaceDir, 'marketplace.json');
    await writeFile(
      marketplacePath,
      JSON.stringify({
        plugins: [
          {
            id: 'kimi-datasource',
            tier: 'official',
            displayName: 'Kimi Datasource',
            description: 'Datasource plugin',
            source: 'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
          },
        ],
      }),
      'utf8',
    );
    process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'] = marketplacePath;
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins marketplace');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    // Official loads its catalog lazily; wait for the entry to render before install.
    await vi.waitFor(() => {
      expect(stripSgr(panel.render(120).join('\n'))).toContain('Kimi Datasource');
    });
    // The pinned Kimi WebBridge row leads the Official tab, so move down to
    // the Kimi Datasource entry before installing.
    panel.handleInput('\u001B[B');
    panel.handleInput('\r');

    await vi.waitFor(() => {
      expect(session.installPlugin).toHaveBeenCalledWith(
        'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
      );
    });
    await vi.waitFor(() => {
      const transcript = stripSgr(renderTranscript(driver));
      expect(transcript).toContain('Installed Demo');
      expect(transcript).toContain('Run /new or /reload to apply plugin changes.');
      expect(transcript).not.toContain('Note: This plugin consumes your quota.');
    });
    // Installing closes the panel so the success notice / reload tip is visible.
    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBe(driver.state.editor);
    });
  });

  it('returns to the plugin list when a marketplace install fails', async () => {
    const marketplaceDir = await makeTempHome();
    const marketplacePath = join(marketplaceDir, 'marketplace.json');
    await writeFile(
      marketplacePath,
      JSON.stringify({
        plugins: [
          {
            id: 'kimi-datasource',
            tier: 'official',
            displayName: 'Kimi Datasource',
            source: 'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
          },
        ],
      }),
      'utf8',
    );
    process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'] = marketplacePath;
    const installPlugin = vi.fn(async () => {
      throw new Error('install failed');
    });
    const session = makeSession({ installPlugin });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins marketplace');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    await vi.waitFor(() => {
      expect(stripSgr(panel.render(120).join('\n'))).toContain('Kimi Datasource');
    });
    panel.handleInput('\r');

    // The panel must not get stuck on the one-way "Installing…" view; it should
    // return to the list so the user can retry.
    await vi.waitFor(() => {
      const rendered = stripSgr(panel.render(120).join('\n'));
      expect(rendered).toContain('Kimi Datasource');
      expect(rendered).not.toContain('Installing');
    });
  });

  it('prompts for trust before installing a third-party marketplace entry', async () => {
    const marketplaceDir = await makeTempHome();
    const marketplacePath = join(marketplaceDir, 'marketplace.json');
    await writeFile(
      marketplacePath,
      JSON.stringify({
        plugins: [
          {
            id: 'superpowers',
            tier: 'curated',
            displayName: 'Superpowers',
            description: 'Curated plugin',
            source: './superpowers',
          },
        ],
      }),
      'utf8',
    );
    const session = makeSession();
    const { driver } = await makeDriver(session);

    // Passing the marketplace path opens the panel directly on the Third-party tab.
    driver.handleUserInput(`/plugins marketplace ${marketplacePath}`);

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    await vi.waitFor(() => {
      expect(stripSgr(panel.render(120).join('\n'))).toContain('Superpowers');
    });
    panel.handleInput('\r');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginInstallTrustConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginInstallTrustConfirmComponent;
    confirm.handleInput('\u001B[B'); // switch from "Exit" to "Trust and install"
    confirm.handleInput('\r');

    await vi.waitFor(() => {
      expect(session.installPlugin).toHaveBeenCalledWith(join(marketplaceDir, 'superpowers'));
    });
  });

  it('restores the panel when a third-party marketplace install fails', async () => {
    const marketplaceDir = await makeTempHome();
    const marketplacePath = join(marketplaceDir, 'marketplace.json');
    await writeFile(
      marketplacePath,
      JSON.stringify({
        plugins: [
          {
            id: 'superpowers',
            tier: 'curated',
            displayName: 'Superpowers',
            source: './superpowers',
          },
        ],
      }),
      'utf8',
    );
    const installPlugin = vi.fn(async () => {
      throw new Error('install failed');
    });
    const session = makeSession({ installPlugin });
    const { driver } = await makeDriver(session);

    driver.handleUserInput(`/plugins marketplace ${marketplacePath}`);

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    await vi.waitFor(() => {
      expect(stripSgr(panel.render(120).join('\n'))).toContain('Superpowers');
    });
    panel.handleInput('\r');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginInstallTrustConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginInstallTrustConfirmComponent;
    confirm.handleInput('\u001B[B'); // switch from "Exit" to "Trust and install"
    confirm.handleInput('\r');

    // The failed install must return the user to the marketplace panel so they
    // can retry, rather than dropping them back at the editor.
    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBe(panel);
    });
  });

  it('removes a plugin record without auto-running any cleanup skill', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins remove kimi-webbridge');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginRemoveConfirmComponent,
      );
    });
    const confirm = driver.state.editorContainer.children[0] as PluginRemoveConfirmComponent;
    confirm.handleInput('\u001B[B');
    confirm.handleInput('\r');

    await vi.waitFor(() => {
      expect(session.removePlugin).toHaveBeenCalledWith('kimi-webbridge');
    });
    expect(session.activateSkill).not.toHaveBeenCalled();
  });

  it('installs default marketplace entries through plain install', async () => {
    const originalFetch = globalThis.fetch;
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      plugins: [
        {
          id: 'kimi-datasource',
          tier: 'official',
          displayName: 'Kimi Datasource',
          description: 'Datasource plugin',
          source: './official/kimi-datasource.zip',
        },
      ],
    }))));
    const session = makeSession();
    const { driver } = await makeDriver(session);

    try {
      driver.handleUserInput('/plugins marketplace');

      await vi.waitFor(() => {
        expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
      });
      const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
      await vi.waitFor(() => {
        expect(stripSgr(panel.render(120).join('\n'))).toContain('Kimi Datasource');
      });
      // The pinned Kimi WebBridge row leads the Official tab, so move down to
      // the Kimi Datasource entry before installing.
      panel.handleInput('\u001B[B');
      panel.handleInput('\r');

      await vi.waitFor(() => {
        expect(session.installPlugin).toHaveBeenCalledWith(
          'https://code.kimi.com/kimi-code/plugins/official/kimi-datasource.zip',
        );
      });
      expect(globalThis.fetch).toHaveBeenCalledWith(kimiCodePluginMarketplaceUrl());
    } finally {
      vi.stubGlobal('fetch', originalFetch);
    }
  });

  it('shows an inline Official error when the marketplace is unreachable, keeping the panel open', async () => {
    const originalFetch = globalThis.fetch;
    process.env['KIMI_CODE_PLUGIN_MARKETPLACE_URL'] = 'https://example.test/marketplace.json';
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('fetch failed');
      }),
    );
    const session = makeSession();
    const { driver } = await makeDriver(session);

    try {
      driver.handleUserInput('/plugins');

      // The panel opens immediately on the Installed tab — no marketplace fetch.
      await vi.waitFor(() => {
        expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
      });
      const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
      panel.handleInput('\t'); // → Official, which lazily (and unsuccessfully) loads

      await vi.waitFor(() => {
        expect(stripSgr(panel.render(120).join('\n'))).toContain(
          'Marketplace unavailable: fetch failed',
        );
      });
      // The panel stays mounted; the failure does not close /plugins.
      expect(driver.state.editorContainer.children[0]).toBe(panel);
    } finally {
      vi.stubGlobal('fetch', originalFetch);
    }
  });

  it('toggles plugins from the Installed tab with space', async () => {
    let enabled = true;
    const session = makeSession({
      listPlugins: vi.fn(async () => [
        {
          id: 'demo',
          displayName: 'Demo',
          version: '1.0.0',
          enabled,
          state: 'ok',
          skillCount: 1,
          mcpServerCount: 0,
          enabledMcpServerCount: 0,
          hasErrors: false,
          source: 'local-path',
        },
      ]),
      setPluginEnabled: vi.fn(async (_id: string, nextEnabled: boolean) => {
        enabled = nextEnabled;
      }),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    panel.handleInput(' ');

    // Toggling refreshes the panel in place: it must not flash back to the
    // editor between the keypress and the refreshed panel mounting.
    expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);

    await vi.waitFor(() => {
      expect(session.setPluginEnabled).toHaveBeenCalledWith('demo', false);
    });
    await vi.waitFor(() => {
      const refreshed = stripSgr(driver.state.editorContainer.children[0]!.render(120).join('\n'));
      expect(refreshed).toContain('❯ Demo  disabled  run /reload or /new to apply');
    });
    expect(stripSgr(renderTranscript(driver))).not.toContain(
      'Disabled demo. Run /reload or /new to apply.',
    );
  });

  it('toggles plugin MCP servers from the overview MCP picker', async () => {
    const serverEnabled = new Map([
      ['metadata', true],
      ['data', true],
    ]);
    const session = makeSession({
      listPlugins: vi.fn(async () => [
        {
          id: 'kimi-datasource',
          displayName: 'Kimi Datasource',
          version: '1.0.0',
          enabled: true,
          state: 'ok',
          skillCount: 1,
          mcpServerCount: 2,
          enabledMcpServerCount: 2,
          hasErrors: false,
        },
      ]),
      getPluginInfo: vi.fn(async () => ({
        id: 'kimi-datasource',
        displayName: 'Kimi Datasource',
        version: '1.0.0',
        enabled: true,
        state: 'ok',
        skillCount: 1,
        mcpServerCount: 2,
        enabledMcpServerCount: [...serverEnabled.values()].filter(Boolean).length,
        hasErrors: false,
        source: 'local-path',
        root: '/plugins/kimi-datasource',
        manifest: undefined,
        mcpServers: [
          {
            name: 'metadata',
            runtimeName: 'plugin-kimi-datasource-metadata',
            enabled: serverEnabled.get('metadata') === true,
            transport: 'stdio',
            command: 'node',
            args: ['./bin/kimi-datasource.mjs', 'metadata'],
          },
          {
            name: 'data',
            runtimeName: 'plugin-kimi-datasource-data',
            enabled: serverEnabled.get('data') === true,
            transport: 'stdio',
            command: 'node',
            args: ['./bin/kimi-datasource.mjs', 'data'],
          },
        ],
        diagnostics: [],
      })),
      setPluginMcpServerEnabled: vi.fn(async (_id: string, _server: string, nextEnabled: boolean) => {
        serverEnabled.set(_server, nextEnabled);
      }),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginsPanelComponent);
    });
    const panel = driver.state.editorContainer.children[0] as PluginsPanelComponent;
    panel.handleInput('m');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginMcpSelectorComponent,
      );
    });
    const mcpPicker = driver.state.editorContainer.children[0] as PluginMcpSelectorComponent;
    mcpPicker.handleInput('\u001B[B');
    mcpPicker.handleInput(' ');

    await vi.waitFor(() => {
      expect(session.setPluginMcpServerEnabled).toHaveBeenCalledWith(
        'kimi-datasource',
        'data',
        false,
      );
    });
    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(PluginMcpSelectorComponent);
    });
    const out = stripSgr(driver.state.editorContainer.children[0]!.render(120).join('\n'));
    expect(out).toContain('❯ data  disabled  run /reload or /new to apply');
    expect(stripSgr(renderTranscript(driver))).not.toContain(
      'Disabled MCP server data for kimi-datasource. Run /reload or /new to apply.',
    );
  });

  it('requires confirmation before /plugins remove removes a plugin', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins remove demo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(
        PluginRemoveConfirmComponent,
      );
    });
    expect(session.removePlugin).not.toHaveBeenCalled();

    const confirm = driver.state.editorContainer.children[0] as PluginRemoveConfirmComponent;
    expect(stripSgr(confirm.render(120).join('\n'))).toContain('Remove demo (demo)?');
    confirm.handleInput('\r');

    await vi.waitFor(() => {
      expect(stripSgr(renderTranscript(driver))).toContain('Remove cancelled: demo.');
    });
    expect(session.removePlugin).not.toHaveBeenCalled();
  });

  it('renders /plugins <id> info to the transcript', async () => {
    const session = makeSession({
      listPlugins: vi.fn(async () => [
        {
          id: 'demo',
          displayName: 'Demo',
          version: '1.0.0',
          enabled: true,
          state: 'ok',
          skillCount: 1,
          mcpServerCount: 0,
          enabledMcpServerCount: 0,
          hasErrors: false,
        },
      ]),
    });
    const { driver } = await makeDriver(session);

    driver.handleUserInput('/plugins demo');

    await vi.waitFor(() => {
      expect(session.getPluginInfo).toHaveBeenCalledWith('demo');
    });
  });

  it('applies /model selection with inline thinking state', async () => {
    const session = makeSession();
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
          },
          turbo: {
            provider: 'managed:kimi-code',
            model: 'kimi-turbo',
            maxContextSize: 100,
            displayName: 'Kimi Turbo',
            capabilities: ['thinking'],
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: false },
      })),
      setConfig,
    });

    driver.handleUserInput('/model turbo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0];
    const pickerOutput = stripSgr((picker as TabbedModelSelectorComponent).render(120).join('\n'));
    expect(pickerOutput).toMatch(/Kimi K2\s+Kimi Code ← current/);
    expect(pickerOutput).toMatch(/❯ Kimi Turbo\s+Kimi Code/);
    (picker as TabbedModelSelectorComponent).handleInput('t');
    (picker as TabbedModelSelectorComponent).handleInput('u');
    const filteredOutput = stripSgr((picker as TabbedModelSelectorComponent).render(120).join('\n'));
    expect(filteredOutput).toContain('Search: tu');
    expect(filteredOutput).toContain('Kimi Turbo');
    expect(filteredOutput).not.toContain('Kimi K2');
    // Turbo is a thinking-capable model that is not the active one, so it
    // defaults to thinking on — selecting it applies thinking without a toggle.
    (picker as TabbedModelSelectorComponent).handleInput('\r');

    await vi.waitFor(() => {
      expect(session.setModel).toHaveBeenCalledWith('turbo');
      expect(session.setThinking).toHaveBeenCalledWith('on');
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'turbo',
        thinking: { enabled: true },
      });
    });
    expect(driver.state.appState.model).toBe('turbo');
    expect(driver.state.appState.thinkingEffort).toBe('on');
  });

  it('applies /model selection to the session only on Alt+S without persisting', async () => {
    const session = makeSession();
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
          },
          turbo: {
            provider: 'managed:kimi-code',
            model: 'kimi-turbo',
            maxContextSize: 100,
            displayName: 'Kimi Turbo',
            capabilities: ['thinking'],
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: false },
      })),
      setConfig,
    });

    driver.handleUserInput('/model turbo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0];
    // /model turbo preselects turbo; Alt+S applies it to the current session only.
    (picker as TabbedModelSelectorComponent).handleInput(`${ESC}s`);

    await vi.waitFor(() => {
      expect(session.setModel).toHaveBeenCalledWith('turbo');
      expect(session.setThinking).toHaveBeenCalledWith('on');
    });
    expect(setConfig).not.toHaveBeenCalled();
    expect(driver.state.appState.model).toBe('turbo');
    expect(driver.state.appState.thinkingEffort).toBe('on');
  });

  it('uses the effective effort returned after a model-switch fallback', async () => {
    let switched = false;
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: switched ? 'turbo' : 'k2',
        thinkingEffort: switched ? 'mid' : 'ultra',
        permission: 'manual',
        planMode: false,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
      setModel: vi.fn(async () => {
        switched = true;
      }),
    });
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'ultra'],
            defaultEffort: 'ultra',
          },
          turbo: {
            provider: 'managed:kimi-code',
            model: 'kimi-turbo',
            maxContextSize: 100,
            capabilities: ['thinking'],
            supportEfforts: ['low', 'mid', 'high'],
            defaultEffort: 'mid',
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: true, effort: 'ultra' },
      })),
      setConfig,
    });

    driver.handleUserInput('/model turbo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    (driver.state.editorContainer.children[0] as TabbedModelSelectorComponent).handleInput('\r');

    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'turbo',
        thinking: { enabled: true, effort: 'mid' },
      });
    });
    expect(driver.state.appState.model).toBe('turbo');
    expect(driver.state.appState.thinkingEffort).toBe('mid');
    expect(renderTranscript(driver)).toContain('Switched to kimi-turbo with thinking mid.');
  });

  it('persists /model selection even when runtime state is unchanged', async () => {
    const session = makeSession();
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
          },
        },
        defaultModel: 'old-default',
        thinking: { enabled: true },
      })),
      setConfig,
    });

    driver.handleUserInput('/model k2');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0];
    (picker as TabbedModelSelectorComponent).handleInput('\r');

    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'k2',
        thinking: { enabled: false },
      });
    });
    expect(session.setModel).not.toHaveBeenCalled();
    expect(session.setThinking).not.toHaveBeenCalled();
  });

  it('does not write config when re-confirming the current effort in the picker', async () => {
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: 'high',
        permission: 'manual',
        planMode: false,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
    });
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'max'],
            defaultEffort: 'high',
          },
        },
        defaultModel: 'k2',
        // No persisted effort: re-confirming the shown level must not turn the
        // runtime default into a stored preference.
        thinking: { enabled: true },
      })),
      setConfig,
    });

    driver.handleUserInput('/effort');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(EffortSelectorComponent);
    });
    (driver.state.editorContainer.children[0] as EffortSelectorComponent).handleInput('\r');

    await vi.waitFor(() => {
      expect(renderTranscript(driver)).toContain('Already using Kimi K2 with thinking high.');
    });
    expect(setConfig).not.toHaveBeenCalled();
    expect(session.setThinking).not.toHaveBeenCalled();
  });

  it('persists only the model when a switch keeps the same effort', async () => {
    let switched = false;
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: switched ? 'turbo' : 'k2',
        thinkingEffort: 'high',
        permission: 'manual',
        planMode: false,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
      setModel: vi.fn(async () => {
        switched = true;
      }),
    });
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'max'],
            defaultEffort: 'high',
          },
          turbo: {
            provider: 'managed:kimi-code',
            model: 'kimi-turbo',
            maxContextSize: 100,
            displayName: 'Turbo',
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'max'],
            defaultEffort: 'high',
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: true, effort: 'high' },
      })),
      setConfig,
    });

    driver.handleUserInput('/model turbo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    (driver.state.editorContainer.children[0] as TabbedModelSelectorComponent).handleInput('\r');

    // The effort matches the value shown when the picker opened, so the patch
    // carries no effort key; the stored preference stays as-is via the merge.
    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'turbo',
        thinking: { enabled: true },
      });
    });
  });

  it('persists max when the model default effort is max', async () => {
    let switched = false;
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: 'k2',
        thinkingEffort: switched ? 'max' : 'high',
        permission: 'manual',
        planMode: false,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
      setThinking: vi.fn(async () => {
        switched = true;
      }),
    });
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'max'],
            defaultEffort: 'max',
          },
        },
        defaultModel: 'k2',
        // A previously stored effort keeps the runtime below the delivered
        // max default, so picking max is an explicit change.
        thinking: { enabled: true, effort: 'high' },
      })),
      setConfig,
    });

    driver.handleUserInput('/effort max');

    await vi.waitFor(() => {
      expect(session.setThinking).toHaveBeenCalledWith('max');
    });
    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'k2',
        thinking: { enabled: true, effort: 'max' },
      });
    });
    expect(driver.state.appState.thinkingEffort).toBe('max');
  });

  it('keeps an xhigh pick session-only for a Claude model via the profile inference', async () => {
    // claude-opus-4-7 declares no efforts; the Anthropic profile inference
    // supplies [low, medium, high, xhigh, max] and resolves the default to
    // 'high', so an xhigh pick ranks above the persistence ceiling.
    let switched = false;
    const session = makeSession({
      getStatus: vi.fn(async () => ({
        model: 'opus',
        thinkingEffort: switched ? 'xhigh' : 'high',
        permission: 'manual',
        planMode: false,
        contextTokens: 0,
        maxContextTokens: 100,
        contextUsage: 0,
      })),
      setThinking: vi.fn(async () => {
        switched = true;
      }),
    });
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        providers: {
          compatible: { type: 'anthropic', apiKey: 'test-key' },
        },
        models: {
          opus: {
            provider: 'compatible',
            model: 'claude-opus-4-7',
            maxContextSize: 100,
          },
        },
        defaultModel: 'opus',
        thinking: { enabled: true, effort: 'high' },
      })),
      setConfig,
    });

    driver.handleUserInput('/effort xhigh');

    await vi.waitFor(() => {
      expect(session.setThinking).toHaveBeenCalledWith('xhigh');
    });
    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'opus',
        thinking: { enabled: true },
      });
    });
    expect(driver.state.appState.thinkingEffort).toBe('xhigh');
  });

  it('refreshes only OAuth provider models before opening /model picker', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Old Kimi K2',
            capabilities: ['thinking'],
          },
        },
      })),
    });
    const tui = driver as unknown as KimiTUI;
    const refreshProviderModels = vi
      .spyOn(tui.authFlow, 'refreshProviderModels')
      .mockRejectedValue(new Error('full provider refresh should not run'));
    const refreshOAuthProviderModels = vi.fn(async () => {
      await Promise.resolve();
      tui.setAppState({
        availableModels: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Fresh Kimi K2',
            capabilities: ['thinking'],
          },
        },
      });
      return { changed: [], unchanged: ['managed:kimi-code'], failed: [] };
    });
    (
      tui.authFlow as unknown as {
        refreshOAuthProviderModels: typeof refreshOAuthProviderModels;
      }
    ).refreshOAuthProviderModels = refreshOAuthProviderModels;

    driver.handleUserInput('/model');

    await vi.waitFor(() => {
      const picker = driver.state.editorContainer.children[0];
      expect(picker).toBeInstanceOf(TabbedModelSelectorComponent);
      const output = stripSgr((picker as TabbedModelSelectorComponent).render(120).join('\n'));
      expect(output).toContain('Fresh Kimi K2');
      expect(output).not.toContain('Old Kimi K2');
    });
    expect(refreshOAuthProviderModels).toHaveBeenCalledOnce();
    expect(refreshProviderModels).not.toHaveBeenCalled();
  });

  it('opens /model picker after 2s when OAuth refresh is still pending', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
          },
        },
      })),
    });
    const tui = driver as unknown as KimiTUI;
    const refreshOAuthProviderModels = vi.fn(() => new Promise<never>(() => {}));
    (
      tui.authFlow as unknown as {
        refreshOAuthProviderModels: typeof refreshOAuthProviderModels;
      }
    ).refreshOAuthProviderModels = refreshOAuthProviderModels;

    vi.useFakeTimers();
    try {
      driver.handleUserInput('/model');
      await Promise.resolve();

      expect(refreshOAuthProviderModels).toHaveBeenCalledOnce();
      expect(driver.state.editorContainer.children[0]).not.toBeInstanceOf(TabbedModelSelectorComponent);

      await vi.advanceTimersByTimeAsync(1_999);
      expect(driver.state.editorContainer.children[0]).not.toBeInstanceOf(TabbedModelSelectorComponent);

      await vi.advanceTimersByTimeAsync(1);
      const picker = driver.state.editorContainer.children[0];
      expect(picker).toBeInstanceOf(TabbedModelSelectorComponent);
      const output = stripSgr((picker as TabbedModelSelectorComponent).render(120).join('\n'));
      expect(output).toContain('Kimi K2');
    } finally {
      vi.useRealTimers();
    }
  });

  it('enables search in the shared model selector helper', async () => {
    const { driver } = await makeDriver();
    const selection = runModelSelector(driver as any, {
      alpha: {
        provider: 'managed:kimi-code',
        model: 'kimi-alpha',
        maxContextSize: 100,
        displayName: 'Kimi Alpha',
        capabilities: ['thinking'],
      },
      turbo: {
        provider: 'managed:kimi-code',
        model: 'kimi-turbo',
        maxContextSize: 100,
        displayName: 'Kimi Turbo',
        capabilities: ['thinking'],
      },
    });

    const picker = driver.state.editorContainer.children[0];
    expect(picker).toBeInstanceOf(ModelSelectorComponent);
    (picker as ModelSelectorComponent).handleInput('t');
    (picker as ModelSelectorComponent).handleInput('u');

    const output = stripSgr((picker as ModelSelectorComponent).render(120).join('\n'));
    expect(output).toContain('Search: tu');
    expect(output).toContain('Kimi Turbo');
    expect(output).not.toContain('Kimi Alpha');

    (picker as ModelSelectorComponent).handleInput('\u001B');
    (picker as ModelSelectorComponent).handleInput('\u001B');
    await expect(selection).resolves.toBeUndefined();
  });

  it('deletes Kitty inline images when /new clears the transcript', async () => {
    setCapabilities({ images: 'kitty', trueColor: true, hyperlinks: true });
    const { driver, harness } = await makeDriver(makeSession({ id: 'ses-1' }));
    const nextSession = makeSession({ id: 'ses-2' });
    harness.createSession.mockResolvedValueOnce(nextSession);
    const write = vi.spyOn(driver.state.terminal, 'write').mockImplementation(() => {});

    driver.handleUserInput('/new');

    await vi.waitFor(() => {
      expect(harness.createSession).toHaveBeenCalledTimes(2);
      expect(driver.getCurrentSessionId()).toBe('ses-2');
    });
    expect(write).toHaveBeenCalledWith(deleteAllKittyImages());
  });

  it('updates terminal title through pi-tui without changing process title', async () => {
    const originalTitle = process.title;
    const { driver } = await makeDriver(makeSession({ id: 'ses-1' }));
    const setTitle = vi.spyOn(driver.state.terminal, 'setTitle').mockImplementation(() => {});

    try {
      process.title = 'kimi-test-runner';
      driver.sessionEventHandler.handleEvent(
        {
          type: 'session.meta.updated',
          sessionId: 'ses-1',
          agentId: 'main',
          title: 'Implement terminal title',
        } as Event,
        () => {},
      );

      expect(setTitle).toHaveBeenCalledWith('Implement terminal title');
      expect(process.title).toBe('kimi-test-runner');
    } finally {
      process.title = originalTitle;
    }
  });

  it('forks the active session and stays in the source session', async () => {
    const originalTitle = process.title;
    const source = makeSession({
      id: 'ses-source',
      summary: { title: 'Source title' },
    });
    const forked = makeSession({
      id: 'ses-fork',
      summary: { title: 'Fork: Source title' },
    });
    const forkSession = vi.fn(async () => forked);
    const { driver, harness } = await makeDriver(source, { forkSession });
    const setTitle = vi.spyOn(driver.state.terminal, 'setTitle').mockImplementation(() => {});

    try {
      process.title = 'kimi-test-runner';
      driver.handleUserInput('/fork ignored args');

      await vi.waitFor(() => {
        expect(forkSession).toHaveBeenCalledWith({
          id: 'ses-source',
          title: 'Fork: Source title',
        });
        expect(driver.state.transcriptContainer.render(120).join('\n')).toContain(
          'Session forked (ses-fork). Still in the original session; switch to the fork via /sessions.',
        );
      });
      expect(copyTextToClipboard).toHaveBeenCalledWith(
        "cd '/tmp/proj-a' && kimi --resume 'ses-fork'",
      );
      const transcript = driver.state.transcriptContainer.render(120).join('\n');
      expect(transcript).toContain(
        "To enter the fork in a new process, run: cd '/tmp/proj-a' && kimi --resume 'ses-fork'",
      );
      expect(transcript).toContain('Command copied to clipboard');
      expect(driver.getCurrentSessionId()).toBe('ses-source');
      expect(source.close).not.toHaveBeenCalled();
      expect(forked.close).toHaveBeenCalledOnce();
      expect(forked.onEvent).not.toHaveBeenCalled();
      expect(setTitle).not.toHaveBeenCalled();
      expect(process.title).toBe('kimi-test-runner');
      expect(harness.resumeSession).not.toHaveBeenCalled();
    } finally {
      process.title = originalTitle;
    }
  });

  it('still prints the fork resume command when the clipboard copy fails', async () => {
    vi.mocked(copyTextToClipboard).mockRejectedValueOnce(new Error('no clipboard'));
    const source = makeSession({ id: 'ses-source' });
    const forked = makeSession({ id: 'ses-fork' });
    const forkSession = vi.fn(async () => forked);
    const { driver } = await makeDriver(source, { forkSession });

    driver.handleUserInput('/fork');

    await vi.waitFor(() => {
      const transcript = driver.state.transcriptContainer.render(120).join('\n');
      expect(transcript).toContain(
        "To enter the fork in a new process, run: cd '/tmp/proj-a' && kimi --resume 'ses-fork'",
      );
      expect(transcript).toContain('Failed to copy command to clipboard');
    });
    expect(driver.getCurrentSessionId()).toBe('ses-source');
  });

  it('labels OSC 52 clipboard delivery as unverified after a fork', async () => {
    vi.mocked(copyTextToClipboard).mockResolvedValueOnce('osc52');
    const source = makeSession({ id: 'ses-source' });
    const forked = makeSession({ id: 'ses-fork' });
    const forkSession = vi.fn(async () => forked);
    const { driver } = await makeDriver(source, { forkSession });

    driver.handleUserInput('/fork');

    await vi.waitFor(() => {
      expect(driver.state.transcriptContainer.render(120).join('\n')).toContain(
        'Command copied via terminal escape sequence (unverified)',
      );
    });
    expect(driver.getCurrentSessionId()).toBe('ses-source');
  });

  it('prints a pushd-based fork resume command on Windows', async () => {
    const platformDescriptor = Object.getOwnPropertyDescriptor(process, 'platform');
    Object.defineProperty(process, 'platform', { value: 'win32' });
    try {
      const source = makeSession({ id: 'ses-source' });
      const forked = makeSession({ id: 'ses-fork' });
      const forkSession = vi.fn(async () => forked);
      const { driver } = await makeDriver(source, { forkSession }, {
        ...makeStartupInput(),
        workDir: 'D:\\proj',
      });

      driver.handleUserInput('/fork');

      // cmd.exe's `cd` does not switch drives; pushd works in cmd + PowerShell.
      await vi.waitFor(() => {
        expect(copyTextToClipboard).toHaveBeenCalledWith(
          'pushd "D:\\proj" && kimi --resume "ses-fork"',
        );
      });
      expect(driver.getCurrentSessionId()).toBe('ses-source');
    } finally {
      if (platformDescriptor !== undefined) {
        Object.defineProperty(process, 'platform', platformDescriptor);
      }
    }
  });

  it('keeps the current session when fork fails', async () => {
    const forkSession = vi.fn(async () => {
      throw new Error('fork unavailable');
    });
    const { driver } = await makeDriver(makeSession({ id: 'ses-source' }), { forkSession });

    driver.handleUserInput('/fork');

    await vi.waitFor(() => {
      expect(forkSession).toHaveBeenCalledWith({
        id: 'ses-source',
        title: 'Fork: ses-source',
      });
      expect(driver.getCurrentSessionId()).toBe('ses-source');
      expect(driver.state.transcriptContainer.render(120).join('\n')).toContain(
        'Failed to fork session: fork unavailable',
      );
    });
  });

  it('reports when the forked runtime cannot be released', async () => {
    const source = makeSession({ id: 'ses-source' });
    const forked = makeSession({ id: 'ses-fork' });
    forked.close.mockRejectedValueOnce(new Error('close unavailable'));
    const forkSession = vi.fn(async () => forked);
    const { driver } = await makeDriver(source, { forkSession });

    driver.handleUserInput('/fork');

    await vi.waitFor(() => {
      expect(forked.close).toHaveBeenCalledOnce();
      expect(driver.getCurrentSessionId()).toBe('ses-source');
      expect(driver.state.transcriptContainer.render(120).join('\n')).toContain(
        'Session forked (ses-fork), but failed to release its runtime: close unavailable',
      );
    });
    expect(source.close).not.toHaveBeenCalled();
  });

  it('does not create a thinking component for empty thinking deltas', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'thinking';
    driver.state.appState.streamingStartTime = 1;

    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: '',
      } as Event,
      vi.fn(),
    );

    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(false);
  });

  it('does not create a thinking component for whitespace-only thinking deltas', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'waiting';

    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: ' ',
      } as Event,
      vi.fn(),
    );
    driver.streamingUI.flushNow();

    // Nothing to render: no component, and the phase is not hijacked into thinking.
    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(false);
    expect(driver.state.appState.streamingPhase).toBe('waiting');

    // Real thinking text after the whitespace still starts thinking normally.
    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: 'actual reasoning',
      } as Event,
      vi.fn(),
    );
    driver.streamingUI.flushNow();

    expect(driver.state.appState.streamingPhase).toBe('thinking');
    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(true);
    expect(stripSgr(renderTranscript(driver))).toContain('actual reasoning');
  });

  it('does not create a thinking component for whitespace-only thinking on session replay', async () => {
    const { driver } = await makeDriver();

    // Session replay flushes stored thinking verbatim through onThinkingUpdate
    // (see SessionReplayRenderer.flushAssistant), so a persisted whitespace-only
    // think part must not become a bare bullet line.
    driver.streamingUI.onThinkingUpdate(' ');
    driver.streamingUI.onThinkingEnd();

    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(false);
    expect(
      driver.state.transcriptContainer.children.filter(
        (child) => child instanceof ThinkingComponent,
      ),
    ).toHaveLength(0);

    // Real stored thinking still replays normally.
    driver.streamingUI.onThinkingUpdate('visible reasoning');
    driver.streamingUI.onThinkingEnd();

    expect(stripSgr(renderTranscript(driver))).toContain('visible reasoning');
  });

  it('keeps the waiting moon spinner while reasoning streams only empty (encrypted) thinking deltas', async () => {
    const { driver } = await makeDriver();

    // Turn begins -> waiting mode shows the moon spinner.
    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.started',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
      } as Event,
      vi.fn(),
    );
    expect(driver.state.appState.streamingPhase).toBe('waiting');
    expect(driver.state.livePane.mode).toBe('waiting');

    // Encrypted reasoning: thinking.delta events whose visible text is empty.
    for (let i = 0; i < 3; i++) {
      driver.sessionEventHandler.handleEvent(
        {
          type: 'thinking.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          delta: '',
        } as Event,
        vi.fn(),
      );
    }

    // The moon must stay up: still waiting, no orphan thinking component, and
    // the activity pane still renders a moon frame (no blank, spinner-less gap).
    expect(driver.state.appState.streamingPhase).toBe('waiting');
    expect(driver.state.livePane.mode).toBe('waiting');
    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(false);
    const activity = stripSgr(renderActivity(driver));
    expect(MOON_SPINNER_FRAMES.some((frame) => activity.includes(frame))).toBe(true);

    // Real thinking text finally arrives -> transition into thinking mode.
    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: 'actual reasoning',
      } as Event,
      vi.fn(),
    );
    driver.streamingUI.flushNow();
    expect(driver.state.appState.streamingPhase).toBe('thinking');
    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(true);
  });

  it('finalizes an orphaned thinking component on turn end', async () => {
    const { driver } = await makeDriver();
    driver.state.appState.streamingPhase = 'thinking';
    driver.state.appState.streamingStartTime = 1;
    const sendQueued = vi.fn();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: 'leaked',
      } as Event,
      vi.fn(),
    );
    driver.streamingUI.flushNow();
    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(true);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        reason: 'completed',
      } as Event,
      sendQueued,
    );

    expect(driver.streamingUI.hasActiveThinkingComponent()).toBe(false);
  });

  it('renders newly streamed thinking expanded when ctrl+o toggle was already active', async () => {
    const { driver } = await makeDriver();
    driver.state.toolOutputExpanded = true;

    const longThinking = ['t1', 't2', 't3', 't4', 't5', 't6', 't7'].join('\n');
    driver.sessionEventHandler.handleEvent(
      {
        type: 'thinking.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: longThinking,
      } as Event,
      vi.fn(),
    );
    driver.sessionEventHandler.handleEvent(
      {
        type: 'assistant.delta',
        agentId: 'main',
        sessionId: 'ses-1',
        delta: 'answer',
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('t7');
    expect(transcript).not.toContain('ctrl+o expand');
  });

  it('renders hook results without XML tags', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'hook.result',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        hookEvent: 'UserPromptSubmit',
        content: '{}',
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('UserPromptSubmit hook');
    expect(transcript).toContain('{}');
    expect(transcript).not.toContain('<hook_result');
  });

  it('renders empty hook results as empty status text', async () => {
    const { driver } = await makeDriver();

    driver.sessionEventHandler.handleEvent(
      {
        type: 'hook.result',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        hookEvent: 'UserPromptSubmit',
        content: '',
      } as Event,
      vi.fn(),
    );

    const transcript = stripSgr(renderTranscript(driver));
    expect(transcript).toContain('UserPromptSubmit hook');
    expect(transcript).toContain('(empty)');
    expect(transcript).not.toContain('<hook_result');
  });
});

describe('/model status displayName override', () => {
  it('shows the overridden display name in the switch status', async () => {
    const session = makeSession();
    const setConfig = vi.fn(async () => ({ providers: {} }));
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        models: {
          k2: {
            provider: 'managed:kimi-code',
            model: 'kimi-k2',
            maxContextSize: 100,
            displayName: 'Kimi K2',
            capabilities: ['thinking'],
          },
          turbo: {
            provider: 'managed:kimi-code',
            model: 'kimi-turbo',
            maxContextSize: 100,
            displayName: 'Remote Turbo',
            capabilities: ['thinking'],
            overrides: { displayName: 'Custom Turbo' },
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: false },
      })),
      setConfig,
    });

    driver.handleUserInput('/model turbo');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(TabbedModelSelectorComponent);
    });
    (driver.state.editorContainer.children[0] as TabbedModelSelectorComponent).handleInput('\r');

    await vi.waitFor(() => {
      expect(setConfig).toHaveBeenCalledWith({
        defaultModel: 'turbo',
        thinking: { enabled: true },
      });
    });

    expect(renderTranscript(driver)).toContain('Switched to Custom Turbo with thinking on.');
    expect(renderTranscript(driver)).not.toContain('Remote Turbo');
  });
});

describe('/effort support_efforts override', () => {
  it('warns and applies efforts hidden by an Anthropic support_efforts override', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        providers: {
          compatible: { type: 'kimi', apiKey: 'test-key' },
        },
        models: {
          k2: {
            provider: 'compatible',
            model: 'compatible-model',
            protocol: 'anthropic',
            maxContextSize: 100,
            displayName: 'Compatible Model',
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high', 'max'],
            overrides: { supportEfforts: ['low', 'high'] },
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: true, effort: 'low' },
      })),
    });

    driver.handleUserInput('/effort max');

    await vi.waitFor(() => {
      expect(session.setThinking).toHaveBeenCalledWith('max');
    });
    await vi.waitFor(() => {
      expect(renderTranscript(driver)).toContain('Thinking set to max.');
    });
    const transcript = renderTranscript(driver).replaceAll(/\s+/g, ' ');
    expect(transcript).toContain(
      'Thinking effort "max" is not listed for k2 (known: low, high). Sending "max" unchanged; the configured provider will validate it.',
    );
    expect(transcript).toContain('Thinking set to max.');
  });

  it('offers the latest Opus efforts for an unknown Claude-marked Anthropic-compatible model', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        providers: {
          compatible: { type: 'anthropic', apiKey: 'test-key' },
        },
        models: {
          k2: {
            provider: 'compatible',
            model: 'compatible-claude-model',
            maxContextSize: 100,
          },
        },
        defaultModel: 'k2',
      })),
    });

    driver.handleUserInput('/effort');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(EffortSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0] as EffortSelectorComponent;
    expect(picker.render(80).join('\n')).toContain('Max');
  });

  it('offers no fallback efforts for a clearly non-Claude Anthropic-compatible model', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        providers: {
          compatible: { type: 'anthropic', apiKey: 'test-key' },
        },
        models: {
          k2: {
            provider: 'compatible',
            model: 'compatible-model',
            maxContextSize: 100,
          },
        },
        defaultModel: 'k2',
      })),
    });

    driver.handleUserInput('/effort');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(EffortSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0] as EffortSelectorComponent;
    expect(picker.render(80).join('\n')).not.toContain('Max');
  });

  it('offers no fallback efforts for an unknown model on a Kimi provider using the Anthropic protocol', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        providers: {
          compatible: { type: 'kimi', apiKey: 'test-key' },
        },
        models: {
          k2: {
            provider: 'compatible',
            model: 'compatible-model',
            protocol: 'anthropic',
            maxContextSize: 100,
          },
        },
        defaultModel: 'k2',
      })),
    });

    driver.handleUserInput('/effort');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(EffortSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0] as EffortSelectorComponent;
    expect(picker.render(80).join('\n')).not.toContain('Max');
  });

  it('offers the latest Opus efforts for a flat providerless Claude-marked Anthropic model', async () => {
    const { driver } = await makeDriver(makeSession(), {
      getConfig: vi.fn(async () => ({
        providers: {},
        models: {
          // v2 flat model shape: no named provider, inline endpoint + protocol.
          k2: {
            model: 'compatible-claude-model',
            baseUrl: 'https://anthropic.example.test',
            protocol: 'anthropic',
            maxContextSize: 100,
          },
        },
        defaultModel: 'k2',
      })),
    });

    driver.handleUserInput('/effort');

    await vi.waitFor(() => {
      expect(driver.state.editorContainer.children[0]).toBeInstanceOf(EffortSelectorComponent);
    });
    const picker = driver.state.editorContainer.children[0] as EffortSelectorComponent;
    expect(picker.render(80).join('\n')).toContain('Max');
  });

  it('keeps rejecting efforts hidden by a Kimi support_efforts override', async () => {
    const session = makeSession();
    const { driver } = await makeDriver(session, {
      getConfig: vi.fn(async () => ({
        providers: {
          kimi: { type: 'kimi', apiKey: 'test-key' },
        },
        models: {
          k2: {
            provider: 'kimi',
            model: 'kimi-model',
            maxContextSize: 100,
            capabilities: ['thinking'],
            supportEfforts: ['low', 'high'],
          },
        },
        defaultModel: 'k2',
        thinking: { enabled: true, effort: 'low' },
      })),
    });

    driver.handleUserInput('/effort max');

    await vi.waitFor(() => {
      expect(renderTranscript(driver)).toContain(
        'Unsupported thinking effort "max" for k2. Available: off, low, high',
      );
    });
    expect(session.setThinking).not.toHaveBeenCalled();
  });
});

describe('transcript step and assistant folding', () => {
  function driveSteps(driver: MessageDriver, cycles: number): void {
    for (let i = 0; i < cycles; i++) {
      driver.sessionEventHandler.handleEvent(
        {
          type: 'assistant.delta',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          delta: `msg-${i} `,
        } as Event,
        vi.fn(),
      );
      driver.sessionEventHandler.handleEvent(
        {
          type: 'tool.call.started',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          toolCallId: `call_${i}`,
          name: 'Bash',
          args: { command: 'ls' },
        } as Event,
        vi.fn(),
      );
      driver.sessionEventHandler.handleEvent(
        {
          type: 'tool.result',
          agentId: 'main',
          sessionId: 'ses-1',
          turnId: 1,
          toolCallId: `call_${i}`,
          output: 'ok',
          isError: undefined,
        } as Event,
        vi.fn(),
      );
    }
  }

  it('folds the oldest assistant messages and steps beyond their per-turn caps', async () => {
    const { driver } = await makeDriver();
    driver.handleUserInput('fold me');

    const cycles = Math.max(TRANSCRIPT_KEEP_RECENT_ASSISTANT, TRANSCRIPT_KEEP_RECENT_STEPS) + 7;
    driveSteps(driver, cycles);

    const children = driver.state.transcriptContainer.children;
    const assistantCount = children.filter(
      (child) => child instanceof AssistantMessageComponent,
    ).length;
    const toolCount = children.filter((child) => child instanceof ToolCallComponent).length;
    expect(assistantCount).toBe(TRANSCRIPT_KEEP_RECENT_ASSISTANT);
    expect(toolCount).toBe(TRANSCRIPT_KEEP_RECENT_STEPS);

    const summaries = children.filter((child) => child instanceof StepSummaryComponent);
    expect(summaries).toHaveLength(1);
    const summaryText = stripSgr(summaries[0]!.render(120).join('\n'));
    expect(summaryText).toContain(`call ${cycles - TRANSCRIPT_KEEP_RECENT_STEPS} tools`);
    expect(summaryText).toContain(`${cycles - TRANSCRIPT_KEEP_RECENT_ASSISTANT} messages`);

    // Folding drops mounted components only; every transcript entry is kept.
    const assistantEntries = driver.state.transcriptEntries.filter(
      (entry) => entry.kind === 'assistant',
    );
    expect(assistantEntries).toHaveLength(cycles);
  });

  it('does not fold a turn within the caps', async () => {
    const { driver } = await makeDriver();
    driver.handleUserInput('small turn');
    driveSteps(driver, 3);

    const children = driver.state.transcriptContainer.children;
    expect(children.filter((child) => child instanceof AssistantMessageComponent)).toHaveLength(3);
    expect(children.filter((child) => child instanceof ToolCallComponent)).toHaveLength(3);
    expect(children.filter((child) => child instanceof StepSummaryComponent)).toHaveLength(0);
  });

  it('folds a completed turn down to its conclusion tail on turn end', async () => {
    const { driver } = await makeDriver();
    driver.handleUserInput('round one');
    const cycles = 10;
    driveSteps(driver, cycles);

    // Below the active-turn caps, nothing folds while the turn is live.
    let children = driver.state.transcriptContainer.children;
    expect(
      children.filter((child) => child instanceof AssistantMessageComponent),
    ).toHaveLength(cycles);

    driver.sessionEventHandler.handleEvent(
      {
        type: 'turn.ended',
        agentId: 'main',
        sessionId: 'ses-1',
        turnId: 1,
        reason: 'completed',
      } as Event,
      vi.fn(),
    );

    children = driver.state.transcriptContainer.children;
    const assistants = children.filter((child) => child instanceof AssistantMessageComponent);
    expect(assistants).toHaveLength(TRANSCRIPT_KEEP_RECENT_ASSISTANT_COMPLETED);

    const summaries = children.filter((child) => child instanceof StepSummaryComponent);
    expect(summaries).toHaveLength(1);
    const summaryText = stripSgr(summaries[0]!.render(120).join('\n'));
    expect(summaryText).toContain(`${cycles - TRANSCRIPT_KEEP_RECENT_ASSISTANT_COMPLETED} messages`);

    // Steps below the step cap are untouched by the completed-turn fold.
    expect(children.filter((child) => child instanceof ToolCallComponent)).toHaveLength(cycles);

    // The conclusion stays mounted.
    const lastAssistant = assistants.at(-1)!;
    expect(stripSgr(lastAssistant.render(120).join('\n'))).toContain(`msg-${cycles - 1}`);
  });
});
