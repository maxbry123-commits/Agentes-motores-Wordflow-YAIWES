# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import copy
import logging
import threading
import time
from typing import Any
from uuid import UUID
from uuid import uuid4

from langchain_core.callbacks import AsyncCallbackHandler
from langchain_core.messages import AIMessage
from langchain_core.messages import BaseMessage
from langchain_core.outputs import ChatGeneration
from langchain_core.outputs import LLMResult

from nat.builder.context import Context
from nat.builder.framework_enum import LLMFrameworkEnum
from nat.data_models.intermediate_step import IntermediateStepPayload
from nat.data_models.intermediate_step import IntermediateStepType
from nat.data_models.intermediate_step import ServerToolUseSchema
from nat.data_models.intermediate_step import StreamEventData
from nat.data_models.intermediate_step import ToolDetails
from nat.data_models.intermediate_step import ToolParameters
from nat.data_models.intermediate_step import ToolSchema
from nat.data_models.intermediate_step import TraceMetadata
from nat.data_models.intermediate_step import UsageInfo
from nat.data_models.profiler_callback import BaseProfilerCallback
from nat.data_models.token_usage import TokenUsageBaseModel

logger = logging.getLogger(__name__)


def _extract_tools_schema(invocation_params: dict) -> list:

    tools_schema = []
    if invocation_params is not None:
        for tool in invocation_params.get("tools", []):
            try:
                tools_schema.append(ToolSchema(**tool))
            except Exception:
                # Handle non-OpenAI tool formats (e.g. Anthropic: top-level name/description/input_schema)
                try:
                    input_schema = tool.get("input_schema") or {}
                    tools_schema.append(
                        ToolSchema(
                            type="function",
                            function=ToolDetails(
                                name=tool["name"],
                                description=tool.get("description", ""),
                                parameters=ToolParameters(
                                    properties=input_schema.get("properties", {}),
                                    required=input_schema.get("required", []),
                                    additionalProperties=input_schema.get("additionalProperties", False),
                                ),
                            ),
                        ))
                except (KeyError, TypeError, AttributeError):
                    logger.exception(
                        "Failed to parse tool schema from invocation params: %s. \n This "
                        "can occur when the LLM server has native tools and can be ignored if "
                        "using the responses API.",
                        tool)

    return tools_schema


def _extract_run_name(serialized: dict[str, Any], fallback: str = "") -> str:
    if not isinstance(serialized, dict):
        return fallback

    name = serialized.get("name") or serialized.get("lc_name")
    if name:
        return str(name)

    serialized_id = serialized.get("id")
    if isinstance(serialized_id, list) and serialized_id:
        return str(serialized_id[-1])
    if serialized_id:
        return str(serialized_id)

    return fallback


class LangchainProfilerHandler(AsyncCallbackHandler, BaseProfilerCallback):
    """Callback Handler that tracks NIM info."""

    total_tokens: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    successful_requests: int = 0
    raise_error = True  # Override to raise error and run inline
    run_inline = True

    def __init__(self) -> None:
        super().__init__()
        self._lock = threading.Lock()
        self.last_call_ts = time.time()

        self.step_manager = Context.get().intermediate_step_manager
        self._state = IntermediateStepType.LLM_END

        self._run_id_to_model_name = {}
        self._run_id_to_llm_input = {}
        self._run_id_to_tool_input = {}
        self._run_id_to_chain_input = {}
        self._run_id_to_chain_name = {}
        self._run_id_to_start_time = {}

    def __repr__(self) -> str:
        return (f"Tokens Used: {self.total_tokens}\n"
                f"\tPrompt Tokens: {self.prompt_tokens}\n"
                f"\tCompletion Tokens: {self.completion_tokens}\n"
                f"Successful Requests: {self.successful_requests}\n")

    def __getstate__(self):
        """Used for serializing instances"""

        # start with a copy so we don't accidentally modify the object state
        # or cause other conflicts
        state = self.__dict__.copy()

        # remove unpicklable entries
        del state["_lock"]
        del state["step_manager"]
        return state

    def __setstate__(self, state):
        """Used for deserializing"""
        # restore the state which was picklable

        if (getattr(self, "_lock", None) is None):
            setattr(self, "_lock", threading.Lock())

        with self._lock:
            self.__dict__.update(state)

            if (getattr(self, "step_manager", None) is None):
                setattr(self, "step_manager", Context.get().intermediate_step_manager)

    @property
    def always_verbose(self) -> bool:
        """Whether to call verbose callbacks even if verbose is False."""
        return True

    def _extract_token_base_model(self, usage_metadata: dict[str, Any]) -> TokenUsageBaseModel:
        if usage_metadata:
            prompt_tokens = usage_metadata.get("input_tokens", 0)
            completion_tokens = usage_metadata.get("output_tokens", 0)
            total_tokens = usage_metadata.get("total_tokens", 0)

            cache_tokens = usage_metadata.get("input_token_details", {}).get("cache_read", 0)

            reasoning_tokens = usage_metadata.get("output_token_details", {}).get("reasoning", 0)

            return TokenUsageBaseModel(prompt_tokens=prompt_tokens,
                                       completion_tokens=completion_tokens,
                                       total_tokens=total_tokens,
                                       cached_tokens=cache_tokens,
                                       reasoning_tokens=reasoning_tokens)
        return TokenUsageBaseModel()

    async def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], **kwargs: Any) -> None:

        model_name = ""
        try:
            model_name = kwargs.get("metadata")["ls_model_name"]
        except Exception as e:
            logger.exception("Error getting model name: %s", e)

        run_id = str(kwargs.get("run_id", str(uuid4())))
        self._run_id_to_model_name[run_id] = model_name

        stats = IntermediateStepPayload(event_type=IntermediateStepType.LLM_START,
                                        framework=LLMFrameworkEnum.LANGCHAIN,
                                        name=model_name,
                                        UUID=run_id,
                                        data=StreamEventData(input=prompts[-1]),
                                        metadata=TraceMetadata(chat_inputs=copy.deepcopy(prompts)),
                                        usage_info=UsageInfo(token_usage=TokenUsageBaseModel(),
                                                             num_llm_calls=1,
                                                             seconds_between_calls=int(time.time() -
                                                                                       self.last_call_ts)))

        self.step_manager.push_intermediate_step(stats)
        self._run_id_to_llm_input[run_id] = prompts[-1]
        self._state = IntermediateStepType.LLM_START
        self.last_call_ts = time.time()
        self._run_id_to_start_time[run_id] = time.time()

    async def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:

        model_name = ""
        try:
            model_name = metadata["ls_model_name"] if metadata else kwargs.get("metadata")["ls_model_name"]
        except Exception as e:
            logger.exception("Error getting model name: %s", e)

        run_id = str(run_id)
        self._run_id_to_model_name[run_id] = model_name

        stats = IntermediateStepPayload(
            event_type=IntermediateStepType.LLM_START,
            framework=LLMFrameworkEnum.LANGCHAIN,
            name=model_name,
            UUID=run_id,
            data=StreamEventData(input=copy.deepcopy(messages[0])),
            metadata=TraceMetadata(chat_inputs=copy.deepcopy(messages[0]),
                                   tools_schema=_extract_tools_schema(kwargs.get("invocation_params", {}))),
            usage_info=UsageInfo(token_usage=TokenUsageBaseModel(),
                                 num_llm_calls=1,
                                 seconds_between_calls=int(time.time() - self.last_call_ts)))

        self.step_manager.push_intermediate_step(stats)
        self._run_id_to_llm_input[run_id] = messages[0][-1].content
        self._state = IntermediateStepType.LLM_START
        self.last_call_ts = time.time()
        self._run_id_to_start_time[run_id] = time.time()

    async def on_llm_new_token(self, token: str, **kwargs: Any) -> None:
        """Collect stats for just the token"""
        model_name = ""
        try:
            model_name = self._run_id_to_model_name.get(str(kwargs.get("run_id", "")), "")
        except Exception as e:
            logger.exception("Error getting model name: %s", e)

        usage_metadata = {}
        try:
            usage_metadata = kwargs.get("chunk").message.usage_metadata if kwargs.get("chunk") else {}
        except Exception as e:
            logger.exception("Error getting usage metadata: %s", e)

        stats = IntermediateStepPayload(
            event_type=IntermediateStepType.LLM_NEW_TOKEN,
            framework=LLMFrameworkEnum.LANGCHAIN,
            name=model_name,
            UUID=str(kwargs.get("run_id", str(uuid4()))),
            data=StreamEventData(input=self._run_id_to_llm_input.get(str(kwargs.get("run_id", "")), ""), chunk=token),
            usage_info=UsageInfo(token_usage=self._extract_token_base_model(usage_metadata),
                                 num_llm_calls=1,
                                 seconds_between_calls=int(time.time() - self.last_call_ts)),
            metadata=TraceMetadata(chat_responses=[kwargs.get("chunk")] if kwargs.get("chunk") else []))

        self.step_manager.push_intermediate_step(stats)

    async def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Collect token usage."""

        usage_metadata = {}

        model_name = ""
        try:
            model_name = response.llm_output["model_name"]
        except Exception as e:
            try:
                model_name = self._run_id_to_model_name.get(str(kwargs.get("run_id", "")), "")
            except Exception as e_inner:
                logger.exception("Error getting model name: %s from outer error %s", e_inner, e)

        try:
            generation = response.generations[0][0]
        except IndexError:
            generation = None

        message = None
        if isinstance(generation, ChatGeneration):
            try:
                message = generation.message
                if isinstance(message, AIMessage):
                    usage_metadata = message.usage_metadata
                else:
                    usage_metadata = {}
            except AttributeError:
                usage_metadata = {}

        if generation:
            llm_text_output = generation.message.content
            if "tool_calls" in generation.message.additional_kwargs:
                # add tool calls if included in the output
                tool_calls = generation.message.additional_kwargs['tool_calls']
                llm_text_output = f"{llm_text_output}\n\nTool calls: {tool_calls}"
            elif isinstance(message, AIMessage) and message.tool_calls:
                tool_calls = message.tool_calls
                llm_text_output = f"{llm_text_output}\n\nTool calls: {tool_calls}"
        else:
            llm_text_output = ""

        tool_outputs_list = []
        # Check if message.additional_kwargs as tool_outputs indicative of server side tool calling
        if message and message.additional_kwargs and "tool_outputs" in message.additional_kwargs:
            tools_outputs = message.additional_kwargs["tool_outputs"]
            if isinstance(tools_outputs, list):
                for tool in tools_outputs:
                    try:
                        tool_outputs_list.append(ServerToolUseSchema(**tool))
                    except Exception:
                        pass

        # update shared state behind lock
        with self._lock:
            usage_stat = IntermediateStepPayload(
                span_event_timestamp=self._run_id_to_start_time.get(str(kwargs.get("run_id", "")), time.time()),
                event_type=IntermediateStepType.LLM_END,
                framework=LLMFrameworkEnum.LANGCHAIN,
                name=model_name,
                UUID=str(kwargs.get("run_id", str(uuid4()))),
                data=StreamEventData(input=self._run_id_to_llm_input.get(str(kwargs.get("run_id", "")), ""),
                                     output=llm_text_output,
                                     payload=generation),
                usage_info=UsageInfo(token_usage=self._extract_token_base_model(usage_metadata)),
                metadata=TraceMetadata(chat_responses=[generation] if generation else [],
                                       tool_outputs=tool_outputs_list if tool_outputs_list else []))

            self.step_manager.push_intermediate_step(usage_stat)

        self._state = IntermediateStepType.LLM_END

    async def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        inputs: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> Any:

        stats = IntermediateStepPayload(event_type=IntermediateStepType.TOOL_START,
                                        framework=LLMFrameworkEnum.LANGCHAIN,
                                        name=serialized.get("name", ""),
                                        UUID=str(run_id),
                                        data=StreamEventData(input=input_str),
                                        metadata=TraceMetadata(tool_inputs=copy.deepcopy(inputs),
                                                               tool_info=copy.deepcopy(serialized)),
                                        usage_info=UsageInfo(token_usage=TokenUsageBaseModel()))

        self.step_manager.push_intermediate_step(stats)
        self._run_id_to_tool_input[str(run_id)] = input_str
        self._run_id_to_start_time[str(run_id)] = time.time()

    async def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:

        run_id_str = str(run_id)
        start_time = time.time()
        name = _extract_run_name(serialized, fallback=kwargs.get("name", ""))
        chain_inputs = copy.deepcopy(inputs)

        stats = IntermediateStepPayload(event_type=IntermediateStepType.FUNCTION_START,
                                        framework=LLMFrameworkEnum.LANGCHAIN,
                                        name=name,
                                        UUID=run_id_str,
                                        tags=copy.deepcopy(tags),
                                        data=StreamEventData(input=chain_inputs, payload=copy.deepcopy(serialized)),
                                        metadata=TraceMetadata(span_inputs=chain_inputs,
                                                               provided_metadata=copy.deepcopy(metadata)),
                                        usage_info=UsageInfo(token_usage=TokenUsageBaseModel()))

        self.step_manager.push_intermediate_step(stats)
        self._run_id_to_chain_input[run_id_str] = chain_inputs
        self._run_id_to_chain_name[run_id_str] = name
        self._run_id_to_start_time[run_id_str] = start_time

    def _clear_chain_run_state(self, run_id_str: str) -> None:
        self._run_id_to_chain_input.pop(run_id_str, None)
        self._run_id_to_chain_name.pop(run_id_str, None)
        self._run_id_to_start_time.pop(run_id_str, None)

    async def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:

        run_id_str = str(run_id)
        chain_outputs = copy.deepcopy(outputs)
        chain_input = self._run_id_to_chain_input.get(run_id_str, "")
        chain_name = self._run_id_to_chain_name.get(run_id_str, kwargs.get("name", ""))
        chain_start_time = self._run_id_to_start_time.get(run_id_str, time.time())

        stats = IntermediateStepPayload(event_type=IntermediateStepType.FUNCTION_END,
                                        span_event_timestamp=chain_start_time,
                                        framework=LLMFrameworkEnum.LANGCHAIN,
                                        name=chain_name,
                                        UUID=run_id_str,
                                        tags=copy.deepcopy(tags),
                                        metadata=TraceMetadata(span_outputs=chain_outputs),
                                        usage_info=UsageInfo(token_usage=TokenUsageBaseModel()),
                                        data=StreamEventData(input=chain_input,
                                                             output=chain_outputs,
                                                             payload=chain_outputs))

        self.step_manager.push_intermediate_step(stats)
        self._clear_chain_run_state(run_id_str)

    async def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        **kwargs: Any,
    ) -> None:

        self._clear_chain_run_state(str(run_id))

    async def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> Any:

        stats = IntermediateStepPayload(event_type=IntermediateStepType.TOOL_END,
                                        span_event_timestamp=self._run_id_to_start_time.get(str(run_id), time.time()),
                                        framework=LLMFrameworkEnum.LANGCHAIN,
                                        name=kwargs.get("name", ""),
                                        UUID=str(run_id),
                                        metadata=TraceMetadata(tool_outputs=output),
                                        usage_info=UsageInfo(token_usage=TokenUsageBaseModel()),
                                        data=StreamEventData(input=self._run_id_to_tool_input.get(str(run_id), ""),
                                                             output=output,
                                                             payload=output))

        self.step_manager.push_intermediate_step(stats)
