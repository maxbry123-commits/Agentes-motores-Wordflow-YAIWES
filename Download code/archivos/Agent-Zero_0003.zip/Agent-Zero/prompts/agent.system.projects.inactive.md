no project currently activated
