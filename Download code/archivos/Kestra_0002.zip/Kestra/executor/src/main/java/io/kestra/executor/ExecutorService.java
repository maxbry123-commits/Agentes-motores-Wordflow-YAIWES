package io.kestra.executor;

import java.time.DateTimeException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.event.Level;

import io.kestra.core.assets.AssetService;
import io.kestra.core.debug.Breakpoint;
import io.kestra.core.exceptions.InternalException;
import io.kestra.core.exceptions.NoMatchingWorkerQueueException;
import io.kestra.core.metrics.MetricRegistry;
import io.kestra.core.models.Label;
import io.kestra.core.models.assets.AssetIdentifier;
import io.kestra.core.models.assets.AssetUser;
import io.kestra.core.models.assets.AssetsDeclaration;
import io.kestra.core.models.assets.AssetsInOut;
import io.kestra.core.models.executions.*;
import io.kestra.core.models.flows.FlowInterface;
import io.kestra.core.models.flows.FlowWithSource;
import io.kestra.core.models.flows.State;
import io.kestra.core.models.flows.sla.Violation;
import io.kestra.core.models.tasks.*;
import io.kestra.core.models.tasks.Output;
import io.kestra.core.models.tasks.retrys.AbstractRetry;
import io.kestra.core.queues.BroadcastQueueInterface;
import io.kestra.core.queues.DispatchQueueInterface;
import io.kestra.core.queues.QueueException;
import io.kestra.core.runners.*;
import io.kestra.core.runners.SubflowExecutionEnd;
import io.kestra.core.services.*;
import io.kestra.core.test.flow.TaskFixture;
import io.kestra.core.trace.propagation.RunContextTextMapSetter;
import io.kestra.core.utils.*;
import io.kestra.core.worker.WorkerQueues;
import io.kestra.plugin.core.flow.*;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.propagation.ContextPropagators;
import io.opentelemetry.context.propagation.TextMapPropagator;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;

import static io.kestra.core.utils.Rethrow.throwConsumer;
import static io.kestra.core.utils.Rethrow.throwFunction;

@Singleton
@Slf4j
public class ExecutorService {
    private final RunContextFactory runContextFactory;
    private final MetricRegistry metricRegistry;
    protected final FlowMetaStoreInterface flowExecutorInterface;
    private final ExecutionService executionService;
    private final WorkerQueueService workerQueueService;
    private final SLAService slaService;
    private final Optional<OpenTelemetry> openTelemetry;
    protected final BroadcastQueueInterface<ExecutionKilled> killQueue;
    private final DispatchQueueInterface<LoopExecutionEvent> loopExecutionEventQueue;
    private final RunContextLoggerFactory runContextLoggerFactory;
    private final AssetService assetService;
    private final RunContextInitializer runContextInitializer;
    private final TaskOutputService taskOutputService;
    private final ExecutionOutputService executionOutputService;
    private final PausedTaskNotifier pausedTaskNotifier;

    @Inject
    public ExecutorService(
        RunContextFactory runContextFactory,
        MetricRegistry metricRegistry,
        FlowMetaStoreInterface flowExecutorInterface,
        ExecutionService executionService,
        WorkerQueueService workerQueueService,
        SLAService slaService,
        Optional<OpenTelemetry> openTelemetry,
        BroadcastQueueInterface<ExecutionKilled> killQueue,
        DispatchQueueInterface<LoopExecutionEvent> loopExecutionEventQueue,
        RunContextLoggerFactory runContextLoggerFactory,
        AssetService assetService,
        RunContextInitializer runContextInitializer,
        TaskOutputService taskOutputService,
        ExecutionOutputService executionOutputService,
        PausedTaskNotifier pausedTaskNotifier) {
        this.runContextFactory = runContextFactory;
        this.metricRegistry = metricRegistry;
        this.flowExecutorInterface = flowExecutorInterface;
        this.executionService = executionService;
        this.workerQueueService = workerQueueService;
        this.slaService = slaService;
        this.openTelemetry = openTelemetry;
        this.killQueue = killQueue;
        this.loopExecutionEventQueue = loopExecutionEventQueue;
        this.runContextLoggerFactory = runContextLoggerFactory;
        this.assetService = assetService;
        this.runContextInitializer = runContextInitializer;
        this.taskOutputService = taskOutputService;
        this.executionOutputService = executionOutputService;
        this.pausedTaskNotifier = pausedTaskNotifier;
    }

    /**
     * Evaluate the scoped concurrency limits in order against their running counts: the first
     * limit reached defines the behavior applied to the execution; when none is reached the
     * execution runs.
     */
    public ExecutionRunning processExecutionRunning(List<ScopedConcurrencyLimit> limits, List<Integer> runningCounts, ExecutionRunning executionRunning) {
        for (int i = 0; i < limits.size(); i++) {
            ScopedConcurrencyLimit limit = limits.get(i);
            int runningCount = runningCounts.get(i);
            if (runningCount < limit.concurrency().getLimit()) {
                continue;
            }

            return switch (limit.concurrency().getBehavior()) {
                case QUEUE -> {
                    Logs.logExecution(
                        executionRunning.getExecution(),
                        Level.INFO,
                        "Execution is queued due to " + scopeDescription(limit) + "concurrency limit exceeded, {} running(s)",
                        runningCount
                    );
                    var newExecution = executionRunning.getExecution().withState(State.Type.QUEUED);
                    metricRegistry
                        .counter(MetricRegistry.METRIC_EXECUTOR_EXECUTION_QUEUED_COUNT, MetricRegistry.METRIC_EXECUTOR_EXECUTION_QUEUED_COUNT_DESCRIPTION, metricRegistry.tags(newExecution))
                        .increment();
                    yield executionRunning
                        .withExecution(newExecution)
                        .withConcurrencyState(ExecutionRunning.ConcurrencyState.QUEUED);
                }
                case CANCEL -> executionRunning
                    .withExecution(executionRunning.getExecution().withState(State.Type.CANCELLED))
                    .withConcurrencyState(ExecutionRunning.ConcurrencyState.CANCELLED);
                case FAIL -> {
                    var failedExecution = executionRunning.getExecution()
                        .failedExecutionFromExecutor(new IllegalStateException("Execution is FAILED due to " + scopeDescription(limit) + "concurrency limit exceeded"));
                    var logger = runContextLoggerFactory.create(executionRunning.getExecution());
                    logger.emitLogs(failedExecution.logs());
                    yield executionRunning
                        .withExecution(failedExecution.execution())
                        .withConcurrencyState(ExecutionRunning.ConcurrencyState.FAILED);
                }

            };
        }

        // if under every limit, run it!
        return runExecutionRunning(executionRunning);
    }

    private static ExecutionRunning runExecutionRunning(ExecutionRunning executionRunning) {
        return executionRunning
            .withExecution(executionRunning.getExecution().withState(State.Type.RUNNING))
            .withConcurrencyState(ExecutionRunning.ConcurrencyState.RUNNING);
    }

    private static String scopeDescription(ScopedConcurrencyLimit limit) {
        return switch (limit.scope()) {
            case FLOW -> "";
            case NAMESPACE -> "namespace '" + limit.namespace() + "' ";
            case TENANT -> "tenant ";
        };
    }

    public ExecutorContext process(ExecutorContext executor) {
        // previous failed (flow join can fail), just forward
        // or concurrency limit failed/cancelled the execution
        if (!executor.canBeProcessed() || executionService.isTerminated(executor.getFlow(), executor.getExecution())) {
            return executor;
        }

        long nanos = System.nanoTime();
        try {
            executor = this.handleRestart(executor);
            executor = this.handleEnd(executor);
            // if killing: move created tasks to killed as they are not already started
            executor = this.handleCreatedKilling(executor);
            //then set the execution to killed
            executor = this.handleKilling(executor);

            // process next task if not killing, killed or queued
            if (
                executor.getExecution().getState().getCurrent() != State.Type.KILLING && executor.getExecution().getState().getCurrent() != State.Type.KILLED
                    && executor.getExecution().getState().getCurrent() != State.Type.QUEUED
            ) {
                executor = this.handleNext(executor);
            }

            // but keep listeners on killing
            executor = this.handleAfterExecution(executor);

            // send worker task to the Worker
            executor = this.handleWorkerTasks(executor);

            // process flowable tasks
            executor = this.handleFlowableTasks(executor);

            // search for execution updating tasks
            executor = this.handleExecutionUpdatingTasks(executor);

            // search for flow task
            executor = this.handleExecutableTasks(executor);
        } catch (Exception e) {
            return executor.withException(e, "process");
        } finally {
            metricRegistry
                .timer(
                    MetricRegistry.METRIC_EXECUTOR_EXECUTION_MESSAGE_PROCESS_DURATION, MetricRegistry.METRIC_EXECUTOR_EXECUTION_MESSAGE_PROCESS_DURATION_DESCRIPTION,
                    metricRegistry.tags(executor.getExecution())
                )
                .record(Duration.ofNanos(System.nanoTime() - nanos));
        }

        return executor;
    }

    public Execution onNext(Execution execution, int nextCount) {
        if (log.isTraceEnabled()) {
            Logs.logExecution(
                execution,
                Level.TRACE,
                "Found {} next(s) tasks to process",
                nextCount
            );
        }

        if (execution.getState().getCurrent() != State.Type.CREATED) {
            return execution;
        }

        metricRegistry
            .counter(MetricRegistry.METRIC_EXECUTOR_EXECUTION_STARTED_COUNT, MetricRegistry.METRIC_EXECUTOR_EXECUTION_STARTED_COUNT_DESCRIPTION, metricRegistry.tags(execution))
            .increment();

        Logs.logExecution(
            execution,
            Level.INFO,
            "Flow started"
        );

        return execution.withState(State.Type.RUNNING);
    }

    public ExecutorContext handleFailedExecutionFromExecutor(ExecutorContext executor, Exception e) {
        Execution.FailedExecutionWithLog failedExecutionWithLog = executor.getExecution().failedExecutionFromExecutor(e);
        var logger = runContextLoggerFactory.create(failedExecutionWithLog.execution());
        logger.emitLogs(failedExecutionWithLog.logs());
        return executor.withExecution(failedExecutionWithLog.execution(), "exception");
    }

    private Optional<WorkerTaskResult> childWorkerTaskResult(FlowWithSource flow, Execution execution, TaskRun parentTaskRun, RunContext runContext) throws InternalException {
        Task parent = flow.findTaskByTaskId(parentTaskRun.getTaskId());

        if (parent instanceof FlowableTask<?> flowableParent) {

            // first find the normal ended child tasks and send result
            Optional<State.Type> state;
            try {
                state = flowableParent.resolveState(runContext, execution, parentTaskRun);
            } catch (Exception e) {
                // This will lead to the next task being still executed, but at least Kestra will not crash.
                // This is the best we can do, Flowable task should not fail, so it's a kind of panic mode.
                runContext.logger().error("Unable to resolve state from the Flowable task: {}", e.getMessage(), e);
                state = Optional.of(State.Type.FAILED);
            }
            Optional<WorkerTaskResult> endedTask = childWorkerTaskTypeToWorkerTask(
                state,
                parentTaskRun
            );

            if (endedTask.isPresent()) {
                WorkerTaskResult workerTaskResult = endedTask.get();
                // Compute outputs for the parent Flowable task if a terminated state was resolved
                if (workerTaskResult.getTaskRun().getState().isTerminated()) {
                    var outputs = workerTaskResult.getOutputs();
                    try {
                        // as flowable tasks can save outputs during iterative execution, we must merge the maps here
                        Output parentOutputs = flowableParent.outputs(runContext);
                        if (parentOutputs != null) {
                            outputs = MapUtils.merge(outputs, parentOutputs.toMap());
                        }
                    } catch (Exception e) {
                        runContext.logger().error("Unable to resolve outputs from the Flowable task: {}", e.getMessage(), e);
                        outputs = Collections.emptyMap();
                    }

                    taskOutputService.saveOutputs(workerTaskResult.getTaskRun(), outputs);

                    // flowable attempt state transition to terminated
                    List<TaskRunAttempt> attempts = Optional.ofNullable(parentTaskRun.getAttempts())
                        .map(ArrayList::new)
                        .orElseGet(ArrayList::new);
                    if (!attempts.isEmpty()) { // can occur on migration from pre-1.2
                        State.Type endedState = endedTask.get().getTaskRun().getState().getCurrent();
                        TaskRunAttempt updated = attempts.getLast().withState(endedState);
                        attempts.set(attempts.size() - 1, updated);
                    }

                    return Optional.of(
                        new WorkerTaskResult(
                            workerTaskResult
                                .getTaskRun()
                                .withAttempts(attempts)
                        )
                    );
                }
                return endedTask;
            }

            // after if the execution is KILLING, we find if all already started tasks if finished
            if (execution.getState().getCurrent() == State.Type.KILLING) {
                // first notified the parent taskRun of killing to avoid new creation of tasks
                if (parentTaskRun.getState().getCurrent() != State.Type.KILLING) {
                    return childWorkerTaskTypeToWorkerTask(
                        Optional.of(State.Type.KILLING),
                        parentTaskRun
                    );
                }

                // Then wait for completion (KILLED or whatever) on child tasks to KILLED the parent one.
                List<ResolvedTask> currentTasks = execution.findTaskDependingFlowState(
                    flowableParent.childTasks(runContext, parentTaskRun),
                    FlowableUtils.resolveTasks(flowableParent.getErrors(), parentTaskRun),
                    FlowableUtils.resolveTasks(flowableParent.getFinally(), parentTaskRun)
                );

                List<TaskRun> taskRunByTasks = execution.findTaskRunByTasks(currentTasks, parentTaskRun);

                if (taskRunByTasks.stream().filter(t -> t.getState().isTerminated()).count() == taskRunByTasks.size()) {
                    // Use withStateAndAttempt so the last attempt gets an end date; withState alone
                    // leaves the attempt in RUNNING, causing the UI to show a stuck duration counter.
                    return Optional.of(new WorkerTaskResult(parentTaskRun.withStateAndAttempt(State.Type.KILLED)));
                }
            }
        }

        return Optional.empty();
    }

    private Optional<WorkerTaskResult> childWorkerTaskTypeToWorkerTask(
        Optional<State.Type> findState,
        TaskRun taskRun) {
        return findState
            .map(throwFunction(type -> new WorkerTaskResult(taskRun.withState(type))));
    }

    /**
     * A flowable can only create a new child task run, via {@code resolveNexts}, or terminate, via
     * {@code resolveState}, when it has no child task run yet or when at least one of its child
     * task runs has terminated — every {@code FlowableUtils.resolveSequentialNexts}/{@code resolveParallelNexts}/
     * {@code resolveWaitForNext}/{@code resolveState} implementation already returns empty/absent
     * otherwise. Checking this upfront avoids building a {@link RunContext} (and its output query)
     * on cycles that can only resolve to nothing.
     */
    private boolean canChildrenProgress(Execution execution, TaskRun parentTaskRun) {
        if (execution.getTaskRunList() == null) {
            return true;
        }

        boolean hasChild = false;
        for (TaskRun taskRun : execution.getTaskRunList()) {
            if (parentTaskRun.getId().equals(taskRun.getParentTaskRunId())) {
                hasChild = true;
                if (taskRun.getState().isTerminated()) {
                    return true;
                }
            }
        }

        return !hasChild;
    }

    private List<TaskRun> childNextsTaskRun(ExecutorContext executor, TaskRun parentTaskRun, RunContext runContext) throws InternalException {
        Task parent = executor.getFlow().findTaskByTaskId(parentTaskRun.getTaskId());
        if (parent instanceof FlowableTask<?> flowableParent) {
            // Count the number of flowable tasks executions, some flowable are being called multiple times,
            // so this is not exactly the number of flowable taskruns but the number of times they are executed.
            metricRegistry
                .counter(MetricRegistry.METRIC_EXECUTOR_FLOWABLE_EXECUTION_COUNT, MetricRegistry.METRIC_EXECUTOR_FLOWABLE_EXECUTION_COUNT_DESCRIPTION, metricRegistry.tags(parent))
                .increment();

            try {
                List<NextTaskRun> nexts = flowableParent.resolveNexts(
                    runContext,
                    executor.getExecution(),
                    parentTaskRun
                );

                if (!nexts.isEmpty()) {
                    List<TaskRun> taskRuns = saveFlowableOutput(nexts, executor);
                    if (Boolean.TRUE.equals(parentTaskRun.getForceExecution())) {
                        return taskRuns.stream()
                            .map(taskRun -> taskRun.withForceExecution(true))
                            .toList();
                    }
                    return taskRuns;
                }
            } catch (ConstraintViolationException e) {
                // An invalid flowable config (e.g. a negative concurrency) is surfaced to the caller,
                // which fails the flowable task run so the execution terminates cleanly.
                throw e;
            } catch (Exception e) {
                log.warn("Unable to resolve the next tasks to run", e);
            }
        }

        return Collections.emptyList();
    }

    private List<TaskRun> saveFlowableOutput(
        List<NextTaskRun> nextTaskRuns,
        ExecutorContext executor) {
        return nextTaskRuns
            .stream()
            .map(throwFunction(t ->
            {
                TaskRun taskRun = t.getTaskRun();

                if (!(t.getTask() instanceof FlowableTask<?> flowableTask)) {
                    return taskRun;
                }
                RunContext runContext = runContextFactory.of(
                    executor.getFlow(),
                    t.getTask(),
                    executor.getExecution(),
                    t.getTaskRun()
                );

                try {
                    Output outputs = flowableTask.outputs(runContext);
                    taskOutputService.saveOutputs(taskRun, outputs);

                } catch (Exception e) {
                    runContext.logger().warn("Unable to save output on taskRun '{}'", taskRun, e);
                }

                return taskRun;
            }))
            .toList();
    }

    private ExecutorContext onEnd(ExecutorContext executor) {
        final FlowWithSource flow = executor.getFlow();

        // For LOOP sub-executions, use guessFinalState(List<ResolvedTask>, TaskRun, boolean, boolean) to compute the final state from the Loop's child tasks directly.
        State.Type finalState;
        if (executor.getExecution().getKind() == ExecutionKind.LOOP && executor.getExecution().getLoopRun() != null) {
            Loop loop = (Loop) flow.findTaskByTaskIdOrNull(executor.getExecution().getLoopRun().taskId());
            if (loop != null) {
                List<ResolvedTask> childTasks = loop.getTasks().stream().map(ResolvedTask::of).toList();
                finalState = executor.getExecution().guessFinalState(childTasks, null, false, false);
            } else {
                finalState = executor.getExecution().guessFinalState(flow);
            }
        } else {
            finalState = executor.getExecution().guessFinalState(flow);
        }

        Execution newExecution = executor.getExecution()
            .withState(finalState);

        if (flow.getOutputs() != null && executor.getExecution().getKind() != ExecutionKind.LOOP) {
            RunContext runContext = runContextFactory.of(executor.getFlow(), executor.getExecution());
            var inputAndOutput = runContext.inputAndOutput();

            try {
                Map<String, Object> outputs = inputAndOutput.renderOutputs(flow.getOutputs());
                outputs = inputAndOutput.typedOutputs(flow, executor.getExecution(), outputs);
                executionOutputService.saveOutputs(newExecution, outputs);
            } catch (Exception e) {
                Logs.logExecution(
                    executor.getExecution(),
                    Level.ERROR,
                    "Failed to render output values",
                    e
                );
                runContext.logger().error("Failed to render output values: {}", e.getMessage(), e);
                newExecution = newExecution.withState(State.Type.FAILED);
            }
        }

        Logs.logExecution(
            newExecution,
            Level.INFO,
            "Flow completed with state {} in {}",
            newExecution.getState().getCurrent(),
            newExecution.getState().humanDuration()
        );

        if (log.isTraceEnabled()) {
            log.trace(newExecution.toString(true));
        }

        metricRegistry
            .counter(MetricRegistry.METRIC_EXECUTOR_EXECUTION_END_COUNT, MetricRegistry.METRIC_EXECUTOR_EXECUTION_END_COUNT_DESCRIPTION, metricRegistry.tags(newExecution))
            .increment();

        metricRegistry
            .timer(MetricRegistry.METRIC_EXECUTOR_EXECUTION_DURATION, MetricRegistry.METRIC_EXECUTOR_EXECUTION_DURATION_DESCRIPTION, metricRegistry.tags(newExecution))
            .record(newExecution.getState().getDurationOrComputeIt());

        return executor.withExecution(newExecution, "onEnd");
    }

    private ExecutorContext handleNext(ExecutorContext executor) throws InternalException {
        List<NextTaskRun> nextTaskRuns;
        if (executor.getExecution().getKind() != ExecutionKind.LOOP) {
            nextTaskRuns = FlowableUtils.resolveSequentialNexts(
                executor.getExecution(),
                ResolvedTask.of(executor.getFlow().getTasks()),
                ResolvedTask.of(executor.getFlow().getErrors()),
                ResolvedTask.of(executor.getFlow().getFinally())
            );
        } else if (executor.getExecution().getLoopRun() != null) { // should always be true but better be safe
            // for LOOP executions: we only execute the loop itself, not the whole execution
            Loop loop = (Loop) executor.getFlow().findTaskByTaskId(executor.getExecution().getLoopRun().taskId());
            // Build a minimal task run representing the Loop in the parent execution so that child task runs get parentTaskRunId set.
            TaskRun loopTaskRun = TaskRun.builder()
                .id(executor.getExecution().getLoopRun().taskRunId())
                .build();
            nextTaskRuns = FlowableUtils.resolveSequentialNexts(
                executor.getExecution(),
                FlowableUtils.resolveTasks(loop.getTasks(), loopTaskRun),
                FlowableUtils.resolveTasks(loop.getErrors(), loopTaskRun),
                FlowableUtils.resolveTasks(loop.getFinally(), loopTaskRun),
                loopTaskRun
            );
        } else {
            // should never happen but better be safe
            return executor;
        }

        if (nextTaskRuns.isEmpty()) {
            return executor;
        }

        return executor.withTaskRun(
            this.saveFlowableOutput(nextTaskRuns, executor),
            "handleNext"
        );
    }

    private ExecutorContext handleFlowableTasks(ExecutorContext executor) throws Exception {
        if (executor.getExecution().getTaskRunList() == null) {
            return executor;
        }

        List<TaskRun> nextTaskRuns = new ArrayList<>();
        List<WorkerTaskResult> list = new ArrayList<>();
        List<ExecutionDelay> executionDelays = new ArrayList<>();
        List<ExecutorContext.ExecutorWorkerTask> onPauses = new ArrayList<>();

        for (TaskRun taskRun : executor.getExecution().getTaskRunList()) {
            Task task = executor.getFlow().findTaskByTaskIdOrNull(taskRun.getTaskId());

            // For running flowable tasks: compute both next task runs and the worker task result in a single pass.
            if (taskRun.getState().isRunning() && task instanceof FlowableTask<?> && this.canChildrenProgress(executor.getExecution(), taskRun)) {
                RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);
                try {
                    nextTaskRuns.addAll(this.childNextsTaskRun(executor, taskRun, runContext));
                    Optional<WorkerTaskResult> flowableResult = this.childWorkerTaskResult(executor.getFlow(), executor.getExecution(), taskRun, runContext);
                    if (flowableResult.isPresent()) {
                        list.add(flowableResult.get());
                        // fail-fast: a flowable that just resolved to FAILED asks to interrupt its still-running children
                        if (flowableResult.get().getTaskRun().getState().isFailed() && task instanceof OnChildFailureInterface onChildFailure) {
                            this.interruptOnChildFailure(executor, onChildFailure, taskRun, runContext);
                        }
                    }
                } catch (ConstraintViolationException e) {
                    // An invalid flowable configuration fails the flowable task run, which terminates the
                    // execution cleanly (failing the execution while the task run stays RUNNING would loop).
                    runContext.logger().error("Failed to process flowable task {}: {}", taskRun.getId(), e.getMessage(), e);
                    executor.withExecution(executor.getExecution().withTaskRun(taskRun.withState(State.Type.FAILED)), "flowableValidation");
                }
            }

            // For KILLING flowable tasks: only compute worker task result (kill-path) — no new child tasks
            if (taskRun.getState().getCurrent() == State.Type.KILLING && task instanceof FlowableTask<?>) {
                RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);
                this.childWorkerTaskResult(executor.getFlow(), executor.getExecution(), taskRun, runContext).ifPresent(list::add);
            }

            // Handle retry for runnable and flowable tasks
            if (
                !executor.getExecution().getState().isRetrying() &&
                    taskRun.getState().isFailed() &&
                    (task instanceof RunnableTask<?> || task instanceof Subflow)
            ) {
                Instant nextRetryDate = null;
                AbstractRetry.Behavior behavior = null;

                try {
                    // Case task has a retry
                    if (task.getRetry() != null) {
                        AbstractRetry retry = task.getRetry();
                        behavior = retry.getBehavior();
                        nextRetryDate = behavior.equals(AbstractRetry.Behavior.CREATE_NEW_EXECUTION) ? taskRun.nextRetryDate(retry, executor.getExecution()) : taskRun.nextRetryDate(retry);
                    } else {
                        // Case parent task has a retry
                        Task parentTaskWithRetry = searchForParentTaskWithRetry(taskRun, executor);
                        AbstractRetry retry = parentTaskWithRetry != null ? parentTaskWithRetry.getRetry() : null;
                        if (retry != null) {
                            // The parent's errors/finally tasks (e.g. AllowFailure.errors) must complete before the retry timer is allowed to fire.
                            if (!isErrorOrFinallyHandlingPending(taskRun, parentTaskWithRetry, executor, nextTaskRuns)) {
                                behavior = retry.getBehavior();
                                nextRetryDate = behavior.equals(AbstractRetry.Behavior.CREATE_NEW_EXECUTION) ? taskRun.nextRetryDate(retry, executor.getExecution()) : taskRun.nextRetryDate(retry);
                            }
                        }
                        // Case flow has a retry
                        else if (executor.getFlow().getRetry() != null) {
                            retry = executor.getFlow().getRetry();
                            behavior = retry.getBehavior();
                            nextRetryDate = behavior.equals(AbstractRetry.Behavior.CREATE_NEW_EXECUTION) ? executionService.nextRetryDate(retry, executor.getExecution())
                                : taskRun.nextRetryDate(retry);
                        }
                    }
                } catch (DateTimeException | ArithmeticException e) {
                    throw new InternalException("The retry interval or maxDuration is out of the supported range.", e);
                }

                if (nextRetryDate != null) {
                    ExecutionDelay.ExecutionDelayBuilder executionDelayBuilder = ExecutionDelay.builder()
                        .taskRunId(taskRun.getId())
                        .executionId(executor.getExecution().getId())
                        .date(nextRetryDate)
                        .state(State.Type.RUNNING)
                        .delayType(behavior.equals(AbstractRetry.Behavior.CREATE_NEW_EXECUTION) ? ExecutionDelay.DelayType.RESTART_FAILED_FLOW : ExecutionDelay.DelayType.RESTART_FAILED_TASK);
                    executionDelays.add(executionDelayBuilder.build());
                    executor.withExecution(
                        behavior.equals(AbstractRetry.Behavior.CREATE_NEW_EXECUTION) ? executionService.markWithTaskRunAs(executor.getExecution(), taskRun.getId(), State.Type.RETRIED, true)
                            : executionService.markWithTaskRunAs(executor.getExecution(), taskRun.getId(), State.Type.RETRYING, false),
                        "handleRetryTask"
                    );
                    // Prevent workerTaskResult from flowable tasks to be sent because one of its children is retrying
                    if (taskRun.getParentTaskRunId() != null) {
                        list = list.stream().filter(workerTaskResult -> !workerTaskResult.getTaskRun().getId().equals(taskRun.getParentTaskRunId()))
                            .collect(Collectors.toCollection(ArrayList::new));
                    }
                }
            }

            // handle flowable tasks Executor custom logic
            if (task instanceof FlowableTask<?>) {
                try {
                    switch (task) {
                        case LoopUntil waitFor when taskRun.getState().isRunning() -> {
                            if (waitFor.childTaskRunExecuted(executor.getExecution(), taskRun)) {
                                Map<String, Object> previousOutput = taskOutputService.getOutputs(taskRun);
                                RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution().withTaskRun(taskRun), taskRun);
                                Instant nextDate = waitFor.nextExecutionDate(runContext, executor.getExecution(), taskRun);
                                if (nextDate != null) {
                                    Output newOutput = waitFor.outputs(previousOutput);
                                    taskOutputService.saveOutputs(taskRun, newOutput);
                                    executionDelays.add(
                                        ExecutionDelay.builder()
                                            .taskRunId(taskRun.getId())
                                            .executionId(executor.getExecution().getId())
                                            .date(nextDate)
                                            .state(State.Type.RUNNING)
                                            .delayType(ExecutionDelay.DelayType.CONTINUE_FLOWABLE)
                                            .build()
                                    );
                                    Execution execution = executionService.pauseFlowable(executor.getExecution(), taskRun);
                                    executor.withExecution(execution, "pauseLoop");
                                } else {
                                    executor.withExecution(executor.getExecution().withTaskRun(taskRun), "handleWaitFor");
                                }
                            }
                        }
                        case Pause pause when pause.getOnPause() != null -> {
                            // if a Pause task defines an onPause, we must create a TaskRun and a WorkerTask
                            RunContext runContext = runContextFactory.of(executor.getFlow(), executor.getExecution());
                            WorkerTask pauseWorkerTask = WorkerTask.builder()
                                .data(WorkerTaskData.from(runContext))
                                .taskRun(
                                    TaskRun.of(
                                        executor.getExecution(),
                                        ResolvedTask.of(pause.getOnPause())
                                    )
                                )
                                .task(pause.getOnPause())
                                .executionKind(executor.getExecution().getKind())
                                .build();
                            onPauses.add(new ExecutorContext.ExecutorWorkerTask(pauseWorkerTask, runContext));
                        }
                        case Loop loop -> {
                            if (!loop.isMySubExecution(executor.getExecution(), taskRun)) {
                                if (taskRun.getState().getCurrent() == State.Type.CREATED) {
                                    RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);
                                    var valuesUri = FlowableUtils.resolveLoopValuesUri(runContext, loop.getValues());

                                    if (valuesUri.isPresent()) {
                                        var init = loop.initFromUri(runContext, valuesUri.get());
                                        // save the iteration information in outputs to know how many loop iterations we already triggered
                                        taskOutputService.saveOutputs(
                                            taskRun, Map.of(
                                                Loop.ITERATION_COUNT_OUTPUT, init.totalCount(),
                                                Loop.RUNNING_ITERATIONS_OUTPUT, init.limit(),
                                                Loop.TERMINATED_ITERATIONS_OUTPUT, HashMap.newHashMap(6),
                                                Loop.NEXT_OFFSET_OUTPUT, init.nextOffset()
                                            )
                                        );
                                        for (int i = 0; i < init.values().size(); i++) {
                                            var loopExecution = executor.getExecution().loopExecution(taskRun, i, null, init.values().get(i));
                                            executor.withLoopExecution(loopExecution, "handleLoopExecution");
                                        }
                                    } else {
                                        var init = loop.initFromValues(runContext);
                                        // save the iteration information in outputs to know how many loop iterations we already triggered
                                        taskOutputService.saveOutputs(
                                            taskRun, Map.of(
                                                Loop.ITERATION_COUNT_OUTPUT, init.totalCount(),
                                                Loop.RUNNING_ITERATIONS_OUTPUT, init.limit(),
                                                Loop.TERMINATED_ITERATIONS_OUTPUT, HashMap.newHashMap(6)
                                            )
                                        );

                                        if (init.totalCount() == 0) {
                                            // if no loop iteration, we end the task immediately
                                            executor.withExecution(
                                                executor.getExecution()
                                                    .withTaskRun(taskRun.withState(State.Type.SUCCESS)),
                                                "handleLoop"
                                            );
                                            // replace existing CREATED WorkerTask to SUCCESS
                                            executor.getWorkerTasks().replaceAll(
                                                ewt -> ewt.workerTask().getTaskRun().getId().equals(taskRun.getId())
                                                    ? new ExecutorContext.ExecutorWorkerTask(ewt.workerTask().withTaskRun(taskRun.withState(State.Type.SUCCESS)), ewt.runContext())
                                                    : ewt
                                            );
                                        } else {
                                            if (init.values().isLeft()) {
                                                List<String> values = init.values().getLeft();
                                                for (int i = 0; i < init.limit(); i++) {
                                                    var loopExecution = executor.getExecution().loopExecution(taskRun, i, null, values.get(i));
                                                    executor.withLoopExecution(loopExecution, "handleLoopExecution");
                                                }
                                            } else {
                                                List<Pair<String, String>> values = init.values().getRight();
                                                for (int i = 0; i < init.limit(); i++) {
                                                    var value = values.get(i);
                                                    var loopExecution = executor.getExecution().loopExecution(taskRun, i, value.getKey(), value.getValue());
                                                    executor.withLoopExecution(loopExecution, "handleLoopExecution");
                                                }
                                            }

                                            executor.withExecution(
                                                executor.getExecution()
                                                    .withTaskRun(taskRun.withState(State.Type.RUNNING)),
                                                "handleLoop"
                                            );
                                        }
                                    }
                                } else if (taskRun.getState().getCurrent() == State.Type.RESTARTED) {
                                    // On restart, find the last failing sub-execution and restart it instead of
                                    // re-initializing from scratch.
                                    Optional<Execution> failingSubExecution = executionService.findLastFailingLoopSubExecution(executor.getExecution(), taskRun);
                                    if (failingSubExecution.isPresent()) {
                                        Execution restarted = executionService.restart(failingSubExecution.get(), executor.getFlow(), null);
                                        executor.withLoopExecution(restarted, "restartLoopExecution");
                                        executor.withExecution(
                                            executor.getExecution()
                                                .withTaskRun(taskRun.withState(State.Type.RUNNING)),
                                            "handleLoop"
                                        );
                                    } else {
                                        // No restartable sub-execution found — fail the loop task to avoid stalling.
                                        RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);
                                        runContext.logger().error("No restartable loop sub-execution found for task run {} — marking loop as FAILED", taskRun.getId());
                                        executor.withExecution(
                                            executor.getExecution()
                                                .withTaskRun(taskRun.withState(State.Type.FAILED)),
                                            "handleLoop"
                                        );
                                        executor.getWorkerTasks().replaceAll(
                                            ewt -> ewt.workerTask().getTaskRun().getId().equals(taskRun.getId())
                                                ? new ExecutorContext.ExecutorWorkerTask(ewt.workerTask().withTaskRun(taskRun.withState(State.Type.FAILED)), ewt.runContext())
                                                : ewt
                                        );
                                    }
                                }
                            }
                        }
                        default -> {
                            // not all flowable tasks have custom Executor logic
                        }
                    }
                } catch (Exception e) {
                    RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);
                    runContext.logger().error("Failed to process flowable task {}: {}", taskRun.getId(), e.getMessage(), e);
                    executor.withExecution(
                        executor.getExecution()
                            .withTaskRun(taskRun.withState(State.Type.FAILED)),
                        "handleChildWorkerTaskResult"
                    );
                    // replace existing RESTARTED WorkerTask to FAILED to prevent it from transitioning to RUNNING
                    executor.getWorkerTasks().replaceAll(
                        ewt -> ewt.workerTask().getTaskRun().getId().equals(taskRun.getId())
                            ? new ExecutorContext.ExecutorWorkerTask(ewt.workerTask().withTaskRun(taskRun.withState(State.Type.FAILED)), ewt.runContext())
                            : ewt
                    );
                }
            }

            // If the task is retrying
            // make sure that the workerTaskResult of the parent task is not sent
            if (taskRun.getState().isRetrying() && taskRun.getParentTaskRunId() != null) {
                list = list.stream().filter(workerTaskResult -> !workerTaskResult.getTaskRun().getId().equals(taskRun.getParentTaskRunId()))
                    .collect(Collectors.toCollection(ArrayList::new));
            }

            // If the task is a flowable and is terminated, check that all children flowable tasks are terminated.
            // This may not be the case for parallel flowable tasks like Parallel, Dag, ...
            // After a failed task, some child flowable may not be correctly terminated.
            // Restricted to flowable children on purpose (fixes #6780's original intent): a leaf task
            // run that is still running is genuinely in progress on a worker and will report its own terminal state.
            if (task instanceof FlowableTask<?> && taskRun.getState().isTerminated()) {
                FlowWithSource flow = executor.getFlow();
                List<TaskRun> updated = executor.getExecution().findChildren(taskRun).stream()
                    .filter(child -> !child.getState().isTerminated())
                    .filter(child -> flow.findTaskByTaskIdOrNull(child.getTaskId()) instanceof FlowableTask<?>)
                    .map(throwFunction(child -> child.withState(taskRun.getState().getCurrent())))
                    .toList();
                if (!updated.isEmpty()) {
                    Execution execution = executor.getExecution();
                    for (TaskRun child : updated) {
                        execution = execution.withTaskRun(child);
                    }
                    executor = executor.withExecution(execution, "handledTerminatedFlowableTasks");
                }
            }
        }

        if (!nextTaskRuns.isEmpty()) {
            executor.withTaskRun(nextTaskRuns, "handleFlowableTasks");
        }

        metricRegistry
            .counter(
                MetricRegistry.METRIC_EXECUTOR_EXECUTION_DELAY_CREATED_COUNT, MetricRegistry.METRIC_EXECUTOR_EXECUTION_DELAY_CREATED_COUNT_DESCRIPTION,
                metricRegistry.tags(executor.getExecution())
            )
            .increment(executionDelays.size());

        executor.withWorkerTaskDelays(executionDelays, "handleChildWorkerTaskDelay");

        if (list.isEmpty()) {
            return executor;
        }

        if (!onPauses.isEmpty()) {
            List<TaskRun> taskRuns = onPauses.stream().map(executorTask -> executorTask.workerTask().getTaskRun()).toList();
            executor.withTaskRun(taskRuns, "handlePauses");
            executor.withWorkerTasks(onPauses, "handlePauses");
        }

        executor = this.handlePausedDelay(executor, list);

        this.addWorkerTaskResults(executor, list);

        return executor;
    }

    /**
     * Interrupts every still-running task run in the task subtree so they don't keep executing on an already-failed branch.
     * Send an {@link ExecutionKilledTaskRuns} event to the Worker to interrupt the non-terminated task runs.
     */
    private void interruptOnChildFailure(ExecutorContext executor, OnChildFailureInterface onChildFailure, TaskRun parentTaskRun, RunContext runContext) throws InternalException {
        OnChildFailureInterface.OnChildFailure config = runContext.render(onChildFailure.getOnChildFailure())
            .as(OnChildFailureInterface.OnChildFailure.class)
            .orElse(OnChildFailureInterface.OnChildFailure.CONTINUE);
        if (config == OnChildFailureInterface.OnChildFailure.CONTINUE || config == OnChildFailureInterface.OnChildFailure.UNKNOWN) {
            return;
        }

        List<TaskRun> nonTerminated = onChildFailure.nonTerminatedChildrenTaskRuns(executor.getExecution(), parentTaskRun);
        if (nonTerminated.isEmpty()) {
            return;
        }

        State.Type targetState = config.toTaskRunState();
        List<String> leafTaskRunIds = new ArrayList<>();
        List<WorkerTaskResult> resolvedFlowables = new ArrayList<>();

        for (TaskRun descendant : nonTerminated) {
            Task descendantTask = executor.getFlow().findTaskByTaskIdOrNull(descendant.getTaskId());
            if (descendantTask instanceof FlowableTask<?>) {
                // A flowable task has no worker job of its own to interrupt: resolve it directly to the configured state.
                // Its own descendants are covered independently in this same loop, since nonTerminatedChildrenTaskRuns() is already fully recursive.
                resolvedFlowables.add(new WorkerTaskResult(descendant.withStateAndAttempt(targetState)));
            } else {
                leafTaskRunIds.add(descendant.getId());
            }
        }

        if (!resolvedFlowables.isEmpty()) {
            this.addWorkerTaskResults(executor, resolvedFlowables);
        }

        if (!leafTaskRunIds.isEmpty()) {
            try {
                killQueue.emit(
                    ExecutionKilledTaskRuns.builder()
                        .tenantId(parentTaskRun.getTenantId())
                        .executionId(parentTaskRun.getExecutionId())
                        .taskRunIds(leafTaskRunIds)
                        .taskRunState(targetState)
                        .state(ExecutionKilled.State.EXECUTED)
                        .build()
                );
            } catch (QueueException e) {
                log.error("Unable to interrupt task runs {} after child failure", leafTaskRunIds, e);
            }
        }
    }

    private Task searchForParentTaskWithRetry(TaskRun taskRun, ExecutorContext executor) {
        // search in all parents, recursively
        if (taskRun.getParentTaskRunId() != null) {
            String taskId = taskRun.getTaskId();
            Task parentTask;
            do {
                parentTask = executor.getFlow().findParentTasksByTaskId(taskId);
                if (parentTask != null) {
                    taskId = parentTask.getId();
                }
            } while (parentTask != null && parentTask.getRetry() == null);

            return parentTask;
        }

        return null;
    }

    /**
     * Whether the errors/finally branch of the flowable task owning the retry still has non-terminal task runs
     * for the current failure. Used to prevent a retry timer from firing before those tasks terminate.
     * <p>
     * Known scope limitation: only gates the case where the failing task's <b>direct</b> parent is the flowable
     * owning the retry (mirroring the same direct-parent-only assumption already made by
     * {@link ExecutionService#retryTask}, which purges errors/finally task runs the same way). If the retry is
     * owned by a grandparent flowable further up the tree, this check does not apply.
     */
    private boolean isErrorOrFinallyHandlingPending(TaskRun taskRun, Task parentTaskWithRetry, ExecutorContext executor, List<TaskRun> nextTaskRuns) {
        if (!(parentTaskWithRetry instanceof FlowableTask<?> flowableTask) || taskRun.getParentTaskRunId() == null) {
            return false;
        }

        Optional<TaskRun> directParentTaskRun = ListUtils.emptyOnNull(executor.getExecution().getTaskRunList()).stream()
            .filter(t -> t.getId().equals(taskRun.getParentTaskRunId()))
            .findFirst();

        if (directParentTaskRun.isEmpty() || !directParentTaskRun.get().getTaskId().equals(parentTaskWithRetry.getId())) {
            return false;
        }

        Set<String> errorAndFinallyTaskIds = Stream.concat(
            ListUtils.emptyOnNull(flowableTask.getErrors()).stream(),
            ListUtils.emptyOnNull(flowableTask.getFinally()).stream()
        )
            .map(Task::getId)
            .collect(Collectors.toSet());

        if (errorAndFinallyTaskIds.isEmpty()) {
            return false;
        }

        String parentTaskRunId = directParentTaskRun.get().getId();

        // The errors/finally children may have just been resolved earlier in this same handleFlowableTasks pass, but not merged into the execution yet.
        // Check the pending list too, otherwise the very first failure would see no sibling task run at all and wrongly conclude "not pending".
        boolean justResolvedThisPass = nextTaskRuns.stream()
            .anyMatch(t -> parentTaskRunId.equals(t.getParentTaskRunId()) && errorAndFinallyTaskIds.contains(t.getTaskId()));
        if (justResolvedThisPass) {
            return true;
        }

        return executor.getExecution().getTaskRunList().stream()
            .filter(t -> parentTaskRunId.equals(t.getParentTaskRunId()))
            .filter(t -> errorAndFinallyTaskIds.contains(t.getTaskId()))
            .anyMatch(t -> !t.getState().isTerminated());
    }

    private ExecutorContext handlePausedDelay(ExecutorContext executor, List<WorkerTaskResult> workerTaskResults) throws InternalException, QueueException {
        if (
            workerTaskResults
                .stream()
                .noneMatch(workerTaskResult -> workerTaskResult.getTaskRun().getState().getCurrent() == State.Type.PAUSED)
        ) {
            return executor;
        }

        List<ExecutionDelay> list = workerTaskResults
            .stream()
            .filter(workerTaskResult -> workerTaskResult.getTaskRun().getState().getCurrent() == State.Type.PAUSED)
            .map(throwFunction(workerTaskResult ->
            {
                Task task = executor.getFlow().findTaskByTaskId(workerTaskResult.getTaskRun().getTaskId());

                if (task instanceof Pause pauseTask) {
                    if (pauseTask.getPauseDuration() != null || pauseTask.getTimeout() != null) {
                        RunContext runContext = runContextFactory.of(executor.getFlow(), executor.getExecution());
                        Duration duration = runContext.render(pauseTask.getPauseDuration()).as(Duration.class).orElse(null);
                        if (duration != null && (duration.isZero() || duration.isNegative())) {
                            throw new InternalException("The Pause 'pauseDuration' must be a strictly positive duration but was '%s'.".formatted(duration));
                        }
                        Duration timeout = runContext.render(pauseTask.getTimeout()).as(Duration.class).orElse(null);
                        Pause.Behavior behavior = runContext.render(pauseTask.getBehavior()).as(Pause.Behavior.class).orElse(Pause.Behavior.RESUME);
                        if (duration != null || timeout != null) { // rendering can lead to null, so we must re-check here
                            // if duration is set, we use it, and we use the Pause behavior as a state
                            // if no duration, we use the standard timeout property and use FAILED as the target state
                            return ExecutionDelay.builder()
                                .taskRunId(workerTaskResult.getTaskRun().getId())
                                .executionId(executor.getExecution().getId())
                                .date(DateUtils.plusOrThrow(workerTaskResult.getTaskRun().getState().maxDate(), duration != null ? duration : timeout))
                                .state(duration != null ? behavior.mapToState() : State.Type.fail(pauseTask))
                                .delayType(ExecutionDelay.DelayType.RESUME_FLOW)
                                .build();
                        }
                    }
                }

                return null;
            }))
            .filter(Objects::nonNull)
            .toList();

        if (executor.getExecution().getState().getCurrent() != State.Type.PAUSED) {
            workerTaskResults
                .stream()
                .filter(workerTaskResult -> workerTaskResult.getTaskRun().getState().getCurrent() == State.Type.PAUSED)
                .forEach(throwConsumer(workerTaskResult ->
                {
                    try {
                        Task task = executor.getFlow().findTaskByTaskId(workerTaskResult.getTaskRun().getTaskId());
                        pausedTaskNotifier.taskPaused(executor.getFlow(), executor.getExecution(), workerTaskResult.getTaskRun(), task);
                    } catch (Exception e) {
                        log.warn("Unable to notify paused task '{}' for execution '{}'", workerTaskResult.getTaskRun().getTaskId(), executor.getExecution().getId(), e);
                    }
                }));

            ExecutorContext updated = executor
                .withExecution(executor.getExecution().withState(State.Type.PAUSED), "handlePausedDelay")
                .withWorkerTaskDelays(list, "handlePausedDelay");

            // propagate the pause to the parent execution when running inside a Loop sub-execution
            if (executor.getExecution().getKind() == ExecutionKind.LOOP) {
                loopExecutionEventQueue.emit(
                    new LoopExecutionEvent(
                        executor.getExecution().getLoopRun(), executor.getExecution().getId(), State.Type.PAUSED, null
                    )
                );
            }

            return updated;
        }

        return executor.withWorkerTaskDelays(list, "handlePausedDelay");
    }

    private ExecutorContext handleCreatedKilling(ExecutorContext executor) throws InternalException {
        if (executor.getExecution().getTaskRunList() == null || executor.getExecution().getState().getCurrent() != State.Type.KILLING) {
            return executor;
        }

        List<WorkerTaskResult> workerTaskResults = executor.getExecution()
            .getTaskRunList()
            .stream()
            .filter(taskRun -> taskRun.getState().getCurrent().isCreated())
            .map(
                t -> childWorkerTaskTypeToWorkerTask(
                    Optional.of(State.Type.KILLED),
                    t
                )
            )
            .filter(Optional::isPresent)
            .map(Optional::get)
            .toList();

        this.addWorkerTaskResults(executor, workerTaskResults);
        return executor;
    }

    private ExecutorContext handleAfterExecution(ExecutorContext executor) {
        // LOOP sub-executions must not execute afterExecution tasks
        if (!executor.getExecution().getState().isTerminated() || executor.getExecution().getKind() == ExecutionKind.LOOP) {
            return executor;
        }

        // execute afterExecution tasks
        List<ResolvedTask> afterExecutionResolvedTasks = executionService.resolveAfterExecutionTasks(executor.getFlow());
        List<TaskRun> afterExecutionNexts = FlowableUtils.resolveSequentialNexts(executor.getExecution(), afterExecutionResolvedTasks)
            .stream()
            .map(throwFunction(NextTaskRun::getTaskRun))
            .map(taskRun -> taskRun.withForceExecution(true)) // forceExecution so it would be executed even if the execution is killed
            .toList();
        if (!afterExecutionNexts.isEmpty()) {
            return executor.withTaskRun(afterExecutionNexts, "handleAfterExecution ");
        }

        // if nothing more, just return the executor as is
        return executor;
    }

    private ExecutorContext handleEnd(ExecutorContext executor) throws InternalException {
        if (executor.getExecution().getState().isTerminated() || executor.getExecution().getState().isPaused() || executor.getExecution().getState().isRetrying()) {
            return executor;
        }

        List<ResolvedTask> currentTasks = null;
        if (executor.getExecution().getKind() != ExecutionKind.LOOP) {
            currentTasks = executor.getExecution().findTaskDependingFlowState(
                ResolvedTask.of(executor.getFlow().getTasks()),
                ResolvedTask.of(executor.getFlow().getErrors()),
                ResolvedTask.of(executor.getFlow().getFinally())
            );
        } else if (executor.getExecution().getLoopRun() != null) { // should always be true but better be safe
            Loop loop = (Loop) executor.getFlow().findTaskByTaskId(executor.getExecution().getLoopRun().taskId());
            currentTasks = executor.getExecution().findTaskDependingFlowState(
                ResolvedTask.of(loop.getTasks()),
                ResolvedTask.of(loop.getErrors()),
                ResolvedTask.of(loop.getFinally())
            );
        }

        if (currentTasks == null || !executor.getExecution().isTerminated(currentTasks)) {
            return executor;
        }

        return this.onEnd(executor);
    }

    private ExecutorContext handleRestart(ExecutorContext executor) {
        if (executor.getExecution().getState().getCurrent() != State.Type.RESTARTED) {
            return executor;
        }

        metricRegistry
            .counter(MetricRegistry.METRIC_EXECUTOR_EXECUTION_STARTED_COUNT, MetricRegistry.METRIC_EXECUTOR_EXECUTION_STARTED_COUNT_DESCRIPTION, metricRegistry.tags(executor.getExecution()))
            .increment();

        Logs.logExecution(
            executor.getExecution(),
            Level.INFO,
            "Flow restarted"
        );

        return executor.withExecution(executor.getExecution().withState(State.Type.RUNNING), "handleRestart");
    }

    private ExecutorContext handleKilling(ExecutorContext executor) {
        if (executor.getExecution().getState().getCurrent() != State.Type.KILLING) {
            return executor;
        }

        // Only transition to KILLED once all task runs are in a terminal state;
        // flowable parents may still be in KILLING while their children finish.
        if (
            executor.getExecution().getTaskRunList() != null &&
                !executor.getExecution().getTaskRunList().stream().allMatch(t -> t.getState().isTerminated())
        ) {
            return executor;
        }

        Execution newExecution = executor.getExecution().withState(State.Type.KILLED);

        return executor.withExecution(newExecution, "handleKilling");
    }

    private ExecutorContext handleWorkerTasks(final ExecutorContext executor) throws InternalException {
        if (executor.getExecution().getTaskRunList() == null || executor.getExecution().getState().getCurrent() == State.Type.KILLING) {
            return executor;
        }

        Optional<TextMapPropagator> textMapPropagator = openTelemetry
            .map(OpenTelemetry::getPropagators)
            .map(ContextPropagators::getTextMapPropagator);

        // submit TaskRun when receiving created, must be done after the state execution store
        Map<Boolean, List<ExecutorContext.ExecutorWorkerTask>> workerTasks = executor.getExecution()
            .getTaskRunList()
            .stream()
            .filter(taskRun -> taskRun.getState().getCurrent().isCreated() && executor.getExecution().getFixtureForTaskRun(taskRun).isEmpty())
            .map(throwFunction(taskRun ->
            {
                Task task = executor.getFlow().findTaskByTaskId(taskRun.getTaskId());
                RunContext runContext = runContextFactory.of(executor.getFlow(), task, executor.getExecution(), taskRun);

                // inject the traceparent into the run context
                textMapPropagator.ifPresent(propagator -> propagator.inject(Context.current(), runContext, RunContextTextMapSetter.INSTANCE));

                WorkerTask workerTask = WorkerTask.builder()
                    .data(WorkerTaskData.from(runContext))
                    .taskRun(taskRun)
                    .task(task)
                    .executionKind(executor.getExecution().getKind())
                    .build();
                // Resolve the target Worker Queue for this task
                Optional<WorkerQueueRouting> routing;
                try {
                    routing = workerQueueService.resolveWorkerQueueForJob(executor.getFlow(), workerTask);
                } catch (NoMatchingWorkerQueueException e) {
                    runContext.logger()
                        .error(e.getMessage(), workerTask.getTaskRun().getId(), e);
                    // fail the task-run because we cannot determine the target Worker Queue
                    return new ExecutorContext.ExecutorWorkerTask(workerTask.withTaskRun(workerTask.getTaskRun().fail()), runContext);
                }
                if (routing.isEmpty() || routing.get().isDefault()) {
                    return new ExecutorContext.ExecutorWorkerTask(workerTask, runContext);
                }
                WorkerQueueRouting r = routing.get();
                String workerQueueForLog = WorkerQueues.forLog(r.tags(), r.workerQueueId());
                return switch (r.disposition()) {
                    case DISPATCH -> new ExecutorContext.ExecutorWorkerTask(workerTask, runContext);
                    case WAIT_AND_DISPATCH -> {
                        runContext.logger()
                            .info("No workers are available for {}, waiting for one to be available.", workerQueueForLog);
                        yield new ExecutorContext.ExecutorWorkerTask(workerTask, runContext);
                    }
                    case FAIL -> {
                        runContext.logger()
                            .error("No workers are available for {}, failing the task.", workerQueueForLog);
                        yield new ExecutorContext.ExecutorWorkerTask(workerTask.withTaskRun(workerTask.getTaskRun().fail()), runContext);
                    }
                    case CANCEL -> {
                        runContext.logger()
                            .info("No workers are available for {}, canceling the task.", workerQueueForLog);
                        yield new ExecutorContext.ExecutorWorkerTask(workerTask.withTaskRun(workerTask.getTaskRun().withState(State.Type.CANCELLED)), runContext);
                    }
                };
            })
            )
            .collect(
                Collectors.groupingBy(
                    executorTask -> executorTask.workerTask().getTaskRun().getState().isFailed() || executorTask.workerTask().getTaskRun().getState().getCurrent() == State.Type.CANCELLED
                )
            );

        // mock WorkerTaskResult for mocked execution
        // submit TaskRun when receiving created, must be done after the state execution store
        boolean hasMockedWorkerTask = false;
        record FixtureAndTaskRun(TaskFixture fixture, TaskRun taskRun) {
        }
        if (executor.getExecution().getFixtures() != null) {
            RunContext runContext = runContextInitializer.forExecutor(
                (DefaultRunContext) runContextFactory.of(
                    executor.getFlow(),
                    executor.getExecution()
                )
            );
            List<WorkerTaskResult> workerTaskResults = executor.getExecution()
                .getTaskRunList()
                .stream()
                .filter(taskRun -> taskRun.getState().getCurrent().isCreated())
                .flatMap(taskRun -> executor.getExecution().getFixtureForTaskRun(taskRun).stream().map(fixture -> new FixtureAndTaskRun(fixture, taskRun)))
                .map(throwFunction(fixtureAndTaskRun ->
                {
                    AssetsDeclaration assetsDeclaration = executor.getFlow().findTaskByTaskId(fixtureAndTaskRun.taskRun.getTaskId()).getAssets();
                    return WorkerTaskResult.builder()
                        .taskRun(
                            fixtureAndTaskRun.taskRun()
                                .withState(Optional.ofNullable(fixtureAndTaskRun.fixture().getState()).orElse(State.Type.SUCCESS))
                                .withAssetEmits(
                                    List.of(
                                        new AssetsInOut(
                                            Optional.ofNullable(assetsDeclaration).map(AssetsDeclaration::getInputs)
                                                .map(throwFunction(assetInputs -> runContext.render(assetInputs).asList(AssetIdentifier.class)))
                                                .stream()
                                                .flatMap(Collection::stream)
                                                .map(throwFunction(assetIdentifier -> assetIdentifier.withTenantId(executor.getFlow().getTenantId())))
                                                .toList(),
                                            fixtureAndTaskRun.fixture().getAssets() == null ? null
                                                : fixtureAndTaskRun.fixture().getAssets().stream()
                                                    .map(asset -> asset.withTenantId(executor.getFlow().getTenantId()))
                                                    .toList()
                                        )
                                    )
                                )
                        )
                        .outputs(fixtureAndTaskRun.fixture().getOutputs() == null ? null : runContext.render(fixtureAndTaskRun.fixture().getOutputs()))
                        .build();
                }
                ))
                .toList();

            hasMockedWorkerTask = !workerTaskResults.isEmpty();
            this.addWorkerTaskResults(executor, workerTaskResults);
        }

        if (workerTasks.isEmpty() || hasMockedWorkerTask) {
            return executor;
        }

        ExecutorContext executorToReturn = executor;

        // suspend on breakpoint: if a breakpoint is for a CREATED taskrun, set the execution state to BREAKPOINT and ends here
        if (!ListUtils.isEmpty(executor.getExecution().getBreakpoints())) {
            List<Breakpoint> breakpoints = executor.getExecution().getBreakpoints();
            if (
                executor.getExecution()
                    .getTaskRunList()
                    .stream()
                    .anyMatch(taskRun -> shouldSuspend(taskRun, breakpoints))
            ) {
                List<TaskRun> newTaskRuns = executor.getExecution().getTaskRunList().stream().map(
                    taskRun ->
                    {
                        if (shouldSuspend(taskRun, breakpoints)) {
                            return taskRun.withState(State.Type.BREAKPOINT);
                        }
                        return taskRun;
                    }
                ).toList();
                Execution newExecution = executor.getExecution().withTaskRunList(newTaskRuns).withState(State.Type.BREAKPOINT);
                executorToReturn = executorToReturn.withExecution(newExecution, "handleBreakpoint");
                Logs.logExecution(
                    newExecution,
                    Level.INFO,
                    "Flow is suspended at a breakpoint."
                );
            }
        }

        // Ends FAILED or CANCELLED task runs by creating worker task results
        List<ExecutorContext.ExecutorWorkerTask> endedTasks = workerTasks.get(true);
        if (endedTasks != null && !endedTasks.isEmpty()) {
            List<WorkerTaskResult> failed = endedTasks
                .stream()
                .map(executorTask -> WorkerTaskResult.builder().taskRun(executorTask.workerTask().getTaskRun()).build())
                .toList();

            this.addWorkerTaskResults(executor, failed);
        }

        // Send other TaskRun to the worker (create worker tasks)
        List<ExecutorContext.ExecutorWorkerTask> processingTasks = workerTasks.get(false);
        if (processingTasks != null && !processingTasks.isEmpty() && !executor.getExecution().getState().isBreakpoint()) {
            executorToReturn = executorToReturn.withWorkerTasks(processingTasks, "handleWorkerTasks");

            metricRegistry
                .counter(MetricRegistry.METRIC_EXECUTOR_TASKRUN_CREATED_COUNT, MetricRegistry.METRIC_EXECUTOR_TASKRUN_CREATED_COUNT_DESCRIPTION, metricRegistry.tags(executor.getExecution()))
                .increment(processingTasks.size());
        }

        return executorToReturn;
    }

    private boolean shouldSuspend(TaskRun taskRun, List<Breakpoint> breakpoints) {
        return taskRun.getState().getCurrent().isCreated() && breakpoints.stream()
            .anyMatch(breakpoint -> taskRun.getTaskId().equals(breakpoint.getId()) && (breakpoint.getValue() == null || Objects.equals(taskRun.getValue(), breakpoint.getValue())));
    }

    private ExecutorContext handleExecutableTasks(final ExecutorContext executor) {
        List<SubflowExecution<?>> executions = new ArrayList<>();
        List<SubflowExecutionResult> subflowExecutionResults = new ArrayList<>();

        boolean haveFlows = executor.getWorkerTasks()
            .removeIf(executorTask ->
            {
                WorkerTask workerTask = executorTask.workerTask();
                if (!(workerTask.getTask() instanceof ExecutableTask)) {
                    return false;
                }

                var executableTask = (Task & ExecutableTask<?>) workerTask.getTask();
                try {
                    // mark taskrun as running to avoid multiple try for failed
                    TaskRun executableTaskRun = executor.getExecution()
                        .findTaskRunByTaskRunId(workerTask.getTaskRun().getId());
                    executor.withExecution(
                        executor
                            .getExecution()
                            .withTaskRun(executableTaskRun.withState(State.Type.RUNNING)),
                        "handleExecutableTaskRunning"
                    );

                    // handle runIf
                    if (!TruthUtils.isTruthy(executorTask.runContext().render(workerTask.getTask().getRunIf()))) {
                        executor.withExecution(
                            executor
                                .getExecution()
                                .withTaskRun(executableTaskRun.withState(State.Type.SKIPPED).addAttempt(TaskRunAttempt.builder().state(new State().withState(State.Type.SKIPPED)).build())),
                            "handleExecutableTaskSkipped"
                        );
                        return false;
                    }

                    RunContext runContext = executorTask.runContext();
                    List<SubflowExecution<?>> subflowExecutions = executableTask
                        .createSubflowExecutions(runContext, flowExecutorInterface, executor.getFlow(), executor.getExecution(), executableTaskRun);
                    if (subflowExecutions.isEmpty()) {
                        // if no executions we move the task to SUCCESS immediately
                        executor.withExecution(
                            executor
                                .getExecution()
                                .withTaskRun(executableTaskRun.withState(State.Type.SUCCESS)),
                            "handleExecutableTaskRunnings.noExecution"
                        );
                    } else {
                        executions.addAll(subflowExecutions);
                        Optional<FlowInterface> flow = flowExecutorInterface.findByExecution(subflowExecutions.getFirst().getExecution());
                        if (flow.isPresent()) {
                            // add SubflowExecutionResults to notify parents
                            for (SubflowExecution<?> subflowExecution : subflowExecutions) {
                                Optional<SubflowExecutionResult> subflowExecutionResult = executableTask.createSubflowExecutionResult(
                                    runContext,
                                    // if we didn't wait for the execution, we directly set the state to SUCCESS
                                    executableTask.waitForExecution() ? subflowExecution.getParentTaskRun() : subflowExecution.getParentTaskRun().withState(State.Type.SUCCESS),
                                    flow.get(),
                                    subflowExecution.getExecution(),
                                    subflowExecution.getOutputs()
                                );
                                subflowExecutionResult.ifPresent(subflowExecutionResults::add);
                            }
                        } else {
                            log.error("Unable to find flow for execution {}", subflowExecutions.getFirst().getExecution().getId());
                        }
                    }
                } catch (Exception e) {
                    try {
                        executor
                            .withExecution(executor.getExecution().withTaskRun(workerTask.getTaskRun().fail()), "handleExecutableTasks")
                            .withException(e, "handleExecutableTasks");
                    } catch (InternalException ex) {
                        log.error("Unable to fail the executable task.", ex);
                    }
                }
                return true;
            });

        if (!haveFlows) {
            return executor;
        }

        ExecutorContext resultExecutor = executor.withSubflowExecutions(executions, "handleExecutableTasks");

        if (!subflowExecutionResults.isEmpty()) {
            resultExecutor = executor.withSubflowExecutionResults(subflowExecutionResults, "handleExecutableTaskWorkerTaskResults");
        }

        return resultExecutor;
    }

    private ExecutorContext handleExecutionUpdatingTasks(final ExecutorContext executor) throws InternalException {
        List<WorkerTaskResult> workerTaskResults = new ArrayList<>();

        executor.getWorkerTasks()
            .removeIf(executorTask ->
            {
                WorkerTask workerTask = executorTask.workerTask();
                if (!(workerTask.getTask() instanceof ExecutionUpdatableTask executionUpdatingTask)) {
                    return false;
                }

                try {
                    // Skip task if runIf condition is false
                    if (!TruthUtils.isTruthy(executorTask.runContext().render(workerTask.getTask().getRunIf()))) {
                        executor.withExecution(
                            executor
                                .getExecution()
                                .withTaskRun(
                                    workerTask.getTaskRun().withState(State.Type.SKIPPED).addAttempt(TaskRunAttempt.builder().state(new State().withState(State.Type.SKIPPED)).build())
                                ),
                            "handleExecutionUpdatingTaskSkipped"
                        );
                        return false;
                    }

                    TaskRun runningTaskRun = workerTask
                        .getTaskRun()
                        .withAttempts(List.of(TaskRunAttempt.builder().state(new State().withState(State.Type.RUNNING)).build()))
                        .withState(State.Type.RUNNING);

                    var newExecution = executionUpdatingTask.update(executor.getExecution(), executorTask.runContext());
                    if (newExecution.getState().getCurrent() == State.Type.KILLED) {
                        killQueue.emit(
                            ExecutionKilledExecution.builder()
                                .state(ExecutionKilled.State.REQUESTED)
                                .executionId(newExecution.getId())
                                .isOnKillCascade(true)
                                .tenantId(newExecution.getTenantId())
                                .build()
                        );
                    }
                    executor.withExecution(
                        newExecution.withTaskRun(runningTaskRun),
                        "handleExecutionUpdatingTasks.updateExecution"
                    );

                    var terminalState = executionUpdatingTask
                        .resolveState(executorTask.runContext(), executor.getExecution())
                        .orElse(State.Type.SUCCESS);

                    TaskRunAttempt terminalAttempt = runningTaskRun.lastAttempt().withState(terminalState);

                    workerTaskResults.add(
                        WorkerTaskResult.builder()
                            .taskRun(
                                runningTaskRun
                                    .withAttempts(List.of(terminalAttempt))
                                    .withState(terminalState)
                            )
                            .build()
                    );
                } catch (Exception e) {
                    Task task = workerTask.getTask();
                    // Log against the task run so the failure carries its taskId/taskRunId, not only the execution.
                    executorTask.runContext().logger().error("Failed to process task: {}", e.getMessage(), e);

                    // State.Type.fail resolves the failure against allowFailure/allowWarning: FAILED, WARNING or SUCCESS.
                    State.Type failState = State.Type.fail(task);
                    // Fail the execution only when the task itself ends FAILED; WARNING/SUCCESS let it continue.
                    if (failState == State.Type.FAILED) {
                        executor.withException(e, "handleExecutionUpdatingTasks");
                    }

                    TaskRunAttempt failedAttempt = TaskRunAttempt.builder().state(new State(failState)).build();
                    workerTaskResults.add(
                        WorkerTaskResult.builder()
                            .taskRun(workerTask.getTaskRun().withAttempts(List.of(failedAttempt)).withState(failState))
                            .build()
                    );
                }
                return true;
            });

        this.addWorkerTaskResults(executor, workerTaskResults);

        return executor;
    }

    public void addWorkerTaskResults(ExecutorContext executor, List<WorkerTaskResult> workerTaskResults) throws InternalException {
        for (WorkerTaskResult workerTaskResult : workerTaskResults) {
            this.addWorkerTaskResult(executor, () -> executor.getFlow(), workerTaskResult);
        }
    }

    public void addWorkerTaskResult(ExecutorContext executor, Supplier<FlowWithSource> flow, WorkerTaskResult workerTaskResult) throws InternalException {
        // add dynamic taskruns + taskruns created by the WorkingDirectory
        this.addAdditionalTaskRun(
            executor,
            flow,
            workerTaskResult
        );

        TaskRun taskRun = workerTaskResult.getTaskRun();
        Execution newExecution = executor.getExecution().withTaskRun(taskRun);
        // If the worker task result is killed, we must check if it has a parents to also kill them if not already done.
        // Running flowable tasks that have child tasks running in the worker will be killed thanks to that.
        if (taskRun.getState().getCurrent() == State.Type.KILLED && taskRun.getParentTaskRunId() != null) {
            newExecution = executionService.killParentTaskruns(taskRun, newExecution);
        }
        executor.withExecution(newExecution, "addWorkerTaskResult");

        if (taskRun.getState().isTerminated()) {
            log.trace("TaskRun terminated: {}", taskRun);

            // may be escalated below by assetFailureBehavior; kept separate from `taskRun` for the metrics in the finally block
            TaskRun finalTaskRun = taskRun;
            try {
                // outputs
                taskOutputService.saveOutputs(taskRun, workerTaskResult.getOutputs());

                ExecutionKind executionKind = Optional.ofNullable(executor.getExecution().getKind()).orElse(ExecutionKind.NORMAL);
                boolean hasAssets = taskRun.getAssetEmits() != null && taskRun.getAssetEmits().stream()
                    .anyMatch(bundle -> !bundle.getInputs().isEmpty() || !bundle.getOutputs().isEmpty());
                if (
                    hasAssets
                        && executionKind != ExecutionKind.TEST
                ) {
                    AssetUser assetUser = new AssetUser(
                        taskRun.getTenantId(),
                        taskRun.getNamespace(),
                        taskRun.getFlowId(),
                        newExecution.getFlowRevision(),
                        taskRun.getExecutionId(),
                        taskRun.getTaskId(),
                        taskRun.getId(),
                        taskRun.getState().getCurrent(),
                        taskRun.getState().getStartDate(),
                        taskRun.getState().getEndDate().orElse(null)
                    );

                    try {
                        Optional<TaskRun> escalated = assetService.processTaskRunAssets(assetUser, taskRun, newExecution, flow, executionKind);
                        if (escalated.isPresent()) {
                            finalTaskRun = escalated.get();
                            executor.withExecution(executor.getExecution().withTaskRun(finalTaskRun), "addWorkerTaskResult");
                        }
                    } catch (Exception e) {
                        // a bug in asset-lineage/escalation processing must not prevent the taskRun's own
                        // (already-terminated) result from being recorded; metrics below still tag from taskRun
                        log.error("Unable to process assets for taskRun {}", taskRun.getId(), e);
                    }
                }
            } finally {
                // tagged from finalTaskRun so a state escalated above by assetFailureBehavior is reflected in the metrics too
                WorkerTaskResult finalWorkerTaskResult = workerTaskResult.withTaskRun(finalTaskRun);
                metricRegistry
                    .counter(
                        MetricRegistry.METRIC_EXECUTOR_TASKRUN_ENDED_COUNT,
                        MetricRegistry.METRIC_EXECUTOR_TASKRUN_ENDED_COUNT_DESCRIPTION,
                        metricRegistry.tags(finalWorkerTaskResult)
                    )
                    .increment();

                // duration from the original taskRun: withState() above would otherwise inflate it by the escalation delay
                metricRegistry
                    .timer(
                        MetricRegistry.METRIC_EXECUTOR_TASKRUN_ENDED_DURATION,
                        MetricRegistry.METRIC_EXECUTOR_TASKRUN_ENDED_DURATION_DESCRIPTION,
                        metricRegistry.tags(finalWorkerTaskResult)
                    )
                    .record(taskRun.getState().getDurationOrComputeIt());
            }
        }
    }

    // Note: as the flow is only used in an error branch, and it can take time to load, we pass it thought a Supplier
    private void addAdditionalTaskRun(ExecutorContext executor, Supplier<FlowWithSource> flow, WorkerTaskResult workerTaskResult) throws InternalException {
        Execution execution = executor.getExecution();
        List<TaskRun> taskRuns = new ArrayList<>(ListUtils.emptyOnNull(execution.getTaskRunList()));

        // if there is a parent but the taskrun didn't exist: the parent should be the WorkingDirectory
        // as inside a WorkingDirectory, a taskrun is directly created inside the Worker and not inside the Executor
        if (workerTaskResult.getTaskRun().getParentTaskRunId() != null && taskRuns.stream().noneMatch(t -> t.getId().equals(workerTaskResult.getTaskRun().getId()))) {
            TaskRun parentTaskRun = execution.findTaskRunByTaskRunId(workerTaskResult.getTaskRun().getParentTaskRunId());
            Task parentTask = flow.get().findTaskByTaskId(parentTaskRun.getTaskId());
            if (parentTask instanceof WorkingDirectory) {
                taskRuns.add(workerTaskResult.getTaskRun());
            }
        }

        // declared dynamic tasks
        if (!ListUtils.isEmpty(workerTaskResult.getDynamicTaskRuns())) {
            taskRuns.addAll(workerTaskResult.getDynamicTaskRuns());
        }

        if (taskRuns.size() > ListUtils.emptyOnNull(execution.getTaskRunList()).size()) {
            executor.withExecution(execution.withTaskRunList(taskRuns), "addAdditionalTaskRun");
        }
    }

    public void log(Logger log, boolean in, WorkerJob value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            if (value instanceof WorkerTask workerTask) {
                log.debug(
                    "{} {} : {}",
                    in ? "<< IN " : ">> OUT",
                    workerTask.getClass().getSimpleName(),
                    workerTask.getTaskRun().toStringState()
                );
            } else if (value instanceof WorkerTrigger workerTrigger) {
                log.debug(
                    "{} {} : {}",
                    in ? "<< IN " : ">> OUT",
                    workerTrigger.getClass().getSimpleName(),
                    workerTrigger.uid()
                );
            }
        }
    }

    public void log(Logger log, boolean in, WorkerTaskResult value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            log.debug(
                "{} {} : {}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.getTaskRun().toStringState()
            );
        }
    }

    public void log(Logger log, boolean in, SubflowExecutionResult value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            log.debug(
                "{} {} : {}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.getParentTaskRun().toStringState()
            );
        }
    }

    public void log(Logger log, boolean in, SubflowExecutionEnd value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            log.debug(
                "{} {} : {}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.toStringState()
            );
        }
    }

    public void log(Logger log, boolean in, Execution value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            log.debug(
                "{} {} [key='{}']\n{}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.getId(),
                value.toStringState()
            );
        }
    }

    public void log(Logger log, boolean in, ExecutorContext value) {
        if (log.isDebugEnabled()) { // taskRun().toStringState() is costly so we avoid calling it if not needed
            log.debug(
                "{} {} [key='{}', from='{}', crc32='{}']\n{}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.getExecution().getId(),
                value.getFrom(),
                value.getExecution().toCrc32State(),
                value.getExecution().toStringState()
            );
        }
    }

    public void log(Logger log, boolean in, LoopExecutionEvent value) {
        if (log.isDebugEnabled()) {
            log.debug(
                "{} {} : {}",
                in ? "<< IN " : ">> OUT",
                value.getClass().getSimpleName(),
                value.toStringState()
            );
        }
    }

    public void log(Logger log, Boolean in, ExecutionKilledExecution value) {
        log.debug(
            "{} {} [key='{}']\n{}",
            in ? "<< IN " : ">> OUT",
            value.getClass().getSimpleName(),
            value.getExecutionId(),
            value
        );
    }

    /**
     * Handle flow ExecutionChangedSLA on an executor.
     * If there are SLA violations, it will take care of updating the execution based on the SLA behavior.
     * NOTE: Loop executions are skipped.
     *
     * @see #processViolation(RunContext, ExecutorContext, Violation)
     *      <p>
     *      WARNING: ATM, only the first violation will update the execution.
     */
    public ExecutorContext handleExecutionChangedSLA(ExecutorContext executor) throws QueueException {
        if (executor.getFlow() == null || ListUtils.isEmpty(executor.getFlow().getSla()) || executor.getExecution().getState().isTerminated() ||
            executor.getExecution().getKind() ==  ExecutionKind.LOOP) {
            return executor;
        }

        RunContext runContext = runContextFactory.of(executor.getFlow(), executor.getExecution());
        List<Violation> violations = slaService.evaluateExecutionChangedSLA(runContext, executor.getFlow(), executor.getExecution());
        if (!violations.isEmpty()) {
            metricRegistry
                .counter(MetricRegistry.METRIC_EXECUTOR_SLA_VIOLATION_COUNT, MetricRegistry.METRIC_EXECUTOR_SLA_VIOLATION_COUNT_DESCRIPTION, metricRegistry.tags(executor.getExecution()))
                .increment(violations.size());

            // For now, we only consider the first violation to be capable of updating the execution.
            // Other violations would only be logged.
            Violation violation = violations.getFirst();
            return processViolation(runContext, executor, violation);
        }

        return executor;
    }

    /**
     * Process an SLA violation on an executor:
     * - If behavior is FAIL or CANCEL: kill the execution, then return it with the new state.
     * - If behavior is NONE: do nothing and return an unmodified executor.
     * <p>
     * Then, if there are labels, they are added to the SLA (modifying the executor)
     */
    public ExecutorContext processViolation(RunContext runContext, ExecutorContext executor, Violation violation) throws QueueException {
        boolean hasChanged = false;
        Execution newExecution = switch (violation.behavior()) {
            case FAIL -> {
                runContext.logger().error("Execution failed due to SLA '{}' violated: {}", violation.slaId(), violation.reason());
                hasChanged = true;
                yield markAs(executor.getExecution(), State.Type.FAILED);
            }
            case CANCEL -> {
                hasChanged = true;
                yield markAs(executor.getExecution(), State.Type.CANCELLED);
            }
            case NONE -> executor.getExecution();
        };

        if (!ListUtils.isEmpty(violation.labels()) && !LabelService.containsAll(executor.getExecution().getLabels(), violation.labels())) {
            List<Label> labels = new ArrayList<>(newExecution.getLabels());
            labels.addAll(violation.labels());
            hasChanged = true;
            newExecution = newExecution.withLabels(labels);
        }

        if (hasChanged) {
            return executor.withExecution(newExecution, "SLAViolation");
        }
        return executor;
    }

    private Execution markAs(Execution execution, State.Type state) throws QueueException {
        Execution newExecution = execution.findLastNotTerminated()
            .map(taskRun ->
            {
                try {
                    return execution.withTaskRun(taskRun.withStateAndAttempt(state));
                } catch (InternalException e) {
                    // in case we cannot update the last not terminated task run, we ignore it
                    return execution;
                }
            })
            .orElse(execution)
            .withState(state);

        killQueue.emit(
            ExecutionKilledExecution
                .builder()
                .state(ExecutionKilled.State.REQUESTED)
                .executionState(state)
                .executionId(execution.getId())
                .isOnKillCascade(true)
                .tenantId(execution.getTenantId())
                .build()
        );

        return newExecution;
    }
}
