import os 

from agent_framework.openai import OpenAIChatCompletionClient  
from dotenv import load_dotenv # 📁 Secure configuration loading

load_dotenv()  # 📁 Load environment variables from .env file


openai_chat_client = OpenAIChatCompletionClient(
    base_url=os.environ.get("GITHUB_ENDPOINT"),    # 🌐 GitHub Models API endpoint
    api_key=os.environ.get("GITHUB_TOKEN"),        # 🔑 Authentication token
    model=os.environ.get("GITHUB_MODEL_ID")        # 🎯 Selected AI model
)

FRONTDESK_NAME = "FrontDesk"
FRONTDESK_INSTRUCTIONS = """
    You are a Front Desk Travel Agent with ten years of experience and are known for brevity as you deal with many customers.
    The goal is to provide the best activities and locations for a traveler to visit.
    Only provide a single recommendation per response.
    You're laser focused on the goal at hand.
    Don't waste time with chit chat.
    Consider suggestions when refining an idea.
    """



front_desk_agent = openai_chat_client.as_agent(
    instructions=FRONTDESK_INSTRUCTIONS,
    name=FRONTDESK_NAME,
)