// @vitest-environment happy-dom
/**
 * A mid-line composition must not visually swallow the character after the cursor.
 *
 * The preedit overlay (`.composition-view`) is an opaque box anchored to the cursor cell. Nothing
 * reaches the PTY while composing, so the covered cells still hold their characters — the box just
 * hides them for the whole composition (#12545). Composing `가` with the cursor before `하` in
 * `안녕하세요` blanks `하` until the syllable commits.
 *
 * The fix renders the rest of the row's committed text after the preedit inside the overlay, so the
 * composition reads as inserted text pushing the tail right. The overlay is also themed from
 * `options.theme` instead of the stock `#000`/`#FFF`, with any alpha dropped — a see-through mask
 * would re-expose the very cells the rendered tail stands in for.
 *
 * happy-dom performs no layout, so the cell size is supplied and geometry is not asserted; the
 * on-screen geometry arm lives in `tests/e2e/terminal-korean-midline-preedit-occlusion.spec.ts`.
 */
import { Terminal } from '@xterm/xterm'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const CELL_WIDTH_PX = 8
const CELL_HEIGHT_PX = 16
const THEME = { background: '#112233', foreground: '#aabbcc' }

const openTerminals: Terminal[] = []

function nextEventLoop(): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, 0))
}

type Rig = {
  compositionView: HTMLElement
  compose: (preedit: string) => void
  composeStart: () => void
  composeUpdate: (preedit: string) => void
  terminal: Terminal
  write: (data: string) => Promise<void>
  writeAwaitingRender: (data: string) => Promise<void>
}

function openTerminal(theme: { background: string; foreground: string } = THEME): Rig {
  const container = document.createElement('div')
  document.body.appendChild(container)
  const terminal = new Terminal({ cols: 80, rows: 24, theme })
  terminal.open(container)
  const textarea = terminal.textarea
  const compositionView = container.querySelector<HTMLElement>('.composition-view')
  if (!textarea || !compositionView) {
    throw new Error('xterm did not create the helper textarea and composition view')
  }
  openTerminals.push(terminal)

  const cell = (
    terminal as unknown as {
      _core: {
        _renderService: { dimensions: { css: { cell: { height: number; width: number } } } }
      }
    }
  )._core._renderService.dimensions.css.cell
  cell.width = CELL_WIDTH_PX
  cell.height = CELL_HEIGHT_PX

  const write = (data: string): Promise<void> =>
    new Promise((resolve) => terminal.write(data, resolve))

  // Awaits the repaint the write triggers, so the tail refresh runs through the production
  // terminal.onRender path rather than a test shortcut. The listener arms only after the write's
  // parse callback, because a repaint scheduled by an earlier write can fire first and still show
  // the old row.
  const writeAwaitingRender = async (data: string): Promise<void> => {
    await write(data)
    await new Promise<void>((resolve) => {
      const rendered = terminal.onRender(() => {
        rendered.dispose()
        resolve()
      })
    })
  }

  const composeStart = (): void => {
    const start = new CompositionEvent('compositionstart', { bubbles: true })
    Object.defineProperty(start, 'data', { value: '' })
    textarea.dispatchEvent(start)
  }

  const composeUpdate = (preedit: string): void => {
    const update = new CompositionEvent('compositionupdate', { bubbles: true })
    Object.defineProperty(update, 'data', { value: preedit })
    textarea.value = preedit
    textarea.dispatchEvent(update)
  }

  const compose = (preedit: string): void => {
    composeStart()
    composeUpdate(preedit)
  }

  return {
    compositionView,
    compose,
    composeStart,
    composeUpdate,
    terminal,
    write,
    writeAwaitingRender
  }
}

function stripMarks(text: string | null): string {
  return (text ?? '').replaceAll('‎', '')
}

describe('mid-line composition renders the covered row tail after the preedit', () => {
  beforeEach(() => {
    // happy-dom has no 2d context, which the DOM renderer's WidthCache requires.
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockReturnValue({
      measureText: () => ({ width: 10 })
    } as unknown as CanvasRenderingContext2D)
  })

  afterEach(async () => {
    // updateCompositionElements re-arms on a timer; let the pending one run before dispose.
    await nextEventLoop()
    await nextEventLoop()
    while (openTerminals.length > 0) {
      openTerminals.pop()?.dispose()
    }
    vi.restoreAllMocks()
    document.body.replaceChildren()
  })

  it('shows the tail from the cursor when composing before committed text (#12545 repro)', async () => {
    const rig = openTerminal()
    // 안녕하세요 then CUB 6: each Hangul syllable is two cells, so the cursor lands on 하 (x=4).
    await rig.write('안녕하세요\x1b[6D')

    rig.compose('가')

    const spans = Array.from(rig.compositionView.children) as HTMLElement[]
    expect(spans).toHaveLength(2)
    expect(stripMarks(spans[0]!.textContent)).toBe('가')
    expect(spans[0]!.style.textDecoration).toBe('underline')
    expect(spans[1]!.textContent).toBe('하세요')
    // Start-anchored so the preedit stays put and the pushed tail clips at the right edge.
    expect(rig.compositionView.style.direction).toBe('ltr')
  })

  it('keeps the tail current as the preedit grows through the composition', async () => {
    const rig = openTerminal()
    await rig.write('안녕하세요\x1b[6D')

    // One composition stays active while the preedit grows through updates,
    // matching how an IME actually streams ㄱ → 가 → 강.
    rig.composeStart()
    rig.composeUpdate('ㄱ')
    rig.composeUpdate('가')
    rig.composeUpdate('강')

    const spans = Array.from(rig.compositionView.children) as HTMLElement[]
    expect(spans).toHaveLength(2)
    expect(stripMarks(spans[0]!.textContent)).toBe('강')
    expect(spans[1]!.textContent).toBe('하세요')
  })

  // The view is `white-space: nowrap`, which collapses runs of spaces exactly like `normal`.
  // Without `pre` on the tail, an agent TUI's padded input row — `> text …spaces… |` — renders its
  // right border a cell after the preedit while the real border stays put. xterm sets `pre` on its
  // grid rows for the same reason.
  it('preserves the tail spacing of a padded row so its trailing glyph stays on the grid', async () => {
    const rig = openTerminal()
    // A TUI input row: text, padding, then a real border glyph the trim cannot drop.
    await rig.write('> hi          |\x1b[13D')

    rig.compose('가')

    const spans = Array.from(rig.compositionView.children) as HTMLElement[]
    expect(spans).toHaveLength(2)
    expect(spans[1]!.textContent, 'the tail must keep every padding cell').toBe('hi          |')
    expect(
      spans[1]!.style.whiteSpace,
      'nowrap collapses the padding, so the border lands left of its grid column'
    ).toBe('pre')
  })

  it('keeps the plain single-text overlay when composing at the end of the row', async () => {
    const rig = openTerminal()
    await rig.write('안녕하세요')

    rig.compose('가')

    expect(rig.compositionView.children).toHaveLength(0)
    expect(stripMarks(rig.compositionView.textContent)).toBe('가')
    // The rtl trick still keeps a long preedit's end in view when nothing follows the cursor.
    expect(rig.compositionView.style.direction).toBe('rtl')
  })

  it('themes the overlay from options.theme instead of the stock #000/#FFF', async () => {
    const rig = openTerminal()
    await rig.write('안녕하세요\x1b[6D')

    rig.compose('가')

    const { background, color } = rig.compositionView.style
    expect([THEME.background, 'rgb(17, 34, 51)']).toContain(background)
    expect([THEME.foreground, 'rgb(170, 187, 204)']).toContain(color)
  })

  it('drops the alpha of a translucent theme background so the mask stays opaque', async () => {
    // terminalBackgroundOpacity composes theme.background down to rgba(); carried through as-is it
    // would let the covered cells show straight through the tail this renders.
    const rig = openTerminal({ background: 'rgba(17, 34, 51, 0.6)', foreground: '#aabbcc' })
    await rig.write('안녕하세요\x1b[6D')

    rig.compose('가')

    expect(rig.compositionView.style.background).toBe('rgb(17, 34, 51)')
  })

  it('refreshes the tail when the row repaints under an open composition', async () => {
    const rig = openTerminal()
    await rig.write('안녕하세요\x1b[6D')
    rig.compose('가')

    // A TUI repaint: erase from the cursor, draw a different tail, put the cursor back.
    await rig.writeAwaitingRender('\x1b[K체크\x1b[4D')

    const spans = Array.from(rig.compositionView.children) as HTMLElement[]
    expect(spans).toHaveLength(2)
    expect(stripMarks(spans[0]!.textContent)).toBe('가')
    expect(spans[1]!.textContent).toBe('체크')
  })

  it('starts rendering a tail when text lands after an end-of-row composition began', async () => {
    const rig = openTerminal()
    await rig.write('안녕')
    rig.compose('가')
    expect(rig.compositionView.children).toHaveLength(0)

    // Streamed output arrives to the right of the cursor while the composition is open.
    await rig.writeAwaitingRender('하세요\x1b[6D')

    const spans = Array.from(rig.compositionView.children) as HTMLElement[]
    expect(spans).toHaveLength(2)
    expect(stripMarks(spans[0]!.textContent)).toBe('가')
    expect(spans[1]!.textContent).toBe('하세요')
  })

  it('leaves no tail behind for the next composition after one ends', async () => {
    const rig = openTerminal()
    await rig.write('안녕하세요\x1b[6D')
    rig.compose('가')

    const end = new CompositionEvent('compositionend', { bubbles: true })
    Object.defineProperty(end, 'data', { value: '가' })
    rig.terminal.textarea!.dispatchEvent(end)
    await nextEventLoop()
    await nextEventLoop()

    expect(rig.compositionView.classList.contains('active')).toBe(false)
    expect(rig.compositionView.children).toHaveLength(0)
    expect(rig.compositionView.textContent).toBe('')
  })
})
