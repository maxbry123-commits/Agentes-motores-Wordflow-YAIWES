import type { AgentType } from '../../../../shared/agent-status-types'
import { TUI_AGENT_CONFIG } from '../../../../shared/tui-agent-config'
import { resolveCommittedTitleAgentType } from '../../lib/pane-agent-evidence'
import type { PaneForegroundAgentEntry } from '@/store/slices/pane-foreground-agent'

export type WindowsShiftEnterEncoding = 'alt-enter' | 'csi-u'

type WindowsShiftEnterAgentSignals = {
  foreground?: PaneForegroundAgentEntry
  launchAgentType?: AgentType
}

type WindowsShiftEnterPaneState = {
  paneForegroundAgentByPaneKey: Record<string, PaneForegroundAgentEntry | undefined>
  agentLaunchConfigByPaneKey: Record<string, { identity: { agentType?: AgentType } } | undefined>
}

/** Resolve without key-path PTY I/O; current process/shell evidence overrides
 * launch ownership. Hook status is excluded because PTY output can forge it. */
export function resolveWindowsShiftEnterEncoding(
  signals: WindowsShiftEnterAgentSignals
): WindowsShiftEnterEncoding {
  if (signals.foreground?.shellForeground) {
    return 'alt-enter'
  }
  // Why: a pending confirmation retains the last allowlisted byte capability;
  // CSI-u is inert in a shell, while Esc+CR can submit in Pi.
  const agent =
    signals.foreground?.routingTrusted === true ||
    signals.foreground?.routingConfirmationPending === true
      ? signals.foreground.agent
      : null
  return agent ? (TUI_AGENT_CONFIG[agent].windowsShiftEnterEncoding ?? 'alt-enter') : 'alt-enter'
}

/** Resolves only pane-keyed evidence so a split sibling cannot inherit tab ownership. */
export function resolveWindowsShiftEnterEncodingForPane(
  state: WindowsShiftEnterPaneState,
  paneKey: string,
  terminalTitle?: string
): WindowsShiftEnterEncoding {
  const foreground = state.paneForegroundAgentByPaneKey[paneKey]
  const encoding = resolveWindowsShiftEnterEncoding({
    foreground: state.paneForegroundAgentByPaneKey[paneKey],
    launchAgentType: state.agentLaunchConfigByPaneKey[paneKey]?.identity.agentType
  })
  if (
    encoding === 'csi-u' ||
    !terminalTitle ||
    foreground?.routingTrusted === true ||
    foreground?.routingRevoked === true ||
    foreground?.shellForeground === true
  ) {
    return encoding
  }
  // Why: strict pane-local titles recover Pi/Droid through process-scan gaps without overriding process or shell proof.
  const titleAgent = resolveCommittedTitleAgentType(terminalTitle)
  return titleAgent
    ? (TUI_AGENT_CONFIG[titleAgent].windowsShiftEnterEncoding ?? 'alt-enter')
    : 'alt-enter'
}
