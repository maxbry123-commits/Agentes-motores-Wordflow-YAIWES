# Rationale: `kani_malformed_variant_1`

- Partition: `train`
- Category: `lane`
- Expected decision signal: `require_human_review`

## Why this expectation

Lane fixture status and merge recommendation must match the declared expectations, including counterexample class when present.

## Non-claims

This case does not claim complete application security or solver completeness.
