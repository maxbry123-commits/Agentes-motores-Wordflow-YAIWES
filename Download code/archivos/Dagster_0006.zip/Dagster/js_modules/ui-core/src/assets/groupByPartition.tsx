import groupBy from 'lodash/groupBy';
import {useMemo} from 'react';

import {
  AssetFailedToMaterializeFragment,
  AssetObservationFragment,
  AssetSuccessfulMaterializationFragment,
} from './types/useRecentAssetEvents.types';

const NO_PARTITION_KEY = '__NO_PARTITION__';

type Event =
  | AssetSuccessfulMaterializationFragment
  | AssetFailedToMaterializeFragment
  | AssetObservationFragment;

export type AssetEventGroup = {
  latest: Event | null;
  all: Event[];
  timestamp?: string;
  partition?: string;
};

const sortByEventTimestamp = (a: Event, b: Event) => Number(b?.timestamp) - Number(a?.timestamp);

const groupByPartition = (events: Event[], definedPartitionKeys: string[]): AssetEventGroup[] => {
  const grouped = groupBy(events, (m) => m.partition || NO_PARTITION_KEY);
  const orderedPartitionKeys = [...definedPartitionKeys].reverse();

  if (NO_PARTITION_KEY in grouped) {
    orderedPartitionKeys.push(NO_PARTITION_KEY);
  }

  return orderedPartitionKeys
    .filter((key) => key !== NO_PARTITION_KEY)
    .map((key) => {
      const sorted = [...(grouped[key] || [])].sort(sortByEventTimestamp);
      const latestMaterialization = sorted.find((a) => a.__typename === 'MaterializationEvent');
      const latest = latestMaterialization || sorted[0] || null;

      return {
        all: sorted,
        latest,
        timestamp: latest?.timestamp,
        partition: key,
      };
    });
};

/**
 * A hook that can bucket a list of materializations by partition, if any, with the `latest`
 * materialization separated from predecessor materializations.
 */
export function useGroupedEvents(
  xAxis: 'partition' | 'time',
  events: Event[],
  loadedPartitionKeys: string[] | undefined,
) {
  return useMemo<AssetEventGroup[]>(() => {
    if (xAxis === 'partition' && loadedPartitionKeys) {
      return groupByPartition(events, loadedPartitionKeys);
    } else {
      // return a group for every materialization to achieve un-grouped rendering
      return events.map((event) => ({
        latest: event,
        partition: event.partition || undefined,
        timestamp: event.timestamp,
        all: [],
      }));
    }
  }, [loadedPartitionKeys, events, xAxis]);
}
