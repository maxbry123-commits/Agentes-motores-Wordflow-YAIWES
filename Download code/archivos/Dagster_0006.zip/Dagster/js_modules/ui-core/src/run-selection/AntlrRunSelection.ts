import {CharStream, CommonTokenStream} from 'antlr4ng';

import {AntlrRunSelectionVisitor} from './AntlrRunSelectionVisitor';
import {AntlrInputErrorListener} from '../asset-selection/parseAssetSelectionQuery';
import {RunGraphQueryItem} from '../gantt/toGraphQueryItems';
import {RunSelectionLexer} from './generated/RunSelectionLexer';
import {RunSelectionParser} from './generated/RunSelectionParser';
import {weakMapMemoize} from '../util/weakMapMemoize';

export type RunSelectionQueryResult = {
  all: RunGraphQueryItem[];
  focus: RunGraphQueryItem[];
};

export const parseRunSelectionQuery = (
  all_runs: RunGraphQueryItem[],
  query: string,
): RunSelectionQueryResult | Error => {
  try {
    const lexer = new RunSelectionLexer(CharStream.fromString(query));
    lexer.removeErrorListeners();
    lexer.addErrorListener(new AntlrInputErrorListener());

    const tokenStream = new CommonTokenStream(lexer);
    tokenStream.fill(); // Ensure all tokens are loaded before parsing

    const parser = new RunSelectionParser(tokenStream);
    parser.removeErrorListeners();
    parser.addErrorListener(new AntlrInputErrorListener());

    const tree = parser.start();

    const visitor = new AntlrRunSelectionVisitor(all_runs);
    const all_selection = visitor.visit(tree) ?? new Set<RunGraphQueryItem>();
    const focus_selection = visitor.focus_runs;

    return {
      all: Array.from(all_selection),
      focus: Array.from(focus_selection),
    };
  } catch (e) {
    return e as Error;
  }
};

export const filterRunSelectionByQuery = weakMapMemoize(
  (all_runs: RunGraphQueryItem[], query: string): RunSelectionQueryResult => {
    if (query.length === 0) {
      return {all: all_runs, focus: []};
    }
    const result = parseRunSelectionQuery(all_runs, query);
    if (result instanceof Error) {
      return {all: [], focus: []};
    }
    return result;
  },
  {maxEntries: 20},
);
