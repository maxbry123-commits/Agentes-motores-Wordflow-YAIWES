﻿// Copyright (c) Microsoft. All rights reserved.

using System;
using System.Threading;
using System.Threading.Tasks;

namespace Microsoft.Agents.AI.Hosting;

/// <summary>
/// A delegating <see cref="AgentSessionStore"/> that scopes session keys by an isolation key
/// provided by an <see cref="AgentIsolationKeyProvider"/>, ensuring that sessions are isolated
/// per logical partition (e.g., user, tenant, or composite key).
/// </summary>
public class IsolationKeyScopedAgentSessionStore : DelegatingAgentSessionStore
{
    private readonly AgentIsolationKeyProvider? _keyProvider;
    private readonly bool _strict;

    /// <summary>
    /// Initializes a new instance of the <see cref="IsolationKeyScopedAgentSessionStore"/> class.
    /// </summary>
    /// <param name="innerStore">The underlying <see cref="AgentSessionStore"/> to delegate to.</param>
    /// <param name="keyProvider">
    /// The <see cref="AgentIsolationKeyProvider"/> used to retrieve the isolation key for the current context.
    /// </param>
    /// <param name="options">The options for configuring the session store. If null, defaults are used.</param>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="innerStore"/> is <see langword="null"/>.
    /// </exception>
    public IsolationKeyScopedAgentSessionStore(
        AgentSessionStore innerStore,
        AgentIsolationKeyProvider? keyProvider,
        IsolationKeyScopedAgentSessionStoreOptions? options = null)
        : base(innerStore)
    {
        this._keyProvider = keyProvider;
        options ??= new IsolationKeyScopedAgentSessionStoreOptions();
        this._strict = options.Strict;
    }

    /// <summary>
    /// Asynchronously retrieves the isolation key from the provider and validates it if in strict mode.
    /// </summary>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>
    /// The isolation key string, or <see langword="null"/> if no key is available and non-strict mode is enabled.
    /// </returns>
    /// <exception cref="InvalidOperationException">
    /// The provider returned <see langword="null"/> and strict mode is enabled.
    /// </exception>
    private async ValueTask<string?> GetIsolationKeyAsync(CancellationToken cancellationToken)
    {
        string? key = this._keyProvider != null
                    ? await this._keyProvider.GetIsolationKeyAsync(cancellationToken).ConfigureAwait(false)
                    : null;

        if (this._strict && key == null)
        {
            throw new InvalidOperationException("Agent isolation key is required but was not provided by the configured AgentIsolationKeyProvider.");
        }

        return key;
    }

    /// <summary>
    /// Escapes special characters in the isolation key to ensure unambiguous scoped session store IDs.
    /// </summary>
    /// <param name="key">The raw isolation key.</param>
    /// <returns>The escaped isolation key.</returns>
    /// <remarks>
    /// Backslashes are escaped first (\ becomes \\), then colons (: becomes \:).
    /// This ensures the scoped session store ID format {key}::{sessionStoreId} can be parsed correctly.
    /// </remarks>
    private static string EscapeIsolationKey(string key) => key.Replace("\\", "\\\\").Replace(":", "\\:");

    /// <summary>
    /// Constructs a scoped session store ID by prefixing the bare session store ID with the escaped isolation key.
    /// </summary>
    /// <param name="bareSessionStoreId">The original session store ID.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>
    /// The scoped session store ID in the format {escapedKey}::{sessionStoreId}, or the bare session store ID
    /// if no isolation key is available and non-strict mode is enabled.
    /// </returns>
    private async ValueTask<string> GetScopedSessionStoreIdAsync(string bareSessionStoreId, CancellationToken cancellationToken)
    {
        string? key = await this.GetIsolationKeyAsync(cancellationToken).ConfigureAwait(false);
        if (key == null)
        {
            return bareSessionStoreId;
        }

        return $"{EscapeIsolationKey(key)}::{bareSessionStoreId}";
    }

    /// <inheritdoc />
    public override async ValueTask<AgentSession> GetSessionAsync(AIAgent agent, string sessionStoreId, CancellationToken cancellationToken = default)
    {
        string scopedSessionStoreId = await this.GetScopedSessionStoreIdAsync(sessionStoreId, cancellationToken).ConfigureAwait(false);
        return await this.InnerStore.GetSessionAsync(agent, scopedSessionStoreId, cancellationToken).ConfigureAwait(false);
    }

    /// <inheritdoc />
    public override async ValueTask SaveSessionAsync(AIAgent agent, string sessionStoreId, AgentSession session, CancellationToken cancellationToken = default)
    {
        string scopedSessionStoreId = await this.GetScopedSessionStoreIdAsync(sessionStoreId, cancellationToken).ConfigureAwait(false);
        await this.InnerStore.SaveSessionAsync(agent, scopedSessionStoreId, session, cancellationToken).ConfigureAwait(false);
    }

    /// <inheritdoc />
    public override async ValueTask DeleteSessionAsync(AIAgent agent, string sessionStoreId, CancellationToken cancellationToken = default)
    {
        string scopedSessionStoreId = await this.GetScopedSessionStoreIdAsync(sessionStoreId, cancellationToken).ConfigureAwait(false);
        await this.InnerStore.DeleteSessionAsync(agent, scopedSessionStoreId, cancellationToken).ConfigureAwait(false);
    }
}
