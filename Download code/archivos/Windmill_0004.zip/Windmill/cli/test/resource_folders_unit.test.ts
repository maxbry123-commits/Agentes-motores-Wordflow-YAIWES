/**
 * Unit tests for resource_folders.ts path detection and manipulation functions.
 * Tests both dotted (.flow, .app, .raw_app) and non-dotted (__flow, __app, __raw_app) modes.
 */

import { expect, test, describe, beforeEach, afterEach } from "bun:test";
import {
  setNonDottedPaths,
  getNonDottedPaths,
  getFolderSuffixes,
  getFolderSuffix,
  getMetadataFileName,
  getMetadataPathSuffix,
  isFlowPath,
  isAppPath,
  isRawAppPath,
  isFolderResourcePath,
  isFolderResourcePathAnyFormat,
  detectFolderResourceType,
  isRawAppBackendPath,
  isAppInlineScriptPath,
  isFlowInlineScriptPath,
  extractResourceName,
  extractFolderPath,
  buildFolderPath,
  buildMetadataPath,
  hasFolderSuffix,
  validateFolderName,
  extractNameFromFolder,
  isFlowMetadataFile,
  isAppMetadataFile,
  isRawAppMetadataFile,
  isRawAppFolderMetadataFile,
  isAppFolderMetadataFile,
  isFlowFolderMetadataFile,
  getDeleteSuffix,
  transformJsonPathToDir,
  isModuleEntryPoint,
  getScriptBasePathFromModulePath,
  isDbtGeneratedPath,
  dbtGeneratedDirs,
  isUnderGeneratedDir,
  isDbtModulePath,
  isBundledModuleFile,
  moduleFileExclusion,
  MAX_MODULE_BYTES,
} from "../src/utils/resource_folders.ts";
import { removeWorkerPrefix } from "../src/commands/worker-groups/worker-groups.ts";

// =============================================================================
// Helper: reset to dotted mode before each test
// =============================================================================

beforeEach(() => {
  setNonDottedPaths(false);
});

// =============================================================================
// Configuration Functions
// =============================================================================

describe("setNonDottedPaths / getNonDottedPaths", () => {
  test("defaults to false (dotted)", () => {
    expect(getNonDottedPaths()).toBe(false);
  });

  test("can be set to true", () => {
    setNonDottedPaths(true);
    expect(getNonDottedPaths()).toBe(true);
  });

  test("can be toggled back to false", () => {
    setNonDottedPaths(true);
    setNonDottedPaths(false);
    expect(getNonDottedPaths()).toBe(false);
  });
});

describe("getFolderSuffixes", () => {
  test("returns dotted suffixes by default", () => {
    const suffixes = getFolderSuffixes();
    expect(suffixes.flow).toBe(".flow");
    expect(suffixes.app).toBe(".app");
    expect(suffixes.raw_app).toBe(".raw_app");
  });

  test("returns non-dotted suffixes when configured", () => {
    setNonDottedPaths(true);
    const suffixes = getFolderSuffixes();
    expect(suffixes.flow).toBe("__flow");
    expect(suffixes.app).toBe("__app");
    expect(suffixes.raw_app).toBe("__raw_app");
  });
});

describe("getFolderSuffix", () => {
  test("returns correct suffix for each type (dotted)", () => {
    expect(getFolderSuffix("flow")).toBe(".flow");
    expect(getFolderSuffix("app")).toBe(".app");
    expect(getFolderSuffix("raw_app")).toBe(".raw_app");
  });

  test("returns correct suffix for each type (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(getFolderSuffix("flow")).toBe("__flow");
    expect(getFolderSuffix("app")).toBe("__app");
    expect(getFolderSuffix("raw_app")).toBe("__raw_app");
  });
});

// =============================================================================
// Metadata File Names
// =============================================================================

describe("getMetadataFileName", () => {
  test("returns correct metadata file names", () => {
    expect(getMetadataFileName("flow", "yaml")).toBe("flow.yaml");
    expect(getMetadataFileName("flow", "json")).toBe("flow.json");
    expect(getMetadataFileName("app", "yaml")).toBe("app.yaml");
    expect(getMetadataFileName("app", "json")).toBe("app.json");
    expect(getMetadataFileName("raw_app", "yaml")).toBe("raw_app.yaml");
    expect(getMetadataFileName("raw_app", "json")).toBe("raw_app.json");
  });
});

describe("getMetadataPathSuffix", () => {
  test("returns correct path suffix (dotted)", () => {
    expect(getMetadataPathSuffix("flow", "yaml")).toBe(".flow/flow.yaml");
    expect(getMetadataPathSuffix("app", "json")).toBe(".app/app.json");
    expect(getMetadataPathSuffix("raw_app", "yaml")).toBe(".raw_app/raw_app.yaml");
  });

  test("returns correct path suffix (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(getMetadataPathSuffix("flow", "yaml")).toBe("__flow/flow.yaml");
    expect(getMetadataPathSuffix("app", "json")).toBe("__app/app.json");
    expect(getMetadataPathSuffix("raw_app", "yaml")).toBe("__raw_app/raw_app.yaml");
  });
});

// =============================================================================
// Path Detection Functions (dotted mode)
// =============================================================================

describe("isFlowPath (dotted)", () => {
  test("detects flow paths", () => {
    expect(isFlowPath("f/my_flow.flow/flow.yaml")).toBe(true);
    expect(isFlowPath("u/admin/test.flow/step.ts")).toBe(true);
  });

  test("rejects non-flow paths", () => {
    expect(isFlowPath("f/my_script.ts")).toBe(false);
    expect(isFlowPath("f/my_app.app/app.yaml")).toBe(false);
  });
});

describe("isAppPath (dotted)", () => {
  test("detects app paths", () => {
    expect(isAppPath("f/my_app.app/app.yaml")).toBe(true);
    expect(isAppPath("u/admin/dashboard.app/inline.ts")).toBe(true);
  });

  test("rejects non-app paths", () => {
    expect(isAppPath("f/my_script.ts")).toBe(false);
    expect(isAppPath("f/my_flow.flow/flow.yaml")).toBe(false);
  });
});

describe("isRawAppPath (dotted)", () => {
  test("detects raw_app paths", () => {
    expect(isRawAppPath("f/my_raw.raw_app/raw_app.yaml")).toBe(true);
  });

  test("rejects non-raw_app paths", () => {
    expect(isRawAppPath("f/my_app.app/app.yaml")).toBe(false);
    expect(isRawAppPath("f/my_script.ts")).toBe(false);
  });
});

// =============================================================================
// Path Detection Functions (non-dotted mode)
// =============================================================================

describe("isFlowPath (non-dotted)", () => {
  test("detects non-dotted flow paths", () => {
    setNonDottedPaths(true);
    expect(isFlowPath("f/my_flow__flow/flow.yaml")).toBe(true);
  });

  test("rejects dotted flow paths in non-dotted mode", () => {
    setNonDottedPaths(true);
    expect(isFlowPath("f/my_flow.flow/flow.yaml")).toBe(false);
  });
});

describe("isAppPath (non-dotted)", () => {
  test("detects non-dotted app paths", () => {
    setNonDottedPaths(true);
    expect(isAppPath("f/my_app__app/app.yaml")).toBe(true);
  });
});

describe("isRawAppPath (non-dotted)", () => {
  test("detects non-dotted raw_app paths", () => {
    setNonDottedPaths(true);
    expect(isRawAppPath("f/my_raw__raw_app/raw_app.yaml")).toBe(true);
  });
});

// =============================================================================
// Composite Path Detection
// =============================================================================

describe("isFolderResourcePath", () => {
  test("returns true for any folder resource path", () => {
    expect(isFolderResourcePath("f/x.flow/flow.yaml")).toBe(true);
    expect(isFolderResourcePath("f/x.app/app.yaml")).toBe(true);
    expect(isFolderResourcePath("f/x.raw_app/raw_app.yaml")).toBe(true);
  });

  test("returns false for non-folder paths", () => {
    expect(isFolderResourcePath("f/script.ts")).toBe(false);
    expect(isFolderResourcePath("f/var.variable.yaml")).toBe(false);
  });
});

// This is the bug that isFolderResourcePathAnyFormat fixes:
// when nonDottedPaths is false (default), isFolderResourcePath misses non-dotted paths
// like "f/my_raw__raw_app/backend/a.ts", causing raw app backend scripts to leak
// into the standalone script list during generate-metadata.
describe("isFolderResourcePathAnyFormat", () => {
  test("detects non-dotted paths even when global setting is dotted", () => {
    setNonDottedPaths(false);
    expect(isFolderResourcePathAnyFormat("f/my_raw__raw_app/backend/a.ts")).toBe(true);
    expect(isFolderResourcePathAnyFormat("f/my_flow__flow/step.ts")).toBe(true);
    expect(isFolderResourcePathAnyFormat("f/dashboard__app/inline.ts")).toBe(true);
  });

  test("detects dotted paths even when global setting is non-dotted", () => {
    setNonDottedPaths(true);
    expect(isFolderResourcePathAnyFormat("f/my_raw.raw_app/backend/a.ts")).toBe(true);
    expect(isFolderResourcePathAnyFormat("f/my_flow.flow/step.ts")).toBe(true);
    expect(isFolderResourcePathAnyFormat("f/dashboard.app/inline.ts")).toBe(true);
  });

  test("rejects non-folder-resource paths", () => {
    expect(isFolderResourcePathAnyFormat("f/my_script.ts")).toBe(false);
    expect(isFolderResourcePathAnyFormat("f/var.variable.yaml")).toBe(false);
  });

  test("confirms isFolderResourcePath fails for mismatched format (the bug)", () => {
    setNonDottedPaths(false);
    // isFolderResourcePath misses non-dotted paths when setting is dotted
    expect(isFolderResourcePath("f/my_raw__raw_app/backend/a.ts")).toBe(false);
    // isFolderResourcePathAnyFormat catches it
    expect(isFolderResourcePathAnyFormat("f/my_raw__raw_app/backend/a.ts")).toBe(true);
  });
});

describe("detectFolderResourceType", () => {
  test("detects flow type", () => {
    expect(detectFolderResourceType("f/x.flow/flow.yaml")).toBe("flow");
  });

  test("detects app type", () => {
    expect(detectFolderResourceType("f/x.app/app.yaml")).toBe("app");
  });

  test("detects raw_app type", () => {
    expect(detectFolderResourceType("f/x.raw_app/raw_app.yaml")).toBe("raw_app");
  });

  test("returns null for non-folder paths", () => {
    expect(detectFolderResourceType("f/script.ts")).toBeNull();
  });
});

// =============================================================================
// Inline Script / Backend Path Detection
// =============================================================================

describe("isRawAppBackendPath", () => {
  test("detects raw app backend paths (dotted)", () => {
    expect(isRawAppBackendPath("f/my_app.raw_app/backend/handler.ts")).toBe(true);
  });

  test("rejects non-backend raw app paths", () => {
    expect(isRawAppBackendPath("f/my_app.raw_app/raw_app.yaml")).toBe(false);
  });

  test("detects raw app backend paths (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(isRawAppBackendPath("f/my_app__raw_app/backend/handler.ts")).toBe(true);
  });
});

describe("isAppInlineScriptPath", () => {
  test("detects inline script paths in apps", () => {
    expect(isAppInlineScriptPath("f/dashboard.app/inline_0.ts")).toBe(true);
  });

  test("rejects non-app paths", () => {
    expect(isAppInlineScriptPath("f/script.ts")).toBe(false);
  });
});

describe("isFlowInlineScriptPath", () => {
  test("detects inline script paths in flows", () => {
    expect(isFlowInlineScriptPath("f/pipeline.flow/step_0.ts")).toBe(true);
  });

  test("rejects non-flow paths", () => {
    expect(isFlowInlineScriptPath("f/script.ts")).toBe(false);
  });
});

// =============================================================================
// Path Manipulation Functions
// =============================================================================

describe("extractResourceName", () => {
  test("extracts name from flow path", () => {
    expect(extractResourceName("f/my_flow.flow/flow.yaml", "flow")).toBe("f/my_flow");
  });

  test("extracts name from app path", () => {
    expect(extractResourceName("f/dashboard.app/app.yaml", "app")).toBe("f/dashboard");
  });

  test("extracts name from raw_app path", () => {
    expect(extractResourceName("f/my_raw.raw_app/raw_app.yaml", "raw_app")).toBe("f/my_raw");
  });

  test("returns null when type doesn't match", () => {
    expect(extractResourceName("f/script.ts", "flow")).toBeNull();
  });

  test("works in non-dotted mode", () => {
    setNonDottedPaths(true);
    expect(extractResourceName("f/my_flow__flow/flow.yaml", "flow")).toBe("f/my_flow");
  });
});

describe("extractFolderPath", () => {
  test("extracts folder path from flow", () => {
    expect(extractFolderPath("f/my_flow.flow/flow.yaml", "flow")).toBe("f/my_flow.flow/");
  });

  test("returns null when type doesn't match", () => {
    expect(extractFolderPath("f/script.ts", "flow")).toBeNull();
  });
});

describe("buildFolderPath", () => {
  test("builds folder path (dotted)", () => {
    expect(buildFolderPath("f/my_flow", "flow")).toBe("f/my_flow.flow");
    expect(buildFolderPath("f/dashboard", "app")).toBe("f/dashboard.app");
    expect(buildFolderPath("f/my_raw", "raw_app")).toBe("f/my_raw.raw_app");
  });

  test("builds folder path (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(buildFolderPath("f/my_flow", "flow")).toBe("f/my_flow__flow");
    expect(buildFolderPath("f/dashboard", "app")).toBe("f/dashboard__app");
    expect(buildFolderPath("f/my_raw", "raw_app")).toBe("f/my_raw__raw_app");
  });
});

describe("buildMetadataPath", () => {
  test("builds metadata path (dotted, yaml)", () => {
    expect(buildMetadataPath("f/my_flow", "flow", "yaml")).toBe("f/my_flow.flow/flow.yaml");
  });

  test("builds metadata path (dotted, json)", () => {
    expect(buildMetadataPath("f/dashboard", "app", "json")).toBe("f/dashboard.app/app.json");
  });

  test("builds metadata path (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(buildMetadataPath("f/my_flow", "flow", "yaml")).toBe("f/my_flow__flow/flow.yaml");
  });
});

// =============================================================================
// Folder Validation Functions
// =============================================================================

describe("hasFolderSuffix", () => {
  test("returns true for matching suffix", () => {
    expect(hasFolderSuffix("my_flow.flow", "flow")).toBe(true);
    expect(hasFolderSuffix("dashboard.app", "app")).toBe(true);
    expect(hasFolderSuffix("my_raw.raw_app", "raw_app")).toBe(true);
  });

  test("returns false for non-matching suffix", () => {
    expect(hasFolderSuffix("my_flow.app", "flow")).toBe(false);
    expect(hasFolderSuffix("script.ts", "flow")).toBe(false);
  });

  test("works in non-dotted mode", () => {
    setNonDottedPaths(true);
    expect(hasFolderSuffix("my_flow__flow", "flow")).toBe(true);
    expect(hasFolderSuffix("my_flow.flow", "flow")).toBe(false);
  });
});

describe("validateFolderName", () => {
  test("returns null for valid folder name", () => {
    expect(validateFolderName("my_flow.flow", "flow")).toBeNull();
  });

  test("returns error message for invalid folder name", () => {
    const result = validateFolderName("my_flow.app", "flow");
    expect(result).not.toBeNull();
    expect(result).toContain("my_flow.app");
    expect(result).toContain(".flow");
  });
});

describe("extractNameFromFolder", () => {
  test("extracts name by removing suffix (dotted)", () => {
    expect(extractNameFromFolder("my_flow.flow", "flow")).toBe("my_flow");
    expect(extractNameFromFolder("dashboard.app", "app")).toBe("dashboard");
    expect(extractNameFromFolder("my_raw.raw_app", "raw_app")).toBe("my_raw");
  });

  test("returns original name if suffix doesn't match", () => {
    expect(extractNameFromFolder("my_script", "flow")).toBe("my_script");
  });

  test("extracts name (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(extractNameFromFolder("my_flow__flow", "flow")).toBe("my_flow");
  });
});

// =============================================================================
// Metadata File Detection Functions
// =============================================================================

describe("isFlowMetadataFile", () => {
  test("detects dotted flow metadata files", () => {
    expect(isFlowMetadataFile("f/my_flow.flow.json")).toBe(true);
    expect(isFlowMetadataFile("f/my_flow.flow.yaml")).toBe(true);
  });

  test("rejects non-flow metadata files", () => {
    expect(isFlowMetadataFile("f/my_app.app.json")).toBe(false);
    expect(isFlowMetadataFile("f/script.ts")).toBe(false);
  });

  test("detects non-dotted flow metadata files when configured", () => {
    setNonDottedPaths(true);
    expect(isFlowMetadataFile("f/my_flow__flow.json")).toBe(true);
    expect(isFlowMetadataFile("f/my_flow__flow.yaml")).toBe(true);
    // API format (dotted) is always detected
    expect(isFlowMetadataFile("f/my_flow.flow.json")).toBe(true);
  });
});

describe("isAppMetadataFile", () => {
  test("detects dotted app metadata files", () => {
    expect(isAppMetadataFile("f/dashboard.app.json")).toBe(true);
    expect(isAppMetadataFile("f/dashboard.app.yaml")).toBe(true);
  });

  test("rejects non-app metadata files", () => {
    expect(isAppMetadataFile("f/my_flow.flow.json")).toBe(false);
  });

  test("detects non-dotted app metadata files when configured", () => {
    setNonDottedPaths(true);
    expect(isAppMetadataFile("f/dashboard__app.json")).toBe(true);
    // API format always detected
    expect(isAppMetadataFile("f/dashboard.app.json")).toBe(true);
  });
});

describe("isRawAppMetadataFile", () => {
  test("detects dotted raw_app metadata files", () => {
    expect(isRawAppMetadataFile("f/my_raw.raw_app.json")).toBe(true);
    expect(isRawAppMetadataFile("f/my_raw.raw_app.yaml")).toBe(true);
  });

  test("rejects non-raw_app metadata files", () => {
    expect(isRawAppMetadataFile("f/my_app.app.json")).toBe(false);
  });

  test("detects non-dotted raw_app metadata files when configured", () => {
    setNonDottedPaths(true);
    expect(isRawAppMetadataFile("f/my_raw__raw_app.json")).toBe(true);
    expect(isRawAppMetadataFile("f/my_raw.raw_app.json")).toBe(true);
  });
});

describe("isRawAppFolderMetadataFile", () => {
  test("detects raw_app folder metadata file (dotted)", () => {
    expect(isRawAppFolderMetadataFile("f/my_raw.raw_app/raw_app.yaml")).toBe(true);
    expect(isRawAppFolderMetadataFile("f/my_raw.raw_app/raw_app.json")).toBe(true);
  });

  test("rejects non-metadata files", () => {
    expect(isRawAppFolderMetadataFile("f/my_raw.raw_app/backend/handler.ts")).toBe(false);
  });
});

describe("isAppFolderMetadataFile", () => {
  test("detects app folder metadata file (dotted)", () => {
    expect(isAppFolderMetadataFile("f/common/landing.app/app.yaml")).toBe(true);
    expect(isAppFolderMetadataFile("f/common/landing.app/app.json")).toBe(true);
  });

  test("rejects inline script files inside app folder", () => {
    expect(isAppFolderMetadataFile("f/common/landing.app/eval_of_e.inline_script.frontend.js")).toBe(false);
    expect(isAppFolderMetadataFile("f/common/landing.app/button1.inline_script.bun.ts")).toBe(false);
  });

  test("rejects top-level app metadata files", () => {
    expect(isAppFolderMetadataFile("f/common/landing.app.json")).toBe(false);
    expect(isAppFolderMetadataFile("f/common/landing.app.yaml")).toBe(false);
  });
});

describe("isFlowFolderMetadataFile", () => {
  test("detects flow folder metadata file (dotted)", () => {
    expect(isFlowFolderMetadataFile("f/common/my_flow.flow/flow.yaml")).toBe(true);
    expect(isFlowFolderMetadataFile("f/common/my_flow.flow/flow.json")).toBe(true);
  });

  test("rejects inline script files inside flow folder", () => {
    expect(isFlowFolderMetadataFile("f/common/my_flow.flow/step_0.inline_script.ts")).toBe(false);
  });

  test("rejects top-level flow metadata files", () => {
    expect(isFlowFolderMetadataFile("f/common/my_flow.flow.json")).toBe(false);
  });
});

// =============================================================================
// Sync-related Path Functions
// =============================================================================

describe("getDeleteSuffix", () => {
  test("returns correct delete suffix", () => {
    expect(getDeleteSuffix("flow", "yaml")).toBe(".flow/flow.yaml");
    expect(getDeleteSuffix("app", "json")).toBe(".app/app.json");
    expect(getDeleteSuffix("raw_app", "yaml")).toBe(".raw_app/raw_app.yaml");
  });

  test("returns correct delete suffix (non-dotted)", () => {
    setNonDottedPaths(true);
    expect(getDeleteSuffix("flow", "yaml")).toBe("__flow/flow.yaml");
  });
});

describe("transformJsonPathToDir", () => {
  test("transforms API dotted .flow.json to dotted dir", () => {
    expect(transformJsonPathToDir("f/my_flow.flow.json", "flow")).toBe("f/my_flow.flow");
  });

  test("transforms API dotted .app.json to dotted dir", () => {
    expect(transformJsonPathToDir("f/dashboard.app.json", "app")).toBe("f/dashboard.app");
  });

  test("transforms API dotted to non-dotted dir when configured", () => {
    setNonDottedPaths(true);
    expect(transformJsonPathToDir("f/my_flow.flow.json", "flow")).toBe("f/my_flow__flow");
  });

  test("handles already-configured format", () => {
    setNonDottedPaths(true);
    expect(transformJsonPathToDir("f/my_flow__flow.json", "flow")).toBe("f/my_flow__flow");
  });

  test("returns unchanged path when suffix doesn't match", () => {
    expect(transformJsonPathToDir("f/script.ts", "flow")).toBe("f/script.ts");
  });
});

// =============================================================================
// removeWorkerPrefix (from worker-groups.ts)
// =============================================================================

// =============================================================================
// Module Path Functions
// =============================================================================

describe("isModuleEntryPoint", () => {
  test("detects entry point files in __mod folders", () => {
    expect(isModuleEntryPoint("f/my_script__mod/script.ts")).toBe(true);
    expect(isModuleEntryPoint("u/admin/tool__mod/script.py")).toBe(true);
    expect(isModuleEntryPoint("f/nested/path/script__mod/script.go")).toBe(true);
  });

  test("rejects non-entry-point files in __mod folders", () => {
    expect(isModuleEntryPoint("f/my_script__mod/helper.ts")).toBe(false);
    expect(isModuleEntryPoint("f/my_script__mod/utils/math.py")).toBe(false);
    expect(isModuleEntryPoint("f/my_script__mod/helper.lock")).toBe(false);
  });

  test("rejects entry point files in subdirectories of __mod", () => {
    expect(isModuleEntryPoint("f/my_script__mod/sub/script.ts")).toBe(false);
  });

  test("rejects paths without __mod", () => {
    expect(isModuleEntryPoint("f/my_script.ts")).toBe(false);
    expect(isModuleEntryPoint("f/script.ts")).toBe(false);
  });

  test("handles windows-style separators", () => {
    expect(isModuleEntryPoint("f\\my_script__mod\\script.ts")).toBe(true);
    expect(isModuleEntryPoint("f\\my_script__mod\\helper.ts")).toBe(false);
  });

  test("matches any extension for script.*", () => {
    expect(isModuleEntryPoint("f/x__mod/script.yaml")).toBe(true);
    expect(isModuleEntryPoint("f/x__mod/script.json")).toBe(true);
    expect(isModuleEntryPoint("f/x__mod/script.lock")).toBe(true);
    expect(isModuleEntryPoint("f/x__mod/script.sh")).toBe(true);
  });
});

describe("getScriptBasePathFromModulePath", () => {
  test("extracts base path from module entry point", () => {
    expect(getScriptBasePathFromModulePath("f/my_script__mod/script.ts")).toBe("f/my_script");
    expect(getScriptBasePathFromModulePath("u/admin/tool__mod/script.py")).toBe("u/admin/tool");
  });

  test("extracts base path from module helper files", () => {
    expect(getScriptBasePathFromModulePath("f/my_script__mod/helper.ts")).toBe("f/my_script");
    expect(getScriptBasePathFromModulePath("f/my_script__mod/utils/math.py")).toBe("f/my_script");
  });

  test("extracts base path from nested script paths", () => {
    expect(getScriptBasePathFromModulePath("f/deeply/nested/script__mod/helper.ts")).toBe("f/deeply/nested/script");
  });

  test("returns undefined for non-module paths", () => {
    expect(getScriptBasePathFromModulePath("f/my_script.ts")).toBeUndefined();
    expect(getScriptBasePathFromModulePath("f/my_flow.flow/flow.yaml")).toBeUndefined();
  });

  test("handles windows-style separators", () => {
    expect(getScriptBasePathFromModulePath("f\\my_script__mod\\helper.ts")).toBe("f/my_script");
  });
});

describe("removeWorkerPrefix", () => {
  test("removes worker__ prefix", () => {
    expect(removeWorkerPrefix("worker__default")).toBe("default");
    expect(removeWorkerPrefix("worker__gpu")).toBe("gpu");
  });

  test("returns name unchanged if no prefix", () => {
    expect(removeWorkerPrefix("default")).toBe("default");
    expect(removeWorkerPrefix("gpu")).toBe("gpu");
  });

  test("handles empty string", () => {
    expect(removeWorkerPrefix("")).toBe("");
  });

  test("handles worker__ as the entire name", () => {
    expect(removeWorkerPrefix("worker__")).toBe("");
  });
});

// A dbt project's generated directories never belong to the bundle: hashing and
// uploading a local `target/` would make every local `dbt run` look like a
// project change, and a stale manifest in it is what the runtime reads as the
// graph. They are configurable, so they are read from the project.
describe("dbtGeneratedDirs", () => {
  const fs = require("node:fs");
  const os = require("node:os");
  const nodePath = require("node:path");
  let dir: string;
  // Every temp directory this block makes, so none outlives the run: the helper
  // below mints one per call by design.
  let made: string[] = [];

  beforeEach(() => {
    dir = fs.mkdtempSync(nodePath.join(os.tmpdir(), "dbtgen-"));
    made = [dir];
  });

  afterEach(() => {
    for (const d of made) fs.rmSync(d, { recursive: true, force: true });
  });

  // A fresh directory per call: `dbtGeneratedDirs` memoizes per project folder,
  // since within one sync the project file does not change under it.
  const write = (yml: string) => {
    const d = fs.mkdtempSync(nodePath.join(os.tmpdir(), "dbtgen-"));
    made.push(d);
    fs.writeFileSync(nodePath.join(d, "dbt_project.yml"), yml);
    return dbtGeneratedDirs(d);
  };

  test("defaults apply with no project file", () => {
    const dirs = dbtGeneratedDirs(dir);
    expect(dirs.has("target")).toBe(true);
    expect(dirs.has("dbt_packages")).toBe(true);
  });

  test("reads nested target-path and packages-install-path", () => {
    const dirs = write(
      'name: p\ntarget-path: "build/target"\npackages-install-path: ./vendor/pkgs\n',
    );
    expect(dirs.has("build/target")).toBe(true);
    expect(dirs.has("vendor/pkgs")).toBe(true);
  });

  test("reads clean-targets in both of dbt's spellings", () => {
    expect(write('name: p\nclean-targets: ["a", b]\n').has("a")).toBe(true);
    const block = write("name: p\nclean-targets:\n  - out/one\n  - two\nmodels: {}\n");
    expect(block.has("out/one")).toBe(true);
    expect(block.has("two")).toBe(true);
    expect(block.has("models")).toBe(false);
  });

  test("ignores a configured path that escapes the project", () => {
    const dirs = write('name: p\ntarget-path: "../../etc"\n');
    expect([...dirs].some((d) => d.includes(".."))).toBe(false);
  });
});

describe("isUnderGeneratedDir", () => {
  const dirs = new Set(["target", "build/target"]);

  test("matches the directory and everything under it", () => {
    expect(isUnderGeneratedDir("target", dirs)).toBe(true);
    expect(isUnderGeneratedDir("target/manifest.json", dirs)).toBe(true);
    expect(isUnderGeneratedDir("build/target/run_results.json", dirs)).toBe(true);
  });

  test("does not match a sibling sharing the prefix", () => {
    expect(isUnderGeneratedDir("targetx/a.sql", dirs)).toBe(false);
    expect(isUnderGeneratedDir("models/target_helper.sql", dirs)).toBe(false);
    expect(isUnderGeneratedDir("build/targeted/a.sql", dirs)).toBe(false);
  });
});

// A Windows path spells the folder `__dbt\\`. A lookup that searched the raw
// path for `__dbt/` would find nothing, so a module-only edit would return
// without deploying its parent while the file was still recorded as synced.
describe("dbt module paths on either separator", () => {
  test("isDbtModulePath and getScriptBasePathFromModulePath accept backslashes", () => {
    expect(isDbtModulePath("f\\x\\proj__dbt\\models\\a.sql")).toBe(true);
    expect(getScriptBasePathFromModulePath("f\\x\\proj__dbt\\models\\a.sql")).toBe(
      "f/x/proj",
    );
    expect(getScriptBasePathFromModulePath("f/x/proj__dbt/models/a.sql")).toBe(
      "f/x/proj",
    );
  });

  test("a path with no module folder has no base path", () => {
    expect(getScriptBasePathFromModulePath("f/x/proj.dbt.yaml")).toBeUndefined();
  });
});

// The push, the staleness hash and the sync diff all ask this question. They
// must agree: a file one drops and another keeps is a change no push resolves.
describe("isBundledModuleFile", () => {
  const fs = require("node:fs");
  const os = require("node:os");
  const nodePath = require("node:path");
  let dir: string;

  beforeEach(() => {
    dir = fs.mkdtempSync(nodePath.join(os.tmpdir(), "bundled-"));
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  const write = (name: string, data: Buffer | string) => {
    const p = nodePath.join(dir, name);
    fs.writeFileSync(p, data);
    return p;
  };

  test("keeps text, including empty and unicode", () => {
    expect(isBundledModuleFile(write("a.sql", "select 1\n"))).toBe(true);
    expect(isBundledModuleFile(write("empty.sql", ""))).toBe(true);
    expect(isBundledModuleFile(write("u.sql", "select 'café'\n"))).toBe(true);
  });

  test("drops a binary file, which a NUL identifies", () => {
    expect(isBundledModuleFile(write("x.png", Buffer.from([0x89, 0x50, 0x00, 0x1a])))).toBe(
      false,
    );
  });

  test("drops a file over the per-file limit", () => {
    expect(isBundledModuleFile(write("huge.csv", "x".repeat(MAX_MODULE_BYTES + 1)))).toBe(
      false,
    );
  });

  // The two reasons a file is not carried are not interchangeable: sync hides
  // dbt's binary leftovers, but an oversized seed the project authored has to
  // stay in the diff, or the push that reports the size error never runs and the
  // remote project is left incomplete without saying so.
  test("says WHY a file is not carried", () => {
    expect(moduleFileExclusion(write("a.sql", "select 1\n"))).toBe(undefined);
    expect(moduleFileExclusion(write("x.png", Buffer.from([0x89, 0x50, 0x00, 0x1a])))).toBe(
      "binary",
    );
    expect(moduleFileExclusion(write("seed.csv", "x".repeat(MAX_MODULE_BYTES + 1)))).toBe(
      "oversized",
    );
  });

  // A pull asks this about files that do not exist locally yet. Answering "not
  // carried" there made sync ignore the whole incoming project and write
  // nothing — the bundle silently vanished on every fresh checkout.
  test("treats a missing file as carried, not as excluded", () => {
    expect(isBundledModuleFile(nodePath.join(dir, "does-not-exist.sql"))).toBe(true);
  });
});

test("a nested __mod inside a dbt project does not steal the script boundary", () => {
  // dbt owns its directory names verbatim, so a folder ending `__mod` is legal
  // inside a project. The script is the OUTER module boundary.
  expect(
    getScriptBasePathFromModulePath("f/x/proj__dbt/models/legacy__mod/a.sql"),
  ).toBe("f/x/proj");
  expect(getScriptBasePathFromModulePath("f/x/proj__dbt/models/a.sql")).toBe(
    "f/x/proj",
  );
  expect(getScriptBasePathFromModulePath("f/x/s__mod/inner.ts")).toBe("f/x/s");
});

test("a nested __mod inside a dbt project is not a module entry point", () => {
  expect(isModuleEntryPoint("f/x/s__mod/script.ts")).toBe(true);
  // `legacy__mod` is a legal dbt directory; its script.ts belongs to the dbt
  // project, not to a module folder of its own.
  expect(isModuleEntryPoint("f/x/proj__dbt/models/legacy__mod/script.ts")).toBe(
    false,
  );
  expect(isModuleEntryPoint("f/x/proj__dbt/models/a.sql")).toBe(false);
});

test("a __dbt directory nested inside an ordinary module is not a dbt project file", () => {
  expect(isDbtModulePath("f/x/proj__dbt/models/a.sql")).toBe(true);
  // `vendor/x__dbt/` belongs to the `foo__mod` script, not to a dbt project.
  expect(isDbtModulePath("f/x/foo__mod/vendor/x__dbt/a.ts")).toBe(false);
  expect(isDbtModulePath("f/x/foo__mod/helper.ts")).toBe(false);
});

test("a __dbt/target nested in an ordinary module is not generated dbt output", () => {
  expect(isDbtGeneratedPath("f/x/proj__dbt/target/manifest.json")).toBe(true);
  // Belongs to the `foo__mod` script; excluding it would drop a real edit.
  expect(isDbtGeneratedPath("f/x/foo__mod/vendor/x__dbt/target/a.ts")).toBe(false);
});
