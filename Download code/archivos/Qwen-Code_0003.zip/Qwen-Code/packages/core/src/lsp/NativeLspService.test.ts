/**
 * @license
 * Copyright 2025 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, beforeEach, afterEach, expect, test, vi } from 'vitest';
import { NativeLspService } from './NativeLspService.js';
import { EventEmitter } from 'events';
import type { Config as CoreConfig } from '../config/config.js';
import type { FileDiscoveryService } from '../services/fileDiscoveryService.js';
import type { IdeContextStore } from '../ide/ideContext.js';
import type { WorkspaceContext } from '../utils/workspaceContext.js';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';

// 模拟依赖项
class MockConfig {
  rootPath = '/test/workspace';

  isTrustedFolder(): boolean {
    return true;
  }

  get(_key: string) {
    return undefined;
  }

  getProjectRoot(): string {
    return this.rootPath;
  }
}

class MockWorkspaceContext {
  rootPath = '/test/workspace';

  async fileExists(_path: string): Promise<boolean> {
    return _path.endsWith('.json') || _path.includes('package.json');
  }

  async readFile(_path: string): Promise<string> {
    if (_path.includes('.lsp.json')) {
      return JSON.stringify({
        typescript: {
          command: 'typescript-language-server',
          args: ['--stdio'],
          transport: 'stdio',
        },
      });
    }
    return '{}';
  }

  resolvePath(_path: string): string {
    return this.rootPath + '/' + _path;
  }

  isPathWithinWorkspace(_path: string): boolean {
    return true;
  }

  getDirectories(): string[] {
    return [this.rootPath];
  }
}

class MockFileDiscoveryService {
  async discoverFiles(_root: string, _options: unknown): Promise<string[]> {
    // 模拟发现一些文件
    return [
      '/test/workspace/src/index.ts',
      '/test/workspace/src/utils.ts',
      '/test/workspace/server.py',
      '/test/workspace/main.go',
    ];
  }

  shouldIgnoreFile(): boolean {
    return false;
  }
}

class MockIdeContextStore {
  // 模拟 IDE 上下文存储
}

describe('NativeLspService', () => {
  let lspService: NativeLspService;
  let mockConfig: MockConfig;
  let mockWorkspace: MockWorkspaceContext;
  let mockFileDiscovery: MockFileDiscoveryService;
  let mockIdeStore: MockIdeContextStore;
  let eventEmitter: EventEmitter;

  beforeEach(() => {
    mockConfig = new MockConfig();
    mockWorkspace = new MockWorkspaceContext();
    mockFileDiscovery = new MockFileDiscoveryService();
    mockIdeStore = new MockIdeContextStore();
    eventEmitter = new EventEmitter();

    lspService = new NativeLspService(
      mockConfig as unknown as CoreConfig,
      mockWorkspace as unknown as WorkspaceContext,
      eventEmitter,
      mockFileDiscovery as unknown as FileDiscoveryService,
      mockIdeStore as unknown as IdeContextStore,
    );
  });

  test('should initialize correctly', () => {
    expect(lspService).toBeDefined();
  });

  test('discoverAndPrepare should not invoke language detection', async () => {
    const service = new NativeLspService(
      mockConfig as unknown as CoreConfig,
      mockWorkspace as unknown as WorkspaceContext,
      eventEmitter,
      mockFileDiscovery as unknown as FileDiscoveryService,
      mockIdeStore as unknown as IdeContextStore,
    );

    const detectLanguages = vi.fn(async () => {
      throw new Error('detectLanguages should not be called');
    });
    (
      service as unknown as {
        languageDetector: { detectLanguages: () => Promise<string[]> };
      }
    ).languageDetector = { detectLanguages };

    await expect(service.discoverAndPrepare()).resolves.toBeUndefined();
    expect(detectLanguages).not.toHaveBeenCalled();
  });

  test('should prepare configs without language detection', async () => {
    await lspService.discoverAndPrepare();
    const status = lspService.getStatus();

    // 检查服务是否已准备就绪
    expect(status).toBeDefined();
  });

  test('reinitialize reconciles valid .lsp.json configs', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-reinit-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
            args: ['--stdio'],
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const reconcileServerConfigs = vi.fn(async () => ({
        added: ['typescript-language-server'],
        removed: [],
        restarted: [],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      const result = await service.reinitialize();

      expect(reconcileServerConfigs).toHaveBeenCalledWith([
        expect.objectContaining({
          name: 'typescript-language-server',
          languages: ['typescript'],
        }),
      ]);
      expect(result.reconcile.added).toEqual(['typescript-language-server']);
      expect(result.skipped).toEqual([]);
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize preserves runtime state on invalid .lsp.json', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-invalid-'));
    try {
      fs.writeFileSync(path.join(tempDir, '.lsp.json'), '{');
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const reconcileServerConfigs = vi.fn();
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      await expect(service.reinitialize()).rejects.toThrow();
      expect(reconcileServerConfigs).not.toHaveBeenCalled();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize preserves runtime state on invalid server entries', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-invalid-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            transport: 'stdio',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const reconcileServerConfigs = vi.fn();
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      await expect(service.reinitialize()).rejects.toThrow(
        'Invalid LSP server config',
      );
      expect(reconcileServerConfigs).not.toHaveBeenCalled();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize queue continues after a failed reload', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-queue-error-'));
    try {
      fs.writeFileSync(path.join(tempDir, '.lsp.json'), '{');
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const reconcileServerConfigs = vi.fn(async () => ({
        added: ['typescript-language-server'],
        removed: [],
        restarted: [],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      await expect(service.reinitialize()).rejects.toThrow();
      expect(reconcileServerConfigs).not.toHaveBeenCalled();

      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const result = await service.reinitialize();

      expect(reconcileServerConfigs).toHaveBeenCalledOnce();
      expect(result.reconcile.added).toEqual(['typescript-language-server']);
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize replays open documents after restarting servers', async () => {
    vi.useFakeTimers();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-replay-'));
    try {
      const filePath = path.join(tempDir, 'main.ts');
      const uri = pathToFileURL(filePath).toString();
      fs.writeFileSync(filePath, 'const value = 1;\n', 'utf-8');
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const connection = {
        listen: vi.fn(),
        send: vi.fn(),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const handle = {
        config: {
          name: 'typescript-language-server',
          languages: ['typescript'],
          command: 'typescript-language-server',
          args: [],
          transport: 'stdio',
        },
        status: 'READY',
        connection,
      };
      const reconcileServerConfigs = vi.fn(async () => ({
        added: [],
        removed: [],
        restarted: ['typescript-language-server'],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        getHandles: () => new Map([['typescript-language-server', handle]]),
      };
      const internals = service as unknown as {
        openedDocuments: Map<string, Set<string>>;
      };
      internals.openedDocuments.set(
        'typescript-language-server',
        new Set([uri]),
      );

      const reinitialize = service.reinitialize();
      await vi.runAllTimersAsync();
      await reinitialize;

      expect(connection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
          params: {
            textDocument: expect.objectContaining({
              uri,
              languageId: 'typescript',
              text: 'const value = 1;\n',
            }),
          },
        }),
      );
      expect(vi.getTimerCount()).toBe(0);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize continues replaying documents after one server send fails', async () => {
    vi.useFakeTimers();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-replay-'));
    try {
      const firstPath = path.join(tempDir, 'first.ts');
      const secondPath = path.join(tempDir, 'second.py');
      const firstUri = pathToFileURL(firstPath).toString();
      const secondUri = pathToFileURL(secondPath).toString();
      fs.writeFileSync(firstPath, 'const value = 1;\n', 'utf-8');
      fs.writeFileSync(secondPath, 'value = 1\n', 'utf-8');
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
          python: {
            command: 'pyright-langserver',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const firstConnection = {
        listen: vi.fn(),
        send: vi.fn(() => {
          throw new Error('broken pipe');
        }),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const secondConnection = {
        listen: vi.fn(),
        send: vi.fn(),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const handles = new Map([
        [
          'typescript-language-server',
          {
            config: {
              name: 'typescript-language-server',
              languages: ['typescript'],
              command: 'typescript-language-server',
              args: [],
              transport: 'stdio',
            },
            status: 'READY',
            connection: firstConnection,
          },
        ],
        [
          'pyright-langserver',
          {
            config: {
              name: 'pyright-langserver',
              languages: ['python'],
              command: 'pyright-langserver',
              args: [],
              transport: 'stdio',
            },
            status: 'READY',
            connection: secondConnection,
          },
        ],
      ]);
      const reconcileServerConfigs = vi.fn(async () => ({
        added: [],
        removed: [],
        restarted: ['typescript-language-server', 'pyright-langserver'],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        getHandles: () => handles,
      };
      const internals = service as unknown as {
        openedDocuments: Map<string, Set<string>>;
        lastConnections: Map<string, unknown>;
      };
      internals.openedDocuments.set(
        'typescript-language-server',
        new Set([firstUri]),
      );
      internals.openedDocuments.set('pyright-langserver', new Set([secondUri]));

      const reinitialize = service.reinitialize();
      await vi.runAllTimersAsync();
      await expect(reinitialize).resolves.toBeDefined();

      expect(firstConnection.send).toHaveBeenCalledOnce();
      expect(internals.lastConnections.has('typescript-language-server')).toBe(
        false,
      );
      expect(internals.lastConnections.get('pyright-langserver')).toBe(
        secondConnection,
      );
      expect(secondConnection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
          params: {
            textDocument: expect.objectContaining({
              uri: secondUri,
              languageId: 'python',
              text: 'value = 1\n',
            }),
          },
        }),
      );
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize preserves open documents for failed servers until a later restart succeeds', async () => {
    vi.useFakeTimers();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-failed-'));
    try {
      const filePath = path.join(tempDir, 'index.ts');
      const uri = pathToFileURL(filePath).toString();
      fs.writeFileSync(filePath, 'const value = 1;\n', 'utf-8');
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const connection = {
        listen: vi.fn(),
        send: vi.fn(),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const handle = {
        config: {
          name: 'typescript-language-server',
          languages: ['typescript'],
          command: 'typescript-language-server',
          args: [],
          transport: 'stdio',
        },
        status: 'READY',
        connection,
      };
      const reconcileServerConfigs = vi
        .fn()
        .mockResolvedValueOnce({
          added: [],
          removed: [],
          restarted: [],
          unchanged: [],
          failed: ['typescript-language-server'],
        })
        .mockResolvedValueOnce({
          added: [],
          removed: [],
          restarted: ['typescript-language-server'],
          unchanged: [],
          failed: [],
        });
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        getHandles: () => new Map([['typescript-language-server', handle]]),
      };
      const internals = service as unknown as {
        openedDocuments: Map<string, Set<string>>;
      };
      internals.openedDocuments.set(
        'typescript-language-server',
        new Set([uri]),
      );

      await service.reinitialize();
      expect(
        internals.openedDocuments.get('typescript-language-server'),
      ).toEqual(new Set([uri]));

      const reinitialize = service.reinitialize();
      await vi.runAllTimersAsync();
      await reinitialize;

      expect(connection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
          params: {
            textDocument: expect.objectContaining({
              uri,
              languageId: 'typescript',
              text: 'const value = 1;\n',
            }),
          },
        }),
      );
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize serializes the full snapshot reconcile and replay flow', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-queue-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      let resolveFirstReconcile: (
        value: Awaited<ReturnType<typeof reconcileServerConfigs>>,
      ) => void;
      const firstReconcile = new Promise<{
        added: string[];
        removed: string[];
        restarted: string[];
        unchanged: string[];
        failed: string[];
      }>((resolve) => {
        resolveFirstReconcile = resolve;
      });
      const reconcileServerConfigs = vi
        .fn()
        .mockReturnValueOnce(firstReconcile)
        .mockResolvedValueOnce({
          added: [],
          removed: [],
          restarted: [],
          unchanged: ['typescript-language-server'],
          failed: [],
        });
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      const first = service.reinitialize();
      await vi.waitFor(() => {
        expect(reconcileServerConfigs).toHaveBeenCalledOnce();
      });
      const second = service.reinitialize();
      await Promise.resolve();

      expect(reconcileServerConfigs).toHaveBeenCalledOnce();

      resolveFirstReconcile!({
        added: ['typescript-language-server'],
        removed: [],
        restarted: [],
        unchanged: [],
        failed: [],
      });
      await first;
      await vi.waitFor(() => {
        expect(reconcileServerConfigs).toHaveBeenCalledTimes(2);
      });
      await second;
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize snapshots documents opened while reconcile is pending', async () => {
    vi.useFakeTimers();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-snapshot-'));
    try {
      const filePath = path.join(tempDir, 'index.ts');
      const uri = pathToFileURL(filePath).toString();
      fs.writeFileSync(filePath, 'const value = 1;\n', 'utf-8');
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const connection = {
        listen: vi.fn(),
        send: vi.fn(),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const handle = {
        config: {
          name: 'typescript-language-server',
          languages: ['typescript'],
          command: 'typescript-language-server',
          args: [],
          transport: 'stdio',
        },
        status: 'READY',
        connection,
      };
      let resolveReconcile: (
        value: Awaited<ReturnType<typeof reconcileServerConfigs>>,
      ) => void;
      const reconcilePromise = new Promise<{
        added: string[];
        removed: string[];
        restarted: string[];
        unchanged: string[];
        failed: string[];
      }>((resolve) => {
        resolveReconcile = resolve;
      });
      const reconcileServerConfigs = vi.fn(() => reconcilePromise);
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        getHandles: () => new Map([['typescript-language-server', handle]]),
      };
      const internals = service as unknown as {
        openedDocuments: Map<string, Set<string>>;
      };

      const reinitialize = service.reinitialize();
      await vi.waitFor(() => {
        expect(reconcileServerConfigs).toHaveBeenCalledOnce();
      });
      internals.openedDocuments.set(
        'typescript-language-server',
        new Set([uri]),
      );
      resolveReconcile!({
        added: [],
        removed: [],
        restarted: ['typescript-language-server'],
        unchanged: [],
        failed: [],
      });
      await vi.runAllTimersAsync();
      await reinitialize;

      expect(connection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
          params: {
            textDocument: expect.objectContaining({
              uri,
              languageId: 'typescript',
              text: 'const value = 1;\n',
            }),
          },
        }),
      );
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('stop cancels an in-flight reinitialize replay delay', async () => {
    vi.useFakeTimers();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-stop-'));
    try {
      const filePath = path.join(tempDir, 'index.ts');
      const uri = pathToFileURL(filePath).toString();
      fs.writeFileSync(filePath, 'const value = 1;\n', 'utf-8');
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      const connection = {
        listen: vi.fn(),
        send: vi.fn(),
        onNotification: vi.fn(),
        onRequest: vi.fn(),
        request: vi.fn(),
        initialize: vi.fn(),
        shutdown: vi.fn(),
        end: vi.fn(),
      };
      const handle = {
        config: {
          name: 'typescript-language-server',
          languages: ['typescript'],
          command: 'typescript-language-server',
          args: [],
          transport: 'stdio',
        },
        status: 'READY',
        connection,
      };
      const stopAll = vi.fn(async () => {});
      const reconcileServerConfigs = vi.fn(async () => ({
        added: [],
        removed: [],
        restarted: ['typescript-language-server'],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        getHandles: () => new Map([['typescript-language-server', handle]]),
        stopAll,
      };
      const internals = service as unknown as {
        openedDocuments: Map<string, Set<string>>;
        lastConnections: Map<string, unknown>;
      };
      internals.openedDocuments.set(
        'typescript-language-server',
        new Set([uri]),
      );
      internals.lastConnections.set('typescript-language-server', connection);

      const reinitialize = service.reinitialize();
      await vi.waitFor(() => {
        expect(connection.send).toHaveBeenCalledOnce();
      });
      await service.stop();

      await expect(reinitialize).rejects.toThrow('LSP reinitialize cancelled');
      expect(stopAll).toHaveBeenCalledOnce();
      expect(vi.getTimerCount()).toBe(0);
      expect(internals.openedDocuments.size).toBe(0);
      expect(internals.lastConnections.size).toBe(0);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('stop cancels queued reinitialize calls before they start', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-stop-queue-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          typescript: {
            command: 'typescript-language-server',
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { workspaceRoot: tempDir },
      );
      let resolveFirstReconcile: (
        value: Awaited<ReturnType<typeof reconcileServerConfigs>>,
      ) => void;
      const firstReconcile = new Promise<{
        added: string[];
        removed: string[];
        restarted: string[];
        unchanged: string[];
        failed: string[];
      }>((resolve) => {
        resolveFirstReconcile = resolve;
      });
      const reconcileServerConfigs = vi.fn(() => firstReconcile);
      const stopAll = vi.fn(async () => {});
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
        stopAll,
      };

      const first = service.reinitialize();
      await vi.waitFor(() => {
        expect(reconcileServerConfigs).toHaveBeenCalledOnce();
      });
      const second = service.reinitialize();
      await service.stop();

      resolveFirstReconcile!({
        added: ['typescript-language-server'],
        removed: [],
        restarted: [],
        unchanged: [],
        failed: [],
      });

      await expect(first).rejects.toThrow('LSP reinitialize cancelled');
      await expect(second).rejects.toThrow('LSP reinitialize cancelled');
      expect(reconcileServerConfigs).toHaveBeenCalledOnce();
      expect(stopAll).toHaveBeenCalledOnce();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('reinitialize stops all servers when trusted workspace is required but unavailable', async () => {
    const tempConfig = new MockConfig();
    vi.spyOn(tempConfig, 'isTrustedFolder').mockReturnValue(false);
    const service = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      mockWorkspace as unknown as WorkspaceContext,
      eventEmitter,
      mockFileDiscovery as unknown as FileDiscoveryService,
      mockIdeStore as unknown as IdeContextStore,
      { requireTrustedWorkspace: true },
    );
    const stopAll = vi.fn(async () => {});
    const internals = service as unknown as {
      serverManager: unknown;
      openedDocuments: Map<string, Set<string>>;
      lastConnections: Map<string, unknown>;
    };
    internals.serverManager = {
      getHandles: () => new Map([['tsserver', {}]]),
      stopAll,
    };
    internals.openedDocuments.set('tsserver', new Set(['file:///a.ts']));
    internals.lastConnections.set('tsserver', {});

    const result = await service.reinitialize();

    expect(stopAll).toHaveBeenCalledOnce();
    expect(result.reconcile.removed).toEqual(['tsserver']);
    expect(internals.openedDocuments.has('tsserver')).toBe(false);
    expect(internals.lastConnections.has('tsserver')).toBe(false);
  });

  test('reinitialize skips all user-configured servers in untrusted workspaces', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-untrusted-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          trusted: {
            command: 'trusted-language-server',
            languages: ['typescript'],
            trustRequired: true,
          },
          untrusted: {
            command: 'untrusted-language-server',
            languages: ['javascript'],
            trustRequired: false,
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      vi.spyOn(tempConfig, 'isTrustedFolder').mockReturnValue(false);
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { requireTrustedWorkspace: false, workspaceRoot: tempDir },
      );
      const reconcileServerConfigs = vi.fn(async () => ({
        added: [],
        removed: [],
        restarted: [],
        unchanged: [],
        failed: [],
      }));
      (service as unknown as { serverManager: unknown }).serverManager = {
        reconcileServerConfigs,
      };

      const result = await service.reinitialize();

      expect(reconcileServerConfigs).toHaveBeenCalledWith([]);
      expect(result.skipped).toEqual([
        {
          name: 'trusted-language-server',
          reason: 'server_trust_required',
        },
        {
          name: 'untrusted-language-server',
          reason: 'server_trust_required',
        },
      ]);
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('discoverAndPrepare skips trust-required servers in untrusted workspaces', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-discover-'));
    try {
      fs.writeFileSync(
        path.join(tempDir, '.lsp.json'),
        JSON.stringify({
          trusted: {
            command: 'trusted-language-server',
            languages: ['typescript'],
            trustRequired: true,
          },
          untrusted: {
            command: 'untrusted-language-server',
            languages: ['javascript'],
            trustRequired: false,
          },
        }),
      );
      const tempConfig = new MockConfig();
      tempConfig.rootPath = tempDir;
      vi.spyOn(tempConfig, 'isTrustedFolder').mockReturnValue(false);
      const service = new NativeLspService(
        tempConfig as unknown as CoreConfig,
        mockWorkspace as unknown as WorkspaceContext,
        eventEmitter,
        mockFileDiscovery as unknown as FileDiscoveryService,
        mockIdeStore as unknown as IdeContextStore,
        { requireTrustedWorkspace: false, workspaceRoot: tempDir },
      );

      await service.discoverAndPrepare();

      const handles = Array.from(
        (
          service as unknown as {
            serverManager: { getHandles: () => Map<string, unknown> };
          }
        ).serverManager
          .getHandles()
          .keys(),
      );
      expect(handles).toEqual([]);
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('stop clears document tracking caches', async () => {
    const stopAll = vi.fn(async () => {});
    const internals = lspService as unknown as {
      serverManager: { stopAll: () => Promise<void> };
      openedDocuments: Map<string, Set<string>>;
      lastConnections: Map<string, unknown>;
    };
    internals.serverManager = { stopAll };
    internals.openedDocuments.set('tsserver', new Set(['file:///a.ts']));
    internals.lastConnections.set('tsserver', {});

    await lspService.stop();

    expect(stopAll).toHaveBeenCalledOnce();
    expect(internals.openedDocuments.size).toBe(0);
    expect(internals.lastConnections.size).toBe(0);
  });

  test('should expose a detailed status snapshot for configured servers', () => {
    const serverManager = {
      getHandles: () =>
        new Map([
          [
            'clangd',
            {
              config: {
                name: 'clangd',
                languages: ['c', 'cpp'],
                command: 'clangd',
                args: ['--background-index'],
                transport: 'stdio',
                rootUri: 'file:///test/workspace',
                workspaceFolder: '/test/workspace',
              },
              status: 'READY',
              process: { pid: 12345 },
              warmedUp: true,
              restartAttempts: 1,
              processDiagnostics: {
                stderrTail: 'clangd: unknown argument\n',
                exitCode: 7,
                exitSignal: null,
              },
            },
          ],
          [
            'pyright',
            {
              config: {
                name: 'pyright',
                languages: ['python'],
                command: 'pyright-langserver',
                args: ['--stdio'],
                transport: 'stdio',
                rootUri: 'file:///test/workspace',
                workspaceFolder: '/test/workspace',
              },
              status: 'FAILED',
              error: new Error('startup failed'),
            },
          ],
        ]),
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    const snapshot = lspService.getStatusSnapshot();

    expect(snapshot).toEqual({
      enabled: true,
      configuredServers: 2,
      readyServers: 1,
      failedServers: 1,
      inProgressServers: 0,
      notStartedServers: 0,
      servers: [
        {
          name: 'clangd',
          status: 'READY',
          languages: ['c', 'cpp'],
          transport: 'stdio',
          command: 'clangd',
          args: ['--background-index'],
          rootUri: 'file:///test/workspace',
          workspaceFolder: '/test/workspace',
          pid: 12345,
          warmedUp: true,
          restartAttempts: 1,
          stderrTail: 'clangd: unknown argument\n',
          exitCode: 7,
          exitSignal: null,
        },
        {
          name: 'pyright',
          status: 'FAILED',
          languages: ['python'],
          transport: 'stdio',
          command: 'pyright-langserver',
          args: ['--stdio'],
          rootUri: 'file:///test/workspace',
          workspaceFolder: '/test/workspace',
          error: 'startup failed',
        },
      ],
    });
  });

  test('should open document before hover requests', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-test-'));
    const filePath = path.join(tempDir, 'main.cpp');
    fs.writeFileSync(filePath, 'int main(){return 0;}\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    const events: string[] = [];
    const connection = {
      listen: vi.fn(),
      send: vi.fn((message: { method?: string }) => {
        events.push(`send:${message.method ?? 'unknown'}`);
      }),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        events.push(`request:${method}`);
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise1 = lspService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise1;

      expect(connection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
          params: {
            textDocument: expect.objectContaining({
              uri,
              languageId: 'cpp',
            }),
          },
        }),
      );
      expect(connection.request).toHaveBeenCalledWith(
        'textDocument/hover',
        expect.any(Object),
      );
      expect(events[0]).toBe('send:textDocument/didOpen');

      const promise2 = lspService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise2;

      expect(connection.send).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should open a workspace file before workspace symbol search', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-symbol-'));
    const workspaceFile = path.join(tempDir, 'src', 'main.cpp');
    fs.mkdirSync(path.dirname(workspaceFile), { recursive: true });
    fs.writeFileSync(workspaceFile, 'int main(){return 0;}\n', 'utf-8');
    const workspaceUri = pathToFileURL(workspaceFile).toString();

    const events: string[] = [];
    let opened = false;
    const connection = {
      listen: vi.fn(),
      send: vi.fn((message: { method?: string }) => {
        events.push(`send:${message.method ?? 'unknown'}`);
        if (message.method === 'textDocument/didOpen') {
          opened = true;
        }
      }),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        events.push(`request:${method}`);
        if (method === 'workspace/symbol') {
          return opened
            ? [
                {
                  name: 'Calculator',
                  kind: 5,
                  location: {
                    uri: workspaceUri,
                    range: {
                      start: { line: 0, character: 0 },
                      end: { line: 0, character: 10 },
                    },
                  },
                },
              ]
            : [];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => false,
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;
    const tempDiscovery = new MockFileDiscoveryService();
    const tempIdeStore = new MockIdeContextStore();
    const tempEmitter = new EventEmitter();

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      tempEmitter,
      tempDiscovery as unknown as FileDiscoveryService,
      tempIdeStore as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = tempService.workspaceSymbols('Calculator');
      await vi.runAllTimersAsync();
      const results = await promise;

      expect(connection.send).toHaveBeenCalledWith(
        expect.objectContaining({
          method: 'textDocument/didOpen',
        }),
      );
      expect(events[0]).toBe('send:textDocument/didOpen');
      expect(results.length).toBe(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should retry workspace symbols after warmup when initial result is empty', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-symbol-retry-'));
    const workspaceFile = path.join(tempDir, 'src', 'main.cpp');
    fs.mkdirSync(path.dirname(workspaceFile), { recursive: true });
    fs.writeFileSync(workspaceFile, 'int main(){return 0;}\n', 'utf-8');
    const workspaceUri = pathToFileURL(workspaceFile).toString();

    const events: string[] = [];
    let opened = false;
    let symbolCalls = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn((message: { method?: string }) => {
        events.push(`send:${message.method ?? 'unknown'}`);
        if (message.method === 'textDocument/didOpen') {
          opened = true;
        }
      }),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        events.push(`request:${method}`);
        if (method === 'workspace/symbol') {
          symbolCalls += 1;
          if (!opened) {
            return [];
          }
          if (symbolCalls === 1) {
            return [];
          }
          return [
            {
              name: 'Calculator',
              kind: 5,
              location: {
                uri: workspaceUri,
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 0, character: 10 },
                },
              },
            },
          ];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => false,
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;
    const tempDiscovery = new MockFileDiscoveryService();
    const tempIdeStore = new MockIdeContextStore();
    const tempEmitter = new EventEmitter();

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      tempEmitter,
      tempDiscovery as unknown as FileDiscoveryService,
      tempIdeStore as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = tempService.workspaceSymbols('Calculator');
      await vi.runAllTimersAsync();
      const results = await promise;

      expect(symbolCalls).toBe(2);
      expect(results.length).toBe(1);
      expect(events[0]).toBe('send:textDocument/didOpen');
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should not retry workspace symbols when no warmup file is available', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-symbol-empty-'));

    let symbolCalls = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        if (method === 'workspace/symbol') {
          symbolCalls += 1;
          return [];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => false,
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;
    const tempDiscovery = new MockFileDiscoveryService();
    const tempIdeStore = new MockIdeContextStore();
    const tempEmitter = new EventEmitter();

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      tempEmitter,
      tempDiscovery as unknown as FileDiscoveryService,
      tempIdeStore as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = tempService.workspaceSymbols('Calculator');
      await vi.runAllTimersAsync();
      await promise;

      expect(symbolCalls).toBe(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should reopen documents after connection changes', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-reopen-'));
    const filePath = path.join(tempDir, 'main.cpp');
    fs.writeFileSync(filePath, 'int main(){return 0;}\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    const connection1 = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async () => null),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };
    const connection2 = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async () => null),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection: connection1,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;
    const tempDiscovery = new MockFileDiscoveryService();
    const tempIdeStore = new MockIdeContextStore();
    const tempEmitter = new EventEmitter();

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      tempEmitter,
      tempDiscovery as unknown as FileDiscoveryService,
      tempIdeStore as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise1 = tempService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise1;

      expect(connection1.send).toHaveBeenCalledWith(
        expect.objectContaining({ method: 'textDocument/didOpen' }),
      );

      handle.connection = connection2;

      const promise2 = tempService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise2;

      expect(connection2.send).toHaveBeenCalledWith(
        expect.objectContaining({ method: 'textDocument/didOpen' }),
      );
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });
  test('should delay after fresh document open then send request', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-delay-'));
    const filePath = path.join(tempDir, 'main.cpp');
    fs.writeFileSync(filePath, 'int main(){return 0;}\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    const timeline: Array<{ event: string; time: number }> = [];
    const connection = {
      listen: vi.fn(),
      send: vi.fn((message: { method?: string }) => {
        if (message.method === 'textDocument/didOpen') {
          timeline.push({ event: 'didOpen', time: Date.now() });
        }
      }),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        if (method === 'textDocument/definition') {
          timeline.push({ event: 'definition', time: Date.now() });
          return [
            {
              uri,
              range: {
                start: { line: 0, character: 4 },
                end: { line: 0, character: 8 },
              },
            },
          ];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = lspService.definitions({
        uri,
        range: {
          start: { line: 0, character: 4 },
          end: { line: 0, character: 4 },
        },
      });
      await vi.runAllTimersAsync();
      const results = await promise;

      // Verify didOpen fires before the definition request
      expect(timeline.length).toBe(2);
      expect(timeline[0]!.event).toBe('didOpen');
      expect(timeline[1]!.event).toBe('definition');
      // The delay should have elapsed between the two events (200ms)
      expect(timeline[1]!.time - timeline[0]!.time).toBeGreaterThanOrEqual(200);
      expect(results.length).toBe(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should skip delay when document is already open', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-nodelay-'));
    const filePath = path.join(tempDir, 'main.cpp');
    fs.writeFileSync(filePath, 'int main(){return 0;}\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    let didOpenCount = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn((message: { method?: string }) => {
        if (message.method === 'textDocument/didOpen') {
          didOpenCount += 1;
        }
      }),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async () => null),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'clangd',
        languages: ['cpp'],
        command: 'clangd',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['clangd', handle]]),
      warmupTypescriptServer: vi.fn(),
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      // First hover opens the document
      const promise1 = lspService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise1;
      expect(didOpenCount).toBe(1);

      // Second hover should not re-open or delay
      const startTime = Date.now();
      const promise2 = lspService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise2;
      const elapsed = Date.now() - startTime;

      expect(didOpenCount).toBe(1);
      // No delay should have been triggered (well under 200ms with fake timers)
      expect(elapsed).toBeLessThan(200);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should not send duplicate didOpen for warmup-opened URI on subsequent requests', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-warmup-track-'));
    const queryFilePath = path.join(tempDir, 'main.cpp');
    const warmupFilePath = path.join(tempDir, 'index.ts');
    fs.writeFileSync(queryFilePath, 'int main(){return 0;}\n', 'utf-8');
    fs.writeFileSync(warmupFilePath, 'export const x = 1;\n', 'utf-8');
    const queryUri = pathToFileURL(queryFilePath).toString();
    const warmupUri = pathToFileURL(warmupFilePath).toString();

    const didOpenUris: string[] = [];
    const connection = {
      listen: vi.fn(),
      send: vi.fn(
        (message: {
          method?: string;
          params?: { textDocument?: { uri?: string } };
        }) => {
          if (message.method === 'textDocument/didOpen') {
            didOpenUris.push(message.params?.textDocument?.uri ?? '');
          }
        },
      ),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async () => null),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'typescript',
        languages: ['typescript'],
        command: 'typescript-language-server',
        args: ['--stdio'],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    // First call: warmup returns warmupUri (different from queryUri)
    const serverManager = {
      getHandles: () => new Map([['typescript', handle]]),
      warmupTypescriptServer: vi.fn(async () => warmupUri),
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      // First request: opens queryUri via ensureDocumentOpen, warmup returns warmupUri
      const promise1 = lspService.hover({
        uri: queryUri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise1;

      // queryUri should have been opened via ensureDocumentOpen
      expect(didOpenUris).toContain(queryUri);
      const countAfterFirst = didOpenUris.length;

      // Second request: for warmupUri which was already tracked from warmup
      const promise2 = lspService.hover({
        uri: warmupUri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise2;

      // warmupUri should NOT have been opened again via ensureDocumentOpen
      // because it was tracked from the warmup in the first call
      expect(didOpenUris.length).toBe(countAfterFirst);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should retry document operations for slow servers after fresh didOpen', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-retry-doc-'));
    const filePath = path.join(tempDir, 'Main.java');
    fs.writeFileSync(filePath, 'public class Main { }\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    let requestCount = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        if (method === 'textDocument/documentSymbol') {
          requestCount += 1;
          // First call returns empty (server still indexing), second returns data
          if (requestCount === 1) {
            return [];
          }
          return [
            {
              name: 'Main',
              kind: 5,
              range: {
                start: { line: 0, character: 0 },
                end: { line: 0, character: 21 },
              },
              selectionRange: {
                start: { line: 0, character: 13 },
                end: { line: 0, character: 17 },
              },
            },
          ];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'jdtls',
        languages: ['java'],
        command: 'jdtls',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['jdtls', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => false,
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      new EventEmitter(),
      new MockFileDiscoveryService() as unknown as FileDiscoveryService,
      new MockIdeContextStore() as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = tempService.documentSymbols(uri);
      await vi.runAllTimersAsync();
      const results = await promise;

      // Should have retried: 2 requests total
      expect(requestCount).toBe(2);
      expect(results.length).toBe(1);
      expect(results[0]?.name).toBe('Main');
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should NOT retry document operations for TypeScript servers', async () => {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-no-retry-ts-'));
    const filePath = path.join(tempDir, 'index.ts');
    fs.writeFileSync(filePath, 'export const x = 1;\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    let requestCount = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        if (method === 'textDocument/documentSymbol') {
          requestCount += 1;
          return [];
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'typescript-language-server',
        languages: ['typescript'],
        command: 'typescript-language-server',
        args: ['--stdio'],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['typescript', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => true,
    };

    (lspService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      const promise = lspService.documentSymbols(uri);
      await vi.runAllTimersAsync();
      await promise;

      // Should NOT have retried: only 1 request
      expect(requestCount).toBe(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  test('should NOT retry when document was already open', async () => {
    const tempDir = fs.mkdtempSync(
      path.join(os.tmpdir(), 'lsp-no-retry-open-'),
    );
    const filePath = path.join(tempDir, 'Main.java');
    fs.writeFileSync(filePath, 'public class Main { }\n', 'utf-8');
    const uri = pathToFileURL(filePath).toString();

    let requestCount = 0;
    const connection = {
      listen: vi.fn(),
      send: vi.fn(),
      onNotification: vi.fn(),
      onRequest: vi.fn(),
      request: vi.fn(async (method: string) => {
        if (
          method === 'textDocument/hover' ||
          method === 'textDocument/documentSymbol'
        ) {
          requestCount += 1;
          return null;
        }
        return null;
      }),
      initialize: vi.fn(async () => ({})),
      shutdown: vi.fn(async () => {}),
      end: vi.fn(),
    };

    const handle = {
      config: {
        name: 'jdtls',
        languages: ['java'],
        command: 'jdtls',
        args: [],
        transport: 'stdio',
      },
      status: 'READY',
      connection,
    };

    const serverManager = {
      getHandles: () => new Map([['jdtls', handle]]),
      warmupTypescriptServer: vi.fn(),
      isTypescriptServer: () => false,
    };

    const tempConfig = new MockConfig();
    tempConfig.rootPath = tempDir;
    const tempWorkspace = new MockWorkspaceContext();
    tempWorkspace.rootPath = tempDir;

    const tempService = new NativeLspService(
      tempConfig as unknown as CoreConfig,
      tempWorkspace as unknown as WorkspaceContext,
      new EventEmitter(),
      new MockFileDiscoveryService() as unknown as FileDiscoveryService,
      new MockIdeContextStore() as unknown as IdeContextStore,
      { workspaceRoot: tempDir },
    );

    (tempService as unknown as { serverManager: unknown }).serverManager =
      serverManager;

    vi.useFakeTimers();
    try {
      // First call opens the document (retry is allowed on this call)
      const promise1 = tempService.hover({
        uri,
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
      });
      await vi.runAllTimersAsync();
      await promise1;

      requestCount = 0;

      // Second call - document already open, should NOT retry even though empty
      const promise2 = tempService.documentSymbols(uri);
      await vi.runAllTimersAsync();
      await promise2;

      expect(requestCount).toBe(1);
    } finally {
      vi.useRealTimers();
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  });

  // PR #4333 review fold-in: cover the two error branches added in
  // applyTextEdits — only-ENOENT read guard and the W_OK access check.
  // The branches are reached via the private applyTextEdits, accessed
  // through a typed cast since making them public-for-test would inflate
  // the API surface for one verification.
  describe('applyTextEdits — error branches', () => {
    let tmpDir: string;

    beforeEach(() => {
      tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lsp-edits-error-'));
      // Override the workspace mock so any path inside tmpDir is in-scope.
      (
        mockWorkspace as unknown as {
          isPathWithinWorkspace: (p: string) => boolean;
        }
      ).isPathWithinWorkspace = (p: string) => p.startsWith(tmpDir);
    });

    afterEach(() => {
      try {
        // Restore perms before rm so cleanup can traverse 0o000 / 0o444 files.
        for (const f of fs.readdirSync(tmpDir)) {
          try {
            fs.chmodSync(path.join(tmpDir, f), 0o644);
          } catch {
            /* ignore */
          }
        }
      } catch {
        /* ignore */
      }
      fs.rmSync(tmpDir, { recursive: true, force: true });
    });

    test.skipIf(process.platform === 'win32' || process.getuid?.() === 0)(
      'read failure on chmod 0000 file propagates EACCES (does not silently become empty content)',
      async () => {
        const filePath = path.join(tmpDir, 'unreadable.txt');
        fs.writeFileSync(filePath, 'original content');
        fs.chmodSync(filePath, 0o000);

        const uri = pathToFileURL(filePath).toString();
        const edit = {
          range: {
            start: { line: 0, character: 0 },
            end: { line: 0, character: 0 },
          },
          newText: 'INJECTED ',
        };
        const applyTextEdits = (
          lspService as unknown as {
            applyTextEdits: (
              uri: string,
              edits: Array<typeof edit>,
            ) => Promise<void>;
          }
        ).applyTextEdits.bind(lspService);

        let caught: NodeJS.ErrnoException | undefined;
        try {
          await applyTextEdits(uri, [edit]);
        } catch (err) {
          caught = err as NodeJS.ErrnoException;
        }
        expect(caught?.code).toBe('EACCES');

        // File is unchanged — read fail should NOT have triggered the
        // pre-fix "treat as empty, overwrite with edits" path.
        fs.chmodSync(filePath, 0o644);
        expect(fs.readFileSync(filePath, 'utf-8')).toBe('original content');
      },
    );

    test.skipIf(process.platform === 'win32' || process.getuid?.() === 0)(
      'chmod 0444 read-only file is rejected before write (W_OK check)',
      async () => {
        const filePath = path.join(tmpDir, 'readonly.txt');
        fs.writeFileSync(filePath, 'do not modify me');
        fs.chmodSync(filePath, 0o444);

        const uri = pathToFileURL(filePath).toString();
        const edit = {
          range: {
            start: { line: 0, character: 0 },
            end: { line: 0, character: 0 },
          },
          newText: 'BAD ',
        };
        const applyTextEdits = (
          lspService as unknown as {
            applyTextEdits: (
              uri: string,
              edits: Array<typeof edit>,
            ) => Promise<void>;
          }
        ).applyTextEdits.bind(lspService);

        let caught: NodeJS.ErrnoException | undefined;
        try {
          await applyTextEdits(uri, [edit]);
        } catch (err) {
          caught = err as NodeJS.ErrnoException;
        }
        expect(caught?.code).toMatch(/^E(ACCES|PERM)$/);

        // Original content untouched — atomic rename did NOT bypass perms.
        fs.chmodSync(filePath, 0o644);
        expect(fs.readFileSync(filePath, 'utf-8')).toBe('do not modify me');
      },
    );

    test('nonexistent file is accepted (LSP can create via edits)', async () => {
      const filePath = path.join(tmpDir, 'new-file.txt');
      const uri = pathToFileURL(filePath).toString();
      const edit = {
        range: {
          start: { line: 0, character: 0 },
          end: { line: 0, character: 0 },
        },
        newText: 'created via edit',
      };
      const applyTextEdits = (
        lspService as unknown as {
          applyTextEdits: (
            uri: string,
            edits: Array<typeof edit>,
          ) => Promise<void>;
        }
      ).applyTextEdits.bind(lspService);

      await applyTextEdits(uri, [edit]);
      expect(fs.existsSync(filePath)).toBe(true);
      expect(fs.readFileSync(filePath, 'utf-8')).toBe('created via edit');
    });
  });
});
