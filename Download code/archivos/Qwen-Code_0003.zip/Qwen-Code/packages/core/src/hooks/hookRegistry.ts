/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */

import type { HookDefinition, HookConfig } from './types.js';
import {
  HookEventName,
  HooksConfigSource,
  HOOKS_CONFIG_FIELDS,
} from './types.js';
import { createDebugLogger } from '../utils/debugLogger.js';

const debugLogger = createDebugLogger('HOOK_REGISTRY');

/**
 * Extension with hooks support
 */
export interface ExtensionWithHooks {
  isActive: boolean;
  hooks?: { [K in HookEventName]?: HookDefinition[] };
}

/**
 * Configuration interface for HookRegistry
 * This abstracts the Config dependency to make the registry more flexible
 */
export interface HookRegistryConfig {
  getProjectRoot(): string;
  isTrustedFolder(): boolean;
  getUserHooks(): { [K in HookEventName]?: HookDefinition[] } | undefined;
  getProjectHooks(): { [K in HookEventName]?: HookDefinition[] } | undefined;
  getExtensions(): ExtensionWithHooks[];
}

/**
 * Feedback emitter interface for warning/info messages
 */
export interface FeedbackEmitter {
  emitFeedback(type: 'warning' | 'info' | 'error', message: string): void;
}

/**
 * Hook registry entry with source information
 */
export interface HookRegistryEntry {
  config: HookConfig;
  source: HooksConfigSource;
  eventName: HookEventName;
  matcher?: string;
  sequential?: boolean;
  enabled: boolean;
  /**
   * Identifier for ephemeral entries attached at runtime by a specific
   * subagent (via {@link HookRegistry.addAgentHooks}). Used by the matching
   * unregister callback to remove the entries when the subagent ends. Plain
   * (session/user/project/extension) entries leave this undefined.
   */
  agentScope?: string;
}

/**
 * Hook registry that loads and validates hook definitions from multiple sources
 */
export class HookRegistry {
  private readonly config: HookRegistryConfig;
  private readonly feedbackEmitter?: FeedbackEmitter;
  private entries: HookRegistryEntry[] = [];

  constructor(config: HookRegistryConfig, feedbackEmitter?: FeedbackEmitter) {
    this.config = config;
    this.feedbackEmitter = feedbackEmitter;
  }

  /**
   * Initialize the registry by processing hooks from config
   */
  async initialize(): Promise<void> {
    this.entries = [];
    this.processHooksFromConfig();

    debugLogger.debug(
      `Hook registry initialized with ${this.entries.length} hook entries`,
    );
  }

  async reloadConfiguredHooks(): Promise<void> {
    const previousEntries = this.entries;
    const enabledSnapshot = new Map(
      previousEntries.map((entry) => [
        this.getHookStateKey(entry),
        entry.enabled,
      ]),
    );
    const agentEntries = this.entries.filter(
      (entry) => entry.agentScope !== undefined,
    );

    try {
      this.entries = [...agentEntries];
      this.processHooksFromConfig();
      for (const entry of this.entries) {
        const enabled = enabledSnapshot.get(this.getHookStateKey(entry));
        if (enabled !== undefined) {
          entry.enabled = enabled;
        }
      }
    } catch (err) {
      this.entries = previousEntries;
      throw err;
    }

    debugLogger.debug(
      `Hook registry reloaded with ${this.entries.length} hook entries`,
    );
  }

  /**
   * Get all hook entries for a specific event
   */
  getHooksForEvent(eventName: HookEventName): HookRegistryEntry[] {
    return this.entries
      .filter((entry) => entry.eventName === eventName && entry.enabled)
      .sort(
        (a, b) =>
          this.getSourcePriority(a.source) - this.getSourcePriority(b.source),
      );
  }

  /**
   * Get all registered hooks
   */
  getAllHooks(): HookRegistryEntry[] {
    return [...this.entries];
  }

  /**
   * Append ephemeral hook entries scoped to a specific subagent. Used by
   * `SubagentManager` to wire the `hooks` field from a declarative agent
   * frontmatter into the live registry when the subagent spawns.
   *
   * The hooks are validated through the same per-definition pipeline as
   * session/user/project hooks (`processHookDefinition`), so a malformed
   * entry is logged and dropped instead of breaking the spawn. Returns an
   * unregister callback that removes exactly the entries added by this call;
   * the caller is responsible for invoking it when the subagent finishes.
   *
   * v1 scope limitation: entries added here fire for every event of their
   * declared type while they remain in the registry, regardless of which
   * agent is currently active. If two subagents with different per-agent
   * hook sets run concurrently, both sets fire for both agents. Proper
   * per-agent scope filtering at firing time is left to a follow-up.
   */
  addAgentHooks(
    hooks: { [K in HookEventName]?: HookDefinition[] },
    agentScope: string,
  ): () => void {
    const before = this.entries.length;
    this.processHooksConfiguration(
      hooks,
      HooksConfigSource.Session,
      agentScope,
    );
    const addedCount = this.entries.length - before;
    debugLogger.debug(
      `Registered ${addedCount} ephemeral hook entries for agent scope "${agentScope}"`,
    );
    return () => {
      const sizeBefore = this.entries.length;
      this.entries = this.entries.filter(
        (entry) => entry.agentScope !== agentScope,
      );
      const removed = sizeBefore - this.entries.length;
      if (removed > 0) {
        debugLogger.debug(
          `Removed ${removed} ephemeral hook entries for agent scope "${agentScope}"`,
        );
      }
    };
  }

  /**
   * Enable or disable a specific hook
   */
  setHookEnabled(hookName: string, enabled: boolean): void {
    const updated = this.entries.filter((entry) => {
      const name = this.getHookName(entry);
      if (name === hookName) {
        entry.enabled = enabled;
        return true;
      }
      return false;
    });

    if (updated.length > 0) {
      debugLogger.info(
        `${enabled ? 'Enabled' : 'Disabled'} ${updated.length} hook(s) matching "${hookName}"`,
      );
    } else {
      debugLogger.warn(`No hooks found matching "${hookName}"`);
    }
  }

  /**
   * Get a stable unique identity for duplicate detection.
   * Uses full values (not truncated) to ensure accurate duplicate detection.
   */
  private getHookIdentity(
    entry: HookRegistryEntry | { config: HookConfig },
  ): string {
    const config = entry.config;
    if (config.name) return config.name;
    if (config.type === 'command')
      return (config as { command?: string }).command || 'unknown-command';
    if (config.type === 'http')
      return (config as { url?: string }).url || 'unknown-url';
    if (config.type === 'function')
      return (config as { id?: string }).id || 'unknown-function';
    if (config.type === 'prompt')
      return (config as { prompt?: string }).prompt || 'prompt-hook';
    return 'unknown-hook';
  }

  /**
   * Get hook name for display purposes (may be truncated for readability).
   */
  private getHookName(
    entry: HookRegistryEntry | { config: HookConfig },
  ): string {
    const identity = this.getHookIdentity(entry);
    // Truncate prompt identities for display
    const config = entry.config;
    if (!config.name && config.type === 'prompt') {
      return identity.length > 30 ? identity.slice(0, 30) + '...' : identity;
    }
    return identity;
  }

  private getHookStateKey(entry: HookRegistryEntry): string {
    return JSON.stringify([
      entry.eventName,
      entry.source,
      entry.agentScope ?? null,
      this.getHookIdentity(entry),
      entry.matcher ?? null,
      entry.sequential ?? null,
    ]);
  }

  /**
   * Process hooks from the config that was already loaded by the CLI
   */
  private processHooksFromConfig(): void {
    // Load user hooks (always available, regardless of folder trust)
    const userHooks = this.config.getUserHooks();
    if (userHooks) {
      this.processHooksConfiguration(userHooks, HooksConfigSource.User);
    }

    // Load project hooks (only in trusted folders)
    // The config.getProjectHooks() already checks trust status internally
    const projectHooks = this.config.getProjectHooks();
    if (projectHooks) {
      this.processHooksConfiguration(projectHooks, HooksConfigSource.Project);
    }

    // Extension hooks are always loaded
    const extensions = this.config.getExtensions() || [];
    for (const extension of extensions) {
      if (extension.isActive && extension.hooks) {
        this.processHooksConfiguration(
          extension.hooks,
          HooksConfigSource.Extensions,
        );
      }
    }
  }

  /**
   * Process hooks configuration and add entries
   */
  private processHooksConfiguration(
    hooksConfig: { [K in HookEventName]?: HookDefinition[] },
    source: HooksConfigSource,
    agentScope?: string,
  ): void {
    for (const [eventName, definitions] of Object.entries(hooksConfig)) {
      if (HOOKS_CONFIG_FIELDS.includes(eventName)) {
        continue;
      }

      if (!this.isValidEventName(eventName)) {
        this.feedbackEmitter?.emitFeedback(
          'warning',
          `Invalid hook event name: "${eventName}" from ${source} config. Skipping.`,
        );
        continue;
      }

      const typedEventName = eventName;

      if (!Array.isArray(definitions)) {
        debugLogger.warn(
          `Hook definitions for event "${eventName}" from source "${source}" is not an array. Skipping.`,
        );
        continue;
      }

      for (const definition of definitions) {
        this.processHookDefinition(
          definition,
          typedEventName,
          source,
          agentScope,
        );
      }
    }
  }

  /**
   * Process a single hook definition
   */
  private processHookDefinition(
    definition: HookDefinition,
    eventName: HookEventName,
    source: HooksConfigSource,
    agentScope?: string,
  ): void {
    if (
      !definition ||
      typeof definition !== 'object' ||
      !Array.isArray(definition.hooks)
    ) {
      debugLogger.warn(
        `Discarding invalid hook definition for ${eventName} from ${source}:`,
        definition,
      );
      return;
    }

    for (const hookConfig of definition.hooks) {
      if (
        hookConfig &&
        typeof hookConfig === 'object' &&
        this.validateHookConfig(hookConfig, eventName, source)
      ) {
        const hookIdentity = this.getHookIdentity({ config: hookConfig });
        const hookName = this.getHookName({ config: hookConfig });

        // Check for duplicate hooks. `agentScope` participates in the key so
        // a per-agent hook does not get swallowed when an identical
        // session/user/project hook already exists, and so two concurrent
        // subagents declaring the same hook each keep their own copy.
        const isDuplicate = this.entries.some(
          (existing) =>
            existing.eventName === eventName &&
            existing.source === source &&
            existing.agentScope === agentScope &&
            this.getHookIdentity(existing) === hookIdentity &&
            existing.matcher === definition.matcher &&
            existing.sequential === definition.sequential,
        );
        if (isDuplicate) {
          debugLogger.debug(
            `Skipping duplicate hook "${hookName}" for ${eventName} from ${source}`,
          );
          continue;
        }

        // Add source to hook config (only for command and http hooks)
        if (hookConfig.type !== 'function') {
          (hookConfig as { source?: HooksConfigSource }).source = source;
        }

        this.entries.push({
          config: hookConfig,
          source,
          eventName,
          matcher: definition.matcher,
          sequential: definition.sequential,
          enabled: true,
          ...(agentScope !== undefined ? { agentScope } : {}),
        });
      } else {
        // Invalid hooks are logged and discarded here, they won't reach HookRunner
        debugLogger.warn(
          `Discarding invalid hook configuration for ${eventName} from ${source}:`,
          hookConfig,
        );
      }
    }
  }

  /**
   * Validate a hook configuration
   */
  private validateHookConfig(
    config: HookConfig,
    eventName: HookEventName,
    source: HooksConfigSource,
  ): boolean {
    if (
      !config.type ||
      !['command', 'http', 'function', 'prompt'].includes(config.type)
    ) {
      debugLogger.warn(
        `Invalid hook ${eventName} from ${source} type: ${config.type}`,
      );
      return false;
    }

    if (config.type === 'command' && !config.command) {
      debugLogger.warn(
        `Command hook ${eventName} from ${source} missing command field`,
      );
      return false;
    }

    if (config.type === 'http' && !config.url) {
      debugLogger.warn(
        `HTTP hook ${eventName} from ${source} missing url field`,
      );
      return false;
    }

    if (config.type === 'function' && typeof config.callback !== 'function') {
      debugLogger.warn(
        `Function hook ${eventName} from ${source} missing or invalid callback`,
      );
      return false;
    }

    if (config.type === 'prompt' && !config.prompt) {
      debugLogger.warn(
        `Prompt hook ${eventName} from ${source} missing prompt field`,
      );
      return false;
    }

    return true;
  }

  /**
   * Check if an event name is valid
   */
  private isValidEventName(eventName: string): eventName is HookEventName {
    const validEventNames: string[] = Object.values(HookEventName);
    return validEventNames.includes(eventName);
  }

  /**
   * Get source priority (lower number = higher priority)
   */
  private getSourcePriority(source: HooksConfigSource): number {
    switch (source) {
      case HooksConfigSource.Project:
        return 1;
      case HooksConfigSource.User:
        return 2;
      case HooksConfigSource.System:
        return 3;
      case HooksConfigSource.Extensions:
        return 4;
      default:
        return 999;
    }
  }
}
