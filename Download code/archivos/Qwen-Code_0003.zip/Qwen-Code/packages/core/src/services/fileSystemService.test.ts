/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'node:fs/promises';
import {
  StandardFileSystemService,
  needsUtf8Bom,
  resetUtf8BomCache,
  detectLineEnding,
  ensureCrlfLineEndings,
} from './fileSystemService.js';
import { encodeTextFileContent } from './sync-file-encoding.js';

const mockPlatform = vi.hoisted(() => vi.fn().mockReturnValue('linux'));
const mockGetSystemEncoding = vi.hoisted(() =>
  vi.fn().mockReturnValue('utf-8'),
);

vi.mock('fs/promises');
vi.mock('os', () => ({
  default: {
    platform: mockPlatform,
  },
  platform: mockPlatform,
}));
vi.mock('../utils/systemEncoding.js', () => ({
  getSystemEncoding: mockGetSystemEncoding,
}));

vi.mock('../utils/atomicFileWrite.js', () => ({
  atomicWriteFile: vi.fn(
    async (
      filePath: string,
      data: string | Buffer,
      options?: { encoding?: BufferEncoding },
    ) => {
      const fsMock = await import('fs/promises');
      if (typeof data === 'string' && options?.encoding) {
        await fsMock.default.writeFile(filePath, data, options.encoding);
      } else {
        await fsMock.default.writeFile(filePath, data);
      }
    },
  ),
}));

vi.mock('../utils/fileUtils.js', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../utils/fileUtils.js')>();
  return {
    ...actual,
    readFileWithLineAndLimit: vi.fn(),
  };
});

import { readFileWithLineAndLimit } from '../utils/fileUtils.js';

describe('StandardFileSystemService', () => {
  let fileSystem: StandardFileSystemService;

  beforeEach(() => {
    vi.resetAllMocks();
    resetUtf8BomCache();
    mockPlatform.mockReturnValue('linux');
    mockGetSystemEncoding.mockReturnValue('utf-8');
    fileSystem = new StandardFileSystemService();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('readTextFile', () => {
    it('should read file content and return ReadTextFileResponse', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'Hello, World!',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 1,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      const result = await fileSystem.readTextFile({ path: '/test/file.txt' });

      expect(readFileWithLineAndLimit).toHaveBeenCalledWith({
        path: '/test/file.txt',
        limit: Infinity,
      });
      expect(result.content).toBe('Hello, World!');
      expect(result._meta?.bom).toBe(false);
      expect(result._meta?.encoding).toBe('utf-8');
    });

    it('should pass limit and line params to readFileWithLineAndLimit', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'line 5',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 100,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      const result = await fileSystem.readTextFile({
        path: '/test/file.txt',
        limit: 10,
        line: 5,
      });

      expect(readFileWithLineAndLimit).toHaveBeenCalledWith({
        path: '/test/file.txt',
        limit: 10,
        line: 5,
      });
      expect(result._meta?.originalLineCount).toBe(100);
    });

    it('should preserve explicit line zero for offset reads', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'line 1',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 100,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      await fileSystem.readTextFile({
        path: '/test/file.txt',
        line: 0,
      });

      expect(readFileWithLineAndLimit).toHaveBeenCalledWith({
        path: '/test/file.txt',
        limit: Infinity,
        line: 0,
      });
    });

    it('should pass maxOutputBytes and return byte-truncation metadata', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'partial',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 100,
        originalLineCountExact: true,
        truncatedByBytes: true,
      });

      const result = await fileSystem.readTextFile({
        path: '/test/file.txt',
        limit: 10,
        line: 5,
        maxOutputBytes: 128,
      });

      expect(readFileWithLineAndLimit).toHaveBeenCalledWith({
        path: '/test/file.txt',
        limit: 10,
        line: 5,
        maxOutputBytes: 128,
      });
      expect(result._meta?.truncatedByBytes).toBe(true);
    });

    it('should pass cached stats to readFileWithLineAndLimit', async () => {
      const stats = { size: 123 } as import('node:fs').Stats;
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'line 1',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 1,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      await fileSystem.readTextFile({
        path: '/test/file.txt',
        maxOutputBytes: 128,
        stats,
      });

      expect(readFileWithLineAndLimit).toHaveBeenCalledWith({
        path: '/test/file.txt',
        limit: Infinity,
        maxOutputBytes: 128,
        stats,
      });
    });

    // Handle-bound reads no longer route through `readFileWithLineAndLimit`,
    // so asserting the arguments it was called with would test nothing. The
    // behaviour is covered against real files in `read-text-range.test.ts`
    // and at the real boundary in `workspace-file-system.test.ts`; only the
    // argument validation below needs a unit test, and it needs no mock.
    it.each([
      ['maxOutputBytes', { maxOutputBytes: Number.POSITIVE_INFINITY }],
      ['maxScanBytes', { maxScanBytes: Number.POSITIVE_INFINITY }],
      ['maxOutputBytes', { maxOutputBytes: 0 }],
      ['maxScanBytes', { maxScanBytes: -1 }],
    ])('should reject a handle read with unbounded %s', async (bound, over) => {
      const fileHandle = {} as import('node:fs/promises').FileHandle;

      await expect(
        fileSystem.readTextFileFromHandle({
          fileHandle,
          fileSize: 300_000,
          limit: 20,
          maxOutputBytes: 262_144,
          maxScanBytes: 8 * 1024 * 1024,
          ...over,
        }),
      ).rejects.toThrow(new RegExp(`positive finite ${bound}`));
    });

    it.each([
      ['a fractional limit', 2.5],
      ['a zero limit', 0],
      ['a negative limit', -1],
    ])('should reject %s on a handle read', async (_label, limit) => {
      const fileHandle = {} as import('node:fs/promises').FileHandle;

      await expect(
        fileSystem.readTextFileFromHandle({
          fileHandle,
          fileSize: 300_000,
          limit,
          maxOutputBytes: 262_144,
          maxScanBytes: 8 * 1024 * 1024,
        }),
      ).rejects.toThrow(/positive integer limit or Infinity/);
    });

    it.each([
      ['fileSize', { fileSize: -1 }],
      ['fileSize', { fileSize: 1.5 }],
      ['line', { line: -1 }],
      ['line', { line: 1.5 }],
    ])('should reject invalid handle-bound %s', async (field, over) => {
      const fileHandle = {} as import('node:fs/promises').FileHandle;

      await expect(
        fileSystem.readTextFileFromHandle({
          fileHandle,
          fileSize: 300_000,
          limit: 1,
          maxOutputBytes: 262_144,
          maxScanBytes: 8 * 1024 * 1024,
          ...over,
        }),
      ).rejects.toThrow(new RegExp(field));
    });

    it.each([
      ['maxOutputBytes', { maxOutputBytes: Number.POSITIVE_INFINITY }],
      ['maxOutputBytes', { maxOutputBytes: 0 }],
      ['maxSnapBytes', { maxSnapBytes: Number.POSITIVE_INFINITY }],
      ['maxSnapBytes', { maxSnapBytes: 0 }],
    ])('should reject invalid cursor-bound %s', async (bound, over) => {
      const fileHandle = {} as import('node:fs/promises').FileHandle;

      await expect(
        fileSystem.readTextCursorFromHandle({
          fileHandle,
          startOffset: 0,
          fileSize: 300_000,
          limit: 20,
          maxOutputBytes: 262_144,
          maxSnapBytes: 8 * 1024 * 1024,
          ...over,
        }),
      ).rejects.toThrow(new RegExp(`positive finite ${bound}`));
    });

    it.each([
      ['startOffset', { startOffset: -1 }],
      ['startOffset', { startOffset: 1.5 }],
      ['fileSize', { fileSize: -1 }],
      ['fileSize', { fileSize: 1.5 }],
    ])('should reject invalid cursor-bound %s', async (field, over) => {
      const fileHandle = {} as import('node:fs/promises').FileHandle;

      await expect(
        fileSystem.readTextCursorFromHandle({
          fileHandle,
          startOffset: 0,
          fileSize: 300_000,
          limit: 20,
          maxOutputBytes: 262_144,
          maxSnapBytes: 8 * 1024 * 1024,
          ...over,
        }),
      ).rejects.toThrow(new RegExp(field));
    });

    it.each([2.5, 0, -1])(
      'should reject invalid cursor-bound limit %s',
      async (limit) => {
        const fileHandle = {} as import('node:fs/promises').FileHandle;

        await expect(
          fileSystem.readTextCursorFromHandle({
            fileHandle,
            startOffset: 0,
            fileSize: 300_000,
            limit,
            maxOutputBytes: 262_144,
            maxSnapBytes: 8 * 1024 * 1024,
          }),
        ).rejects.toThrow(/positive integer limit/);
      },
    );

    it('should return encoding info for GBK file', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: '你好世界',
        bom: false,
        encoding: 'gb18030',
        originalLineCount: 1,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      const result = await fileSystem.readTextFile({ path: '/test/gbk.txt' });

      expect(result.content).toBe('你好世界');
      expect(result._meta?.encoding).toBe('gb18030');
      expect(result._meta?.bom).toBe(false);
    });

    it('should propagate readFileWithLineAndLimit errors', async () => {
      const error = new Error('ENOENT: File not found');
      vi.mocked(readFileWithLineAndLimit).mockRejectedValue(error);

      await expect(
        fileSystem.readTextFile({ path: '/test/file.txt' }),
      ).rejects.toThrow('ENOENT: File not found');
    });
  });

  describe('writeTextFile', () => {
    it('encodeTextFileContent returns final bytes for UTF-8 and CRLF metadata', () => {
      const encoded = encodeTextFileContent('/test/file.txt', 'a\nb\n', {
        lineEnding: 'crlf',
      });
      expect(encoded.toString('utf8')).toBe('a\r\nb\r\n');
    });

    it('encodeTextFileContent preserves UTF-8 BOM in returned bytes', () => {
      const encoded = encodeTextFileContent('/test/file.txt', 'Hello', {
        bom: true,
      });
      expect(Array.from(encoded.subarray(0, 3))).toEqual([0xef, 0xbb, 0xbf]);
      expect(encoded.subarray(3).toString('utf8')).toBe('Hello');
    });

    it('should write file content using fs', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello, World!',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'Hello, World!',
        'utf-8',
      );
    });

    it('should write file with BOM when bom option is true', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello, World!',
        _meta: { bom: true },
      });

      // Verify that fs.writeFile was called with a Buffer that starts with BOM
      const writeCall = vi.mocked(fs.writeFile).mock.calls[0];
      expect(writeCall[0]).toBe('/test/file.txt');
      expect(writeCall[1]).toBeInstanceOf(Buffer);
      const buffer = writeCall[1] as Buffer;
      expect(buffer[0]).toBe(0xef);
      expect(buffer[1]).toBe(0xbb);
      expect(buffer[2]).toBe(0xbf);
    });

    it('should write file without BOM when bom option is false', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello, World!',
        _meta: { bom: false },
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'Hello, World!',
        'utf-8',
      );
    });

    it('should not duplicate BOM when content already has BOM character', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      // Content that includes the BOM character (as readTextFile would return)
      const contentWithBOM = '\uFEFF' + 'Hello';
      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: contentWithBOM,
        _meta: { bom: true },
      });

      // Verify that fs.writeFile was called with a Buffer that has only one BOM
      const writeCall = vi.mocked(fs.writeFile).mock.calls[0];
      expect(writeCall[0]).toBe('/test/file.txt');
      expect(writeCall[1]).toBeInstanceOf(Buffer);
      const buffer = writeCall[1] as Buffer;
      // First three bytes should be BOM
      expect(buffer[0]).toBe(0xef);
      expect(buffer[1]).toBe(0xbb);
      expect(buffer[2]).toBe(0xbf);
      // Fourth byte should be 'H' (0x48), not another BOM
      expect(buffer[3]).toBe(0x48);
      // Count BOM sequences in the buffer - should be only one
      let bomCount = 0;
      for (let i = 0; i <= buffer.length - 3; i++) {
        if (
          buffer[i] === 0xef &&
          buffer[i + 1] === 0xbb &&
          buffer[i + 2] === 0xbf
        ) {
          bomCount++;
        }
      }
      expect(bomCount).toBe(1);
    });

    it('should write file with non-UTF-8 encoding using iconv-lite', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: '你好世界',
        _meta: { encoding: 'gbk' },
      });

      // Verify that fs.writeFile was called with a Buffer (iconv-encoded)
      const writeCall = vi.mocked(fs.writeFile).mock.calls[0];
      expect(writeCall[0]).toBe('/test/file.txt');
      expect(writeCall[1]).toBeInstanceOf(Buffer);
    });

    it('should write file as UTF-8 when encoding is utf-8', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello',
        _meta: { encoding: 'utf-8' },
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'Hello',
        'utf-8',
      );
    });

    it('should preserve UTF-16LE BOM when writing back a UTF-16LE file', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello',
        _meta: { encoding: 'utf-16le', bom: true },
      });

      // iconv-lite encodes as UTF-16LE; with bom:true the FF FE BOM is prepended
      const writeCall = vi.mocked(fs.writeFile).mock.calls[0];
      expect(writeCall[0]).toBe('/test/file.txt');
      expect(writeCall[1]).toBeInstanceOf(Buffer);
      const buf = writeCall[1] as Buffer;
      // First two bytes must be the UTF-16LE BOM: FF FE
      expect(buf[0]).toBe(0xff);
      expect(buf[1]).toBe(0xfe);
    });

    it('should not add BOM when writing UTF-16LE file without bom flag', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'Hello',
        _meta: { encoding: 'utf-16le', bom: false },
      });

      // No BOM prepended — raw iconv-encoded buffer written directly
      const writeCall = vi.mocked(fs.writeFile).mock.calls[0];
      expect(writeCall[0]).toBe('/test/file.txt');
      expect(writeCall[1]).toBeInstanceOf(Buffer);
      const buf = writeCall[1] as Buffer;
      // First two bytes should NOT be FF FE (the UTF-16LE BOM)
      expect(!(buf[0] === 0xff && buf[1] === 0xfe)).toBe(true);
    });

    it('should convert LF to CRLF when writing .bat files on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.bat',
        content: '@echo off\necho hello\nexit /b 0\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.bat',
        '@echo off\r\necho hello\r\nexit /b 0\r\n',
        'utf-8',
      );
    });

    it('should convert LF to CRLF when writing .cmd files on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.cmd',
        content: '@echo off\necho hello\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.cmd',
        '@echo off\r\necho hello\r\n',
        'utf-8',
      );
    });

    it('should not double-convert existing CRLF in .bat files on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.bat',
        content: '@echo off\r\necho hello\r\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.bat',
        '@echo off\r\necho hello\r\n',
        'utf-8',
      );
    });

    it('should handle mixed line endings in .bat files on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.bat',
        content: 'line1\r\nline2\nline3\r\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.bat',
        'line1\r\nline2\r\nline3\r\n',
        'utf-8',
      );
    });

    it('should be case-insensitive for .BAT extension on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/SCRIPT.BAT',
        content: 'echo hello\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/SCRIPT.BAT',
        'echo hello\r\n',
        'utf-8',
      );
    });

    it('should not convert line endings for non-.bat/.cmd files on Windows', async () => {
      mockPlatform.mockReturnValue('win32');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.sh',
        content: '#!/bin/bash\necho hello\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.sh',
        '#!/bin/bash\necho hello\n',
        'utf-8',
      );
    });

    it('should not convert line endings for .bat files on non-Windows', async () => {
      mockPlatform.mockReturnValue('darwin');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/script.bat',
        content: '@echo off\necho hello\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/script.bat',
        '@echo off\necho hello\n',
        'utf-8',
      );
    });
  });

  describe('needsUtf8Bom', () => {
    beforeEach(() => {
      resetUtf8BomCache();
    });

    it('should return true for .ps1 files on Windows with non-UTF-8 code page', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue('gbk');

      expect(needsUtf8Bom('/test/script.ps1')).toBe(true);
    });

    it('should return true for .PS1 files (case-insensitive)', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue('gbk');

      expect(needsUtf8Bom('/test/SCRIPT.PS1')).toBe(true);
    });

    it('should return false for .ps1 files on Windows with UTF-8 code page', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue('utf-8');

      expect(needsUtf8Bom('/test/script.ps1')).toBe(false);
    });

    it('should return false for .ps1 files on non-Windows', () => {
      mockPlatform.mockReturnValue('darwin');

      expect(needsUtf8Bom('/test/script.ps1')).toBe(false);
    });

    it('should return false for non-.ps1 files on Windows with non-UTF-8 code page', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue('gbk');

      expect(needsUtf8Bom('/test/script.sh')).toBe(false);
      expect(needsUtf8Bom('/test/file.txt')).toBe(false);
      expect(needsUtf8Bom('/test/script.bat')).toBe(false);
    });

    it('should cache the platform/encoding check across calls', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue('gbk');

      needsUtf8Bom('/test/script.ps1');
      needsUtf8Bom('/test/other.ps1');

      // getSystemEncoding should only be called once due to caching
      expect(mockGetSystemEncoding).toHaveBeenCalledTimes(1);
    });

    it('should treat null system encoding as non-UTF-8', () => {
      mockPlatform.mockReturnValue('win32');
      mockGetSystemEncoding.mockReturnValue(null);

      expect(needsUtf8Bom('/test/script.ps1')).toBe(true);
    });
  });

  describe('detectLineEnding', () => {
    it('should detect CRLF line endings', () => {
      expect(detectLineEnding('line1\r\nline2\r\n')).toBe('crlf');
    });

    it('should detect LF line endings', () => {
      expect(detectLineEnding('line1\nline2\n')).toBe('lf');
    });

    it('should return lf for content with no line endings', () => {
      expect(detectLineEnding('single line')).toBe('lf');
    });

    it('should return lf for empty content', () => {
      expect(detectLineEnding('')).toBe('lf');
    });

    it('should detect CRLF even in mixed content', () => {
      expect(detectLineEnding('line1\r\nline2\nline3')).toBe('crlf');
    });
  });

  describe('ensureCrlfLineEndings', () => {
    it('should convert LF to CRLF', () => {
      expect(ensureCrlfLineEndings('line1\nline2\n')).toBe(
        'line1\r\nline2\r\n',
      );
    });

    it('should not double-convert existing CRLF', () => {
      expect(ensureCrlfLineEndings('line1\r\nline2\r\n')).toBe(
        'line1\r\nline2\r\n',
      );
    });

    it('should handle mixed line endings', () => {
      expect(ensureCrlfLineEndings('line1\r\nline2\nline3\r\n')).toBe(
        'line1\r\nline2\r\nline3\r\n',
      );
    });

    it('should handle content with no line endings', () => {
      expect(ensureCrlfLineEndings('single line')).toBe('single line');
    });
  });

  describe('writeTextFile with lineEnding preservation', () => {
    it('should convert LF to CRLF when lineEnding is crlf', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'line1\nline2\n',
        _meta: { lineEnding: 'crlf' },
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'line1\r\nline2\r\n',
        'utf-8',
      );
    });

    it('should not convert line endings when lineEnding is lf', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'line1\nline2\n',
        _meta: { lineEnding: 'lf' },
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'line1\nline2\n',
        'utf-8',
      );
    });

    it('should not convert line endings when lineEnding is not specified', async () => {
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.txt',
        content: 'line1\nline2\n',
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.txt',
        'line1\nline2\n',
        'utf-8',
      );
    });

    it('should preserve CRLF for non-bat files on non-Windows when lineEnding is crlf', async () => {
      mockPlatform.mockReturnValue('linux');
      vi.mocked(fs.writeFile).mockResolvedValue();

      await fileSystem.writeTextFile({
        path: '/test/file.cs',
        content: 'using System;\nclass Foo {}\n',
        _meta: { lineEnding: 'crlf' },
      });

      expect(fs.writeFile).toHaveBeenCalledWith(
        '/test/file.cs',
        'using System;\r\nclass Foo {}\r\n',
        'utf-8',
      );
    });
  });

  describe('readTextFile with lineEnding detection', () => {
    it('should detect CRLF line ending in file content', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'line1\r\nline2\r\n',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 3,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      const result = await fileSystem.readTextFile({ path: '/test/file.txt' });

      expect(result._meta?.lineEnding).toBe('crlf');
    });

    it('should detect LF line ending in file content', async () => {
      vi.mocked(readFileWithLineAndLimit).mockResolvedValue({
        content: 'line1\nline2\n',
        bom: false,
        encoding: 'utf-8',
        originalLineCount: 3,
        originalLineCountExact: true,
        truncatedByBytes: false,
      });

      const result = await fileSystem.readTextFile({ path: '/test/file.txt' });

      expect(result._meta?.lineEnding).toBe('lf');
    });
  });
});
