/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Tests for the #4437 fix:
 *  - `write_file` to an existing path inside the project skills root is
 *    denied (was 'allow' before — silently clobbered the prior SKILL.md).
 *  - `edit` semantics for existing auto-skills are preserved.
 *  - `buildTaskPrompt` enumerates existing skill directory names so the
 *    agent picks a fresh name on the first attempt.
 */

import * as fs from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Config } from '../config/config.js';
import type { PermissionManager } from '../permissions/permission-manager.js';
import {
  AUTO_SKILL_DIR_PREFIX,
  buildTaskPrompt,
  createSkillScopedAgentConfig,
  DEFAULT_AUTO_SKILL_MAX_TURNS,
  DEFAULT_AUTO_SKILL_TIMEOUT_MS,
  listExistingSkillDirNames,
  runSkillReviewByAgent,
  SKILL_REVIEW_SYSTEM_PROMPT,
} from './skillReviewAgentPlanner.js';
import { ToolNames } from '../tools/tool-names.js';
import { runForkedAgent } from '../agents/forkedAgent.js';

vi.mock('../agents/forkedAgent.js', () => ({
  runForkedAgent: vi.fn(),
}));

function makeMinimalConfig(projectRoot: string): Config {
  return {
    getProjectRoot: () => projectRoot,
    getPermissionManager: () => undefined,
  } as unknown as Config;
}

/**
 * Build the scoped Config and return its non-null PermissionManager.
 * `createSkillScopedAgentConfig` always installs one, but Config's
 * declared `getPermissionManager(): PermissionManager | null` forces
 * tests to launder the null at the call site — this helper does it
 * once with an assertion that fires loudly if the contract ever breaks.
 */
function scopedPm(projectRoot: string) {
  const scoped = createSkillScopedAgentConfig(
    makeMinimalConfig(projectRoot),
    projectRoot,
  );
  const pm = scoped.getPermissionManager();
  if (!pm) {
    throw new Error(
      'createSkillScopedAgentConfig must install a PermissionManager',
    );
  }
  return pm;
}

async function writeSkillFile(
  projectRoot: string,
  skillName: string,
  content: string,
): Promise<string> {
  const dir = path.join(projectRoot, '.qwen', 'skills', skillName);
  await fs.mkdir(dir, { recursive: true });
  const filePath = path.join(dir, 'SKILL.md');
  await fs.writeFile(filePath, content, 'utf-8');
  return filePath;
}

const AUTO_SKILL = `---
name: my-skill
source: auto-skill
---

body
`;

const USER_SKILL = `---
name: my-skill
description: hand-authored
---

human body
`;

describe('skillReviewAgentPlanner — write_file collision deny (#4437)', () => {
  let tempDir: string;
  let projectRoot: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'skill-review-v2-'));
    projectRoot = path.join(tempDir, 'project');
    await fs.mkdir(projectRoot, { recursive: true });
  });

  afterEach(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
  });

  it("denies write_file to an existing AUTO-skill path (the #4437 bug — was 'allow')", async () => {
    const filePath = await writeSkillFile(projectRoot, 'my-skill', AUTO_SKILL);
    const pm = scopedPm(projectRoot);

    const decision = await pm.evaluate({
      toolName: ToolNames.WRITE_FILE,
      filePath,
    });
    expect(decision).toBe('deny');
  });

  it('denies write_file to an existing USER-skill path (already worked — kept as regression guard)', async () => {
    const filePath = await writeSkillFile(projectRoot, 'my-skill', USER_SKILL);
    const pm = scopedPm(projectRoot);

    const decision = await pm.evaluate({
      toolName: ToolNames.WRITE_FILE,
      filePath,
    });
    expect(decision).toBe('deny');
  });

  it('allows write_file to a fresh path that does not yet exist', async () => {
    const fresh = path.join(
      projectRoot,
      '.qwen',
      'skills',
      'brand-new',
      'SKILL.md',
    );
    const pm = scopedPm(projectRoot);

    const decision = await pm.evaluate({
      toolName: ToolNames.WRITE_FILE,
      filePath: fresh,
    });
    expect(decision).toBe('allow');
  });

  it('denies write_file when the directory name is already archived', async () => {
    const directoryName = 'auto-skill-retired';
    await fs.mkdir(
      path.join(projectRoot, '.qwen', 'archived-skills', directoryName),
      { recursive: true },
    );
    const target = path.join(
      projectRoot,
      '.qwen',
      'skills',
      directoryName,
      'SKILL.md',
    );

    expect(
      await scopedPm(projectRoot).evaluate({
        toolName: ToolNames.WRITE_FILE,
        filePath: target,
      }),
    ).toBe('deny');
  });

  it('denies edit creation when the directory name is already archived', async () => {
    const directoryName = 'auto-skill-retired';
    await fs.mkdir(
      path.join(projectRoot, '.qwen', 'archived-skills', directoryName),
      { recursive: true },
    );
    const target = path.join(
      projectRoot,
      '.qwen',
      'skills',
      directoryName,
      'SKILL.md',
    );

    expect(
      await scopedPm(projectRoot).evaluate({
        toolName: ToolNames.EDIT,
        filePath: target,
      }),
    ).toBe('deny');
  });

  it('still allows edit on an existing auto-skill (update path preserved)', async () => {
    const filePath = await writeSkillFile(projectRoot, 'my-skill', AUTO_SKILL);
    const pm = scopedPm(projectRoot);

    const decision = await pm.evaluate({
      toolName: ToolNames.EDIT,
      filePath,
    });
    expect(decision).toBe('allow');
  });

  it('still denies edit on a user skill (update path safety preserved)', async () => {
    const filePath = await writeSkillFile(projectRoot, 'my-skill', USER_SKILL);
    const pm = scopedPm(projectRoot);

    const decision = await pm.evaluate({
      toolName: ToolNames.EDIT,
      filePath,
    });
    expect(decision).toBe('deny');
  });

  it('write_file deny rule message points the agent at a fresh name', async () => {
    const filePath = await writeSkillFile(projectRoot, 'my-skill', AUTO_SKILL);
    const pm = scopedPm(projectRoot);

    const rule = pm.findMatchingDenyRule({
      toolName: ToolNames.WRITE_FILE,
      filePath,
    });
    expect(rule).toMatch(/<name>-2/);
    expect(rule).toMatch(/edit/);
  });

  it('denies write_file to a path outside the project skills root', async () => {
    // Security-boundary regression guard for the `isProjectSkillPath`
    // false branch — without it the agent could escape to anywhere
    // reachable from CWD.
    const escape = path.join(projectRoot, 'NOT-SKILLS', 'evil.md');
    const pm = scopedPm(projectRoot);
    expect(
      await pm.evaluate({
        toolName: ToolNames.WRITE_FILE,
        filePath: escape,
      }),
    ).toBe('deny');
  });

  it('denies write_file to a non-SKILL.md path inside the skills root', async () => {
    // Auxiliary files (NOTES.md, attachments) must not land in the
    // skills dir — SkillManager would ignore them but they'd still
    // pollute the layout. Tightening the basename invariant is the
    // hard guard for that.
    const aux = path.join(
      projectRoot,
      '.qwen',
      'skills',
      'my-skill',
      'NOTES.md',
    );
    await fs.mkdir(path.dirname(aux), { recursive: true });
    const pm = scopedPm(projectRoot);
    expect(
      await pm.evaluate({
        toolName: ToolNames.WRITE_FILE,
        filePath: aux,
      }),
    ).toBe('deny');
  });

  it('denies write_file when the target traverses a symlink outside the skills root', async () => {
    // Symlink-escape regression guard for the `assertRealProjectSkillPath`
    // catch. A skill dir that's actually a symlink to /tmp would let the
    // agent write outside the project; the realpath check stops it.
    const outside = path.join(tempDir, 'outside');
    await fs.mkdir(outside, { recursive: true });
    const skillsRoot = path.join(projectRoot, '.qwen', 'skills');
    await fs.mkdir(skillsRoot, { recursive: true });
    await fs.symlink(outside, path.join(skillsRoot, 'escape'));
    const target = path.join(skillsRoot, 'escape', 'SKILL.md');
    const pm = scopedPm(projectRoot);
    expect(
      await pm.evaluate({
        toolName: ToolNames.WRITE_FILE,
        filePath: target,
      }),
    ).toBe('deny');
  });

  it('denies write_file when the target path is a directory, not a file', async () => {
    // `fs.stat` on a directory SUCCEEDS (returning stats with
    // `isDirectory: true`); it does not throw EISDIR. So this exercise
    // path A in evaluateScopedDecision — `try { await fs.stat(); return
    // 'deny'; }` — i.e. "target exists" rather than the non-ENOENT
    // catch. WriteFileTool would later fail with EISDIR on the actual
    // write, but the permission layer catches it earlier here.
    const dirAsFile = path.join(
      projectRoot,
      '.qwen',
      'skills',
      'is-a-directory',
      'SKILL.md',
    );
    await fs.mkdir(dirAsFile, { recursive: true });
    const pm = scopedPm(projectRoot);
    expect(
      await pm.evaluate({
        toolName: ToolNames.WRITE_FILE,
        filePath: dirAsFile,
      }),
    ).toBe('deny');
  });

  // Note on coverage of the `fs.stat` catch branch in
  // evaluateScopedDecision:
  // The branch is defense-in-depth — anything that would make `fs.stat`
  // throw a non-ENOENT error (EACCES, ELOOP, ENAMETOOLONG, EIO) also
  // throws from `assertRealProjectSkillPath`'s `realpath`/`lstat` one
  // step earlier, which is exercised by the symlink-traversal test
  // above. Spying on `fs.stat` from ESM tests is blocked
  // (https://vitest.dev/guide/browser/#limitations), and chmod-based
  // reproductions of EACCES are non-portable to Windows CI. The deny
  // contract is straightforward enough that the structural duplication
  // here is acceptable.
});

describe('listExistingSkillDirNames', () => {
  let tempDir: string;
  let projectRoot: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'skill-list-'));
    projectRoot = path.join(tempDir, 'project');
    await fs.mkdir(projectRoot, { recursive: true });
  });

  afterEach(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
  });

  it('returns sorted directory names that contain a SKILL.md', async () => {
    await writeSkillFile(projectRoot, 'zebra', AUTO_SKILL);
    await writeSkillFile(projectRoot, 'apple', AUTO_SKILL);
    expect(await listExistingSkillDirNames(projectRoot)).toEqual([
      'apple',
      'zebra',
    ]);
  });

  it('does not treat archive-only directory names as live skills', async () => {
    const archived = path.join(
      projectRoot,
      '.qwen',
      'archived-skills',
      'auto-skill-retired',
    );
    await fs.mkdir(archived, { recursive: true });
    await writeSkillFile(projectRoot, 'auto-skill-live', AUTO_SKILL);

    expect(await listExistingSkillDirNames(projectRoot)).toEqual([
      'auto-skill-live',
    ]);
  });

  it('skips directories without SKILL.md so half-built dirs do not reserve names', async () => {
    await writeSkillFile(projectRoot, 'real', AUTO_SKILL);
    await fs.mkdir(path.join(projectRoot, '.qwen', 'skills', 'empty'), {
      recursive: true,
    });
    expect(await listExistingSkillDirNames(projectRoot)).toEqual(['real']);
  });

  it('returns [] when the skills directory does not exist', async () => {
    expect(await listExistingSkillDirNames(projectRoot)).toEqual([]);
  });

  it('includes skills whose directory is a symlink (matches skill-load.ts convention)', async () => {
    // Build a real skill outside the skills root, then symlink it in.
    // `skill-load.ts:31-34` and `skill-manager.ts:994-997` both treat
    // `isDirectory() || isSymbolicLink()` as a skill candidate; the
    // enumeration here mirrors that.
    const external = path.join(tempDir, 'external-skills', 'linked');
    await fs.mkdir(external, { recursive: true });
    await fs.writeFile(path.join(external, 'SKILL.md'), AUTO_SKILL, 'utf-8');
    const skillsRoot = path.join(projectRoot, '.qwen', 'skills');
    await fs.mkdir(skillsRoot, { recursive: true });
    await fs.symlink(external, path.join(skillsRoot, 'linked'));
    await writeSkillFile(projectRoot, 'regular', AUTO_SKILL);
    expect(await listExistingSkillDirNames(projectRoot)).toEqual([
      'linked',
      'regular',
    ]);
  });
});

describe('buildTaskPrompt', () => {
  let tempDir: string;
  let projectRoot: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'skill-prompt-'));
    projectRoot = path.join(tempDir, 'project');
    await fs.mkdir(projectRoot, { recursive: true });
  });

  afterEach(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
  });

  it('lists existing skill names so the agent picks a non-colliding name', async () => {
    await writeSkillFile(projectRoot, 'alpha', AUTO_SKILL);
    await writeSkillFile(projectRoot, 'beta', AUTO_SKILL);
    const prompt = await buildTaskPrompt(projectRoot);
    expect(prompt).toContain('alpha');
    expect(prompt).toContain('beta');
    expect(prompt).toMatch(/Active skill directory names/i);
    // The inspection guidance must only reference tools in this run's filter
    // (read_file/write_file/edit) — not `ls`/list_directory, which is opt-in.
    expect(prompt).toContain(
      'Use `read_file` to inspect the existing skill files listed above',
    );
    expect(prompt).not.toContain('Use `ls`');
  });

  it('lists archived directory names as reserved', async () => {
    const directoryName = 'auto-skill-retired';
    await fs.mkdir(
      path.join(projectRoot, '.qwen', 'archived-skills', directoryName),
      { recursive: true },
    );

    expect(await buildTaskPrompt(projectRoot)).toContain(directoryName);
  });

  it.skipIf(process.platform === 'win32')(
    'excludes archived directory names carrying control bytes from the prompt',
    async () => {
      // Mirrors the curator's charset guard: a crafted archived directory name
      // with ANSI/control bytes must not reach the task prompt verbatim.
      const directoryName = 'auto-skill-evil\u001b[31m';
      await fs.mkdir(
        path.join(projectRoot, '.qwen', 'archived-skills', directoryName),
        { recursive: true },
      );

      const prompt = await buildTaskPrompt(projectRoot);
      expect(prompt).not.toContain('\u001b[31m');
    },
  );

  it('falls back to a placeholder line when no skills exist yet', async () => {
    const prompt = await buildTaskPrompt(projectRoot);
    expect(prompt).toMatch(/no skills exist yet/i);
  });

  it('displays the project skills root derived from the same projectRoot used for enumeration', async () => {
    // Regression guard for the param collapse — the displayed root and
    // the enumerated names always come from the same source.
    await writeSkillFile(projectRoot, 'real', AUTO_SKILL);
    const prompt = await buildTaskPrompt(projectRoot);
    expect(prompt).toContain(path.join(projectRoot, '.qwen', 'skills'));
    expect(prompt).toContain('real');
  });

  it('instructs the agent to use the auto-skill- directory prefix (#4837)', async () => {
    // The `.gitignore` re-ignores `.qwen/skills/auto-skill-*/`, so new
    // auto-generated skills must land under an `auto-skill-`-prefixed
    // directory to stay out of version control. The prompt is the soft
    // guard that steers the agent there.
    const prompt = await buildTaskPrompt(projectRoot);
    expect(prompt).toContain(AUTO_SKILL_DIR_PREFIX);
    expect(prompt).toContain(`.qwen/skills/${AUTO_SKILL_DIR_PREFIX}<name>/`);
    expect(prompt).toMatch(/mandatory/i);
  });
});

describe('SKILL_REVIEW_SYSTEM_PROMPT', () => {
  it('requires the auto-skill- directory prefix for new skills (#4837)', () => {
    // The system prompt and buildTaskPrompt carry the prefix instruction on
    // two independent string arrays. buildTaskPrompt is asserted above; this
    // guards the parallel system-prompt line so an edit to one can't silently
    // drop the prefix mandate from the other.
    expect(SKILL_REVIEW_SYSTEM_PROMPT).toContain(AUTO_SKILL_DIR_PREFIX);
    expect(SKILL_REVIEW_SYSTEM_PROMPT).toContain(
      `.qwen/skills/${AUTO_SKILL_DIR_PREFIX}<name>/`,
    );
    expect(SKILL_REVIEW_SYSTEM_PROMPT).toMatch(/MUST use/i);
  });
});

describe('runSkillReviewByAgent limit wiring', () => {
  let tempDir: string;
  let projectRoot: string;

  function makeConfig(
    options: {
      timeoutMinutes?: number;
      maxTurns?: number;
    } = {},
  ): Config {
    return {
      getProjectRoot: () => projectRoot,
      getPermissionManager: () => undefined,
      getMemoryAgentTimeoutMinutes: vi
        .fn()
        .mockReturnValue(options.timeoutMinutes),
      getMemoryAgentMaxTurns: vi.fn().mockReturnValue(options.maxTurns),
    } as unknown as Config;
  }

  beforeEach(async () => {
    vi.mocked(runForkedAgent).mockReset();
    vi.mocked(runForkedAgent).mockResolvedValue({
      status: 'completed',
      finalText: '',
      filesTouched: [],
    });
    tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'skill-timeout-'));
    projectRoot = path.join(tempDir, 'project');
    await fs.mkdir(projectRoot, { recursive: true });
  });

  afterEach(async () => {
    await fs.rm(tempDir, { recursive: true, force: true });
  });

  it('uses the configured memory agent timeout when no timeoutMs param is passed', async () => {
    await runSkillReviewByAgent({
      config: makeConfig({ timeoutMinutes: 30 }),
      projectRoot,
      history: [],
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({ maxTimeMinutes: 30 }),
    );
  });

  it('uses the configured memory agent turn limit when maxTurns is omitted', async () => {
    await runSkillReviewByAgent({
      config: makeConfig({ maxTurns: 25 }),
      projectRoot,
      history: [],
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({ maxTurns: 25 }),
    );
  });

  it('passes the zero turn-limit sentinel through to the forked agent', async () => {
    await runSkillReviewByAgent({
      config: makeConfig({ maxTurns: 0 }),
      projectRoot,
      history: [],
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({ maxTurns: 0 }),
    );
  });

  it('lets an explicit maxTurns param override the configured value', async () => {
    await runSkillReviewByAgent({
      config: makeConfig({ maxTurns: 25 }),
      projectRoot,
      history: [],
      maxTurns: 3,
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({ maxTurns: 3 }),
    );
  });

  it('lets an explicit timeoutMs param override the configured value', async () => {
    await runSkillReviewByAgent({
      config: makeConfig({ timeoutMinutes: 30 }),
      projectRoot,
      history: [],
      timeoutMs: 60_000,
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({ maxTimeMinutes: 1 }),
    );
  });

  it('falls back to the built-in default when neither is set', async () => {
    await runSkillReviewByAgent({
      config: makeConfig(),
      projectRoot,
      history: [],
    });

    expect(runForkedAgent).toHaveBeenCalledWith(
      expect.objectContaining({
        maxTurns: DEFAULT_AUTO_SKILL_MAX_TURNS,
        maxTimeMinutes: DEFAULT_AUTO_SKILL_TIMEOUT_MS / 60_000,
      }),
    );
  });

  it('passes only always-registered tools to the forked agent', async () => {
    // list_directory is disabled by default, so it must not be requested for
    // this turn-budgeted background agent — the prompt steers to read_file.
    await runSkillReviewByAgent({
      config: makeConfig(),
      projectRoot,
      history: [],
    });

    const call = vi.mocked(runForkedAgent).mock.calls[0]?.[0];
    expect(call?.tools).toEqual([
      ToolNames.READ_FILE,
      ToolNames.WRITE_FILE,
      ToolNames.EDIT,
    ]);
  });
});

describe('skill-scoped shim registration-gate delegation (#10075)', () => {
  function scopedPmWithBase(basePm: unknown): PermissionManager {
    const scoped = createSkillScopedAgentConfig(
      {
        getProjectRoot: () => '/project',
        getPermissionManager: () => basePm,
      } as unknown as Config,
      '/project',
    );
    const pm = scoped.getPermissionManager();
    if (!pm) {
      throw new Error(
        'createSkillScopedAgentConfig must install a PermissionManager',
      );
    }
    return pm;
  }

  it('isToolDisabledByCoreToolsAllowList delegates when present, defaults to false otherwise', () => {
    const gate = vi.fn().mockReturnValue(true);
    const withGate: Pick<
      PermissionManager,
      'isToolDisabledByCoreToolsAllowList'
    > = {
      isToolDisabledByCoreToolsAllowList: gate,
    };
    const delegated = scopedPmWithBase(withGate);
    expect(delegated.isToolDisabledByCoreToolsAllowList(ToolNames.EDIT)).toBe(
      true,
    );
    expect(gate).toHaveBeenCalledWith(ToolNames.EDIT);

    const noBase = scopedPmWithBase(undefined);
    expect(noBase.isToolDisabledByCoreToolsAllowList(ToolNames.EDIT)).toBe(
      false,
    );

    // A base PM without the method (older shape) must not throw — the
    // scheduler's own `typeof` guard relies on this returning false.
    const legacyBase: Pick<PermissionManager, 'isToolEnabled'> = {
      isToolEnabled: vi.fn().mockResolvedValue(true),
    };
    const legacy = scopedPmWithBase(legacyBase);
    expect(legacy.isToolDisabledByCoreToolsAllowList(ToolNames.EDIT)).toBe(
      false,
    );
  });

  it('getToolRegistrationStatus delegates when present, defaults to registered', async () => {
    // Use a non-scoped tool: read_file/ls/edit/write_file short-circuit as
    // scoped tools before the base delegation.
    const status = vi.fn().mockResolvedValue('disabled');
    const withStatus: Pick<PermissionManager, 'getToolRegistrationStatus'> = {
      getToolRegistrationStatus: status,
    };
    const delegated = scopedPmWithBase(withStatus);
    await expect(
      delegated.getToolRegistrationStatus(ToolNames.WEB_FETCH),
    ).resolves.toBe('disabled');
    expect(status).toHaveBeenCalledWith(ToolNames.WEB_FETCH);

    const noBase = scopedPmWithBase(undefined);
    await expect(
      noBase.getToolRegistrationStatus(ToolNames.WEB_FETCH),
    ).resolves.toBe('registered');
  });
});
