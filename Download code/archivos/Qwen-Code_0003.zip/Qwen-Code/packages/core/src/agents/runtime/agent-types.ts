/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Agent runtime types.
 *
 * Contains the canonical definitions for agent configuration (prompt, model,
 * run, tool), termination modes, and interactive agent types.
 */

import type { Content, FunctionDeclaration } from '@google/genai';

// ─── Agent Configuration ─────────────────────────────────────

/**
 * Configures the initial prompt for an agent.
 */
export interface PromptConfig {
  /**
   * A single system prompt string that defines the agent's persona and instructions.
   * Templated via ${var} substitution, optionally suffixed with non-interactive
   * rules and user memory. Mutually exclusive with `renderedSystemPrompt`.
   */
  systemPrompt?: string;

  /**
   * A pre-rendered system instruction consumed verbatim — no templating, no
   * non-interactive suffix, no user-memory injection. Used by fork subagents
   * to share the parent conversation's exact cache prefix. Mutually exclusive
   * with `systemPrompt`.
   */
  renderedSystemPrompt?: string | Content;

  /**
   * Seed chat history. When set, fully replaces the default env bootstrap
   * (the caller owns the full prior context, e.g. fork inheriting parent
   * history). Can coexist with `systemPrompt` / `renderedSystemPrompt`.
   */
  initialMessages?: Content[];
}

/**
 * Configures the generative model parameters for an agent.
 */
export interface ModelConfig {
  /**
   * The name or identifier of the model to be used (e.g., 'qwen3-coder-plus').
   *
   * TODO: In the future, this needs to support 'auto' or some other string to support routing use cases.
   */
  model?: string;
}

/**
 * Configures the execution environment and constraints for an agent.
 *
 * TODO: Consider adding max_tokens as a form of budgeting.
 */
export interface RunConfig {
  /** The maximum execution time for the agent in minutes. */
  max_time_minutes?: number;
  /**
   * The maximum number of conversational turns (a user message + model response)
   * before the execution is terminated. Helps prevent infinite loops.
   */
  max_turns?: number;
}

export type AgentExternalInput =
  | string
  | {
      kind: 'notification';
      text: string;
    };

/**
 * Configures the tools available to an agent during its execution.
 */
export interface ToolConfig {
  /**
   * A list of tool names (from the tool registry) or full function declarations
   * exposed to the model.
   */
  tools: Array<string | FunctionDeclaration>;

  /**
   * Optional execution-layer allowlist. Tool declarations remain unchanged,
   * but calls outside this list are rejected before scheduling or approval.
   * Supports exact tool names and MCP server-level patterns.
   */
  executionAllowedTools?: string[];

  /**
   * Optional list of tool names to exclude from the agent's tool pool.
   * Applied after the allowlist and MCP bypass. Supports MCP server-level
   * patterns (e.g., "mcp__server" blocks all tools from that server).
   */
  disallowedTools?: string[];
}

/**
 * Describes the possible termination modes for an agent.
 * This enum provides a clear indication of why an agent's execution ended.
 */
export enum AgentTerminateMode {
  /** The agent's execution terminated due to an unrecoverable error. */
  ERROR = 'ERROR',
  /** The agent's execution terminated because it exceeded the maximum allowed working time. */
  TIMEOUT = 'TIMEOUT',
  /** The agent's execution successfully completed all its defined goals. */
  GOAL = 'GOAL',
  /** The agent's execution terminated because it exceeded the maximum number of turns. */
  MAX_TURNS = 'MAX_TURNS',
  /** The agent's execution terminated after detecting a tool-call loop. */
  LOOP_DETECTED = 'LOOP_DETECTED',
  /** The agent's execution was cancelled via an abort signal. */
  CANCELLED = 'CANCELLED',
  /** The agent was gracefully shut down (e.g., arena/team session ended). */
  SHUTDOWN = 'SHUTDOWN',
}

// ─── Agent Status ────────────────────────────────────────────

/**
 * Canonical lifecycle status for any agent (headless, interactive, arena).
 *
 * State machine:
 *   INITIALIZING → RUNNING → IDLE ⇄ RUNNING → … → COMPLETED / FAILED / CANCELLED
 *
 * - INITIALIZING: Setting up (creating chat, loading tools).
 * - RUNNING:      Actively processing (model thinking / tool execution).
 * - IDLE:         Finished current work, waiting — can accept new messages.
 * - COMPLETED:    Finished for good (explicit shutdown). No further interaction.
 * - FAILED:       Finished with error (API failure, process crash, etc.).
 * - CANCELLED:    Cancelled by user or system.
 */
export enum AgentStatus {
  INITIALIZING = 'initializing',
  RUNNING = 'running',
  IDLE = 'idle',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
}

/** True for COMPLETED, FAILED, CANCELLED — agent is done for good. */
export const isTerminalStatus = (s: AgentStatus): boolean =>
  s === AgentStatus.COMPLETED ||
  s === AgentStatus.FAILED ||
  s === AgentStatus.CANCELLED;

/** True for IDLE or COMPLETED — agent finished its work successfully. */
export const isSuccessStatus = (s: AgentStatus): boolean =>
  s === AgentStatus.IDLE || s === AgentStatus.COMPLETED;

/** True for terminal statuses OR IDLE — agent has settled (not actively working). */
export const isSettledStatus = (s: AgentStatus): boolean =>
  s === AgentStatus.IDLE || isTerminalStatus(s);

/**
 * Lightweight configuration for an AgentInteractive instance.
 * Carries only interactive-specific parameters; the heavy runtime
 * configs (prompt, model, run, tools) live on AgentCore.
 */
export interface AgentInteractiveConfig {
  /** Unique identifier for this agent. */
  agentId: string;
  /** Human-readable name for display. */
  agentName: string;
  /** Optional initial task to start working on immediately. */
  initialTask?: string;
  /** Max model round-trips per enqueued message (default: unlimited). */
  maxTurnsPerMessage?: number;
  /**
   * When true, the agent transitions to COMPLETED (terminal) instead of
   * IDLE when its message queue empties — for truly one-shot agents that
   * should not linger after finishing.
   *
   * Note: team teammates deliberately use `false` (the default). They
   * settle to IDLE rather than COMPLETED so they stay alive to receive
   * follow-up messages and auto-claim further tasks; the leader's wait
   * loop relies on that (see `hasActiveTeammates` /
   * `allTeammatesTerminated` in TeamManager).
   */
  completeOnIdle?: boolean;
  /** Max wall-clock minutes per enqueued message (default: unlimited). */
  maxTimeMinutesPerMessage?: number;
  /**
   * Optional conversation history from a parent session to seed the
   * agent's chat with prior context.
   */
  chatHistory?: Content[];
  /**
   * Optional async context wrapper for every agent processing loop.
   * Used by team agents to preserve teammate identity across follow-up messages.
   */
  runInContext?: <T>(fn: () => T) => T;
}

/**
 * A message exchanged with or produced by an interactive agent.
 *
 * This is a UI-oriented data model (not the Gemini API Content type).
 * AgentInteractive is the sole writer; the UI reads via getMessages().
 */
export interface AgentMessage {
  /** Discriminator for the message kind. */
  role: 'user' | 'assistant' | 'tool_call' | 'tool_result' | 'info';
  /** The text content of the message. */
  content: string;
  /** When the message was created (ms since epoch). */
  timestamp: number;
  /**
   * Whether this assistant message contains thinking/reasoning content.
   * Mirrors AgentStreamTextEvent.thought. Only meaningful when role is 'assistant'.
   */
  thought?: boolean;
  /**
   * Optional metadata.
   *
   * For role='info': metadata.level?: 'info' | 'warning' | 'success' | 'error'
   *   Controls which status message component is rendered. Defaults to 'info'.
   * For role='tool_call': callId, toolName, args, description, renderOutputAsMarkdown, round
   * For role='tool_result': callId, toolName, success, resultDisplay, outputFile, round
   * For role='assistant' with error: error=true
   */
  metadata?: Record<string, unknown>;
}

/**
 * The last model-visible answer in a message history, or undefined
 * when there is none. Scans most-recent-first; the first non-empty,
 * non-thought assistant message wins. Shared by the team pre-attach
 * recovery (TeamManager) and the arena final-text fallback
 * (ArenaManager) so both apply the same selection rule.
 */
export function lastVisibleAnswer(
  messages: readonly AgentMessage[],
): string | undefined {
  for (let i = messages.length - 1; i >= 0; i--) {
    const message = messages[i]!;
    if (message.role !== 'assistant' || message.thought) continue;
    const text = message.content.trim();
    if (text) return text;
  }
  return undefined;
}

/**
 * Snapshot of in-progress streaming state for UI mid-switch handoff.
 * Returned by AgentInteractive.getInProgressStream().
 */
export interface InProgressStreamState {
  /** Accumulated non-thought text so far in the current round. */
  text: string;
  /** Accumulated thinking text so far in the current round. */
  thinking: string;
  /** The reasoning-loop round number being streamed. */
  round: number;
}
