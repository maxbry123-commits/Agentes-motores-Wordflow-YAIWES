"""Module for defect analysis."""
