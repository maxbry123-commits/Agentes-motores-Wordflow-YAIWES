# Copyright (c) Microsoft. All rights reserved.
import asyncio
import os

from agent_framework.declarative import AgentFactory
from azure.identity.aio import AzureCliCredential
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

"""
This sample shows how to create an agent using an inline YAML string rather than a file.

It uses a Azure AI Client so it needs the credential to be passed into the AgentFactory.

Prerequisites:
- `pip install agent-framework-foundry agent-framework-declarative`
- Note: this sample uses `AgentFactory` (declarative agents), which is experimental and emits an `ExperimentalWarning` on first use.
- Set the following environment variables in a .env file or your environment:
    - FOUNDRY_PROJECT_ENDPOINT
    - FOUNDRY_MODEL
"""


async def main():
    """Create an agent from a declarative YAML specification and run it."""
    yaml_definition = """kind: Prompt
name: DiagnosticAgent
displayName: Diagnostic Assistant
instructions: Specialized diagnostic and issue detection agent for systems with critical error protocol and automatic handoff capabilities
description: A agent that performs diagnostics on systems and can escalate issues when critical errors are detected.

model:
  id: =Env.FOUNDRY_MODEL
"""
    # create the agent from the yaml
    async with (
        AzureCliCredential() as credential,
        AgentFactory(
            client_kwargs={
                "credential": credential,
                "project_endpoint": os.environ["FOUNDRY_PROJECT_ENDPOINT"],
            },
            safe_mode=False,
        ).create_agent_from_yaml(yaml_definition) as agent,
    ):
        response = await agent.run("What can you do for me?")
        print("Agent response:", response.text)


if __name__ == "__main__":
    asyncio.run(main())
