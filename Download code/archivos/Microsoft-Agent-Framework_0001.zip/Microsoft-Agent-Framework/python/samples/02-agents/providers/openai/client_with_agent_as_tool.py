# Copyright (c) Microsoft. All rights reserved.

import asyncio
from collections.abc import Awaitable, Callable

from agent_framework import Agent, FunctionInvocationContext
from agent_framework.openai import OpenAIChatClient
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

"""
OpenAI Chat Client Agent-as-Tool Example

Demonstrates hierarchical agent architectures where one agent delegates
work to specialized sub-agents wrapped as tools using as_tool().

This pattern is useful when you want a coordinator agent to orchestrate
multiple specialized agents, each focusing on specific tasks.
"""


async def logging_middleware(
    context: FunctionInvocationContext,
    call_next: Callable[[], Awaitable[None]],
) -> None:
    """MiddlewareTypes that logs tool invocations to show the delegation flow."""
    print(f"[Calling tool: {context.function.name}]")
    print(f"[Request: {context.arguments}]")

    await call_next()

    print(f"[Response: {context.result}]")


async def main() -> None:
    print("=== OpenAI Chat Client Agent-as-Tool Pattern ===")

    client = OpenAIChatClient()

    # Create a specialized writer agent
    writer = Agent(
        client=client,
        name="WriterAgent",
        instructions="You are a creative writer. Write short, engaging content.",
    )

    # Convert writer agent to a tool using as_tool()
    writer_tool = writer.as_tool(
        name="creative_writer",
        description="Generate creative content like taglines, slogans, or short copy",
        arg_name="request",
        arg_description="What to write",
    )

    # Create coordinator agent with writer as a tool
    coordinator = Agent(
        client=client,
        name="CoordinatorAgent",
        instructions="You coordinate with specialized agents. Delegate writing tasks to the creative_writer tool.",
        tools=[writer_tool],
        middleware=[logging_middleware],
    )

    query = "Create a tagline for a coffee shop"
    print(f"User: {query}")
    result = await coordinator.run(query)
    print(f"Coordinator: {result}\n")


if __name__ == "__main__":
    asyncio.run(main())
