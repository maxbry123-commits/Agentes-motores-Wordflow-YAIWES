import { invoke } from '@tauri-apps/api/core'
import { SessionInfo, UnloadResult, MlxConfig } from './types'

export { SessionInfo, UnloadResult, MlxConfig } from './types'

function asNumber(v: any, defaultValue = 0): number {
  if (v === '' || v === null || v === undefined) return defaultValue
  const n = Number(v)
  return isFinite(n) ? n : defaultValue
}

export function normalizeMlxConfig(config: any): MlxConfig {
  return {
    ctx_size: asNumber(config.ctx_size),
    draft_model_path: config.draft_model_path ?? '',
    block_size: asNumber(config.block_size),
    draft_kind: config.draft_kind ?? '',
    kv_bits: asNumber(config.kv_bits),
    kv_quant_scheme: config.kv_quant_scheme ?? '',
  }
}

export async function loadMlxModel(
  modelId: string,
  modelPath: string,
  port: number,
  cfg: MlxConfig,
  envs: Record<string, string>,
  isEmbedding: boolean = false,
  timeout: number = 600
): Promise<SessionInfo> {
  const config = normalizeMlxConfig(cfg)
  return await invoke('plugin:mlx|load_mlx_model', {
    modelId,
    modelPath,
    port,
    config,
    envs,
    isEmbedding,
    timeout,
  })
}

export async function unloadMlxModel(pid: number): Promise<UnloadResult> {
  return await invoke('plugin:mlx|unload_mlx_model', { pid })
}

export async function isMlxProcessRunning(pid: number): Promise<boolean> {
  return await invoke('plugin:mlx|is_mlx_process_running', { pid })
}

export async function getMlxRandomPort(): Promise<number> {
  return await invoke('plugin:mlx|get_mlx_random_port')
}

export async function findMlxSessionByModel(
  modelId: string
): Promise<SessionInfo | null> {
  return await invoke('plugin:mlx|find_mlx_session_by_model', { modelId })
}

export async function getMlxLoadedModels(): Promise<string[]> {
  return await invoke('plugin:mlx|get_mlx_loaded_models')
}

export async function getMlxAllSessions(): Promise<SessionInfo[]> {
  return await invoke('plugin:mlx|get_mlx_all_sessions')
}
