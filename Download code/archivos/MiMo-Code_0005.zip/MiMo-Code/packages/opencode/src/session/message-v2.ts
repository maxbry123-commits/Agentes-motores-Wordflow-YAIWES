import { BusEvent } from "@/bus/bus-event"
import { SessionID, MessageID, PartID } from "./schema"
import z from "zod"
import { NamedError } from "@mimo-ai/shared/util/error"
import {
  APICallError,
  convertToModelMessages,
  LoadAPIKeyError,
  RetryError,
  type ModelMessage,
  type UIMessage,
} from "ai"
import { LSP } from "../lsp"
import { Snapshot } from "@/snapshot"
import { SyncEvent } from "../sync"
import { Database, NotFoundError, and, desc, eq, inArray, lt, or } from "@/storage"
import { MessageTable, PartTable, SessionTable } from "./session.sql"
import { ProviderError } from "@/provider"
import { errorMessage } from "@/util/error"
import { isMedia } from "@/util/media"
import type { Provider } from "@/provider"
import { ModelID, ProviderID } from "@/provider/schema"
import { Effect } from "effect"
import { EffectLogger } from "@/effect"
import {
  inlineToolAttachment,
  routeToolAttachment,
  toolAttachmentFilename,
  toolAttachmentPlaceholder,
} from "./tool-attachment"
import { isSkillCatalogReminder } from "./skill-catalog"
import { collapseCheckpointTail } from "./tail-digest"

/** Error shape thrown by Bun's fetch() when gzip/br decompression fails mid-stream */
interface FetchDecompressionError extends Error {
  code: "ZlibError"
  errno: number
  path: string
}

function causeMetadata(error: unknown): Record<string, string> | undefined {
  const causeChain = ProviderError.summarizeCause(error)
  return causeChain.length > 1 ? { causeChain: JSON.stringify(causeChain) } : undefined
}

export const SYNTHETIC_ATTACHMENT_PROMPT = "Attached file(s) from tool result:"
export { isMedia }

export const OutputLengthError = NamedError.create("MessageOutputLengthError", z.object({}))
export const AbortedError = NamedError.create("MessageAbortedError", z.object({ message: z.string() }))
export const StructuredOutputError = NamedError.create(
  "StructuredOutputError",
  z.object({
    message: z.string(),
    retries: z.number(),
  }),
)
export const AuthError = NamedError.create(
  "ProviderAuthError",
  z.object({
    providerID: z.string(),
    message: z.string(),
  }),
)
export const APIError = NamedError.create(
  "APIError",
  z.object({
    message: z.string(),
    statusCode: z.number().optional(),
    isRetryable: z.boolean(),
    responseHeaders: z.record(z.string(), z.string()).optional(),
    responseBody: z.string().optional(),
    metadata: z.record(z.string(), z.string()).optional(),
  }),
)
export type APIError = z.infer<typeof APIError.Schema>

function isAuthenticationFailure(error: APIError): boolean {
  if (error.data.statusCode === 401) return true
  if (error.data.statusCode !== 403) return false
  const body = error.data.responseBody?.toLowerCase() ?? ""
  const message = error.data.message.toLowerCase()
  const text = `${message} ${body}`
  return /(?:invalid|expired|missing|malformed)\s*(?:api[ _-]?key|token|credential)|(?:api[ _-]?key|token|credential)\s*(?:invalid|expired|missing|malformed)|\b(?:authentication|authorization)\s+(?:failed|required|invalid|missing)|\binvalid credentials?\b|\baccess denied\b/.test(text) || message.trim() === "unauthorized" || body.trim() === "unauthorized"
}

export function isAuthError(error: unknown): boolean {
  return AuthError.isInstance(error) || (APIError.isInstance(error) && isAuthenticationFailure(error))
}
export const ContextOverflowError = NamedError.create(
  "ContextOverflowError",
  z.object({ message: z.string(), responseBody: z.string().optional() }),
)
export const InvalidOutputError = NamedError.create("InvalidOutputError", z.object({ message: z.string() }))
export const TextToolCallError = NamedError.create("TextToolCallError", z.object({ message: z.string() }))
export const ContentFilterError = NamedError.create("ContentFilterError", z.object({ message: z.string() }))
export const ModelError = NamedError.create("ModelError", z.object({ message: z.string() }))

export const OutputFormatText = z
  .object({
    type: z.literal("text"),
  })
  .meta({
    ref: "OutputFormatText",
  })

export const OutputFormatJsonSchema = z
  .object({
    type: z.literal("json_schema"),
    schema: z.record(z.string(), z.any()).meta({ ref: "JSONSchema" }),
    retryCount: z.number().int().min(0).default(2),
  })
  .meta({
    ref: "OutputFormatJsonSchema",
  })

export const Format = z.discriminatedUnion("type", [OutputFormatText, OutputFormatJsonSchema]).meta({
  ref: "OutputFormat",
})
export type OutputFormat = z.infer<typeof Format>

const PartBase = z.object({
  id: PartID.zod,
  sessionID: SessionID.zod,
  messageID: MessageID.zod,
})

export const SnapshotPart = PartBase.extend({
  type: z.literal("snapshot"),
  snapshot: z.string(),
}).meta({
  ref: "SnapshotPart",
})
export type SnapshotPart = z.infer<typeof SnapshotPart>

export const PatchPart = PartBase.extend({
  type: z.literal("patch"),
  hash: z.string(),
  files: z.string().array(),
}).meta({
  ref: "PatchPart",
})
export type PatchPart = z.infer<typeof PatchPart>

export const TextPart = PartBase.extend({
  type: z.literal("text"),
  text: z.string(),
  synthetic: z.boolean().optional(),
  ignored: z.boolean().optional(),
  time: z
    .object({
      start: z.number(),
      end: z.number().optional(),
    })
    .optional(),
  metadata: z.record(z.string(), z.any()).optional(),
}).meta({
  ref: "TextPart",
})
export type TextPart = z.infer<typeof TextPart>

export const ReasoningPart = PartBase.extend({
  type: z.literal("reasoning"),
  text: z.string(),
  metadata: z.record(z.string(), z.any()).optional(),
  time: z.object({
    start: z.number(),
    end: z.number().optional(),
  }),
}).meta({
  ref: "ReasoningPart",
})
export type ReasoningPart = z.infer<typeof ReasoningPart>

const FilePartSourceBase = z.object({
  text: z
    .object({
      value: z.string(),
      start: z.number().int(),
      end: z.number().int(),
    })
    .meta({
      ref: "FilePartSourceText",
    }),
})

export const FileSource = FilePartSourceBase.extend({
  type: z.literal("file"),
  path: z.string(),
}).meta({
  ref: "FileSource",
})

export const SymbolSource = FilePartSourceBase.extend({
  type: z.literal("symbol"),
  path: z.string(),
  range: LSP.Range,
  name: z.string(),
  kind: z.number().int(),
}).meta({
  ref: "SymbolSource",
})

export const ResourceSource = FilePartSourceBase.extend({
  type: z.literal("resource"),
  clientName: z.string(),
  uri: z.string(),
}).meta({
  ref: "ResourceSource",
})

export const FilePartSource = z.discriminatedUnion("type", [FileSource, SymbolSource, ResourceSource]).meta({
  ref: "FilePartSource",
})

export const FilePart = PartBase.extend({
  type: z.literal("file"),
  mime: z.string(),
  filename: z.string().optional(),
  url: z.string(),
  source: FilePartSource.optional(),
}).meta({
  ref: "FilePart",
})
export type FilePart = z.infer<typeof FilePart>

export const AgentPart = PartBase.extend({
  type: z.literal("agent"),
  name: z.string(),
  source: z
    .object({
      value: z.string(),
      start: z.number().int(),
      end: z.number().int(),
    })
    .optional(),
}).meta({
  ref: "AgentPart",
})
export type AgentPart = z.infer<typeof AgentPart>

export const CheckpointPart = PartBase.extend({
  type: z.literal("checkpoint"),
  checkpointDir: z.string(),
  checkpointNumber: z.number(),
  coveredUpTo: MessageID.zod,
  /**
   * Last message that already existed when this rebuild boundary was inserted.
   * Post-rebuild activity-log collapse digests only messages after the
   * checkpoint up to (and including) this id; anything newer stays live so a
   * mid-turn tool loop is not folded into the log on the next request.
   * Optional: older boundaries predate the field and skip collapse.
   */
  digestUpTo: MessageID.zod.optional(),
}).meta({
  ref: "CheckpointPart",
})
export type CheckpointPart = z.infer<typeof CheckpointPart>

export const SubtaskPart = PartBase.extend({
  type: z.literal("subtask"),
  prompt: z.string(),
  description: z.string(),
  agent: z.string(),
  model: z
    .object({
      providerID: ProviderID.zod,
      modelID: ModelID.zod,
    })
    .optional(),
  command: z.string().optional(),
}).meta({
  ref: "SubtaskPart",
})
export type SubtaskPart = z.infer<typeof SubtaskPart>

export const CompactionPart = PartBase.extend({
  type: z.literal("compaction"),
  auto: z.boolean(),
  overflow: z.boolean().optional(),
  // ID of the user message marking the start of the preserved-tail (verbatim
  // recent-turns kept after summarization). Optional: when undefined, no tail
  // was preserved (entire history was summarized).
  tail_start_id: MessageID.zod.optional(),
}).meta({
  ref: "CompactionPart",
})
export type CompactionPart = z.infer<typeof CompactionPart>

export const RetryPart = PartBase.extend({
  type: z.literal("retry"),
  attempt: z.number(),
  error: APIError.Schema,
  time: z.object({
    created: z.number(),
  }),
}).meta({
  ref: "RetryPart",
})
export type RetryPart = z.infer<typeof RetryPart>

export const StepStartPart = PartBase.extend({
  type: z.literal("step-start"),
  snapshot: z.string().optional(),
}).meta({
  ref: "StepStartPart",
})
export type StepStartPart = z.infer<typeof StepStartPart>

export const StepFinishPart = PartBase.extend({
  type: z.literal("step-finish"),
  reason: z.string(),
  snapshot: z.string().optional(),
  cost: z.number(),
  tokens: z.object({
    total: z.number().optional(),
    input: z.number(),
    output: z.number(),
    reasoning: z.number(),
    cache: z.object({
      read: z.number(),
      write: z.number(),
    }),
  }),
}).meta({
  ref: "StepFinishPart",
})
export type StepFinishPart = z.infer<typeof StepFinishPart>

export const ToolStatePending = z
  .object({
    status: z.literal("pending"),
    input: z.record(z.string(), z.any()),
    raw: z.string(),
  })
  .meta({
    ref: "ToolStatePending",
  })

export type ToolStatePending = z.infer<typeof ToolStatePending>

export const ToolStateRunning = z
  .object({
    status: z.literal("running"),
    input: z.record(z.string(), z.any()),
    title: z.string().optional(),
    metadata: z.record(z.string(), z.any()).optional(),
    time: z.object({
      start: z.number(),
    }),
  })
  .meta({
    ref: "ToolStateRunning",
  })
export type ToolStateRunning = z.infer<typeof ToolStateRunning>

export const ToolStateCompleted = z
  .object({
    status: z.literal("completed"),
    input: z.record(z.string(), z.any()),
    output: z.string(),
    providerOutput: z.unknown().optional(),
    providerMetadata: z.record(z.string(), z.any()).optional(),
    title: z.string(),
    metadata: z.record(z.string(), z.any()),
    time: z.object({
      start: z.number(),
      end: z.number(),
      compacted: z.number().optional(),
    }),
    attachments: FilePart.array().optional(),
  })
  .meta({
    ref: "ToolStateCompleted",
  })
export type ToolStateCompleted = z.infer<typeof ToolStateCompleted>

export const ToolStateError = z
  .object({
    status: z.literal("error"),
    input: z.record(z.string(), z.any()),
    error: z.string(),
    metadata: z.record(z.string(), z.any()).optional(),
    time: z.object({
      start: z.number(),
      end: z.number(),
    }),
    attachments: FilePart.array().optional(),
  })
  .meta({
    ref: "ToolStateError",
  })
export type ToolStateError = z.infer<typeof ToolStateError>

/**
 * The terminal state for a tool part that was left unfinished by an
 * interruption. A `pending`/`running` part is persisted the moment the tool
 * starts (so the TUI can stream progress) and is only rewritten by whoever
 * finalizes the turn — so every finalizer must produce the SAME shape, or the
 * transcript renders interrupted calls inconsistently. Callers: the abort
 * finalizer in `SessionProcessor.cleanup` and `SessionPrompt.sweepOrphanToolParts`.
 */
export function abortedToolState(state: ToolPart["state"], error = "Tool execution aborted"): ToolStateError {
  const end = Date.now()
  return {
    status: "error",
    input: state.input,
    error,
    metadata: { ...("metadata" in state && state.metadata ? state.metadata : {}), interrupted: true },
    time: { start: "time" in state ? state.time.start : end, end },
  }
}

export const ToolState = z
  .discriminatedUnion("status", [ToolStatePending, ToolStateRunning, ToolStateCompleted, ToolStateError])
  .meta({
    ref: "ToolState",
  })

export const ToolPart = PartBase.extend({
  type: z.literal("tool"),
  callID: z.string(),
  tool: z.string(),
  state: ToolState,
  metadata: z.record(z.string(), z.any()).optional(),
}).meta({
  ref: "ToolPart",
})
export type ToolPart = z.infer<typeof ToolPart>

const Base = z.object({
  id: MessageID.zod,
  sessionID: SessionID.zod,
  agentID: z.string().optional(),
})

export const Provenance = z
  .object({
    hookPhase: z.enum(["pre", "post"]),
    hookIteration: z.number().int().nonnegative(),
    pluginNames: z.array(z.string()),
    hookIDs: z.array(z.string()),
  })
  .meta({ ref: "Provenance" })
export type Provenance = z.infer<typeof Provenance>

export const User = Base.extend({
  role: z.literal("user"),
  time: z.object({
    created: z.number(),
  }),
  format: Format.optional(),
  summary: z
    .object({
      title: z.string().optional(),
      body: z.string().optional(),
      diffs: Snapshot.FileDiff.array(),
    })
    .optional(),
  agent: z.string(),
  model: z.object({
    providerID: ProviderID.zod,
    modelID: ModelID.zod,
    variant: z.string().optional(),
  }),
  system: z.string().optional(),
  systemMode: z.enum(["append", "replace-agent"]).optional(),
  harness: z.enum(["auto", "codex", "default"]).optional(),
  tools: z.record(z.string(), z.boolean()).optional(),
  provenance: Provenance.optional(),
}).meta({
  ref: "UserMessage",
})
export type User = z.infer<typeof User>

export const Part = z
  .discriminatedUnion("type", [
    TextPart,
    SubtaskPart,
    ReasoningPart,
    FilePart,
    ToolPart,
    StepStartPart,
    StepFinishPart,
    SnapshotPart,
    PatchPart,
    AgentPart,
    RetryPart,
    CheckpointPart,
    CompactionPart,
  ])
  .meta({
    ref: "Part",
  })
export type Part = z.infer<typeof Part>

export const Assistant = Base.extend({
  role: z.literal("assistant"),
  time: z.object({
    created: z.number(),
    completed: z.number().optional(),
  }),
  error: z
    .discriminatedUnion("name", [
      AuthError.Schema,
      NamedError.Unknown.Schema,
      OutputLengthError.Schema,
      AbortedError.Schema,
      StructuredOutputError.Schema,
      ContextOverflowError.Schema,
      InvalidOutputError.Schema,
      TextToolCallError.Schema,
      ContentFilterError.Schema,
      ModelError.Schema,
      APIError.Schema,
    ])
    .optional(),
  parentID: MessageID.zod,
  modelID: ModelID.zod,
  providerID: ProviderID.zod,
  /**
   * @deprecated
   */
  mode: z.string(),
  agent: z.string(),
  path: z.object({
    cwd: z.string(),
    root: z.string(),
  }),
  summary: z.boolean().optional(),
  cost: z.number(),
  tokens: z.object({
    total: z.number().optional(),
    input: z.number(),
    output: z.number(),
    reasoning: z.number(),
    cache: z.object({
      read: z.number(),
      write: z.number(),
    }),
  }),
  structured: z.any().optional(),
  variant: z.string().optional(),
  finish: z.string().optional(),
}).meta({
  ref: "AssistantMessage",
})
export type Assistant = z.infer<typeof Assistant>

export const Info = z.discriminatedUnion("role", [User, Assistant]).meta({
  ref: "Message",
})
export type Info = z.infer<typeof Info>

export const Event = {
  Updated: SyncEvent.define({
    type: "message.updated",
    version: 1,
    aggregate: "sessionID",
    schema: z.object({
      sessionID: SessionID.zod,
      info: Info,
    }),
  }),
  Removed: SyncEvent.define({
    type: "message.removed",
    version: 1,
    aggregate: "sessionID",
    schema: z.object({
      sessionID: SessionID.zod,
      messageID: MessageID.zod,
    }),
  }),
  PartUpdated: SyncEvent.define({
    type: "message.part.updated",
    version: 1,
    aggregate: "sessionID",
    schema: z.object({
      sessionID: SessionID.zod,
      part: Part,
      time: z.number(),
    }),
  }),
  PartDelta: BusEvent.define(
    "message.part.delta",
    z.object({
      sessionID: SessionID.zod,
      messageID: MessageID.zod,
      partID: PartID.zod,
      field: z.string(),
      delta: z.string(),
    }),
  ),
  PartRemoved: SyncEvent.define({
    type: "message.part.removed",
    version: 1,
    aggregate: "sessionID",
    schema: z.object({
      sessionID: SessionID.zod,
      messageID: MessageID.zod,
      partID: PartID.zod,
    }),
  }),
}

export const WithParts = z.object({
  info: Info,
  parts: z.array(Part),
})
export type WithParts = z.infer<typeof WithParts>

const Cursor = z.object({
  id: MessageID.zod,
  time: z.number(),
})
type Cursor = z.infer<typeof Cursor>

export const cursor = {
  encode(input: Cursor) {
    return Buffer.from(JSON.stringify(input)).toString("base64url")
  },
  decode(input: string) {
    return Cursor.parse(JSON.parse(Buffer.from(input, "base64url").toString("utf8")))
  },
}

const info = (row: typeof MessageTable.$inferSelect) =>
  ({
    ...row.data,
    id: row.id,
    sessionID: row.session_id,
    agentID: row.agent_id,
  }) as Info

const part = (row: typeof PartTable.$inferSelect) =>
  ({
    ...row.data,
    id: row.id,
    sessionID: row.session_id,
    messageID: row.message_id,
  }) as Part

const older = (row: Cursor) =>
  or(lt(MessageTable.time_created, row.time), and(eq(MessageTable.time_created, row.time), lt(MessageTable.id, row.id)))

function hydrate(rows: (typeof MessageTable.$inferSelect)[]) {
  const ids = rows.map((row) => row.id)
  const partByMessage = new Map<string, Part[]>()
  if (ids.length > 0) {
    const partRows = Database.use((db) =>
      db
        .select()
        .from(PartTable)
        .where(inArray(PartTable.message_id, ids))
        .orderBy(PartTable.message_id, PartTable.id)
        .all(),
    )
    for (const row of partRows) {
      const next = part(row)
      const list = partByMessage.get(row.message_id)
      if (list) list.push(next)
      else partByMessage.set(row.message_id, [next])
    }
  }

  return rows.map((row) => ({
    info: info(row),
    parts: partByMessage.get(row.id) ?? [],
  }))
}

function providerMeta(metadata: Record<string, any> | undefined) {
  if (!metadata) return undefined
  const { providerExecuted: _, ...rest } = metadata
  return Object.keys(rest).length > 0 ? rest : undefined
}

export const toModelMessagesEffect = Effect.fnUntraced(function* (
  input: WithParts[],
  model: Provider.Model,
  /**
   * When true, messages after the latest rebuild checkpoint are collapsed into
   * a single activity-log user message (see tail-digest.ts). Off by default so
   * checkpoint writers / compaction / title generation keep full fidelity.
   */
  options?: { stripMedia?: boolean; collapseCheckpointTail?: boolean },
) {
  const result: UIMessage[] = []
  const toolNames = new Set<string>()
  const source = options?.collapseCheckpointTail ? collapseCheckpointTail(input) : input

  const toModelOutput = (options: { toolCallId: string; input: unknown; output: unknown }) => {
    const output = options.output
    if (typeof output === "string") {
      return { type: "text", value: output }
    }

    if (
      output &&
      typeof output === "object" &&
      "text" in output &&
      typeof output.text === "string" &&
      "attachments" in output &&
      Array.isArray(output.attachments)
    ) {
      const outputObject = output as {
        text: string
        attachments?: Array<{ mime: string; url: string; filename?: string }>
      }
      const attachments = (outputObject.attachments ?? []).flatMap((attachment) => {
        const inline = inlineToolAttachment(attachment)
        return inline ? [{ ...attachment, ...inline }] : []
      })

      return {
        type: "content",
        value: [
          { type: "text", text: outputObject.text },
          ...attachments.map((attachment) =>
            attachment.mime.startsWith("image/")
              ? {
                  type: "image-data" as const,
                  mediaType: attachment.mediaType,
                  data: attachment.data,
                }
              : {
                  type: "file-data" as const,
                  mediaType: attachment.mediaType,
                  data: attachment.data,
                  filename: toolAttachmentFilename(attachment),
                },
          ),
        ],
      }
    }

    return { type: "json", value: output as never }
  }

  for (const msg of source) {
    if (msg.parts.length === 0) continue

    if (msg.info.role === "user") {
      const userMessage: UIMessage = {
        id: msg.info.id,
        role: "user",
        parts: [],
      }
      result.push(userMessage)
      for (const part of msg.parts) {
        if (part.type === "text") {
          // Skill catalogs moved to the system tail. Suppress snapshots persisted
          // by older versions so resumed sessions do not receive a duplicate user-side catalog.
          if (part.synthetic && isSkillCatalogReminder(part.text)) continue
          if (!part.ignored)
            userMessage.parts.push({
              type: "text",
              text: part.text,
            })
        }
        // text/plain and directory files are converted into text parts, ignore them
        if (part.type === "file" && part.mime !== "text/plain" && part.mime !== "application/x-directory") {
          if (options?.stripMedia && isMedia(part.mime)) {
            userMessage.parts.push({
              type: "text",
              text: `[Attached ${part.mime}: ${part.filename ?? "file"}]`,
            })
          } else {
            userMessage.parts.push({
              type: "file",
              url: part.url,
              mediaType: part.mime,
              filename: part.filename,
            })
          }
        }

        if (part.type === "checkpoint") {
          userMessage.parts.push({
            type: "text" as const,
            text: "Summary of previous conversation from checkpoint files:",
          })
        }
        if (part.type === "compaction") {
          userMessage.parts.push({
            type: "text" as const,
            text: "Summary of previous conversation:",
          })
        }
        if (part.type === "subtask") {
          userMessage.parts.push({
            type: "text",
            text: "The following tool was executed by the user",
          })
        }
      }
    }

    if (msg.info.role === "assistant") {
      const differentModel = `${model.providerID}/${model.id}` !== `${msg.info.providerID}/${msg.info.modelID}`
      const syntheticGroups: Array<{
        tool: string
        callID: string
        status: "completed" | "error"
        parts: Array<
          { type: "file"; url: string; mediaType: string; filename?: string } | { type: "text"; text: string }
        >
      }> = []
      const routeAttachments = (input: {
        tool: string
        callID: string
        status: "completed" | "error"
        attachments: FilePart[]
        allowNative: boolean
      }) => {
        const native: FilePart[] = []
        const parts: (typeof syntheticGroups)[number]["parts"] = []
        for (const attachment of input.attachments) {
          const route = routeToolAttachment({ model, attachment, allowNative: input.allowNative })
          if (route === "native") native.push(attachment)
          if (route === "synthetic") {
            parts.push({
              type: "file",
              url: attachment.url,
              mediaType: attachment.mime,
              filename: toolAttachmentFilename(attachment),
            })
          }
          if (route === "placeholder") {
            parts.push({
              type: "text",
              text: toolAttachmentPlaceholder(attachment),
            })
          }
        }
        if (parts.length > 0) {
          syntheticGroups.push({
            tool: input.tool,
            callID: input.callID,
            status: input.status,
            parts,
          })
        }
        return native
      }

      if (
        msg.info.error &&
        !(
          AbortedError.isInstance(msg.info.error) &&
          msg.parts.some((part) => part.type !== "step-start" && part.type !== "reasoning")
        )
      ) {
        continue
      }
      const assistantMessage: UIMessage = {
        id: msg.info.id,
        role: "assistant",
        parts: [],
      }
      for (const part of msg.parts) {
        if (part.type === "text")
          assistantMessage.parts.push({
            type: "text",
            text: part.text,
            ...(differentModel ? {} : { providerMetadata: part.metadata }),
          })
        if (part.type === "step-start")
          assistantMessage.parts.push({
            type: "step-start",
          })
        if (part.type === "tool") {
          toolNames.add(part.tool)
          if (part.state.status === "completed") {
            const outputText = part.state.time.compacted ? "[Old tool result content cleared]" : part.state.output
            const attachments = part.state.time.compacted || options?.stripMedia ? [] : (part.state.attachments ?? [])
            const finalAttachments = routeAttachments({
              tool: part.tool,
              callID: part.callID,
              status: "completed",
              attachments,
              allowNative: true,
            })

            const output =
              part.state.providerOutput !== undefined
                ? part.state.providerOutput
                : finalAttachments.length > 0
                  ? {
                      text: outputText,
                      attachments: finalAttachments,
                    }
                  : outputText

            assistantMessage.parts.push({
              type: ("tool-" + part.tool) as `tool-${string}`,
              state: "output-available",
              toolCallId: part.callID,
              input: part.state.input,
              output,
              ...(part.metadata?.providerExecuted ? { providerExecuted: true } : {}),
              ...(differentModel ? {} : { callProviderMetadata: providerMeta(part.metadata) }),
              ...(differentModel ? {} : { resultProviderMetadata: providerMeta(part.state.providerMetadata) }),
            })
          }
          if (part.state.status === "error") {
            const attachments = options?.stripMedia ? [] : (part.state.attachments ?? [])
            routeAttachments({
              tool: part.tool,
              callID: part.callID,
              status: "error",
              attachments,
              allowNative: false,
            })
            const output = part.state.metadata?.interrupted === true ? part.state.metadata.output : undefined
            if (typeof output === "string") {
              assistantMessage.parts.push({
                type: ("tool-" + part.tool) as `tool-${string}`,
                state: "output-available",
                toolCallId: part.callID,
                input: part.state.input,
                output,
                ...(part.metadata?.providerExecuted ? { providerExecuted: true } : {}),
                ...(differentModel ? {} : { callProviderMetadata: providerMeta(part.metadata) }),
              })
            } else {
              assistantMessage.parts.push({
                type: ("tool-" + part.tool) as `tool-${string}`,
                state: "output-error",
                toolCallId: part.callID,
                input: part.state.input,
                errorText: part.state.error,
                ...(part.metadata?.providerExecuted ? { providerExecuted: true } : {}),
                ...(differentModel ? {} : { callProviderMetadata: providerMeta(part.metadata) }),
              })
            }
          }
          // Handle pending/running tool calls to prevent dangling tool_use blocks
          // Anthropic/Claude APIs require every tool_use to have a corresponding tool_result
          if (part.state.status === "pending" || part.state.status === "running")
            assistantMessage.parts.push({
              type: ("tool-" + part.tool) as `tool-${string}`,
              state: "output-error",
              toolCallId: part.callID,
              input: part.state.input,
              errorText: "[Tool execution was interrupted]",
              ...(part.metadata?.providerExecuted ? { providerExecuted: true } : {}),
              ...(differentModel ? {} : { callProviderMetadata: providerMeta(part.metadata) }),
            })
        }
        if (part.type === "reasoning") {
          assistantMessage.parts.push({
            type: "reasoning",
            text: part.text,
            ...(differentModel ? {} : { providerMetadata: part.metadata }),
          })
        }
      }
      if (assistantMessage.parts.length > 0) {
        result.push(assistantMessage)
        if (syntheticGroups.length > 0) {
          result.push({
            id: MessageID.ascending(),
            role: "user",
            parts: [
              {
                type: "text" as const,
                text: SYNTHETIC_ATTACHMENT_PROMPT,
              },
              ...syntheticGroups.flatMap((group) => [
                {
                  type: "text" as const,
                  text: `Tool "${group.tool}" call ${group.callID} ${group.status === "error" ? "failed" : "completed"}:`,
                },
                ...group.parts,
              ]),
            ],
          })
        }
      }
    }
  }

  const tools = Object.fromEntries(Array.from(toolNames).map((toolName) => [toolName, { toModelOutput }]))

  return yield* Effect.promise(() =>
    convertToModelMessages(
      result.filter((msg) => msg.parts.some((part) => part.type !== "step-start")),
      {
        //@ts-expect-error (convertToModelMessages expects a ToolSet but only actually needs tools[name]?.toModelOutput)
        tools,
      },
    ),
  )
})

export function toModelMessages(
  input: WithParts[],
  model: Provider.Model,
  options?: { stripMedia?: boolean; collapseCheckpointTail?: boolean },
): Promise<ModelMessage[]> {
  return Effect.runPromise(toModelMessagesEffect(input, model, options).pipe(Effect.provide(EffectLogger.layer)))
}

export function page(input: { sessionID: SessionID; limit: number; before?: string; agentID?: string }) {
  const before = input.before ? cursor.decode(input.before) : undefined
  // Slice contract: agentID `undefined` (default) ⇒ main slice only;
  // `"*"` ⇒ every slice (full-stream opt-out for export/stats/share/etc.);
  // any other string ⇒ that subagent's actorID slice.
  const agentClause = input.agentID === "*" ? undefined : eq(MessageTable.agent_id, input.agentID ?? "main")
  const where = and(
    eq(MessageTable.session_id, input.sessionID),
    ...(before ? [older(before)] : []),
    ...(agentClause ? [agentClause] : []),
  )
  const rows = Database.use((db) =>
    db
      .select()
      .from(MessageTable)
      .where(where)
      .orderBy(desc(MessageTable.time_created), desc(MessageTable.id))
      .limit(input.limit + 1)
      .all(),
  )
  if (rows.length === 0) {
    const row = Database.use((db) =>
      db.select({ id: SessionTable.id }).from(SessionTable).where(eq(SessionTable.id, input.sessionID)).get(),
    )
    if (!row) throw new NotFoundError({ message: `Session not found: ${input.sessionID}` })
    return {
      items: [] as WithParts[],
      more: false,
    }
  }

  const more = rows.length > input.limit
  const slice = more ? rows.slice(0, input.limit) : rows
  const items = hydrate(slice)
  items.reverse()
  const tail = slice.at(-1)
  return {
    items,
    more,
    cursor: more && tail ? cursor.encode({ id: tail.id, time: tail.time_created }) : undefined,
  }
}

/**
 * Iterate session messages oldest-last (caller usually reverses).
 *
 * Slice contract (forwarded to `page`):
 *   options.agentID === undefined  → main slice only (default)
 *   options.agentID === "*"        → every slice (full-stream opt-out)
 *   any other string               → that actor's slice
 */
export function* stream(sessionID: SessionID, options?: { agentID?: string }) {
  const size = 50
  let before: string | undefined
  while (true) {
    const next = page({ sessionID, limit: size, before, agentID: options?.agentID })
    if (next.items.length === 0) break
    for (let i = next.items.length - 1; i >= 0; i--) {
      yield next.items[i]
    }
    if (!next.more || !next.cursor) break
    before = next.cursor
  }
}

export function parts(message_id: MessageID) {
  const rows = Database.use((db) =>
    db.select().from(PartTable).where(eq(PartTable.message_id, message_id)).orderBy(PartTable.id).all(),
  )
  return rows.map(
    (row) =>
      ({
        ...row.data,
        id: row.id,
        sessionID: row.session_id,
        messageID: row.message_id,
      }) as Part,
  )
}

export function get(input: { sessionID: SessionID; messageID: MessageID }): WithParts {
  const row = Database.use((db) =>
    db
      .select()
      .from(MessageTable)
      .where(and(eq(MessageTable.id, input.messageID), eq(MessageTable.session_id, input.sessionID)))
      .get(),
  )
  if (!row) throw new NotFoundError({ message: `Message not found: ${input.messageID}` })
  return {
    info: info(row),
    parts: parts(input.messageID),
  }
}

export function filterCompacted(msgs: Iterable<WithParts>) {
  const result = [] as WithParts[]
  for (const msg of msgs) {
    result.push(msg)
    if (msg.info.role === "user" && msg.parts.some((p) => p.type === "checkpoint" || p.type === "compaction")) break
  }
  result.reverse()
  return result
}

export const filterCompactedEffect = Effect.fnUntraced(function* (
  sessionID: SessionID,
  options?: { contextFrom?: SessionID; contextWatermark?: MessageID; agentID?: string },
) {
  const ownMessages = filterCompacted(stream(sessionID, { agentID: options?.agentID }))

  if (!options?.contextFrom) return ownMessages

  // Load parent messages up to the watermark. Inherited parent context is
  // always scoped to the parent's main thread (agent_id = 'main') — subagent
  // siblings on the parent must not leak into a child session/subagent.
  const parentStream = stream(options.contextFrom, { agentID: "main" })
  const parentFiltered = filterCompacted(parentStream)

  // If watermark is set, truncate parent messages at the watermark point
  if (options.contextWatermark) {
    const watermarkIdx = parentFiltered.findIndex((msg) => msg.info.id === options.contextWatermark)
    if (watermarkIdx >= 0) {
      return [...parentFiltered.slice(0, watermarkIdx + 1), ...ownMessages]
    }
  }

  // Fallback: use all parent messages
  return [...parentFiltered, ...ownMessages]
})

function fromParsedStreamError(
  parsed: ProviderError.ParsedStreamError,
  cause: unknown,
): NonNullable<Assistant["error"]> {
  const metadata = causeMetadata(cause)
  if (parsed.type === "context_overflow") {
    return new ContextOverflowError(
      { message: parsed.message, responseBody: parsed.responseBody },
      { cause },
    ).toObject()
  }
  return new APIError(
    {
      message: parsed.message,
      isRetryable: parsed.isRetryable,
      responseBody: parsed.responseBody,
      ...(metadata ? { metadata } : {}),
    },
    { cause },
  ).toObject()
}

export function fromError(
 e: unknown,
  ctx: { providerID: ProviderID; aborted?: boolean; allow404Retry?: boolean },
): NonNullable<Assistant["error"]> {
  switch (true) {
    case e instanceof DOMException && e.name === "AbortError":
      return new AbortedError({ message: e.message }, { cause: e }).toObject()
    case ProviderError.isAbortError(e):
      return new AbortedError({ message: errorMessage(e) }, { cause: e }).toObject()
    // The AI SDK wraps the real failure in AI_RetryError after exhausting its
    // own maxRetries. Unwrap to the underlying error (.lastError) so the
    // APICallError branch below can extract statusCode/isRetryable/responseBody.
    // Without this, a wrapped 5xx falls through to the `e instanceof Error`
    // catch-all and collapses to an opaque UnknownError — which SessionRetry
    // can't classify, so the visible retry status never fires and the turn
    // hangs with a dead spinner.
    case RetryError.isInstance(e): {
      const errors = Array.isArray(e.errors) ? e.errors : []
      const inner = e.lastError ?? errors[errors.length - 1]
      if (inner !== undefined && inner !== e) return fromError(inner, ctx)
      return new NamedError.Unknown({ message: e.message }, { cause: e }).toObject()
    }
    case OutputLengthError.isInstance(e):
      return e
    case LoadAPIKeyError.isInstance(e):
      return new AuthError(
        {
          providerID: ctx.providerID,
          message: e.message,
        },
        { cause: e },
      ).toObject()
    case e instanceof Error && ProviderError.isRetryableNetworkError(e): {
      const code = ProviderError.networkErrorCode(e)
      const message =
        code === "ECONNRESET"
          ? "Connection reset by server"
          : code === "ETIMEDOUT"
            ? "Request timed out"
            : errorMessage(e) || "Transient network error"
      return new APIError(
        {
          message,
          isRetryable: true,
          metadata: {
            ...(code ? { code } : {}),
            message: e.message,
            ...causeMetadata(e),
          },
        },
        { cause: e },
      ).toObject()
    }
    case e instanceof Error && (e as FetchDecompressionError).code === "ZlibError":
      if (ctx.aborted) {
        return new AbortedError({ message: e.message }, { cause: e }).toObject()
      }
      return new APIError(
        {
          message: "Response decompression failed",
          isRetryable: true,
          metadata: {
            code: (e as FetchDecompressionError).code,
            message: e.message,
            ...causeMetadata(e),
          },
        },
        { cause: e },
      ).toObject()
    case APICallError.isInstance(e):
      const parsed = ProviderError.parseAPICallError({
        providerID: ctx.providerID,
        error: e,
        allow404Retry: ctx.allow404Retry,
      })
      if (parsed.type === "context_overflow") {
        return new ContextOverflowError(
          {
            message: parsed.message,
            responseBody: parsed.responseBody,
          },
          { cause: e },
        ).toObject()
      }

      return new APIError(
        {
          message: parsed.message,
          statusCode: parsed.statusCode,
          isRetryable: parsed.isRetryable,
          responseHeaders: parsed.responseHeaders,
          responseBody: parsed.responseBody,
          metadata: (() => {
            const metadata = { ...parsed.metadata, ...causeMetadata(e) }
            return Object.keys(metadata).length > 0 ? metadata : undefined
          })(),
        },
        { cause: e },
      ).toObject()
    // A TypeError (e.g. "j.map is not a function" from non-array content)
    // is a programming defect, not a transient API failure. Surface it as a
    // named error so it is diagnosable instead of collapsing to UnknownError.
    case e instanceof TypeError:
    case e instanceof Error: {
      const parsed = ProviderError.parseStreamError(e)
      if (parsed) return fromParsedStreamError(parsed, e)
      const message = e instanceof TypeError ? `TypeError: ${errorMessage(e)}` : errorMessage(e)
      return new NamedError.Unknown({ message }, { cause: e }).toObject()
    }
    default: {
      const parsed = ProviderError.parseStreamError(e)
      if (parsed) return fromParsedStreamError(parsed, e)
      return new NamedError.Unknown({ message: JSON.stringify(e) ?? String(e) }, { cause: e }).toObject()
    }
  }
}

export * as MessageV2 from "./message-v2"
