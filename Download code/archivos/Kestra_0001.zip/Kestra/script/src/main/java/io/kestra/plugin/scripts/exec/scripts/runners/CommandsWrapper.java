package io.kestra.plugin.scripts.exec.scripts.runners;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;

import org.apache.commons.lang3.SystemUtils;

import io.kestra.core.exceptions.IllegalVariableEvaluationException;
import io.kestra.core.models.property.Property;
import io.kestra.core.models.tasks.NamespaceFiles;
import io.kestra.core.models.tasks.RunnableTaskException;
import io.kestra.core.models.tasks.runners.*;
import io.kestra.core.models.tasks.runners.DefaultLogConsumer;
import io.kestra.core.runners.FilesService;
import io.kestra.core.runners.RunContext;
import io.kestra.core.utils.IdUtils;
import io.kestra.core.utils.NamespaceFilesUtils;
import io.kestra.plugin.core.runner.Process;
import io.kestra.plugin.scripts.exec.scripts.models.DockerOptions;
import io.kestra.plugin.scripts.exec.scripts.models.RunnerType;
import io.kestra.plugin.scripts.exec.scripts.models.ScriptOutput;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.With;

import static io.kestra.core.utils.Rethrow.throwFunction;

@AllArgsConstructor
@Getter
public class CommandsWrapper implements TaskCommands {
    private RunContext runContext;

    private Path workingDirectory;

    private Path outputDirectory;

    private Map<String, Object> additionalVars;

    @With
    private Property<List<String>> interpreter;

    @With
    private Property<List<String>> beforeCommands;

    @With
    private Property<List<String>> commands;

    @With
    private boolean beforeCommandsWithOptions;

    @With
    private boolean failFast;

    private Map<String, String> env;

    @With
    private io.kestra.core.models.tasks.runners.AbstractLogConsumer logConsumer;

    @With
    @Deprecated
    private RunnerType runnerType;

    @With
    private String containerImage;

    @With
    private TaskRunner<?> taskRunner;

    @With
    @Deprecated
    private DockerOptions dockerOptions;

    @With
    @Deprecated
    private Boolean warningOnStdErr;
    @With
    private NamespaceFiles namespaceFiles;

    @With
    private Object inputFiles;

    @With
    private List<String> outputFiles;

    @With
    private Boolean enableOutputDirectory;

    @With
    private Duration timeout;

    @With
    private TargetOS targetOS;

    @With
    private KotlpOptions kotlp;

    public CommandsWrapper(RunContext runContext) {
        this.runContext = runContext;
        this.workingDirectory = runContext.workingDir().path();
        this.logConsumer = new DefaultLogConsumer(runContext);
        this.additionalVars = new HashMap<>();
        this.env = new HashMap<>();
    }

    public CommandsWrapper withEnv(Map<String, String> envs) {
        return new CommandsWrapper(
            runContext,
            workingDirectory,
            getOutputDirectory(),
            additionalVars,
            interpreter,
            beforeCommands,
            commands,
            beforeCommandsWithOptions,
            failFast,
            envs,
            logConsumer,
            runnerType,
            containerImage,
            taskRunner,
            dockerOptions,
            warningOnStdErr,
            namespaceFiles,
            inputFiles,
            outputFiles,
            enableOutputDirectory,
            timeout,
            targetOS,
            kotlp
        );
    }

    public CommandsWrapper addAdditionalVars(Map<String, Object> additionalVars) {
        if (this.additionalVars == null) {
            this.additionalVars = new HashMap<>();
        }
        this.additionalVars.putAll(additionalVars);

        return this;
    }

    public CommandsWrapper addEnv(Map<String, String> envs) {
        if (this.env == null) {
            this.env = new HashMap<>();
        }
        this.env.putAll(envs);

        return this;
    }

    public <T extends TaskRunnerDetailResult> ScriptOutput run() throws Exception {
        if (this.namespaceFiles != null && !Boolean.FALSE.equals(runContext.render(this.namespaceFiles.getEnabled()).as(Boolean.class).orElse(true))) {
            NamespaceFilesUtils.loadNamespaceFiles(runContext, this.namespaceFiles);
        }

        // Inject non-glob outputFiles into the Pebble render context as a name→path map before any rendering.
        // This makes {{ outputFiles["name"] }} resolvable in scripts, consistent with JDBC tasks.
        // Glob patterns are skipped here — they cannot resolve to a single path; post-run collection still handles them.
        Map<String, Object> runnerVars = taskRunner.additionalVars(runContext, this);
        if (this.outputFiles != null && !this.outputFiles.isEmpty()) {
            String workingDir = String.valueOf(runnerVars.getOrDefault(ScriptService.VAR_WORKING_DIR, this.workingDirectory));
            Map<String, String> outputFilesMap = new LinkedHashMap<>();
            for (String name : this.outputFiles) {
                if (!name.contains("*") && !name.contains("?") && !name.contains("[")) {
                    outputFilesMap.put(name, workingDir + "/" + name);
                }
            }
            if (!outputFilesMap.isEmpty()) {
                runnerVars.put("outputFiles", outputFilesMap);
            }
        }

        if (this.inputFiles != null) {
            FilesService.inputFiles(runContext, runnerVars, this.inputFiles);
        }

        if (this.isKotlpEnabled()) {
            KotlpUtils.copyTo(this.workingDirectory.resolve(kotlpBinaryName()));
        }

        RunContext taskRunnerRunContext = runContext.cloneForPlugin(taskRunner);

        List<String> renderedCommands = this.renderCommands(runContext, commands);
        List<String> renderedBeforeCommands = this.renderCommands(runContext, beforeCommands);
        List<String> renderedInterpreter = this.renderCommands(runContext, interpreter);

        List<String> effectiveBeforeCommands = this.isBeforeCommandsWithOptions() ? getBeforeCommandsWithOptions(renderedBeforeCommands) : renderedBeforeCommands;
        if (!renderedBeforeCommands.isEmpty()) {
            List<String> marked = new ArrayList<>();
            marked.add("echo '##kestra:log:debug##'");
            marked.addAll(effectiveBeforeCommands);
            marked.add("echo '##kestra:log:info##'");
            effectiveBeforeCommands = marked;
        }

        List<String> finalCommands = renderedBeforeCommands.isEmpty() && renderedInterpreter.isEmpty() ? renderedCommands
            : ScriptService.scriptCommands(
                renderedInterpreter,
                effectiveBeforeCommands,
                renderedCommands,
                Optional.ofNullable(targetOS).orElse(TargetOS.AUTO)
            );

        if (this.isKotlpEnabled()) {
            if (this.kotlp.logFlushInterval() != null && this.kotlp.logDir() == null) {
                throw new IllegalArgumentException("The kotlp 'logFlushInterval' option requires 'logDir' to be set.");
            }

            String workingDir = String.valueOf(runnerVars.getOrDefault(ScriptService.VAR_WORKING_DIR, this.workingDirectory));
            List<String> wrapped = new ArrayList<>(finalCommands.size() + 7);
            if (!this.isWindowsTarget()) {
                // The kotlp APE binary cannot be exec'd directly without kernel binfmt support; its header is a valid shell script that bootstraps it.
                wrapped.add("/bin/sh");
            }
            wrapped.add(workingDir + "/" + kotlpBinaryName());
            if (this.kotlp.logDir() != null) {
                wrapped.add("--log-dir");
                wrapped.add(this.kotlp.logDir());
                if (this.kotlp.logFlushInterval() != null) {
                    wrapped.add("--log-flush-interval");
                    wrapped.add(String.valueOf(this.kotlp.logFlushInterval().toSeconds()));
                }
            }
            wrapped.add("--");
            wrapped.addAll(finalCommands);
            finalCommands = wrapped;
        }

        this.commands = Property.ofValue(finalCommands);

        ScriptOutput.ScriptOutputBuilder scriptOutputBuilder = ScriptOutput.builder();

        try {
            TaskRunnerResult<T> taskRunnerResult = (TaskRunnerResult<T>) taskRunner.run(taskRunnerRunContext, this, this.outputFiles);
            scriptOutputBuilder.exitCode(taskRunnerResult.getExitCode())
                .outputFiles(getOutputFiles(taskRunnerRunContext))
                .taskRunner(taskRunnerResult.getDetails());

            if (taskRunnerResult.getLogConsumer() != null) {
                scriptOutputBuilder
                    .stdOutLineCount(taskRunnerResult.getLogConsumer().getStdOutCount())
                    .stdErrLineCount(taskRunnerResult.getLogConsumer().getStdErrCount())
                    .vars(taskRunnerResult.getLogConsumer().getOutputs());
            }

            return scriptOutputBuilder.build();
        } catch (TaskException e) {
            var output = scriptOutputBuilder.exitCode(e.getExitCode())
                .stdOutLineCount(e.getStdOutCount())
                .stdErrLineCount(e.getStdErrCount())
                .vars(e.getLogConsumer() != null ? e.getLogConsumer().getOutputs() : null)
                .taskRunner(e.getDetails())
                .outputFiles(getOutputFiles(taskRunnerRunContext))
                .build();
            throw new RunnableTaskException(e, output);
        }
    }

    private Map<String, URI> getOutputFiles(RunContext taskRunnerRunContext) throws Exception {
        Map<String, URI> outputFiles = new HashMap<>();
        if (this.outputDirectoryEnabled()) {
            outputFiles.putAll(ScriptService.uploadOutputFiles(taskRunnerRunContext, this.getOutputDirectory()));
        }

        if (this.outputFiles != null) {
            outputFiles.putAll(FilesService.outputFiles(taskRunnerRunContext, this.outputFiles));
        }
        return outputFiles;
    }

    public Path getOutputDirectory() {
        if (this.outputDirectory == null) {
            this.outputDirectory = this.workingDirectory.resolve(IdUtils.create());
            if (!this.outputDirectory.toFile().mkdirs()) {
                throw new RuntimeException("Unable to create the output directory " + this.outputDirectory);
            }
        }

        return this.outputDirectory;
    }

    public String render(RunContext runContext, String command, List<String> internalStorageLocalFiles) throws IllegalVariableEvaluationException, IOException {
        TaskRunner<?> taskRunner = this.getTaskRunner();
        return ScriptService.replaceInternalStorage(
            this.runContext,
            taskRunner.additionalVars(runContext, this),
            command,
            taskRunner instanceof RemoteRunnerInterface
        );
    }

    public String render(RunContext runContext, Property<String> command) throws IllegalVariableEvaluationException, IOException {
        TaskRunner<?> taskRunner = this.getTaskRunner();
        if (command == null) {
            return null;
        }

        Map<String, Object> additionalVars = taskRunner.additionalVars(runContext, this);
        if (this.outputFiles != null && !this.outputFiles.isEmpty()) {
            String workingDir = String.valueOf(additionalVars.getOrDefault(ScriptService.VAR_WORKING_DIR, this.workingDirectory));
            Map<String, String> outputFilesMap = new LinkedHashMap<>();
            for (String name : this.outputFiles) {
                if (!name.contains("*") && !name.contains("?") && !name.contains("[")) {
                    outputFilesMap.put(name, workingDir + "/" + name);
                }
            }
            if (!outputFilesMap.isEmpty()) {
                additionalVars.put("outputFiles", outputFilesMap);
            }
        }

        return runContext.render(command).as(String.class, additionalVars)
            .map(throwFunction(c -> ScriptService.replaceInternalStorage(runContext, c, taskRunner instanceof RemoteRunnerInterface)))
            .orElse(null);
    }

    public List<String> renderCommands(RunContext runContext, Property<List<String>> commands) throws IllegalVariableEvaluationException, IOException {
        TaskRunner<?> taskRunner = this.getTaskRunner();
        return ScriptService.replaceInternalStorage(
            this.runContext,
            taskRunner.additionalVars(runContext, this),
            commands,
            taskRunner instanceof RemoteRunnerInterface
        );
    }

    protected List<String> getBeforeCommandsWithOptions(List<String> beforeCommands) throws IllegalVariableEvaluationException {
        if (!this.isFailFast()) {
            return beforeCommands;
        }

        if (beforeCommands == null || beforeCommands.isEmpty()) {
            return getExitOnErrorCommands();
        }

        ArrayList<String> newCommands = new ArrayList<>(beforeCommands.size() + 1);
        newCommands.addAll(getExitOnErrorCommands());
        newCommands.addAll(beforeCommands);
        return newCommands;
    }

    protected List<String> getExitOnErrorCommands() {
        if (this.isWindowsTarget()) {
            return List.of("");
        }
        // errexit option may be unsupported by non-shell interpreter.
        return List.of("set -e");
    }

    // If targetOS is Windows OR targetOS is AUTO && current system is windows and we use process as a runner.(TLDR will run on windows)
    private boolean isWindowsTarget() {
        TargetOS os = this.getTargetOS();
        return os == TargetOS.WINDOWS ||
            (os == TargetOS.AUTO && SystemUtils.IS_OS_WINDOWS && this.getTaskRunner() instanceof Process);
    }

    private boolean isKotlpEnabled() {
        return this.kotlp != null && this.kotlp.isEnabled();
    }

    // kotlp is a single portable binary; Windows only needs it renamed with an '.exe' extension.
    private String kotlpBinaryName() {
        return this.isWindowsTarget() ? KotlpUtils.WINDOWS_BINARY_NAME : KotlpUtils.BINARY_NAME;
    }
}