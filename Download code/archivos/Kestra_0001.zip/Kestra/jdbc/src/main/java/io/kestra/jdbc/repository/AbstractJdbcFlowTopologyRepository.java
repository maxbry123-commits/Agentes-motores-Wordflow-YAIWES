package io.kestra.jdbc.repository;

import java.util.ArrayList;
import java.util.List;

import org.jooq.*;
import org.jooq.Record;
import org.jooq.impl.DSL;

import io.kestra.core.models.flows.FlowInterface;
import io.kestra.core.models.topologies.FlowTopology;
import io.kestra.core.repositories.FlowTopologyRepositoryInterface;

public abstract class AbstractJdbcFlowTopologyRepository extends AbstractJdbcRepository implements FlowTopologyRepositoryInterface {
    protected final io.kestra.jdbc.AbstractJdbcRepository<FlowTopology> jdbcRepository;

    public AbstractJdbcFlowTopologyRepository(io.kestra.jdbc.AbstractJdbcRepository<FlowTopology> jdbcRepository) {
        this.jdbcRepository = jdbcRepository;
    }

    @Override
    public List<FlowTopology> findByFlow(String tenantId, String namespace, String flowId, Boolean destinationOnly) {
        return jdbcRepository
            .getDslContextWrapper()
            .transactionResult(configuration ->
            {
                List<Condition> ors = new ArrayList<>();
                ors.add(
                    DSL.and(
                        buildTenantCondition("destination", tenantId),
                        field("destination_namespace").eq(namespace),
                        field("destination_id").eq(flowId)
                    )
                );

                if (!destinationOnly) {
                    ors.add(
                        DSL.and(
                            buildTenantCondition("source", tenantId),
                            field("source_namespace").eq(namespace),
                            field("source_id").eq(flowId)
                        )
                    );
                }

                Select<Record1<Object>> from = DSL
                    .using(configuration)
                    .select(VALUE_FIELD)
                    .from(this.jdbcRepository.getTable())
                    .where(DSL.or(ors));

                return this.jdbcRepository.fetch(from);
            });
    }

    @Override
    public List<FlowTopology> findByNamespace(String tenantId, String namespace) {
        return jdbcRepository
            .getDslContextWrapper()
            .transactionResult(configuration ->
            {
                List<Condition> ors = new ArrayList<>();
                ors.add(
                    DSL.and(
                        buildTenantCondition("destination", tenantId),
                        field("destination_namespace").eq(namespace),
                        buildTenantCondition("source", tenantId),
                        field("source_namespace").eq(namespace)
                    )
                );

                Select<Record1<Object>> from = DSL
                    .using(configuration)
                    .select(VALUE_FIELD)
                    .from(this.jdbcRepository.getTable())
                    .where(DSL.or(ors));

                return this.jdbcRepository.fetch(from);
            });
    }

    @Override
    public List<FlowTopology> findByNamespacePrefix(String tenantId, String namespacePrefix) {
        return jdbcRepository
            .getDslContextWrapper()
            .transactionResult(configuration ->
            {
                // Match flows that originate from the namespace or its children
                Condition sourceCondition = field("source_namespace").eq(namespacePrefix)
                    .or(field("source_namespace").startsWith(namespacePrefix + "."));

                Condition tenantSource = buildTenantCondition("source", tenantId);
                Condition tenantDest = buildTenantCondition("destination", tenantId);

                Select<Record1<Object>> from = DSL
                    .using(configuration)
                    .select(VALUE_FIELD)
                    .from(this.jdbcRepository.getTable())
                    .where(tenantSource.and(tenantDest).and(sourceCondition));

                return this.jdbcRepository.fetch(from);
            });
    }

    @Override
    public List<FlowTopology> findAll(String tenantId) {
        return jdbcRepository
            .getDslContextWrapper()
            .transactionResult(configuration ->
            {
                List<Condition> ors = new ArrayList<>();
                ors.add(
                    DSL.and(
                        buildTenantCondition("destination", tenantId),
                        buildTenantCondition("source", tenantId)
                    )
                );

                Select<Record1<Object>> from = DSL
                    .using(configuration)
                    .select(VALUE_FIELD)
                    .from(this.jdbcRepository.getTable())
                    .where(DSL.or(ors));

                return this.jdbcRepository.fetch(from);
            });
    }

    @Override
    public void save(FlowInterface flow, List<FlowTopology> flowTopologies) {
        jdbcRepository
            .getDslContextWrapper()
            .transaction(configuration ->
            {
                DSLContext context = DSL.using(configuration);

                context
                    .delete(this.jdbcRepository.getTable())
                    .where(
                        DSL.or(
                            DSL.and(
                                buildTenantCondition("destination", flow.getTenantId()),
                                field("destination_namespace").eq(flow.getNamespace()),
                                field("destination_id").eq(flow.getId())
                            ),
                            DSL.and(
                                buildTenantCondition("source", flow.getTenantId()),
                                field("source_namespace").eq(flow.getNamespace()),
                                field("source_id").eq(flow.getId())
                            )
                        )
                    )
                    .execute();

                if (!flowTopologies.isEmpty()) {
                    context
                        .batch(
                            flowTopologies
                                .stream()
                                .map(flowTopology -> buildMergeStatement(context, flowTopology))
                                .toList()
                        )
                        .execute();
                }
            });
    }

    protected DMLQuery<Record> buildMergeStatement(DSLContext context, FlowTopology flowTopology) {
        return context.mergeInto(this.jdbcRepository.getTable())
            .using(context.selectOne())
            .on(KEY_FIELD.eq(this.jdbcRepository.key(flowTopology)))
            .whenMatchedThenUpdate()
            .set(this.jdbcRepository.persistFields(flowTopology))
            .whenNotMatchedThenInsert()
            .set(KEY_FIELD, this.jdbcRepository.key(flowTopology))
            .set(this.jdbcRepository.persistFields(flowTopology));
    }

    @Override
    public FlowTopology save(FlowTopology flowTopology) {
        this.jdbcRepository.persist(flowTopology);

        return flowTopology;
    }

    protected Condition buildTenantCondition(String prefix, String tenantId) {
        return tenantId == null ? field(prefix + "_tenant_id").isNull() : field(prefix + "_tenant_id").eq(tenantId);
    }
}
