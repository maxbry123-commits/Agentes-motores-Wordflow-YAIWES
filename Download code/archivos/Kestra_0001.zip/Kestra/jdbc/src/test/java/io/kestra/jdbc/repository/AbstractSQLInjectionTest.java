package io.kestra.jdbc.repository;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import io.kestra.core.exceptions.InvalidQueryFiltersException;
import io.kestra.core.models.Label;
import io.kestra.core.models.QueryFilter;
import io.kestra.core.models.flows.Flow;
import io.kestra.core.models.flows.FlowWithSource;
import io.kestra.core.models.flows.GenericFlow;
import io.kestra.core.models.flows.State;
import io.kestra.core.repositories.ExecutionRepositoryInterface;
import io.kestra.core.repositories.FlowRepositoryInterface;
import io.kestra.core.utils.TestsUtils;

import io.micronaut.data.model.Pageable;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

import static io.kestra.core.repositories.AbstractExecutionRepositoryTest.builder;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@MicronautTest
public abstract class AbstractSQLInjectionTest {
    private static final String TEST_NAMESPACE = "io.kestra.unittest";

    @Inject
    private ExecutionRepositoryInterface executionRepository;

    @Inject
    private FlowRepositoryInterface flowRepository;

    @Test
    void executionLabelFilterShouldResistSqlInjection() {
        var tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        var exec = executionRepository.save(
            builder(tenant, State.Type.RUNNING, null)
                .labels(List.of(new Label("mykey", "myvalue")))
                .build()
        );

        // QueryFilter API — EQUALS: injection in label key must return no results
        assertThat(
            executionRepository.find(
                Pageable.from(1, 10), tenant, List.of(
                    QueryFilter.builder()
                        .field(QueryFilter.Field.LABELS)
                        .operation(QueryFilter.Op.EQUALS)
                        .value(Map.of("' OR '1'='1", "anything"))
                        .build()
                )
            )
        ).as("EQUALS with SQL injection in label key should return no results").isEmpty();

        // QueryFilter API — EQUALS: injection in label value must return no results
        assertThat(
            executionRepository.find(
                Pageable.from(1, 10), tenant, List.of(
                    QueryFilter.builder()
                        .field(QueryFilter.Field.LABELS)
                        .operation(QueryFilter.Op.EQUALS)
                        .value(Map.of("mykey", "' OR '1'='1"))
                        .build()
                )
            )
        ).as("EQUALS with SQL injection in label value should return no results").isEmpty();

        // QueryFilter API — NOT_EQUALS: injection in label key; no execution has the injected key,
        // so NOT_EQUALS must return the execution (tests the Postgres jsonb_path_query_first path and MySQL JSON_SEARCH path)
        assertThat(
            executionRepository.find(
                Pageable.from(1, 10), tenant, List.of(
                    QueryFilter.builder()
                        .field(QueryFilter.Field.LABELS)
                        .operation(QueryFilter.Op.NOT_EQUALS)
                        .value(Map.of("' OR '1'='1", "anything"))
                        .build()
                )
            )
        ).as("NOT_EQUALS with SQL injection in label key should return the execution (literal comparison, key absent)")
            .usingRecursiveFieldByFieldElementComparatorOnFields("id")
            .containsOnly(exec);

        // Old Map-based API — injection in label key must return no results
        assertThat(
            executionRepository.find(
                null, tenant, null, null, null, null, null, null,
                Map.of("' OR '1'='1", "anything"), null, false
            )
                .collectList().block()
        ).as("Old API: SQL injection in label key should return no results").isEmpty();

        // Old Map-based API — injection in label value must return no results
        assertThat(
            executionRepository.find(
                null, tenant, null, null, null, null, null, null,
                Map.of("mykey", "' OR '1'='1"), null, false
            )
                .collectList().block()
        ).as("Old API: SQL injection in label value should return no results").isEmpty();
    }

    @Test
    void flowLabelFilterShouldResistSqlInjection() {
        String tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        FlowWithSource flow = FlowWithSource.builder()
            .id("sql-injection-test")
            .namespace(TEST_NAMESPACE)
            .tenantId(tenant)
            .labels(Label.from(Map.of("mykey", "myvalue")))
            .build();
        flow = flowRepository.create(GenericFlow.of(flow));

        try {
            // EQUALS: injection in label key — payload must be treated as a literal string, returning no results
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.LABELS)
                            .operation(QueryFilter.Op.EQUALS)
                            .value(Map.of("' OR '1'='1", "anything"))
                            .build()
                    )
                )
            ).as("EQUALS with SQL injection in label key should return no results").isEmpty();

            // EQUALS: injection in label value — payload must be treated as a literal string, returning no results
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.LABELS)
                            .operation(QueryFilter.Op.EQUALS)
                            .value(Map.of("mykey", "' OR '1'='1"))
                            .build()
                    )
                )
            ).as("EQUALS with SQL injection in label value should return no results").isEmpty();

            // NOT_EQUALS: injection in label key — no flow has the injected key, so NOT_EQUALS must return the flow
            // (tests the Postgres jsonb_path_query_first path and MySQL JSON_SEARCH path)
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.LABELS)
                            .operation(QueryFilter.Op.NOT_EQUALS)
                            .value(Map.of("' OR '1'='1", "anything"))
                            .build()
                    )
                )
            ).as("NOT_EQUALS with SQL injection in label key should return the flow (literal comparison, key absent)")
                .hasSize(1)
                .extracting(Flow::getId)
                .containsExactly("sql-injection-test");
        } finally {
            deleteFlow(flow);
        }
    }

    @Test
    void flowFullTextShouldNotReturnAllResultsWithWildcardQuery() {
        String tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        FlowWithSource flow = FlowWithSource.builder()
            .id("wildcard-test-flow")
            .namespace(TEST_NAMESPACE)
            .tenantId(tenant)
            .build();
        flow = flowRepository.create(GenericFlow.of(flow));

        try {
            // A bare '%' must not act as a match-all wildcard
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.QUERY)
                            .operation(QueryFilter.Op.EQUALS)
                            .value("%")
                            .build()
                    )
                )
            ).as("Querying with '%' should return no results, not all flows").isEmpty();

            // A bare '_' must not act as a single-char wildcard
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.QUERY)
                            .operation(QueryFilter.Op.EQUALS)
                            .value("_")
                            .build()
                    )
                )
            ).as("Querying with '_' should return no results, not all flows").isEmpty();

            // Searching with the real id must still find the flow
            assertThat(
                flowRepository.find(
                    Pageable.UNPAGED, tenant, List.of(
                        QueryFilter.builder()
                            .field(QueryFilter.Field.QUERY)
                            .operation(QueryFilter.Op.EQUALS)
                            .value("wildcard")
                            .build()
                    )
                )
            ).as("Querying with the flow id should return the flow")
                .hasSize(1)
                .extracting(Flow::getId)
                .containsExactly("wildcard-test-flow");
        } finally {
            deleteFlow(flow);
        }
    }

    private static final String CATASTROPHIC_REGEX_PATTERN = "(a+)+$";
    private static final String INVALID_SYNTAX_REGEX_PATTERN = "[a-";

    private QueryFilter catastrophicRegexFilter() {
        return QueryFilter.builder()
            .field(QueryFilter.Field.NAMESPACE)
            .operation(QueryFilter.Op.REGEX)
            .value(CATASTROPHIC_REGEX_PATTERN)
            .build();
    }

    private QueryFilter invalidSyntaxRegexFilter() {
        return QueryFilter.builder()
            .field(QueryFilter.Field.NAMESPACE)
            .operation(QueryFilter.Op.REGEX)
            .value(INVALID_SYNTAX_REGEX_PATTERN)
            .build();
    }

    @Test
    void flowRegexFilterShouldRejectCatastrophicBacktrackingPattern() {
        String tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        // A REGEX filter prone to catastrophic backtracking must be rejected before reaching the DB engine
        assertThatThrownBy(() -> flowRepository.find(Pageable.UNPAGED, tenant, List.of(catastrophicRegexFilter())))
            .as("REGEX with a catastrophic-backtracking pattern should be rejected")
            .isInstanceOf(InvalidQueryFiltersException.class);
    }

    @Test
    void executionRegexFilterShouldRejectCatastrophicBacktrackingPattern() {
        var tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        // Same guard on the execution repository's QueryFilter path
        assertThatThrownBy(() -> executionRepository.find(Pageable.from(1, 10), tenant, List.of(catastrophicRegexFilter())))
            .as("REGEX with a catastrophic-backtracking pattern should be rejected")
            .isInstanceOf(InvalidQueryFiltersException.class);
    }

    @Test
    void executionRegexFilterShouldRejectInvalidSyntaxPattern() {
        var tenant = TestsUtils.randomTenant(this.getClass().getSimpleName());

        // A syntactically invalid REGEX pattern must be rejected before it reaches the DB engine,
        // instead of surfacing as a 500 that leaks the rendered SQL (kestra-ee#10266)
        assertThatThrownBy(() -> executionRepository.find(Pageable.from(1, 10), tenant, List.of(invalidSyntaxRegexFilter())))
            .as("REGEX with an invalid syntax pattern should be rejected")
            .isInstanceOf(InvalidQueryFiltersException.class);
    }

    private void deleteFlow(Flow flow) {
        if (flow == null) {
            return;
        }
        flowRepository
            .findByIdWithSource(flow.getTenantId(), flow.getNamespace(), flow.getId())
            .ifPresent(delete -> flowRepository.delete(flow.toBuilder().revision(null).build()));
    }
}
