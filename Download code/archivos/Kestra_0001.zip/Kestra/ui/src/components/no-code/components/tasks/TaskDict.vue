<template>
    <KsAlert
        v-if="duplicatedKeys?.length"
        :title="$t('duplicate-pair', {label: $t('key'), key: duplicatedKeys[0]})"
        type="error"
        :closable="false"
        class="mb-2"
    />
    <div class="task-collection" :class="{'task-collection--filled': currentValue.length > 0}">
        <template v-if="componentType">
            <Wrapper v-for="(item, index) in currentValue" :key="index" class="item-wrapper">
                <template #tasks>
                    <InputText
                        :ref="el => { if (el) keyInputRefs[index] = el }"
                        :modelValue="item[0]"
                        @update:model-value="onKey(index, $event)"
                        margin="m-0"
                        placeholder="Key"
                        :haveError="duplicatedKeys.includes(item[0])"
                    />
                    <hr>
                    <component
                        ref="valueComponent"
                        :is="componentType"
                        :modelValue="item[1]"
                        @update:model-value="onValueChange(index, $event)"
                        :root="getKey(item[0])"
                        :schema="schema.additionalProperties"
                        :required="isRequired(item[0])"
                        :disabled
                        merge
                    />
                    <div class="delete-container">
                        <button @click="removeItem(index)" class="remove-entry">
                            {{ te(`no_code.remove.${root}`) ? $t(`no_code.remove.${root}`) : $t('no_code.remove.default') }} <DeleteOutline />
                        </button>
                    </div>
                </template>
            </Wrapper>
        </template>
        <template v-else>
            <KsRow v-for="(item, index) in currentValue" :key="index" :gutter="10" class="w-100" style="align-items: center;" :data-testid="`task-dict-item-${item[0]}-${index}`">
                <KsCol :span="6">
                    <InputText
                        :ref="el => { if (el) keyInputRefs[index] = el }"
                        :modelValue="item[0]"
                        @update:model-value="onKey(index, $event)"
                        margin="m-0"
                        placeholder="Key"
                        :haveError="duplicatedKeys.includes(item[0])"
                        :inputStyle="{minHeight: 'var(--kel-component-size)', padding: '7px 11px'}"
                    />
                </KsCol>
                <KsCol :span="16">
                    <TaskExpression
                        :modelValue="item[1]"
                        @update:model-value="onValueChange(index, $event)"
                        :root="getKey(item[0])"
                        :schema="schema.additionalProperties"
                        :required="isRequired(item[0])"
                        :disabled
                    />
                </KsCol>
                <KsCol :span="2" class="col align-self-center delete">
                    <DeleteOutline @click="removeItem(index)" />
                </KsCol>
            </KsRow>
        </template>
        <Add v-if="!props.disabled" :to="addTargetName" @add="addItem()" />
    </div>
</template>

<script setup lang="ts">
    import {computed, ref, watch, nextTick} from "vue"
    import {useI18n} from "vue-i18n"
    import {DeleteOutline} from "../../utils/icons"

    import InputText from "../inputs/InputText.vue"
    import TaskExpression from "./TaskExpression.vue"
    import Add from "../Add.vue"
    import debounce from "lodash/debounce"
    import Wrapper from "./Wrapper.vue"
    import {useBlockComponent} from "./useBlockComponent"

    const {te} = useI18n()

    defineOptions({
        inheritAttrs: false,
    })

    const props = withDefaults(defineProps<{
        modelValue?: Record<string, any>;
        schema?: any;
        root?: string;
        disabled?: boolean;
    }>(), {
        disabled: false,
        modelValue: () => ({}),
        root: undefined,
        schema: () => ({type: "object"}),
    })

    const {getBlockComponent} = useBlockComponent()

    const addTargetName = computed(() =>
        props.root?.split(".").pop()?.replace(/\[\d+\]$/, "") || undefined)

    const componentType = computed(() => {
        return props.schema?.additionalProperties ? getBlockComponent.value(
            props.schema.additionalProperties,
            props.root,
        ) : undefined
    })

    const currentValue = ref<[string, any][]>([])
    const keyInputRefs: Record<number, any> = {}

    const localEdit = ref(false)

    watch(
        () => props.modelValue,
        (newValue) => {
            if(localEdit.value) {
                return
            }
            localEdit.value = false
            if(newValue === undefined || newValue === null) {
                currentValue.value = []
                return
            }
            currentValue.value = Object.entries(newValue ?? {})
        },
        {
            immediate: true,
            deep: true,
        },
    )

    const duplicatedKeys = computed(() => {
        return currentValue.value.map(pair => pair[0])
            .filter(key => key !== "")
            .filter((key, index, self) =>
                self.indexOf(key) !== index,
            )
    })

    const emitUpdate = debounce(function () {
        if(duplicatedKeys.value?.length > 0) {
            return
        }
        localEdit.value = true
        emit("update:modelValue", Object.fromEntries(currentValue.value.filter(pair => pair[0] !== "" && pair[1] !== undefined)))
    }, 200)

    const emit = defineEmits(["update:modelValue"])

    function getKey(key: string) {
        if (!props.root) return key
        return key ? `${props.root}.${key}` : props.root
    }

    function isRequired(key: string) {
        return props.schema?.required?.includes(key)
    }

    function onKey(key: number, val: string) {
        currentValue.value[key][0] = val
        emitUpdate()
    }

    function onValueChange(key: number, val: any) {
        currentValue.value[key][1] = val
        emitUpdate()
    }

    function removeItem(index: number) {
        currentValue.value.splice(index, 1)
        emitUpdate()
    }

    function addItem() {
        currentValue.value.push(["", undefined])
        const newIndex = currentValue.value.length - 1
        emitUpdate()

        nextTick(() => {
            setTimeout(() => {
                keyInputRefs[newIndex]?.focus()
            }, 100)
        })
    }
</script>

<style scoped lang="scss">
@import "../../styles/code.scss";

.task-container{
    margin-bottom: 1rem;
}

.delete-container{
    display: flex;
    align-items: center;
    margin-left: 1rem;
    justify-content: end;
}

.remove-entry{
    color: var(--ks-text-secondary);
    background-color: var(--ks-btn-secondary-bg-default);
    border: none;
    display: flex;
    align-items: center;
    gap: .5rem;
    opacity: 0.7;
    padding: 0;
    height: .75rem;
    &:hover {
        color: var(--ks-text-secondary);
        opacity: 1;
    }
}

.item-wrapper {
    margin: .25rem 0;
    background-color: var(--ks-bg-surface);
}
</style>
