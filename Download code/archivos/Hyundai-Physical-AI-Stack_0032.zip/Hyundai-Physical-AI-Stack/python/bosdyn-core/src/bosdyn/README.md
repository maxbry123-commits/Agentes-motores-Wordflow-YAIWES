<!--
Copyright (c) 2023 Boston Dynamics, Inc.  All rights reserved.

Downloading, reproducing, distributing or otherwise using the SDK Software
is subject to the terms and conditions of the Boston Dynamics Software
Development Kit License (20191101-BDSDK-SL).
-->

# Python Core

Core code and interfaces for the Boston Dynamics robot API.

## Contents

- [BDDF](bddf/README)
- [Geometry](geometry)
- [Util](util)
- [Deprecated](deprecated)
