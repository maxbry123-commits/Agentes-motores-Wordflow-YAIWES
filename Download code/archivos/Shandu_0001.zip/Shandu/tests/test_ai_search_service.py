from __future__ import annotations

import asyncio
from types import SimpleNamespace

from shandu.services.ai_search import AISearchService
from shandu.services.search import SearchHit
from shandu.services.scrape import ScrapedPage


class FakeDesk:
    def __init__(self, content: str) -> None:
        self._content = content

    async def arun(self, worker, job):
        del worker, job
        return SimpleNamespace(status="completed", content=self._content)


class FakeRuntime:
    def __init__(self, content: str) -> None:
        self.settings = SimpleNamespace(model="deepseek/deepseek-v4-flash")
        self.desk = FakeDesk(content)


class FakeSearchService:
    async def search(self, query: str, max_results: int) -> list[SearchHit]:
        del query, max_results
        return [
            SearchHit(
                query="q",
                url="https://example.com/a",
                title="Example A",
                snippet="Snippet A",
            ),
            SearchHit(
                query="q",
                url="https://example.com/b",
                title="Example B",
                snippet="Snippet B",
            ),
        ]


class EmptySearchService:
    async def search(self, query: str, max_results: int) -> list[SearchHit]:
        del query, max_results
        return []


class FakeScrapeService:
    async def scrape_many(self, urls: list[str]) -> tuple[list[ScrapedPage], int]:
        pages = [
            ScrapedPage(
                requested_url=url,
                url=url,
                title=f"Title {idx}",
                text=f"Long text for {url}",
                domain="example.com",
            )
            for idx, url in enumerate(urls, start=1)
        ]
        return pages, 0


def test_ai_search_returns_model_answer_when_available() -> None:
    service = AISearchService(
        runtime=FakeRuntime("# Result\n\n## Answer\nBody [1]"),
        search_service=FakeSearchService(),
        scrape_service=FakeScrapeService(),
    )

    result = asyncio.run(service.search("test query"))
    assert "## Answer" in result.answer_markdown
    assert len(result.sources) == 2


def test_ai_search_handles_empty_sources() -> None:
    service = AISearchService(
        runtime=FakeRuntime(""),
        search_service=EmptySearchService(),
        scrape_service=FakeScrapeService(),
    )

    result = asyncio.run(service.search("missing"))
    assert "No search results were returned" in result.answer_markdown
    assert result.sources == []


def test_ai_search_attaches_scraped_excerpt_for_noncanonical_hit_url() -> None:
    from shandu.services.scrape.service import _canonicalize_url

    class NonCanonicalSearch:
        async def search(self, query: str, max_results: int) -> list[SearchHit]:
            del query, max_results
            return [SearchHit(query="q", url="https://example.com", title="Home", snippet="")]

    class CanonicalizingScrape:
        async def scrape_many(self, urls: list[str]) -> tuple[list[ScrapedPage], int]:
            pages = [
                ScrapedPage(
                    requested_url=_canonicalize_url(url),
                    url=_canonicalize_url(url),
                    title="Home",
                    text="Body text from the homepage.",
                    domain="example.com",
                )
                for url in urls
            ]
            return pages, 0

    service = AISearchService(
        runtime=FakeRuntime(""),
        search_service=NonCanonicalSearch(),
        scrape_service=CanonicalizingScrape(),
    )

    result = asyncio.run(service.search("home"))
    assert result.sources[0].text_excerpt.startswith("Body text")
