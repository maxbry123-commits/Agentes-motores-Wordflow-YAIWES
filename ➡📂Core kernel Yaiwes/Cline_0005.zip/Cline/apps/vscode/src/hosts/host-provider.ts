import { WebviewProvider } from "@/core/webview"
import { CommentReviewController } from "@/integrations/editor/CommentReviewController"
import { EditPreview } from "@/integrations/editor/EditPreview"
import { HostBridgeClientProvider } from "./host-provider-types"
/**
 * Singleton class that manages host-specific providers for dependency injection.
 *
 * This system runs on two different platforms (VSCode extension and cline-core),
 * so all the host-specific classes and properties are contained in here. The
 * rest of the codebase can use the host provider interface to access platform-specific
 * implementations in a platform-agnostic way.
 *
 * Usage:
 * - Initialize once: HostProvider.initialize(webviewCreator, editPreviewCreator, hostBridge)
 * - Access HostBridge services: HostProvider.window.showMessage()
 * - Access Host Provider factories: HostProvider.get().createEditPreview()
 */
export class HostProvider {
	private static instance: HostProvider | null = null

	createWebviewProvider: WebviewProviderCreator
	createEditPreview: EditPreviewCreator
	createCommentReviewController: CommentReviewControllerCreator
	hostBridge: HostBridgeClientProvider

	// Logs to a user-visible output channel.
	logToChannel: LogToChannel

	// Returns a callback URL that will redirect to Cline.
	// The path parameter specifies the route for the callback (e.g., "/auth", "/openrouter").
	// The optional preferredPort parameter hints that the provider should try to bind
	// this specific port first (used to preserve OAuth client registrations across sessions).
	getCallbackUrl: (path: string, preferredPort?: number) => Promise<string>

	// Returns the location of the binary `name`.
	// Use `getBinaryLocation()` from utils/ts.ts instead of using
	// this directly. The helper function correctly handles the file
	// extension on Windows.
	getBinaryLocation: (name: string) => Promise<string>

	// The absolute file system path where the extension is installed.
	// Use to this to get the location of extension assets.
	extensionFsPath: string

	// The absolute file system path where the extension can store global state.
	globalStorageFsPath: string

	// Private constructor to enforce singleton pattern
	private constructor(
		createWebviewProvider: WebviewProviderCreator,
		createEditPreview: EditPreviewCreator,
		createCommentReviewController: CommentReviewControllerCreator,
		hostBridge: HostBridgeClientProvider,
		logToChannel: LogToChannel,
		getCallbackUrl: (path: string, preferredPort?: number) => Promise<string>,
		getBinaryLocation: (name: string) => Promise<string>,
		extensionFsPath: string,
		globalStorageFsPath: string,
	) {
		this.createWebviewProvider = createWebviewProvider
		this.createEditPreview = createEditPreview
		this.createCommentReviewController = createCommentReviewController
		this.hostBridge = hostBridge
		this.logToChannel = logToChannel
		this.getCallbackUrl = getCallbackUrl
		this.getBinaryLocation = getBinaryLocation
		this.extensionFsPath = extensionFsPath
		this.globalStorageFsPath = globalStorageFsPath
	}

	public static initialize(
		webviewProviderCreator: WebviewProviderCreator,
		editPreviewCreator: EditPreviewCreator,
		commentReviewControllerCreator: CommentReviewControllerCreator,
		hostBridgeProvider: HostBridgeClientProvider,
		logToChannel: LogToChannel,
		getCallbackUrl: (path: string, preferredPort?: number) => Promise<string>,
		getBinaryLocation: (name: string) => Promise<string>,
		extensionFsPath: string,
		globalStorageFsPath: string,
	): HostProvider {
		if (HostProvider.instance) {
			throw new Error("Host provider has already been initialized.")
		}
		HostProvider.instance = new HostProvider(
			webviewProviderCreator,
			editPreviewCreator,
			commentReviewControllerCreator,
			hostBridgeProvider,
			logToChannel,
			getCallbackUrl,
			getBinaryLocation,
			extensionFsPath,
			globalStorageFsPath,
		)
		return HostProvider.instance
	}

	/**
	 * Gets the singleton instance
	 */
	public static get(): HostProvider {
		if (!HostProvider.instance) {
			throw new Error("HostProvider not setup. Call HostProvider.initialize() first.")
		}
		return HostProvider.instance
	}

	public static isInitialized(): boolean {
		return !!HostProvider.instance
	}

	/**
	 * Resets the HostProvider instance (primarily for testing)
	 * This allows tests to reinitialize the HostProvider with different configurations
	 */
	public static reset(): void {
		HostProvider.instance = null
	}

	public static get workspace() {
		return HostProvider.get().hostBridge.workspaceClient
	}

	public static get env() {
		return HostProvider.get().hostBridge.envClient
	}

	public static get window() {
		return HostProvider.get().hostBridge.windowClient
	}

	public static get diff() {
		return HostProvider.get().hostBridge.diffClient
	}
}

/**
 * A function that creates WebviewProvider instances
 */
export type WebviewProviderCreator = () => WebviewProvider

/**
 * A function that creates EditPreview instances (read-only virtual diff previews)
 */
export type EditPreviewCreator = () => EditPreview

/**
 * A function that creates CommentReviewController instances
 */
export type CommentReviewControllerCreator = () => CommentReviewController

export type LogToChannel = (message: string) => void
