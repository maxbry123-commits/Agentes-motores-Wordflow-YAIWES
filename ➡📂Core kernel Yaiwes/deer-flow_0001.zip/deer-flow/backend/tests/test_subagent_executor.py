"""Tests for subagent executor async/sync execution paths.

Covers:
- SubagentExecutor.execute() synchronous execution path
- SubagentExecutor._aexecute() asynchronous execution path
- execute_async() routes background work without bouncing through execute()
- Error handling in both sync and async paths
- Async tool support (MCP tools)
- Cooperative cancellation via cancel_event
- Parent/child checkpoint-lineage and message-stream isolation

Note: Due to circular import issues in the main codebase, conftest.py mocks
deerflow.subagents.executor. This test file uses delayed import via fixture to test
the real implementation in isolation.
"""

import asyncio
import importlib
import sys
import threading
import time
from datetime import datetime
from importlib.metadata import version as package_version
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from packaging.version import Version

from deerflow.skills.types import Skill
from deerflow.subagents.capacity import SubagentCapacityRejected

# Module names that need to be mocked to break circular imports
_MOCKED_MODULE_NAMES = [
    "deerflow.agents",
    "deerflow.agents.thread_state",
    "deerflow.agents.middlewares",
    "deerflow.agents.middlewares.thread_data_middleware",
    "deerflow.sandbox",
    "deerflow.sandbox.middleware",
    "deerflow.sandbox.security",
    "deerflow.models",
    "deerflow.skills.storage",
]

_LANGGRAPH_HAS_ROOT_LINEAGE_STREAM_REGRESSION = Version(package_version("langgraph")) >= Version("1.2.6")


def _default_app_config():
    return SimpleNamespace(
        tool_search=SimpleNamespace(enabled=False),
        authorization=SimpleNamespace(enabled=False),
        skills=SimpleNamespace(
            deferred_discovery=True,
            container_path="/mnt/skills",
        ),
        skill_evolution=SimpleNamespace(enabled=False),
    )


def _patch_default_get_app_config(executor_module):
    executor_module.get_app_config = _default_app_config
    return executor_module


def _clear_stale_executor_package_attr() -> None:
    subagents_pkg = sys.modules.get("deerflow.subagents")
    if subagents_pkg is not None and hasattr(subagents_pkg, "executor"):
        delattr(subagents_pkg, "executor")


@pytest.fixture(autouse=True)
def _setup_executor_classes():
    """Set up mocked modules and import real executor classes.

    This fixture runs once per test and yields the executor classes.
    It handles module cleanup to avoid affecting other test files.
    """
    # Save original modules
    original_modules = {name: sys.modules.get(name) for name in _MOCKED_MODULE_NAMES}
    original_executor = sys.modules.get("deerflow.subagents.executor")
    original_tool_search = sys.modules.get("deerflow.tools.builtins.tool_search")

    # Preload the real deferred-tool helpers before replacing the parent agent
    # packages with cycle-breaking test doubles. Executor imports this module
    # lazily while building initial state.
    tool_search_module = importlib.import_module("deerflow.tools.builtins.tool_search")

    # Remove mocked executor if exists (from conftest.py)
    if "deerflow.subagents.executor" in sys.modules:
        del sys.modules["deerflow.subagents.executor"]
    _clear_stale_executor_package_attr()

    # Set up mocks
    for name in _MOCKED_MODULE_NAMES:
        sys.modules[name] = MagicMock()
    storage_module = ModuleType("deerflow.skills.storage")
    storage_module.get_or_new_skill_storage = lambda **kwargs: SimpleNamespace(load_skills=lambda *, enabled_only: [])
    storage_module.get_or_new_user_skill_storage = lambda user_id, **kwargs: SimpleNamespace(load_skills=lambda *, enabled_only: [])
    sys.modules["deerflow.skills.storage"] = storage_module
    sys.modules["deerflow.tools.builtins.tool_search"] = tool_search_module

    # Import real classes inside fixture
    from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

    from deerflow.subagents.config import SubagentConfig
    from deerflow.subagents.executor import (
        SubagentExecutor,
        SubagentResult,
        SubagentStatus,
    )

    executor_module = sys.modules["deerflow.subagents.executor"]

    # Most tests in this module patch _create_agent and exercise executor
    # control flow only. Keep those tests hermetic: CI checkouts do not include
    # the gitignored config.yaml, and deferral-specific tests override this
    # default explicitly.
    _patch_default_get_app_config(executor_module)

    # Store classes in a dict to yield
    classes = {
        "AIMessage": AIMessage,
        "HumanMessage": HumanMessage,
        "ToolMessage": ToolMessage,
        "SubagentConfig": SubagentConfig,
        "SubagentExecutor": SubagentExecutor,
        "SubagentResult": SubagentResult,
        "SubagentStatus": SubagentStatus,
    }

    yield classes

    # Cleanup: Restore original modules
    for name in _MOCKED_MODULE_NAMES:
        if original_modules[name] is not None:
            sys.modules[name] = original_modules[name]
        elif name in sys.modules:
            del sys.modules[name]

    # Restore executor module (conftest.py mock)
    if original_executor is not None:
        sys.modules["deerflow.subagents.executor"] = original_executor
    elif "deerflow.subagents.executor" in sys.modules:
        del sys.modules["deerflow.subagents.executor"]
    if original_tool_search is not None:
        sys.modules["deerflow.tools.builtins.tool_search"] = original_tool_search
    else:
        sys.modules.pop("deerflow.tools.builtins.tool_search", None)


# Helper classes that wrap real classes for testing
class MockHumanMessage:
    """Mock HumanMessage for testing - wraps real class from fixture."""

    def __init__(self, content, _classes=None):
        self._content = content
        self._classes = _classes

    def _get_real(self):
        return self._classes["HumanMessage"](content=self._content)


class MockAIMessage:
    """Mock AIMessage for testing - wraps real class from fixture."""

    def __init__(self, content, msg_id=None, _classes=None):
        self._content = content
        self._msg_id = msg_id
        self._classes = _classes

    def _get_real(self):
        msg = self._classes["AIMessage"](content=self._content)
        if self._msg_id:
            msg.id = self._msg_id
        return msg


class NamedTool:
    def __init__(self, name: str):
        self.name = name


def _skill(name: str, allowed_tools: list[str] | None) -> Skill:
    skill_dir = Path(f"/tmp/{name}")
    return Skill(
        name=name,
        description=f"{name} skill",
        license=None,
        skill_dir=skill_dir,
        skill_file=skill_dir / "SKILL.md",
        relative_path=Path(name),
        category="custom",
        allowed_tools=tuple(allowed_tools) if allowed_tools is not None else None,
        enabled=True,
    )


async def async_iterator(items):
    """Helper to create an async iterator from a list."""
    for item in items:
        yield item


# -----------------------------------------------------------------------------
# Fixtures
# -----------------------------------------------------------------------------


@pytest.fixture
def classes(_setup_executor_classes):
    """Provide access to executor classes."""
    return _setup_executor_classes


@pytest.fixture
def base_config(classes):
    """Return a basic subagent config for testing."""
    return classes["SubagentConfig"](
        name="test-agent",
        description="Test agent",
        system_prompt="You are a test agent.",
        max_turns=10,
        timeout_seconds=60,
    )


@pytest.fixture
def mock_agent():
    """Return a properly configured mock agent with async stream."""
    agent = MagicMock()
    agent.astream = MagicMock()
    return agent


def _module(name: str, **attrs):
    module = ModuleType(name)
    for key, value in attrs.items():
        setattr(module, key, value)
    return module


# Helper to create real message objects
class _MsgHelper:
    """Helper to create real message objects from fixture classes."""

    def __init__(self, classes):
        self.classes = classes

    def human(self, content):
        return self.classes["HumanMessage"](content=content)

    def ai(self, content, msg_id=None):
        msg = self.classes["AIMessage"](content=content)
        if msg_id:
            msg.id = msg_id
        return msg

    def tool(self, content, tool_call_id, name=None, msg_id=None):
        msg = self.classes["ToolMessage"](content=content, tool_call_id=tool_call_id, name=name)
        if msg_id:
            msg.id = msg_id
        return msg


@pytest.fixture
def msg(classes):
    """Provide message factory."""
    return _MsgHelper(classes)


# -----------------------------------------------------------------------------
# Agent Construction Tests
# -----------------------------------------------------------------------------


class TestAgentConstruction:
    """Test _create_agent() wiring before execution starts."""

    def test_create_agent_threads_explicit_app_config_to_model_and_middlewares(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """Explicit app_config must flow into both model and middleware factories."""
        import deerflow.config as config_module
        from deerflow.subagents import executor as executor_module

        SubagentExecutor = classes["SubagentExecutor"]

        app_config = SimpleNamespace(models=[SimpleNamespace(name="default-model")])
        model = object()
        middlewares = [object()]
        agent = object()
        captured: dict[str, dict] = {}

        def fake_get_app_config():
            raise AssertionError("ambient get_app_config() must not be used when app_config is explicit")

        def fake_create_chat_model(**kwargs):
            captured["model"] = kwargs
            return model

        def fake_build_subagent_runtime_middlewares(**kwargs):
            captured["middlewares"] = kwargs
            return middlewares

        def fake_create_agent(**kwargs):
            captured["agent"] = kwargs
            return agent

        monkeypatch.setattr(config_module, "get_app_config", fake_get_app_config)
        monkeypatch.setattr(
            executor_module,
            "create_chat_model",
            fake_create_chat_model,
        )
        monkeypatch.setattr(executor_module, "create_agent", fake_create_agent)
        monkeypatch.setitem(
            sys.modules,
            "deerflow.agents.middlewares.tool_error_handling_middleware",
            _module(
                "deerflow.agents.middlewares.tool_error_handling_middleware",
                build_subagent_runtime_middlewares=fake_build_subagent_runtime_middlewares,
            ),
        )

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            app_config=app_config,
            parent_model="parent-model",
        )
        provider = object()
        executor._authz_provider = provider

        result = executor._create_agent()

        assert result is agent
        assert captured["middlewares"]["authorization_provider"] is provider
        assert captured["model"] == {
            "name": "parent-model",
            "thinking_enabled": False,
            "app_config": app_config,
            # attach_tracing=False pairs with graph-root tracing callbacks
            # injected in _aexecute (see TestSubagentTracingWiring). Without
            # this the subagent would emit both a model-level trace and a
            # graph-level trace per call.
            "attach_tracing": False,
        }
        assert captured["middlewares"] == {
            "app_config": app_config,
            "model_name": "parent-model",
            "lazy_init": True,
            "deferred_setup": None,
            "agent_name": "test-agent",
            "available_skills": set(),
            "user_id": "default",
            "authorization_provider": provider,
        }
        assert captured["agent"]["model"] is model
        assert captured["agent"]["middleware"] is middlewares
        assert captured["agent"]["tools"] == []
        assert captured["agent"]["system_prompt"] is None  # system_prompt is merged into initial state messages

    @pytest.mark.anyio
    async def test_load_skills_uses_explicit_app_config_for_skill_storage(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path,
    ):
        """Explicit app_config must be threaded into subagent skill storage lookup."""
        SubagentExecutor = classes["SubagentExecutor"]

        app_config = SimpleNamespace(models=[SimpleNamespace(name="default-model")])
        skill_dir = tmp_path / "demo-skill"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text("Use demo skill", encoding="utf-8")
        captured: dict[str, object] = {}

        def fake_get_or_new_user_skill_storage(user_id, *, app_config=None):
            captured["user_id"] = user_id
            captured["app_config"] = app_config
            return SimpleNamespace(load_skills=lambda *, enabled_only: [SimpleNamespace(name="demo-skill", skill_file=skill_file)])

        monkeypatch.setattr(sys.modules["deerflow.skills.storage"], "get_or_new_user_skill_storage", fake_get_or_new_user_skill_storage)

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            app_config=app_config,
            thread_id="test-thread",
        )

        skills = await executor._load_skills()
        assert captured == {"user_id": "default", "app_config": app_config}
        assert [skill.name for skill in skills] == ["demo-skill"]

    @pytest.mark.anyio
    async def test_load_skills_uses_each_subagent_users_scoped_storage(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        SubagentExecutor = classes["SubagentExecutor"]
        app_config = SimpleNamespace(models=[SimpleNamespace(name="default-model")])
        storage_calls: list[tuple[str, object]] = []

        def user_storage(user_id: str, *, app_config=None):
            storage_calls.append((user_id, app_config))
            return SimpleNamespace(load_skills=lambda *, enabled_only: [SimpleNamespace(name="shared-skill", owner=user_id)])

        global_storage = MagicMock(side_effect=AssertionError("subagents must not read the global-only skill catalog"))
        monkeypatch.setattr(sys.modules["deerflow.skills.storage"], "get_or_new_skill_storage", global_storage)
        monkeypatch.setattr(sys.modules["deerflow.skills.storage"], "get_or_new_user_skill_storage", user_storage)

        alice = SubagentExecutor(config=base_config, tools=[], app_config=app_config, thread_id="alice-thread", user_id="alice")
        bob = SubagentExecutor(config=base_config, tools=[], app_config=app_config, thread_id="bob-thread", user_id="bob")

        alice_skills = await alice._load_skills()
        bob_skills = await bob._load_skills()

        assert [skill.owner for skill in alice_skills] == ["alice"]
        assert [skill.owner for skill in bob_skills] == ["bob"]
        assert storage_calls == [("alice", app_config), ("bob", app_config)]
        global_storage.assert_not_called()

    @pytest.mark.anyio
    async def test_load_skills_defaults_missing_user_to_default_scope(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        SubagentExecutor = classes["SubagentExecutor"]
        user_storage = MagicMock(return_value=SimpleNamespace(load_skills=lambda *, enabled_only: []))
        global_storage = MagicMock(side_effect=AssertionError("subagents must not read the global-only skill catalog"))
        monkeypatch.setattr(sys.modules["deerflow.skills.storage"], "get_or_new_skill_storage", global_storage)
        monkeypatch.setattr(sys.modules["deerflow.skills.storage"], "get_or_new_user_skill_storage", user_storage)

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread", user_id=None)

        assert await executor._load_skills() == []
        user_storage.assert_called_once_with("default")
        global_storage.assert_not_called()

    @pytest.mark.anyio
    async def test_build_initial_state_consolidates_system_prompt_and_skill_discovery(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path,
    ):
        """_build_initial_state merges system_prompt and skill discovery metadata."""
        SubagentExecutor = classes["SubagentExecutor"]

        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text("Skill instructions here", encoding="utf-8")

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: [SimpleNamespace(name="my-skill", skill_file=skill_file, allowed_tools=None)]),
        )

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")

        state, _final_tools, _deferred_setup = await executor._build_initial_state("Do the task")

        messages = state["messages"]
        # Should have exactly 2 messages: one combined SystemMessage + one HumanMessage
        assert len(messages) == 2

        from langchain_core.messages import HumanMessage, SystemMessage

        assert isinstance(messages[0], SystemMessage)
        assert isinstance(messages[1], HumanMessage)
        # SystemMessage should contain the prompt and discoverable skill name,
        # but not eagerly load the SKILL.md body.
        assert base_config.system_prompt in messages[0].content
        assert "my-skill" in messages[0].content
        assert "Skill instructions here" not in messages[0].content
        # HumanMessage should be the task
        assert messages[1].content == "Do the task"

    @pytest.mark.anyio
    async def test_build_initial_state_no_skills_only_system_prompt(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """_build_initial_state works when there are no skills."""
        SubagentExecutor = classes["SubagentExecutor"]

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: []),
        )

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        state, _final_tools, _deferred_setup = await executor._build_initial_state("Do the task")

        messages = state["messages"]
        from langchain_core.messages import HumanMessage, SystemMessage

        assert len(messages) == 2
        assert isinstance(messages[0], SystemMessage)
        assert base_config.system_prompt in messages[0].content
        assert isinstance(messages[1], HumanMessage)

    @pytest.mark.anyio
    async def test_build_initial_state_no_system_prompt_with_skills(
        self,
        classes,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path,
    ):
        """_build_initial_state works when there is no system_prompt but there are skills."""
        SubagentConfig = classes["SubagentConfig"]

        config = SubagentConfig(
            name="test-agent",
            description="Test agent",
            system_prompt=None,
            max_turns=10,
            timeout_seconds=60,
        )

        skill_dir = tmp_path / "my-skill"
        skill_dir.mkdir()
        skill_file = skill_dir / "SKILL.md"
        skill_file.write_text("Skill content", encoding="utf-8")

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: [SimpleNamespace(name="my-skill", skill_file=skill_file, allowed_tools=None)]),
        )

        SubagentExecutor = classes["SubagentExecutor"]
        executor = SubagentExecutor(config=config, tools=[], thread_id="test-thread")

        state, _final_tools, _deferred_setup = await executor._build_initial_state("Do the task")

        messages = state["messages"]
        from langchain_core.messages import HumanMessage, SystemMessage

        assert len(messages) == 2
        assert isinstance(messages[0], SystemMessage)
        assert "my-skill" in messages[0].content
        assert "Skill content" not in messages[0].content
        assert isinstance(messages[1], HumanMessage)

    @pytest.mark.anyio
    async def test_build_initial_state_defers_mcp_tools_when_tool_search_enabled(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """tool_search enabled + a surviving MCP tool: _build_initial_state appends
        the tool_search tool, withholds the MCP schema, and injects the
        <available-deferred-tools> section into the SystemMessage."""
        from langchain_core.tools import tool as as_tool

        from deerflow.subagents import executor as executor_module
        from deerflow.tools.mcp_metadata import tag_mcp_tool

        SubagentExecutor = classes["SubagentExecutor"]

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: []),
        )
        monkeypatch.setattr(
            executor_module,
            "get_app_config",
            lambda: SimpleNamespace(
                tool_search=SimpleNamespace(enabled=True),
                authorization=SimpleNamespace(enabled=False),
                skills=SimpleNamespace(deferred_discovery=True, container_path="/mnt/skills"),
            ),
        )

        @as_tool
        def mcp_calc(expression: str) -> str:
            "Evaluate arithmetic."
            return expression

        executor = SubagentExecutor(config=base_config, tools=[tag_mcp_tool(mcp_calc)], thread_id="test-thread")

        state, final_tools, deferred_setup = await executor._build_initial_state("Do the task")

        assert "tool_search" in [t.name for t in final_tools]
        assert deferred_setup.deferred_names == frozenset({"mcp_calc"})

        system_message = state["messages"][0]
        assert "<available-deferred-tools>" in system_message.content
        assert "mcp_calc" in system_message.content
        # The base system_prompt is still present alongside the injected section.
        assert base_config.system_prompt in system_message.content

    @pytest.mark.anyio
    async def test_build_initial_state_no_deferral_when_tool_search_disabled(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """tool_search disabled: no tool_search tool, no section - pure no-op even
        with an MCP-tagged tool present."""
        from langchain_core.tools import tool as as_tool

        from deerflow.subagents import executor as executor_module
        from deerflow.tools.mcp_metadata import tag_mcp_tool

        SubagentExecutor = classes["SubagentExecutor"]

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: []),
        )
        monkeypatch.setattr(
            executor_module,
            "get_app_config",
            lambda: SimpleNamespace(
                tool_search=SimpleNamespace(enabled=False),
                authorization=SimpleNamespace(enabled=False),
                skills=SimpleNamespace(deferred_discovery=True, container_path="/mnt/skills"),
            ),
        )

        @as_tool
        def mcp_calc(expression: str) -> str:
            "Evaluate arithmetic."
            return expression

        executor = SubagentExecutor(config=base_config, tools=[tag_mcp_tool(mcp_calc)], thread_id="test-thread")

        state, final_tools, deferred_setup = await executor._build_initial_state("Do the task")

        assert "tool_search" not in [t.name for t in final_tools]
        assert deferred_setup.deferred_names == frozenset()
        assert "<available-deferred-tools>" not in state["messages"][0].content

    @pytest.mark.anyio
    async def test_build_initial_state_applies_authorization_before_deferral(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        from deerflow.config.authorization_config import AuthorizationConfig, AuthorizationProviderConfig

        SubagentExecutor = classes["SubagentExecutor"]
        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_skill_storage",
            lambda *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: []),
        )
        app_config = SimpleNamespace(
            authorization=AuthorizationConfig(
                enabled=True,
                provider=AuthorizationProviderConfig(
                    use="deerflow.authz.rbac:RbacAuthorizationProvider",
                    config={"roles": {"user": {"tools": {"allow": ["safe_tool"]}}}},
                ),
            ),
            models=[SimpleNamespace(name="test-model")],
            tool_search=SimpleNamespace(enabled=False),
            skills=SimpleNamespace(deferred_discovery=True, container_path="/mnt/skills"),
        )
        executor = SubagentExecutor(
            config=base_config,
            tools=[NamedTool("safe_tool"), NamedTool("denied_tool")],
            app_config=app_config,
            parent_model="test-model",
            user_role="user",
            thread_id="test-thread",
        )

        _state, final_tools, deferred_setup = await executor._build_initial_state("Do the task")

        assert [tool.name for tool in final_tools] == ["safe_tool"]
        assert deferred_setup.deferred_names == frozenset()
        assert executor._authz_provider is not None

    @pytest.mark.anyio
    async def test_build_initial_state_deferral_respects_tool_policy_and_tool_search_is_infra(
        self,
        classes,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """Adversarial-review follow-up (#3341): tool_search is appended AFTER the
        subagent tool-policy filter, mirroring the lead's intentional decision
        (test_tool_search_appended_after_policy_but_never_exposes_denied_tool).
        Lock the safe-by-construction property:

        - an MCP tool denied by ``disallowed_tools`` never enters the deferred
          catalog, so tool_search can never promote/expose it;
        - tool_search itself is infrastructure: naming it in ``disallowed_tools``
          does not remove it, because its catalog derives from the already-
          filtered list and carries no access the policy didn't already grant.
        """
        from langchain_core.tools import tool as as_tool

        from deerflow.subagents import executor as executor_module
        from deerflow.tools.mcp_metadata import tag_mcp_tool

        SubagentConfig = classes["SubagentConfig"]
        SubagentExecutor = classes["SubagentExecutor"]

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: []),
        )
        monkeypatch.setattr(
            executor_module,
            "get_app_config",
            lambda: SimpleNamespace(
                tool_search=SimpleNamespace(enabled=True),
                authorization=SimpleNamespace(enabled=False),
                skills=SimpleNamespace(deferred_discovery=True, container_path="/mnt/skills"),
            ),
        )

        @as_tool
        def active_tool(x: str) -> str:
            "active"
            return x

        @as_tool
        def mcp_allowed(x: str) -> str:
            "allowed mcp tool"
            return x

        @as_tool
        def mcp_denied(x: str) -> str:
            "denied mcp tool"
            return x

        config = SubagentConfig(
            name="test-agent",
            description="Test agent",
            system_prompt="You are a test agent.",
            max_turns=10,
            timeout_seconds=60,
            disallowed_tools=["mcp_denied", "tool_search"],
        )
        executor = SubagentExecutor(
            config=config,
            tools=[active_tool, tag_mcp_tool(mcp_allowed), tag_mcp_tool(mcp_denied)],
            thread_id="test-thread",
        )

        _state, final_tools, deferred_setup = await executor._build_initial_state("Do the task")

        names = {t.name for t in final_tools}
        # The policy-denied MCP tool is gone and never reaches the catalog.
        assert "mcp_denied" not in names
        assert "mcp_denied" not in deferred_setup.deferred_names
        assert deferred_setup.deferred_names == frozenset({"mcp_allowed"})
        # tool_search is infra: present despite being named in disallowed_tools.
        assert "tool_search" in names

    def test_create_agent_threads_deferred_setup_to_middlewares(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
    ):
        """A deferred setup passed to _create_agent flows into the subagent
        middleware factory (so DeferredToolFilterMiddleware can attach)."""
        from deerflow.subagents import executor as executor_module
        from deerflow.tools.builtins.tool_search import DeferredToolSetup

        SubagentExecutor = classes["SubagentExecutor"]
        app_config = SimpleNamespace(models=[SimpleNamespace(name="default-model")], tool_search=SimpleNamespace(enabled=True, auto_promote_top_k=3))
        captured: dict[str, object] = {}

        def fake_build_subagent_runtime_middlewares(**kwargs):
            captured["middlewares"] = kwargs
            return [object()]

        monkeypatch.setattr(executor_module, "create_chat_model", lambda **kwargs: object())
        monkeypatch.setattr(executor_module, "create_agent", lambda **kwargs: object())
        monkeypatch.setitem(
            sys.modules,
            "deerflow.agents.middlewares.tool_error_handling_middleware",
            _module(
                "deerflow.agents.middlewares.tool_error_handling_middleware",
                build_subagent_runtime_middlewares=fake_build_subagent_runtime_middlewares,
            ),
        )

        deferred_setup = DeferredToolSetup(object(), frozenset({"mcp_calc"}), "hash123")
        executor = SubagentExecutor(config=base_config, tools=[], app_config=app_config, parent_model="parent-model")

        executor._create_agent(tools=[], deferred_setup=deferred_setup)

        assert captured["middlewares"]["deferred_setup"] is deferred_setup


# -----------------------------------------------------------------------------
# Async Execution Path Tests
# -----------------------------------------------------------------------------


class TestAsyncExecutionPath:
    """Test _aexecute() async execution path."""

    @pytest.mark.anyio
    async def test_aexecute_success(self, classes, base_config, mock_agent, msg):
        """Test successful async execution returns completed result."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_message = msg.ai("Task completed successfully", "msg-1")
        final_state = {
            "messages": [
                msg.human("Do something"),
                final_message,
            ]
        }
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "Task completed successfully"
        assert result.error is None
        assert result.started_at is not None
        assert result.completed_at is not None

    @pytest.mark.anyio
    async def test_aexecute_marks_capacity_rejection_as_admission_failure(self, classes, base_config):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        class RejectingSlot:
            async def __aenter__(self):
                raise SubagentCapacityRejected("Process-wide subagent capacity is full")

            async def __aexit__(self, exc_type, exc, traceback):
                return False

        class RejectingCapacity:
            def slot(self):
                return RejectingSlot()

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            execution_capacity=RejectingCapacity(),
        )

        result = await executor._aexecute("Do something")

        assert result.status == SubagentStatus.FAILED
        assert result.admission_failure is True
        assert "capacity is full" in result.error

    @pytest.mark.anyio
    async def test_aexecute_marks_structured_llm_error_fallback_as_failed(self, classes, base_config, mock_agent, msg):
        """A handled provider error is still a failed delegated task.

        ``LLMErrorHandlingMiddleware`` intentionally returns an ``AIMessage``
        instead of raising, so the executor must honor its structured marker
        rather than treating normal graph termination as task success.
        """
        AIMessage = classes["AIMessage"]
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        fallback_text = "LLM request failed: provider rejected the request"
        fallback_message = AIMessage(
            content=fallback_text,
            additional_kwargs={
                "deerflow_error_fallback": True,
                "error_type": "BadRequestError",
                "error_reason": "generic",
                "error_detail": "Error code: 400 - InvalidParameter",
            },
        )
        final_state = {"messages": [msg.human("Do something"), fallback_message]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Do something")

        assert result.status == SubagentStatus.FAILED
        assert result.error == fallback_text
        assert result.result is None
        assert result.stop_reason is None

    @pytest.mark.anyio
    async def test_aexecute_does_not_infer_llm_failure_from_message_text(self, classes, base_config, mock_agent, msg):
        """Error-looking prose without the middleware marker is valid output."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_text = "LLM request failed is the message shown by the previous system."
        final_state = {"messages": [msg.human("Explain the prior error"), msg.ai(final_text)]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Explain the prior error")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == final_text
        assert result.error is None

    @pytest.mark.anyio
    async def test_aexecute_ignores_stale_parent_history_fallback_marker(self, classes, base_config, mock_agent, msg):
        """A stale fallback marker replayed from parent history is not terminal.

        Subagents share the parent's ``thread_id`` and LangGraph replays the
        full parent message history, so ``final_state`` can carry a fallback
        ``AIMessage`` left by an earlier parent turn. Because the subagent
        always appends its own terminal assistant message, ``_extract_llm_error_fallback``
        inspects only the last ``AIMessage`` and must treat this run as a
        normal completion — this locks the "no masking needed" invariant that
        justifies scanning the tail instead of all messages.
        """
        AIMessage = classes["AIMessage"]
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        stale_fallback = AIMessage(
            content="LLM request failed: an earlier parent-history error",
            additional_kwargs={
                "deerflow_error_fallback": True,
                "error_type": "BadRequestError",
                "error_reason": "generic",
                "error_detail": "Error code: 400 - InvalidParameter",
            },
        )
        final_state = {"messages": [stale_fallback, msg.human("Do something"), msg.ai("real result")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "real result"
        assert result.error is None

    @pytest.mark.anyio
    async def test_aexecute_exposes_collected_usage_before_subagent_finishes(self, classes, base_config, mock_agent, msg, monkeypatch):
        """Polling callers can read a cumulative token snapshot while running."""
        from deerflow.subagents import executor as executor_module

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]
        collectors = []
        yielded = asyncio.Event()
        release = asyncio.Event()

        class Collector:
            def __init__(self, caller):
                self.records = []
                collectors.append(self)

            def snapshot_records(self):
                return list(self.records)

        async def streaming_agent(*args, **kwargs):
            collectors[0].records = [
                {
                    "source_run_id": "subagent-llm-1",
                    "caller": "subagent:test-agent",
                    "input_tokens": 100,
                    "output_tokens": 20,
                    "total_tokens": 120,
                }
            ]
            yielded.set()
            yield {"messages": [msg.human("Task"), msg.ai("Working", "m1")]}
            await release.wait()

        monkeypatch.setattr(executor_module, "SubagentTokenCollector", Collector)
        mock_agent.astream = streaming_agent
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        result_holder = SubagentResult(
            task_id="task-1",
            trace_id="trace-1",
            status=SubagentStatus.RUNNING,
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            running = asyncio.create_task(executor._aexecute("Task", result_holder=result_holder))
            await yielded.wait()
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            assert result_holder.status == SubagentStatus.RUNNING
            assert result_holder.token_usage_records == [
                {
                    "source_run_id": "subagent-llm-1",
                    "caller": "subagent:test-agent",
                    "input_tokens": 100,
                    "output_tokens": 20,
                    "total_tokens": 120,
                }
            ]
            release.set()
            await running

    @pytest.mark.anyio
    async def test_aexecute_collects_ai_messages(self, classes, base_config, mock_agent, msg):
        """Test that AI messages are collected during streaming."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        msg1 = msg.ai("First response", "msg-1")
        msg2 = msg.ai("Second response", "msg-2")

        chunk1 = {"messages": [msg.human("Task"), msg1]}
        chunk2 = {"messages": [msg.human("Task"), msg1, msg2]}

        mock_agent.astream = lambda *args, **kwargs: async_iterator([chunk1, chunk2])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert len(result.ai_messages) == 2
        assert result.ai_messages[0]["id"] == "msg-1"
        assert result.ai_messages[1]["id"] == "msg-2"

    @pytest.mark.anyio
    async def test_aexecute_handles_duplicate_messages(self, classes, base_config, mock_agent, msg):
        """Test that duplicate AI messages are not added."""
        SubagentExecutor = classes["SubagentExecutor"]

        msg1 = msg.ai("Response", "msg-1")

        # Same message appears in multiple chunks
        chunk1 = {"messages": [msg.human("Task"), msg1]}
        chunk2 = {"messages": [msg.human("Task"), msg1]}

        mock_agent.astream = lambda *args, **kwargs: async_iterator([chunk1, chunk2])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert len(result.ai_messages) == 1

    @pytest.mark.anyio
    async def test_aexecute_dedup_scales_over_repeated_chunks(self, classes, base_config, mock_agent, msg):
        """``stream_mode="values"`` re-yields the same trailing message across many
        snapshots before the next one appears. Dedup must collapse the repeats and
        still capture each distinct message exactly once, in arrival order."""
        SubagentExecutor = classes["SubagentExecutor"]

        m1 = msg.ai("first", "msg-1")
        m2 = msg.ai("second", "msg-2")
        m3 = msg.ai("third", "msg-3")
        # m1 is re-yielded as the trailing message several times before m2/m3 arrive.
        chunks = [
            {"messages": [msg.human("Task"), m1]},
            {"messages": [msg.human("Task"), m1]},
            {"messages": [msg.human("Task"), m1]},
            {"messages": [msg.human("Task"), m1, m2]},
            {"messages": [msg.human("Task"), m1, m2]},
            {"messages": [msg.human("Task"), m1, m2, m3]},
        ]
        mock_agent.astream = lambda *args, **kwargs: async_iterator(chunks)

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert [m["id"] for m in result.ai_messages] == ["msg-1", "msg-2", "msg-3"]

    @pytest.mark.anyio
    async def test_aexecute_dedup_idless_messages_fall_back_to_content(self, classes, base_config, mock_agent, msg):
        """Messages without an id can't be keyed by the seen-id set, so dedup must
        fall back to a full content compare: identical content collapses, distinct
        content is kept."""
        SubagentExecutor = classes["SubagentExecutor"]

        chunks = [
            {"messages": [msg.human("Task"), msg.ai("same")]},  # id-less
            {"messages": [msg.human("Task"), msg.ai("same")]},  # id-less, identical content -> dropped
            {"messages": [msg.human("Task"), msg.ai("different")]},  # id-less, distinct -> kept
        ]
        mock_agent.astream = lambda *args, **kwargs: async_iterator(chunks)

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert [m["content"] for m in result.ai_messages] == ["same", "different"]

    @pytest.mark.anyio
    async def test_aexecute_captures_all_tool_outputs_from_one_super_step(self, classes, base_config, mock_agent, msg):
        """Regression for #3779: when the model emits several tool calls in one
        turn, LangGraph's ToolNode appends all their ToolMessages in a single
        ``values`` super-step. Capturing only ``messages[-1]`` dropped every tool
        output but the last; all three must now survive in ``ai_messages``."""
        SubagentExecutor = classes["SubagentExecutor"]

        human = msg.human("Task")
        ai_turn = msg.ai("running three tools", "ai-1")
        t1 = msg.tool("result 1", "call_1", name="web_search", msg_id="tool-1")
        t2 = msg.tool("result 2", "call_2", name="read_file", msg_id="tool-2")
        t3 = msg.tool("result 3", "call_3", name="web_search", msg_id="tool-3")
        final = msg.ai("done", "ai-2")
        chunks = [
            {"messages": [human, ai_turn]},
            # One super-step appends all three ToolMessages at once.
            {"messages": [human, ai_turn, t1, t2, t3]},
            {"messages": [human, ai_turn, t1, t2, t3, final]},
        ]
        mock_agent.astream = lambda *args, **kwargs: async_iterator(chunks)

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert [m["id"] for m in result.ai_messages] == ["ai-1", "tool-1", "tool-2", "tool-3", "ai-2"]

    @pytest.mark.anyio
    async def test_aexecute_step_capture_survives_history_contraction(self, classes, base_config, mock_agent, msg):
        """Regression for #3875 Phase 3: DeerFlowSummarizationMiddleware rewrites the
        messages channel mid-run via ``RemoveMessage(id=REMOVE_ALL_MESSAGES)``,
        so a later ``values`` snapshot hands the executor a SHORTER message list
        than the cursor it was tracking. Without the contraction reset in
        ``capture_new_step_messages``, every step appended after the compaction
        is dropped until the list length overtakes the stale cursor.

        Faithful to the real middleware: compaction puts the summary into a
        SEPARATE ``summary_text`` state key — the messages channel after
        compaction holds only the preserved recent tail (already-seen
        messages), NOT a synthetic summary AIMessage. So the contraction chunk
        is the already-seen tail (deduped, no new step); the real regression
        coverage is that POST-compaction growth is still captured."""
        SubagentExecutor = classes["SubagentExecutor"]

        human = msg.human("Task")
        ai1 = msg.ai("turn one", "ai-1")
        tool1 = msg.tool("r1", "call_1", name="web_search", msg_id="tool-1")
        ai2 = msg.ai("turn two", "ai-2")  # also the preserved tail after compaction
        tool2 = msg.tool("r2", "call_2", name="read_file", msg_id="tool-2")
        final = msg.ai("final answer", "ai-3")

        chunks = [
            # Pre-compaction growth (cursor → 4).
            {"messages": [human, ai1]},
            {"messages": [human, ai1, tool1]},
            {"messages": [human, ai1, tool1, ai2]},
            # Compaction: channel rewrites to just the preserved tail (ai2) —
            # length drops from 4 to 1, below the cursor. ai2 is already seen
            # (deduped), so no new step is emitted. (The summary lives in
            # summary_text, out of channel.)
            {"messages": [ai2]},
            # Post-compaction growth — the bug: tool-2/final were dropped.
            {"messages": [ai2, tool2]},
            {"messages": [ai2, tool2, final]},
        ]
        mock_agent.astream = lambda *args, **kwargs: async_iterator(chunks)

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        # Pre-compaction steps survive (ai2 not re-emitted — deduped), and
        # crucially the post-compaction tool + final answer are NOT dropped.
        assert [m["id"] for m in result.ai_messages] == [
            "ai-1",
            "tool-1",
            "ai-2",
            "tool-2",
            "ai-3",
        ]

    @pytest.mark.anyio
    async def test_aexecute_handles_list_content(self, classes, base_config, mock_agent, msg):
        """Test handling of list-type content in AIMessage."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_message = msg.ai([{"text": "Part 1"}, {"text": "Part 2"}])
        final_state = {
            "messages": [
                msg.human("Task"),
                final_message,
            ]
        }
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert "Part 1" in result.result
        assert "Part 2" in result.result

    @pytest.mark.anyio
    async def test_aexecute_handles_agent_exception(self, classes, base_config, mock_agent):
        """Test that exceptions during execution are caught and returned as FAILED."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        mock_agent.astream.side_effect = Exception("Agent error")

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.FAILED
        assert "Agent error" in result.error
        assert result.completed_at is not None

    @pytest.mark.anyio
    async def test_aexecute_recursion_error_with_partial_surfaces_completed_turn_capped(self, classes, base_config, mock_agent, msg):
        """#3875 Phase 2: ``GraphRecursionError`` (``recursion_limit`` ==
        ``max_turns``) with usable partial work surfaces as ``completed`` +
        ``stop_reason=turn_capped`` — the partial work survives on ``result``
        the way a clean success does, and the cap travels on the additive
        ``stop_reason`` field, not a dedicated status enum (which would break v1
        contract consumers). Before #3949 this fell through to the generic
        ``except Exception`` and was misclassified as FAILED; #3949 then used a
        ``MAX_TURNS_REACHED`` enum that diverged from the agreed additive-field
        contract, which this change corrects."""
        from langgraph.errors import GraphRecursionError

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        partial_ai = msg.ai("Found 3 of 5 sources; still working", "msg-1")
        partial_state = {"messages": [msg.human("Task"), partial_ai]}

        async def mock_astream(*args, **kwargs):
            yield partial_state
            raise GraphRecursionError("Recursion limit of 10 reached")

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        # The partial work from the last streamed chunk is preserved, not dropped.
        assert result.result == "Found 3 of 5 sources; still working"
        # The cap is surfaced on the additive stop_reason field.
        assert result.stop_reason == "turn_capped"
        # completed suppresses the error blob; the cap lives on stop_reason only.
        assert result.error is None
        assert result.completed_at is not None

    @pytest.mark.anyio
    async def test_aexecute_recursion_error_prefers_guard_stop_reason_over_turn_capped(self, classes, base_config, mock_agent, msg):
        """If a guard (token budget / loop) already hard-stopped this run and
        set its stop reason, and ``GraphRecursionError`` then trips on the next
        super-step before the forced final answer lands, the exception handler
        surfaces the guard's reason (the binding constraint) instead of blindly
        falling back to ``turn_capped``. Keeps the exception path consistent
        with the normal-completion path (both consult
        ``_consume_guard_stop_reason``) and pops the reason so it is not
        orphaned in the guard's bounded dict."""
        from langgraph.errors import GraphRecursionError

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        partial_ai = msg.ai("Found 3 of 5 sources; still working", "msg-1")
        partial_state = {"messages": [msg.human("Task"), partial_ai]}

        async def mock_astream(*args, **kwargs):
            yield partial_state
            raise GraphRecursionError("Recursion limit reached after the token budget fired")

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        # A guard fired earlier this run and stamped token_capped.
        executor._stop_reason_middlewares = [SimpleNamespace(consume_stop_reason=lambda _run_id: "token_capped")]

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        # Guard reason wins; not the turn_capped fallback.
        assert result.stop_reason == "token_capped"
        assert result.result == "Found 3 of 5 sources; still working"

    @pytest.mark.anyio
    async def test_aexecute_recursion_error_before_first_chunk_surfaces_failed_turn_capped(self, classes, base_config, mock_agent):
        """If ``GraphRecursionError`` fires before any chunk is yielded there is
        no usable partial work to recover; the result is ``failed`` +
        ``stop_reason=turn_capped`` so the budget-cap signal survives even when
        nothing was streamed."""
        from langgraph.errors import GraphRecursionError

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        async def mock_astream(*args, **kwargs):
            raise GraphRecursionError("Recursion limit reached before first step")
            yield  # pragma: no cover - make this an async generator

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.FAILED
        assert result.stop_reason == "turn_capped"
        assert str(base_config.max_turns) in (result.error or "")
        assert result.completed_at is not None

    @pytest.mark.anyio
    async def test_aexecute_recursion_error_with_llm_error_fallback_surfaces_failed(self, classes, base_config, mock_agent, msg):
        """A structured LLM error fallback that coincides with hitting
        ``max_turns`` must still classify as ``failed``, not ``completed``.

        ``_extract_llm_error_fallback`` (#4042) marks a terminal ``AIMessage``
        as a handled provider failure via
        ``additional_kwargs.deerflow_error_fallback``, and the
        normal-completion branch above already consults it before falling
        back to ``_extract_final_result``. This except-block must apply the
        same check before recovering ``usable_partial`` from raw non-empty
        ``AIMessage`` text: a fallback message always carries non-empty
        user-facing text, so without checking the marker first it is
        indistinguishable from genuine partial output and gets misclassified
        as a completed task rather than the failed provider error it is.
        """
        from langgraph.errors import GraphRecursionError

        AIMessage = classes["AIMessage"]
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        fallback_text = "LLM request failed: provider rejected the request"
        fallback_message = AIMessage(
            content=fallback_text,
            additional_kwargs={
                "deerflow_error_fallback": True,
                "error_type": "BadRequestError",
                "error_reason": "generic",
                "error_detail": "Error code: 400 - InvalidParameter",
            },
        )
        fallback_state = {"messages": [msg.human("Task"), fallback_message]}

        async def mock_astream(*args, **kwargs):
            yield fallback_state
            raise GraphRecursionError("Recursion limit reached right after the LLM error fallback")

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.FAILED
        assert result.error == fallback_text
        assert result.result is None
        assert result.stop_reason == "turn_capped"

    @pytest.mark.anyio
    async def test_aexecute_token_capped_surfaces_completed_token_capped(self, classes, base_config, mock_agent, msg):
        """#3875 Phase 2: the token-budget hard-stop does not raise — it strips
        tool_calls so the run completes with a final answer. When the captured
        ``TokenBudgetMiddleware`` reports ``token_capped`` via
        ``consume_stop_reason``, the completed result carries
        ``stop_reason=token_capped`` so the lead can tell a budget-capped
        completion from a clean one."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_state = {"messages": [msg.human("Task"), msg.ai("partial final answer", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        # Simulate the hard-stop having fired: the captured guard reports
        # token_capped for this run. _create_agent is mocked below so the real
        # capture path is bypassed and this list is what _aexecute reads.
        executor._stop_reason_middlewares = [SimpleNamespace(consume_stop_reason=lambda _run_id: "token_capped")]

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "partial final answer"
        assert result.stop_reason == "token_capped"

    @pytest.mark.anyio
    async def test_aexecute_loop_capped_surfaces_when_loop_guard_fires(self, classes, base_config, mock_agent, msg):
        """#3875 Phase 2 (ggnnggez review): the executor collects EVERY guard
        middleware with ``consume_stop_reason``, not just the first. When the
        token-budget guard reports no cap but the loop-detection guard reports
        ``loop_capped``, the completed result carries ``stop_reason=loop_capped``
        — proving the contract's full cap vocabulary is reachable, not only the
        token axis. A ``next(...)`` capture would stop at the first guard and
        miss the loop cap entirely."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_state = {"messages": [msg.human("Task"), msg.ai("partial final answer", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        executor._stop_reason_middlewares = [
            SimpleNamespace(consume_stop_reason=lambda _run_id: None),
            SimpleNamespace(consume_stop_reason=lambda _run_id: "loop_capped"),
        ]

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "partial final answer"
        assert result.stop_reason == "loop_capped"

    @pytest.mark.anyio
    async def test_aexecute_no_final_state(self, classes, base_config, mock_agent):
        """Test handling when no final state is returned."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        mock_agent.astream = lambda *args, **kwargs: async_iterator([])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "No response generated"

    @pytest.mark.anyio
    async def test_aexecute_no_ai_message_in_state(self, classes, base_config, mock_agent, msg):
        """Test fallback when no AIMessage found in final state."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_state = {"messages": [msg.human("Task")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        # Should fallback to string representation of last message
        assert result.status == SubagentStatus.COMPLETED
        assert "Task" in result.result

    @pytest.mark.anyio
    async def test_aexecute_passes_at_most_one_system_message_to_agent(
        self,
        classes,
        base_config,
        monkeypatch: pytest.MonkeyPatch,
        tmp_path,
    ):
        """Regression: messages sent to agent.astream must contain at most one
        SystemMessage and it must be the first message.

        This catches any regression where system_prompt would be re-injected
        via create_agent() (e.g. system_prompt not passed as None) and appear
        as a second SystemMessage, which providers like vLLM and Xinference
        reject with "System message must be at the beginning."
        """
        from langchain_core.messages import AIMessage, SystemMessage

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        # Set up a skill so both system_prompt AND skill content are present,
        # maximising the chance of catching a double-SystemMessage regression.
        skill_dir = tmp_path / "regression-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("Skill instruction text", encoding="utf-8")

        monkeypatch.setattr(
            sys.modules["deerflow.skills.storage"],
            "get_or_new_user_skill_storage",
            lambda user_id, *, app_config=None: SimpleNamespace(load_skills=lambda *, enabled_only: [SimpleNamespace(name="regression-skill", skill_file=skill_dir / "SKILL.md", allowed_tools=None)]),
        )

        captured_states: list[dict] = []

        async def capturing_astream(state, **kwargs):
            captured_states.append(state)
            yield {"messages": [AIMessage(content="Done", id="msg-1")]}

        mock_agent = MagicMock()
        mock_agent.astream = capturing_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert len(captured_states) == 1, "astream should be called exactly once"
        initial_messages = captured_states[0]["messages"]

        system_messages = [m for m in initial_messages if isinstance(m, SystemMessage)]
        assert len(system_messages) <= 1, f"Expected at most 1 SystemMessage but got {len(system_messages)}: {system_messages}"
        if system_messages:
            assert initial_messages[0] is system_messages[0], "SystemMessage must be the first message in the conversation"
            # The consolidated SystemMessage carries the base prompt and skill
            # discovery metadata, while the body stays unloaded until activation.
            assert base_config.system_prompt in system_messages[0].content
            assert "regression-skill" in system_messages[0].content
            assert "Skill instruction text" not in system_messages[0].content


class TestSkillAllowedTools:
    @pytest.mark.anyio
    async def test_passive_skill_allowed_tools_do_not_filter_agent_tools(self, classes, base_config, mock_agent, msg):
        """Enabled skills are discoverable, not policy-active until loaded."""
        SubagentExecutor = classes["SubagentExecutor"]

        final_state = {"messages": [msg.human("Task"), msg.ai("Done", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])
        tools = [NamedTool("bash"), NamedTool("read_file"), NamedTool("write_file"), NamedTool("review_skill_package")]
        executor = SubagentExecutor(config=base_config, tools=tools, thread_id="test-thread")

        async def load_skills():
            return [_skill("skill-reviewer", ["review_skill_package"])]

        with patch.object(executor, "_load_skills", load_skills), patch.object(executor, "_create_agent", return_value=mock_agent) as create_agent_mock:
            await executor._aexecute("Task")

        create_agent_mock.assert_called_once()
        assert [tool.name for tool in create_agent_mock.call_args.args[0]] == ["bash", "read_file", "write_file", "review_skill_package", "describe_skill"]
        assert [tool.name for tool in executor.tools] == ["bash", "read_file", "write_file", "review_skill_package"]
        assert executor._available_skill_names == {"skill-reviewer"}

    @pytest.mark.anyio
    async def test_skill_load_failure_fails_without_creating_agent(self, classes, base_config, mock_agent):
        SubagentExecutor = classes["SubagentExecutor"]
        executor = SubagentExecutor(config=base_config, tools=[NamedTool("bash")], thread_id="test-thread")

        async def load_skills():
            raise RuntimeError("skill storage unavailable")

        with patch.object(executor, "_load_skills", load_skills), patch.object(executor, "_create_agent", return_value=mock_agent) as create_agent_mock:
            result = await executor._aexecute("Task")

        assert result.status == classes["SubagentStatus"].FAILED
        assert result.error == "skill storage unavailable"
        create_agent_mock.assert_not_called()


# -----------------------------------------------------------------------------
# Sync Execution Path Tests
# -----------------------------------------------------------------------------


class TestSyncExecutionPath:
    """Test execute() synchronous execution path with asyncio.run()."""

    def test_execute_runs_async_in_event_loop(self, classes, base_config, mock_agent, msg):
        """Test that execute() runs _aexecute() in a new event loop via asyncio.run()."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_message = msg.ai("Sync result", "msg-1")
        final_state = {
            "messages": [
                msg.human("Task"),
                final_message,
            ]
        }
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = executor.execute("Task")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "Sync result"

    def test_execute_in_thread_pool_context(self, classes, base_config, msg):
        """Test that execute() works correctly when called from a thread pool.

        This simulates the real-world usage where execute() is called from
        a worker thread outside the main event loop.
        """
        from concurrent.futures import ThreadPoolExecutor

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        final_message = msg.ai("Thread pool result", "msg-1")
        final_state = {
            "messages": [
                msg.human("Task"),
                final_message,
            ]
        }

        def run_in_thread():
            mock_agent = MagicMock()
            mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])

            executor = SubagentExecutor(
                config=base_config,
                tools=[],
                thread_id="test-thread",
            )

            with patch.object(executor, "_create_agent", return_value=mock_agent):
                return executor.execute("Task")

        # Execute in thread pool to simulate sync execution outside the main loop.
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(run_in_thread)
            result = future.result(timeout=5)

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "Thread pool result"

    @pytest.mark.anyio
    async def test_execute_in_running_event_loop_calls_isolated_loop_directly(self, classes, base_config, mock_agent, msg):
        """Test that execute() calls the isolated-loop helper directly in a running loop."""
        from deerflow.runtime.user_context import (
            get_effective_user_id,
            reset_current_user,
            set_current_user,
        )

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        caller_thread = threading.current_thread().name
        isolated_helper_threads = []
        execution_threads = []
        effective_user_ids = []
        final_state = {
            "messages": [
                msg.human("Task"),
                msg.ai("Async loop result", "msg-1"),
            ]
        }

        async def mock_astream(*args, **kwargs):
            execution_threads.append(threading.current_thread().name)
            effective_user_ids.append(get_effective_user_id())
            yield final_state

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        original_isolated_execute = executor._execute_in_isolated_loop

        def tracked_isolated_execute(task, result_holder=None):
            isolated_helper_threads.append(threading.current_thread().name)
            return original_isolated_execute(task, result_holder)

        token = set_current_user(SimpleNamespace(id="alice"))
        try:
            with patch.object(executor, "_create_agent", return_value=mock_agent):
                with patch.object(executor, "_execute_in_isolated_loop", side_effect=tracked_isolated_execute) as isolated:
                    result = executor.execute("Task")
        finally:
            reset_current_user(token)

        assert isolated.call_count == 1
        assert isolated_helper_threads == [caller_thread]
        assert execution_threads
        assert execution_threads == ["subagent-persistent-loop"]
        assert effective_user_ids == ["alice"]
        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "Async loop result"

    @pytest.mark.anyio
    async def test_execute_in_running_event_loop_reuses_persistent_isolated_loop(self, classes, base_config, mock_agent, msg):
        """Regression: repeated isolated executions should reuse one long-lived loop."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        execution_loops = []

        final_state = {
            "messages": [
                msg.human("Task"),
                msg.ai("Async loop result", "msg-1"),
            ]
        }

        async def mock_astream(*args, **kwargs):
            execution_loops.append(asyncio.get_running_loop())
            yield final_state

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            first = executor.execute("Task 1")
            second = executor.execute("Task 2")

        assert first.status == SubagentStatus.COMPLETED
        assert second.status == SubagentStatus.COMPLETED
        assert len(execution_loops) == 2
        assert execution_loops[0] is execution_loops[1]
        assert execution_loops[0].is_running()

    def test_execute_handles_asyncio_run_failure(self, classes, base_config):
        """Test handling when asyncio.run() itself fails."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_aexecute") as mock_aexecute:
            mock_aexecute.side_effect = Exception("Asyncio run error")

            result = executor.execute("Task")

        assert result.status == SubagentStatus.FAILED
        assert "Asyncio run error" in result.error
        assert result.completed_at is not None

    def test_execute_with_result_holder(self, classes, base_config, mock_agent, msg):
        """Test execute() updates provided result_holder in real-time."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        msg1 = msg.ai("Step 1", "msg-1")
        chunk1 = {"messages": [msg.human("Task"), msg1]}

        mock_agent.astream = lambda *args, **kwargs: async_iterator([chunk1])

        # Pre-create result holder (as done in execute_async)
        result_holder = SubagentResult(
            task_id="predefined-id",
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = executor.execute("Task", result_holder=result_holder)

        # Should be the same object
        assert result is result_holder
        assert result.task_id == "predefined-id"
        assert result.status == SubagentStatus.COMPLETED


# -----------------------------------------------------------------------------
# Async Tool Support Tests (MCP Tools)
# -----------------------------------------------------------------------------


class TestAsyncToolSupport:
    """Test that async-only tools (like MCP tools) work correctly."""

    @pytest.mark.anyio
    async def test_async_tool_called_in_astream(self, classes, base_config, msg):
        """Test that async tools are properly awaited in astream.

        This verifies the fix for: async MCP tools not being executed properly
        because they were being called synchronously.
        """
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        async_tool_calls = []

        async def mock_async_tool(*args, **kwargs):
            async_tool_calls.append("called")
            await asyncio.sleep(0.01)  # Simulate async work
            return {"result": "async tool result"}

        mock_agent = MagicMock()

        # Simulate agent that calls async tools during streaming
        async def mock_astream(*args, **kwargs):
            await mock_async_tool()
            yield {
                "messages": [
                    msg.human("Task"),
                    msg.ai("Done", "msg-1"),
                ]
            }

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task")

        assert len(async_tool_calls) == 1
        assert result.status == SubagentStatus.COMPLETED

    def test_sync_execute_with_async_tools(self, classes, base_config, msg):
        """Test that sync execute() properly runs async tools via asyncio.run()."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        async_tool_calls = []

        async def mock_async_tool():
            async_tool_calls.append("called")
            await asyncio.sleep(0.01)
            return {"result": "async result"}

        mock_agent = MagicMock()

        async def mock_astream(*args, **kwargs):
            await mock_async_tool()
            yield {
                "messages": [
                    msg.human("Task"),
                    msg.ai("Done", "msg-1"),
                ]
            }

        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = executor.execute("Task")

        assert len(async_tool_calls) == 1
        assert result.status == SubagentStatus.COMPLETED


# -----------------------------------------------------------------------------
# Thread Safety Tests
# -----------------------------------------------------------------------------


class TestThreadSafety:
    """Test thread safety of executor operations."""

    @pytest.fixture
    def executor_module(self, _setup_executor_classes):
        """Import the executor module with real classes."""
        executor = importlib.import_module("deerflow.subagents.executor")

        return _patch_default_get_app_config(importlib.reload(executor))

    def test_multiple_executors_in_parallel(self, classes, base_config, msg):
        """Test multiple executors running in parallel via thread pool."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        results = []

        def execute_task(task_id: int):
            def make_astream(*args, **kwargs):
                return async_iterator(
                    [
                        {
                            "messages": [
                                msg.human(f"Task {task_id}"),
                                msg.ai(f"Result {task_id}", f"msg-{task_id}"),
                            ]
                        }
                    ]
                )

            mock_agent = MagicMock()
            mock_agent.astream = make_astream

            executor = SubagentExecutor(
                config=base_config,
                tools=[],
                thread_id=f"thread-{task_id}",
            )

            with patch.object(executor, "_create_agent", return_value=mock_agent):
                return executor.execute(f"Task {task_id}")

        # Execute multiple tasks in parallel
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(execute_task, i) for i in range(5)]
            for future in as_completed(futures):
                results.append(future.result())

        assert len(results) == 5
        for result in results:
            assert result.status == SubagentStatus.COMPLETED
            assert "Result" in result.result

    def test_terminal_status_is_published_after_payload_fields(self, executor_module, monkeypatch):
        """Readers must not observe terminal status before terminal payload is complete."""
        SubagentResult = executor_module.SubagentResult
        SubagentStatus = executor_module.SubagentStatus

        now_entered = threading.Event()
        release_now = threading.Event()
        completed_at = datetime(2026, 5, 1, 12, 0, 0)
        writer_errors: list[BaseException] = []

        class BlockingDateTime:
            @staticmethod
            def now():
                now_entered.set()
                release_now.wait(timeout=5)
                return completed_at

        monkeypatch.setattr(executor_module, "datetime", BlockingDateTime)

        result = SubagentResult(
            task_id="test-terminal-publication-order",
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
        )
        token_usage_records = [
            {
                "source_run_id": "run-1",
                "caller": "subagent:test-agent",
                "input_tokens": 10,
                "output_tokens": 5,
                "total_tokens": 15,
            }
        ]
        tool_receipts = [{"id": "r1", "tool_call_id": "tc-1"}]

        def set_terminal():
            try:
                assert result.try_set_terminal(
                    SubagentStatus.COMPLETED,
                    result="done",
                    token_usage_records=token_usage_records,
                    tool_receipts=tool_receipts,
                )
            except BaseException as exc:
                writer_errors.append(exc)

        writer = threading.Thread(target=set_terminal)
        writer.start()

        assert now_entered.wait(timeout=3), "try_set_terminal did not reach completed_at assignment"
        assert result.completed_at is None
        assert result.status == SubagentStatus.RUNNING
        assert result.token_usage_records == token_usage_records
        assert result.tool_receipts == tool_receipts

        release_now.set()
        writer.join(timeout=3)

        assert not writer.is_alive(), "try_set_terminal did not finish"
        assert writer_errors == []
        assert result.completed_at == completed_at
        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "done"
        assert result.token_usage_records == token_usage_records
        assert result.tool_receipts == tool_receipts


# -----------------------------------------------------------------------------
# Cleanup Background Task Tests
# -----------------------------------------------------------------------------


class TestCleanupBackgroundTask:
    """Test cleanup_background_task function for race condition prevention."""

    @pytest.fixture
    def executor_module(self, _setup_executor_classes):
        """Import the executor module with real classes."""
        # Re-import to get the real module with cleanup_background_task
        executor = importlib.import_module("deerflow.subagents.executor")

        return _patch_default_get_app_config(importlib.reload(executor))

    def test_cleanup_removes_terminal_completed_task(self, executor_module, classes):
        """Test that cleanup removes a COMPLETED task."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        # Add a completed task
        task_id = "test-completed-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.COMPLETED,
            result="done",
            completed_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        # Cleanup should remove it
        executor_module.cleanup_background_task(task_id)

        assert task_id not in executor_module._background_tasks

    def test_cleanup_removes_terminal_failed_task(self, executor_module, classes):
        """Test that cleanup removes a FAILED task."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-failed-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.FAILED,
            error="error",
            completed_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        assert task_id not in executor_module._background_tasks

    def test_cleanup_removes_terminal_timed_out_task(self, executor_module, classes):
        """Test that cleanup removes a TIMED_OUT task."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-timedout-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.TIMED_OUT,
            error="timeout",
            completed_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        assert task_id not in executor_module._background_tasks

    def test_cleanup_skips_running_task(self, executor_module, classes):
        """Test that cleanup does NOT remove a RUNNING task.

        This prevents race conditions where task_tool calls cleanup
        while the background executor is still updating the task.
        """
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-running-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        # Should still be present because it's RUNNING
        assert task_id in executor_module._background_tasks

    def test_cleanup_skips_pending_task(self, executor_module, classes):
        """Test that cleanup does NOT remove a PENDING task."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-pending-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.PENDING,
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        assert task_id in executor_module._background_tasks

    def test_cleanup_handles_unknown_task_gracefully(self, executor_module):
        """Test that cleanup doesn't raise for unknown task IDs."""
        # Should not raise
        executor_module.cleanup_background_task("nonexistent-task")

    def test_cleanup_removes_task_with_completed_at_even_if_running(self, executor_module, classes):
        """Test that cleanup removes task if completed_at is set, even if status is RUNNING.

        This is a safety net: if completed_at is set, the task is considered done
        regardless of status.
        """
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-completed-at-task"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,  # Status not terminal
            completed_at=datetime.now(),  # But completed_at is set
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        # Should be removed because completed_at is set
        assert task_id not in executor_module._background_tasks


# -----------------------------------------------------------------------------
# Cooperative Cancellation Tests
# -----------------------------------------------------------------------------


class TestCooperativeCancellation:
    """Test cooperative cancellation via cancel_event."""

    @pytest.fixture
    def executor_module(self, _setup_executor_classes):
        """Import the executor module with real classes."""
        executor = importlib.import_module("deerflow.subagents.executor")

        return _patch_default_get_app_config(importlib.reload(executor))

    @pytest.mark.anyio
    async def test_aexecute_cancelled_before_streaming(self, classes, base_config, mock_agent, msg):
        """Test that _aexecute returns CANCELLED when cancel_event is set before streaming."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        # The agent should never be called
        call_count = 0

        async def mock_astream(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            yield {"messages": [msg.human("Task"), msg.ai("Done", "msg-1")]}

        mock_agent.astream = mock_astream

        # Pre-create result holder with cancel_event already set
        result_holder = SubagentResult(
            task_id="cancel-before",
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )
        result_holder.cancel_event.set()

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task", result_holder=result_holder)

        assert result.status == SubagentStatus.CANCELLED
        assert result.error == "Cancelled by user"
        assert result.completed_at is not None
        assert call_count == 0  # astream was never entered

    @pytest.mark.anyio
    async def test_aexecute_cancelled_mid_stream(self, classes, base_config, msg):
        """Test that _aexecute returns CANCELLED when cancel_event is set during streaming."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        cancel_event = threading.Event()

        async def mock_astream(*args, **kwargs):
            yield {"messages": [msg.human("Task"), msg.ai("Partial", "msg-1")]}
            # Simulate cancellation during streaming
            cancel_event.set()
            yield {"messages": [msg.human("Task"), msg.ai("Should not appear", "msg-2")]}

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream

        result_holder = SubagentResult(
            task_id="cancel-mid",
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )
        result_holder.cancel_event = cancel_event

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )

        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute("Task", result_holder=result_holder)

        assert result.status == SubagentStatus.CANCELLED
        assert result.error == "Cancelled by user"
        assert result.completed_at is not None

    def test_request_cancel_sets_event(self, executor_module, classes):
        """Test that request_cancel_background_task sets the cancel_event."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-cancel-event"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        assert not result.cancel_event.is_set()

        executor_module.request_cancel_background_task(task_id)

        assert result.cancel_event.is_set()

    def test_request_cancel_nonexistent_task_is_noop(self, executor_module):
        """Test that requesting cancellation on a nonexistent task does not raise."""
        executor_module.request_cancel_background_task("nonexistent-task")

    def test_execute_async_runs_without_calling_execute(self, executor_module, classes, base_config):
        """Regression: execute_async should not route through execute()/asyncio.run()."""
        import concurrent.futures

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        def run_coroutine(context, coroutine_factory):
            future = concurrent.futures.Future()
            try:
                future.set_result(context.run(lambda: asyncio.run(coroutine_factory())))
            except Exception as exc:
                future.set_exception(exc)
            return future

        async def fake_aexecute(task, result_holder=None):
            result = result_holder or SubagentResult(
                task_id="inline-task",
                trace_id="test-trace",
                status=SubagentStatus.RUNNING,
            )
            result.status = SubagentStatus.COMPLETED
            result.result = f"done: {task}"
            result.completed_at = datetime.now()
            return result

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )

        with (
            patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=run_coroutine),
            patch.object(executor, "_aexecute", side_effect=fake_aexecute),
            patch.object(executor, "execute", side_effect=AssertionError("execute() should not be called by execute_async")),
        ):
            task_id = executor.execute_async("Task")

        result = executor_module._background_tasks.get(task_id)
        assert result is not None
        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "done: Task"
        assert result.error is None

    def test_execute_async_isolates_duplicate_external_task_ids(self, executor_module, classes, base_config):
        """Concurrent runs must not share registry entries when provider IDs collide."""
        import concurrent.futures

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        def run_coroutine(context, coroutine_factory):
            future = concurrent.futures.Future()
            try:
                future.set_result(context.run(lambda: asyncio.run(coroutine_factory())))
            except Exception as exc:
                future.set_exception(exc)
            return future

        async def complete_a(_task, result_holder=None):
            result_holder.status = SubagentStatus.COMPLETED
            result_holder.result = "done-a"
            result_holder.completed_at = datetime.now()
            return result_holder

        async def complete_b(_task, result_holder=None):
            result_holder.status = SubagentStatus.COMPLETED
            result_holder.result = "done-b"
            result_holder.completed_at = datetime.now()
            return result_holder

        executor_a = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="thread-a",
            trace_id="trace-a",
        )
        executor_b = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="thread-b",
            trace_id="trace-b",
        )

        with (
            patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=run_coroutine),
            patch.object(executor_a, "_aexecute", side_effect=complete_a),
            patch.object(executor_b, "_aexecute", side_effect=complete_b),
        ):
            execution_a = executor_a.execute_async("Task A", task_id="same-provider-tool-call-id")
            execution_b = executor_b.execute_async("Task B", task_id="same-provider-tool-call-id")

            assert execution_a != execution_b
            assert executor_module._background_tasks[execution_a].trace_id == "trace-a"
            assert executor_module._background_tasks[execution_b].trace_id == "trace-b"

        assert executor_module._background_tasks[execution_a].result == "done-a"
        assert executor_module._background_tasks[execution_b].result == "done-b"

        result_a = executor_module._background_tasks[execution_a]
        result_b = executor_module._background_tasks[execution_b]
        executor_module.request_cancel_background_task(execution_a)
        assert result_a.cancel_event.is_set()
        assert not result_b.cancel_event.is_set()

        executor_module.cleanup_background_task(execution_a)
        assert execution_a not in executor_module._background_tasks
        assert executor_module._background_tasks[execution_b] is result_b
        executor_module.cleanup_background_task(execution_b)

    def test_execute_async_propagates_user_context_to_isolated_loop(self, executor_module, classes, base_config):
        """Regression: background subagent execution must keep request user context."""
        import concurrent.futures

        from deerflow.runtime.user_context import (
            get_effective_user_id,
            reset_current_user,
            set_current_user,
        )

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        async def fake_aexecute(task, result_holder=None):
            result = result_holder
            result.status = SubagentStatus.COMPLETED
            result.result = get_effective_user_id()
            result.completed_at = datetime.now()
            return result

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )

        def run_coroutine(context, coroutine_factory):
            future = concurrent.futures.Future()
            try:
                future.set_result(context.run(lambda: asyncio.run(coroutine_factory())))
            except Exception as exc:
                future.set_exception(exc)
            return future

        token = set_current_user(SimpleNamespace(id="alice"))
        try:
            with (
                patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=run_coroutine),
                patch.object(executor, "_aexecute", side_effect=fake_aexecute),
                patch.object(executor, "execute", side_effect=AssertionError("execute() should not be called by execute_async")),
            ):
                task_id = executor.execute_async("Task")
        finally:
            reset_current_user(token)

        result = executor_module._background_tasks.get(task_id)
        assert result is not None
        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "alice"
        assert result.error is None

    def test_execute_async_drops_parent_callbacks_at_isolated_loop_boundary(self, executor_module, classes, base_config):
        """Parent graph callbacks are loop-bound and must not enter the child loop."""
        import concurrent.futures

        from langchain_core.runnables.config import var_child_runnable_config
        from langgraph._internal._config import ensure_config

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        parent_callback = SimpleNamespace(deerflow_loop_bound=True)
        stream_callback = object()
        child_callback = object()
        observed: dict[str, object] = {}

        async def fake_aexecute(task, result_holder=None):
            effective = ensure_config({"callbacks": [child_callback]})
            observed["callbacks"] = effective["callbacks"]
            observed["configurable"] = effective["configurable"]
            result_holder.status = SubagentStatus.COMPLETED
            result_holder.result = "done"
            result_holder.completed_at = datetime.now()
            return result_holder

        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )

        def run_coroutine(context, coroutine_factory):
            future = concurrent.futures.Future()
            try:
                future.set_result(context.run(lambda: asyncio.run(coroutine_factory())))
            except Exception as exc:
                future.set_exception(exc)
            return future

        token = var_child_runnable_config.set(
            {
                "callbacks": [parent_callback, stream_callback],
                "configurable": {
                    "thread_id": "parent-thread",
                    "checkpoint_ns": "parent:task",
                },
            }
        )
        try:
            with (
                patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=run_coroutine),
                patch.object(executor, "_aexecute", side_effect=fake_aexecute),
            ):
                executor.execute_async("Task")
        finally:
            var_child_runnable_config.reset(token)

        assert child_callback in observed["callbacks"]
        assert parent_callback not in observed["callbacks"]
        assert stream_callback in observed["callbacks"]
        assert observed["configurable"] == {
            "thread_id": "parent-thread",
            "checkpoint_ns": "parent:task",
        }

    def test_isolated_context_filters_callback_manager_without_mutating_parent(self, executor_module):
        from langchain_core.callbacks.manager import AsyncCallbackManager
        from langchain_core.runnables.config import var_child_runnable_config

        loop_bound = SimpleNamespace(deerflow_loop_bound=True)
        stream_handler = object()
        manager = AsyncCallbackManager(
            handlers=[loop_bound, stream_handler],
            inheritable_handlers=[loop_bound, stream_handler],
        )
        token = var_child_runnable_config.set({"callbacks": manager})
        try:
            context = executor_module._copy_isolated_subagent_context()
        finally:
            var_child_runnable_config.reset(token)

        isolated_manager = context.get(var_child_runnable_config)["callbacks"]
        assert isolated_manager is not manager
        assert isolated_manager.handlers == [stream_handler]
        assert isolated_manager.inheritable_handlers == [stream_handler]
        assert manager.handlers == [loop_bound, stream_handler]
        assert manager.inheritable_handlers == [loop_bound, stream_handler]

    def test_timeout_does_not_overwrite_cancelled(self, executor_module, classes, base_config, msg):
        """Test that the real timeout handler does not overwrite CANCELLED status.

        This exercises the actual execute_async → run_task → FuturesTimeoutError
        code path in executor.py.  We make execute() block so the timeout fires
        deterministically, pre-set the task to CANCELLED, and verify the RUNNING
        guard preserves it.  Uses threading.Event for synchronisation instead of
        wall-clock sleeps.
        """
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        short_config = classes["SubagentConfig"](
            name="test-agent",
            description="Test agent",
            system_prompt="You are a test agent.",
            max_turns=10,
            timeout_seconds=0.05,  # 50ms – just enough for the future to time out
        )

        # Synchronisation primitives
        execute_entered = threading.Event()  # signals that _aexecute() has started

        # A blocking _aexecute() replacement so we control the timing exactly.
        async def blocking_aexecute(task, result_holder=None):
            execute_entered.set()
            await asyncio.Event().wait()

        executor = SubagentExecutor(
            config=short_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )

        with patch.object(executor, "_aexecute", side_effect=blocking_aexecute):
            task_id = executor.execute_async("Task")

            # Wait until _aexecute() is entered on the persistent loop.
            assert execute_entered.wait(timeout=3), "_aexecute() was never called"

            # Set CANCELLED on the result before the timeout handler runs.
            # The 50ms timeout will fire while execute() is blocked.
            with executor_module._background_tasks_lock:
                executor_module._background_tasks[task_id].status = SubagentStatus.CANCELLED
                executor_module._background_tasks[task_id].error = "Cancelled by user"
                executor_module._background_tasks[task_id].completed_at = datetime.now()

            deadline = time.monotonic() + 5
            while task_id in executor_module._background_futures and time.monotonic() < deadline:
                time.sleep(0.01)
            assert task_id not in executor_module._background_futures, "background coroutine did not finish"

        result = executor_module._background_tasks.get(task_id)
        assert result is not None
        # The RUNNING guard in the FuturesTimeoutError handler must have
        # preserved CANCELLED instead of overwriting with TIMED_OUT.
        assert result.status.value == SubagentStatus.CANCELLED.value
        assert result.error == "Cancelled by user"
        assert result.completed_at is not None

    def test_late_completion_after_timeout_does_not_overwrite_timed_out(self, executor_module, classes, msg):
        """Late completion from the execution worker must not overwrite TIMED_OUT."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        short_config = classes["SubagentConfig"](
            name="test-agent",
            description="Test agent",
            system_prompt="You are a test agent.",
            max_turns=10,
            timeout_seconds=0.05,
        )

        first_chunk_seen = threading.Event()
        finish_stream = threading.Event()
        execution_done = threading.Event()

        async def mock_astream(*args, **kwargs):
            yield {"messages": [msg.human("Task"), msg.ai("late completion", "msg-late")]}
            first_chunk_seen.set()
            deadline = asyncio.get_running_loop().time() + 5
            while not finish_stream.is_set():
                if asyncio.get_running_loop().time() >= deadline:
                    break
                await asyncio.sleep(0.001)

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream

        executor = SubagentExecutor(
            config=short_config,
            tools=[],
            thread_id="test-thread",
            trace_id="test-trace",
        )
        original_aexecute = executor._aexecute

        async def tracked_aexecute(task, result_holder=None):
            try:
                return await original_aexecute(task, result_holder)
            finally:
                execution_done.set()

        with patch.object(executor, "_create_agent", return_value=mock_agent), patch.object(executor, "_aexecute", tracked_aexecute):
            task_id = executor.execute_async("Task")
            assert first_chunk_seen.wait(timeout=3), "stream did not yield initial chunk"

            result = executor_module._background_tasks[task_id]
            assert result.cancel_event.wait(timeout=3), "timeout handler did not request cancellation"
            assert result.status.value == SubagentStatus.TIMED_OUT.value
            timed_out_error = result.error
            timed_out_completed_at = result.completed_at

            finish_stream.set()
            assert execution_done.wait(timeout=3), "execution worker did not finish"

        result = executor_module._background_tasks.get(task_id)
        assert result is not None
        assert result.status.value == SubagentStatus.TIMED_OUT.value
        assert result.result is None
        assert result.error == timed_out_error
        assert result.completed_at == timed_out_completed_at

    def test_cleanup_removes_cancelled_task(self, executor_module, classes):
        """Test that cleanup removes a CANCELLED task (terminal state)."""
        SubagentResult = classes["SubagentResult"]
        SubagentStatus = classes["SubagentStatus"]

        task_id = "test-cancelled-cleanup"
        result = SubagentResult(
            task_id=task_id,
            trace_id="test-trace",
            status=SubagentStatus.CANCELLED,
            error="Cancelled by user",
            completed_at=datetime.now(),
        )
        executor_module._background_tasks[task_id] = result

        executor_module.cleanup_background_task(task_id)

        assert task_id not in executor_module._background_tasks


# -----------------------------------------------------------------------------
# Subagent Tracing Wiring
# -----------------------------------------------------------------------------
#
# Regression coverage for the asymmetry fix: subagent runs must mirror the
# lead agent pattern so a single subagent execution produces one trace with
# the parent thread's session_id and user_id, not an isolated top-level trace.
# Three things must hold simultaneously:
#   1. ``build_tracing_callbacks()`` is appended to ``run_config["callbacks"]``
#      so the Langfuse handler sees ``on_chain_start(parent_run_id=None)`` and
#      actually promotes ``langfuse_*`` metadata onto the root trace.
#   2. ``inject_langfuse_metadata(run_config, ...)`` carries the parent
#      thread_id (-> session_id) and the captured user_id (-> user_id).
#   3. The subagent's model is built with ``attach_tracing=False`` so the
#      model-level handler does not double-count (covered separately by
#      ``test_create_agent_threads_explicit_app_config_to_model_and_middlewares``).


class _FakeStreamAgent:
    """Stand-in agent that records the ``config`` passed to ``astream``.

    Yields no chunks so ``_aexecute`` takes the ``final_state is None`` path
    and finishes without exercising message-handling code that is unrelated
    to the tracing wiring under test.
    """

    def __init__(self) -> None:
        self.captured_config: dict | None = None
        self.captured_context: dict | None = None

    async def astream(self, state, *, config, context, stream_mode):  # noqa: ARG002 - signature parity
        self.captured_config = config
        self.captured_context = context
        return
        yield  # pragma: no cover - make this an async generator


class TestSubagentCheckpointLineage:
    """Keep delegated graphs on the parent run's checkpoint lineage."""

    @pytest.mark.anyio
    async def test_aexecute_leaves_checkpoint_coordinates_to_parent_context(
        self,
        classes,
        monkeypatch,
    ):
        """A delegated graph must not declare a new root checkpoint lineage.

        LangGraph treats any explicitly supplied checkpoint coordinate as an
        independent lineage.  In particular, re-supplying the parent's own
        ``thread_id`` clears the ambient ``checkpoint_ns`` on LangGraph 1.2.6+,
        so the child is routed as a root graph instead of a subgraph.
        """
        executor_module = importlib.import_module("deerflow.subagents.executor")
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [])

        executor = classes["SubagentExecutor"](
            config=classes["SubagentConfig"](
                name="general-purpose",
                description="Checkpoint lineage test agent",
                system_prompt="You are a checkpoint lineage test agent.",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            parent_model="test-model",
            thread_id="parent-thread-1",
            trace_id="trace-lineage-1",
        )
        fake_agent = _FakeStreamAgent()

        async def build_initial_state(task):
            return ({"messages": [classes["HumanMessage"](content=task)]}, [], None)

        monkeypatch.setattr(executor, "_build_initial_state", build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *args, **kwargs: fake_agent)

        await executor._aexecute("do something")

        assert fake_agent.captured_config is not None
        configurable = fake_agent.captured_config.get("configurable") or {}
        checkpoint_coordinates = {
            "thread_id",
            "checkpoint_ns",
            "checkpoint_id",
            "checkpoint_map",
        }
        assert checkpoint_coordinates.isdisjoint(configurable), f"subagent invocation must inherit checkpoint coordinates from the parent context, got {configurable!r}"
        assert fake_agent.captured_context is not None
        assert fake_agent.captured_context["thread_id"] == "parent-thread-1"

    @pytest.mark.anyio
    @pytest.mark.skipif(
        not _LANGGRAPH_HAS_ROOT_LINEAGE_STREAM_REGRESSION,
        reason="root-lineage message leak only manifests on LangGraph >=1.2.6",
    )
    async def test_parent_message_stream_excludes_delegated_graph_messages(
        self,
        classes,
        monkeypatch,
    ):
        """Child AI/tool frames stay outside the parent's messages stream."""
        from langchain_core.messages import AIMessage, ToolMessage
        from langgraph.checkpoint.memory import MemorySaver
        from langgraph.graph import END, START, MessagesState, StateGraph

        executor_module = importlib.import_module("deerflow.subagents.executor")
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [])

        child_builder = StateGraph(MessagesState)
        child_builder.add_node(
            "child_model",
            lambda _state: {
                "messages": [
                    AIMessage(
                        content="",
                        id="child-ai-sentinel",
                        tool_calls=[
                            {
                                "name": "child_tool",
                                "args": {},
                                "id": "child-tool-call",
                                "type": "tool_call",
                            }
                        ],
                    )
                ]
            },
        )
        child_builder.add_node(
            "child_tool",
            lambda _state: {
                "messages": [
                    ToolMessage(
                        content="CHILD_TOOL_SENTINEL",
                        name="child_tool",
                        tool_call_id="child-tool-call",
                        id="child-tool-sentinel",
                    )
                ]
            },
        )
        child_builder.add_node(
            "child_final",
            lambda _state: {
                "messages": [
                    AIMessage(
                        content="CHILD_FINAL_SENTINEL",
                        id="child-final-sentinel",
                    )
                ]
            },
        )
        child_builder.add_edge(START, "child_model")
        child_builder.add_edge("child_model", "child_tool")
        child_builder.add_edge("child_tool", "child_final")
        child_builder.add_edge("child_final", END)
        child_graph = child_builder.compile(checkpointer=False)

        executor = classes["SubagentExecutor"](
            config=classes["SubagentConfig"](
                name="general-purpose",
                description="Stream isolation test agent",
                system_prompt="You are a stream isolation test agent.",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            parent_model="test-model",
            thread_id="parent-thread-1",
            trace_id="trace-stream-isolation-1",
        )

        async def build_initial_state(task):
            return ({"messages": [classes["HumanMessage"](content=task)]}, [], None)

        monkeypatch.setattr(executor, "_build_initial_state", build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *args, **kwargs: child_graph)

        async def delegate(_state):
            task_id = executor.execute_async("run the child graph")
            try:
                deadline = asyncio.get_running_loop().time() + 5
                while True:
                    result = executor_module.get_background_task_result(task_id)
                    if result is not None and result.status.is_terminal:
                        break
                    if asyncio.get_running_loop().time() >= deadline:
                        pytest.fail("background subagent did not complete")
                    await asyncio.sleep(0.001)
                assert result.status.value == "completed"
            finally:
                executor_module.cleanup_background_task(task_id)
            return {
                "messages": [
                    AIMessage(
                        content="PARENT_FINAL_SENTINEL",
                        id="parent-final-sentinel",
                    )
                ]
            }

        parent_builder = StateGraph(MessagesState)
        parent_builder.add_node("delegate", delegate)
        parent_builder.add_edge(START, "delegate")
        parent_builder.add_edge("delegate", END)
        parent_graph = parent_builder.compile(checkpointer=MemorySaver())

        streamed_messages = [
            message
            async for message, _metadata in parent_graph.astream(
                {"messages": [classes["HumanMessage"](content="delegate")]},
                config={"configurable": {"thread_id": "parent-thread-1"}},
                stream_mode="messages",
            )
        ]

        streamed_ids = {message.id for message in streamed_messages}
        assert "parent-final-sentinel" in streamed_ids
        assert (
            not {
                "child-ai-sentinel",
                "child-tool-sentinel",
                "child-final-sentinel",
            }
            & streamed_ids
        )


class TestSubagentTracingWiring:
    """Verify the subagent graph-root tracing wiring matches the lead agent."""

    @pytest.fixture
    def executor_module(self, _setup_executor_classes):
        executor = importlib.import_module("deerflow.subagents.executor")
        return _patch_default_get_app_config(importlib.reload(executor))

    @pytest.fixture(autouse=True)
    def _clear_langfuse_env(self, monkeypatch):
        """Reset tracing config and env between tests so monkeypatched env
        vars do not leak across tests in this class or the rest of the suite.
        """
        from deerflow.config.tracing_config import reset_tracing_config

        for name in ("LANGFUSE_TRACING", "LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY", "LANGFUSE_BASE_URL"):
            monkeypatch.delenv(name, raising=False)
        reset_tracing_config()
        yield
        reset_tracing_config()

    def _make_executor(self, classes, *, user_id=None, name="general-purpose", parent_model="test-model", deerflow_trace_id=None):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        config = SubagentConfig(
            name=name,
            description="Tracing test agent",
            system_prompt="You are a tracing test agent.",
            max_turns=5,
            timeout_seconds=30,
        )
        return SubagentExecutor(
            config=config,
            tools=[],
            parent_model=parent_model,
            thread_id="thread-trace-1",
            trace_id="trace-1",
            user_id=user_id,
            deerflow_trace_id=deerflow_trace_id,
        )

    @pytest.mark.anyio
    async def test_aexecute_appends_tracing_callbacks_to_run_config(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """``build_tracing_callbacks()`` output must be appended (not replace)
        to the existing callbacks so the SubagentTokenCollector keeps working.
        """
        SubagentStatus = classes["SubagentStatus"]

        sentinel_handler = object()
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [sentinel_handler])

        executor = self._make_executor(classes, user_id="alice")
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        result = await executor._aexecute("do something")

        assert fake_agent.captured_config is not None
        callbacks = fake_agent.captured_config.get("callbacks") or []
        assert sentinel_handler in callbacks, "tracing handler must reach run_config['callbacks']"
        # SubagentTokenCollector must survive the append (graph-root tracing
        # cannot displace the token-accounting callback).
        assert len(callbacks) >= 2, "existing callbacks must be preserved when tracing is injected"
        assert result.status.value == SubagentStatus.COMPLETED.value

    @pytest.mark.anyio
    async def test_aexecute_injects_langfuse_session_user_and_trace_name(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """When Langfuse is enabled, ``run_config['metadata']`` must carry the
        parent thread_id (-> session_id), the constructor-supplied user_id, and
        a ``subagent:<name>`` trace name so the subagent trace groups under
        the parent thread's session card.
        """
        monkeypatch.setenv("LANGFUSE_TRACING", "true")
        monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
        monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
        from deerflow.config.tracing_config import reset_tracing_config

        reset_tracing_config()

        class _Sentinel:
            pass

        sentinel = _Sentinel()
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [sentinel])

        executor = self._make_executor(classes, user_id="alice", name="general_purpose", deerflow_trace_id="gateway-trace-sub")
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        metadata = (fake_agent.captured_config or {}).get("metadata") or {}
        assert metadata.get("langfuse_session_id") == "thread-trace-1", "subagent trace must inherit parent thread_id as session_id"
        assert metadata.get("langfuse_user_id") == "alice", "subagent trace must carry the user_id captured at task_tool layer"
        # Underscores are normalized to hyphens so the trace name matches the
        # lead-agent naming shape.
        assert metadata.get("langfuse_trace_name") == "subagent:general-purpose"
        assert metadata.get("deerflow_trace_id") == "gateway-trace-sub"
        assert fake_agent.captured_context.get("deerflow_trace_id") == "gateway-trace-sub"
        tags = metadata.get("langfuse_tags") or []
        assert any(t.startswith("model:") for t in tags), "model tag must be emitted for cost attribution"

    @pytest.mark.anyio
    async def test_aexecute_skips_langfuse_metadata_when_disabled(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """When Langfuse is not in the enabled providers, ``inject_langfuse_metadata``
        must be a no-op and ``run_config['metadata']`` must not carry langfuse_*
        keys. LangSmith-only deployments are unaffected.
        """
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [])

        executor = self._make_executor(classes, user_id="alice")
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        metadata = (fake_agent.captured_config or {}).get("metadata") or {}
        for key in ("langfuse_session_id", "langfuse_user_id", "langfuse_trace_name", "langfuse_tags"):
            assert key not in metadata, f"{key} must be absent when Langfuse is disabled"

    @pytest.mark.anyio
    async def test_user_id_defaults_when_not_supplied(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """When ``user_id`` is None at construction (parent did not capture
        one), the tracing layer must fall back to DEFAULT_USER_ID so the
        Langfuse Users page still groups the trace.
        """
        monkeypatch.setenv("LANGFUSE_TRACING", "true")
        monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
        monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
        from deerflow.config.tracing_config import reset_tracing_config

        reset_tracing_config()
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [object()])

        executor = self._make_executor(classes, user_id=None)
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        metadata = (fake_agent.captured_config or {}).get("metadata") or {}
        # DEFAULT_USER_ID is "default" (see deerflow.runtime.user_context).
        assert metadata.get("langfuse_user_id") == "default"

    @pytest.mark.anyio
    async def test_trace_name_falls_back_when_config_name_empty(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """A subagent config without ``name`` must still produce a non-empty
        trace name so Langfuse does not render the trace as unnamed.
        """
        monkeypatch.setenv("LANGFUSE_TRACING", "true")
        monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
        monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
        from deerflow.config.tracing_config import reset_tracing_config

        reset_tracing_config()
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [object()])

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        config = SubagentConfig(
            name="",  # empty name exercises the fallback branch
            description="No name",
            system_prompt="",
            max_turns=5,
            timeout_seconds=30,
        )
        executor = SubagentExecutor(
            config=config,
            tools=[],
            thread_id="thread-trace-2",
            trace_id="trace-2",
        )
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        metadata = (fake_agent.captured_config or {}).get("metadata") or {}
        assert metadata.get("langfuse_trace_name") == "subagent"

    @pytest.mark.anyio
    async def test_environment_tag_emitted_from_deer_flow_env(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """``DEER_FLOW_ENV`` must surface as an ``env:<value>`` tag so Langfuse
        cost aggregation can split traces by deployment environment.
        """
        monkeypatch.setenv("LANGFUSE_TRACING", "true")
        monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-test")
        monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-test")
        monkeypatch.setenv("DEER_FLOW_ENV", "staging")
        from deerflow.config.tracing_config import reset_tracing_config

        reset_tracing_config()
        monkeypatch.setattr(executor_module, "build_tracing_callbacks", lambda: [object()])

        executor = self._make_executor(classes, user_id="alice")
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        metadata = (fake_agent.captured_config or {}).get("metadata") or {}
        tags = metadata.get("langfuse_tags") or []
        assert "env:staging" in tags

    async def _noop_build_initial_state(self, task):  # noqa: ARG002 - signature parity
        """Return a minimal state tuple so ``_aexecute`` reaches ``astream``
        without loading skills, MCP tools, or the real config.
        """
        from langchain_core.messages import HumanMessage

        return ({"messages": [HumanMessage(content=task)]}, [], None)


class TestSubagentGuardrailAttribution:
    """GuardrailMiddleware runs on subagents too, so the authenticated runtime
    context captured at the lead-agent layer must reach the subagent's own
    ``astream`` context — otherwise delegated tool calls are evaluated with
    ``user_role=None`` and role-aware policy silently mis-attributes them.
    """

    @pytest.fixture
    def executor_module(self, _setup_executor_classes):
        executor = importlib.import_module("deerflow.subagents.executor")
        return _patch_default_get_app_config(importlib.reload(executor))

    def _make_executor(
        self,
        classes,
        *,
        user_id=None,
        user_role=None,
        oauth_provider=None,
        oauth_id=None,
        run_id=None,
        name="general-purpose",
        parent_model="test-model",
    ):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        config = SubagentConfig(
            name=name,
            description="Guardrail attribution test agent",
            system_prompt="You are a guardrail attribution test agent.",
            max_turns=5,
            timeout_seconds=30,
        )
        return SubagentExecutor(
            config=config,
            tools=[],
            parent_model=parent_model,
            thread_id="thread-attrib-1",
            trace_id="trace-attrib-1",
            user_id=user_id,
            user_role=user_role,
            oauth_provider=oauth_provider,
            oauth_id=oauth_id,
            run_id=run_id,
        )

    @pytest.mark.anyio
    async def test_aexecute_propagates_attribution_to_subagent_context(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """The authenticated runtime context captured at task_tool must reach
        the subagent's ``astream`` context so GuardrailMiddleware sees the
        same identity/attribution as the lead agent.
        """
        executor = self._make_executor(
            classes,
            user_id="alice",
            user_role="admin",
            oauth_provider="keycloak",
            oauth_id="subj-123",
            run_id="run-42",
        )
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None, "subagent context must be passed to astream"
        assert context.get("user_id") == "alice"
        assert context.get("user_role") == "admin"
        assert context.get("oauth_provider") == "keycloak"
        assert context.get("oauth_id") == "subj-123"
        assert context.get("run_id") == "run-42"
        assert context.get("is_subagent") is True

    @pytest.mark.anyio
    async def test_aexecute_propagates_channel_user_id_to_subagent_context(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """The IM-channel sender identity captured at task_tool must reach the
        subagent's ``astream`` context so delegated bash commands export the
        dispatching turn's ``DEERFLOW_CHANNEL_USER_ID`` (group chats share one
        thread across senders)."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        executor = SubagentExecutor(
            config=SubagentConfig(
                name="general-purpose",
                description="Channel identity test agent",
                system_prompt="You are a channel identity test agent.",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            parent_model="test-model",
            thread_id="thread-channel-1",
            trace_id="trace-channel-1",
            channel_user_id="ou_group_sender_1",
        )
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None
        assert context.get("channel_user_id") == "ou_group_sender_1"

    @pytest.mark.anyio
    async def test_aexecute_context_defaults_to_none_when_attribution_absent(
        self,
        classes,
        executor_module,
        monkeypatch,
    ):
        """When no authenticated context is propagated (e.g. internal-auth
        runs), the subagent context still carries the attribution keys as
        None so GuardrailRequest fields stay None rather than KeyError-ing.
        """
        executor = self._make_executor(classes)
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None
        assert context.get("user_role") is None
        assert context.get("oauth_provider") is None
        assert context.get("oauth_id") is None
        assert context.get("run_id") is None

    async def _noop_build_initial_state(self, task):  # noqa: ARG002 - signature parity
        from langchain_core.messages import HumanMessage

        return ({"messages": [HumanMessage(content=task)]}, [], None)

    @pytest.mark.anyio
    async def test_aexecute_writes_is_internal_true(
        self,
        classes,
        monkeypatch,
    ):
        """is_internal=True must propagate to subagent context."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        executor = SubagentExecutor(
            config=SubagentConfig(
                name="general-purpose",
                description="is_internal test",
                system_prompt="test",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            thread_id="t1",
            is_internal=True,
        )
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None
        assert context.get("is_internal") is True

    @pytest.mark.anyio
    async def test_aexecute_writes_is_internal_false(
        self,
        classes,
        monkeypatch,
    ):
        """is_internal=False must be written explicitly, not omitted."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        executor = SubagentExecutor(
            config=SubagentConfig(
                name="general-purpose",
                description="is_internal false test",
                system_prompt="test",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            thread_id="t1",
            is_internal=False,
        )
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None
        assert context.get("is_internal") is False

    @pytest.mark.anyio
    async def test_aexecute_copies_attributes_on_writeback(
        self,
        classes,
        monkeypatch,
    ):
        """authz_attributes must be copied on write-back; mutating context copy
        doesn't affect executor's internal copy."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        source_attributes = {"dept": "eng"}
        executor = SubagentExecutor(
            config=SubagentConfig(
                name="general-purpose",
                description="attributes copy test",
                system_prompt="test",
                max_turns=5,
                timeout_seconds=30,
            ),
            tools=[],
            thread_id="t1",
            authz_attributes=source_attributes,
        )
        source_attributes["dept"] = "changed-before-run"
        assert executor.authz_attributes == {"dept": "eng"}
        fake_agent = _FakeStreamAgent()
        monkeypatch.setattr(executor, "_build_initial_state", self._noop_build_initial_state)
        monkeypatch.setattr(executor, "_create_agent", lambda *a, **kw: fake_agent)

        await executor._aexecute("do something")

        context = fake_agent.captured_context
        assert context is not None
        assert context.get("authz_attributes") == {"dept": "eng"}
        # Mutate the context copy
        context["authz_attributes"]["dept"] = "changed"
        # Executor's internal copy should be unaffected
        assert executor.authz_attributes["dept"] == "eng"

    def test_executor_rejects_non_mapping_attributes(self, classes):
        """Constructor must raise TypeError for non-Mapping authz_attributes."""
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentConfig = classes["SubagentConfig"]
        with pytest.raises(TypeError, match="authz_attributes must be a Mapping"):
            SubagentExecutor(
                config=SubagentConfig(
                    name="general-purpose",
                    description="test",
                    system_prompt="test",
                    max_turns=5,
                    timeout_seconds=30,
                ),
                tools=[],
                authz_attributes=["not", "a", "mapping"],
            )


class TestToolReceiptHarvest:
    """RFC #4651 PR2: the executor harvests the child's receipts at terminal."""

    class _ImmediateSlot:
        async def __aenter__(self):
            return None

        async def __aexit__(self, exc_type, exc, traceback):
            return False

    class _ImmediateCapacity:
        def slot(self):
            return TestToolReceiptHarvest._ImmediateSlot()

    class _ThreadSubmitter:
        """Run submitted coroutines on test-owned threads, not global loops."""

        def __init__(self):
            self.threads = []

        def submit(self, context, coroutine_factory):
            from concurrent.futures import Future

            future = Future()

            def run():
                try:
                    value = context.run(lambda: asyncio.run(coroutine_factory()))
                except BaseException as exc:
                    if not future.cancelled():
                        future.set_exception(exc)
                else:
                    if not future.cancelled():
                        future.set_result(value)

            thread = threading.Thread(target=run, daemon=True)
            self.threads.append(thread)
            thread.start()
            return future

        def close(self):
            for thread in self.threads:
                thread.join(timeout=3)
                assert not thread.is_alive()

    def test_harvest_uses_current_scan_when_latest_chunk_ends_in_tool_result(self, classes, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        latest = [{"id": "r1", "tool_call_id": "tc-latest"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: [],
            extract_tool_receipts=lambda messages: latest,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        state = {
            "messages": [
                msg.ai("Earlier report", "msg-1"),
                msg.tool("latest output", "tc-latest", name="write_file"),
            ]
        }

        assert executor_module._harvest_tool_receipts(state) == latest

    def test_completed_tool_ended_partial_prefers_bounded_citing_snapshot(self, classes, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        bounded = [{"id": "r24", "tool_call_id": "tc-cited"}]
        latest = [
            {"id": "r1", "tool_call_id": "tc-omitted"},
            {"id": "r31", "tool_call_id": "tc-latest"},
        ]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: bounded,
            extract_tool_receipts=lambda messages: latest,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        state = {
            "messages": [
                msg.ai("Partial report [r24]", "msg-1"),
                msg.tool("latest output", "tc-latest", name="write_file"),
            ]
        }

        assert executor_module._harvest_tool_receipts(state) == latest
        assert executor_module._harvest_tool_receipts(state, prefer_citing_turn=True) == bounded

    def test_completed_result_does_not_fallback_when_citing_snapshot_is_invalid(self, classes, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        current = [{"id": "r1", "tool_call_id": "tc-renumbered"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: None,
            extract_tool_receipts=lambda messages: current,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        state = {"messages": [msg.ai("Completed report [r1]", "msg-1")]}

        assert executor_module._harvest_tool_receipts(state) == current
        assert executor_module._harvest_tool_receipts(state, prefer_citing_turn=True) is None

    @pytest.mark.anyio
    async def test_recursion_capped_tool_ended_partial_persists_bounded_citing_snapshot(
        self,
        classes,
        base_config,
        msg,
        monkeypatch,
    ):
        from langgraph.errors import GraphRecursionError

        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        bounded = [{"id": "r24", "tool_call_id": "tc-cited"}]
        latest = [{"id": "r1", "tool_call_id": "tc-omitted"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: bounded,
            extract_tool_receipts=lambda messages: latest,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        final_state = {
            "messages": [
                msg.ai("Partial report [r24]", "msg-1"),
                msg.tool("latest output", "tc-latest", name="write_file"),
            ]
        }

        async def mock_astream(*args, **kwargs):
            yield final_state
            raise GraphRecursionError("turn limit")

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream
        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
        )
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.result == "Partial report [r24]"
        assert result.tool_receipts == bounded

    @pytest.mark.anyio
    async def test_aexecute_harvests_tool_receipts_on_completion(self, classes, base_config, mock_agent, msg, monkeypatch):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        harvested = [
            {
                "id": "r1",
                "tool_call_id": "tc-1",
                "tool_name": "write_file",
                "status": "success",
                "args_sha256": "a" * 16,
                "output_sha256": "b" * 16,
                "output_bytes": 3,
                "created_at": "2026-08-24T00:00:00+00:00",
            }
        ]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)

        final_state = {
            "messages": [
                msg.human("Do something"),
                msg.tool("out", "tc-1", name="write_file"),
                msg.ai("Done [r1]", "msg-1"),
            ]
        }
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.tool_receipts == harvested

    @pytest.mark.anyio
    async def test_aexecute_cancelled_before_stream_has_no_receipts(self, classes, base_config, mock_agent, msg):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        holder = classes["SubagentResult"](
            task_id="t1",
            trace_id="tr",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )
        holder.cancel_event.set()
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with patch.object(executor, "_create_agent", return_value=mock_agent):
            result = await executor._aexecute_admitted("Do something", result_holder=holder)

        assert result.status == SubagentStatus.CANCELLED
        assert result.tool_receipts is None

    @pytest.mark.anyio
    async def test_aexecute_harvests_receipt_from_chunk_yielded_after_cancellation(self, classes, base_config, msg, monkeypatch):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        harvested = [
            {
                "id": "r1",
                "tool_call_id": "tc-1",
                "tool_name": "write_file",
                "status": "success",
                "args_sha256": "a" * 16,
                "output_sha256": "b" * 16,
                "output_bytes": 3,
                "created_at": "2026-08-24T00:00:00+00:00",
            }
        ]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested if messages[-1].id == "msg-2" else None,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)

        holder = classes["SubagentResult"](
            task_id="cancel-after-tool",
            trace_id="tr",
            status=SubagentStatus.RUNNING,
            started_at=datetime.now(),
        )

        async def mock_astream(*args, **kwargs):
            yield {"messages": [msg.human("Task"), msg.ai("Working", "msg-1")]}
            holder.cancel_event.set()
            yield {"messages": [msg.human("Task"), msg.tool("out", "tc-1", name="write_file"), msg.ai("Done [r1]", "msg-2")]}

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something", result_holder=holder)

        assert result.status == SubagentStatus.CANCELLED
        assert result.tool_receipts == harvested

    def test_execute_async_preserves_published_receipts_on_forced_cancellation(self, classes, base_config, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        harvested = [{"id": "r1", "tool_call_id": "tc-1"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        chunk_seen = threading.Event()

        async def mock_astream(*args, **kwargs):
            yield {"messages": [msg.human("Task"), msg.tool("out", "tc-1", name="write_file")]}
            chunk_seen.set()
            while True:
                await asyncio.sleep(0.001)
                yield {"messages": [msg.human("Task"), msg.tool("out", "tc-1", name="write_file")]}

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream
        executor = SubagentExecutor(
            config=base_config,
            tools=[],
            thread_id="test-thread",
            extensions=SimpleNamespace(needs_task_store=False, has_task_lifecycle=False),
            execution_capacity=self._ImmediateCapacity(),
        )
        submitter = self._ThreadSubmitter()
        try:
            with (
                patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=submitter.submit),
                patch.object(executor_module, "build_tracing_callbacks", return_value=[]),
                patch.object(executor_module, "inject_langfuse_metadata"),
                patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
                patch.object(executor, "_create_agent", return_value=mock_agent),
            ):
                task_id = executor.execute_async("Do something")
                assert chunk_seen.wait(timeout=3)
                executor_module.request_cancel_background_task(task_id)
                deadline = time.monotonic() + 3
                while not executor_module._background_tasks[task_id].status.is_terminal and time.monotonic() < deadline:
                    time.sleep(0.01)
        finally:
            submitter.close()

        result = executor_module._background_tasks[task_id]
        assert result.status == SubagentStatus.CANCELLED
        assert result.tool_receipts == harvested

    def test_execute_async_preserves_published_receipts_on_timeout(self, classes, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        short_config = classes["SubagentConfig"](
            name="test-agent",
            description="Test agent",
            system_prompt="You are a test agent.",
            max_turns=10,
            timeout_seconds=0.05,
        )
        harvested = [{"id": "r1", "tool_call_id": "tc-1"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        chunk_seen = threading.Event()

        async def mock_astream(*args, **kwargs):
            yield {"messages": [msg.human("Task"), msg.tool("out", "tc-1", name="write_file")]}
            chunk_seen.set()
            await asyncio.Event().wait()

        mock_agent = MagicMock()
        mock_agent.astream = mock_astream
        executor = SubagentExecutor(
            config=short_config,
            tools=[],
            thread_id="test-thread",
            extensions=SimpleNamespace(needs_task_store=False, has_task_lifecycle=False),
            execution_capacity=self._ImmediateCapacity(),
        )
        submitter = self._ThreadSubmitter()
        try:
            with (
                patch.object(executor_module, "_submit_to_isolated_loop_in_context", side_effect=submitter.submit),
                patch.object(executor_module, "build_tracing_callbacks", return_value=[]),
                patch.object(executor_module, "inject_langfuse_metadata"),
                patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
                patch.object(executor, "_create_agent", return_value=mock_agent),
            ):
                task_id = executor.execute_async("Do something")
                assert chunk_seen.wait(timeout=3)
                deadline = time.monotonic() + 3
                while task_id in executor_module._background_futures and time.monotonic() < deadline:
                    time.sleep(0.01)
        finally:
            submitter.close()

        result = executor_module._background_tasks[task_id]
        assert result.status == SubagentStatus.TIMED_OUT
        assert result.tool_receipts == harvested

    @pytest.mark.anyio
    async def test_harvest_skipped_when_receipts_disabled(self, classes, base_config, mock_agent, msg, monkeypatch):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        harvested = [
            {
                "id": "r1",
                "tool_call_id": "tc-1",
                "tool_name": "write_file",
                "status": "success",
                "args_sha256": "a",
                "output_sha256": "b",
                "output_bytes": 3,
                "created_at": "t",
            }
        ]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)

        app_config = _default_app_config()
        app_config.models = [SimpleNamespace(name="default-model")]
        app_config.verification = SimpleNamespace(receipts_enabled=False)
        final_state = {"messages": [msg.human("Do something"), msg.ai("Done", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread", app_config=app_config)
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.tool_receipts is None

    @pytest.mark.anyio
    async def test_harvest_honors_globally_resolved_disabled_receipts(self, classes, base_config, mock_agent, msg, monkeypatch):
        executor_module = importlib.import_module("deerflow.subagents.executor")
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]
        harvested = [{"id": "r1", "tool_call_id": "tc-1"}]
        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=lambda messages: harvested,
            extract_tool_receipts=lambda messages: harvested,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)
        resolved_config = _default_app_config()
        resolved_config.verification = SimpleNamespace(receipts_enabled=False)
        monkeypatch.setattr(executor_module, "get_app_config", lambda: resolved_config)

        final_state = {"messages": [msg.human("Do something"), msg.ai("Done", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something")

        assert executor.app_config is None
        assert executor._get_resolved_app_config() is resolved_config
        assert result.status == SubagentStatus.COMPLETED
        assert result.tool_receipts is None

    @pytest.mark.anyio
    async def test_harvest_failure_never_breaks_execution(self, classes, base_config, mock_agent, msg, monkeypatch):
        SubagentExecutor = classes["SubagentExecutor"]
        SubagentStatus = classes["SubagentStatus"]

        def _explode(messages):
            raise RuntimeError("boom")

        fake_tool_receipt = _module(
            "deerflow.agents.middlewares.tool_receipt",
            extract_citing_turn_receipts=_explode,
            extract_tool_receipts=_explode,
        )
        monkeypatch.setitem(sys.modules, "deerflow.agents.middlewares.tool_receipt", fake_tool_receipt)

        final_state = {"messages": [msg.human("Do something"), msg.ai("Done", "msg-1")]}
        mock_agent.astream = lambda *args, **kwargs: async_iterator([final_state])
        executor = SubagentExecutor(config=base_config, tools=[], thread_id="test-thread")
        with (
            patch.object(executor, "_build_initial_state", new=AsyncMock(return_value=({}, [], None))),
            patch.object(executor, "_create_agent", return_value=mock_agent),
        ):
            result = await executor._aexecute_admitted("Do something")

        assert result.status == SubagentStatus.COMPLETED
        assert result.tool_receipts is None
