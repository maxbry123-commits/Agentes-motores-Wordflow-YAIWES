import type { Logger } from '@repo/shared';
import type { ITransport, RouteTransportMode } from './transport';

/**
 * Minimal interface for container fetch functionality
 */
export interface ContainerStub {
  containerFetch(
    url: string,
    options: RequestInit,
    port?: number
  ): Promise<Response>;

  /**
   * Fetch that can handle WebSocket upgrades (routes through parent Container class).
   * Required for WebSocket transport to establish control plane connections.
   */
  fetch(request: Request): Promise<Response>;
}

/**
 * Shared HTTP client configuration options
 */
export interface HttpClientOptions {
  logger?: Logger;
  baseUrl?: string;
  port?: number;
  stub?: ContainerStub;
  onCommandComplete?: (
    success: boolean,
    exitCode: number,
    stdout: string,
    stderr: string,
    command: string
  ) => void;
  onError?: (error: string, command?: string) => void;

  /**
   * Route-based transport mode: 'http' (default) or 'websocket'.
   * WebSocket mode multiplexes HTTP API requests over a single connection.
   */
  transportMode?: RouteTransportMode;

  /**
   * WebSocket URL for WebSocket transport mode.
   * Required when transportMode is 'websocket'.
   */
  wsUrl?: string;

  /**
   * Shared transport instance (for internal use).
   * When provided, clients will use this transport instead of creating their own.
   */
  transport?: ITransport;

  /**
   * Total retry budget in milliseconds for retryable transport responses.
   * Used for WebSocket upgrade retries and HTTP 503 startup retries.
   * Passed through to the transport layer. Defaults to 120_000 (2 minutes).
   */
  retryTimeoutMs?: number;

  /**
   * Headers merged into every outgoing container request.
   * Used to propagate stable context (e.g. sandboxId) from the Durable Object
   * to the container so container logs carry the same identifiers as DO logs.
   */
  defaultHeaders?: Record<string, string>;
}

/**
 * Base response interface for all API responses
 */
export interface BaseApiResponse {
  success: boolean;
  timestamp: string;
}

/**
 * Standard error response structure - matches BaseHandler.createErrorResponse()
 */
export interface ApiErrorResponse {
  success: false;
  error: string;
  code: string;
  details?: any;
  timestamp: string;
}

/**
 * Validation error response structure - matches ValidationMiddleware
 */
export interface ValidationErrorResponse {
  error: string;
  message: string;
  details?: any[];
  timestamp: string;
}

/**
 * Legacy error response interface - deprecated, use ApiErrorResponse
 */
export interface ErrorResponse {
  error: string;
  details?: string;
  code?: string;
}

/**
 * HTTP request configuration
 */
export interface RequestConfig extends RequestInit {
  endpoint: string;
  data?: Record<string, any>;
}

/**
 * Typed response handler
 */
export type ResponseHandler<T> = (response: Response) => Promise<T>;

/**
 * Common session-aware request interface
 */
export interface SessionRequest {
  sessionId?: string;
}
