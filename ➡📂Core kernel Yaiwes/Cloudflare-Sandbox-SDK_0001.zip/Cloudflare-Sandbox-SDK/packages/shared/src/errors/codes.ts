/**
 * Centralized error code registry
 * Each code maps to a specific error type with consistent semantics
 */
export const ErrorCode = {
  // File System Errors (404)
  FILE_NOT_FOUND: 'FILE_NOT_FOUND',

  // Permission Errors (403)
  PERMISSION_DENIED: 'PERMISSION_DENIED',

  // File System Errors (409)
  FILE_EXISTS: 'FILE_EXISTS',

  // File System Errors (400)
  IS_DIRECTORY: 'IS_DIRECTORY',
  NOT_DIRECTORY: 'NOT_DIRECTORY',

  // File Too Large Errors (413)
  FILE_TOO_LARGE: 'FILE_TOO_LARGE',

  // File System Errors (500)
  NO_SPACE: 'NO_SPACE',
  TOO_MANY_FILES: 'TOO_MANY_FILES',
  RESOURCE_BUSY: 'RESOURCE_BUSY',
  READ_ONLY: 'READ_ONLY',
  NAME_TOO_LONG: 'NAME_TOO_LONG',
  TOO_MANY_LINKS: 'TOO_MANY_LINKS',
  FILESYSTEM_ERROR: 'FILESYSTEM_ERROR',

  // Command Errors (404)
  COMMAND_NOT_FOUND: 'COMMAND_NOT_FOUND',

  // Command Errors (403/400)
  COMMAND_PERMISSION_DENIED: 'COMMAND_PERMISSION_DENIED',
  INVALID_COMMAND: 'INVALID_COMMAND',

  // Command Errors (500)
  COMMAND_EXECUTION_ERROR: 'COMMAND_EXECUTION_ERROR',
  STREAM_START_ERROR: 'STREAM_START_ERROR',

  // Process Errors (404)
  PROCESS_NOT_FOUND: 'PROCESS_NOT_FOUND',

  // Process Errors (403/500)
  PROCESS_PERMISSION_DENIED: 'PROCESS_PERMISSION_DENIED',
  PROCESS_ERROR: 'PROCESS_ERROR',

  // Session Errors (409)
  SESSION_ALREADY_EXISTS: 'SESSION_ALREADY_EXISTS',

  // Session Errors (410)
  SESSION_DESTROYED: 'SESSION_DESTROYED',
  SESSION_TERMINATED: 'SESSION_TERMINATED',

  // Port Errors (409)
  PORT_ALREADY_EXPOSED: 'PORT_ALREADY_EXPOSED',
  PORT_IN_USE: 'PORT_IN_USE',

  // Port Errors (404)
  PORT_NOT_EXPOSED: 'PORT_NOT_EXPOSED',

  // Port Errors (400)
  INVALID_PORT_NUMBER: 'INVALID_PORT_NUMBER',
  INVALID_PORT: 'INVALID_PORT',

  // Port Errors (502/500)
  SERVICE_NOT_RESPONDING: 'SERVICE_NOT_RESPONDING',
  PORT_OPERATION_ERROR: 'PORT_OPERATION_ERROR',

  // Port Errors (400)
  CUSTOM_DOMAIN_REQUIRED: 'CUSTOM_DOMAIN_REQUIRED',

  // Git Errors (404)
  GIT_REPOSITORY_NOT_FOUND: 'GIT_REPOSITORY_NOT_FOUND',
  GIT_BRANCH_NOT_FOUND: 'GIT_BRANCH_NOT_FOUND',

  // Git Errors (401)
  GIT_AUTH_FAILED: 'GIT_AUTH_FAILED',

  // Git Errors (502)
  GIT_NETWORK_ERROR: 'GIT_NETWORK_ERROR',

  // Git Errors (400)
  INVALID_GIT_URL: 'INVALID_GIT_URL',

  // Git Errors (500)
  GIT_CLONE_FAILED: 'GIT_CLONE_FAILED',
  GIT_CHECKOUT_FAILED: 'GIT_CHECKOUT_FAILED',
  GIT_OPERATION_FAILED: 'GIT_OPERATION_FAILED',

  // Bucket mounting errors
  BUCKET_MOUNT_ERROR: 'BUCKET_MOUNT_ERROR',
  BUCKET_UNMOUNT_ERROR: 'BUCKET_UNMOUNT_ERROR',
  S3FS_MOUNT_ERROR: 'S3FS_MOUNT_ERROR',
  MISSING_CREDENTIALS: 'MISSING_CREDENTIALS',
  INVALID_MOUNT_CONFIG: 'INVALID_MOUNT_CONFIG',

  // Backup Errors (500)
  BACKUP_CREATE_FAILED: 'BACKUP_CREATE_FAILED',
  BACKUP_RESTORE_FAILED: 'BACKUP_RESTORE_FAILED',

  // Backup Errors (404)
  BACKUP_NOT_FOUND: 'BACKUP_NOT_FOUND',

  // Backup Errors (400)
  BACKUP_EXPIRED: 'BACKUP_EXPIRED',
  INVALID_BACKUP_CONFIG: 'INVALID_BACKUP_CONFIG',

  // Code Interpreter Errors (503)
  INTERPRETER_NOT_READY: 'INTERPRETER_NOT_READY',

  // Code Interpreter Errors (404)
  CONTEXT_NOT_FOUND: 'CONTEXT_NOT_FOUND',

  // Code Interpreter Errors (500)
  CODE_EXECUTION_ERROR: 'CODE_EXECUTION_ERROR',

  // Code Interpreter Errors (501) - Feature not available in image variant
  PYTHON_NOT_AVAILABLE: 'PYTHON_NOT_AVAILABLE',
  JAVASCRIPT_NOT_AVAILABLE: 'JAVASCRIPT_NOT_AVAILABLE',

  // OpenCode Errors (503)
  OPENCODE_STARTUP_FAILED: 'OPENCODE_STARTUP_FAILED',

  // Process Readiness Errors (408/500)
  PROCESS_READY_TIMEOUT: 'PROCESS_READY_TIMEOUT',
  PROCESS_EXITED_BEFORE_READY: 'PROCESS_EXITED_BEFORE_READY',

  // File Watch Errors (404)
  WATCH_NOT_FOUND: 'WATCH_NOT_FOUND',

  // File Watch Errors (500)
  WATCH_START_ERROR: 'WATCH_START_ERROR',
  WATCH_STOP_ERROR: 'WATCH_STOP_ERROR',

  // Validation Errors (400)
  VALIDATION_FAILED: 'VALIDATION_FAILED',

  // Generic Errors (400/500)
  INVALID_JSON_RESPONSE: 'INVALID_JSON_RESPONSE',
  UNKNOWN_ERROR: 'UNKNOWN_ERROR',
  INTERNAL_ERROR: 'INTERNAL_ERROR',

  // RPC Transport Errors (503) — capnweb WebSocket session-level failures
  // raised on the SDK side, not by the container. The container went away
  // mid-call (peer close), the WebSocket failed before/after upgrade, the
  // peer sent a frame the transport cannot handle, or the session was
  // disposed while a call was in flight.
  RPC_TRANSPORT_ERROR: 'RPC_TRANSPORT_ERROR',

  // Container Availability Errors (503) — raised when the sandbox container
  // is not yet ready to accept requests or was replaced while a connection
  // attempt was in progress. Always retryable from the caller's perspective.
  CONTAINER_UNAVAILABLE: 'CONTAINER_UNAVAILABLE',

  // Operation Lifecycle Errors (409) — raised when a sandbox-owned operation
  // (e.g. backup restore) was interrupted by a runtime replacement or sandbox
  // lifetime change after the operation had already been admitted. The caller
  // should retry the full operation from the beginning.
  OPERATION_INTERRUPTED: 'OPERATION_INTERRUPTED'
} as const;

export type ErrorCode = (typeof ErrorCode)[keyof typeof ErrorCode];
