from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.mcp_type_0 import McpType0
    from ..models.sandbox_auto_resume_config import SandboxAutoResumeConfig
    from ..models.sandbox_iam import SandboxIam
    from ..models.sandbox_network_config import SandboxNetworkConfig
    from ..models.sandbox_volume_mount import SandboxVolumeMount


T = TypeVar("T", bound="NewSandbox")


@_attrs_define
class NewSandbox:
    """
    Attributes:
        template_id (str): Identifier of the required template
        timeout (Union[Unset, int]): Time to live for the sandbox in seconds. Default: 15.
        auto_pause (Union[Unset, bool]): Automatically pauses the sandbox after the timeout Default: False.
        auto_pause_memory (Union[Unset, bool]): Controls the snapshot kind taken when the sandbox auto-pauses on timeout
            (only relevant when autoPause is true). When false, the auto-pause drops the in-memory state and persists only
            the filesystem (a filesystem-only snapshot); resuming it cold-boots (reboots) the sandbox from disk. Such a
            snapshot cannot be auto-resumed by traffic and must be resumed explicitly, so it cannot be combined with
            autoResume. Defaults to true (full memory snapshot). Default: True.
        auto_resume (Union[Unset, SandboxAutoResumeConfig]): Auto-resume configuration for paused sandboxes.
        secure (Union[Unset, bool]): Secure all system communication with sandbox
        allow_internet_access (Union[Unset, bool]): Allow sandbox to access the internet. When set to false, it behaves
            the same as specifying denyOut to 0.0.0.0/0 in the network config.
        network (Union[Unset, SandboxNetworkConfig]):
        metadata (Union[Unset, Any]):
        env_vars (Union[Unset, Any]):
        mcp (Union['McpType0', None, Unset]): MCP configuration for the sandbox
        iam (Union[Unset, SandboxIam]): Sandbox workload identity configuration. A non-empty, valid tokens map enables
            workload identity for the sandbox.
        volume_mounts (Union[Unset, list['SandboxVolumeMount']]):
    """

    template_id: str
    timeout: Union[Unset, int] = 15
    auto_pause: Union[Unset, bool] = False
    auto_pause_memory: Union[Unset, bool] = True
    auto_resume: Union[Unset, "SandboxAutoResumeConfig"] = UNSET
    secure: Union[Unset, bool] = UNSET
    allow_internet_access: Union[Unset, bool] = UNSET
    network: Union[Unset, "SandboxNetworkConfig"] = UNSET
    metadata: Union[Unset, Any] = UNSET
    env_vars: Union[Unset, Any] = UNSET
    mcp: Union["McpType0", None, Unset] = UNSET
    iam: Union[Unset, "SandboxIam"] = UNSET
    volume_mounts: Union[Unset, list["SandboxVolumeMount"]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.mcp_type_0 import McpType0

        template_id = self.template_id

        timeout = self.timeout

        auto_pause = self.auto_pause

        auto_pause_memory = self.auto_pause_memory

        auto_resume: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.auto_resume, Unset):
            auto_resume = self.auto_resume.to_dict()

        secure = self.secure

        allow_internet_access = self.allow_internet_access

        network: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.network, Unset):
            network = self.network.to_dict()

        metadata = self.metadata

        env_vars = self.env_vars

        mcp: Union[None, Unset, dict[str, Any]]
        if isinstance(self.mcp, Unset):
            mcp = UNSET
        elif isinstance(self.mcp, McpType0):
            mcp = self.mcp.to_dict()
        else:
            mcp = self.mcp

        iam: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.iam, Unset):
            iam = self.iam.to_dict()

        volume_mounts: Union[Unset, list[dict[str, Any]]] = UNSET
        if not isinstance(self.volume_mounts, Unset):
            volume_mounts = []
            for volume_mounts_item_data in self.volume_mounts:
                volume_mounts_item = volume_mounts_item_data.to_dict()
                volume_mounts.append(volume_mounts_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "templateID": template_id,
            }
        )
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if auto_pause is not UNSET:
            field_dict["autoPause"] = auto_pause
        if auto_pause_memory is not UNSET:
            field_dict["autoPauseMemory"] = auto_pause_memory
        if auto_resume is not UNSET:
            field_dict["autoResume"] = auto_resume
        if secure is not UNSET:
            field_dict["secure"] = secure
        if allow_internet_access is not UNSET:
            field_dict["allow_internet_access"] = allow_internet_access
        if network is not UNSET:
            field_dict["network"] = network
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if env_vars is not UNSET:
            field_dict["envVars"] = env_vars
        if mcp is not UNSET:
            field_dict["mcp"] = mcp
        if iam is not UNSET:
            field_dict["iam"] = iam
        if volume_mounts is not UNSET:
            field_dict["volumeMounts"] = volume_mounts

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.mcp_type_0 import McpType0
        from ..models.sandbox_auto_resume_config import SandboxAutoResumeConfig
        from ..models.sandbox_iam import SandboxIam
        from ..models.sandbox_network_config import SandboxNetworkConfig
        from ..models.sandbox_volume_mount import SandboxVolumeMount

        d = dict(src_dict)
        template_id = d.pop("templateID")

        timeout = d.pop("timeout", UNSET)

        auto_pause = d.pop("autoPause", UNSET)

        auto_pause_memory = d.pop("autoPauseMemory", UNSET)

        _auto_resume = d.pop("autoResume", UNSET)
        auto_resume: Union[Unset, SandboxAutoResumeConfig]
        if isinstance(_auto_resume, Unset):
            auto_resume = UNSET
        else:
            auto_resume = SandboxAutoResumeConfig.from_dict(_auto_resume)

        secure = d.pop("secure", UNSET)

        allow_internet_access = d.pop("allow_internet_access", UNSET)

        _network = d.pop("network", UNSET)
        network: Union[Unset, SandboxNetworkConfig]
        if isinstance(_network, Unset):
            network = UNSET
        else:
            network = SandboxNetworkConfig.from_dict(_network)

        metadata = d.pop("metadata", UNSET)

        env_vars = d.pop("envVars", UNSET)

        def _parse_mcp(data: object) -> Union["McpType0", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_mcp_type_0 = McpType0.from_dict(data)

                return componentsschemas_mcp_type_0
            except:  # noqa: E722
                pass
            return cast(Union["McpType0", None, Unset], data)

        mcp = _parse_mcp(d.pop("mcp", UNSET))

        _iam = d.pop("iam", UNSET)
        iam: Union[Unset, SandboxIam]
        if isinstance(_iam, Unset):
            iam = UNSET
        else:
            iam = SandboxIam.from_dict(_iam)

        volume_mounts = []
        _volume_mounts = d.pop("volumeMounts", UNSET)
        for volume_mounts_item_data in _volume_mounts or []:
            volume_mounts_item = SandboxVolumeMount.from_dict(volume_mounts_item_data)

            volume_mounts.append(volume_mounts_item)

        new_sandbox = cls(
            template_id=template_id,
            timeout=timeout,
            auto_pause=auto_pause,
            auto_pause_memory=auto_pause_memory,
            auto_resume=auto_resume,
            secure=secure,
            allow_internet_access=allow_internet_access,
            network=network,
            metadata=metadata,
            env_vars=env_vars,
            mcp=mcp,
            iam=iam,
            volume_mounts=volume_mounts,
        )

        new_sandbox.additional_properties = d
        return new_sandbox

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
