# Compliance pack — Northstar Health

Demo bundle for the healthcare lineage scenario.
Window: 2026-02-01 .. 2026-02-28
Entries: 32

Verify with:  bernstein-verify pack expected-pack.zip
