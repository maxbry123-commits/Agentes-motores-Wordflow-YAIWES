# Compliance pack — Bavarian Tooling GmbH

Demo bundle for the eu-manufacturer lineage scenario.
Window: 2026-03-01 .. 2026-03-31
Entries: 30

Verify with:  bernstein-verify pack expected-pack.zip
