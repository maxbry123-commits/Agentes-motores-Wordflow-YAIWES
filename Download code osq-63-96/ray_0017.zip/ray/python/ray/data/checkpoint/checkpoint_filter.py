import abc
import logging
import os
import posixpath
import sys
import time
from abc import abstractmethod
from typing import List, Optional, Tuple

import numpy as np
import pyarrow
from pyarrow.fs import FileSelector, FileType

import ray
from ray._common.retry import call_with_retry
from ray.data._internal.arrow_ops import transform_pyarrow
from ray.data._internal.execution.interfaces.ref_bundle import RefBundle
from ray.data.block import Block, BlockMetadata, Schema
from ray.data.checkpoint import CheckpointConfig
from ray.data.checkpoint.checkpoint_writer import PENDING_CHECKPOINT_SUFFIX
from ray.data.checkpoint.util import build_pending_checkpoint_trie
from ray.data.context import DataContext
from ray.data.datasource.path_util import _unwrap_protocol
from ray.types import ObjectRef
from ray.util.annotations import DeveloperAPI

logger = logging.getLogger(__name__)

# Retry configuration for checkpoint recovery operations.
# These can be overridden via environment variables for testing or tuning.
CHECKPOINT_RECOVERY_MAX_ATTEMPTS = int(
    os.environ.get("RAY_DATA_CHECKPOINT_RECOVERY_MAX_ATTEMPTS", "3")
)
CHECKPOINT_RECOVERY_MAX_BACKOFF_S = int(
    os.environ.get("RAY_DATA_CHECKPOINT_RECOVERY_MAX_BACKOFF_S", "8")
)


def _numpy_size(array: np.ndarray) -> int:
    """Calculate the size of a numpy ndarray."""
    total_size = array.nbytes
    if array.dtype == object:
        sample_count = 10**4

        if len(array) <= sample_count:
            for item in array.flat:
                total_size += sys.getsizeof(item)
        else:
            sample_total_size = 0
            for item in array[:sample_count].flat:
                sample_total_size += sys.getsizeof(item)
            total_size += int(sample_total_size / sample_count * len(array))
    return total_size


@ray.remote(num_cpus=0)
def _clean_pending_checkpoints_task(
    checkpoint_path_unwrapped: str,
    checkpoint_filesystem: pyarrow.fs.FileSystem,
    data_file_dir_unwrapped: str,
    data_file_filesystem: pyarrow.fs.FileSystem,
) -> int:
    """Delete data files that have matching pending checkpoint files, then
    delete the pending checkpoints.

    This runs as a remote task to avoid blocking the driver during potentially
    slow filesystem operations (especially on cloud storage like S3).

    Algorithm:
    1. List all files in checkpoint dir, find those ending with .pending.parquet
    2. Build a PrefixTrie from their basenames (strip .pending.parquet)
    3. List all data files in data_file_dir (recursively for partitions)
    4. For each data file, if trie.has_prefix_of(basename) -> delete it
    5. Delete all the pending checkpoint files
    6. Return count of pending checkpoints cleaned

    Args:
        checkpoint_path_unwrapped: The unwrapped checkpoint path.
        checkpoint_filesystem: The filesystem for checkpoint files.
        data_file_dir_unwrapped: The unwrapped directory where data files are
            written (protocol prefix already stripped).
        data_file_filesystem: The filesystem for data files. May differ from
            checkpoint_filesystem (e.g., checkpoints on local disk, data on S3).

    Returns:
        Number of pending checkpoints cleaned.
    """

    def _clean() -> int:
        # 1. List all files in checkpoint dir, find pending ones
        ckpt_files = checkpoint_filesystem.get_file_info(
            FileSelector(
                checkpoint_path_unwrapped, recursive=False, allow_not_found=True
            )
        )
        pending_suffix = f"{PENDING_CHECKPOINT_SUFFIX}.parquet"
        pending_file_paths = [
            f
            for f in ckpt_files
            if f.type == FileType.File and f.path.endswith(pending_suffix)
        ]

        if not pending_file_paths:
            return 0

        # 2. Build prefix trie from pending checkpoint basenames
        trie = build_pending_checkpoint_trie(pending_file_paths, pending_suffix)

        # 3. List all data files (recursively for partitions)
        data_files = data_file_filesystem.get_file_info(
            FileSelector(data_file_dir_unwrapped, recursive=True, allow_not_found=True)
        )

        # 4. Delete data files matching a pending checkpoint prefix
        for f in data_files:
            if f.type != FileType.File:
                continue
            basename = posixpath.basename(f.path)
            if trie.has_prefix_of(basename):
                data_file_filesystem.delete_file(f.path)

        # 5. Delete all pending checkpoint files
        for f in pending_file_paths:
            checkpoint_filesystem.delete_file(f.path)

        return len(pending_file_paths)

    return call_with_retry(
        _clean,
        description="clean pending checkpoints",
        max_attempts=CHECKPOINT_RECOVERY_MAX_ATTEMPTS,
        max_backoff_s=CHECKPOINT_RECOVERY_MAX_BACKOFF_S,
    )


@ray.remote(num_returns=2)
def convert_and_sort_checkpointed_ids(
    checkpointed_ids_arrow: Block, id_column: str
) -> Tuple[np.ndarray, int]:
    """Convert checkpointed IDs from pyarrow.Table to sorted np.ndarray.

    Args:
        checkpointed_ids_arrow: A pyarrow.Table containing the checkpointed
            IDs, loaded from the checkpoint parquet files.
        id_column: The id column of `checkpoint_ids_array`.

    Returns:
        A tuple of:
        - The sorted checkpointed IDs of type numpy.ndarray, which can be
          passed directly to each checkpoint filter actor.
        - The size (bytes) of the ndarray, which can be used to determine
          the `ray_remote_args` of each checkpoint filter actor.
    """
    checkpointed_ids_ndarray = np.array([])

    try:
        if checkpointed_ids_arrow.num_rows != 0:
            checkpointed_ids_ndarray = np.sort(
                transform_pyarrow.to_numpy(
                    checkpointed_ids_arrow[id_column], zero_copy_only=False
                )
            )
    except Exception as e:
        raise RuntimeError(f"Failed to convert and sort checkpointed IDs: {e}")

    checkpoint_size = _numpy_size(checkpointed_ids_ndarray)
    return checkpointed_ids_ndarray, checkpoint_size


@DeveloperAPI
class CheckpointManager(abc.ABC):
    """Manage checkpoint data.

    Subclasses passed as ``CheckpointConfig.checkpoint_manager_cls`` must have
    a constructor accepting ``(checkpoint_config=..., data_context=...)``
    keyword arguments, and their ``load_checkpoint`` must return an
    ``(ObjectRef, int)`` tuple: the ref is passed opaquely to the configured
    ``CheckpointFilter`` class's constructor, and the int (size in bytes) is
    used for the per-actor memory reservation of the filter actors. Returning
    ``(None, 0)`` means there is no checkpoint data to restore from, and the
    checkpoint filter operator is not added to the plan.
    """

    def __init__(
        self,
        checkpoint_config: CheckpointConfig,
        data_context: DataContext,
    ):
        """Initialize the CheckpointManager.

        Args:
            checkpoint_config: the checkpoint config.
            data_context: the DataContext snapshot whose ``execution_options``
                should govern the Ray tasks fired during checkpoint loading
                and pending-checkpoint cleanup. Pass the dataset's
                ``_context`` (not ``DataContext.get_current()``) so the
                label_selector and other execution options stay consistent
                with the rest of materialize.
        """
        self.checkpoint_path = checkpoint_config.checkpoint_path
        self.filesystem = checkpoint_config.filesystem
        self.id_column = checkpoint_config.id_column
        self.checkpoint_path_partition_filter = (
            checkpoint_config.checkpoint_path_partition_filter
        )
        self.checkpoint_path_unwrapped = _unwrap_protocol(
            checkpoint_config.checkpoint_path
        )
        self._data_context = data_context

    def load_checkpoint(
        self,
        data_file_dir: Optional[str] = None,
        data_file_filesystem: Optional["pyarrow.fs.FileSystem"] = None,
    ) -> Tuple[Optional[ObjectRef[np.ndarray]], int]:
        """Loading checkpoint data.

        This method first cleans up any pending checkpoints from incomplete
        2-phase commits, then loads the committed checkpoint data.

        Args:
            data_file_dir: Optional directory where data files are written.
                If provided, pending checkpoints will be used to find and
                delete matching data files before loading.
            data_file_filesystem: Optional filesystem for data files. If not
                provided, defaults to the checkpoint filesystem. Should be
                provided when data files are on a different filesystem than
                checkpoints.

        Returns:
            ObjectRef: The ref of checkpointed IDs array. None if no checkpoint was loaded.
            int: the size of the checkpointed IDs array.
        """
        logger.info(
            "Loading checkpoint from %s, this could take a while.", self.checkpoint_path
        )

        start_t = time.time()

        # Clean up pending checkpoints before loading (runs as a Ray task)
        if data_file_dir is not None:
            self._clean_pending_checkpoints(data_file_dir, data_file_filesystem)

        # If the checkpoint directory has no remaining data files (e.g., all
        # entries were pending checkpoints that were just cleaned up), skip
        # the inner ``read_parquet``. V2's ``read_parquet`` raises on empty
        # directories while V1 returned a zero-row dataset; this pre-check
        # keeps ``load_checkpoint`` behaving the same under both.
        # Recurse when a partition filter is configured because committed
        # files live under Hive-partitioned subdirectories rather than at
        # the top level.
        entries = self.filesystem.get_file_info(
            FileSelector(
                self.checkpoint_path_unwrapped,
                recursive=self.checkpoint_path_partition_filter is not None,
                allow_not_found=True,
            )
        )
        if not any(f.type == FileType.File for f in entries):
            return None, 0

        # Load the checkpoint data
        checkpoint_ds: ray.data.Dataset = ray.data.read_parquet(
            self.checkpoint_path,
            filesystem=self.filesystem,
            partition_filter=self.checkpoint_path_partition_filter,
        )
        checkpoint_ds.set_name("checkpoint_dataset")

        # Manually disable checkpointing for loading the checkpoint metadata
        # to avoid recursively restoring checkpoints.
        # TODO: Clean way to do this would be to introduce per Op config
        # [https://github.com/ray-project/ray/issues/54520]
        checkpoint_ds.context.checkpoint_config = None

        # Pre-process data pipeline
        checkpoint_ds: ray.data.Dataset = self._preprocess_data_pipeline(checkpoint_ds)

        # Repartition to 1 block.
        checkpoint_ds = checkpoint_ds.repartition(num_blocks=1)

        # Get the block reference
        ref_bundles: List[RefBundle] = list(checkpoint_ds.iter_internal_ref_bundles())

        assert len(ref_bundles) == 1

        # If there are no valid files under the checkpoint_path, return None, 0.
        if ref_bundles[0].num_rows() == 0:
            return None, 0

        ref_bundle: RefBundle = ref_bundles[0]
        schema: Schema = ref_bundle.schema
        assert len(ref_bundle.blocks) == 1
        block_ref: ObjectRef[Block] = ref_bundle.blocks[0].ref
        metadata: BlockMetadata = ref_bundle.blocks[0].metadata
        # Validate the loaded checkpoint
        self._validate_loaded_checkpoint(schema, metadata)

        # Convert arrow-typed ids to sorted numpy-typed ids.
        # Note: the convert is very time-consuming.
        # Get the object ref the checkpointed IDs, because we do not want the IDs
        # to occupy the memory of the head node.
        ctx_label_selector = self._data_context.execution_options.label_selector
        task = convert_and_sort_checkpointed_ids
        if ctx_label_selector:
            task = task.options(label_selector=ctx_label_selector)
        (
            checkpointed_ids_ref,
            checkpoint_size_ref,
        ) = task.remote(block_ref, self.id_column)

        checkpoint_size = ray.get(checkpoint_size_ref)

        logger.info(
            "Checkpoint loaded for %s in %.2f seconds. SizeBytes = %d, Schema = %s",
            type(self).__name__,
            time.time() - start_t,
            checkpoint_size,
            schema.to_string(),
        )
        return checkpointed_ids_ref, checkpoint_size

    def _clean_pending_checkpoints(
        self,
        data_file_dir: Optional[str],
        data_file_filesystem: Optional["pyarrow.fs.FileSystem"] = None,
    ) -> None:
        """Clean up pending checkpoints from incomplete 2-phase commits.

        Finds pending checkpoint files, builds a prefix trie from their basenames,
        deletes matching data files, then deletes the pending checkpoints.

        Runs as a Ray task to avoid blocking the driver during potentially
        slow filesystem operations (especially on cloud storage like S3).

        Args:
            data_file_dir: The directory where data files are written.
            data_file_filesystem: The filesystem for data files. If not
                provided, defaults to the checkpoint filesystem.
        """
        if not data_file_dir:
            return
        if data_file_filesystem is None:
            data_file_filesystem = self.filesystem
        ctx_label_selector = self._data_context.execution_options.label_selector
        task = _clean_pending_checkpoints_task
        if ctx_label_selector:
            task = task.options(label_selector=ctx_label_selector)
        try:
            cleaned_count = ray.get(
                task.remote(
                    self.checkpoint_path_unwrapped,
                    self.filesystem,
                    _unwrap_protocol(data_file_dir),
                    data_file_filesystem,
                )
            )
            if cleaned_count > 0:
                logger.info(f"Cleaned up {cleaned_count} pending checkpoint(s)")
        except ray.exceptions.RayTaskError:
            logger.exception("Failed to clean up pending checkpoints")
            raise

    def _preprocess_data_pipeline(
        self, checkpoint_ds: ray.data.Dataset
    ) -> ray.data.Dataset:
        """Pre-process the checkpoint dataset.

        Subclasses can override this method for custom processing.
        """
        return checkpoint_ds

    def _validate_loaded_checkpoint(
        self, schema: Schema, metadata: BlockMetadata
    ) -> None:
        """Validate the loaded checkpoint. Subclasses can override for custom validation."""
        pass


@DeveloperAPI
class IdColumnCheckpointManager(CheckpointManager):
    """Manager for regular ID columns."""


@DeveloperAPI
class CheckpointFilter(abc.ABC):
    """Abstract class which defines the interface for filtering checkpointed rows
    based on varying backends.

    Subclasses passed as ``CheckpointConfig.checkpoint_filter_cls`` are
    constructed with ``(checkpoint_config, checkpoint_ref)``, where
    ``checkpoint_ref`` is the ``ObjectRef`` returned by the checkpoint
    manager's ``load_checkpoint`` (by default, a sorted NumPy array of
    checkpointed IDs). Subclasses that define their own constructor must
    accept the same two arguments. The class is instantiated once per
    checkpoint filter actor on a remote worker, so it must be serializable
    (or importable) there.
    """

    def __init__(
        self,
        config: CheckpointConfig,
        checkpoint_ref: Optional[ObjectRef] = None,
    ):
        self.ckpt_config = config
        self.id_column = self.ckpt_config.id_column
        self.checkpoint_ref = checkpoint_ref

    @abstractmethod
    def filter_rows_for_block(self, block: Block) -> Block:
        """For the given block, filter out rows that have already
        been checkpointed, and return the resulting block.

        Args:
            block: The input block to filter.
        Returns:
            A new block with rows that have not been checkpointed.
        """
        raise NotImplementedError


@DeveloperAPI
class NumpyArrayBasedCheckpointFilter(CheckpointFilter):
    """CheckpointFilter for batch-based backends.

    This filter will first fetch the checkpointed IDs (as NumPy arrays) from the object store.
    For each input block, it filters the block and returns the filtered block.
    """

    def __init__(
        self,
        checkpoint_config: CheckpointConfig,
        checkpoint_ref: ObjectRef[np.ndarray],
    ):
        super().__init__(checkpoint_config, checkpoint_ref)
        self.checkpointed_ids = ray.get(checkpoint_ref)
        assert isinstance(self.checkpointed_ids, np.ndarray)

    def filter_rows_for_block(
        self,
        block: Block,
    ) -> Block:
        """Filter IDs in memory using NumPy's binary search."""

        if self.checkpointed_ids.shape[0] == 0 or len(block) == 0:
            return block

        assert isinstance(block, pyarrow.Table)

        # The checkpointed_ids block is sorted (see load_checkpoint).
        # We'll use binary search to filter out processed rows.

        # Convert the block's ID column to a numpy array for fast processing.
        block_ids = transform_pyarrow.to_numpy(
            block[self.id_column], zero_copy_only=False
        )

        # Start with a mask of all True (keep all rows).
        mask = np.ones(len(block_ids), dtype=bool)
        # Use binary search to find where block_ids would be in ckpt_ids.
        sorted_indices = np.searchsorted(self.checkpointed_ids, block_ids)
        # Only consider indices that are within bounds.
        valid_indices = sorted_indices < len(self.checkpointed_ids)
        # For valid indices, check for exact matches.
        potential_matches = sorted_indices[valid_indices]
        matched = self.checkpointed_ids[potential_matches] == block_ids[valid_indices]
        # Mark matched IDs as False (filter out these rows).
        mask[valid_indices] = ~matched

        # Convert the final mask to a PyArrow array and filter the block.
        mask_array = pyarrow.array(mask)
        filtered_block = block.filter(mask_array)
        return filtered_block
