import copy
import warnings
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    import pyarrow as pa

from typing_extensions import override

from ray.data._internal.execution.bundle_queue import (
    BaseBundleQueue,
    RebundleQueue,
)
from ray.data._internal.execution.interfaces import (
    ExecutionResources,
    PhysicalOperator,
    RefBundle,
    TaskContext,
)
from ray.data._internal.execution.operators.map_operator import (
    MapOperator,
    _map_task,
)
from ray.data._internal.execution.operators.map_transformer import MapTransformer
from ray.data._internal.remote_fn import cached_remote_fn
from ray.data.context import DataContext


class TaskPoolMapOperator(MapOperator):
    """A MapOperator implementation that executes tasks on a task pool."""

    def __init__(
        self,
        map_transformer: MapTransformer,
        input_op: PhysicalOperator,
        data_context: DataContext,
        name: str = "TaskPoolMap",
        target_max_block_size_override: Optional[int] = None,
        min_rows_per_bundle: Optional[int] = None,
        ref_bundler: Optional[RebundleQueue] = None,
        max_concurrency: Optional[int] = None,
        supports_fusion: bool = True,
        map_task_kwargs: Optional[Dict[str, Any]] = None,
        ray_remote_args_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        ray_remote_args: Optional[Dict[str, Any]] = None,
        on_start: Optional[Callable[[Optional["pa.Schema"]], None]] = None,
        isolate_workers: bool = False,
        default_logical_memory_enabled: bool = False,
    ):
        """Create an TaskPoolMapOperator instance.

        Args:
            map_transformer: The :class:`MapTransformer` to apply to each ref
                bundle input.
            input_op: Operator generating input data for this op.
            data_context: The :class:`DataContext` to use for this operator.
            name: The name of this operator.
            target_max_block_size_override: Override for target max-block-size.
            min_rows_per_bundle: The number of rows to gather per batch passed to the
                transform_fn, or None to use the block size. Setting the batch size is
                important for the performance of GPU-accelerated transform functions.
                The actual rows passed may be less if the dataset is small.
            ref_bundler: The ref bundler to use for this operator.
            max_concurrency: The maximum number of Ray tasks to use concurrently,
                or None to use as many tasks as possible.
            supports_fusion: Whether this operator supports fusion with other operators.
            map_task_kwargs: A dictionary of kwargs to pass to the map task. You can
                access these kwargs through the `TaskContext.kwargs` dictionary.
            ray_remote_args_fn: A function that returns a dictionary of remote args
                passed to each map worker. The purpose of this argument is to generate
                dynamic arguments for each actor/task, and will be called each time
                prior to initializing the worker. Args returned from this dict will
                always override the args in ``ray_remote_args``. Note: this is an
                advanced, experimental feature.
            ray_remote_args: Customize the :func:`ray.remote` args for this op's tasks.
            on_start: Optional callback invoked with the schema from the first input
                bundle before any tasks are submitted.
            isolate_workers: If ``True``, ensure that other operators' tasks don't get
                scheduled on the same worker processes as this operator's. This flag
                is useful to prevent side-effects from affecting other operators, like
                large PyArrow memory allocations.
            default_logical_memory_enabled: If ``True``, the operator launches tasks
                with a default logical ``memory``. The method for choosing the
                default is an implementation detail.
        """
        super().__init__(
            map_transformer,
            input_op,
            data_context,
            name,
            target_max_block_size_override,
            min_rows_per_bundle,
            ref_bundler,
            supports_fusion,
            map_task_kwargs,
            ray_remote_args_fn,
            ray_remote_args,
            on_start,
            default_logical_memory_enabled,
        )

        self._isolate_workers = isolate_workers

        if max_concurrency is not None and max_concurrency <= 0:
            raise ValueError(f"max_concurrency have to be > 0 (got {max_concurrency})")

        self._max_concurrency = max_concurrency
        self._current_logical_usage = ExecutionResources.zero()

        # NOTE: Unlike static Ray remote args, dynamic arguments extracted from the
        #       blocks themselves are going to be passed inside `fn.options(...)`
        #       invocation
        ray_remote_static_args = {
            **(self._ray_remote_args or {}),
            "num_returns": "streaming",
            "_labels": {self._OPERATOR_ID_LABEL_KEY: self.id},
        }

        # Ray Core doesn't share workers for tasks with different `runtime_env`s. We use
        # this property to implicitly ensure that this operator's tasks run on isolated
        # workers.
        if self._isolate_workers:
            ray_remote_static_args = self._add_unique_runtime_env(
                ray_remote_static_args
            )

        self._map_task = cached_remote_fn(_map_task, **ray_remote_static_args)

    def _add_unique_runtime_env(
        self, ray_remote_args: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Return a copy of the remote args with a runtime env that's unique to this
        operator.
        """
        ray_remote_args = copy.deepcopy(ray_remote_args)

        runtime_env = ray_remote_args.get("runtime_env", {})
        env_vars = ray_remote_args.get("env_vars", {})
        env_vars["__RAY_DATA_OPERATOR_ID"] = self.id
        runtime_env["env_vars"] = env_vars

        ray_remote_args["runtime_env"] = runtime_env
        return ray_remote_args

    @property
    def isolate_workers(self) -> bool:
        """Return whether this operator launches tasks on isolated worker processes.

        If ``True``, other operators' tasks won't get scheduled on the same worker
        processes as this operator's. This flag is useful to prevent side-effects
        from affecting other operators, like large PyArrow memory allocations.
        """
        return self._isolate_workers

    @property
    @override
    def _input_queues(self) -> List["BaseBundleQueue"]:
        return [self._block_ref_bundler]

    @property
    @override
    def _output_queues(self) -> List["BaseBundleQueue"]:
        return [self._output_queue]

    def _try_schedule_task(self, bundle: RefBundle, strict: bool):
        # Notify first input for deferred initialization (e.g., Iceberg schema evolution).
        self._notify_first_input(bundle)
        # Submit the task as a normal Ray task.
        ctx = TaskContext(
            task_idx=self._next_data_task_idx,
            op_name=self.name,
            target_max_block_size_override=self.target_max_block_size_override,
        )

        dynamic_ray_remote_args = self._get_dynamic_ray_remote_args(input_bundle=bundle)
        dynamic_ray_remote_args["name"] = self.name
        logical_usage = ExecutionResources.from_resource_dict(dynamic_ray_remote_args)

        if (
            "_generator_backpressure_num_objects" not in dynamic_ray_remote_args
            and self.data_context._max_num_blocks_in_streaming_gen_buffer is not None
        ):
            # The `_generator_backpressure_num_objects` parameter should be
            # `2 * _max_num_blocks_in_streaming_gen_buffer` because we yield
            # 2 objects for each block: the block and the block metadata.
            dynamic_ray_remote_args["_generator_backpressure_num_objects"] = (
                2 * self.data_context._max_num_blocks_in_streaming_gen_buffer
            )

        gen = self._map_task.options(**dynamic_ray_remote_args).remote(
            self._map_transformer_ref,
            self._data_context_ref,
            ctx,
            *bundle.block_refs,
            slices=bundle.slices,
            **self.get_map_task_kwargs(),
        )

        self._current_logical_usage = self._current_logical_usage.add(logical_usage)

        def task_done_callback():
            self._current_logical_usage = self._current_logical_usage.subtract(
                logical_usage
            )

        self._submit_data_task(gen, bundle, task_done_callback=task_done_callback)

    def progress_str(self) -> str:
        return ""

    def current_logical_usage(self) -> ExecutionResources:
        return self._current_logical_usage

    def pending_logical_usage(self) -> ExecutionResources:
        return ExecutionResources()

    def incremental_resource_usage(self) -> ExecutionResources:
        return self.per_task_resource_allocation()

    def per_task_resource_allocation(self) -> ExecutionResources:
        return ExecutionResources(
            cpu=self._ray_remote_args.get("num_cpus", 0),
            gpu=self._ray_remote_args.get("num_gpus", 0),
            memory=self._ray_remote_args.get("memory", 0),
        )

    def min_scheduling_resources(
        self: "PhysicalOperator",
    ) -> ExecutionResources:
        return self.incremental_resource_usage()

    def get_max_concurrency_limit(self) -> Optional[int]:
        return self._max_concurrency

    def min_max_resource_requirements(
        self,
    ) -> Tuple[ExecutionResources, ExecutionResources]:
        """Returns min/max resource requirements for this operator.

        - Min: resources needed for one task (minimum to make progress)
        - Max: resources for max_concurrency tasks (if set), else infinite
        """
        per_task = self.per_task_resource_allocation()
        obj_store_per_task = (
            self._metrics.obj_store_mem_max_pending_output_per_task or 0
        )

        min_resource_usage = per_task.copy(object_store_memory=obj_store_per_task)

        # Cap resources to 0 if this operator doesn't use them.
        # This prevents operators from hoarding resource budget they don't need.
        max_concurrency = (
            self._max_concurrency if self._max_concurrency is not None else float("inf")
        )
        max_resource_usage = ExecutionResources(
            cpu=0 if per_task.cpu == 0 else per_task.cpu * max_concurrency,
            gpu=0 if per_task.gpu == 0 else per_task.gpu * max_concurrency,
            memory=0 if per_task.memory == 0 else per_task.memory * max_concurrency,
            # Set the max `object_store_memory` requirement to 'inf', because we
            # don't know how much data each task can output.
            object_store_memory=float("inf"),
        )

        return min_resource_usage, max_resource_usage

    def all_inputs_done(self):
        super().all_inputs_done()

        if (
            self._max_concurrency is not None
            and self._metrics.num_inputs_received < self._max_concurrency
        ):
            warnings.warn(
                f"The maximum number of concurrent tasks for '{self.name}' is set to "
                f"{self._max_concurrency}, but the operator only received "
                f"{self._metrics.num_inputs_received} input(s). This means that the "
                f"operator can launch at most {self._metrics.num_inputs_received} "
                "task(s), which is less than the concurrency limit. You might be able "
                "to increase the number of concurrent tasks by configuring "
                "`override_num_blocks` earlier in the pipeline."
            )
