import time
from collections import defaultdict
from dataclasses import Field, dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set

import ray
from ray.data._internal.execution.bundle_queue import create_bundle_queue
from ray.data._internal.execution.interfaces.common import (
    RuntimeMetricsHistogram,
    histogram_bucket_rows,
    histogram_buckets_bytes,
    histogram_buckets_s,
)
from ray.data._internal.execution.interfaces.distribution_tracker import (
    DistributionTracker,
)
from ray.data._internal.execution.interfaces.ref_bundle import RefBundle
from ray.data._internal.memory_tracing import trace_allocation
from ray.data.block import BlockMetadata, TaskExecWorkerStats

if TYPE_CHECKING:
    from ray.data._internal.execution.interfaces.physical_operator import (
        PhysicalOperator,
        TaskExecDriverStats,
    )


# A metadata key used to mark a dataclass field as a metric.
_IS_FIELD_METRIC_KEY = "__is_metric"
# Metadata keys used to store information about a metric.
_METRIC_FIELD_DESCRIPTION_KEY = "__metric_description"
_METRIC_FIELD_METRICS_GROUP_KEY = "__metric_metrics_group"
_METRIC_FIELD_METRICS_TYPE_KEY = "__metric_metrics_type"
_METRIC_FIELD_METRICS_ARGS_KEY = "__metric_metrics_args"
_METRIC_FIELD_IS_MAP_ONLY_KEY = "__metric_is_map_only"

_METRICS: List["MetricDefinition"] = []

NODE_UNKNOWN = "unknown"


class MetricsGroup(Enum):
    INPUTS = "inputs"
    OUTPUTS = "outputs"
    TASKS = "tasks"
    OBJECT_STORE_MEMORY = "object_store_memory"
    ACTORS = "actors"


class MetricsType(Enum):
    Counter = 0
    Gauge = 1
    Histogram = 2
    Unsupported = 3
    Distribution = 4


@dataclass(frozen=True)
class MetricDefinition:
    """Metadata for a metric.

    Args:
        name: The name of the metric.
        description: A human-readable description of the metric, also used as the chart
            description on the Ray Data dashboard.
        metrics_group: The group of the metric, used to organize metrics into groups in
            'StatsActor' and on the Ray Data dashboard.
        map_only: Whether the metric is only measured for 'MapOperators'.
    """

    name: str
    description: str
    metrics_group: str
    metrics_type: MetricsType
    metrics_args: Dict[str, Any]
    # TODO: Let's refactor this parameter so it isn't tightly coupled with a specific
    # operator type (MapOperator).
    map_only: bool = False
    internal_only: bool = False  # do not expose this metric to the user


def metric_field(
    *,
    description: str,
    metrics_group: str,
    metrics_type: MetricsType = MetricsType.Gauge,
    metrics_args: Dict[str, Any] = None,
    map_only: bool = False,
    internal_only: bool = False,  # do not expose this metric to the user
    **field_kwargs,
):
    """A dataclass field that represents a metric."""
    metadata = field_kwargs.get("metadata", {})

    metadata[_IS_FIELD_METRIC_KEY] = True

    metadata[_METRIC_FIELD_DESCRIPTION_KEY] = description
    metadata[_METRIC_FIELD_METRICS_GROUP_KEY] = metrics_group
    metadata[_METRIC_FIELD_METRICS_TYPE_KEY] = metrics_type
    metadata[_METRIC_FIELD_METRICS_ARGS_KEY] = metrics_args or {}
    metadata[_METRIC_FIELD_IS_MAP_ONLY_KEY] = map_only

    return field(metadata=metadata, **field_kwargs)


def metric_property(
    *,
    description: str,
    metrics_group: str,
    metrics_type: MetricsType = MetricsType.Gauge,
    metrics_args: Dict[str, Any] = None,
    map_only: bool = False,
    internal_only: bool = False,  # do not expose this metric to the user
):
    """A property that represents a metric."""

    def wrap(func):
        metric = MetricDefinition(
            name=func.__name__,
            description=description,
            metrics_group=metrics_group,
            metrics_type=metrics_type,
            metrics_args=(metrics_args or {}),
            map_only=map_only,
            internal_only=internal_only,
        )

        _METRICS.append(metric)

        return property(func)

    return wrap


@dataclass
class RunningTaskInfo:
    inputs: RefBundle
    num_outputs: int
    bytes_output: int
    num_rows_produced: int
    start_time: float
    cum_block_gen_time_s: float
    cum_block_ser_time_s: float
    task_id: ray.TaskID
    # Node IDs derived from the input blocks' exec_stats at task submission time.
    # Used to determine cache hits: if the task's first output block was produced
    # on a node that already held an input block, it's a "cache hit" (the task
    # ran where its data lived). For source operators (e.g., ReadRange), input
    # blocks lack exec_stats, so input_node_ids will contain NODE_UNKNOWN and
    # all tasks will be classified as cache misses.
    input_node_ids: Set[str] = field(default_factory=set)
    last_updated: float = field(init=False, default_factory=lambda: time.perf_counter())
    # Set once the task's first output is observed. True if the output node
    # matched one of the input_node_ids (data locality was preserved).
    is_task_locality_hit: Optional[bool] = field(init=False, default=None)


@dataclass
class NodeMetrics:
    num_tasks_finished: int = 0
    bytes_outputs_of_finished_tasks: int = 0
    blocks_outputs_of_finished_tasks: int = 0


class OpRuntimesMetricsMeta(type):
    def __init__(cls, name, bases, dict):
        # NOTE: `Field.name` isn't set until the dataclass is created, so we can't
        # create the metrics in `metric_field` directly.
        super().__init__(name, bases, dict)

        # Iterate over the attributes and methods of 'OpRuntimeMetrics'.
        for name, value in dict.items():
            # If an attribute is a dataclass field and has _IS_FIELD_METRIC_KEY in its
            # metadata, then create a metric from the field metadata and add it to the
            # list of metrics. See also the 'metric_field' function.
            if isinstance(value, Field) and value.metadata.get(_IS_FIELD_METRIC_KEY):
                metric = MetricDefinition(
                    name=name,
                    description=value.metadata[_METRIC_FIELD_DESCRIPTION_KEY],
                    metrics_group=value.metadata[_METRIC_FIELD_METRICS_GROUP_KEY],
                    metrics_type=value.metadata[_METRIC_FIELD_METRICS_TYPE_KEY],
                    metrics_args=value.metadata[_METRIC_FIELD_METRICS_ARGS_KEY],
                    map_only=value.metadata[_METRIC_FIELD_IS_MAP_ONLY_KEY],
                )
                _METRICS.append(metric)


def node_id_from_block_metadata(meta: BlockMetadata) -> str:
    if meta.exec_stats is not None and meta.exec_stats.node_id is not None:
        node_id = meta.exec_stats.node_id
    else:
        node_id = NODE_UNKNOWN
    return node_id


@dataclass
class OpRuntimeMetrics(metaclass=OpRuntimesMetricsMeta):
    """Runtime metrics for a 'PhysicalOperator'.

    Metrics are updated dynamically during the execution of the Dataset.
    This class can be used for either observablity or scheduling purposes.

    DO NOT modify the fields of this class directly. Instead, use the provided
    callback methods.
    """

    # TODO(hchen): Fields tagged with "map_only" currently only work for MapOperator.
    # We should make them work for all operators by unifying the task execution code.

    # === Inputs-related metrics ===
    num_inputs_received: int = metric_field(
        default=0,
        description="Number of input blocks received by operator.",
        metrics_group=MetricsGroup.INPUTS,
    )
    num_row_inputs_received: int = metric_field(
        default=0,
        description="Number of input rows received by operator.",
        metrics_group=MetricsGroup.INPUTS,
    )
    bytes_inputs_received: int = metric_field(
        default=0,
        description="Byte size of input blocks received by operator.",
        metrics_group=MetricsGroup.INPUTS,
    )
    num_task_inputs_processed: int = metric_field(
        default=0,
        description=(
            "Number of input blocks that operator's tasks have finished processing."
        ),
        metrics_group=MetricsGroup.INPUTS,
    )
    bytes_task_inputs_processed: int = metric_field(
        default=0,
        description=(
            "Byte size of input blocks that operator's tasks have finished processing."
        ),
        metrics_group=MetricsGroup.INPUTS,
    )
    bytes_inputs_of_submitted_tasks: int = metric_field(
        default=0,
        description="Byte size of input blocks passed to submitted tasks.",
        metrics_group=MetricsGroup.INPUTS,
    )
    rows_inputs_of_submitted_tasks: int = metric_field(
        default=0,
        description="Number of rows in the input blocks passed to submitted tasks.",
        metrics_group=MetricsGroup.INPUTS,
    )

    # === Outputs-related metrics ===
    num_task_outputs_generated: int = metric_field(
        default=0,
        description="Number of output blocks generated by tasks.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    bytes_task_outputs_generated: int = metric_field(
        default=0,
        description="Byte size of output blocks generated by tasks.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    rows_task_outputs_generated: int = metric_field(
        default=0,
        description="Number of output rows generated by tasks.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    row_outputs_taken: int = metric_field(
        default=0,
        description="Number of rows that are already taken by downstream operators.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    block_outputs_taken: int = metric_field(
        default=0,
        description="Number of blocks that are already taken by downstream operators.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_outputs_taken: int = metric_field(
        default=0,
        description=(
            "Number of output blocks that are already taken by downstream operators."
        ),
        metrics_group=MetricsGroup.OUTPUTS,
    )
    bytes_outputs_taken: int = metric_field(
        default=0,
        description=(
            "Byte size of output blocks that are already taken by downstream operators."
        ),
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_outputs_of_finished_tasks: int = metric_field(
        default=0,
        description="Number of generated output blocks that are from finished tasks.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    bytes_outputs_of_finished_tasks: int = metric_field(
        default=0,
        description=(
            "Total byte size of generated output blocks produced by finished tasks."
        ),
        metrics_group=MetricsGroup.OUTPUTS,
    )
    rows_outputs_of_finished_tasks: int = metric_field(
        default=0,
        description=("Number of rows generated by finished tasks."),
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_external_inqueue_blocks: int = metric_field(
        default=0,
        description="Number of blocks in the external inqueue",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_external_inqueue_bytes: int = metric_field(
        default=0,
        description="Byte size of blocks in the external inqueue",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_external_outqueue_blocks: int = metric_field(
        default=0,
        description="Number of blocks in the external outqueue",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    num_external_outqueue_bytes: int = metric_field(
        default=0,
        description="Byte size of blocks in the external outqueue",
        metrics_group=MetricsGroup.OUTPUTS,
    )

    # === Tasks-related metrics ===
    num_tasks_submitted: int = metric_field(
        default=0,
        description="Number of submitted tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_running: int = metric_field(
        default=0,
        description="Number of running tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_have_outputs: int = metric_field(
        default=0,
        description="Number of tasks that already have output.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_finished: int = metric_field(
        default=0,
        description="Number of finished tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_failed: int = metric_field(
        default=0,
        description="Number of failed tasks.",
        metrics_group=MetricsGroup.TASKS,
    )

    task_scheduling_time_task_locality_hit_s: float = metric_field(
        default=0,
        description="Cumulative task scheduling time (s) for cache-hit tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_scheduling_time_task_locality_miss_s: float = metric_field(
        default=0,
        description="Cumulative task scheduling time (s) for cache-miss tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    bytes_inputs_of_task_locality_hit_tasks: int = metric_field(
        default=0,
        description="Total input bytes of completed cache-hit tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    bytes_inputs_of_task_locality_miss_tasks: int = metric_field(
        default=0,
        description="Total input bytes of completed cache-miss tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_completion_time_task_locality_hit_s: float = metric_field(
        default=0,
        description="Total wall time (s) of completed cache-hit tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_completion_time_task_locality_miss_s: float = metric_field(
        default=0,
        description="Total wall time (s) of completed cache-miss tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_task_locality_hit: int = metric_field(
        default=0,
        description="Number of tasks whose first output block was on a node where the input was located.",
        metrics_group=MetricsGroup.TASKS,
    )
    num_tasks_task_locality_miss: int = metric_field(
        default=0,
        description="Number of tasks whose first output block was on a node where the input was NOT located.",
        metrics_group=MetricsGroup.TASKS,
    )

    block_generation_time: float = metric_field(
        default=0,
        description="Time spent generating blocks in tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    block_serialization_time_s: float = metric_field(
        default=0,
        description="Time spent serializing blocks produced.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_submission_backpressure_time: float = metric_field(
        default=0,
        description="Wall-clock time operator wasn't able to launch any new tasks.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_output_backpressure_time: float = metric_field(
        default=0,
        description="Wall-clock time operator wasn't able to read any outputs.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_completion_time_s: float = metric_field(
        default=0,
        description="Time spent running tasks to completion, as measured by the *driver*. This is a cumulative sum of all tasks' completion times.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_worker_completion_time_s: float = metric_field(
        default=0,
        description="Time spent running tasks to completion, as measured by the *workers*. This is a cumulative sum of all tasks' completion times.",
        metrics_group=MetricsGroup.TASKS,
    )
    task_scheduling_time_s: float = metric_field(
        default=0,
        description=(
            "Time spent scheduling tasks: this tracks time from launching the task in the driver, "
            "all the way until it starts running (which is including fetching its arguments "
            "from remote Object Store, submitting to a worker, etc)"
        ),
        metrics_group=MetricsGroup.TASKS,
    )
    task_output_backpressure_time_s: float = metric_field(
        default=0,
        description=(
            "Total time tasks spent in output back-pressure: when task had outputs available but "
            "these weren't retrieved from it."
        ),
        metrics_group=MetricsGroup.TASKS,
    )
    task_completion_time: RuntimeMetricsHistogram = metric_field(
        default_factory=lambda: RuntimeMetricsHistogram(histogram_buckets_s),
        description="Time spent per task running those tasks to completion.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Histogram,
        metrics_args={"boundaries": histogram_buckets_s},
    )
    block_completion_time: RuntimeMetricsHistogram = metric_field(
        default_factory=lambda: RuntimeMetricsHistogram(histogram_buckets_s),
        description="Time spent running a single block to completion. If multiple blocks are generated per task, this is approximated by assuming each block took an equal amount of time to process.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Histogram,
        metrics_args={"boundaries": histogram_buckets_s},
    )
    task_block_gen_and_ser_time_s: float = metric_field(
        default=0,
        description=(
            "Time spent by tasks running UDF, generating blocks and serializing "
            "this into Ray objects"
        ),
        metrics_group=MetricsGroup.TASKS,
    )
    block_size_bytes: RuntimeMetricsHistogram = metric_field(
        default_factory=lambda: RuntimeMetricsHistogram(histogram_buckets_bytes),
        description="Size of blocks generated by tasks.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Histogram,
        metrics_args={"boundaries": histogram_buckets_bytes},
    )
    block_size_rows: RuntimeMetricsHistogram = metric_field(
        default_factory=lambda: RuntimeMetricsHistogram(histogram_bucket_rows),
        description="Number of rows in blocks generated by tasks.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Histogram,
        metrics_args={"boundaries": histogram_bucket_rows},
    )

    # === Actor-related metrics ===
    num_alive_actors: int = metric_field(
        default=0,
        description="Number of alive actors.",
        metrics_group=MetricsGroup.ACTORS,
    )
    num_restarting_actors: int = metric_field(
        default=0,
        description="Number of restarting actors.",
        metrics_group=MetricsGroup.ACTORS,
    )
    num_pending_actors: int = metric_field(
        default=0,
        description="Number of pending actors.",
        metrics_group=MetricsGroup.ACTORS,
    )
    num_active_actors: int = metric_field(
        default=0,
        description="Number of actors with at least one active task.",
        metrics_group=MetricsGroup.ACTORS,
    )
    num_idle_actors: int = metric_field(
        default=0,
        description="Number of idle actors (no active tasks).",
        metrics_group=MetricsGroup.ACTORS,
    )
    pool_utilization: float = metric_field(
        default=0.0,
        description="Actor pool utilization ratio (tasks_in_flight / max_capacity).",
        metrics_group=MetricsGroup.ACTORS,
    )
    num_tasks_in_flight: int = metric_field(
        default=0,
        description="Number of tasks currently being processed by actors.",
        metrics_group=MetricsGroup.ACTORS,
    )

    # === Object store memory metrics ===
    obj_store_mem_internal_inqueue_blocks: int = metric_field(
        default=0,
        description="Number of blocks in operator's internal input queue.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    obj_store_mem_internal_outqueue_blocks: int = metric_field(
        default=0,
        description="Number of blocks in the operator's internal output queue.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    obj_store_mem_freed: int = metric_field(
        default=0,
        description="Byte size of freed memory in object store.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    obj_store_mem_spilled: int = metric_field(
        default=0,
        description="Byte size of spilled memory in object store.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    obj_store_mem_used: int = metric_field(
        default=0,
        description="Byte size of used memory in object store.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )

    def __init__(self, op: "PhysicalOperator"):
        from ray.data._internal.execution.operators.map_operator import MapOperator

        self._op = op
        self._is_map = isinstance(op, MapOperator)
        self._running_tasks: Dict[int, RunningTaskInfo] = {}
        self._extra_metrics: Dict[str, Any] = {}
        # Start time of current pause due to task submission backpressure
        self._task_submission_backpressure_start_time = -1
        # Start time of current pause due to task output backpressure
        self._task_output_backpressure_start_time = -1

        num_inputs = max(len(op.input_dependencies), 1)
        self._internal_inqueues = [create_bundle_queue() for _ in range(num_inputs)]
        self._internal_outqueue = create_bundle_queue()
        self._pending_task_inputs = create_bundle_queue()

        self._per_node_metrics: Dict[str, NodeMetrics] = defaultdict(NodeMetrics)
        self._per_node_metrics_enabled: bool = op.data_context.enable_per_node_metrics

        # Initialize the histogram and distribution metrics
        self.task_completion_time = RuntimeMetricsHistogram(histogram_buckets_s)
        self.block_completion_time = RuntimeMetricsHistogram(histogram_buckets_s)
        self.block_size_bytes = RuntimeMetricsHistogram(histogram_buckets_bytes)
        self.block_size_rows = RuntimeMetricsHistogram(histogram_bucket_rows)
        self._op_task_duration_stats = DistributionTracker()
        self._max_uss_bytes = DistributionTracker()

    @property
    def extra_metrics(self) -> Dict[str, Any]:
        """Return a dict of extra metrics."""
        return self._extra_metrics

    @classmethod
    def get_metrics(self) -> List[MetricDefinition]:
        return list(_METRICS)

    def as_dict(
        self,
        skip_internal_metrics: bool = False,
    ) -> Dict[str, Any]:
        """
        Return a dict representation of the metrics.

        Args:
            skip_internal_metrics: Whether to skip internal metrics.

        Returns:
            A dict representation of the metrics.
        """

        result = []
        for metric in self.get_metrics():
            if not self._is_map and metric.map_only:
                continue
            if skip_internal_metrics and metric.internal_only:
                continue
            value = getattr(self, metric.name)
            if hasattr(value, "as_dict"):
                value = value.as_dict()
            result.append((metric.name, value))

        # TODO: record resource usage in OpRuntimeMetrics,
        # avoid calling self._op.current_logical_usage()
        resource_usage = self._op.current_logical_usage()
        result.extend(
            [
                ("cpu_usage", resource_usage.cpu or 0),
                ("gpu_usage", resource_usage.gpu or 0),
            ]
        )
        result.extend(self._extra_metrics.items())
        return dict(result)

    @metric_property(
        description="Average number of blocks generated per task.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    def average_num_outputs_per_task(self) -> Optional[float]:
        """Average number of output blocks per task, or None if no task has finished."""
        if self.num_tasks_finished == 0:
            return None
        else:
            return self.num_outputs_of_finished_tasks / self.num_tasks_finished

    @metric_property(
        description="Average number of blocks generated per task.",
        metrics_group=MetricsGroup.INPUTS,
    )
    def average_num_inputs_per_task(self) -> Optional[float]:
        """Average number of input blocks per task, or None if no task has finished."""
        if self.num_tasks_finished == 0:
            return None
        else:
            return self.num_task_inputs_processed / self.num_tasks_finished

    @metric_property(
        description="Average number of output blocks per task per second.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    def num_output_blocks_per_task_s(self) -> Optional[float]:
        """Average number of output blocks per task per second.

        If the operator hasn't produced any output yet, this metric returns `None`.
        """
        if self.block_generation_time == 0:
            return None
        else:
            return self.num_task_outputs_generated / self.block_generation_time

    @metric_property(
        description="Average task's completion time in seconds (inclusive of output throttling).",
        metrics_group=MetricsGroup.TASKS,
    )
    def average_total_task_completion_time_s(self) -> Optional[float]:
        """Average task's completion time in seconds (inclusive of output back-pressure)"""
        if self.num_tasks_finished == 0:
            return None

        return self.task_completion_time_s / self.num_tasks_finished

    @metric_property(
        description="Average task's scheduling time in seconds.",
        metrics_group=MetricsGroup.TASKS,
    )
    def average_task_scheduling_time_s(self) -> Optional[float]:
        """Average task's completion time in seconds (inclusive of output back-pressure)"""
        if self.num_tasks_have_outputs == 0:
            return None

        # NOTE: For correct calculation, we must use `num_tasks_have_outputs`, since
        #       scheduling time is incremented upon receiving of the first output
        return self.task_scheduling_time_s / self.num_tasks_have_outputs

    @metric_property(
        description="Average scheduling time (s) for cache-hit tasks.",
        metrics_group=MetricsGroup.TASKS,
        internal_only=True,
    )
    def average_task_scheduling_time_task_locality_hit_s(self) -> Optional[float]:
        if self.num_tasks_task_locality_hit == 0:
            return None
        return (
            self.task_scheduling_time_task_locality_hit_s
            / self.num_tasks_task_locality_hit
        )

    @metric_property(
        description="Average scheduling time (s) for cache-miss tasks.",
        metrics_group=MetricsGroup.TASKS,
        internal_only=True,
    )
    def average_task_scheduling_time_task_locality_miss_s(self) -> Optional[float]:
        if self.num_tasks_task_locality_miss == 0:
            return None
        return (
            self.task_scheduling_time_task_locality_miss_s
            / self.num_tasks_task_locality_miss
        )

    @metric_property(
        description="Average task's time spent in output back-pressure (in seconds).",
        metrics_group=MetricsGroup.TASKS,
    )
    def average_task_output_backpressure_time_s(self) -> Optional[float]:
        """Average task's output backpressure time in seconds"""
        if self.num_tasks_finished == 0:
            return None

        return self.task_output_backpressure_time_s / self.num_tasks_finished

    @metric_property(
        description="Average task's completion time in seconds (excluding output back-pressure).",
        metrics_group=MetricsGroup.TASKS,
    )
    def average_task_completion_time_excl_backpressure_s(self) -> Optional[float]:
        """Average task's completion time in seconds (excluding throttling)"""
        if self.num_tasks_finished == 0:
            return None

        return (
            self.task_completion_time_s - self.task_output_backpressure_time_s
        ) / self.num_tasks_finished

    @metric_property(
        description=(
            "Average task's cumulative block generation and serialization time. "
            "This metric tracks primarily pure UDF generation time, plus overhead "
            "to create Ray objects"
        ),
        metrics_group=MetricsGroup.TASKS,
    )
    def average_task_block_gen_and_ser_time_s(self) -> Optional[float]:
        """Average task's block generation and serialization time in seconds."""
        if self.num_tasks_finished == 0:
            return None

        return self.task_block_gen_and_ser_time_s / self.num_tasks_finished

    @metric_property(
        description="Average size of task output in bytes.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    def average_bytes_per_output(self) -> Optional[float]:
        """Average size in bytes of output blocks."""
        if self.num_task_outputs_generated == 0:
            return None
        else:
            return self.bytes_task_outputs_generated / self.num_task_outputs_generated

    @metric_property(
        description="Byte size of input blocks in the operator's internal input queues, summed across all input dependencies.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    def obj_store_mem_internal_inqueue(self) -> int:
        """Return the total inqueue bytes of all input dependencies."""
        return sum(q.estimate_size_bytes() for q in self._internal_inqueues)

    def obj_store_mem_internal_inqueue_for_input(self, input_index: int) -> int:
        """Return the inqueue bytes attributable to a specific input dependency."""
        return self._internal_inqueues[input_index].estimate_size_bytes()

    @metric_property(
        description=(
            "Byte size of output blocks in the operator's internal output queue."
        ),
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    def obj_store_mem_internal_outqueue(self) -> int:
        return self._internal_outqueue.estimate_size_bytes()

    @metric_property(
        description="Byte size of input blocks used by pending tasks.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    def obj_store_mem_pending_task_inputs(self) -> int:
        return self._pending_task_inputs.estimate_size_bytes()

    @metric_property(
        description="Byte size of *pending* (not yielded yet) output blocks in running tasks.",
        metrics_group=MetricsGroup.OBJECT_STORE_MEMORY,
    )
    def obj_store_mem_pending_task_outputs(self) -> Optional[float]:
        """Estimated size in bytes of output blocks in Ray generator buffers.

        If an estimate isn't available, this property returns ``None``.
        """
        per_task_output = self.obj_store_mem_max_pending_output_per_task
        if per_task_output is None:
            return None

        # Ray Data launches multiple tasks per actor, but only one task runs at a
        # time per actor. So, the number of actually running tasks is capped by the
        # number of active actors.
        from ray.data._internal.execution.operators.actor_pool_map_operator import (
            ActorPoolMapOperator,
        )

        num_tasks_running = self.num_tasks_running
        if isinstance(self._op, ActorPoolMapOperator):
            num_tasks_running = min(
                num_tasks_running, self._op._actor_pool.num_active_actors()
            )

        return num_tasks_running * per_task_output

    @property
    def obj_store_mem_max_pending_output_per_task(self) -> Optional[float]:
        """Estimated size in bytes of output blocks in a task's generator buffer."""
        context = self._op.data_context
        if context._max_num_blocks_in_streaming_gen_buffer is None:
            return None

        bytes_per_output = self.average_bytes_per_output
        # If no output has been produced it, return null
        #
        # NOTE: It's important that we do not overestimate pending task outputs
        #       assuming that it will be at least `target_max_block_size` as this
        #       might result in inability to schedule tasks that actually produce
        #       substantially smaller outputs.
        if bytes_per_output is None:
            return None

        num_pending_outputs = context._max_num_blocks_in_streaming_gen_buffer
        if self.average_num_outputs_per_task is not None:
            num_pending_outputs = min(
                num_pending_outputs, self.average_num_outputs_per_task
            )

        return bytes_per_output * num_pending_outputs

    @metric_property(
        description="Average size of task inputs in bytes.",
        metrics_group=MetricsGroup.INPUTS,
    )
    def average_bytes_inputs_per_task(self) -> Optional[float]:
        """Average size in bytes of ref bundles passed to tasks, or ``None`` if no
        tasks have been submitted."""
        if self.num_tasks_submitted == 0:
            return None
        else:
            return self.bytes_inputs_of_submitted_tasks / self.num_tasks_submitted

    @metric_property(
        description="Average number of rows passed in to the task.",
        metrics_group=MetricsGroup.INPUTS,
    )
    def average_rows_inputs_per_task(self) -> Optional[float]:
        """Average number of rows in input blocks per task,
        or None if no task has been submitted."""
        if self.num_tasks_submitted == 0:
            return None
        else:
            return self.rows_inputs_of_submitted_tasks / self.num_tasks_submitted

    @metric_property(
        description="Average total output size of task in bytes.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    def average_bytes_outputs_per_task(self) -> Optional[float]:
        """Average size in bytes of output blocks per task,
        or None if no task has finished."""
        if self.num_tasks_finished == 0:
            return None
        else:
            return self.bytes_outputs_of_finished_tasks / self.num_tasks_finished

    @metric_property(
        description="Average number of rows produced per task.",
        metrics_group=MetricsGroup.OUTPUTS,
    )
    def average_rows_outputs_per_task(self) -> Optional[float]:
        """Average number of rows in output blocks per task,
        or None if no task has finished."""
        if self.num_tasks_finished == 0:
            return None
        else:
            return self.rows_outputs_of_finished_tasks / self.num_tasks_finished

    @metric_property(
        description="Distribution of task durations in seconds.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Unsupported,
    )
    def op_task_duration_stats(self) -> DistributionTracker:
        return self._op_task_duration_stats

    @metric_property(
        description="Distribution of max USS bytes across tasks.",
        metrics_group=MetricsGroup.TASKS,
        metrics_type=MetricsType.Distribution,
    )
    def max_uss_bytes(self) -> DistributionTracker:
        return self._max_uss_bytes

    def on_input_received(self, input: RefBundle):
        """Callback when the operator receives a new input."""
        self.num_inputs_received += 1
        self.num_row_inputs_received += input.num_rows() or 0
        self.bytes_inputs_received += input.size_bytes()

    def on_input_queued(self, input: RefBundle, *, input_index: int):
        """Callback when the operator queues an input."""
        self.obj_store_mem_internal_inqueue_blocks += len(input.blocks)
        self._internal_inqueues[input_index].add(input)

    def on_input_dequeued(self, input: RefBundle, *, input_index: int):
        """Callback when the operator dequeues an input."""
        self.obj_store_mem_internal_inqueue_blocks -= len(input.blocks)
        input_size = input.size_bytes()
        self._internal_inqueues[input_index].remove(input)
        assert self.obj_store_mem_internal_inqueue >= 0, (
            self._op,
            self.obj_store_mem_internal_inqueue,
            input_size,
        )

    def on_output_queued(self, output: RefBundle):
        """Callback when an output is queued by the operator."""
        self.obj_store_mem_internal_outqueue_blocks += len(output.blocks)
        self._internal_outqueue.add(output)

    def on_output_dequeued(self, output: RefBundle):
        """Callback when an output is dequeued by the operator."""
        self.obj_store_mem_internal_outqueue_blocks -= len(output.blocks)
        output_size = output.size_bytes()
        self._internal_outqueue.remove(output)
        assert self.obj_store_mem_internal_outqueue >= 0, (
            self._op,
            self.obj_store_mem_internal_outqueue,
            output_size,
        )

    def on_toggle_task_submission_backpressure(self, in_backpressure):
        if in_backpressure and self._task_submission_backpressure_start_time == -1:
            # backpressure starting, start timer
            self._task_submission_backpressure_start_time = time.perf_counter()
        elif self._task_submission_backpressure_start_time != -1:
            # backpressure stopping, stop timer
            self.task_submission_backpressure_time += (
                time.perf_counter() - self._task_submission_backpressure_start_time
            )
            self._task_submission_backpressure_start_time = -1

    def on_toggle_task_output_backpressure(self, in_backpressure):
        if in_backpressure and self._task_output_backpressure_start_time == -1:
            # backpressure starting, start timer
            self._task_output_backpressure_start_time = time.perf_counter()
        elif self._task_output_backpressure_start_time != -1:
            # backpressure stopping, stop timer
            delta = time.perf_counter() - self._task_output_backpressure_start_time
            self.task_output_backpressure_time += delta
            self._task_output_backpressure_start_time = -1

    def on_output_taken(self, output: RefBundle):
        """Callback when an output is taken from the operator."""
        self.num_outputs_taken += 1
        self.block_outputs_taken += len(output)
        self.row_outputs_taken += output.num_rows() or 0
        self.bytes_outputs_taken += output.size_bytes()

    def on_task_submitted(
        self,
        task_index: int,
        inputs: RefBundle,
        task_id: Optional[ray.TaskID] = None,
    ):
        """Callback when the operator submits a task."""
        self.num_tasks_submitted += 1
        self.num_tasks_running += 1
        self.bytes_inputs_of_submitted_tasks += inputs.size_bytes()
        self.rows_inputs_of_submitted_tasks += inputs.num_rows() or 0
        self._pending_task_inputs.add(inputs)
        input_node_ids = {
            node_id_from_block_metadata(entry.metadata) for entry in inputs.blocks
        }
        self._running_tasks[task_index] = RunningTaskInfo(
            inputs=inputs,
            num_outputs=0,
            bytes_output=0,
            num_rows_produced=0,
            start_time=time.perf_counter(),
            cum_block_gen_time_s=0,
            cum_block_ser_time_s=0,
            task_id=ray.TaskID.nil() if task_id is None else task_id,
            input_node_ids=input_node_ids,
        )

    def on_task_output_generated(self, task_index: int, output: RefBundle):
        """Callback when a new task generates an output."""
        num_outputs = len(output)
        output_bytes = output.size_bytes()
        num_rows_produced = output.num_rows()

        self.num_task_outputs_generated += num_outputs
        self.bytes_task_outputs_generated += output_bytes
        self.rows_task_outputs_generated += num_rows_produced
        for block in output.metadata:
            if block.size_bytes is not None:
                self.block_size_bytes.observe(block.size_bytes)
            if block.num_rows is not None:
                self.block_size_rows.observe(block.num_rows)

        task_info = self._running_tasks[task_index]

        # Check if first task's outputs;
        if task_info.num_outputs == 0:
            self.num_tasks_have_outputs += 1
            # Checkpoint time to first block
            time_to_first_output_s = time.perf_counter() - task_info.start_time
        else:
            time_to_first_output_s = None

        task_info.num_outputs += num_outputs
        task_info.bytes_output += output_bytes
        task_info.num_rows_produced += num_rows_produced
        task_info.last_updated = time.perf_counter()

        first_output_node_id = None
        for entry in output.blocks:
            block_ref = entry.ref
            meta = entry.metadata
            exec_stats = meta.exec_stats

            assert (
                exec_stats is not None
                and exec_stats.wall_time_s is not None
                and exec_stats.block_ser_time_s is not None
            )

            self.block_generation_time += exec_stats.wall_time_s
            self.block_serialization_time_s += exec_stats.block_ser_time_s

            task_info.cum_block_gen_time_s += exec_stats.wall_time_s
            task_info.cum_block_ser_time_s += exec_stats.block_ser_time_s

            assert meta.num_rows is not None

            trace_allocation(block_ref, "operator_output")

            output_node_id = node_id_from_block_metadata(meta)
            if first_output_node_id is None:
                first_output_node_id = output_node_id

        # Task's scheduling time is calculated as:
        #
        #   Time to first block (driver) - Time to generate & ser first block (worker)
        #
        # NOTE: We're only tracking task scheduling time when `TaskExecStats`
        #       are reported (ie when task completes successfully)
        if time_to_first_output_s is not None:
            scheduling_delta = time_to_first_output_s - (
                task_info.cum_block_gen_time_s + task_info.cum_block_ser_time_s
            )
            self.task_scheduling_time_s += scheduling_delta

            # Classify the task as cache hit/miss based on first output block
            is_hit = (
                first_output_node_id is not None
                and first_output_node_id != NODE_UNKNOWN
                and first_output_node_id in task_info.input_node_ids
            )
            task_info.is_task_locality_hit = is_hit
            if is_hit:
                self.num_tasks_task_locality_hit += 1
                self.task_scheduling_time_task_locality_hit_s += scheduling_delta
            else:
                self.num_tasks_task_locality_miss += 1
                self.task_scheduling_time_task_locality_miss_s += scheduling_delta

        # Update per node metrics
        if self._per_node_metrics_enabled:
            for entry in output.blocks:
                meta = entry.metadata
                node_id = node_id_from_block_metadata(meta)
                node_metrics = self._per_node_metrics[node_id]

                node_metrics.bytes_outputs_of_finished_tasks += meta.size_bytes
                node_metrics.blocks_outputs_of_finished_tasks += 1

    def on_task_finished(
        self,
        task_index: int,
        exception: Optional[Exception],
        task_exec_stats: Optional["TaskExecWorkerStats"],
        task_exec_driver_stats: Optional["TaskExecDriverStats"],
    ):
        """Callback when a task is finished."""
        self.num_tasks_running -= 1
        self.num_tasks_finished += 1
        if exception is not None:
            self.num_tasks_failed += 1

        task_info = self._running_tasks[task_index]

        self.num_outputs_of_finished_tasks += task_info.num_outputs
        self.bytes_outputs_of_finished_tasks += task_info.bytes_output
        self.rows_outputs_of_finished_tasks += task_info.num_rows_produced

        # NOTE: This metric tracks task's wall-clock time as measured by
        #       the driver which starts upon scheduling of the task and runs
        #       until this callback is invoked
        task_wall_time_s = time.perf_counter() - task_info.start_time

        self.task_completion_time_s += task_wall_time_s
        self.task_completion_time.observe(task_wall_time_s)

        # Accumulate throughput accumulators split by cache hit/miss
        if task_info.is_task_locality_hit is True:
            self.bytes_inputs_of_task_locality_hit_tasks += (
                task_info.inputs.size_bytes()
            )
            self.task_completion_time_task_locality_hit_s += task_wall_time_s
        elif task_info.is_task_locality_hit is False:
            self.bytes_inputs_of_task_locality_miss_tasks += (
                task_info.inputs.size_bytes()
            )
            self.task_completion_time_task_locality_miss_s += task_wall_time_s

        # NOTE: This metric tracks task's wall-clock time as measured by
        #       the workers executing the task
        if task_exec_stats is not None:
            self.task_worker_completion_time_s += task_exec_stats.task_wall_time_s

        # NOTE: This is used for Issue Detection
        self._op_task_duration_stats.add_sample(task_wall_time_s)

        if task_exec_stats is not None and task_exec_stats.max_uss_bytes is not None:
            self._max_uss_bytes.add_sample(task_exec_stats.max_uss_bytes)

        task_output_backpressure_s = (
            task_exec_driver_stats.task_output_backpressure_s
            if task_exec_driver_stats
            else 0
        )

        self.task_output_backpressure_time_s += task_output_backpressure_s

        assert task_info.cum_block_gen_time_s is not None

        block_gen_and_ser_time_s = (
            task_info.cum_block_gen_time_s + task_info.cum_block_ser_time_s
        )

        self.task_block_gen_and_ser_time_s += block_gen_and_ser_time_s

        if task_info.num_outputs > 0:
            # Calculate the average block generation time per block
            block_time_delta = block_gen_and_ser_time_s / task_info.num_outputs

            self.block_completion_time.observe(
                block_time_delta, num_observations=task_info.num_outputs
            )

        inputs = self._running_tasks[task_index].inputs
        self.num_task_inputs_processed += len(inputs)
        total_input_size = inputs.size_bytes()
        self.bytes_task_inputs_processed += total_input_size
        input_size = inputs.size_bytes()
        self._pending_task_inputs.remove(inputs)
        assert self.obj_store_mem_pending_task_inputs >= 0, (
            self._op,
            self.obj_store_mem_pending_task_inputs,
            input_size,
        )

        ctx = self._op.data_context
        if ctx.enable_get_object_locations_for_metrics:
            locations = ray.experimental.get_object_locations(inputs.block_refs)
            for entry in inputs.blocks:
                meta = entry.metadata
                if locations[entry.ref].get("did_spill", False):
                    assert meta.size_bytes is not None
                    self.obj_store_mem_spilled += meta.size_bytes

        self.obj_store_mem_freed += total_input_size

        # Update per node metrics
        if self._per_node_metrics_enabled:
            node_ids = set()
            for entry in inputs.blocks:
                meta = entry.metadata
                node_id = node_id_from_block_metadata(meta)
                node_metrics = self._per_node_metrics[node_id]

                # Stats to update once per node id or if node id is unknown
                if node_id not in node_ids or node_id == NODE_UNKNOWN:
                    node_metrics.num_tasks_finished += 1

                # Keep track of node ids to ensure we don't double count
                node_ids.add(node_id)

        inputs.destroy_if_owned()
        del self._running_tasks[task_index]
