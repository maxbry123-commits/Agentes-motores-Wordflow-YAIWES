import logging
from typing import TYPE_CHECKING, Optional

from .backpressure_policy import BackpressurePolicy
from ray._common.utils import env_float
from ray.data._internal.execution.resource_manager import (
    _BLOCKING_MATERIALIZING_OPERATORS,
    ResourceManager,
)
from ray.data.context import DataContext

if TYPE_CHECKING:
    from ray.data._internal.execution.interfaces.physical_operator import (
        PhysicalOperator,
    )
    from ray.data._internal.execution.streaming_executor_state import Topology

logger = logging.getLogger(__name__)


def get_available_object_store_budget_fraction(
    resource_manager: "ResourceManager",
    op: "PhysicalOperator",
    consider_downstream_ineligible_ops: bool,
) -> Optional[float]:
    """Get available object store memory budget fraction for the operator.

    Args:
        resource_manager: The resource manager to use.
        op: The operator to get the budget fraction for.
        consider_downstream_ineligible_ops: If True, include downstream ineligible
            ops in the calculation. If False, only consider this op's usage/budget.

    Returns:
        The available budget fraction, or None if not available.
    """
    op_usage = resource_manager.get_op_usage(
        op, include_ineligible_downstream=consider_downstream_ineligible_ops
    )
    op_budget = resource_manager.get_budget(op)
    if op_usage is None or op_budget is None:
        return None

    total_usage = op_usage.object_store_memory

    total_budget = op_budget.object_store_memory
    total_mem = total_usage + total_budget
    if total_mem == 0:
        return None

    return total_budget / total_mem


def get_utilized_object_store_budget_fraction(
    resource_manager: "ResourceManager",
    op: "PhysicalOperator",
    consider_downstream_ineligible_ops: bool,
) -> Optional[float]:
    """Get utilized object store memory budget fraction for the operator.

    Args:
        resource_manager: The resource manager to use.
        op: The operator to get the utilized fraction for.
        consider_downstream_ineligible_ops: If True, include downstream ineligible
            ops in the calculation. If False, only consider this op's usage/budget.

    Returns:
        The utilized budget fraction, or None if not available.
    """
    available_fraction = get_available_object_store_budget_fraction(
        resource_manager,
        op,
        consider_downstream_ineligible_ops=consider_downstream_ineligible_ops,
    )
    if available_fraction is None:
        return None
    return 1 - available_fraction


class DownstreamCapacityBackpressurePolicy(BackpressurePolicy):
    """Backpressure policy based on downstream processing capacity.

    To backpressure a given operator, use queue size build up / downstream capacity ratio.
    This ratio represents the upper limit of buffering in object store between pipeline stages
    to optimize for throughput.
    """

    # Threshold for per-Op object store budget utilization vs total
    # (utilization / total) ratio to enable downstream capacity backpressure.
    OBJECT_STORE_BUDGET_UTIL_THRESHOLD = env_float(
        "RAY_DATA_DOWNSTREAM_CAPACITY_OBJECT_STORE_BUDGET_UTIL_THRESHOLD", 0.5
    )

    @property
    def name(self) -> str:
        return "DownstreamCapacity"

    def __init__(
        self,
        data_context: DataContext,
        topology: "Topology",
        resource_manager: "ResourceManager",
    ):
        super().__init__(data_context, topology, resource_manager)

        self._backpressure_capacity_ratio = (
            self._data_context.downstream_capacity_backpressure_ratio
        )
        self._prev_should_backpressure: dict["PhysicalOperator", bool] = {}

        if self._backpressure_capacity_ratio is not None:
            logger.debug(
                "DownstreamCapacityBackpressurePolicy enabled with "
                f"ratio threshold: {self._backpressure_capacity_ratio}"
            )

    def _get_downstream_capacity_size_bytes(self, op: "PhysicalOperator") -> int:
        """Get the downstream capacity size for the given operator.

        Downstream capacity size is the sum of the pending task inputs of the
        downstream eligible operators.

        If an output dependency is ineligible, skip it and recurse down to find
        eligible output dependencies. If there are no output dependencies,
        return external consumer bytes.
        """
        if not op.output_dependencies:
            # No output dependencies, return external consumer bytes.
            return self._resource_manager.get_external_consumer_bytes()

        total_capacity_size_bytes = 0
        for output_dependency in op.output_dependencies:
            if self._resource_manager.is_op_eligible(output_dependency):
                # Output dependency is eligible, add its pending task inputs.
                total_capacity_size_bytes += (
                    output_dependency.metrics.obj_store_mem_pending_task_inputs or 0
                )
            else:
                # Output dependency is ineligible, recurse down to find eligible ops.
                total_capacity_size_bytes += self._get_downstream_capacity_size_bytes(
                    output_dependency
                )
        return total_capacity_size_bytes

    def _should_skip_backpressure(self, op: "PhysicalOperator") -> bool:
        """Check if backpressure should be skipped for the operator.
        TODO(srinathk10): Extract this to common logic to skip invoking BackpressurePolicy.
        """
        if self._backpressure_capacity_ratio is None:
            # Downstream capacity backpressure is disabled.
            return True

        if not self._resource_manager.is_op_eligible(op):
            # Operator is not eligible for backpressure.
            return True

        if self._resource_manager._is_blocking_materializing_op(op):
            # The operator or one of its ineligible downstream operators is a
            # blocking materializer, so no need to perform backpressure.
            return True

        if any(
            isinstance(downstream_op, _BLOCKING_MATERIALIZING_OPERATORS)
            for downstream_op in self._resource_manager.get_downstream_eligible_ops(op)
        ):
            # Downstream capacity is materializing, so don't backpressure against it.
            return True

        return False

    def _get_output_pressure(self, op: "PhysicalOperator") -> float:
        """Calculate the output pressure of the current operator on the
        downstream operator.

        We estimate this with: `op_output_bytes / downstream_bytes_in_flight`

        If output_pressure == 0, the consumer may be starving for inputs.
        If output_pressure == 1, we have exactly one "batch" of prefetched
        outputs, and the pipeline should be flowing smoothly.
        If output_pressure > THRESHOLD, the producer is outpacing the consumer
        significantly. Apply backpressure.
        """
        downstream_capacity_size_bytes = self._get_downstream_capacity_size_bytes(op)
        if downstream_capacity_size_bytes == 0:
            # No downstream capacity to backpressure against, so no backpressure.
            return 0

        output_size_bytes = self._resource_manager.get_mem_op_outputs(
            op, include_ineligible_downstream=True
        )
        # output_size_bytes includes both buffered outputs and downstream
        # in-flight inputs. Subtract 1 to isolate the buffered portion:
        #   output_pressure = op_outqueue_bytes / downstream_in_flight_bytes
        #   output_size_bytes = op_outqueue_bytes + downstream_in_flight_bytes
        #   output_pressure = output_size_bytes / downstream_in_flight_bytes - 1
        return (output_size_bytes / downstream_capacity_size_bytes) - 1

    def _should_apply_backpressure(self, op: "PhysicalOperator") -> bool:
        """Check if backpressure should be applied for the operator.

        Returns True if backpressure should be applied, False otherwise.
        """
        if self._should_skip_backpressure(op):
            return False

        utilized_budget_fraction = get_utilized_object_store_budget_fraction(
            self._resource_manager, op, consider_downstream_ineligible_ops=True
        )
        output_pressure = self._get_output_pressure(op)

        if (
            utilized_budget_fraction is not None
            and utilized_budget_fraction <= self.OBJECT_STORE_BUDGET_UTIL_THRESHOLD
        ):
            # Utilized budget fraction is below threshold, so should skip backpressure.
            result = False
        else:
            # Apply backpressure if output pressure exceeds the threshold.
            result = output_pressure > self._backpressure_capacity_ratio

        prev = self._prev_should_backpressure.get(op)
        if prev != result:
            downstream_capacity_bytes = self._get_downstream_capacity_size_bytes(op)
            output_size_bytes = self._resource_manager.get_mem_op_outputs(
                op, include_ineligible_downstream=True
            )
            logger.debug(
                f"Backpressure change {op.name}: {prev} -> {result} "
                f"({output_pressure=}, {output_size_bytes=}, "
                f"{downstream_capacity_bytes=}, {utilized_budget_fraction=})"
            )
            self._prev_should_backpressure[op] = result

        return result

    def can_add_input(self, op: "PhysicalOperator") -> bool:
        """Determine if we can add input to the operator based on
        downstream capacity.
        """
        return not self._should_apply_backpressure(op)

    def max_task_output_bytes_to_read(self, op: "PhysicalOperator") -> Optional[int]:
        """Return the maximum bytes of pending task outputs can be read for
        the given operator. None means no limit."""
        if self._should_apply_backpressure(op):
            return 0
        return None
