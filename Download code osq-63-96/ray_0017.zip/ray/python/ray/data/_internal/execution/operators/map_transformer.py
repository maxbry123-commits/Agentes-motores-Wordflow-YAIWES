import itertools
import time
from abc import ABC, abstractmethod
from enum import Enum
from typing import (
    Any,
    Callable,
    Dict,
    Iterable,
    Iterator,
    List,
    Literal,
    Optional,
    Tuple,
    TypeVar,
    Union,
)

from ray._common.utils import env_integer
from ray.data._internal.block_batching.block_batching import batch_blocks
from ray.data._internal.execution.interfaces.task_context import TaskContext
from ray.data._internal.output_buffer import BlockOutputBuffer, OutputBlockSizeOption
from ray.data.block import (
    BatchFormat,
    Block,
    BlockAccessor,
    CustomOpStats,
    DataBatch,
)

_DEFAULT_BATCH_SIZE_BYTES: int = env_integer(
    "RAY_DATA_DEFAULT_BATCH_SIZE_BYTES", 16 * 1024 * 1024  # 16 MiB
)

# Allowed input/output data types for a MapTransformFn.
Row = Dict[str, Any]
MapTransformFnData = Union[Block, Row, DataBatch]


class CustomOpStatsReporter:
    """Per-task reporter that carries transforms' :class:`CustomOpStats`.

    ``_map_task`` creates one per task and threads it into the transform chain.
    Each producing transform calls ``op_stats_reporter.report(stats)`` once,
    before yielding output blocks, to append its :class:`CustomOpStats` to the
    reporter. Fused transforms each contribute one entry, so the reporter holds a
    list. ``_map_task`` reads :meth:`get_stats` after each output block and stamps
    the list onto the block metadata as part of ``TaskExecWorkerStats``
    """

    def __init__(self) -> None:
        self._stats: List[CustomOpStats] = []

    def report(self, stats: CustomOpStats) -> None:
        """Append a producing transform's per-task CustomOpStats."""
        self._stats.append(stats)

    def get_stats(self) -> List[CustomOpStats]:
        """Return all reported CustomOpStats (empty if none were reported)."""
        return self._stats

    def clear(self) -> None:
        """Drop any reported stats (called before each task attempt)."""
        self._stats = []


# Narrow callback handed to producing transforms to report per-task
# :class:`CustomOpStats`.
CustomOpStatsReportFn = Callable[[CustomOpStats], None]


def _noop_report_custom_op_stats(stats: CustomOpStats) -> None:
    """Stateless default report callback for callers that don't collect stats."""


IN = TypeVar("IN")
OUT = TypeVar("OUT")
# A transform callable accepts either ``(data, ctx)`` or, when it reports
# per-task CustomOpStats, ``(data, ctx, report_custom_op_stats)``.
MapTransformCallable = Union[
    Callable[[Iterable[IN], TaskContext], Iterable[OUT]],
    Callable[[Iterable[IN], TaskContext, CustomOpStatsReportFn], Iterable[OUT]],
]


class MapTransformFnDataType(Enum):
    """An enum that represents the input/output data type of a MapTransformFn."""

    Block = 0
    Row = 1
    Batch = 2


class MapTransformFn(ABC):
    """Represents a single transform function in a MapTransformer."""

    def __init__(
        self,
        fn: Callable,
        input_type: MapTransformFnDataType,
        *,
        is_udf: bool = False,
        output_block_size_option: Optional[OutputBlockSizeOption] = None,
        should_report_custom_op_stats: bool = False,
    ):
        """Initialize a :class:`MapTransformFn`.

        Args:
            fn: The wrapped transform callable. Invoked with ``(data, ctx)``, or
                ``(data, ctx, report_custom_op_stats)`` when
                ``should_report_custom_op_stats=True``.
            input_type: Expected type of the input data.
            is_udf: Whether this transformation is UDF or not.
            output_block_size_option: (Optional) Output block size configuration.
            should_report_custom_op_stats: If ``True``, the wrapped callable accepts a
                third ``report_custom_op_stats`` callback argument and may report
                per-task :class:`CustomOpStats` to the driver. Defaults to
                ``False``, in which case the callable is invoked with
                ``(data, ctx)`` only.
        """
        self._fn = fn
        self._input_type = input_type
        self._output_block_size_option = output_block_size_option
        self._is_udf = is_udf
        self._should_report_custom_op_stats = should_report_custom_op_stats

    @abstractmethod
    def _post_process(self, results: Iterable[MapTransformFnData]) -> Iterable[Block]:
        pass

    def _apply_transform(
        self,
        ctx: TaskContext,
        inputs: Iterable[MapTransformFnData],
        report_custom_op_stats: CustomOpStatsReportFn = _noop_report_custom_op_stats,
    ) -> Iterable[MapTransformFnData]:
        """Call the wrapped fn, passing ``report_custom_op_stats`` only if it opted in.

        Keeps the common ``(data, ctx)`` signature for the vast majority of
        transforms; only those constructed with ``should_report_custom_op_stats=True``
        receive the report callback.
        """
        if self._should_report_custom_op_stats:
            return self._fn(inputs, ctx, report_custom_op_stats)
        return self._fn(inputs, ctx)

    def _pre_process(self, blocks: Iterable[Block]) -> Iterable[MapTransformFnData]:
        return blocks

    def _shape_blocks(self, results: Iterable[MapTransformFnData]) -> Iterable[Block]:
        """Shape results into blocks using a buffer."""
        return _BlockShapingIterator(
            results, self._input_type, self._output_block_size_option
        )

    def __call__(
        self,
        blocks: Iterable[Block],
        ctx: TaskContext,
        report_custom_op_stats: CustomOpStatsReportFn = _noop_report_custom_op_stats,
    ) -> Iterable[Block]:
        batches = self._pre_process(blocks)
        results = self._apply_transform(ctx, batches, report_custom_op_stats)
        return self._post_process(results)

    @property
    def output_block_size_option(self):
        return self._output_block_size_option

    def override_target_max_block_size(self, target_max_block_size: Optional[int]):
        if self._output_block_size_option is not None and (
            self._output_block_size_option.disable_block_shaping
            or self._output_block_size_option.target_num_rows_per_block is not None
        ):
            raise ValueError(
                "Cannot override target_max_block_size if block shaping is disabled or target_num_rows_per_block is set"
            )
        self._output_block_size_option = OutputBlockSizeOption.of(
            target_max_block_size=target_max_block_size
        )

    @property
    def target_max_block_size(self):
        if self._output_block_size_option is None:
            return None
        else:
            return self._output_block_size_option.target_max_block_size

    @property
    def target_num_rows_per_block(self):
        if self._output_block_size_option is None:
            return None
        else:
            return self._output_block_size_option.target_num_rows_per_block


class MapTransformer:
    """Encapsulates the data transformation logic of a physical MapOperator.

    A MapTransformer may consist of one or more steps, each of which is represented
    as a MapTransformFn. The first MapTransformFn must take blocks as input, and
    the last MapTransformFn must output blocks. The intermediate data types can
    be blocks, rows, or batches.
    """

    class _UDFTimingIterator(Iterator[MapTransformFnData]):
        """Iterator that times UDF execution"""

        def __init__(
            self, input: Iterable[MapTransformFnData], transformer: "MapTransformer"
        ):
            self._input = input
            self._transformer = transformer

        def __iter__(self) -> "MapTransformer._UDFTimingIterator":
            return self

        def __next__(self) -> MapTransformFnData:
            start = time.perf_counter()
            try:
                return next(self._input)
            finally:
                self._transformer._report_udf_time(time.perf_counter() - start)

    def __init__(
        self,
        transform_fns: List[MapTransformFn],
        *,
        init_fn: Optional[Callable[[], None]] = None,
        output_block_size_option_override: Optional[OutputBlockSizeOption] = None,
    ):
        """Initialize a :class:`MapTransformer`.

        Args:
            transform_fns: A list of `MapTransformFn`s that will be executed sequentially
                to transform data.
            init_fn: A function that will be called before transforming data.
                Used for the actor-based map operator.
            output_block_size_option_override: (Optional) Output block size configuration.
        """

        self._transform_fns: List[MapTransformFn] = []
        self._init_fn = init_fn if init_fn is not None else lambda: None
        self._output_block_size_option_override = output_block_size_option_override
        self._udf_time_s = 0

        # Add transformations
        self.add_transform_fns(transform_fns)

    def add_transform_fns(self, transform_fns: List[MapTransformFn]) -> None:
        """Set the transform functions."""
        assert len(transform_fns) > 0
        self._transform_fns = self._combine_transformations(
            self._transform_fns, transform_fns
        )

    def get_transform_fns(self) -> List[MapTransformFn]:
        """Get the transform functions."""
        return self._transform_fns

    def override_target_max_block_size(self, target_max_block_size: Optional[int]):
        self._output_block_size_option_override = OutputBlockSizeOption.of(
            target_max_block_size=target_max_block_size
        )

    @property
    def target_max_block_size_override(self) -> Optional[int]:
        if self._output_block_size_option_override is None:
            return None
        else:
            return self._output_block_size_option_override.target_max_block_size

    def init(self) -> None:
        """Initialize the transformer.

        Should be called before applying the transform.
        """
        self._init_fn()

    def apply_transform(
        self,
        input_blocks: Iterable[Block],
        ctx: TaskContext,
        report_custom_op_stats: CustomOpStatsReportFn = _noop_report_custom_op_stats,
    ) -> Iterable[Block]:
        """Apply the transform functions to the input blocks.

        Args:
            input_blocks: The blocks to transform.
            ctx: The task context for this transform.
            report_custom_op_stats: Callback a producing transform calls to report
                its :class:`CustomOpStats`. ``_map_task`` passes its reporter's
                ``report``; defaults to a stateless no-op for callers (e.g. tests)
                that don't collect custom stats.

        Returns:
            An iterable of the transformed output blocks.
        """
        # NOTE: We only need to configure last transforming function to do
        #       appropriate block sizing
        last_transform = self._transform_fns[-1]

        if self.target_max_block_size_override is not None:
            last_transform.override_target_max_block_size(
                self.target_max_block_size_override
            )

        iter = input_blocks
        # Apply the transform functions sequentially to the input iterable.
        for transform_fn in self._transform_fns:
            iter = transform_fn(iter, ctx, report_custom_op_stats)
            if transform_fn._is_udf:
                iter = self._UDFTimingIterator(iter, self)

        return iter

    def fuse(self, other: "MapTransformer") -> "MapTransformer":
        """Fuse two `MapTransformer`s together."""
        assert (
            self.target_max_block_size_override == other.target_max_block_size_override
            or (
                self.target_max_block_size_override is None
                or other.target_max_block_size_override is None
            )
        )
        # Define them as standalone variables to avoid fused_init_fn capturing the
        # entire `MapTransformer` object.
        self_init_fn = self._init_fn
        other_init_fn = other._init_fn

        def fused_init_fn():
            self_init_fn()
            other_init_fn()

        combined_transform_fns = self._combine_transformations(
            self._transform_fns,
            other._transform_fns,
        )

        transformer = MapTransformer(
            combined_transform_fns,
            init_fn=fused_init_fn,
            output_block_size_option_override=OutputBlockSizeOption.of(
                target_max_block_size=(
                    self.target_max_block_size_override
                    or other.target_max_block_size_override
                ),
            ),
        )

        return transformer

    @classmethod
    def _combine_transformations(
        cls, ones: List[MapTransformFn], others: List[MapTransformFn]
    ) -> list[Any]:
        return ones + others

    def udf_time_s(self, reset: bool) -> float:
        cur_time_s = self._udf_time_s
        if reset:
            self._udf_time_s = 0
        return cur_time_s

    def _report_udf_time(self, udf_time: float) -> None:
        self._udf_time_s += udf_time


class RowMapTransformFn(MapTransformFn):
    """A rows-to-rows MapTransformFn."""

    def __init__(
        self,
        row_fn: MapTransformCallable[Row, Row],
        *,
        is_udf: bool = False,
        output_block_size_option: OutputBlockSizeOption,
        should_report_custom_op_stats: bool = False,
    ):
        super().__init__(
            row_fn,
            input_type=MapTransformFnDataType.Row,
            is_udf=is_udf,
            output_block_size_option=output_block_size_option,
            should_report_custom_op_stats=should_report_custom_op_stats,
        )

    def _pre_process(self, blocks: Iterable[Block]) -> Iterable[MapTransformFnData]:
        return _RowBasedIterator(blocks)

    def _post_process(self, results: Iterable[MapTransformFnData]) -> Iterable[Block]:
        return self._shape_blocks(results)

    def __repr__(self) -> str:
        return f"RowMapTransformFn({self._fn})"


def _peek_first_nonempty_block(
    blocks: Iterable[Block],
) -> Tuple[Optional[BlockAccessor], Iterable[Block]]:
    """Advance the iterator past leading empty blocks to find the first non-empty block,
    returning the corresponding accessor and a reconstructed iterator of all blocks.
    We must reconstruct the iterator because we consume blocks as we advance through the iterator."""
    blocks_iter = iter(blocks)
    consumed = []
    for block in blocks_iter:
        consumed.append(block)
        accessor = BlockAccessor.for_block(block)
        if accessor.num_rows() > 0 and accessor.size_bytes() > 0:
            return accessor, itertools.chain(consumed, blocks_iter)
    return None, iter(consumed)


def _compute_auto_batch_size(
    blocks: Iterable[Block],
    target_batch_size_bytes: int = _DEFAULT_BATCH_SIZE_BYTES,
) -> Tuple[Optional[int], Iterable[Block]]:
    """Peek at the first non-empty block to estimate the batch size to use for the
    'auto' batch_size option."""
    sample, blocks = _peek_first_nonempty_block(blocks)
    if sample is None:
        return None, blocks
    bytes_per_row = sample.size_bytes() / sample.num_rows()
    computed_batch_size = max(1, int(target_batch_size_bytes / bytes_per_row))
    return computed_batch_size, blocks


class BatchMapTransformFn(MapTransformFn):
    """A batch-to-batch MapTransformFn."""

    def __init__(
        self,
        batch_fn: MapTransformCallable[DataBatch, DataBatch],
        *,
        is_udf: bool = False,
        batch_size: Union[Optional[int], Literal["auto"]] = None,
        batch_format: Optional[BatchFormat] = None,
        zero_copy_batch: bool = True,
        output_block_size_option: Optional[OutputBlockSizeOption] = None,
        target_batch_size_bytes: int = _DEFAULT_BATCH_SIZE_BYTES,
        should_report_custom_op_stats: bool = False,
    ):
        super().__init__(
            batch_fn,
            input_type=MapTransformFnDataType.Batch,
            is_udf=is_udf,
            output_block_size_option=output_block_size_option,
            should_report_custom_op_stats=should_report_custom_op_stats,
        )

        self._batch_size = batch_size
        self._batch_format = batch_format
        self._zero_copy_batch = zero_copy_batch
        self._target_batch_size_bytes = target_batch_size_bytes

    def _pre_process(self, blocks: Iterable[Block]) -> Iterable[MapTransformFnData]:
        # TODO make batch-udf zero-copy by default
        if self._batch_size == "auto":
            batch_size, blocks = _compute_auto_batch_size(
                blocks, target_batch_size_bytes=self._target_batch_size_bytes
            )
        else:
            batch_size = self._batch_size
        ensure_copy = not self._zero_copy_batch and batch_size is not None
        return batch_blocks(
            blocks=iter(blocks),
            stats=None,
            batch_size=batch_size,
            batch_format=self._batch_format,
            ensure_copy=ensure_copy,
        )

    def _post_process(self, results: Iterable[MapTransformFnData]) -> Iterable[Block]:
        return self._shape_blocks(results)

    def __repr__(self) -> str:
        return f"BatchMapTransformFn({self._fn=}, {self._batch_format=}, {self._batch_size=}, {self._zero_copy_batch=})"


class BlockMapTransformFn(MapTransformFn):
    """A block-to-block MapTransformFn."""

    def __init__(
        self,
        block_fn: MapTransformCallable[Block, Block],
        *,
        is_udf: bool = False,
        disable_block_shaping: bool = False,
        output_block_size_option: Optional[OutputBlockSizeOption] = None,
        should_report_custom_op_stats: bool = False,
    ):
        """
        Initializes the object with a transformation function, accompanying options, and
        configuration for handling blocks during processing.

        Args:
            block_fn: Callable function to apply a transformation to a block.
            is_udf: Specifies if the transformation function is a user-defined
                function (defaults to ``False``).
            disable_block_shaping: Disables block-shaping, making transformer to
                produce blocks as is.
            output_block_size_option: (Optional) Configure output block sizing.
            should_report_custom_op_stats: If ``True``, ``block_fn`` accepts a third
                ``report_custom_op_stats`` callback argument and may report
                per-task :class:`CustomOpStats` to the driver.
        """

        super().__init__(
            block_fn,
            input_type=MapTransformFnDataType.Block,
            is_udf=is_udf,
            output_block_size_option=output_block_size_option,
            should_report_custom_op_stats=should_report_custom_op_stats,
        )

        self._disable_block_shaping = disable_block_shaping

    def _post_process(self, results: Iterable[MapTransformFnData]) -> Iterable[Block]:
        # Short-circuit for block transformations for which no
        # block-shaping is required
        if self._disable_block_shaping:
            return results

        return self._shape_blocks(results)

    def __repr__(self) -> str:
        return f"BlockMapTransformFn({self._fn=}, {self._output_block_size_option=})"


class _BlockShapingIterator(Iterator[Block]):
    """Iterator that shapes results into blocks using a buffer.

    Unlike a generator, local variables in __next__ go out of scope when the method
    returns, avoiding holding references to yielded values.
    """

    def __init__(
        self,
        results: Iterable[MapTransformFnData],
        input_type: MapTransformFnDataType,
        output_block_size_option: Optional[OutputBlockSizeOption],
    ):
        self._results_iter = iter(results)
        self._buffer = BlockOutputBuffer(output_block_size_option)
        self._finalized = False

        if input_type == MapTransformFnDataType.Block:
            self._append_buffer = self._buffer.add_block
        elif input_type == MapTransformFnDataType.Batch:
            self._append_buffer = self._buffer.add_batch
        else:
            assert input_type == MapTransformFnDataType.Row
            self._append_buffer = self._buffer.add

    def __iter__(self) -> "_BlockShapingIterator":
        return self

    def __next__(self) -> Block:
        while True:
            # First, yield any ready blocks from buffer
            if self._buffer.has_next():
                return self._buffer.next()

            # If finalized, no more data
            elif self._finalized:
                raise StopIteration

            try:
                # Fetch more results
                result = next(self._results_iter)
                self._append_buffer(result)
            except StopIteration:
                self._buffer.finalize()
                self._finalized = True


class _RowBasedIterator(Iterator[Row]):
    """Iterator that extracts rows from blocks.

    Unlike a generator, local variables in __next__ go out of scope when the method
    returns, avoiding holding references to yielded values.
    """

    def __init__(self, blocks: Iterable[Block]):
        self._blocks_iter = iter(blocks)
        self._cur_row_iter: Optional[Iterator[Row]] = None

    def __iter__(self) -> "_RowBasedIterator":
        return self

    def __next__(self) -> Row:
        while True:
            # Try to get next row from current block
            if self._cur_row_iter is not None:
                try:
                    return next(self._cur_row_iter)
                except StopIteration:
                    pass

            # Get iterator from the next block
            block = next(self._blocks_iter)

            self._cur_row_iter = BlockAccessor.for_block(block).iter_rows(
                public_row_format=True
            )
