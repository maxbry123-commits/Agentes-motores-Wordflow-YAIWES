"""The stage that runs serve deployment."""

import asyncio
import logging
import time
import uuid
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple, Type

from pydantic import BaseModel, ValidationError

from ray import serve
from ray.exceptions import RayTaskError
from ray.llm._internal.batch.stages.base import (
    StatefulStage,
    StatefulStageUDF,
)
from ray.llm._internal.batch.stages.common import truncate_str

logger = logging.getLogger(__name__)

_MAX_PROMPT_LENGTH_IN_ERROR = 200

# Request-level errors safe to catch. Unknown errors are treated as fatal.
# TimeoutError is included so a single stuck request (see request_timeout_s)
# is dropped as an error row rather than blocking the batch forever.
_SERVE_RECOVERABLE_ERRORS = (
    ValueError,
    TypeError,
    ValidationError,
    TimeoutError,
)


class ServeDeploymentStageUDF(StatefulStageUDF):
    def __init__(
        self,
        data_column: str,
        expected_input_keys: List[str],
        *,
        deployment_name: str,
        app_name: str,
        dtype_mapping: Dict[str, Type[Any]],
        should_continue_on_error: bool = False,
        request_timeout_s: Optional[float] = None,
    ):
        """
        Initialize the ServeDeploymentStageUDF.

        Args:
            data_column: The data column name.
            expected_input_keys: The expected input keys of the stage.
            deployment_name: The name of the deployment.
            app_name: The name of the deployment app.
            dtype_mapping: The mapping of the request class name to the request class.
            should_continue_on_error: If True, continue processing when inference
                fails for a row instead of raising. Failed rows will have
                '__inference_error__' set to the error message.
            request_timeout_s: Optional per-request timeout in seconds. When set,
                a request that does not return within this many seconds raises
                TimeoutError instead of awaiting indefinitely. TimeoutError is
                recoverable, so with should_continue_on_error=True the row is
                emitted as an error row rather than crashing the batch.
        """
        super().__init__(data_column, expected_input_keys)
        self._dtype_mapping = dtype_mapping
        self.should_continue_on_error = should_continue_on_error
        self.request_timeout_s = request_timeout_s

        # Using stream=True as LLM serve deployments return async generators.
        # TODO (Kourosh): Generalize this to support non-streaming deployments.
        self._dh = serve.get_deployment_handle(deployment_name, app_name).options(
            stream=True
        )
        self.request_id = 0

    def _prepare_request(
        self, row: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Optional[Type[Any]], str]:
        """
        Decorate the request with metadata related to the batch.

        Args:
            row: The row.

        Returns:
            A tuple of (decorated_request, dtype, method_name). dtype is the class of
            the request object and can be None if the serve deployment accepts a raw
            dict. method_name is the name of the method to invoke on the deployment.
        """
        method = row.get("method")
        dtype_name = row.get("dtype")

        dtype = None
        if dtype_name is not None:
            if not self._dtype_mapping or dtype_name not in self._dtype_mapping:
                raise ValueError(
                    f"{dtype_name} must be provided in "
                    "ServeDeploymentProcessorConfig's dtype_mapping."
                )
            dtype = self._dtype_mapping[dtype_name]

        request_kwargs = row.pop("request_kwargs")
        request = {
            "request_id": str(self.request_id),
            "idx_in_batch": row[self.IDX_IN_BATCH_COLUMN],
            **request_kwargs,
        }
        self.request_id += 1

        return request, dtype, method

    async def generate_async(
        self, row: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Dict[str, Any], float]:
        """
        Run the serve deployment.

        Args:
            row: The row to run the serve deployment on.

        Returns:
            The response from the serve deployment.
        """
        request, dtype, method = self._prepare_request(row)
        request_obj = dtype(**request) if dtype else request

        if getattr(self._dh, method) is None:
            raise ValueError(f"Method {method} not found in the serve deployment.")

        t = time.perf_counter()
        # Directly using anext() requires python3.10 and above
        response_gen = getattr(self._dh, method).remote(request_obj)
        if self.request_timeout_s is not None:
            try:
                output_data = await asyncio.wait_for(
                    response_gen.__anext__(), timeout=self.request_timeout_s
                )
            except asyncio.TimeoutError as e:
                raise TimeoutError(
                    f"Request timed out after {self.request_timeout_s}s waiting "
                    f"for deployment '{method}' to return a response."
                ) from e
        else:
            output_data = await response_gen.__anext__()
        time_taken = time.perf_counter() - t

        # Convert the output data to a dict if it is a Pydantic model.
        if isinstance(output_data, BaseModel):
            output_data = output_data.model_dump()

        return request, output_data, time_taken

    def _is_recoverable_error(self, exc: Exception) -> bool:
        """Check if exception is recoverable. Unknown errors are treated as fatal."""
        if isinstance(exc, _SERVE_RECOVERABLE_ERRORS):
            return True
        # RayTaskError wraps remote exceptions - check the cause
        if isinstance(exc, RayTaskError) and hasattr(exc, "cause"):
            if isinstance(exc.cause, _SERVE_RECOVERABLE_ERRORS):
                return True
        return False

    async def _generate_with_error_handling(
        self,
        row: Dict[str, Any],
        batch_uuid: uuid.UUID,
    ) -> Dict[str, Any]:
        """Generate output for a row, yielding error row on recoverable failure."""
        idx_in_batch = row[self.IDX_IN_BATCH_COLUMN]
        # Save before generate_async pops it
        original_request_kwargs = row.get("request_kwargs", {})
        try:
            request, output, time_taken = await self.generate_async(row)

            return {
                **output,
                "request_id": request["request_id"],
                self.IDX_IN_BATCH_COLUMN: request["idx_in_batch"],
                "batch_uuid": batch_uuid.hex,
                "time_taken": time_taken,
                "__inference_error__": "",
            }
        except Exception as e:
            # Only recover from known recoverable errors; unknown errors propagate
            if not self._is_recoverable_error(e) or not self.should_continue_on_error:
                raise

            error_msg = f"{type(e).__name__}: {str(e)}"
            logger.warning(
                "[Serve Deployment] Inference failed for row %d in batch %s: %s",
                idx_in_batch,
                batch_uuid.hex,
                error_msg,
            )

            # Include request_kwargs snippet for debuggability
            request_str = truncate_str(
                str(original_request_kwargs), _MAX_PROMPT_LENGTH_IN_ERROR
            )

            return {
                self.IDX_IN_BATCH_COLUMN: idx_in_batch,
                "batch_uuid": batch_uuid.hex,
                "__inference_error__": error_msg,
                "request_kwargs": request_str,
            }

    async def udf(self, batch: List[Dict[str, Any]]) -> AsyncIterator[Dict[str, Any]]:
        """
        Run the serve deployment.

        Args:
            batch: A list of rows to run the serve deployment on.

        Yields:
            Dict[str, Any]: A dictionary containing the response from the serve
            deployment along with processing metadata.
        """
        batch_uuid = uuid.uuid4()
        t = time.perf_counter()

        tasks = [
            asyncio.create_task(self._generate_with_error_handling(row, batch_uuid))
            for row in batch
        ]

        for resp in asyncio.as_completed(tasks):
            yield await resp

        batch_time_taken = time.perf_counter() - t
        logger.info(
            "[LLM Batch - Serve Deployment] Elapsed time for batch %s with size %d: %s",
            batch_uuid.hex,
            len(batch),
            batch_time_taken,
        )


class ServeDeploymentStage(StatefulStage):
    fn: Type[StatefulStageUDF] = ServeDeploymentStageUDF

    def get_required_input_keys(self) -> Dict[str, str]:
        return {
            "method": "Name of the method to invoke on the serve deployment.",
            "request_kwargs": "The request_kwargs to construct the request.",
        }
