"""Contains classes that encapsulate streaming executor state.

This is split out from streaming_executor.py to facilitate better unit testing.
"""

import dataclasses
import logging
import threading
import time
from collections import defaultdict
from dataclasses import dataclass
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

import ray
from ray.data._internal.actor_autoscaler.autoscaling_actor_pool import ActorPoolInfo
from ray.data._internal.execution.backpressure_policy import BackpressurePolicy
from ray.data._internal.execution.block_ref_counter import BlockRefCounter
from ray.data._internal.execution.bundle_queue import (
    ThreadSafeBundleQueue,
    create_bundle_queue,
)
from ray.data._internal.execution.interfaces import (
    ExecutionOptions,
    PhysicalOperator,
    RefBundle,
)
from ray.data._internal.execution.interfaces.physical_operator import (
    DataOpTask,
    MetadataOpTask,
    OpTask,
    Waitable,
)
from ray.data._internal.execution.operators.base_physical_operator import (
    InternalQueueOperatorMixin,
)
from ray.data._internal.execution.operators.input_data_buffer import InputDataBuffer
from ray.data._internal.execution.ranker import Ranker
from ray.data._internal.execution.resource_manager import (
    ResourceManager,
    terminal_operator_from_topology,
)
from ray.data._internal.execution.util import memory_string
from ray.data._internal.util import (
    unify_schemas_with_validation,
)
from ray.exceptions import UserCodeException

if TYPE_CHECKING:
    from ray.data._internal.execution.metadata_fetcher import MetadataFetcher
    from ray.data.block import Schema

logger = logging.getLogger(__name__)


# Holds the full execution state of the streaming topology. It's a dict mapping each
# operator to tracked streaming exec state.
Topology = Dict[PhysicalOperator, "OpState"]

# Maximum time `process_completed_tasks` will block in `ray.wait()` waiting for tasks to complete.
WAIT_FOR_TASK_COMPLETION_TIMEOUT_S = 0.1


class IdleDetector:
    """Utility class for detecting idle operators.

    Note, stalling can happen when there are less resources than Data executor
    expects. E.g., when some resources are preempted by non-Data code, see
    `test_no_deadlock_on_resource_contention` as an example.

    This class is used to detect potential stalling and allow the execution
    to make progress.
    """

    # The interval to detect idle operators.
    # When downstream is idle, we'll allow reading at least one task output
    # per this interval,
    DETECTION_INTERVAL_S = 10.0
    # Print a warning if an operator is idle for this time.
    WARN_ON_IDLE_TIME_S = 60.0
    # Whether a warning has been printed.
    _warn_printed = False

    def __init__(self):
        # per-op fields
        self.last_num_outputs = defaultdict(int)
        self.last_output_time = defaultdict(lambda: time.time())
        self.last_detection_time = defaultdict(lambda: time.time())

    def detect_idle(self, op: PhysicalOperator):
        cur_time = time.time()
        if cur_time - self.last_detection_time[op] > self.DETECTION_INTERVAL_S:
            cur_num_outputs = op.metrics.num_task_outputs_generated
            if cur_num_outputs > self.last_num_outputs[op]:
                self.last_num_outputs[op] = cur_num_outputs
                self.last_output_time[op] = cur_time
                self.last_detection_time[op] = cur_time
            else:
                self.print_warning_if_idle_for_too_long(
                    op, cur_time - self.last_output_time[op]
                )
                return True

        return False

    @classmethod
    def print_warning_if_idle_for_too_long(cls, op: PhysicalOperator, idle_time: float):
        """Print a warning if an operator is idle for too long."""
        if idle_time < cls.WARN_ON_IDLE_TIME_S or cls._warn_printed:
            return
        cls._warn_printed = True
        msg = (
            f"Operator {op} is running but has no outputs for {idle_time} seconds."
            " Execution may be slower than expected.\n"
            "Ignore this warning if your UDF is expected to be slow."
            " Otherwise, this can happen when there are fewer cluster resources"
            " available to Ray Data than expected."
            " If you have non-Data tasks or actors running in the cluster, exclude"
            " their resources from Ray Data with"
            " `DataContext.get_current().execution_options.exclude_resources`."
            " This message will only print once."
        )

        logger.warning(msg)


class OutputBackpressureGuard:
    """Escape hatch for streaming output backpressure.

    When backpressure policies collectively allow 0 bytes of task output to be
    read for an operator, the pipeline can deadlock if downstream is also
    starved (no active tasks, no queued inputs). This guard inspects the
    topology and resource state and decides whether to unblock the backpressure.

    The guard owns per-operator idle-detection state across the lifetime of
    a single executor, so it must be constructed once and reused across
    scheduling-loop iterations.
    """

    def __init__(self, topology: Topology, resource_manager: ResourceManager):
        self._topology = topology
        self._resource_manager = resource_manager
        self._idle_detector = IdleDetector()

    def should_unblock(self, op: PhysicalOperator) -> bool:
        """Return True if output backpressure should be relaxed for ``op``
        to preserve pipeline liveness."""
        downstream_eligible_ops = list(
            self._resource_manager.get_downstream_eligible_ops(op)
        )

        # If this operator is a terminal one (no downstream eligible ops):
        # - No external consumer (e.g., write pipelines where we control draining):
        #   always unblock to maintain liveness.
        # - External consumer (iter_batches, streaming_split): only unblock if
        #   consumers are starving (blocked waiting in get_output_blocking). This
        #   prevents blocks from piling up when consumers are slow, while still
        #   maintaining liveness when the budget is too small for even one block.
        if not downstream_eligible_ops:
            if not self._resource_manager.has_external_consumer:
                return True
            # Check the DAG root rather than the last eligible op because
            # consumers block in get_output_blocking on the root's OpState,
            # which may differ (e.g., OutputSplitter or LimitOperator).
            output_op = terminal_operator_from_topology(self._topology)
            output_op_state = self._topology[output_op]
            return output_op_state.num_waiting_consumers > 0

        for downstream_op in downstream_eligible_ops:
            # To maintain liveness of the pipeline, we relax output backpressure
            # in one of the following cases.
            if downstream_op.num_active_tasks() == 0:
                downstream_op_state = self._topology[downstream_op]

                # Case 1: Downstream operator
                #   - Does *not* have running tasks and
                #   - Is not able to schedule (resource constrained)
                #
                # In this case by relaxing output backpressure we allow upstream
                # operator's task to complete sooner to free up resources.
                if not self._can_submit_new_task(downstream_op):
                    return True

                # Case 2: Downstream operator
                #   - Does *not* have running tasks and
                #   - *Can* schedule new tasks
                #   - Does *not* have any input blocks in the queue
                #
                # In this case we relax output backpressure to produce at least
                # 1 block for downstream operator.
                elif downstream_op_state.total_enqueued_input_blocks() == 0:
                    return True

        # As a last resort we check whether operator has been idling (ie not
        # producing any outputs) for a while, and unblock in that case.
        return self._idle_detector.detect_idle(op)

    def _can_submit_new_task(self, op: PhysicalOperator) -> bool:
        """Whether ``op`` can submit a new task under current resource budgets.

        Falls back to True when no op-level resource allocator is enabled —
        in that case there is no budget-based throttling to wait on, so the
        liveness check shouldn't claim downstream is blocked on resources.
        """
        if not self._resource_manager.op_resource_allocator_enabled():
            return True
        return self._resource_manager.op_resource_allocator.can_submit_new_task(op)


class OpBufferQueue:
    """A FIFO queue to buffer RefBundles between upstream and downstream operators.
    This class is thread-safe.

    Args:
        num_splits: Number of output splits operator's output is partitioned into.
            In case of `num_splits` > 1, bundles are routed to corresponding queue
             based on their `bundle.output_split_idx`.
    """

    def __init__(self, num_splits: int):
        assert num_splits >= 1, f"n_splits must be >= 1, got {num_splits}"

        self._queues: List[ThreadSafeBundleQueue] = [
            ThreadSafeBundleQueue(create_bundle_queue()) for _ in range(num_splits)
        ]

    @property
    def memory_usage(self) -> int:
        """The total memory usage of the queue in bytes."""
        return sum(q.estimate_size_bytes() for q in self._queues)

    @property
    def num_blocks(self) -> int:
        """The total number of blocks in the queue."""
        return sum(q.num_blocks() for q in self._queues)

    def __len__(self):
        return sum(len(q) for q in self._queues)

    def has_next(self, output_split_idx: Optional[int] = None) -> bool:
        """Whether next RefBundle is available.

        Args:
            output_split_idx: If specified, only check ref bundles with the
                given output split. When None, checks the default queue (index 0).

        Returns:
            ``True`` if a ``RefBundle`` is available for the requested split.
        """
        return self._get_queue_for(output_split_idx).has_next()

    def append(self, bundle: RefBundle):
        """Append a RefBundle to the queue."""
        self._get_queue_for(bundle.output_split_idx).add(bundle)

    def pop(self, output_split_idx: Optional[int] = None) -> Optional[RefBundle]:
        """Pop a RefBundle from the queue.

        Args:
            output_split_idx: If specified, only pop a RefBundle
                with the given output split. When None, pops from the default
                queue (index 0).
        Returns:
            A RefBundle if available, otherwise None.
        """
        try:
            bundle = self._get_queue_for(output_split_idx).get_next()
            # NOTE: We're making a copy of the `RefBundle` object to seal off
            #       any potential modifcations to it from propagating backwards:
            #
            #       For ex, `OutputSplitter` modifies `RefBundle.output_split_idx`
            #       that could affect original bundles that could be materialized,
            #       therefore undermining these when these are being reused.
            return dataclasses.replace(bundle)
        except IndexError:
            return None

    def clear(self):
        for q in self._queues:
            q.clear()

    def _get_queue_for(self, output_split_idx: Optional[int]) -> ThreadSafeBundleQueue:
        assert output_split_idx is not None or len(self._queues) == 1, (
            "Setting `output_split_idx` to null is only allowed for queues "
            f"with no output splitting (got {len(self._queues)} total queues)"
        )

        target_output_split_idx = output_split_idx or 0

        assert target_output_split_idx < len(self._queues), (
            f"Output split index is out of range (got {target_output_split_idx}, "
            f"but only {list(range(len(self._queues)))} splits are available)"
        )

        # If output split idx is null, fallback to the first queue
        return self._queues[target_output_split_idx]


@dataclass
class OpSchedulingStatus:
    """The scheduling status of an operator.

    This will be updated each time when StreamingExecutor makes
    a scheduling decision, i.e., in each `select_operator_to_run`
    call.
    """

    # Whether the op was considered runnable in the last scheduling
    # decision.
    runnable: bool = False
    # Whether the resources were sufficient for the operator to run
    # in the last scheduling decision.
    under_resource_limits: bool = False


class OpState:
    """The execution state tracked for each PhysicalOperator.

    This tracks state to manage input and output buffering for StreamingExecutor and
    progress bars, which is separate from execution state internal to the operators.

    Note: we use the `deque` data structure here because it is thread-safe, enabling
    operator queues to be shared across threads.
    """

    def __init__(self, op: PhysicalOperator, inqueues: List[OpBufferQueue]):
        # Each input queue is connected to another operator's output queue.
        assert len(inqueues) == len(op.input_dependencies), (op, inqueues)
        self.input_queues: List[OpBufferQueue] = inqueues
        # The output queue is connected to another operator's input queue (same object).
        #
        # Note: this queue is also accessed concurrently from the consumer thread.
        # (in addition to the streaming executor thread). Hence, it must be a
        # thread-safe type such as `deque`.
        self.output_queue: OpBufferQueue = OpBufferQueue(
            num_splits=op.num_output_splits()
        )
        self.op = op
        self.num_completed_tasks = 0
        self.inputs_done_called = False
        # Tracks whether `input_done` is called for each input op.
        self.input_done_called = [False] * len(op.input_dependencies)
        # Used for StreamingExecutor to signal exception or end of execution
        self._finished: bool = False
        self._exception: Optional[Exception] = None
        self._scheduling_status = OpSchedulingStatus()
        self._schema: Optional["Schema"] = None
        self._warned_on_schema_divergence: bool = False
        # Tracks consumers blocked in get_output_blocking().
        # Used to detect consumer starvation. Guarded by
        # _waiting_consumers_lock since += is not atomic.
        self._num_waiting_consumers: int = 0
        self._waiting_consumers_lock = threading.Lock()

    @property
    def num_waiting_consumers(self) -> int:
        """Return the number of consumers currently blocked in get_output_blocking."""
        return self._num_waiting_consumers

    def __repr__(self):
        return f"OpState({self.op.name})"

    def has_pending_bundles(self) -> bool:
        return any(len(q) > 0 for q in self.input_queues)

    def total_enqueued_input_blocks(self) -> int:
        """Total number of blocks currently enqueued among:
        1. Input queue(s) pending dispatching (``OpState.input_queues``)
        2. Operator's internal queues (like ``MapOperator``s ref-bundler, etc)
        """
        external_queue_size = sum(q.num_blocks for q in self.input_queues)
        internal_queue_size = (
            self.op.internal_input_queue_num_blocks()
            if isinstance(self.op, InternalQueueOperatorMixin)
            else 0
        )
        return external_queue_size + internal_queue_size

    def total_enqueued_input_blocks_bytes(self) -> int:
        """Total number of bytes occupied by input bundles currently enqueued among:
        1. Input queue(s) pending dispatching (``OpState.input_queues``)
        2. Operator's internal queues (like ``MapOperator``s ref-bundler, etc)
        """
        internal_queue_size_bytes = (
            self.op.internal_input_queue_num_bytes()
            if isinstance(self.op, InternalQueueOperatorMixin)
            else 0
        )
        return self.input_queue_bytes() + internal_queue_size_bytes

    def total_enqueued_output_blocks(self) -> int:
        """Total number of blocks currently enqueued among:

        1. Output queue(s) pending dispatching (``OpState.output_queue``)
        2. Operator's internal output queues (like ``MapOperator``s reordering
        bundle-queue, when ``preserve_order=True`` etc)
        """
        external_queue_size = self.output_queue.num_blocks
        internal_queue_size = (
            self.op.internal_output_queue_num_blocks()
            if isinstance(self.op, InternalQueueOperatorMixin)
            else 0
        )

        return external_queue_size + internal_queue_size

    def total_enqueued_output_blocks_bytes(self) -> int:
        """Total number of bytes occupied by output bundles currently enqueued
        among:

        1. Output queue(s) pending dispatching (``OpState.output_queue``)
        2. Operator's internal output queues (like ``MapOperator``s reordering
        bundle-queue, when ``preserve_order=True`` etc)
        """
        internal_queue_size_bytes = (
            self.op.internal_output_queue_num_bytes()
            if isinstance(self.op, InternalQueueOperatorMixin)
            else 0
        )

        return self.output_queue_bytes() + internal_queue_size_bytes

    def add_output(self, ref: RefBundle) -> None:
        """Move a bundle produced by the operator to its outqueue."""

        if ref.schema is not None:
            out_ref, diverged = dedupe_schemas_with_validation(
                self._schema,
                ref,
                enforce_schemas=self.op.data_context.enforce_schemas,
            )

            if (
                diverged
                and not self._warned_on_schema_divergence
                and self.op.data_context.enforce_schemas
            ):
                warning_message = _build_schemas_mismatch_warning(
                    self._schema, ref.schema
                )
                logger.warning(warning_message)

            ref = out_ref
            self._schema = ref.schema
            self._warned_on_schema_divergence |= diverged

        self.output_queue.append(ref)
        self.num_completed_tasks += 1

        actor_info = self.op.get_actor_info()

        self.op.metrics.num_alive_actors = actor_info.running
        self.op.metrics.num_restarting_actors = actor_info.restarting
        self.op.metrics.num_pending_actors = actor_info.pending
        # Update actor pool utilization metrics for monitoring scaling behavior
        self.op.metrics.num_active_actors = actor_info.active
        self.op.metrics.num_idle_actors = actor_info.idle
        self.op.metrics.pool_utilization = actor_info.pool_utilization
        self.op.metrics.num_tasks_in_flight = actor_info.tasks_in_flight
        for next_op in self.op.output_dependencies:
            next_op.metrics.num_external_inqueue_blocks += len(ref.blocks)
            next_op.metrics.num_external_inqueue_bytes += ref.size_bytes()
        self.op.metrics.num_external_outqueue_blocks += len(ref.blocks)
        self.op.metrics.num_external_outqueue_bytes += ref.size_bytes()

    def dispatch_next_task(self) -> None:
        """Move a bundle from the operator inqueue to the operator itself."""
        for i, inqueue in enumerate(self.input_queues):
            ref = inqueue.pop()
            if ref is not None:
                self.op.add_input(ref, input_index=i)
                self.op.metrics.num_external_inqueue_bytes -= ref.size_bytes()
                self.op.metrics.num_external_inqueue_blocks -= len(ref.blocks)
                input_op = self.op.input_dependencies[i]
                # TODO: This needs to be cleaned up.
                # the input_op's output queue = curr_op's input queue
                input_op.metrics.num_external_outqueue_blocks -= len(ref.blocks)
                input_op.metrics.num_external_outqueue_bytes -= ref.size_bytes()
                return

        assert False, "Nothing to dispatch"

    def get_output_blocking(self, output_split_idx: Optional[int]) -> RefBundle:
        """Get an item from this node's output queue, blocking as needed.

        This method must be thread-safe.

        Args:
            output_split_idx: Optional output split index for streaming-split
                consumers; ``None`` reads from the default output queue.

        Returns:
            The RefBundle from the output queue, or an error / end of stream indicator.

        Raises:
            StopIteration: If all outputs are already consumed.
            Exception: If there was an exception raised during execution.
        """
        starving = False
        try:
            while True:
                # Check if StreamingExecutor has caught an exception or is done
                # execution.
                if self._exception is not None:
                    raise self._exception
                elif self._finished and not self.output_queue.has_next(
                    output_split_idx
                ):
                    raise StopIteration()
                ref = self.output_queue.pop(output_split_idx)
                if ref is not None:
                    # Update outqueue metrics when blocks are removed from
                    # this operator's outqueue.
                    # TODO: Abstract queue-releated metrics to queue.
                    self.op.metrics.num_external_outqueue_blocks -= len(ref.blocks)
                    self.op.metrics.num_external_outqueue_bytes -= ref.size_bytes()
                    return ref
                if not starving:
                    # Queue is empty — mark this consumer as starving.
                    with self._waiting_consumers_lock:
                        self._num_waiting_consumers += 1
                    starving = True
                time.sleep(0.01)
        finally:
            if starving:
                with self._waiting_consumers_lock:
                    self._num_waiting_consumers -= 1

    def input_queue_bytes(self) -> int:
        """Return the object store memory of this operator's inqueue."""
        total = 0
        for op, inq in zip(self.op.input_dependencies, self.input_queues):
            # Exclude existing input data items from dynamic memory usage.
            if not isinstance(op, InputDataBuffer):
                total += inq.memory_usage
        return total

    def output_queue_bytes(self) -> int:
        """Return the object store memory of this operator's outqueue."""
        return self.output_queue.memory_usage

    def mark_finished(self, exception: Optional[Exception] = None):
        """Marks this operator as finished. Used for exiting get_output_blocking."""
        if exception is None:
            self._finished = True
        else:
            self._exception = exception


def build_streaming_topology(
    dag: PhysicalOperator,
    options: ExecutionOptions,
    block_ref_counter: BlockRefCounter,
) -> Topology:
    """Instantiate the streaming operator state topology for the given DAG.

    This involves creating the operator state for each operator in the DAG,
    registering it with this class, and wiring up the inqueues/outqueues of
    dependent operator states.

    Args:
        dag: The operator DAG to instantiate.
        options: The execution options to use to start operators.
        block_ref_counter: The executor-wide shared counter for tracking
            object-store memory.

    Returns:
        The topology dict holding the streaming execution state.
    """

    topology: Topology = {}

    # DFS walk to wire up operator states.
    def setup_state(op: PhysicalOperator) -> OpState:
        if op in topology:
            raise ValueError("An operator can only be present in a topology once.")

        # Wire up the input outqueues to this op's inqueues.
        inqueues = []
        for parent in op.input_dependencies:
            parent_state = setup_state(parent)
            inqueues.append(parent_state.output_queue)

        # Create state.
        op_state = OpState(op, inqueues)
        topology[op] = op_state
        op.start(options, block_ref_counter)
        return op_state

    setup_state(dag)
    return topology


def process_completed_tasks(
    topology: Topology,
    backpressure_policies: List[BackpressurePolicy],
    max_errored_blocks: int,
    output_backpressure_guard: OutputBackpressureGuard,
    metadata_fetcher: "MetadataFetcher",
) -> int:
    """Process any newly completed tasks. To update operator
    states, call `update_operator_states()` afterwards.

    Args:
        topology: The topology of operators.
        backpressure_policies: The backpressure policies to use.
        max_errored_blocks: Max number of errored blocks to allow,
            unlimited if negative.
        output_backpressure_guard: Escape hatch for streaming output
            backpressure. Bumps a fully-throttled output limit (0 bytes) to
            1 byte when the guard signals a stall.
        metadata_fetcher: Resolves pulled (block_ref, meta_ref) pairs into
            emitted RefBundles. The threaded fetcher defers metadata fetches to
            a background thread (emitting in per-op order as they become ready);
            the inline fetcher emits synchronously.
    Returns:
        The number of errored blocks.
    """
    # All active tasks, keyed by their waitables.
    active_tasks: Dict[Waitable, Tuple[OpState, OpTask]] = {}
    for op, state in topology.items():
        for task in op.get_active_tasks():
            active_tasks[task.get_waitable()] = (state, task)

    remaining_output_budget: Dict[OpState, int] = {}
    for op, state in topology.items():
        # Check all backpressure policies for max_task_output_bytes_to_read
        # Use the minimum limit from all policies (most restrictive)
        max_bytes_to_read = None
        # Track the first policy that limits output (returning 0 bytes)
        limiting_policy = None
        for policy in backpressure_policies:
            policy_limit = policy.max_task_output_bytes_to_read(op)
            if policy_limit is not None:
                if policy_limit == 0 and limiting_policy is None:
                    limiting_policy = policy.name
                if max_bytes_to_read is None:
                    max_bytes_to_read = policy_limit
                else:
                    max_bytes_to_read = min(max_bytes_to_read, policy_limit)

        assert (
            max_bytes_to_read is None or max_bytes_to_read >= 0
        ), f"Max bytes to read must either be null or >= 0 (got {max_bytes_to_read})"

        # Apply the escape hatch after aggregating across all policies so it
        # fires regardless of which policy drove the limit to 0.
        if max_bytes_to_read == 0 and output_backpressure_guard.should_unblock(op):
            max_bytes_to_read = 1

        # When the guard bumped the limit above 0, clear the policy attribution too
        in_backpressure = max_bytes_to_read == 0
        op.notify_in_task_output_backpressure(
            in_backpressure, limiting_policy if in_backpressure else None
        )

        if max_bytes_to_read is not None:
            remaining_output_budget[state] = max_bytes_to_read

    # Process completed Ray tasks and notify operators.
    num_errored_blocks = 0

    def _record_errored_block(e: BaseException, op_name: str) -> None:
        """Apply ``max_errored_blocks`` accounting to a block-level error from
        either ``on_data_ready`` or a deferred metadata fetch. Raises to abort
        once the budget is exhausted."""
        nonlocal num_errored_blocks
        num_errored_blocks += 1
        should_ignore = (
            max_errored_blocks < 0 or max_errored_blocks >= num_errored_blocks
        )
        error_message = f'An exception was raised from a task of operator "{op_name}".'
        if should_ignore:
            remaining = (
                max_errored_blocks - num_errored_blocks
                if max_errored_blocks >= 0
                else "unlimited"
            )
            error_message += (
                f" Ignoring this exception with remaining"
                f" max_errored_blocks={remaining}."
            )
            logger.error(error_message, exc_info=e)
        else:
            error_message += (
                " Dataset execution will now abort."
                " To ignore this exception and continue, set"
                " DataContext.max_errored_blocks."
            )
            # For a user-code error the traceback is re-logged (cleaned) when the
            # exception propagates to the top-level handler, so don't dump it here
            # too. Genuine internal / system errors keep the full traceback in
            # place for diagnostics.
            if isinstance(e, UserCodeException):
                logger.error(error_message)
            else:
                logger.error(error_message, exc_info=e)
            raise e from None

    if active_tasks:
        ready, _ = ray.wait(
            list(active_tasks.keys()),
            num_returns=len(active_tasks),
            fetch_local=False,
            timeout=WAIT_FOR_TASK_COMPLETION_TIMEOUT_S,
        )

        # Organize tasks by the operator they belong to, and sort them by task index.
        # So that we'll process them in a deterministic order.
        # This is because backpressure policies may limit the number of blocks to read
        # per operator. In this case, we want to have fewer tasks finish quickly and
        # yield resources, instead of having all tasks output blocks together.
        ready_tasks_by_op = defaultdict(list)
        for ref in ready:
            state, task = active_tasks[ref]
            ready_tasks_by_op[state].append(task)

        # Per-op task processing. ``metadata_fetcher`` decides how each pulled
        # (block_ref, meta_ref) pair becomes an emitted RefBundle:
        # - inline mode: ``on_data_ready`` fetches + emits each pair inline and
        #   fires the task's done-callback at end-of-stream (``submit`` is a
        #   no-op).
        # - threaded mode: every pulled pair is deferred (budget arithmetic uses
        #   the block's local ``object_size``, no per-ref ``ray.get``) and handed
        #   to the background fetcher by ``submit``; emission and the postponed
        #   done-callback happen in ``emit_ready_and_fire_done_callbacks``, preserving the per-op,
        #   per-task, per-pair emission order.
        for state, ready_tasks in ready_tasks_by_op.items():
            # TODO elaborate why sorting (helps preserve_order case)
            ready_tasks = sorted(ready_tasks, key=lambda t: t.task_index())
            op_data_tasks: List[DataOpTask] = []
            try:
                for task in ready_tasks:
                    if isinstance(task, DataOpTask):
                        try:
                            bytes_read = task.on_data_ready(
                                remaining_output_budget.get(state, None),
                                metadata_fetcher,
                            )
                            op_data_tasks.append(task)
                            if state in remaining_output_budget:
                                # Clamp remaining output budget at 0
                                remaining_output_budget[state] = max(
                                    remaining_output_budget[state] - bytes_read, 0
                                )
                        except Exception as e:
                            _record_errored_block(e, state.op.name)
                    else:
                        assert isinstance(task, MetadataOpTask)
                        task.on_task_finished()
            finally:
                # Hand this op's just-deferred pairs to the fetcher, and register
                # any end-of-stream tasks for a postponed done-callback (a no-op
                # in inline mode, where the pairs already emitted above). In a
                # ``finally`` so a thrown error can't strand pairs already
                # deferred into the fetcher this iteration.
                metadata_fetcher.submit(state, op_data_tasks)

    # Emit whatever's ready, in per-op order, then fire any postponed done
    # callbacks — UNCONDITIONALLY, even when there are no active tasks this
    # iteration. Pairs deferred in earlier iterations (their tasks may already
    # be gone) can still have metadata land later; gating this on `active_tasks`
    # would strand them and stall output forever. Deferred metadata-fetch
    # failures go through the same `max_errored_blocks` accounting as inline
    # `on_data_ready` errors. (Inline mode returns nothing here.)
    for (
        failed_op_name,
        fetch_exc,
    ) in metadata_fetcher.emit_ready_and_fire_done_callbacks():
        _record_errored_block(fetch_exc, failed_op_name)

    # Pull any operator outputs into the streaming op state.
    for op, op_state in topology.items():
        while op.has_next():
            op_state.add_output(op.get_next())

    return num_errored_blocks


def update_operator_states(topology: Topology) -> None:
    """Update operator states accordingly for newly completed tasks.
    Should be called after `process_completed_tasks()`."""

    for op, op_state in topology.items():

        # Call inputs_done() on ops where no more inputs are coming.
        if op_state.inputs_done_called:
            continue
        all_inputs_done = True
        for idx, dep in enumerate(op.input_dependencies):
            if dep.has_completed() and not topology[dep].output_queue:
                if not op_state.input_done_called[idx]:
                    op.input_done(idx)
                    op_state.input_done_called[idx] = True
            else:
                all_inputs_done = False

        if all_inputs_done:
            op.all_inputs_done()
            op_state.inputs_done_called = True

    # Traverse the topology in reverse topological order.
    # For each op, if all of its downstream operators have completed,
    # call mark_execution_finished() to also complete this op.
    for op, op_state in reversed(list(topology.items())):

        dependents_completed = len(op.output_dependencies) > 0 and all(
            dep.has_completed() for dep in op.output_dependencies
        )
        # For terminal operators (no output dependencies, e.g. OutputSplitter),
        # mark execution finished once the operator has fully completed so that
        # internal queues are properly cleared via clear_internal_input_queue()
        # and clear_internal_output_queue().
        terminal_completed = len(op.output_dependencies) == 0 and op.has_completed()
        if dependents_completed or terminal_completed:
            op.mark_execution_finished()

        # Drain external input queue if current operator is execution finished.
        # This is needed when the limit is reached, and `mark_execution_finished`
        # is called manually.
        if op.has_execution_finished():
            for input_queue in op_state.input_queues:
                # Drain input queue
                input_queue.clear()


def get_eligible_operators(
    topology: Topology,
    backpressure_policies: List[BackpressurePolicy],
    *,
    ensure_liveness: bool,
) -> List[PhysicalOperator]:
    """This method returns all operators that are eligible for execution in the current state
    of the pipeline.

    Operator is considered eligible for execution iff:

        1. It's NOT completed
        2. It has at least 1 input block (in the input queue)
        3. It can accept new inputs
        4. It's not currently throttled (for task-submission)

    """

    dispatchable_ops: List[PhysicalOperator] = []
    # Filter to ops that are eligible for execution, ie ones that are
    #   - Dispatchable
    #   - Not throttled
    eligible_ops: List[PhysicalOperator] = []

    for op, state in topology.items():
        # Operator is considered being in task-submission back-pressure if any
        # back-pressure policy is violated. Track the first triggered policy.
        triggered_policy = None
        for p in backpressure_policies:
            if not p.can_add_input(op):
                triggered_policy = p.name
                break
        in_backpressure = triggered_policy is not None

        op_runnable = False

        # Check whether operator could start executing immediately:
        #   - It's not completed
        #   - It can accept at least one input
        #   - Its input queue has a valid bundle
        if (
            not op.has_completed()
            and op.can_add_input()
            and state.has_pending_bundles()
        ):
            if not in_backpressure:
                op_runnable = True
                eligible_ops.append(op)
            else:
                dispatchable_ops.append(op)

        # Update scheduling status
        state._scheduling_status = OpSchedulingStatus(
            runnable=op_runnable,
            under_resource_limits=not in_backpressure,
        )

        # Signal whether op in backpressure for stats collections
        op.notify_in_task_submission_backpressure(in_backpressure, triggered_policy)

    # To ensure liveness, allow at least 1 operator to schedule tasks regardless of
    # limits in case when topology is entirely idle (no active tasks running)
    if (
        not eligible_ops
        and ensure_liveness
        and all(op.num_active_tasks() == 0 for op in topology)
    ):
        return dispatchable_ops

    return eligible_ops


def select_operator_to_run(
    topology: Topology,
    resource_manager: ResourceManager,
    backpressure_policies: List[BackpressurePolicy],
    ensure_liveness: bool,
    ranker: "Ranker",
) -> Optional[PhysicalOperator]:
    """Select next operator to launch new tasks.

    The objective of this method is to maximize the throughput of the overall
    pipeline, subject to defined memory, parallelism and other constraints.

    To achieve that this method implements following protocol:

        1. Collects all _eligible_ to run operators (check `_get_eligible_ops`
           for more details)
        2. Applies stack-ranking algorithm to select the best operator (check
           `_create_eligible_ops_ranker` for more details)

    """
    eligible_ops = get_eligible_operators(
        topology,
        backpressure_policies,
        ensure_liveness=ensure_liveness,
    )

    if not eligible_ops:
        return None

    ranks = ranker.rank_operators(eligible_ops, topology, resource_manager)

    assert len(eligible_ops) == len(ranks), (eligible_ops, ranks)

    next_op, _ = min(zip(eligible_ops, ranks), key=lambda t: t[1])

    return next_op


def _actor_info_summary_str(info: ActorPoolInfo) -> str:
    total = info.running + info.pending + info.restarting
    base = f"Actors: {total}"

    if total == info.running:
        return base
    else:
        return f"{base} ({info})"


def _format_schema_mismatch_section(
    title: str, entries: List[str], truncate_num_mismatched_fields_to: int
) -> str:
    """Generate a titled section of the schema mismatch warning.

    Args:
        title: Section title describing the mismatched fields.
        entries: Field detail strings (name + type).
        truncate_num_mismatched_fields_to: Max entries shown before truncation.

    Returns:
        A formatted message for the warning section, or "" if entries is empty.
    """
    if not entries:
        return ""

    shown = entries[:truncate_num_mismatched_fields_to]
    remainder = len(entries) - truncate_num_mismatched_fields_to

    body = "\n".join(f"    {line}" for line in shown)
    suffix = f"\n    ... and {remainder} more" if remainder > 0 else ""

    return f"{title} ({len(entries)} total):\n{body}{suffix}\n"


def _build_schemas_mismatch_warning(
    old_schema: "Schema", new_schema: Optional["Schema"], truncation_length: int = 20
) -> str:
    from ray.data.block import _is_empty_schema

    if _is_empty_schema(new_schema):
        old_fields_info = [
            f"{name}: {str(t)}" for name, t in zip(old_schema.names, old_schema.types)
        ]
        is_empty_message = _format_schema_mismatch_section(
            "Operator produced a RefBundle with an empty/unknown schema.",
            old_fields_info,
            truncate_num_mismatched_fields_to=truncation_length,
        )
        return is_empty_message + "This may lead to unexpected behavior."

    # We assume old_schema and new_schema have the same underlying type
    # and can only either be PyArrow schemas or PandasBlockSchema
    old_fields = {name: str(t) for name, t in zip(old_schema.names, old_schema.types)}
    new_fields = {name: str(t) for name, t in zip(new_schema.names, new_schema.types)}

    new_exclusive_fields = [name for name in new_fields if name not in old_fields]
    old_exclusive_fields = [name for name in old_fields if name not in new_fields]
    changed_fields = [
        name
        for name in new_fields
        if name in old_fields and new_fields[name] != old_fields[name]
    ]

    new_excl_fields_info = [
        f"{field}: {new_fields[field]}" for field in new_exclusive_fields
    ]
    old_excl_fields_info = [
        f"{field}: {old_fields[field]}" for field in old_exclusive_fields
    ]
    changed_fields_info = [
        f"{field}: {old_fields[field]} => {new_fields[field]}"
        for field in changed_fields
    ]

    new_excl_fields_message = _format_schema_mismatch_section(
        "Fields exclusive to the incoming schema",
        new_excl_fields_info,
        truncate_num_mismatched_fields_to=truncation_length,
    )
    old_excl_fields_message = _format_schema_mismatch_section(
        "Fields exclusive to the old schema",
        old_excl_fields_info,
        truncate_num_mismatched_fields_to=truncation_length,
    )
    changed_fields_message = _format_schema_mismatch_section(
        "Fields that have different types across the old and the incoming schemas",
        changed_fields_info,
        truncate_num_mismatched_fields_to=truncation_length,
    )

    disordered_message = ""
    if not new_exclusive_fields and not old_exclusive_fields and not changed_fields:
        assert old_fields == new_fields
        disordered_message = "Some fields are ordered differently across the old and the incoming schemas.\n"

    return (
        "Operator produced a RefBundle with a different schema "
        "than the previous one.\n"
        + new_excl_fields_message
        + old_excl_fields_message
        + changed_fields_message
        + disordered_message
        + "This may lead to unexpected behavior."
    )


def dedupe_schemas_with_validation(
    old_schema: Optional["Schema"],
    bundle: "RefBundle",
    enforce_schemas: bool = False,
) -> Tuple["RefBundle", bool]:
    """Unify/Dedupe two schemas

    Args:
        old_schema: The old schema to unify. This can be `None`, in which case
            the new schema will be used as the old schema.
        bundle: The new `RefBundle` to unify with the old schema.
        enforce_schemas: If `True`, allow the schemas to diverge and return unified schema.
            If `False`, but keep the old schema.

    Returns:
        A ref bundle with the unified schema of the two input schemas.
    """

    # Note, often times the refbundles correspond to only one schema. We can reduce the
    # memory footprint of multiple schemas by keeping only one copy.
    diverged = False

    from ray.data.block import _is_empty_schema

    if _is_empty_schema(old_schema):
        return bundle, diverged

    # This check is fast assuming pyarrow schemas
    if old_schema == bundle.schema:
        return bundle, diverged

    diverged = True
    if enforce_schemas:
        old_schema = unify_schemas_with_validation([old_schema, bundle.schema])

    return (
        RefBundle(
            bundle.blocks,
            schema=old_schema,
            owns_blocks=bundle.owns_blocks,
            output_split_idx=bundle.output_split_idx,
            _cached_object_meta=bundle._cached_object_meta,
            _cached_preferred_locations=bundle._cached_preferred_locations,
        ),
        diverged,
    )


def format_op_state_summary(
    op_state: OpState, resource_manager: ResourceManager, verbose: bool = False
) -> str:
    """Get a formatted summary of the OpState for progress reporting."""
    # Active tasks
    active = op_state.op.num_active_tasks()
    desc = f"Tasks: {active}"
    if (
        op_state.op._in_task_submission_backpressure
        or op_state.op._in_task_output_backpressure
    ):
        backpressure_types = []
        if op_state.op._in_task_submission_backpressure:
            # The op is backpressured from submitting new tasks.
            policy = op_state.op._task_submission_backpressure_policy or ""
            backpressure_types.append(f"tasks({policy})")
        if op_state.op._in_task_output_backpressure:
            # The op is backpressured from producing new outputs.
            policy = op_state.op._task_output_backpressure_policy or ""
            backpressure_types.append(f"outputs({policy})")
        desc += f" [backpressured:{','.join(backpressure_types)}]"

    # Actors info
    desc += f"; {_actor_info_summary_str(op_state.op.get_actor_info())}"

    # Queued blocks
    desc += f"; Queued blocks: {op_state.total_enqueued_input_blocks()} ({memory_string(op_state.total_enqueued_input_blocks_bytes())})"
    desc += f"; Resources: {resource_manager.get_op_usage_str(op_state.op, verbose=verbose)}"

    # Any additional operator specific information.
    suffix = op_state.op.progress_str()
    if suffix:
        desc += f"; {suffix}"

    return desc
