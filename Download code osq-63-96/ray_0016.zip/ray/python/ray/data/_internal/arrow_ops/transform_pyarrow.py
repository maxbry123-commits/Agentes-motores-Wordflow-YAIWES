import itertools
import logging
from collections import defaultdict
from typing import TYPE_CHECKING, Any, Dict, Iterable, List, Optional, Union

import numpy as np
import pyarrow
from packaging.version import parse as parse_version

from ray._common.utils import env_integer
from ray._private.utils import INT32_MAX
from ray.data._internal.tensor_extensions.arrow import (
    MIN_PYARROW_VERSION_CHUNKED_ARRAY_TO_NUMPY_ZERO_COPY_ONLY,
    get_arrow_extension_fixed_shape_tensor_types,
    get_arrow_extension_tensor_types,
    unify_tensor_arrays,
    unify_tensor_types,
)
from ray.data._internal.utils.arrow_utils import get_pyarrow_version

# Minimum version support {String,List,Binary}View types
MIN_PYARROW_VERSION_VIEW_TYPES = parse_version("16.0.0")
MIN_PYARROW_VERSION_RUN_END_ENCODED_TYPES = parse_version("12.0.0")
MIN_PYARROW_VERSION_TYPE_PROMOTION = parse_version("14.0.0")

PYARROW_VERSION = get_pyarrow_version()


# pyarrow.Table.slice is slow when the table has many chunks
# so we combine chunks into a single one to make slice faster
# with the cost of an extra copy.
#
# The decision to combine chunks is based on a threshold for the number
# of chunks, set by `MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS`. To make
# this more flexible, we have made this threshold configurable via the
# `RAY_DATA_MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS` environment variable.
#
# This configurability is important because the size of each chunk can vary
# greatly depending on the dataset and the operations performed previously.
# A fixed threshold might not be optimal for all scenarios, as in some cases,
# a smaller number of large chunks could behave differently from a larger
# number of smaller chunks. By making this threshold tunable, users have
# the ability to optimize for their specific case, adjusting based on their
# chunk sizes and available memory.
# See https://github.com/ray-project/ray/issues/31108 for more details.
# TODO(jjyao): remove this once https://github.com/apache/arrow/issues/35126 is resolved
MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS = env_integer(
    "RAY_DATA_MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS", 10
)

logger = logging.getLogger(__name__)


if TYPE_CHECKING:
    from ray.data._internal.planner.exchange.sort_task_spec import SortKey


def sort(table: "pyarrow.Table", sort_key: "SortKey") -> "pyarrow.Table":
    import pyarrow.compute as pac

    indices = pac.sort_indices(table, sort_keys=sort_key.to_arrow_sort_args())
    return take_table(table, indices)


def _create_empty_table(schema: "pyarrow.Schema"):
    import pyarrow as pa

    arrays = [pa.array([], type=t) for t in schema.types]

    return pa.table(arrays, schema=schema)


def _has_unhashable_pandas_types(schema: "pyarrow.Schema") -> bool:
    """Check if any column type becomes unhashable after to_pandas() conversion.

    Nested PyArrow types (struct/list/large_list/fixed_size_list/map/union and
    their view variants) convert to Python dicts/lists, and Ray's tensor and
    Python-object extension types convert to numpy arrays / Python objects.
    None of these are hashable by pandas' hash_pandas_object. We check the
    schema upfront so the hash algorithm choice is deterministic per schema,
    not per block data.
    """
    from ray.data._internal.object_extensions.arrow import ArrowPythonObjectType

    tensor_types = get_arrow_extension_tensor_types()
    for field in schema:
        # `is_nested` covers struct/list/large_list/map/union and (on pyarrow
        # 16+) list_view/large_list_view. It does NOT include fixed_size_list
        # on older pyarrow (<10-ish), so check that explicitly.
        if pyarrow.types.is_nested(field.type) or pyarrow.types.is_fixed_size_list(
            field.type
        ):
            return True
        if isinstance(field.type, tensor_types):
            return True
        if isinstance(field.type, ArrowPythonObjectType):
            return True
    return False


def _hash_partition(
    table: "pyarrow.Table",
    num_partitions: int,
) -> np.ndarray:
    if _has_unhashable_pandas_types(table.schema):
        # Struct/list/map columns become dicts/lists in pandas, which are
        # unhashable. Use row-by-row hashing on PyArrow scalars instead.
        partitions = np.zeros((table.num_rows,), dtype=np.int64)

        # Hoist per-column lookups out of the row loop. Iterating columns in
        # lockstep with zip uses ChunkedArray.__iter__ (a C-level loop) instead
        # of per-row __getitem__ calls, which avoids Python-side method dispatch
        # on every element.
        for i, _tuple in enumerate(zip(*table.columns)):
            partitions[i] = hash(_tuple) % num_partitions
    else:
        # Use pandas' vectorized hash (xxhash-based) instead of a Python
        # row-by-row loop.
        import pandas as pd

        # Use types_mapper=pd.ArrowDtype to keep Arrow-backed extension arrays
        # in pandas. This avoids int64 -> float64 promotion for nullable integer
        # columns, which would cause the same value to hash differently across
        # blocks depending on whether the block contains nulls.
        hashes = pd.util.hash_pandas_object(
            table.to_pandas(types_mapper=pd.ArrowDtype), index=False
        ).values
        # pandas 3.0+ returns a read-only hash array for Arrow-backed columns;
        # avoid in-place np.mod(..., out=hashes). See #64552.
        partitions = np.mod(hashes, num_partitions)

    return partitions


def hash_partition(
    table: "pyarrow.Table",
    *,
    hash_cols: List[str],
    num_partitions: int,
) -> Dict[int, "pyarrow.Table"]:
    """Hash-partitions provided Pyarrow `Table` into `num_partitions` based on
    hash of the composed tuple of values from the provided columns list

    NOTE: Since some partitions could be empty (due to skew in the table) this returns a
          dictionary, rather than a list
    """

    import numpy as np
    import pyarrow.compute as pac

    assert num_partitions > 0

    if table.num_rows == 0:
        return {}
    elif num_partitions == 1:
        return {0: table}

    projected_table = table.select(hash_cols)
    partitions_array = _hash_partition(projected_table, num_partitions=num_partitions)
    # bincount needs signed int; pandas hash path returns uint64.
    partitions_array = np.asarray(partitions_array, dtype=np.int64)

    # Sort rows by partition id so each partition occupies a contiguous range
    # of the result, then carve out partitions with zero-copy slices. The N
    # output partitions together form a permutation of `table`, so one big
    # take + N slices is equivalent to N independent takes and pays the take
    # fixed cost once.
    sort_indices = pac.sort_indices(pyarrow.array(partitions_array))
    counts = np.bincount(partitions_array, minlength=num_partitions)
    offsets = np.zeros(num_partitions + 1, dtype=np.int64)
    offsets[1:] = np.cumsum(counts)

    sorted_table = take_table(table, sort_indices)
    return {
        p: sorted_table.slice(int(offsets[p]), int(counts[p]))
        # NOTE: Since some of the partitions might be empty, we're filtering out
        #       indices of the length 0 to make sure we're not passing around
        #       empty tables
        for p in range(num_partitions)
        if counts[p] > 0
    }


def take_table(
    table: "pyarrow.Table",
    indices: Union[List[int], np.ndarray, "pyarrow.Array", "pyarrow.ChunkedArray"],
) -> "pyarrow.Table":
    """Select rows from the table.

    This method is an alternative to pyarrow.Table.take(), which breaks for
    extension arrays. This is exposed as a static method for easier use on
    intermediate tables, not underlying an ArrowBlockAccessor.
    """
    from ray.data._internal.utils.transform_pyarrow import (
        _concatenate_extension_column,
        _is_pa_extension_type,
    )

    if any(_is_pa_extension_type(col.type) for col in table.columns):
        new_cols = []
        for col in table.columns:
            if _is_pa_extension_type(col.type) and col.num_chunks > 1:
                # .take() will concatenate internally, which currently breaks for
                # extension arrays.
                col = _concatenate_extension_column(col)
            new_cols.append(col.take(indices))
        table = pyarrow.Table.from_arrays(new_cols, schema=table.schema)
    else:
        table = table.take(indices)
    return table


def _reconcile_diverging_fields(
    unique_schemas: List["pyarrow.Schema"],
    promote_types: bool,
) -> Dict[str, Any]:
    """
    Identify and reconcile fields whose presence or types differ across the provided schemas.

    Args:
        unique_schemas: List of PyArrow schemas to find diverging fields in.
        promote_types: Whether to promote types.

    Returns:
        A dictionary of diverging fields with their reconciled types.
    """
    from ray.data._internal.object_extensions.arrow import ArrowPythonObjectType

    reconciled_fields = {}
    field_types = defaultdict(list)  # field_name -> list of types seen so far
    field_flags = defaultdict(
        lambda: defaultdict(bool)
    )  # field_name -> dict of boolean flags

    # Process schemas and reconcile on-the-fly
    for schema in unique_schemas:
        for field_name in schema.names:
            if field_name in reconciled_fields:
                # If the field has already been reconciled, skip it.
                continue

            field_type = schema.field(field_name).type
            if field_type not in field_types[field_name]:
                field_types[field_name].append(field_type)
            flags = field_flags[field_name]

            # Update flags
            flags["has_object"] |= isinstance(field_type, ArrowPythonObjectType)
            flags["has_tensor"] |= isinstance(
                field_type, get_arrow_extension_tensor_types()
            )
            flags["has_list"] |= pyarrow.types.is_list(field_type)
            flags["has_null"] |= pyarrow.types.is_null(field_type)
            flags["has_struct"] |= pyarrow.types.is_struct(field_type)

            # Check for object-tensor conflict
            if flags["has_object"] and flags["has_tensor"]:
                raise ValueError(
                    f"Found columns with both objects and tensors: {field_name}"
                )

            # Reconcile immediately if it's a special type and if it's divergent.
            if any(flags.values()) and len(field_types[field_name]) > 1:
                reconciled_value = _reconcile_field(
                    non_null_types=field_types[field_name],
                    promote_types=promote_types,
                )
                if reconciled_value is not None:
                    reconciled_fields[field_name] = reconciled_value

    return reconciled_fields


def _reconcile_field(
    non_null_types: List[pyarrow.DataType],
    promote_types: bool = False,
) -> Optional[pyarrow.DataType]:
    """
    Reconcile a single divergent field across schemas.

    Returns reconciled type or None if default PyArrow handling is sufficient.
    """
    from ray.data._internal.object_extensions.arrow import ArrowPythonObjectType
    from ray.data._internal.tensor_extensions.arrow import (
        get_arrow_extension_tensor_types,
    )

    if not non_null_types:
        return None

    # Handle special cases in priority order

    # 1. Tensor fields
    tensor_types = get_arrow_extension_tensor_types()
    tensor_field_types = [t for t in non_null_types if isinstance(t, tensor_types)]

    if tensor_field_types:
        return unify_tensor_types(tensor_field_types)

    # 2. Object fields
    if any(isinstance(t, ArrowPythonObjectType) for t in non_null_types):
        return ArrowPythonObjectType()

    # 3. Struct fields (recursive unification)
    struct_types = [t for t in non_null_types if pyarrow.types.is_struct(t)]
    if struct_types:
        # Convert struct types to schemas
        struct_schemas = []
        for t in non_null_types:
            if pyarrow.types.is_struct(t):
                struct_schemas.append(pyarrow.schema(list(t)))
        # Recursively unify
        unified_struct = unify_schemas(struct_schemas, promote_types=promote_types)
        return pyarrow.struct(list(unified_struct))

    # 4. Null-typed list fields (Need this pyarrow < 14.0.0)
    null_lists = [
        t
        for t in non_null_types
        if pyarrow.types.is_list(t) and pyarrow.types.is_null(t.value_type)
    ]
    if null_lists:
        # Find first non-null list type
        for t in non_null_types:
            if not (pyarrow.types.is_list(t) and pyarrow.types.is_null(t.value_type)):
                return t
    # At this phase, we have no special types to reconcile, so return None. Arrow will fail to unify.
    return None


def _unify_schemas_pyarrow(
    schemas: List["pyarrow.Schema"], promote_types: bool = False
) -> "pyarrow.Schema":
    """Wrapper for pyarrow.unify_schemas with version compatibility."""
    if get_pyarrow_version() < MIN_PYARROW_VERSION_TYPE_PROMOTION:
        return pyarrow.unify_schemas(schemas)

    promote_options = "permissive" if promote_types else "default"
    return pyarrow.unify_schemas(schemas, promote_options=promote_options)


def reorder_columns_by_schema(
    table: "pyarrow.Table", schema: "pyarrow.Schema"
) -> "pyarrow.Table":
    """Return `table` with its columns in the order of `schema.names`.

    No-op when the column orders already match. Use before a positional
    operation like `Table.cast(schema)` or
    `RecordBatchReader.from_batches(schema, ...)` so blocks that share
    the same field names in a different order — common when upstream
    UDFs build dicts whose key order varies across workers — don't trip
    the positional schema check.

    Raises `ValueError` if `table` has any columns not in `schema.names`
    (selecting on `schema.names` would silently drop them) and via
    `Table.select` if `table` is missing any column in `schema.names`.
    Callers reconciling field-set mismatches (e.g. via `unify_schemas`)
    must handle that case before calling here.
    """
    if table.schema.names == schema.names:
        return table
    target_names = set(schema.names)
    extra = [n for n in table.schema.names if n not in target_names]
    if extra:
        raise ValueError(
            f"Table has columns not in target schema: {extra}. "
            f"reorder_columns_by_schema only reorders an existing field set; "
            f"reconcile the column set before calling."
        )
    return table.select(schema.names)


def unify_schemas(
    schemas: List["pyarrow.Schema"], *, promote_types: bool = False
) -> "pyarrow.Schema":
    """
    Unify schemas handling Ray-specific types (tensors, objects, etc.).

    Falls back to PyArrow's unify_schemas when possible, with custom
    handling for tensor arrays, object types, and recursive struct unification.
    """
    if not schemas:
        raise ValueError("No schemas provided for unify_schemas")

    # Deduplicate schemas. Calling this before PyArrow's unify_schemas is more efficient (100x faster).

    # Remove metadata for hashability
    schema_to_compare = schemas[0].remove_metadata()
    schemas_to_unify = [schemas[0]]
    for schema in schemas[1:]:
        if not schema.remove_metadata().equals(schema_to_compare):
            schemas_to_unify.append(schema)

    pyarrow_exception = None
    # If there is only one schema, return it
    if len(schemas_to_unify) == 1:
        return schemas_to_unify[0]

    # Try PyArrow's unification first, only reconcile for tensor fields
    try:
        return _unify_schemas_pyarrow(schemas_to_unify, promote_types)
    except (pyarrow.lib.ArrowTypeError, pyarrow.lib.ArrowInvalid) as e:
        # If we raise only on non tensor errors, it fails to unify PythonObjectType and pyarrow primitives.
        # Look at test_pyarrow_conversion_error_handling for an example.
        pyarrow_exception = e
        pass

    # Reconcile diverging fields
    overrides = _reconcile_diverging_fields(schemas_to_unify, promote_types)

    # At this point, we're not able to reconcile the fields, so raise the original exception.
    if not overrides:
        raise pyarrow_exception

    # Apply overrides to schemas. Rebuild each schema once by scanning its
    # fields a single time, rather than calling Schema.set() per override:
    # set() copies the whole schema on every call, which is O(n^2) when
    # many/all columns diverge. This is O(fields + overrides) per schema.
    updated_schemas = []
    for schema in schemas_to_unify:
        fields = [
            field.with_type(overrides[field.name]) if field.name in overrides else field
            for field in schema
        ]
        updated_schemas.append(pyarrow.schema(fields, metadata=schema.metadata))
    schemas_to_unify = updated_schemas

    # Final unification with overrides applied
    try:
        return _unify_schemas_pyarrow(schemas_to_unify, promote_types)
    except Exception as e:
        schemas_str = "\n-----\n".join(str(s) for s in schemas_to_unify)
        logger.error(f"Failed to unify schemas: {schemas_str}", exc_info=e)
        raise


def _concatenate_chunked_arrays(arrs: "pyarrow.ChunkedArray") -> "pyarrow.ChunkedArray":
    """
    Concatenate provided chunked arrays into a single chunked array.
    """
    from ray.data.extensions import get_arrow_extension_tensor_types

    tensor_types = get_arrow_extension_tensor_types()

    # Infer the type as the first non-null type.
    type_ = None
    for arr in arrs:
        assert not isinstance(arr.type, tensor_types), (
            "'_concatenate_chunked_arrays' should only be used on non-tensor "
            f"extension types, but got a chunked array of type {type_}."
        )
        if type_ is None and not pyarrow.types.is_null(arr.type):
            type_ = arr.type
            break

    if type_ is None:
        # All arrays are null, so the inferred type is null.
        type_ = pyarrow.null()

    # Single flat list of chunks across all chunked arrays.
    chunks = []
    for arr in arrs:
        if pyarrow.types.is_null(arr.type) and not pyarrow.types.is_null(type_):
            # If the type is null, we need to cast the array to the inferred type.
            arr = arr.cast(type_)
        elif not pyarrow.types.is_null(arr.type) and type_ != arr.type:
            raise RuntimeError(f"Types mismatch: {type_} != {arr.type}")

        # Add chunks for this chunked array to flat chunk list.
        chunks.extend(arr.chunks)

    # Construct chunked array on flat list of chunks.
    return pyarrow.chunked_array(chunks, type=type_)


def _extract_unified_struct_types(
    schema: "pyarrow.Schema",
) -> Dict[str, "pyarrow.StructType"]:
    """
    Extract all struct fields from a schema and map their names to types.

    Args:
        schema: Arrow schema to extract struct types from.

    Returns:
        Dict[str, pa.StructType]: Mapping of struct field names to their types.
    """
    import pyarrow as pa

    return {
        field.name: field.type for field in schema if pa.types.is_struct(field.type)
    }


def _backfill_missing_fields(
    column: "pyarrow.ChunkedArray",
    unified_struct_type: "pyarrow.StructType",
    block_length: int,
) -> "pyarrow.StructArray":
    """
    Align a struct column's fields to match the unified schema's struct type.

    Args:
        column: The column data to align.
        unified_struct_type: The unified struct type to align to.
        block_length: The number of rows in the block.

    Returns:
        pa.StructArray: The aligned struct array.
    """
    import pyarrow as pa

    from ray.data._internal.tensor_extensions.arrow import (
        ArrowVariableShapedTensorArray,
        ArrowVariableShapedTensorType,
    )
    from ray.data._internal.utils.transform_pyarrow import (
        _is_native_tensor_type,
    )

    # Flatten chunked arrays into a single array if necessary
    if isinstance(column, pa.ChunkedArray):
        column = pa.concat_arrays(column.chunks)

    # Extract the current struct field names and their corresponding data
    current_fields = {
        field.name: column.field(i) for i, field in enumerate(column.type)
    }

    # Assert that the current fields are a subset of the unified struct type's field names
    unified_field_names = {field.name for field in unified_struct_type}
    assert set(current_fields.keys()).issubset(
        unified_field_names
    ), f"Fields {set(current_fields.keys())} are not a subset of unified struct fields {unified_field_names}."

    # Early exit if no fields are missing in the schema
    if column.type == unified_struct_type:
        return column

    aligned_fields = []

    # Iterate over the fields in the unified struct type schema
    for field in unified_struct_type:
        field_name = field.name
        field_type = field.type

        if field_name in current_fields:
            # If the field exists in the current column, align it
            current_array = current_fields[field_name]
            if pa.types.is_struct(field_type):
                # Recursively align nested struct fields
                current_array = _backfill_missing_fields(
                    column=current_array,
                    unified_struct_type=field_type,
                    block_length=block_length,
                )

            # Handle tensor extension type mismatches
            elif isinstance(field_type, ArrowVariableShapedTensorType) and isinstance(
                current_array.type, get_arrow_extension_fixed_shape_tensor_types()
            ):
                # Convert to variable-shaped if needed
                if _is_native_tensor_type(current_array.type):
                    current_array = ArrowVariableShapedTensorArray.from_numpy(
                        current_array.to_numpy_ndarray()
                    )
                else:
                    current_array = current_array.to_var_shaped_tensor_array(
                        ndim=field_type.ndim
                    )

            # Handle type mismatches for primitive types
            # The schema should already be unified by unify_schemas, but
            # struct field types may still diverge (e.g., int64 vs float64).
            # Cast the existing array to match the unified struct field type.
            elif current_array.type != field_type:
                try:
                    current_array = current_array.cast(field_type)
                except pa.ArrowInvalid as e:
                    raise ValueError(
                        f"Cannot cast struct field '{field_name}' from "
                        f"{current_array.type} to {field_type}: {e}"
                    ) from e

            aligned_fields.append(current_array)
        else:
            # If the field is missing, fill with nulls
            aligned_fields.append(pa.nulls(block_length, type=field_type))

    # Reconstruct the struct column with aligned fields
    return pa.StructArray.from_arrays(
        aligned_fields,
        fields=unified_struct_type,
    )


def _align_struct_fields(
    blocks: List["pyarrow.Table"], schema: "pyarrow.Schema"
) -> List["pyarrow.Table"]:
    """
    Align struct columns across blocks to match the provided schema.

    Struct columns in each block are backfilled with nulls for any fields
    present in the unified schema but missing in that block. Non-struct
    columns missing from a block are also appended as null columns, and
    columns are reordered to match the schema.

    Args:
        blocks: List of Arrow tables to align.
        schema: Unified schema with desired struct column alignment.

    Returns:
        List[pa.Table]: List of aligned Arrow tables.

    Example::

        >>> import pyarrow as pa
        >>> block1 = pa.table({"a": [1], "s": [{"x": 1}]})
        >>> block2 = pa.table({"a": [2], "s": [{"x": 2, "y": "hello"}]})
        >>> schema = pa.schema([
        ...     ("a", pa.int64()),
        ...     ("s", pa.struct([("x", pa.int64()), ("y", pa.string())])),
        ... ])
        >>> aligned = _align_struct_fields([block1, block2], schema)
        >>> aligned[0].to_pydict()
        {'a': [1], 's': [{'x': 1, 'y': None}]}
        >>> aligned[1].to_pydict()
        {'a': [2], 's': [{'x': 2, 'y': 'hello'}]}
    """
    import pyarrow as pa

    # Check if all block schemas are already aligned
    if all(block.schema == schema for block in blocks):
        return blocks

    # Extract all struct column types from the provided schema
    unified_struct_types = _extract_unified_struct_types(schema)

    aligned_blocks = []

    # Iterate over each block (table) in the list
    for block in blocks:
        # Fast path: if schema matches exactly, skip
        if block.schema.equals(schema):
            aligned_blocks.append(block)
            continue

        # Get the number of rows in the block
        block_length = len(block)
        block_schema_field_names = set(block.schema.names)

        # Process struct columns that need alignment
        for column_name, unified_struct_type in unified_struct_types.items():
            if column_name in block_schema_field_names:
                column = block[column_name]

                # Check if the column type matches a struct type
                if (
                    isinstance(column.type, pa.StructType)
                    and column.type != unified_struct_type
                ):
                    # Align struct fields
                    aligned_column = _backfill_missing_fields(
                        column, unified_struct_type, block_length
                    )
                    # Replace the column with the aligned version
                    block = block.set_column(
                        block.schema.get_field_index(column_name),
                        column_name,
                        aligned_column,
                    )

        # Find all missing columns (struct and non-struct)
        missing_fields = [f for f in schema if f.name not in block_schema_field_names]

        # Append missing columns with null values
        for field in missing_fields:
            # pa.nulls creates a null array of the correct length and type efficiently
            null_col = pa.nulls(block_length, type=field.type)
            block = block.append_column(field.name, null_col)

        # Reorder columns to match the target schema
        # select() is a zero-copy operation for column reordering
        block = block.select(schema.names)
        aligned_blocks.append(block)

    # Return the list of aligned blocks
    return aligned_blocks


def shuffle(block: "pyarrow.Table", seed: Optional[int] = None) -> "pyarrow.Table":
    """Shuffles provided Arrow table"""

    if len(block) == 0:
        return block

    indices = np.arange(block.num_rows)
    # Shuffle indices
    np.random.RandomState(seed).shuffle(indices)

    return take_table(block, indices)


def _concat_cols_with_null_list(
    col_chunked_arrays: List["pyarrow.ChunkedArray"],
) -> "pyarrow.ChunkedArray":
    """Concatenate chunked arrays where at least one has type ``list<null>``.

    When a column is empty in some blocks (e.g. an empty TFRecord feature),
    PyArrow infers its type as ``list<item: null>``.  Other blocks may have
    a concrete type for the same column (``binary``, ``list<float32>``, etc.).
    ``pa.concat_tables`` can promote ``list<null>`` to ``list<X>`` natively,
    but cannot merge ``list<null>`` with a non-list type like ``binary``.
    This function resolves both cases (for simplicity) by casting or replacing
    ``list<null>`` arrays to match the concrete type found in other blocks.

    Args:
        col_chunked_arrays: Chunked arrays (one per block) for a single
            column, where at least one has type ``list<item: null>``.

    Returns:
        A single concatenated ``ChunkedArray`` with a consistent type.

    Example::

        >>> import pyarrow as pa
        >>> ca1 = pa.chunked_array([pa.array([], type=pa.list_(pa.null()))])
        >>> ca2 = pa.chunked_array([pa.array([[b"hello"]], type=pa.list_(pa.binary()))])
        >>> result = _concat_cols_with_null_list([ca1, ca2])
        >>> result.type
        ListType(list<item: binary>)
    """
    import pyarrow as pa

    # For each opaque list column, iterate through all schemas until
    # we find a valid value_type that can be used to override the
    # column types in the following for-loop.
    value_type = None
    for arr in col_chunked_arrays:
        if not pa.types.is_list(arr.type) or not pa.types.is_null(arr.type.value_type):
            value_type = arr.type
            break

    if value_type is not None:
        for c_idx in range(len(col_chunked_arrays)):
            c = col_chunked_arrays[c_idx]
            if pa.types.is_list(c.type) and pa.types.is_null(c.type.value_type):
                if pa.types.is_list(value_type):
                    # If we are dealing with a list input,
                    # cast the array to the value_type found above.
                    col_chunked_arrays[c_idx] = c.cast(value_type)
                else:
                    # If we are dealing with a single value, construct
                    # a new array with null values filled.
                    col_chunked_arrays[c_idx] = pa.chunked_array(
                        [pa.nulls(c.length(), type=value_type)]
                    )

    return _concatenate_chunked_arrays(col_chunked_arrays)


def _concat_cols_with_extension_tensor_types(
    col_chunked_arrays: Iterable["pyarrow.ChunkedArray"],
) -> "pyarrow.ChunkedArray":
    """Concatenate chunked arrays that have tensor extension types.

    Flattens all chunks from the input chunked arrays and unifies them
    via ``unify_tensor_arrays``.  When every chunk already shares the same
    fixed-shape tensor type the chunks are returned as-is.  When shapes
    differ across chunks, ``unify_tensor_arrays`` promotes them to a
    single variable-shaped tensor type so the result is always a
    consistently-typed ``ChunkedArray``.

    Args:
        col_chunked_arrays: Chunked arrays (one per block) for a single
            tensor column whose element shapes may differ across blocks.

    Returns:
        A single ``ChunkedArray`` with a unified tensor type.

    Example::

        >>> import numpy as np, pyarrow as pa
        >>> from ray.data._internal.tensor_extensions.arrow import (
        ...     ArrowTensorArray,
        ... )
        >>> # Two blocks with different tensor shapes for the same column:
        >>> # 2 rows of shape-(3,) tensors and 2 rows of shape-(4,) tensors
        >>> ca1 = pa.chunked_array([ArrowTensorArray.from_numpy(np.zeros((2, 3)))])
        >>> ca2 = pa.chunked_array([ArrowTensorArray.from_numpy(np.zeros((2, 4)))])
        >>> result = _concat_cols_with_extension_tensor_types([ca1, ca2])
        >>> # Result is a single ChunkedArray promoted to variable-shaped type
        >>> # with 2 + 2 = 4 total rows
        >>> len(result)
        4
    """
    import pyarrow as pa

    # For our tensor extension types, manually construct a chunked array
    # containing chunks from all blocks. This is to handle
    # homogeneous-shaped block columns having different shapes across
    # blocks: if tensor element shapes differ across blocks, a
    # variable-shaped tensor array will be returned.
    combined_chunks = list(
        itertools.chain(*[chunked.iterchunks() for chunked in col_chunked_arrays])
    )

    return pa.chunked_array(unify_tensor_arrays(combined_chunks))


def _concat_cols_with_extension_object_types(
    col_chunked_arrays: Iterable["pyarrow.ChunkedArray"],
) -> "pyarrow.ChunkedArray":
    """Concatenate chunked arrays where the unified type is ``ArrowPythonObjectType``.

    Each chunk that is already an ``ArrowPythonObjectType`` is kept as-is.
    Chunks with a different type are converted to ``ArrowPythonObjectArray``
    via ``from_objects``, so the resulting ``ChunkedArray`` has a uniform
    object extension type.

    Args:
        col_chunked_arrays: Chunked arrays (one per block) for a single
            column whose unified type is ``ArrowPythonObjectType``.

    Returns:
        A single ``ChunkedArray`` with ``ArrowPythonObjectType``.

    Example::

        >>> import pyarrow as pa
        >>> from ray.data.extensions import ArrowPythonObjectArray
        >>> # One block already stores Python objects, another has plain ints
        >>> ca1 = pa.chunked_array([ArrowPythonObjectArray.from_objects([1, 2])])
        >>> ca2 = pa.chunked_array([[3, 4]])
        >>> result = _concat_cols_with_extension_object_types([ca1, ca2])
        >>> # Both chunks are now ArrowPythonObjectType, 2 + 2 = 4 total rows
        >>> len(result)
        4
    """
    import pyarrow as pa

    from ray.data.extensions import ArrowPythonObjectArray, ArrowPythonObjectType

    chunks_to_concat = []
    # Cast everything to objects if concatenated with an object column
    for ca in col_chunked_arrays:
        for chunk in ca.chunks:
            if isinstance(ca.type, ArrowPythonObjectType):
                chunks_to_concat.append(chunk)
            else:
                chunks_to_concat.append(
                    ArrowPythonObjectArray.from_objects(chunk.to_pylist())
                )
    return pa.chunked_array(chunks_to_concat)


def _concat_cols_via_concat_tables(
    col_names: List[str], blocks: List["pyarrow.Table"], promote_types: bool = False
) -> Dict[str, "pyarrow.ChunkedArray"]:
    """Concatenate columns by delegating to ``pa.concat_tables``.

    Selects the named columns from each block and concatenates them using
    PyArrow's built-in ``concat_tables``.  This is suitable for:

    - **Native types** (int, float, string, struct, …) — type promotion
      across blocks is controlled by *promote_types*.
    - **Extension types whose type already matches across all blocks**
      (e.g. same-shaped tensor columns, uniform ``ArrowPythonObjectType``
      columns) — ``concat_tables`` handles these as a no-op promotion
      since the types are identical.

    Columns that are missing from a block are silently skipped (the caller
    is expected to have backfilled them beforehand via
    ``_align_struct_fields`` or similar).

    Args:
        col_names: Column names to concatenate.
        blocks: Arrow tables containing the columns.
        promote_types: If True, use permissive type promotion (e.g.
            int32 -> int64). Only affects native types; uniform extension
            types are concatenated as-is regardless of this flag.

    Returns:
        Dict mapping each column name to its concatenated ``ChunkedArray``.

    Example::

        >>> import pyarrow as pa
        >>> b1 = pa.table({"x": [1, 2], "y": ["a", "b"]})
        >>> b2 = pa.table({"x": [3, 4], "y": ["c", "d"]})
        >>> result = _concat_cols_via_concat_tables(["x", "y"], [b1, b2])
        >>> result["x"].to_pylist()
        [1, 2, 3, 4]
        >>> result["y"].to_pylist()
        ['a', 'b', 'c', 'd']
    """
    if not col_names:
        return {}

    # For columns with native Pyarrow types, we should use built-in pyarrow.concat_tables.
    import pyarrow as pa

    # When concatenating tables we allow type promotions to occur, since
    # no schema enforcement is currently performed, therefore allowing schemas
    # to vary b/w blocks

    # NOTE: Type promotions aren't available in Arrow < 14.0
    subset_blocks = []
    for block in blocks:
        block_cols = set(block.schema.names)
        cols_to_select = [col_name for col_name in col_names if col_name in block_cols]
        subset_blocks.append(block.select(cols_to_select))
    if get_pyarrow_version() < parse_version("14.0.0"):
        table = pa.concat_tables(subset_blocks, promote=True)
    else:
        arrow_promote_types_mode = "permissive" if promote_types else "default"
        table = pa.concat_tables(
            subset_blocks, promote_options=arrow_promote_types_mode
        )
    return {col_name: table.column(col_name) for col_name in table.schema.names}


def concat(
    blocks: List["pyarrow.Table"],
    *,
    promote_types: bool = False,
    preserve_order: Optional[bool] = None,
) -> "pyarrow.Table":
    """Concatenate provided Arrow Tables into a single Arrow Table. This has special
    handling for extension types that pyarrow.concat_tables does not yet support.

    Args:
        blocks: Tables to concatenate.
        promote_types: Whether to allow permissive type promotion for native
            columns.
        preserve_order: If True, rows appear in the same order as the input
            blocks.  If False, schema-matching blocks may be grouped together
            for faster concatenation, which can reorder rows relative to
            non-matching blocks.  Defaults to
            ``DataContext.get_current().execution_options.preserve_order``.

    Returns:
        A single Arrow Table containing all rows from the input tables.
    """
    import pyarrow as pa

    from ray.data._internal.tensor_extensions.arrow import ArrowConversionError
    from ray.data.context import DataContext
    from ray.data.extensions import get_arrow_extension_tensor_types

    tensor_types = get_arrow_extension_tensor_types()

    if not blocks:
        # Short-circuit on empty list of blocks.
        return pa.table([])

    if len(blocks) == 1:
        return blocks[0]

    # If the result contains pyarrow schemas, unify them
    schemas_to_unify = [b.schema for b in blocks]
    try:
        schema = unify_schemas(schemas_to_unify, promote_types=promote_types)
    except Exception as e:
        raise ArrowConversionError(
            f"Failed to unify schemas: {str(e)}\n"
            f"{'-' * 16}\n"
            f"Schemas:\n"
            f"{'-' * 16}\n"
            f"{schemas_to_unify}"
        ) from e

    matched_blocks: List[pa.Table] = []
    mismatched_blocks: List[pa.Table] = []
    for block in blocks:
        if block.schema == schema:
            matched_blocks.append(block)
        else:
            mismatched_blocks.append(block)

    # Fast path: all blocks already share the unified schema.
    if len(matched_blocks) == len(blocks):
        return pa.concat_tables(blocks)

    if preserve_order is None:
        preserve_order = DataContext.get_current().execution_options.preserve_order

    if preserve_order or len(matched_blocks) <= 1:
        return _concat_mismatched_blocks(
            blocks,
            schema=schema,
            tensor_types=tensor_types,
            promote_types=promote_types,
        )

    # When order doesn't matter, split blocks into schema-matching (fast
    # path) and mismatched (slow path) groups, concat each group, then
    # combine.
    single_matched_block = pa.concat_tables(matched_blocks)

    return _concat_mismatched_blocks(
        mismatched_blocks + [single_matched_block],
        schema=schema,
        tensor_types=tensor_types,
        promote_types=promote_types,
    )


def _concat_mismatched_blocks(
    blocks: List["pyarrow.Table"],
    schema: "pyarrow.Schema",
    tensor_types: tuple,
    promote_types: bool,
) -> "pyarrow.Table":
    """Concatenate blocks whose schemas differ from the unified schema.

    Handles struct alignment, ``list<null>`` resolution, and per-column
    reconciliation for tensor / object extension types before delegating
    remaining columns to ``pa.concat_tables``.

    NOTE: Concatenates blocks in the same order as input (preserve_order).

    Args:
        blocks: Tables that do not all share the same schema.
        schema: The unified target schema.
        tensor_types: Tuple of Arrow tensor extension types.
        promote_types: Whether to allow permissive type promotion for
            native columns.

    Returns:
        A single table with columns ordered according to *schema*.
    """
    import pyarrow as pa

    from ray.data.extensions import ArrowPythonObjectType

    # Handle alignment of struct type columns.
    blocks = _align_struct_fields(blocks, schema)

    # Identify columns where any block has list<null> (e.g. empty TFRecord
    # features).  These need special handling because pa.concat_tables
    # cannot merge list<null> with a concrete type like binary.
    cols_with_null_list = set()
    for b in blocks:
        for col_name in b.schema.names:
            col_type = b.schema.field(col_name).type
            if pa.types.is_list(col_type) and pa.types.is_null(col_type.value_type):
                cols_with_null_list.add(col_name)

    # Concatenate the columns according to their type
    concatenated_cols: Dict[str, pa.ChunkedArray] = {}

    # Names of columns that can use pa.concat_tables. This includes
    #   - native types (supports type promotion across blocks)
    #   - extension types (does not support type promotion across blocks)
    concatable_cols: List[str] = []
    for col_name in schema.names:
        col_type = schema.field(col_name).type

        if col_name in cols_with_null_list:
            concatenated_cols[col_name] = _concat_cols_with_null_list(
                [block.column(col_name) for block in blocks]
            )
        elif isinstance(col_type, (*tensor_types, ArrowPythonObjectType)):
            concat_fn = (
                _concat_cols_with_extension_tensor_types
                if isinstance(col_type, tensor_types)
                else _concat_cols_with_extension_object_types
            )
            # Cache field lookups once instead of re-fetching per block in all()
            col_types = [block.schema.field(col_name).type for block in blocks]
            if all(t == col_type for t in col_types):
                concatable_cols.append(col_name)
            else:
                concatenated_cols[col_name] = concat_fn(
                    block.column(col_name) for block in blocks
                )
        else:
            # Add to the list of native pyarrow columns, these will be concatenated after the loop using pyarrow.concat_tables
            concatable_cols.append(col_name)

    concatenated_cols.update(
        _concat_cols_via_concat_tables(concatable_cols, blocks, promote_types)
    )

    # Ensure that the columns are in the same order as the schema, reconstruct the table.
    return pyarrow.Table.from_arrays(
        [concatenated_cols[col_name] for col_name in schema.names], schema=schema
    )


def concat_and_sort(
    blocks: List["pyarrow.Table"],
    sort_key: "SortKey",
    *,
    promote_types: bool = False,
) -> "pyarrow.Table":
    import pyarrow as pa
    import pyarrow.compute as pac

    if len(blocks) == 0:
        return pa.table([])

    ret = concat(blocks, promote_types=promote_types)
    indices = pac.sort_indices(ret, sort_keys=sort_key.to_arrow_sort_args())

    return take_table(ret, indices)


def table_to_numpy_dict_chunked(
    table: "pyarrow.Table",
) -> Dict[str, List[np.ndarray]]:
    """Convert a PyArrow table to a dictionary of lists of numpy arrays.

    Args:
        table: The PyArrow table to convert.

    Returns:
        A dictionary mapping column names to lists of numpy arrays. For chunked columns,
        the list will contain multiple arrays (one per chunk). For non-chunked columns,
        the list will contain a single array.
    """

    numpy_batch = {}
    for col_name in table.column_names:
        col = table[col_name]
        if isinstance(col, pyarrow.ChunkedArray):
            numpy_batch[col_name] = [
                to_numpy(chunk, zero_copy_only=False) for chunk in col.chunks
            ]
        else:
            numpy_batch[col_name] = [to_numpy(col, zero_copy_only=False)]
    return numpy_batch


def to_numpy(
    array: Union["pyarrow.Array", "pyarrow.ChunkedArray"],
    *,
    zero_copy_only: bool = True,
) -> np.ndarray:
    """Wrapper for `Array`s and `ChunkedArray`s `to_numpy` API,
    handling API divergence b/w Arrow versions"""

    import pyarrow as pa

    from ray.data._internal.utils.transform_pyarrow import _is_native_tensor_type

    if isinstance(array, pa.Array):
        if pa.types.is_null(array.type):
            return np.full(len(array), np.nan, dtype=np.float32)
        if _is_native_tensor_type(array.type):
            # This is zero-copy. We use to_numpy_ndarray() because to_numpy
            # will flatten n-dim array into 1d.
            return array.to_numpy_ndarray()
        return array.to_numpy(zero_copy_only=zero_copy_only)
    elif isinstance(array, pa.ChunkedArray):
        if pa.types.is_null(array.type):
            return np.full(array.length(), np.nan, dtype=np.float32)
        if _is_native_tensor_type(array.type):
            # Convert each chunk to numpy, then stack them
            numpy_chunks = [chunk.to_numpy_ndarray() for chunk in array.chunks]
            if len(numpy_chunks) == 0:
                return np.empty((0,) + tuple(array.type.shape))
            return np.vstack(numpy_chunks)
        if PYARROW_VERSION >= MIN_PYARROW_VERSION_CHUNKED_ARRAY_TO_NUMPY_ZERO_COPY_ONLY:
            return array.to_numpy(zero_copy_only=zero_copy_only)
        else:
            return array.to_numpy()
    else:
        raise ValueError(
            f"Either of `Array` or `ChunkedArray` was expected, got {type(array)}"
        )


def try_combine_chunked_columns(
    table: "pyarrow.Table",
    min_chunks_to_combine: int = MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS,
) -> "pyarrow.Table":
    """This method attempts to coalesce table by combining any of its
    columns with at least ``min_chunks_to_combine`` chunks in its
    ``ChunkedArray``.

    This is necessary to improve performance for some operations (like `take`, etc)
    when dealing with `ChunkedArrays` w/ large number of chunks

    For more details check out https://github.com/apache/arrow/issues/35126

    Args:
        table: The PyArrow table to combine chunks for.
        min_chunks_to_combine: Minimum number of chunks in a column to trigger
            combining. Defaults to MIN_NUM_CHUNKS_TO_TRIGGER_COMBINE_CHUNKS.

    Returns:
        A new table with chunked columns combined where applicable.
    """
    if table.num_columns == 0:
        return table

    new_column_values_arrays = []

    for col in table.columns:
        if col.num_chunks >= min_chunks_to_combine and col.num_chunks > 1:
            new_col = combine_chunked_array(col)
        else:
            new_col = col

        new_column_values_arrays.append(new_col)

    return pyarrow.Table.from_arrays(new_column_values_arrays, schema=table.schema)


def combine_chunks(table: "pyarrow.Table", copy: bool = False) -> "pyarrow.Table":
    """This is counterpart for Pyarrow's `Table.combine_chunks` that's using
    extended `ChunkedArray` combination protocol.

    For more details check out `combine_chunked_array` py-doc

    Args:
        table: Table with chunked columns to be combined into contiguous arrays.
        copy: Skip copying when copy is False and there is exactly 1 chunk.

    Returns:
        A new table with contiguous arrays for each column.
    """

    new_column_values_arrays = []

    for col in table.columns:
        new_column_values_arrays.append(combine_chunked_array(col, copy))

    return pyarrow.Table.from_arrays(new_column_values_arrays, schema=table.schema)


def combine_chunked_array(
    array: "pyarrow.ChunkedArray",
    ensure_copy: bool = False,
) -> Union["pyarrow.Array", "pyarrow.ChunkedArray"]:
    """This is counterpart for Pyarrow's `ChunkedArray.combine_chunks` that additionally

        1. Handles `ExtensionType`s (like ArrowTensorType, ArrowTensorTypeV2,
           ArrowPythonObjectType, etc)

        2. Making sure `ChunkedArray`s comprising provided `Table` are combined
           safely, ie avoiding overflows of Arrow's internal offsets (using int32 for
           most of its native types, other than "large" kind).

    For more details check py-doc of `_try_combine_chunks_safe` method.

    Args:
        array: The chunked array to be combined into a single contiguous array.
        ensure_copy: Skip copying when ensure_copy is False and there's exactly
           1 chunk.

    Returns:
        A single combined ``Array`` (or ``ChunkedArray`` for extension types
        that cannot be combined into a single array).
    """

    import pyarrow as pa

    from ray.data._internal.utils.transform_pyarrow import (
        _concatenate_extension_column,
        _is_pa_extension_type,
    )

    assert isinstance(
        array, pa.ChunkedArray
    ), f"Expected `ChunkedArray`, got {type(array)}"

    if _is_pa_extension_type(array.type):
        # Arrow `ExtensionArray`s can't be concatenated via `combine_chunks`,
        # hence require manual concatenation
        return _concatenate_extension_column(array, ensure_copy)
    elif len(array.chunks) == 0:
        # NOTE: In case there's no chunks, we need to explicitly create
        #       an empty array since calling into `combine_chunks` would fail
        #       due to it expecting at least 1 chunk to be present
        return pa.array([], type=array.type)
    elif len(array.chunks) == 1 and not ensure_copy:
        # Skip copying
        return array
    else:
        return _try_combine_chunks_safe(array)


# List of variable-width types using int64 offsets
_VARIABLE_WIDTH_INT64_OFFSET_PA_TYPE_PREDICATES = [
    pyarrow.types.is_large_list,
    pyarrow.types.is_large_string,
    pyarrow.types.is_large_binary,
]


# List of variable-width types using int32 offsets
_VARIABLE_WIDTH_INT32_OFFSET_PA_TYPE_PREDICATES = [
    pyarrow.types.is_string,
    pyarrow.types.is_binary,
    pyarrow.types.is_list,
    # Modeled as list<struct<key, val>>
    pyarrow.types.is_map,
]

if PYARROW_VERSION > MIN_PYARROW_VERSION_VIEW_TYPES:
    _VARIABLE_WIDTH_INT32_OFFSET_PA_TYPE_PREDICATES.extend(
        [
            pyarrow.types.is_string_view,
            pyarrow.types.is_binary_view,
            pyarrow.types.is_list_view,
        ]
    )


def _try_combine_chunks_safe(
    array: "pyarrow.ChunkedArray",
) -> Union["pyarrow.Array", "pyarrow.ChunkedArray"]:
    """This method provides a safe way of combining `ChunkedArray`s exceeding 2 GiB
    in size, which aren't using "large_*" types (and therefore relying on int32
    offsets).

    When handling provided `ChunkedArray` this method will be either

        - Relying on PyArrow's default `combine_chunks` (therefore returning single
        contiguous `Array`) in cases when
            - Array's total size is < 2 GiB
            - Array's underlying type is of "large" kind (ie using one of the
            `large_*` type family)
        - Safely combining subsets of tasks such that resulting `Array`s to not
        exceed 2 GiB in size (therefore returning another `ChunkedArray` albeit
        with potentially smaller number of chunks that have resulted from clumping
        the original ones)

    Args:
        array: The PyArrow ChunkedArray to safely combine.

    Returns:
        - ``pyarrow.Array`` if it's possible to combine provided ``pyarrow.ChunkedArray``
        into single contiguous array
        - ``pyarrow.ChunkedArray`` (albeit with chunks re-combined) if it's not possible to
        produce single pa.Array
    """

    import pyarrow as pa

    from ray.data._internal.utils.transform_pyarrow import _is_pa_extension_type

    assert not _is_pa_extension_type(
        array.type
    ), f"Arrow `ExtensionType`s are not accepted (got {array.type})"

    # It's safe to combine provided `ChunkedArray` in either of 2 cases:
    #   - It's type is NOT a variable-width type (list, binary, string, map),
    #     using int32 offsets into underlying data (bytes) array
    #   - It's type is a variable-width type using int64 offsets (large_list,
    #     large_string, etc)
    #   - It's cumulative byte-size is < INT32_MAX
    if (
        not any(p(array.type) for p in _VARIABLE_WIDTH_INT32_OFFSET_PA_TYPE_PREDICATES)
        or any(p(array.type) for p in _VARIABLE_WIDTH_INT64_OFFSET_PA_TYPE_PREDICATES)
        or array.nbytes < INT32_MAX
    ):
        return array.combine_chunks()

    # In this case it's actually *NOT* safe to try to directly combine
    # Arrow's `ChunkedArray` and is impossible to produce single, contiguous
    # `Array` since
    #     - It's of variable-width type that uses int32 offsets
    #     - It's cumulative estimated byte-size is > INT32_MAX (2 GiB)
    #
    # In this case instead of combining into single contiguous array, we
    # instead "clump" existing chunks into ones such that each of these is < INT32_MAX.
    #
    # NOTE: This branch actually returns `ChunkedArray` and not an `Array`

    new_chunks = []

    cur_chunk_group = []
    cur_chunk_group_size = 0

    for chunk in array.chunks:
        chunk_size = chunk.nbytes

        assert chunk_size <= INT32_MAX

        if cur_chunk_group_size + chunk_size > INT32_MAX:
            # Combine an accumulated group, append to the new list of chunks
            if cur_chunk_group:
                new_chunks.append(pa.concat_arrays(cur_chunk_group))

            cur_chunk_group = []
            cur_chunk_group_size = 0

        cur_chunk_group.append(chunk)
        cur_chunk_group_size += chunk_size

    # Add remaining chunks as last slice
    if cur_chunk_group:
        new_chunks.append(pa.concat_arrays(cur_chunk_group))

    return pa.chunked_array(new_chunks)
