# @trigger.dev/schema-to-json

## 4.5.15

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.15`

## 4.5.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.14`

## 4.5.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.13`

## 4.5.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.12`

## 4.5.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.11`

## 4.5.10

### Patch Changes

- Refresh package builds for TypeScript 7 compatibility while preserving existing runtime entry points. Projects using `emitDecoratorMetadata()` with TypeScript 7 can install the `@typescript/typescript6` compatibility package alongside it; the package remains optional, so installing the Trigger.dev CLI does not install an additional compiler. ([#4318](https://github.com/triggerdotdev/trigger.dev/pull/4318))
- Updated dependencies:
  - `@trigger.dev/core@4.5.10`

## 4.5.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.9`

## 4.5.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.8`

## 4.5.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.7`

## 4.5.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.6`

## 4.5.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.5`

## 4.5.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.4`

## 4.5.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.3`

## 4.5.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.2`

## 4.5.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.1`

## 4.5.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0`

## 4.5.0-rc.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.7`

## 4.5.0-rc.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.6`

## 4.5.0-rc.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.5`

## 4.5.0-rc.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.4`

## 4.5.0-rc.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.3`

## 4.5.0-rc.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.2`

## 4.5.0-rc.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.1`

## 4.5.0-rc.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.0`

## 4.4.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.6`

## 4.4.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.5`

## 4.4.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.4`

## 4.4.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.3`

## 4.4.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.2`

## 4.4.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.1`

## 4.4.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.0`

## 4.3.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.3`

## 4.3.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.2`

## 4.3.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.1`

## 4.3.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.0`

## 4.2.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.2.0`

## 4.1.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.2`

## 4.1.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.1`

## 4.1.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.0`

## 4.0.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.7`

## 4.0.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.6`

## 4.0.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.5`

## 4.0.4

### Patch Changes

- remove effect from optional peer dependencies since it's now a production dependency ([#2527](https://github.com/triggerdotdev/trigger.dev/pull/2527))
- Updated dependencies:
  - `@trigger.dev/core@4.0.4`

## 4.0.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.3`

## 4.0.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.2`

## 4.0.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.1`

## 4.0.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0`

## 4.0.0-v4-beta.28

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.28`

## 4.0.0-v4-beta.27

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.27`
