# @trigger.dev/rsc

## 4.5.15

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.15`

## 4.5.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.14`

## 4.5.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.13`

## 4.5.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.12`

## 4.5.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.11`

## 4.5.10

### Patch Changes

- Refresh package builds for TypeScript 7 compatibility while preserving existing runtime entry points. Projects using `emitDecoratorMetadata()` with TypeScript 7 can install the `@typescript/typescript6` compatibility package alongside it; the package remains optional, so installing the Trigger.dev CLI does not install an additional compiler. ([#4318](https://github.com/triggerdotdev/trigger.dev/pull/4318))
- Updated dependencies:
  - `@trigger.dev/core@4.5.10`

## 4.5.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.9`

## 4.5.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.8`

## 4.5.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.7`

## 4.5.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.6`

## 4.5.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.5`

## 4.5.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.4`

## 4.5.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.3`

## 4.5.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.2`

## 4.5.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.1`

## 4.5.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0`

## 4.5.0-rc.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.7`

## 4.5.0-rc.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.6`

## 4.5.0-rc.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.5`

## 4.5.0-rc.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.4`

## 4.5.0-rc.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.3`

## 4.5.0-rc.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.2`

## 4.5.0-rc.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.1`

## 4.5.0-rc.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.5.0-rc.0`

## 4.4.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.6`

## 4.4.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.5`

## 4.4.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.4`

## 4.4.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.3`

## 4.4.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.2`

## 4.4.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.1`

## 4.4.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.4.0`

## 4.3.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.3`

## 4.3.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.2`

## 4.3.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.1`

## 4.3.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.3.0`

## 4.2.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.2.0`

## 4.1.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.2`

## 4.1.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.1`

## 4.1.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.1.0`

## 4.0.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.7`

## 4.0.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.6`

## 4.0.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.5`

## 4.0.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.4`

## 4.0.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.3`

## 4.0.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.2`

## 4.0.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.1`

## 4.0.0

### Major Changes

- Trigger.dev v4 release. Please see our upgrade to v4 docs to view the full changelog: https://trigger.dev/docs/upgrade-to-v4 ([#1869](https://github.com/triggerdotdev/trigger.dev/pull/1869))

### Patch Changes

- Run Engine 2.0 (alpha) ([#1575](https://github.com/triggerdotdev/trigger.dev/pull/1575))
- Updated dependencies:
  - `@trigger.dev/core@4.0.0`

## 4.0.0-v4-beta.28

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.28`

## 4.0.0-v4-beta.27

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.27`

## 4.0.0-v4-beta.26

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.26`

## 4.0.0-v4-beta.25

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.25`

## 4.0.0-v4-beta.24

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.24`

## 4.0.0-v4-beta.23

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.23`

## 4.0.0-v4-beta.22

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.22`

## 4.0.0-v4-beta.21

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.21`

## 4.0.0-v4-beta.20

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.20`

## 4.0.0-v4-beta.19

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.19`

## 4.0.0-v4-beta.18

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.18`

## 4.0.0-v4-beta.17

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.17`

## 4.0.0-v4-beta.16

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.16`

## 4.0.0-v4-beta.15

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.15`

## 4.0.0-v4-beta.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.14`

## 4.0.0-v4-beta.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.13`

## 4.0.0-v4-beta.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.12`

## 4.0.0-v4-beta.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.11`

## 4.0.0-v4-beta.10

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.10`

## 4.0.0-v4-beta.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.9`

## 4.0.0-v4-beta.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.8`

## 4.0.0-v4-beta.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.7`

## 4.0.0-v4-beta.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.6`

## 4.0.0-v4-beta.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.5`

## 4.0.0-v4-beta.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.4`

## 4.0.0-v4-beta.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.3`

## 4.0.0-v4-beta.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.2`

## 4.0.0-v4-beta.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.1`

## 4.0.0-v4-beta.0

### Major Changes

- Trigger.dev v4 release. Please see our upgrade to v4 docs to view the full changelog: https://trigger.dev/docs/upgrade-to-v4 ([#1869](https://github.com/triggerdotdev/trigger.dev/pull/1869))

### Patch Changes

- Run Engine 2.0 (alpha) ([#1575](https://github.com/triggerdotdev/trigger.dev/pull/1575))
- Updated dependencies:
  - `@trigger.dev/core@4.0.0-v4-beta.0`

## 3.3.17

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.17`

## 3.3.16

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.16`

## 3.3.15

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.15`

## 3.3.14

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.14`

## 3.3.13

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.13`

## 3.3.12

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.12`

## 3.3.11

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.11`

## 3.3.10

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.10`

## 3.3.9

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.9`

## 3.3.8

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.8`

## 3.3.7

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.7`

## 3.3.6

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.6`

## 3.3.5

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.5`

## 3.3.4

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.4`

## 3.3.3

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.3`

## 3.3.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.2`

## 3.3.1

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.1`

## 3.3.0

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.3.0`

## 3.2.2

### Patch Changes

- Updated dependencies:
  - `@trigger.dev/core@3.2.2`

## 3.2.1

### Patch Changes

- Upgrade zod to latest (3.23.8) ([#1484](https://github.com/triggerdotdev/trigger.dev/pull/1484))
- Realtime streams ([#1470](https://github.com/triggerdotdev/trigger.dev/pull/1470))
- Updated dependencies:
  - `@trigger.dev/core@3.2.1`
