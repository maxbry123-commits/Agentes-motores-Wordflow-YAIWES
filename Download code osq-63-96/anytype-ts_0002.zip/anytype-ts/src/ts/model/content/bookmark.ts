import { observable, makeObservable } from 'mobx';
import * as I from 'Interface';

class BlockContentBookmark implements I.ContentBookmark {
	
	targetObjectId = '';
	state: I.BookmarkState = I.BookmarkState.Empty;
	url = '';
	
	constructor (props: I.ContentBookmark) {
		this.targetObjectId = String(props.targetObjectId || '');
		this.state = Number(props.state) || I.BookmarkState.Empty;
		this.url = String(props.url || '');

		makeObservable(this, {
			targetObjectId: observable,
			state: observable,
			url: observable,
		});

		return this;
	};

};

export default BlockContentBookmark;