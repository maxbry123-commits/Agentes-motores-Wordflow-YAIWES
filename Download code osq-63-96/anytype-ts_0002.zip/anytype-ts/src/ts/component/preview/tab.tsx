import React, { forwardRef, useEffect, useRef, useState } from 'react';
import { ObjectName, IconObject, Label } from 'Component';
import * as I from 'Interface';

interface Props {
	spaceview?: any;
	data?: any;
	position?: () => void;
};

const PreviewTab = forwardRef<{}, Props>((props, ref) => {

	const {
		spaceview = {},
		data,
		position,
	} = props;

	const { object, name, action } = data;
	const [ displayObject, setDisplayObject ] = useState<any>(null);
	const [ displayObjectType, setDisplayObjectType ] = useState<any>(null);
	const loadIdRef = useRef(0);

	useEffect(() => {
		const currentLoadId = ++loadIdRef.current;

		setDisplayObject(null);
		setDisplayObjectType(null);
		load(currentLoadId);
	}, [ object?.id, action, spaceview.targetSpaceId ]);

	useEffect(position);

	const load = (loadId: number) => {
		const isChat = (object?.layout == I.ObjectLayout.SpaceView) && spaceview.isOneToOne;

		if (isChat) {
			setDisplayObject({ layout: I.ObjectLayout.Chat, name: translate('commonMainChat') });
		} else
		if (action && name) {
			objectByAction(loadId);
		} else {
			loadObject(loadId);
		};
	};

	const objectByAction = (loadId: number) => {
		const layouts = {
			navigation: I.ObjectLayout.Navigation,
			graph: I.ObjectLayout.Graph,
			archive: I.ObjectLayout.Archive,
			settings: I.ObjectLayout.Settings,
		};

		if (layouts[action]) {
			setDisplayObject({ layout: layouts[action], name });
		} else {
			loadObject(loadId);
		};
	};

	const loadObject = (loadId: number) => {
		if (!object || !object.id) {
			return;
		};
		U.Object.getById(object.id, { spaceId: spaceview.targetSpaceId }, (loaded: any) => {
			if (loaded && (loadId === loadIdRef.current)) {
				setDisplayObject(loaded);
				loadType(loaded.type, loadId);
			};
		});
	};

	const loadType = (id: string, loadId: number) => {
		U.Object.getById(id, { spaceId: spaceview.targetSpaceId }, (loaded: any) => {
			if (loaded && (loadId === loadIdRef.current)) {
				setDisplayObjectType(loaded);
			};
		});
	};

	return (
		<div className="previewTab">
			<div className="previewHeader">
				<IconObject object={spaceview} />
				<ObjectName object={spaceview} />
			</div>
			{displayObject?.name ? (
				<div className="previewObject">
					<div className="side left">
						<IconObject object={displayObject} size={48} iconSize={28} />
					</div>
					<div className="side right">
						<ObjectName object={displayObject} />
						{displayObjectType ? <Label className="type" text={displayObjectType.name} /> : ''}
					</div>
				</div>
			) : null}
		</div>
	);

});

export default PreviewTab;
