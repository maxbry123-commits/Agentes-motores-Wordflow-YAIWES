import React, { forwardRef, useRef, useState, useEffect, MouseEvent } from 'react';
import { Title, Input, Label, Switch, Button, Icon, Error, Loader } from 'Component';
import * as I from 'Interface';

const MenuPublish = forwardRef<I.MenuRef, I.Menu>((props, ref) => {

	const { param, close } = props;
	const { data } = param;
	const { rootId } = data;
	const { space, isOnline } = S.Common;
	const inputRef = useRef(null);
	const publishRef = useRef(null);
	const unpublishRef = useRef(null);
	const spaceInfoRef = useRef(null);
	const spaceview = U.Space.getSpaceview();
	const object = S.Detail.get(rootId, rootId, []);
	const [ slug, setSlug ] = useState(U.String.slug(object.name));
	const [ status, setStatus ] = useState(null);
	const [ isStatusLoading, setIsStatusLoading ] = useState(false);
	const [ isStatusLoaded, setIsStatusLoaded ] = useState(false);
	const [ error, setError ] = useState('');
	const showIncentive = U.Data.isFreeMember();

	const domain = U.Space.getPublishDomain();
	const url = U.Space.getPublishUrl(slug);
	const items: any[] = [
		(!spaceview.isPersonal && !spaceview.isOneToOne ?
		{
			id: 'space',
			icon: 'publish/member',
			name: translate('popupSettingsSpaceIndexShareShareTitle'),
			onClick: () => {
				Action.openSpaceShare(analytics.route.menuPublish);
				close();

				analytics.event('ClickShareObjectShareSpace', { objectType: object.type });
			},
		} : null),
		{
			id: 'export',
			icon: 'publish/export',
			name: translate('popupExportTitle'),
			onClick: () => {
				S.Popup.open('export', { data: { objectIds: [ rootId ], allowHtml: true } });
				close();

				analytics.event('ClickShareObjectShareExport', { objectType: object.type });
			},
		},
	].filter(it => it);

	const onPublish = (isUpdate?: boolean) => {
		const analyticsName = isUpdate ? 'ShareObjectUpdate' : 'ShareObjectPublish';

		publishRef.current?.setLoading(true);

		C.PublishingCreate(space, rootId, slug, spaceInfoRef.current?.getValue(), (message: any) => {
			publishRef.current?.setLoading(false);

			if (message.error.code) {
				switch (message.error.code) {
					default: {
						setError(message.error.description);
						break;
					};

					/*
					case J.Error.Code.Publish.PAGE_SIZE_EXCEEDED: {
						const size = (membership.tierItem.price ? 100 : 10) * 1024 * 1024;
						setError(U.String.sprintf(translate('errorPublishingCreate103'), U.File.size(size));
						break;
					};
					*/
				};

				return;
			};

			if (message.url) {
				Action.openUrl(message.url);
				close();

				analytics.event(analyticsName, { objectType: object.type });
			};
		});

		analytics.event(`Click${analyticsName}`, { objectType: object.type });
	};

	const onUnpublish = () => {
		unpublishRef.current?.setLoading(true);

		C.PublishingRemove(space, rootId, (message: any) => {
			unpublishRef.current?.setLoading(false);

			if (message.error.code) {
				setError(message.error.description);
				return;
			};

			close();
			analytics.event('ShareObjectUnpublish', { objectType: object.type });
		});

		analytics.event('ClickShareObjectUnpublish', { objectType: object.type });
	};

	const onSpaceInfoSwitch = (v: boolean) => {
		analytics.event('SpaceInfoToPublish', { objectType: object.type, type: v });
	};

	const loadStatus = () => {
		setIsStatusLoading(true);

		C.PublishingGetStatus(space, rootId, message => {
			setIsStatusLoading(false);

			if (message.error.code) {
				setError(message.error.description);
				return;
			};

			setIsStatusLoaded(true);

			const { state } = message;

			if (state) {
				setStatus(state);
				setSlug(state.uri);

				inputRef.current?.setValue(state.uri);
				spaceInfoRef.current?.setValue(state.joinSpace);
			};
		});
	};

	const showInfo = (e: MouseEvent) => {
		Preview.tooltipShow({
			text: translate('menuPublishInfoTooltip'),
			className: 'big',
			element: e.currentTarget as HTMLElement,
			typeY: I.MenuDirection.Bottom,
			typeX: I.MenuDirection.Left,
			delay: 0,
		});

		analytics.event('ShowShareObjectHelp', { objectType: object.type });
	};

	const onUpgrade = () => {
		Action.openSettings('membership', analytics.route.menuPublish);
		analytics.event('ClickUpgradePlanTooltip', { type: 'publish' });
	};

	const setSlugHandler = v => setSlug(U.String.slug(v));

	let buttons = [];

	if (isStatusLoaded && isOnline) {
		if (status === null) {
			buttons.push({ text: translate('menuPublishButtonPublish'), ref: publishRef, onClick: () => onPublish() });
		} else {
			buttons = buttons.concat([
				{ text: translate('menuPublishButtonUnpublish'), color: 'blank', ref: unpublishRef, onClick: onUnpublish },
				{ text: translate('commonUpdate'), ref: publishRef, onClick: () => onPublish(true) },
			]);
		};
	};

	useEffect(() => {
		setSlugHandler(object.name);

		if (isOnline) {
			loadStatus();
		};

		return () => {
			Preview.tooltipHide(true);
		};
	}, []);

	useEffect(() => {
		if (isOnline) {
			loadStatus();
		};
	}, [ isOnline ]);

	return (
		<>
			<div className="menuHeader">
				<Title text={translate('menuPublishTitle')} />
				<Icon name="common/info" className="info" onClick={showInfo} />
			</div>

			<Input size={36} value={domain} readonly={true} />
			<Input
                size={36}
                ref={inputRef}
                value={slug}
                focusOnMount={true} 
				onChange={(e, v) => setSlugHandler(v)}
				maxLength={300}
			/>
			<div className="urlWrapper">
				<Label className="small" text={url} onClick={() => Action.openUrl(url)} />
				<Button 
					color="blank" 
					className="simple"
					text={translate('commonCopy')}
					onClick={() => {
						U.Common.copyToast(translate('commonLink'), url);
						analytics.event('ClickShareObjectCopyUrl', { objectType: object.type });
					}} 
				/>
			</div>

			{spaceview.isShared && !spaceview.isOneToOne ? (
				<div className="flex">
					<div className="side left">
						<Icon name="plus/joinSpace" className="joinSpace" />
						<Label text={translate('menuPublishLabelJoinSpace')} />
					</div>
					<div className="value">
						<Switch ref={spaceInfoRef} value={false} onChange={(e, v) => onSpaceInfoSwitch(v)} />
					</div>
				</div>
			) : ''}

			{showIncentive ? (
				<div className="incentiveBanner">
					<Label text={translate('menuPublishBecomeMemberText')} />
					<Button size={28} color="accent" text={translate('commonUpgrade')} onClick={onUpgrade} />
				</div>
			) : ''}

			<div className="buttons">
				{isOnline ? (
					<>
						{isStatusLoading ? <Loader /> : (
							<>
								{buttons.map((item, i) => <Button key={i} {...item} size={36} />)}
							</>
						)}
					</>
				) : <Label text={translate('menuPublishLabelOffline')} />}
			</div>

			<Error text={error} />

			<div className="outer">
				{items.map((item, index) => (
					<div key={index} className="item" onClick={item.onClick}>
						<Icon name={item.icon} color="default" />
						<div className="name">{item.name}</div>
						{item.arrow ? <Icon name="arrow/button" size={8} className="arrow" /> : ''}
					</div>
				))}
			</div>
		</>
	);

});

export default MenuPublish;