package com.xxl.job.admin.business.scheduler.route.strategy;

import com.xxl.job.admin.business.model.XxlJobGroup;
import com.xxl.job.admin.business.scheduler.route.ExecutorRouter;
import com.xxl.job.core.openapi.executor.dto.TriggerRequest;
import com.xxl.tool.response.Response;

import java.util.List;
import java.util.Random;

/**
 * Created by xuxueli on 17/3/10.
 */
public class ExecutorRouteRandom extends ExecutorRouter {

    private static Random localRandom = new Random();

    @Override
    public Response<String> route(TriggerRequest triggerParam, XxlJobGroup jobGroup) {
        List<String> addressList = jobGroup.getRegistryList();
        String address = addressList.get(localRandom.nextInt(addressList.size()));
        return Response.ofSuccess(address);
    }

}
