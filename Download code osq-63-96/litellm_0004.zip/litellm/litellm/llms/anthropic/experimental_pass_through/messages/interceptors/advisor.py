"""
Advisor Orchestration Handler

Implements the advisor tool loop for providers that don't support
advisor_20260301 natively (i.e. everything except Anthropic direct for now).

How it works:
1. Detects advisor_20260301 in tools + non-native provider → intercepts.
2. Translates the advisor tool to a regular function tool the provider understands.
3. Calls the executor model (non-streaming).
4. If the executor makes a tool_use call named "advisor", runs the advisor model
   and injects the result as a tool_result before re-calling the executor.
5. Repeats until the executor produces a final text response or max_uses is hit.
6. Wraps in FakeAnthropicMessagesStreamIterator if the caller requested streaming.
"""

import uuid
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any, Final

import litellm
import litellm.constants as _c
from litellm.litellm_core_utils.url_utils import validate_url
from litellm.llms.anthropic.common_utils import strip_advisor_blocks_from_messages
from litellm.router_utils.cooldown_handlers import mark_advisor_orchestration_failure
from litellm.types.llms.anthropic import ANTHROPIC_ADVISOR_TOOL_TYPE
from litellm.types.llms.anthropic_messages.anthropic_response import (
    AnthropicMessagesResponse,
)

if TYPE_CHECKING:
    from litellm.router import Router

ADVISOR_MAX_USES: Final[int] = _c.ADVISOR_MAX_USES
ADVISOR_NATIVE_PROVIDERS: Final[frozenset] = _c.ADVISOR_NATIVE_PROVIDERS
ADVISOR_TOOL_DESCRIPTION: Final[str] = _c.ADVISOR_TOOL_DESCRIPTION

from .base import MessagesInterceptor


class AdvisorMaxIterationsError(Exception):
    """Raised when the advisor loop exceeds max_uses."""


class AdvisorOrchestrationHandler(MessagesInterceptor):
    """Orchestrates the advisor tool loop for non-native providers."""

    def can_handle(
        self,
        tools: list[dict] | None,
        custom_llm_provider: str | None,
    ) -> bool:
        if not tools:
            return False
        has_advisor: Final = any(t.get("type") == ANTHROPIC_ADVISOR_TOOL_TYPE for t in tools)
        is_non_native: Final = custom_llm_provider not in ADVISOR_NATIVE_PROVIDERS
        return has_advisor and is_non_native

    async def handle(
        self,
        *,
        model: str,
        messages: list[dict],
        tools: list[dict] | None,
        stream: bool | None,
        max_tokens: int,
        custom_llm_provider: str | None,
        **kwargs,
    ) -> AnthropicMessagesResponse | AsyncIterator:
        from litellm.llms.anthropic.experimental_pass_through.messages.fake_stream_iterator import (
            FakeAnthropicMessagesStreamIterator,
        )

        # Extract advisor tool config.
        advisor_tool: Final = next(
            (t for t in (tools or []) if t.get("type") == ANTHROPIC_ADVISOR_TOOL_TYPE),
            None,
        )
        if advisor_tool is None:
            raise ValueError(f"handle() called but no {ANTHROPIC_ADVISOR_TOOL_TYPE} tool found in tools list")
        advisor_model: Final[str] = advisor_tool.get("model") or ""
        if not advisor_model:
            raise ValueError("advisor tool definition must include a 'model' field specifying the advisor model")
        _raw_max_uses: Final = advisor_tool.get("max_uses")
        max_uses: Final[int] = ADVISOR_MAX_USES if _raw_max_uses is None else int(_raw_max_uses)
        advisor_api_key, advisor_api_base = _resolve_advisor_credentials(advisor_tool)

        # Build the synthetic tool definition the provider will receive.
        synthetic_advisor_tool: Final = _make_synthetic_advisor_tool()

        # Executor tools = all original tools with advisor replaced by the synthetic one.
        executor_tools: Final[list[dict]] = [
            (synthetic_advisor_tool if t.get("type") == ANTHROPIC_ADVISOR_TOOL_TYPE else t) for t in (tools or [])
        ]

        # Strip prior advisor blocks from history, preserving advice text as context.
        current_messages: list[dict] = strip_advisor_blocks_from_messages(
            [dict(m) for m in messages], replace_with_text=True
        )

        parent_request_id: Final[str] = str(kwargs.pop("litellm_call_id", None) or uuid.uuid4())
        metadata_base: Final[dict] = dict(kwargs.pop("metadata", None) or {})
        advisor_metadata: Final = {
            **metadata_base,
            "advisor_sub_call": True,
            "parent_request_id": parent_request_id,
        }
        advisor_router: Final = (
            None if (advisor_api_key or advisor_api_base) else _resolve_advisor_router(advisor_model)
        )
        iteration = 0

        while True:
            # --- Executor call (always non-streaming) ---
            executor_response: AnthropicMessagesResponse = await _call_messages_handler(
                model=model,
                messages=current_messages,
                tools=executor_tools,
                stream=False,
                max_tokens=max_tokens,
                custom_llm_provider=custom_llm_provider,
                metadata={
                    **metadata_base,
                    "advisor_sub_call": False,
                    "parent_request_id": parent_request_id,
                },
                **kwargs,
            )

            advisor_use_block = _find_advisor_tool_use(executor_response)

            if advisor_use_block is None:
                # No more advisor calls — this is the final response.
                if stream:
                    return FakeAnthropicMessagesStreamIterator(executor_response)
                return executor_response

            iteration += 1
            if iteration > max_uses:
                max_iterations_error = AdvisorMaxIterationsError(
                    f"Advisor orchestration loop exceeded max_uses={max_uses}. "
                    "Increase max_uses in the advisor tool definition or cap the request."
                )
                mark_advisor_orchestration_failure(max_iterations_error)
                raise max_iterations_error

            # --- Build advisor context ---
            advisor_messages = _build_advisor_context(current_messages, executor_response, advisor_use_block)

            # --- Advisor sub-call (always non-streaming, no tools) ---
            try:
                advisor_response: AnthropicMessagesResponse = (
                    await advisor_router.aanthropic_messages(
                        model=advisor_model,
                        messages=advisor_messages,
                        tools=None,
                        stream=False,
                        max_tokens=max_tokens,
                        metadata=advisor_metadata,
                    )
                    if advisor_router is not None
                    else await _call_messages_handler(
                        model=advisor_model,
                        messages=advisor_messages,
                        tools=None,
                        stream=False,
                        max_tokens=max_tokens,
                        custom_llm_provider=None,
                        metadata=advisor_metadata,
                        api_key=advisor_api_key,
                        api_base=advisor_api_base,
                    )
                )
            except Exception as advisor_sub_call_exception:
                mark_advisor_orchestration_failure(advisor_sub_call_exception)
                raise

            advisor_text = _extract_response_text(advisor_response)

            # --- Inject advisor result and continue loop ---
            current_messages = _inject_advisor_turn(
                current_messages,
                executor_response,
                advisor_use_block,
                advisor_text,
            )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _allow_client_side_advisor_credentials() -> bool:
    """Whether a caller-supplied advisor api_base/api_key may be honored.

    Gated on the proxy's ``allow_client_side_credentials`` opt-in. When the
    interceptor runs outside the proxy (SDK use), there is no admin boundary
    to protect, so client-supplied routing is allowed.
    """
    try:
        from litellm.proxy.proxy_server import general_settings
    except (ImportError, ModuleNotFoundError):
        return True
    return general_settings.get("allow_client_side_credentials") is True


def _resolve_advisor_credentials(advisor_tool: dict) -> tuple[str | None, str | None]:
    """Resolve the (api_key, api_base) override for the advisor sub-call.

    A caller-supplied ``api_base`` is only honored alongside a caller-supplied
    ``api_key``: without one, ``AnthropicModelInfo.get_auth_header()`` falls
    back to the proxy's own Anthropic credentials, which would then be sent to
    the caller-chosen ``api_base``. A caller-supplied ``api_base`` is also
    required to be https with TLS verification on, and SSRF-validated so it
    can't target a private/internal/cloud-metadata address, mirroring
    ``proxy.auth.auth_utils.check_complete_credentials``. https with TLS
    verification is required because ``validate_url`` only rewrites the
    connection to a DNS-pinned IP for http, or for https with
    ``litellm.ssl_verify`` disabled; otherwise it returns the URL unchanged
    and relies on certificate validation to block DNS rebinding, so this
    closes the same gap without threading the pinned URL through the whole
    ``anthropic_messages()`` call chain.
    """
    if not _allow_client_side_advisor_credentials():
        return None, None
    api_key: Final[str | None] = advisor_tool.get("api_key")
    api_base: Final[str | None] = advisor_tool.get("api_base")
    if api_base is None:
        return api_key, None
    if not api_key:
        raise ValueError(
            "advisor tool definition sets 'api_base' without 'api_key'. A "
            "caller-supplied api_base is only honored alongside a "
            "caller-supplied api_key, so the proxy's own credentials are "
            "never sent to a caller-chosen destination."
        )
    if not api_base.startswith("https://"):
        raise ValueError(f"advisor tool definition sets 'api_base'={api_base!r}, which must use the https scheme.")
    if getattr(litellm, "ssl_verify", True) is False:
        raise ValueError(
            "advisor tool definition sets 'api_base' but the proxy has TLS verification "
            "disabled (litellm.ssl_verify=False), so a caller-supplied api_base can't be "
            "safely validated against DNS rebinding."
        )
    if getattr(litellm, "user_url_validation", True):
        validate_url(api_base)
    return api_key, api_base


def _make_synthetic_advisor_tool() -> dict:
    """Build a regular tool definition the executor provider can understand."""
    return {
        "name": "advisor",
        "description": ADVISOR_TOOL_DESCRIPTION,
        "input_schema": {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "The question or challenge you want guidance on.",
                }
            },
            "required": ["question"],
        },
    }


def _find_advisor_tool_use(response: Any) -> dict | None:
    """Return the first tool_use block with name='advisor', or None."""
    content: Final = response.get("content") if isinstance(response, dict) else []
    if not isinstance(content, list):
        return None
    for block in content:
        if isinstance(block, dict) and block.get("type") == "tool_use" and block.get("name") == "advisor":
            return block
    return None


def _extract_response_text(response: Any) -> str:
    """Extract concatenated text from all text blocks in a response."""
    content: Final = response.get("content") if isinstance(response, dict) else []
    if not isinstance(content, list):
        return ""
    parts: Final = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
    return "\n".join(parts).strip()


_PROVIDER_SPECIFIC_KEYS: Final = frozenset({"provider_specific_fields"})


def _build_advisor_context(
    messages: list[dict],
    executor_response: Any,
    advisor_use_block: dict,
) -> list[dict]:
    """
    Build the message list for the advisor sub-call.

    Passes the full conversation + any text the executor produced so far, then
    poses the advisor question as the last user turn.

    tool_use blocks are excluded because Anthropic requires tool_use to be
    immediately followed by tool_result — not the advisor question.

    In-sequence system rows (e.g. Claude Code SessionStart hook output) are
    excluded: they are executor-directed, and a trailing one becomes invalid
    once the question turn is appended after it (a system row must precede an
    assistant message or end the array).
    """
    question: Final = (advisor_use_block.get("input") or {}).get("question") or (
        "Please provide guidance on the current task."
    )
    raw_content: Final = (executor_response.get("content") if isinstance(executor_response, dict) else []) or []
    # Keep only text blocks — strip tool_use and provider-specific fields.
    executor_text_blocks: Final = [
        {k: v for k, v in block.items() if k not in _PROVIDER_SPECIFIC_KEYS}
        for block in raw_content
        if isinstance(block, dict) and block.get("type") == "text"
    ]
    result: Final = [m for m in messages if m.get("role") != "system"]
    if executor_text_blocks:
        result.append({"role": "assistant", "content": executor_text_blocks})
    result.append({"role": "user", "content": question})
    return result


def _inject_advisor_turn(
    messages: list[dict],
    executor_response: Any,
    advisor_use_block: dict,
    advisor_text: str,
) -> list[dict]:
    """
    Append the executor's response (as an assistant turn) and the advisor
    result (as a user tool_result turn) so the executor can continue.
    """
    executor_content: Final = (executor_response.get("content") if isinstance(executor_response, dict) else []) or []
    tool_use_id: Final = advisor_use_block.get("id", "")
    return [
        *messages,
        {"role": "assistant", "content": executor_content},
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": tool_use_id,
                    "content": advisor_text,
                }
            ],
        },
    ]


def _inject_max_uses_error(
    messages: list[dict],
    executor_response: Any,
    advisor_use_block: dict,
) -> list[dict]:
    """
    Inject a max_uses_exceeded error tool_result so the executor continues
    without further advisor calls (mirrors Anthropic's server-side behaviour).
    """
    executor_content: Final = (executor_response.get("content") if isinstance(executor_response, dict) else []) or []
    tool_use_id: Final = advisor_use_block.get("id", "")
    return [
        *messages,
        {"role": "assistant", "content": executor_content},
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": tool_use_id,
                    "content": "Advisor unavailable: max_uses limit reached. Continue without advisor guidance.",
                }
            ],
        },
    ]


def _resolve_advisor_router(advisor_model: str) -> "Router | None":
    """Return the proxy router when it serves ``advisor_model`` directly or via a wildcard.

    Returns ``None`` for SDK callers (no proxy router) and for advisor models the router
    doesn't know about, so those keep resolving through ``litellm.anthropic_messages()``
    provider inference.
    """
    try:
        from litellm.proxy.proxy_server import llm_router
    except (ImportError, ModuleNotFoundError):
        return None
    if llm_router is None:
        return None
    if llm_router.is_recognized_model(advisor_model) or llm_router.pattern_router.route(advisor_model):
        return llm_router
    return None


async def _call_messages_handler(
    model: str,
    messages: list[dict],
    tools: list[dict] | None,
    stream: bool,
    max_tokens: int,
    custom_llm_provider: str | None,
    **kwargs,
) -> Any:
    """
    Call anthropic_messages() — the public async /messages entry point — for
    orchestration sub-calls (executor or advisor).

    Using the public function (decorated with @client) ensures logging, retries,
    and provider resolution all work correctly, identical to a direct user call.
    """
    from litellm.llms.anthropic.experimental_pass_through.messages.handler import (
        anthropic_messages,
    )

    return await anthropic_messages(
        model=model,
        messages=messages,
        tools=tools,
        stream=stream,
        max_tokens=max_tokens,
        custom_llm_provider=custom_llm_provider,
        **kwargs,
    )
