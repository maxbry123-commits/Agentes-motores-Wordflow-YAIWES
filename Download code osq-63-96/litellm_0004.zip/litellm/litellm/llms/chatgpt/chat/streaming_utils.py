"""
Streaming utilities for ChatGPT provider.

Normalizes non-spec-compliant tool_call chunks from the ChatGPT backend API.
"""

from collections.abc import Awaitable
from typing import Final, Protocol

from litellm.types.utils import (
    ChatCompletionDeltaCustomToolCall,
    ChatCompletionDeltaToolCall,
    Delta,
    ModelResponseStream,
)


class ChatGPTChunkStream(Protocol):
    """A ChatGPT chunk source driven either synchronously or asynchronously."""

    def __next__(self) -> ModelResponseStream: ...

    def __anext__(self) -> Awaitable[ModelResponseStream]: ...


def _first_choice_delta(chunk: ModelResponseStream) -> Delta | None:
    return chunk.choices[0].delta


class ChatGPTToolCallNormalizer:
    """
    Wraps a streaming response and fixes tool_call index/dedup issues.

    The ChatGPT backend API (chatgpt.com/backend-api) sends non-spec-compliant
    streaming tool call chunks:
    1. `index` is always 0, even for multiple parallel tool calls
    2. `id` and `name` get repeated in "closing" chunks that shouldn't exist

    This wrapper normalizes the stream to match the OpenAI spec before yielding
    chunks to the consumer.
    """

    def __init__(self, stream: ChatGPTChunkStream):
        self._stream: Final = stream
        self._seen_ids: dict[str, int] = {}  # tool_call_id -> assigned_index
        self._next_index: int = 0
        self._last_id: str | None = None  # tracks which tool call the next delta belongs to

    def __getattr__(self, name: str) -> object:
        return getattr(self._stream, name)

    def __iter__(self) -> "ChatGPTToolCallNormalizer":
        return self

    def __aiter__(self) -> "ChatGPTToolCallNormalizer":
        return self

    def __next__(self) -> ModelResponseStream:
        while True:
            chunk = next(self._stream)
            result = self._normalize(chunk)
            if result is not None:
                return result

    async def __anext__(self) -> ModelResponseStream:
        while True:
            chunk = await self._stream.__anext__()
            result = self._normalize(chunk)
            if result is not None:
                return result

    def _normalize(self, chunk: ModelResponseStream) -> ModelResponseStream | None:
        """Fix tool_calls in the chunk. Returns None to skip duplicate chunks."""
        if not chunk.choices:
            return chunk

        delta: Final = _first_choice_delta(chunk)
        if delta is None or not delta.tool_calls:
            return chunk

        normalized: Final[list[ChatCompletionDeltaToolCall | ChatCompletionDeltaCustomToolCall]] = []
        for tc in delta.tool_calls:
            if tc.id and tc.id not in self._seen_ids:
                # New tool call — assign correct index
                self._seen_ids[tc.id] = self._next_index
                tc.index = self._next_index
                self._last_id = tc.id
                self._next_index += 1
                normalized.append(tc)
            elif tc.id and tc.id in self._seen_ids:
                # Duplicate "closing" chunk — skip it
                continue
            else:
                # Continuation delta (id=None) — fix index
                if self._last_id:
                    tc.index = self._seen_ids[self._last_id]
                normalized.append(tc)

        if not normalized:
            return None  # all tool_calls were duplicates, skip chunk

        delta.tool_calls = normalized
        return chunk
