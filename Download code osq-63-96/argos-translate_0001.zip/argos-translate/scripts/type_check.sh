#!/bin/bash

mypy argostranslate