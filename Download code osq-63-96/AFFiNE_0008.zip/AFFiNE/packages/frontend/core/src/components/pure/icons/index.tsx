export * from './favorite-icon';
