# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import os
from pathlib import Path

AIRFLOW_ROOT_PATH = Path(__file__).resolve().parents[3]

DOCKER_COMPOSE_HOST_PORT = os.environ.get("HOST_PORT", "localhost:8080")
DEFAULT_PYTHON_MAJOR_MINOR_VERSION = "3.10"
DEFAULT_DOCKER_IMAGE = f"ghcr.io/apache/airflow/main/prod/python{DEFAULT_PYTHON_MAJOR_MINOR_VERSION}:latest"
DOCKER_IMAGE = os.environ.get("DOCKER_IMAGE") or DEFAULT_DOCKER_IMAGE
os.environ["AIRFLOW_UID"] = str(os.getuid())

DOCKER_COMPOSE_PATH = (
    AIRFLOW_ROOT_PATH / "airflow-core" / "docs" / "howto" / "docker-compose" / "docker-compose.yaml"
)

AIRFLOW_WWW_USER_USERNAME = os.environ.get("_AIRFLOW_WWW_USER_USERNAME", "airflow")
AIRFLOW_WWW_USER_PASSWORD = os.environ.get("_AIRFLOW_WWW_USER_PASSWORD", "airflow")

E2E_DAGS_FOLDER = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "tests" / "airflow_e2e_tests" / "dags"

# The logs folder where the Airflow logs will be copied to and uploaded to github artifacts
LOGS_FOLDER = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "logs"
TEST_REPORT_FILE = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "_e2e_test_report.json"
LOCALSTACK_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "localstack.yml"
ELASTICSEARCH_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "elasticsearch.yml"
OPENSEARCH_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "opensearch.yml"
E2E_TEST_MODE = os.environ.get("E2E_TEST_MODE", "basic")
AWS_INIT_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "scripts" / "init-aws.sh"

# s3 bucket name for XComObjectStorageBackend tests. This bucket will be created in the `init-aws.sh` script that is run as part of the LocalStack container initialization.
XCOM_BUCKET = "test-xcom-objectstorage-backend"

KAFKA_DIR_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "kafka"

# OpenLineage E2E test paths. The DAGs are sourced from the provider system tests at runtime by
# openlineage_tests/prepare_dags.py; the overlay carries the OpenLineage-specific env + dag_doc mount.
OPENLINEAGE_COMPOSE_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "openlineage.yml"
# Pins the metadata-DB driver back to psycopg2 for the compat matrix (--airflow-version), whose
# released base images predate the psycopg3 default; see openlineage-compat-db.yml for details.
OPENLINEAGE_COMPAT_DB_COMPOSE_PATH = (
    AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "openlineage-compat-db.yml"
)

# CI sets this (the same switch the lang-SDK k8s job uses) to build the lang-SDK
# artifacts with the host toolchain instead of ephemeral toolchain containers.
LANG_SDK_NATIVE_TOOLCHAIN = os.environ.get("LANG_SDK_NATIVE_TOOLCHAIN", "").lower() == "true"

# Java SDK E2E test paths
JAVA_SDK_ROOT_PATH = AIRFLOW_ROOT_PATH / "java-sdk"
JAVA_SDK_EXAMPLE_DAGS_PATH = JAVA_SDK_ROOT_PATH / "example" / "src" / "resources" / "dags"
JAVA_SDK_EXAMPLE_LIBS_PATH = JAVA_SDK_ROOT_PATH / "example" / "build" / "bundle"
JAVA_SDK_MAVEN_CACHE_PATH = AIRFLOW_ROOT_PATH / "files" / "m2"
JAVA_COMPOSE_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "java.yml"
JAVA_DOCKERFILE_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "Dockerfile.java"

# Scala Spark example paths (a separate bundle with its own coordinator/queue).
SCALA_SPARK_EXAMPLE_DAGS_PATH = (
    JAVA_SDK_ROOT_PATH / "scala_spark_example" / "src" / "main" / "resources" / "dags"
)
SCALA_SPARK_EXAMPLE_LIBS_PATH = JAVA_SDK_ROOT_PATH / "scala_spark_example" / "build" / "bundle"

# Java test-fixture bundle paths (deliberately broken task classes for the
# runner-behaviour E2E tests; a separate bundle with its own coordinator/queue
# so they stay out of the user-facing example).
JAVA_TEST_BUNDLE_ROOT_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "java-test-bundle"
JAVA_TEST_BUNDLE_DAGS_PATH = JAVA_TEST_BUNDLE_ROOT_PATH / "src" / "resources" / "dags"
JAVA_TEST_BUNDLE_LIBS_PATH = JAVA_TEST_BUNDLE_ROOT_PATH / "build" / "bundle"

# Go SDK E2E test paths
GO_SDK_ROOT_PATH = AIRFLOW_ROOT_PATH / "go-sdk"
GO_SDK_DAGS_PATH = GO_SDK_ROOT_PATH / "dags"
# Package directory holding func main() for the example bundle; airflow-go-pack
# builds and packs this into a self-contained executable bundle.
GO_SDK_EXAMPLE_BUNDLE_PKG = "./example/bundle"
# Name of the packed bundle binary (matches the example bundle's package dir name).
GO_SDK_BUNDLE_NAME = "example_dags"
# Where airflow-go-pack writes the packed bundle inside the repo (go-sdk/bin is gitignored).
GO_SDK_BIN_PATH = GO_SDK_ROOT_PATH / "bin"
GO_COMPOSE_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "go.yml"
# Go toolchain image used to build the bundle in the containerized path (i.e. unless
# LANG_SDK_NATIVE_TOOLCHAIN is set); must satisfy go-sdk/go.mod's toolchain.
# The Alpine variant is ~7x smaller than the Debian one and is safe here because the
# bundle is built with CGO_ENABLED=0 (a fully static binary, independent of musl/glibc)
# and module fetches go through the HTTPS proxy (no git/gcc needed).
GO_BUILDER_IMAGE = os.environ.get("GO_BUILDER_IMAGE", "golang:1.25-alpine")

# TypeScript SDK E2E test paths
TS_SDK_ROOT_PATH = AIRFLOW_ROOT_PATH / "ts-sdk"
TS_SDK_EXAMPLE_PATH = TS_SDK_ROOT_PATH / "example"
TS_COMPOSE_PATH = AIRFLOW_ROOT_PATH / "airflow-e2e-tests" / "docker" / "ts.yml"
# Builds the bundle and provides the worker's node binary (ts.yml), so the
# bundle runs on the runtime it was built for.
NODE_IMAGE = os.environ.get("NODE_IMAGE", "node:22-slim")
# Writable HOME for the containerized pnpm build; gitignored, caches persist.
TS_SDK_BUILD_HOME_PATH = AIRFLOW_ROOT_PATH / "files" / "pnpm-home"

# Local provider sources are mounted into the airflow containers under this directory so
# ``_PIP_ADDITIONAL_REQUIREMENTS`` can install the in-tree (latest, possibly unreleased)
# provider rather than the published one from PyPI.
PROVIDERS_ROOT_PATH = AIRFLOW_ROOT_PATH / "providers"
PROVIDERS_MOUNT_CONTAINER_PATH = "/opt/airflow-providers"
AIRFLOW_SERVICES_FOR_PROVIDER_MOUNT = (
    "airflow-apiserver",
    "airflow-scheduler",
    "airflow-dag-processor",
    "airflow-worker",
    "airflow-triggerer",
)
