#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import copy
import hashlib
import warnings
from datetime import datetime, timedelta
from typing import Any
from unittest import mock
from unittest.mock import MagicMock, call

import pytest
from tenacity import stop_after_attempt, wait_incrementing

# Do not run the tests when FAB / Flask is not installed
pytest.importorskip("flask_session")

from airflow.models import DAG
from airflow.providers.common.compat.openlineage.facet import (
    Dataset,
    ExternalQueryRunFacet,
    SQLJobFacet,
)
from airflow.providers.common.compat.sdk import AirflowException, BaseOperator, TaskDeferred
from airflow.providers.databricks.exceptions import DatabricksApiError
from airflow.providers.databricks.hooks.databricks import RunState, SQLStatementState
from airflow.providers.databricks.operators.databricks import (
    _DURABLE_UNSET,
    DatabricksCreateJobsOperator,
    DatabricksNotebookOperator,
    DatabricksRunNowOperator,
    DatabricksSQLStatementsOperator,
    DatabricksSubmitRunOperator,
    DatabricksTaskBaseOperator,
    DatabricksTaskOperator,
    _warn_and_disable_durable_pre_3_3,
)
from airflow.providers.databricks.triggers.databricks import (
    DatabricksExecutionTrigger,
    DatabricksSQLStatementExecutionTrigger,
)
from airflow.providers.databricks.utils import databricks as utils

from tests_common.test_utils.version_compat import AIRFLOW_V_3_3_PLUS

DATE = "2017-04-20"
DEFAULT_DATE = datetime(2024, 1, 1)
TASK_ID = "databricks-operator"
DEFAULT_CONN_ID = "databricks_default"
NOTEBOOK_TASK = {"notebook_path": "/test"}
TEMPLATED_NOTEBOOK_TASK = {"notebook_path": "/test-{{ ds }}"}
RENDERED_TEMPLATED_NOTEBOOK_TASK = {"notebook_path": f"/test-{DATE}"}
SPARK_JAR_TASK = {"main_class_name": "com.databricks.Test"}
SPARK_PYTHON_TASK = {"python_file": "test.py", "parameters": ["--param", "123"]}
PIPELINE_ID_TASK = {"pipeline_id": "1234abcd"}
PIPELINE_NAME_TASK = {"pipeline_name": "This is a test pipeline"}
SPARK_SUBMIT_TASK = {
    "parameters": ["--class", "org.apache.spark.examples.SparkPi", "dbfs:/path/to/examples.jar", "10"]
}
NEW_CLUSTER = {
    "spark_version": "2.0.x-scala2.10",
    "node_type_id": "development-node",
    "num_workers": 1,
    "enable_elastic_disk": True,
}
EXISTING_CLUSTER_ID = "existing-cluster-id"
RUN_NAME = "run-name"
RUN_ID = 1
RUN_PAGE_URL = "run-page-url"
STATEMENT_ID = "statement_id"
WAREHOUSE_ID = "warehouse_id"
JOB_ID = "42"
JOB_NAME = "job-name"
JOB_DESCRIPTION = "job-description"
DBT_COMMANDS = ["dbt deps", "dbt seed", "dbt run"]
NOTEBOOK_PARAMS = {"dry-run": "true", "oldest-time-to-consider": "1457570074236"}
JAR_PARAMS = ["param1", "param2"]
RENDERED_TEMPLATED_JAR_PARAMS = [f"/test-{DATE}"]
TEMPLATED_JAR_PARAMS = ["/test-{{ ds }}"]
PYTHON_PARAMS = ["john doe", "35"]
SPARK_SUBMIT_PARAMS = ["--class", "org.apache.spark.examples.SparkPi"]
DBT_TASK = {
    "commands": ["dbt deps", "dbt seed", "dbt run"],
    "schema": "jaffle_shop",
    "warehouse_id": "123456789abcdef0",
}
TAGS = {
    "cost-center": "engineering",
    "team": "jobs",
}
INVALID_RETRY_ARGS_PATTERN = (
    "does not support non-serializable retry_args/databricks_retry_args when deferrable=True"
)
UNSUPPORTED_RETRY_ARGS = [
    pytest.param({"wait": wait_incrementing(start=1, increment=1, max=3)}, id="wait_incrementing"),
    pytest.param({"stop": stop_after_attempt(3)}, id="stop_after_attempt"),
]
TASKS = [
    {
        "task_key": "Sessionize",
        "description": "Extracts session data from events",
        "existing_cluster_id": "0923-164208-meows279",
        "spark_jar_task": {
            "main_class_name": "com.databricks.Sessionize",
            "parameters": [
                "--data",
                "dbfs:/path/to/data.json",
            ],
        },
        "libraries": [
            {"jar": "dbfs:/mnt/databricks/Sessionize.jar"},
        ],
        "timeout_seconds": 86400,
        "max_retries": 3,
        "min_retry_interval_millis": 2000,
        "retry_on_timeout": False,
    },
    {
        "task_key": "Orders_Ingest",
        "description": "Ingests order data",
        "job_cluster_key": "auto_scaling_cluster",
        "spark_jar_task": {
            "main_class_name": "com.databricks.OrdersIngest",
            "parameters": ["--data", "dbfs:/path/to/order-data.json"],
        },
        "libraries": [
            {"jar": "dbfs:/mnt/databricks/OrderIngest.jar"},
        ],
        "timeout_seconds": 86400,
        "max_retries": 3,
        "min_retry_interval_millis": 2000,
        "retry_on_timeout": False,
    },
    {
        "task_key": "Match",
        "description": "Matches orders with user sessions",
        "depends_on": [
            {"task_key": "Orders_Ingest"},
            {"task_key": "Sessionize"},
        ],
        "new_cluster": {
            "spark_version": "7.3.x-scala2.12",
            "node_type_id": "i3.xlarge",
            "spark_conf": {
                "spark.speculation": True,
            },
            "aws_attributes": {
                "availability": "SPOT",
                "zone_id": "us-west-2a",
            },
            "autoscale": {
                "min_workers": 2,
                "max_workers": 16,
            },
        },
        "notebook_task": {
            "notebook_path": "/Users/user.name@databricks.com/Match",
            "source": "WORKSPACE",
            "base_parameters": {
                "name": "John Doe",
                "age": "35",
            },
        },
        "timeout_seconds": 86400,
        "max_retries": 3,
        "min_retry_interval_millis": 2000,
        "retry_on_timeout": False,
    },
]
JOB_CLUSTERS: list[dict[str, Any]] = [
    {
        "job_cluster_key": "auto_scaling_cluster",
        "new_cluster": {
            "spark_version": "7.3.x-scala2.12",
            "node_type_id": "i3.xlarge",
            "spark_conf": {
                "spark.speculation": True,
            },
            "aws_attributes": {
                "availability": "SPOT",
                "zone_id": "us-west-2a",
            },
            "autoscale": {
                "min_workers": 2,
                "max_workers": 16,
            },
        },
    },
]

JOB_CLUSTERS_REPAIR_AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE: list[dict[str, Any]] = [
    {
        **cluster,
        "new_cluster": {
            **cluster["new_cluster"],
            "aws_attributes": {
                **cluster["new_cluster"]["aws_attributes"],
                "zone_id": "us-east-2a",
            },
        },
    }
    for cluster in JOB_CLUSTERS
]

JOB_CLUSTERS_REPAIR_AWS_MAX_SPOT_INSTANCE_COUNT_EXCEEDED_FAILURE: list[dict[str, Any]] = [
    {
        **cluster,
        "new_cluster": {
            **cluster["new_cluster"],
            "aws_attributes": {
                **cluster["new_cluster"]["aws_attributes"],
                "availability": "ON_DEMAND",
            },
        },
    }
    for cluster in JOB_CLUSTERS
]


DATABRICKS_REPAIR_REASON_NEW_SETTINGS = {
    "AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE": {
        "job_clusters": JOB_CLUSTERS_REPAIR_AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE,
    },
    "AWS_MAX_SPOT_INSTANCE_COUNT_EXCEEDED_FAILURE": {
        "job_clusters": JOB_CLUSTERS_REPAIR_AWS_MAX_SPOT_INSTANCE_COUNT_EXCEEDED_FAILURE,
    },
}

EMAIL_NOTIFICATIONS = {
    "on_start": [
        "user.name@databricks.com",
    ],
    "on_success": [
        "user.name@databricks.com",
    ],
    "on_failure": [
        "user.name@databricks.com",
    ],
    "no_alert_for_skipped_runs": False,
}
WEBHOOK_NOTIFICATIONS = {
    "on_start": [
        {
            "id": "03dd86e4-57ef-4818-a950-78e41a1d71ab",
        },
        {
            "id": "0481e838-0a59-4eff-9541-a4ca6f149574",
        },
    ],
    "on_success": [
        {
            "id": "03dd86e4-57ef-4818-a950-78e41a1d71ab",
        }
    ],
    "on_failure": [
        {
            "id": "0481e838-0a59-4eff-9541-a4ca6f149574",
        }
    ],
}
NOTIFICATION_SETTINGS = {"no_alert_for_canceled_runs": True, "no_alert_for_skipped_runs": True}
TIMEOUT_SECONDS = 86400
SCHEDULE = {
    "quartz_cron_expression": "20 30 * * * ?",
    "timezone_id": "Europe/London",
    "pause_status": "PAUSED",
}
MAX_CONCURRENT_RUNS = 10
GIT_SOURCE = {
    "git_url": "https://github.com/databricks/databricks-cli",
    "git_branch": "main",
    "git_provider": "gitHub",
}
ACCESS_CONTROL_LIST = [
    {
        "user_name": "jsmith@example.com",
        "permission_level": "CAN_MANAGE",
    }
]
JOB_PARAMS = [{"name": "param1", "default": "value1"}]


def mock_dict(d: dict):
    m = MagicMock()
    m.return_value = d
    return m


def make_run_with_state_mock(
    lifecycle_state: str, result_state: str, state_message: str = "", run_id=1, job_id=JOB_ID
):
    return mock_dict(
        {
            "job_id": job_id,
            "run_id": run_id,
            "state": {
                "life_cycle_state": lifecycle_state,
                "result_state": result_state,
                "state_message": state_message,
            },
        }
    )


class TestDatabricksCreateJobsOperator:
    def test_init_with_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            name=JOB_NAME,
            tags=TAGS,
            tasks=TASKS,
            job_clusters=JOB_CLUSTERS,
            email_notifications=EMAIL_NOTIFICATIONS,
            webhook_notifications=WEBHOOK_NOTIFICATIONS,
            timeout_seconds=TIMEOUT_SECONDS,
            schedule=SCHEDULE,
            max_concurrent_runs=MAX_CONCURRENT_RUNS,
            git_source=GIT_SOURCE,
            access_control_list=ACCESS_CONTROL_LIST,
        )
        expected = utils.normalise_json_content(
            {
                "name": JOB_NAME,
                "tags": TAGS,
                "tasks": TASKS,
                "job_clusters": JOB_CLUSTERS,
                "email_notifications": EMAIL_NOTIFICATIONS,
                "webhook_notifications": WEBHOOK_NOTIFICATIONS,
                "timeout_seconds": TIMEOUT_SECONDS,
                "schedule": SCHEDULE,
                "max_concurrent_runs": MAX_CONCURRENT_RUNS,
                "git_source": GIT_SOURCE,
                "access_control_list": ACCESS_CONTROL_LIST,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_json(self):
        """
        Test the initializer with json data.
        """
        json = {
            "name": JOB_NAME,
            "tags": TAGS,
            "tasks": TASKS,
            "job_clusters": JOB_CLUSTERS,
            "email_notifications": EMAIL_NOTIFICATIONS,
            "webhook_notifications": WEBHOOK_NOTIFICATIONS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "schedule": SCHEDULE,
            "max_concurrent_runs": MAX_CONCURRENT_RUNS,
            "git_source": GIT_SOURCE,
            "access_control_list": ACCESS_CONTROL_LIST,
        }
        op = DatabricksCreateJobsOperator(task_id=TASK_ID, json=json)

        expected = utils.normalise_json_content(
            {
                "name": JOB_NAME,
                "tags": TAGS,
                "tasks": TASKS,
                "job_clusters": JOB_CLUSTERS,
                "email_notifications": EMAIL_NOTIFICATIONS,
                "webhook_notifications": WEBHOOK_NOTIFICATIONS,
                "timeout_seconds": TIMEOUT_SECONDS,
                "schedule": SCHEDULE,
                "max_concurrent_runs": MAX_CONCURRENT_RUNS,
                "git_source": GIT_SOURCE,
                "access_control_list": ACCESS_CONTROL_LIST,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_merging(self):
        """
        Test the initializer when json and other named parameters are both
        provided. The named parameters should override top level keys in the
        json dict.
        """
        override_name = "override"
        override_tags = {}
        override_tasks = []
        override_job_clusters = []
        override_email_notifications = {}
        override_webhook_notifications = {}
        override_timeout_seconds = 0
        override_schedule = {}
        override_max_concurrent_runs = 0
        override_git_source = {}
        override_access_control_list = []
        json = {
            "name": JOB_NAME,
            "tags": TAGS,
            "tasks": TASKS,
            "job_clusters": JOB_CLUSTERS,
            "email_notifications": EMAIL_NOTIFICATIONS,
            "webhook_notifications": WEBHOOK_NOTIFICATIONS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "schedule": SCHEDULE,
            "max_concurrent_runs": MAX_CONCURRENT_RUNS,
            "git_source": GIT_SOURCE,
            "access_control_list": ACCESS_CONTROL_LIST,
        }

        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            json=json,
            name=override_name,
            tags=override_tags,
            tasks=override_tasks,
            job_clusters=override_job_clusters,
            email_notifications=override_email_notifications,
            webhook_notifications=override_webhook_notifications,
            timeout_seconds=override_timeout_seconds,
            schedule=override_schedule,
            max_concurrent_runs=override_max_concurrent_runs,
            git_source=override_git_source,
            access_control_list=override_access_control_list,
        )

        expected = utils.normalise_json_content(
            {
                "name": override_name,
                "tags": override_tags,
                "tasks": override_tasks,
                "job_clusters": override_job_clusters,
                "email_notifications": override_email_notifications,
                "webhook_notifications": override_webhook_notifications,
                "timeout_seconds": override_timeout_seconds,
                "schedule": override_schedule,
                "max_concurrent_runs": override_max_concurrent_runs,
                "git_source": override_git_source,
                "access_control_list": override_access_control_list,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_templating(self):
        json = {"name": "test-{{ ds }}"}

        dag = DAG("test", schedule=None, start_date=datetime.now())
        op = DatabricksCreateJobsOperator(dag=dag, task_id=TASK_ID, json=json)
        op.render_template_fields(context={"ds": DATE})
        expected = utils.normalise_json_content({"name": f"test-{DATE}"})
        assert expected == utils.normalise_json_content(op._get_merged_json())

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_rendered_python_literal_json_and_templated_named_parameters(self, db_mock_class):
        class FakeTaskInstance:
            @staticmethod
            def xcom_pull(task_ids):
                return {"name": JOB_NAME, "tasks": TASKS}

        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            json="{{ ti.xcom_pull(task_ids='payload') }}",
            name="templated-{{ ds }}",
        )
        op.render_template_fields(context={"ti": FakeTaskInstance(), "ds": DATE})
        db_mock = db_mock_class.return_value
        db_mock.create_job.return_value = JOB_ID
        db_mock.find_job_id_by_name.return_value = None

        return_result = op.execute({})

        expected = utils.normalise_json_content({"name": f"templated-{DATE}", "tasks": TASKS})
        db_mock.create_job.assert_called_once_with(expected)
        assert return_result == JOB_ID

    def test_init_with_bad_type(self):
        json = {"test": datetime.now()}
        # Looks a bit weird since we have to escape regex reserved symbols.
        exception_message = (
            r"Type \<(type|class) \'datetime.datetime\'\> used "
            r"for parameter json\[test\] is not a number or a string"
        )
        op = DatabricksCreateJobsOperator(task_id=TASK_ID, json=json)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_does_not_mutate_json_template_field(self, db_mock_class):
        """``execute`` must not write the merged/normalised payload back into the ``json`` template field.

        The serialized template must stay re-renderable on a retry; this asserts the field the
        ``self.params`` -> ``parameters`` injection touches is left untouched on the operator.
        """
        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            json={"name": JOB_NAME, "tasks": TASKS},
            params={"env": "prod"},
        )
        op.render_template_fields(context={"ds": DATE})
        snapshot = copy.deepcopy(op.json)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = None
        db_mock.create_job.return_value = JOB_ID

        op.execute(None)

        assert op.json == snapshot
        # The params -> parameters injection still reached the payload sent to Databricks.
        assert db_mock.create_job.call_args.args[0]["parameters"] == [{"name": "env", "default": "prod"}]

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_create(self, db_mock_class):
        """
        Test the execute function in case where the job does not exist.
        """
        json = {
            "name": JOB_NAME,
            "description": JOB_DESCRIPTION,
            "tags": TAGS,
            "tasks": TASKS,
            "job_clusters": JOB_CLUSTERS,
            "email_notifications": EMAIL_NOTIFICATIONS,
            "webhook_notifications": WEBHOOK_NOTIFICATIONS,
            "notification_settings": NOTIFICATION_SETTINGS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "schedule": SCHEDULE,
            "max_concurrent_runs": MAX_CONCURRENT_RUNS,
            "git_source": GIT_SOURCE,
            "access_control_list": ACCESS_CONTROL_LIST,
        }
        op = DatabricksCreateJobsOperator(task_id=TASK_ID, json=json)
        db_mock = db_mock_class.return_value
        db_mock.create_job.return_value = JOB_ID

        db_mock.find_job_id_by_name.return_value = None

        return_result = op.execute({})

        expected = utils.normalise_json_content(
            {
                "name": JOB_NAME,
                "description": JOB_DESCRIPTION,
                "tags": TAGS,
                "tasks": TASKS,
                "job_clusters": JOB_CLUSTERS,
                "email_notifications": EMAIL_NOTIFICATIONS,
                "webhook_notifications": WEBHOOK_NOTIFICATIONS,
                "notification_settings": NOTIFICATION_SETTINGS,
                "timeout_seconds": TIMEOUT_SECONDS,
                "schedule": SCHEDULE,
                "max_concurrent_runs": MAX_CONCURRENT_RUNS,
                "git_source": GIT_SOURCE,
                "access_control_list": ACCESS_CONTROL_LIST,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksCreateJobsOperator",
        )

        db_mock.create_job.assert_called_once_with(expected)
        assert return_result == JOB_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_reset(self, db_mock_class):
        """
        Test the execute function in case where the job already exists.
        """
        json = {
            "name": JOB_NAME,
            "description": JOB_DESCRIPTION,
            "tags": TAGS,
            "tasks": TASKS,
            "job_clusters": JOB_CLUSTERS,
            "email_notifications": EMAIL_NOTIFICATIONS,
            "webhook_notifications": WEBHOOK_NOTIFICATIONS,
            "notification_settings": NOTIFICATION_SETTINGS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "schedule": SCHEDULE,
            "max_concurrent_runs": MAX_CONCURRENT_RUNS,
            "git_source": GIT_SOURCE,
            "access_control_list": ACCESS_CONTROL_LIST,
        }
        op = DatabricksCreateJobsOperator(task_id=TASK_ID, json=json)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = JOB_ID

        return_result = op.execute({})

        expected = utils.normalise_json_content(
            {
                "name": JOB_NAME,
                "description": JOB_DESCRIPTION,
                "tags": TAGS,
                "tasks": TASKS,
                "job_clusters": JOB_CLUSTERS,
                "email_notifications": EMAIL_NOTIFICATIONS,
                "webhook_notifications": WEBHOOK_NOTIFICATIONS,
                "notification_settings": NOTIFICATION_SETTINGS,
                "timeout_seconds": TIMEOUT_SECONDS,
                "schedule": SCHEDULE,
                "max_concurrent_runs": MAX_CONCURRENT_RUNS,
                "git_source": GIT_SOURCE,
                "access_control_list": ACCESS_CONTROL_LIST,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksCreateJobsOperator",
        )

        db_mock.reset_job.assert_called_once_with(JOB_ID, expected)
        assert return_result == JOB_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_update_job_permission_with_empty_acl(self, db_mock_class):
        """
        Test job permission update.
        """
        json = {
            "name": JOB_NAME,
            "tags": TAGS,
            "tasks": TASKS,
            "job_clusters": JOB_CLUSTERS,
            "email_notifications": EMAIL_NOTIFICATIONS,
            "webhook_notifications": WEBHOOK_NOTIFICATIONS,
            "timeout_seconds": TIMEOUT_SECONDS,
            "schedule": SCHEDULE,
            "max_concurrent_runs": MAX_CONCURRENT_RUNS,
            "git_source": GIT_SOURCE,
        }
        op = DatabricksCreateJobsOperator(task_id=TASK_ID, json=json)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = JOB_ID

        op.execute({})

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksCreateJobsOperator",
        )

        db_mock.update_job_permission.assert_not_called()

    @pytest.mark.parametrize(
        ("found_job_id", "hook_method"),
        [
            pytest.param(None, "create_job", id="create-path"),
            pytest.param(JOB_ID, "reset_job", id="reset-path"),
        ],
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_injects_airflow_params_when_parameters_missing(self, db_mock_class, found_job_id, hook_method):
        """
        When ``parameters`` is not set in ``json`` and the operator's ``params`` dict is
        non-empty, the operator's ``params`` should be forwarded as job-level
        ``parameters`` on both the create and reset paths (regression test for
        GH-39002).
        """
        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            json={"name": JOB_NAME, "tasks": TASKS},
            params={"env": "prod", "batch_size": 100},
        )
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = found_job_id

        op.execute({})

        # The create-path passes the settings dict directly; the reset-path passes
        # (job_id, settings) — pull the settings out in either case.
        call_args = getattr(db_mock, hook_method).call_args.args
        settings = call_args[0] if hook_method == "create_job" else call_args[1]
        assert settings["parameters"] == [
            {"name": "env", "default": "prod"},
            {"name": "batch_size", "default": 100},
        ]

    @pytest.mark.parametrize(
        ("found_job_id", "hook_method"),
        [
            pytest.param(None, "create_job", id="create-path"),
            pytest.param(JOB_ID, "reset_job", id="reset-path"),
        ],
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_does_not_override_existing_parameters(self, db_mock_class, found_job_id, hook_method):
        """
        When ``parameters`` is already set in ``json``, the operator's ``params`` must
        not override it on either the create or reset paths.
        """
        op = DatabricksCreateJobsOperator(
            task_id=TASK_ID,
            json={"name": JOB_NAME, "tasks": TASKS, "parameters": JOB_PARAMS},
            params={"env": "prod"},
        )
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = found_job_id

        op.execute({})

        call_args = getattr(db_mock, hook_method).call_args.args
        settings = call_args[0] if hook_method == "create_job" else call_args[1]
        assert settings["parameters"] == JOB_PARAMS


class TestDatabricksSubmitRunOperator:
    @staticmethod
    def _configure_running_deferrable_hook(db_mock):
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("RUNNING", "RUNNING")

    def test_init_with_notebook_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, notebook_task=NOTEBOOK_TASK
        )
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_performance_target_named_parameter(self):
        """
        Test the initializer merges ``performance_target`` into the submit payload.
        """
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID,
            new_cluster=NEW_CLUSTER,
            notebook_task=NOTEBOOK_TASK,
            performance_target="PERFORMANCE_OPTIMIZED",
        )
        expected = utils.normalise_json_content(
            {
                "new_cluster": NEW_CLUSTER,
                "notebook_task": NOTEBOOK_TASK,
                "performance_target": "PERFORMANCE_OPTIMIZED",
                "run_name": TASK_ID,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_spark_python_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, spark_python_task=SPARK_PYTHON_TASK
        )
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "spark_python_task": SPARK_PYTHON_TASK, "run_name": TASK_ID}
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_pipeline_name_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, pipeline_task=PIPELINE_NAME_TASK)
        expected = utils.normalise_json_content({"pipeline_task": PIPELINE_NAME_TASK, "run_name": TASK_ID})

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_pipeline_id_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, pipeline_task=PIPELINE_ID_TASK)
        expected = utils.normalise_json_content({"pipeline_task": PIPELINE_ID_TASK, "run_name": TASK_ID})

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_spark_submit_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, spark_submit_task=SPARK_SUBMIT_TASK
        )
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "spark_submit_task": SPARK_SUBMIT_TASK, "run_name": TASK_ID}
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_dbt_task_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        git_source = {
            "git_url": "https://github.com/dbt-labs/jaffle_shop",
            "git_provider": "github",
            "git_branch": "main",
        }
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, dbt_task=DBT_TASK, git_source=git_source
        )
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "dbt_task": DBT_TASK, "git_source": git_source, "run_name": TASK_ID}
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_dbt_task_mixed_parameters(self):
        """
        Test the initializer with mixed parameters.
        """
        git_source = {
            "git_url": "https://github.com/dbt-labs/jaffle_shop",
            "git_provider": "github",
            "git_branch": "main",
        }
        json = {"git_source": git_source}
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, dbt_task=DBT_TASK, json=json
        )
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "dbt_task": DBT_TASK, "git_source": git_source, "run_name": TASK_ID}
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_dbt_task_without_git_source_raises_error(self):
        """
        Test the initializer without the necessary git_source for dbt_task raises error.
        """
        exception_message = "git_source is required for dbt_task"
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, new_cluster=NEW_CLUSTER, dbt_task=DBT_TASK, durable=False
        )
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

    def test_init_with_dbt_task_json_without_git_source_raises_error(self):
        """
        Test the initializer without the necessary git_source for dbt_task raises error.
        """
        json = {"dbt_task": DBT_TASK, "new_cluster": NEW_CLUSTER}

        exception_message = "git_source is required for dbt_task"
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json, durable=False)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

    def test_init_with_json(self):
        """
        Test the initializer with json data.
        """
        json = {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json)
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_tasks(self):
        tasks = [{"task_key": 1, "new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}]
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, tasks=tasks)
        expected = utils.normalise_json_content({"run_name": TASK_ID, "tasks": tasks})
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_specified_run_name(self):
        """
        Test the initializer with a specified run_name.
        """
        json = {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": RUN_NAME}
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json)
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": RUN_NAME}
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_pipeline_task(self):
        """
        Test the initializer with a pipeline task.
        """
        pipeline_task = {"pipeline_id": "test-dlt"}
        json = {"new_cluster": NEW_CLUSTER, "run_name": RUN_NAME, "pipeline_task": pipeline_task}
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json)
        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "pipeline_task": pipeline_task, "run_name": RUN_NAME}
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_merging(self):
        """
        Test the initializer when json and other named parameters are both
        provided. The named parameters should override top level keys in the
        json dict.
        """
        override_new_cluster = {"workers": 999}
        json = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json, new_cluster=override_new_cluster)
        expected = utils.normalise_json_content(
            {
                "new_cluster": override_new_cluster,
                "notebook_task": NOTEBOOK_TASK,
                "run_name": TASK_ID,
            }
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_templating(self):
        json = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": TEMPLATED_NOTEBOOK_TASK,
        }
        dag = DAG("test", schedule=None, start_date=datetime.now())
        op = DatabricksSubmitRunOperator(dag=dag, task_id=TASK_ID, json=json)
        op.render_template_fields(context={"ds": DATE})
        expected = utils.normalise_json_content(
            {
                "new_cluster": NEW_CLUSTER,
                "notebook_task": RENDERED_TEMPLATED_NOTEBOOK_TASK,
                "run_name": TASK_ID,
            }
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_xcom_arg_json_and_templated_named_parameters(self, db_mock_class):
        with DAG("test", schedule=None, start_date=DEFAULT_DATE):
            producer = BaseOperator(task_id="producer")
            op = DatabricksSubmitRunOperator(
                durable=False,
                task_id=TASK_ID,
                json=producer.output,
                new_cluster={**NEW_CLUSTER, "spark_version": "{{ ds }}"},
                wait_for_termination=False,
            )
        ti = MagicMock()
        ti.xcom_pull.return_value = {
            "new_cluster": {"spark_version": "old", "node_type_id": "old", "num_workers": 1},
            "notebook_task": NOTEBOOK_TASK,
        }
        op.render_template_fields(context={"ti": ti, "ds": DATE, "expanded_ti_count": None})
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "new_cluster": {**NEW_CLUSTER, "spark_version": DATE},
                "notebook_task": NOTEBOOK_TASK,
                "run_name": TASK_ID,
            }
        )
        db_mock.submit_run.assert_called_once_with(expected)

    def test_init_with_git_source(self):
        json = {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": RUN_NAME}
        git_source = {
            "git_url": "https://github.com/apache/airflow",
            "git_provider": "github",
            "git_branch": "main",
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, git_source=git_source, json=json)
        expected = utils.normalise_json_content(
            {
                "new_cluster": NEW_CLUSTER,
                "notebook_task": NOTEBOOK_TASK,
                "run_name": RUN_NAME,
                "git_source": git_source,
            }
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_bad_type(self):
        json = {"test": datetime.now()}
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json, durable=False)
        # Looks a bit weird since we have to escape regex reserved symbols.
        exception_message = (
            r"Type \<(type|class) \'datetime.datetime\'\> used "
            r"for parameter json\[test\] is not a number or a string"
        )
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_does_not_mutate_template_fields(self, db_mock_class):
        """``self.params`` injection must not mutate the named task template field in place.

        ``_get_merged_json`` only shallow-copies, so ``self.notebook_task`` is aliased into the merged
        payload by reference. Without an isolated deep copy, ``_inject_airflow_params_into_task`` writes
        ``base_parameters`` straight into the template field, corrupting it for a retry that re-renders
        from it. This is the regression the ``copy.deepcopy`` in ``execute`` guards against.
        """
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            notebook_task={"notebook_path": "/test"},
            new_cluster=NEW_CLUSTER,
            params={"env": "prod"},
        )
        op.render_template_fields(context={"ds": DATE})
        snap_notebook_task = copy.deepcopy(op.notebook_task)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        # The named template field must be untouched (no base_parameters written back into it)...
        assert op.notebook_task == snap_notebook_task
        assert "base_parameters" not in op.notebook_task
        # ...while the params were still injected into the payload actually submitted to Databricks.
        submitted = db_mock.submit_run.call_args.args[0]
        assert submitted["notebook_task"]["base_parameters"] == {"env": "prod"}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_invalid_payload_fails_before_pipeline_lookup(self, db_mock_class):
        """An invalid payload type must fail before any Databricks API call (parity with RunNow).

        The only API a SubmitRun makes before submitting is ``find_pipeline_id_by_name`` (when a
        ``pipeline_name`` is given without a ``pipeline_id``); the up-front ``normalise_json_content``
        validation pass must reject the bad type before that lookup.
        """
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            json={"pipeline_task": {"pipeline_name": "my-pipeline"}, "bad": datetime.now()},
        )
        db_mock = db_mock_class.return_value

        with pytest.raises(AirflowException, match="is not a number or a string"):
            op.execute(None)

        db_mock.find_pipeline_id_by_name.assert_not_called()
        db_mock.submit_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_success(self, db_mock_class):
        """
        Test the execute function in case where the run is successful.
        """
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_pipeline_name(self, db_mock_class):
        """
        Test the execute function when provided a pipeline name.
        """
        run = {"pipeline_task": {"pipeline_name": "This is a test pipeline"}}
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.find_pipeline_id_by_name.return_value = PIPELINE_ID_TASK["pipeline_id"]
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        expected = utils.normalise_json_content({"pipeline_task": PIPELINE_ID_TASK, "run_name": TASK_ID})
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )
        db_mock.find_pipeline_id_by_name.assert_called_once_with("This is a test pipeline")

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_failure(self, db_mock_class):
        """
        Test the execute function in case where the run failed.
        """
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")

        with pytest.raises(AirflowException):
            op.execute(None)

        expected = utils.normalise_json_content(
            {
                "new_cluster": NEW_CLUSTER,
                "notebook_task": NOTEBOOK_TASK,
                "run_name": TASK_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )
        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill(self, db_mock_class):
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=run)
        db_mock = db_mock_class.return_value
        op.run_id = RUN_ID

        op.on_kill()

        db_mock.cancel_run.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_wait_for_termination(self, db_mock_class):
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        assert op.wait_for_termination

        op.execute(None)

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_no_wait_for_termination(self, db_mock_class):
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, wait_for_termination=False, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID

        assert not op.wait_for_termination

        op.execute(None)

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_task_deferred(self, db_mock_class):
        """
        Test the execute function in case where the run is successful.
        """
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("RUNNING", "RUNNING")

        with pytest.raises(TaskDeferred) as exc:
            op.execute(None)
        assert isinstance(exc.value.trigger, DatabricksExecutionTrigger)
        assert exc.value.method_name == "execute_complete"

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @pytest.mark.parametrize("retry_args", UNSUPPORTED_RETRY_ARGS)
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_task_deferred_rejects_non_serializable_retry_args(self, db_mock_class, retry_args):
        op = DatabricksSubmitRunOperator(
            deferrable=True,
            task_id=TASK_ID,
            json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK},
            databricks_retry_args=retry_args,
        )
        db_mock = db_mock_class.return_value
        self._configure_running_deferrable_hook(db_mock)

        with pytest.raises(ValueError, match=INVALID_RETRY_ARGS_PATTERN):
            op.execute(None)

    def test_execute_complete_success(self):
        """
        Test `execute_complete` function in case the Trigger has returned a successful completion event.
        """
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": RunState("TERMINATED", "SUCCESS", "").to_json(),
            "errors": [],
        }

        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID, json=run)
        assert op.execute_complete(context=None, event=event) is None

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks._handle_deferrable_databricks_operator_execution"
    )
    def test_execute_complete_repair_includes_job_parameters(self, mock_handle_exec, mock_hook_class):
        mock_hook_instance = mock_hook_class.return_value
        mock_hook_instance.get_job_id.return_value = 42
        mock_hook_instance.get_latest_repair_id.return_value = None
        mock_hook_instance.repair_run.return_value = "new_repair_id"

        operator = DatabricksRunNowOperator(
            task_id="test_task",
            job_id=42,
            json={"job_parameters": {"key1": "value1"}},
            repair_run=True,
            databricks_conn_id="test_conn",
        )

        context = {}
        event = {
            "run_id": 12345,
            "run_page_url": "https://databricks-instance/#job/42/run/12345",
            "run_state": RunState(
                life_cycle_state="TERMINATED", result_state="FAILED", state_message="Some error occurred"
            ).to_json(),
            "repair_run": True,
            "errors": ["Error detail"],
        }

        operator.execute_complete(context=context, event=event)

        assert mock_hook_instance.repair_run.called, "hook.repair_run should have been called"

        call_args = mock_hook_instance.repair_run.call_args
        repair_json_passed = call_args[0][0]

        assert "job_parameters" in repair_json_passed
        assert repair_json_passed["job_parameters"] == {"key1": "value1"}
        assert repair_json_passed["run_id"] == 12345
        assert repair_json_passed["rerun_all_failed_tasks"] is True
        assert mock_handle_exec.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_complete_failure(self, db_mock_class):
        """
        Test `execute_complete` function in case the Trigger has returned a failure completion event.
        """
        run_state_failed = RunState("TERMINATED", "FAILED", "")
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": run_state_failed.to_json(),
            "repair_run": False,
            "errors": [],
        }

        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID, json=run)
        with pytest.raises(AirflowException):
            op.execute_complete(context=None, event=event)

        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")

        with pytest.raises(AirflowException, match=f"Job run failed with terminal state: {run_state_failed}"):
            op.execute_complete(context=None, event=event)

    def test_execute_complete_incorrect_event_validation_failure(self):
        event = {"event_id": "no such column"}
        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID)
        with pytest.raises(AirflowException):
            op.execute_complete(context=None, event=event)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksSubmitRunOperator.defer")
    def test_databricks_submit_run_deferrable_operator_failed_before_defer(self, mock_defer, db_mock_class):
        """Asserts that terminal failures before deferral fail the task immediately."""
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")
        with pytest.raises(AirflowException, match="Job run failed with terminal state"):
            op.execute(None)

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID
        assert not mock_defer.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksSubmitRunOperator.defer")
    def test_databricks_submit_run_deferrable_operator_success_before_defer(self, mock_defer, db_mock_class):
        """Asserts that a task is not deferred when it succeeds"""
        run = {
            "new_cluster": NEW_CLUSTER,
            "notebook_task": NOTEBOOK_TASK,
        }
        op = DatabricksSubmitRunOperator(deferrable=True, task_id=TASK_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        op.execute(None)

        expected = utils.normalise_json_content(
            {"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK, "run_name": TASK_ID}
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSubmitRunOperator",
        )

        db_mock.submit_run.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID
        assert not mock_defer.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_submit_run_injects_airflow_params_into_notebook_task(self, db_mock_class):
        """
        For a single notebook_task, ``self.params`` should be injected into
        ``notebook_task.base_parameters`` (regression test for GH-39002).
        """
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            notebook_task={"notebook_path": "/Users/me/notebook"},
            new_cluster=NEW_CLUSTER,
            params={"env": "prod", "batch_size": "100"},
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.submit_run.call_args.args[0]
        assert actual["notebook_task"]["base_parameters"] == {"env": "prod", "batch_size": "100"}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_submit_run_injects_airflow_params_into_each_task_in_tasks_list(self, db_mock_class):
        """
        For multiple ``tasks``, dict-shaped per-task params should be filled in for
        each task that supports them.
        """
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            tasks=[
                {"task_key": "t1", "notebook_task": {"notebook_path": "/n1"}},
                {"task_key": "t2", "spark_jar_task": {"main_class_name": "Foo"}},
            ],
            params={"env": "prod"},
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.submit_run.call_args.args[0]
        assert actual["tasks"][0]["notebook_task"]["base_parameters"] == {"env": "prod"}
        # spark_jar_task only accepts List[str] parameters; skip auto-injection.
        assert "parameters" not in actual["tasks"][1]["spark_jar_task"]

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_submit_run_does_not_override_existing_task_parameters(self, db_mock_class):
        """
        If a dict-shaped per-task parameter field is already populated, ``self.params``
        should not override it.
        """
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            notebook_task={
                "notebook_path": "/Users/me/notebook",
                "base_parameters": {"explicit": "value"},
            },
            new_cluster=NEW_CLUSTER,
            params={"env": "prod"},
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.submit_run.call_args.args[0]
        assert actual["notebook_task"]["base_parameters"] == {"explicit": "value"}

    @pytest.mark.parametrize(
        ("json", "exception_message"),
        [
            pytest.param("[1, 2]", "Databricks json payload must resolve to a mapping", id="list"),
            pytest.param("{not-valid", "Databricks json payload string must be valid JSON", id="invalid"),
        ],
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_invalid_rendered_json_raises(self, db_mock_class, json, exception_message):
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json=json, durable=False)

        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        db_mock_class.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_rendered_dbt_task_without_git_source_raises(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            json='{"new_cluster": {"spark_version": "1"}, "dbt_task": {"commands": ["dbt run"]}}',
        )

        with pytest.raises(AirflowException, match="git_source is required for dbt_task"):
            op.execute(None)

        db_mock_class.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_rendered_pipeline_id_and_name_raises(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            json='{"pipeline_task": {"pipeline_id": "1234abcd", "pipeline_name": "pipeline"}}',
        )

        with pytest.raises(
            AirflowException, match="'pipeline_name' is not allowed in conjunction with 'pipeline_id'"
        ):
            op.execute(None)

        db_mock_class.assert_not_called()


class TestDatabricksSubmitRunOperatorOpenLineageInjection:
    """Tests for OpenLineage parent job info and transport info injection in DatabricksSubmitRunOperator."""

    @mock.patch(
        "airflow.providers.databricks.utils.openlineage.inject_openlineage_properties_into_databricks_job"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_inject_parent_job_info_called_when_enabled(self, db_mock_class, mock_inject):
        mock_inject.side_effect = lambda job, context, inject_parent_job_info, inject_transport_info: {
            **job,
            "new_cluster": {
                **job["new_cluster"],
                "spark_conf": {"spark.openlineage.parentJobNamespace": "ns"},
            },
        }
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            new_cluster=NEW_CLUSTER,
            notebook_task=NOTEBOOK_TASK,
            openlineage_inject_parent_job_info=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        mock_inject.assert_called_once()
        submitted = db_mock.submit_run.call_args.args[0]
        assert submitted["new_cluster"]["spark_conf"]["spark.openlineage.parentJobNamespace"] == "ns"

    @mock.patch(
        "airflow.providers.databricks.utils.openlineage.inject_openlineage_properties_into_databricks_job"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_inject_parent_job_info_not_called_when_disabled(self, db_mock_class, mock_inject):
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            new_cluster=NEW_CLUSTER,
            notebook_task=NOTEBOOK_TASK,
            openlineage_inject_parent_job_info=False,
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        mock_inject.assert_not_called()

    @mock.patch(
        "airflow.providers.databricks.utils.openlineage.inject_openlineage_properties_into_databricks_job"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_inject_transport_info_called_when_enabled(self, db_mock_class, mock_inject):
        mock_inject.side_effect = lambda job, context, inject_parent_job_info, inject_transport_info: {
            **job,
            "new_cluster": {**job["new_cluster"], "spark_conf": {"spark.openlineage.transport.type": "http"}},
        }
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            new_cluster=NEW_CLUSTER,
            notebook_task=NOTEBOOK_TASK,
            openlineage_inject_transport_info=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        mock_inject.assert_called_once()
        submitted = db_mock.submit_run.call_args.args[0]
        assert submitted["new_cluster"]["spark_conf"]["spark.openlineage.transport.type"] == "http"

    @mock.patch(
        "airflow.providers.databricks.utils.openlineage.inject_openlineage_properties_into_databricks_job"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_inject_both_parent_and_transport_info(self, db_mock_class, mock_inject):
        mock_inject.side_effect = lambda job, context, inject_parent_job_info, inject_transport_info: job
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            new_cluster=NEW_CLUSTER,
            notebook_task=NOTEBOOK_TASK,
            openlineage_inject_parent_job_info=True,
            openlineage_inject_transport_info=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        mock_inject.assert_called_once()
        _, call_kwargs = mock_inject.call_args
        assert call_kwargs["inject_parent_job_info"] is True
        assert call_kwargs["inject_transport_info"] is True

    @mock.patch(
        "airflow.providers.databricks.utils.openlineage.inject_openlineage_properties_into_databricks_job"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_inject_parent_job_info_preserves_existing_config(self, db_mock_class, mock_inject):
        """Existing ``spark_conf`` entries are preserved alongside the injected OpenLineage properties."""
        new_cluster = {**NEW_CLUSTER, "spark_conf": {"spark.executor.memory": "8g"}}
        mock_inject.side_effect = lambda job, context, inject_parent_job_info, inject_transport_info: {
            **job,
            "new_cluster": {
                **job["new_cluster"],
                "spark_conf": {
                    **job["new_cluster"]["spark_conf"],
                    "spark.openlineage.parentJobNamespace": "ns",
                },
            },
        }
        op = DatabricksSubmitRunOperator(
            durable=False,
            task_id=TASK_ID,
            new_cluster=new_cluster,
            notebook_task=NOTEBOOK_TASK,
            openlineage_inject_parent_job_info=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        submitted = db_mock.submit_run.call_args.args[0]
        assert submitted["new_cluster"]["spark_conf"]["spark.executor.memory"] == "8g"
        assert submitted["new_cluster"]["spark_conf"]["spark.openlineage.parentJobNamespace"] == "ns"


@pytest.mark.skipif(
    not AIRFLOW_V_3_3_PLUS, reason="task_state_store (durable execution) requires Airflow 3.3+"
)
class TestDatabricksSubmitRunOperatorDurable:
    @staticmethod
    def _context(task_store=None):
        ctx: dict = {"ti": MagicMock(stats_tags={})}
        if task_store is not None:
            ctx["task_state_store"] = task_store
        return ctx

    @staticmethod
    def _state(lifecycle: str, result: str = ""):
        return {"state": {"life_cycle_state": lifecycle, "result_state": result, "state_message": ""}}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_persists_run_id_to_task_state_store_on_fresh_submit(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = None

        op.execute(self._context(task_store))

        db_mock.submit_run.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reconnects_to_active_run_without_resubmitting(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        # status check sees the stored run still RUNNING, the poll then sees it finish.
        db_mock.get_run.side_effect = [self._state("RUNNING"), self._state("TERMINATED", "SUCCESS")]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID

        op.execute(self._context(task_store))

        db_mock.submit_run.assert_not_called()
        task_store.set.assert_not_called()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reconnects_to_blocked_run_without_resubmitting(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        # A gated run sits in BLOCKED; the durable retry must reconnect and wait, not resubmit.
        db_mock.get_run.side_effect = [self._state("BLOCKED"), self._state("TERMINATED", "SUCCESS")]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID

        op.execute(self._context(task_store))

        db_mock.submit_run.assert_not_called()
        task_store.set.assert_not_called()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks._handle_databricks_operator_execution")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_already_succeeded_pushes_xcoms_without_polling(self, db_mock_class, mock_poll):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        db_mock.get_run_page_url.return_value = RUN_PAGE_URL
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID
        ti = MagicMock(stats_tags={})

        op.execute({"ti": ti, "task_state_store": task_store})

        # No duplicate submission and no poll loop, but the run xcoms are still pushed for parity
        # with the normal success path.
        db_mock.submit_run.assert_not_called()
        mock_poll.assert_not_called()
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        ti.xcom_push.assert_any_call(key="run_id", value=RUN_ID)
        ti.xcom_push.assert_any_call(key="run_page_url", value=RUN_PAGE_URL)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_fresh_submit_pushes_run_xcoms_exactly_once(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        db_mock.get_run_page_url.return_value = RUN_PAGE_URL
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = None
        ti = MagicMock(stats_tags={})

        op.execute({"ti": ti, "task_state_store": task_store})

        # Poll helper pushes run_id + run_page_url xcoms get_job_result must not push them again
        assert ti.xcom_push.call_count == 2
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_resubmits_when_stored_run_in_terminal_failure(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        # stored run failed, after fresh resubmit the poll sees success.
        db_mock.get_run.side_effect = [
            self._state("TERMINATED", "FAILED"),
            self._state("TERMINATED", "SUCCESS"),
        ]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = 999

        op.execute(self._context(task_store))

        db_mock.submit_run.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_resubmits_when_stored_run_no_longer_exists(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run.side_effect = [
            DatabricksApiError("Response: RESOURCE_DOES_NOT_EXIST, Status Code: 404", http_status_code=404),
            self._state("TERMINATED", "SUCCESS"),
        ]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = 999

        op.execute(self._context(task_store))
        db_mock.submit_run.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_durable_false_never_touches_task_state_store(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}, durable=False
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        task_store = MagicMock(spec_set=["get", "set"])

        op.execute(self._context(task_store))

        db_mock.submit_run.assert_called_once()
        task_store.get.assert_not_called()
        task_store.set.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_durable_true_submits_fresh_missing_task_state_store(self, db_mock_class):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"new_cluster": NEW_CLUSTER, "notebook_task": NOTEBOOK_TASK}
        )
        db_mock = db_mock_class.return_value
        db_mock.submit_run.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(self._context())

        db_mock.submit_run.assert_called_once()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_job_status_encodes_life_cycle_and_result(self, db_mock_class):
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json={"notebook_task": NOTEBOOK_TASK})
        db_mock = db_mock_class.return_value
        db_mock.get_run.return_value = self._state("TERMINATED", "SUCCESS")

        assert op.get_job_status(RUN_ID, {}) == "TERMINATED:SUCCESS"

    @pytest.mark.parametrize(
        ("status", "expected"),
        [
            ("RUNNING:", True),
            ("PENDING:", True),
            ("QUEUED:", True),
            ("TERMINATING:", True),
            ("BLOCKED:", True),
            ("WAITING_FOR_RETRY:", True),
            ("TERMINATED:SUCCESS", False),
            ("TERMINATED:FAILED", False),
            ("SKIPPED:", False),
            ("INTERNAL_ERROR:", False),
            ("NOT_FOUND:", False),
        ],
    )
    def test_is_job_active(self, status, expected):
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json={"notebook_task": NOTEBOOK_TASK})
        assert op.is_job_active(status) is expected

    @pytest.mark.parametrize(
        ("status", "expected"),
        [
            ("TERMINATED:SUCCESS", True),
            ("TERMINATED:FAILED", False),
            ("RUNNING:", False),
            ("SKIPPED:", False),
        ],
    )
    def test_is_job_succeeded(self, status, expected):
        op = DatabricksSubmitRunOperator(task_id=TASK_ID, json={"notebook_task": NOTEBOOK_TASK})
        assert op.is_job_succeeded(status) is expected

    def test_default_args_durable_reaches_operator(self):
        op = DatabricksSubmitRunOperator(
            task_id=TASK_ID, json={"notebook_task": NOTEBOOK_TASK}, default_args={"durable": False}
        )
        assert op.durable is False


class TestDatabricksRunNowOperator:
    def test_init_with_named_parameters(self):
        """
        Test the initializer with the named parameters.
        """
        op = DatabricksRunNowOperator(job_id=JOB_ID, task_id=TASK_ID)
        expected = utils.normalise_json_content({"job_id": 42})

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_json(self):
        """
        Test the initializer with json data.
        """
        json = {
            "dbt_commands": DBT_COMMANDS,
            "notebook_params": NOTEBOOK_PARAMS,
            "jar_params": JAR_PARAMS,
            "python_params": PYTHON_PARAMS,
            "spark_submit_params": SPARK_SUBMIT_PARAMS,
            "job_id": JOB_ID,
            "repair_run": False,
        }
        op = DatabricksRunNowOperator(task_id=TASK_ID, json=json)

        expected = utils.normalise_json_content(
            {
                "dbt_commands": DBT_COMMANDS,
                "notebook_params": NOTEBOOK_PARAMS,
                "jar_params": JAR_PARAMS,
                "python_params": PYTHON_PARAMS,
                "spark_submit_params": SPARK_SUBMIT_PARAMS,
                "job_id": JOB_ID,
                "repair_run": False,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_merging(self):
        """
        Test the initializer when json and other named parameters are both
        provided. The named parameters should override top level keys in the
        json dict.
        """
        override_notebook_params = {"workers": "999"}
        override_jar_params = ["workers", "998"]
        json = {"notebook_params": NOTEBOOK_PARAMS, "jar_params": JAR_PARAMS}

        op = DatabricksRunNowOperator(
            task_id=TASK_ID,
            json=json,
            job_id=JOB_ID,
            dbt_commands=DBT_COMMANDS,
            notebook_params=override_notebook_params,
            python_params=PYTHON_PARAMS,
            jar_params=override_jar_params,
            spark_submit_params=SPARK_SUBMIT_PARAMS,
        )

        expected = utils.normalise_json_content(
            {
                "dbt_commands": DBT_COMMANDS,
                "notebook_params": override_notebook_params,
                "jar_params": override_jar_params,
                "python_params": PYTHON_PARAMS,
                "spark_submit_params": SPARK_SUBMIT_PARAMS,
                "job_id": JOB_ID,
            }
        )

        assert expected == utils.normalise_json_content(op._get_merged_json())

    def test_init_with_templating(self):
        json = {"notebook_params": NOTEBOOK_PARAMS, "jar_params": TEMPLATED_JAR_PARAMS}

        dag = DAG("test", schedule=None, start_date=datetime.now())
        op = DatabricksRunNowOperator(dag=dag, task_id=TASK_ID, job_id=JOB_ID, json=json)
        op.render_template_fields(context={"ds": DATE})
        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "jar_params": RENDERED_TEMPLATED_JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        assert expected == utils.normalise_json_content(op._get_merged_json())

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_json_string_and_templated_named_parameters(self, db_mock_class):
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            json='{"job_id": "1", "notebook_params": {"source": "json"}, "jar_params": ["json"]}',
            job_id="{{ params.job_id }}",
            notebook_params={"date": "{{ ds }}"},
            wait_for_termination=False,
        )
        op.render_template_fields(context={"ds": DATE, "params": {"job_id": JOB_ID}})
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "job_id": JOB_ID,
                "notebook_params": {"date": DATE},
                "jar_params": ["json"],
            }
        )
        db_mock.run_now.assert_called_once_with(expected)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_init_with_bad_type(self, db_mock_class):
        json = {"test": datetime.now()}
        # Looks a bit weird since we have to escape regex reserved symbols.
        exception_message = (
            r"Type \<(type|class) \'datetime.datetime\'\> used "
            r"for parameter json\[test\] is not a number or a string"
        )
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=json, durable=False)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        # Payload type validation now runs before the hook is instantiated, so an invalid payload
        # fails fast without ever creating the DatabricksHook (let alone calling the run-now API).
        db_mock_class.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_does_not_mutate_json_template_field(self, db_mock_class):
        """``execute`` must not write the merged payload (resolved job_id, params, normalisation) back
        into the ``json`` template field, so a retry / deferral-resume re-renders from the original
        template instead of a clobbered dict."""
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            json={"idempotency_token": "token_123"},
            params={"env": "prod"},
        )
        op.render_template_fields(context={"ds": DATE})
        snapshot = copy.deepcopy(op.json)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        assert op.json == snapshot
        # job_id and the params -> job_parameters fallback landed in the submitted payload, not on json.
        submitted = db_mock.run_now.call_args.args[0]
        assert submitted["job_id"] == JOB_ID
        assert submitted["job_parameters"] == {"env": "prod"}

    @pytest.mark.parametrize(
        "kwargs",
        [
            pytest.param({"job_id": JOB_ID}, id="job_id"),
            pytest.param({"job_id": JOB_ID, "cancel_previous_runs": True}, id="cancel_previous_runs"),
            pytest.param({"job_name": JOB_NAME}, id="job_name"),
        ],
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_invalid_payload_fails_before_api_call(self, db_mock_class, kwargs):
        """An invalid payload type must fail before ``find_job_id_by_name`` / ``cancel_all_runs`` /
        ``run_now`` touch the Databricks API."""
        op = DatabricksRunNowOperator(task_id=TASK_ID, json={"bad": datetime.now()}, **kwargs, durable=False)
        db_mock = db_mock_class.return_value

        with pytest.raises(AirflowException, match="is not a number or a string"):
            op.execute(None)

        db_mock.find_job_id_by_name.assert_not_called()
        db_mock.cancel_all_runs.assert_not_called()
        db_mock.run_now.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks._handle_deferrable_databricks_operator_execution"
    )
    def test_execute_complete_repair_includes_named_job_parameters(self, mock_handle_exec, mock_hook_class):
        """Regression guard: ``job_parameters`` supplied via the *named* argument (not inside ``json=``)
        must survive a defer/resume repair. On resume the worker is a fresh process, so the value is
        rebuilt from the template fields via ``_get_merged_json`` rather than read from a mutated
        ``self.json`` (which the previous code did, losing the named value)."""
        mock_hook_instance = mock_hook_class.return_value
        mock_hook_instance.get_job_id.return_value = 42
        mock_hook_instance.get_latest_repair_id.return_value = None
        mock_hook_instance.repair_run.return_value = "new_repair_id"

        operator = DatabricksRunNowOperator(
            task_id="test_task",
            job_id=42,
            job_parameters={"k": "v"},
            repair_run=True,
            databricks_conn_id="test_conn",
        )
        event = {
            "run_id": 12345,
            "run_page_url": "https://databricks-instance/#job/42/run/12345",
            "run_state": RunState(
                life_cycle_state="TERMINATED", result_state="FAILED", state_message="Some error occurred"
            ).to_json(),
            "repair_run": True,
            "errors": ["Error detail"],
        }

        operator.execute_complete(context={}, event=event)

        repair_json_passed = mock_hook_instance.repair_run.call_args[0][0]
        assert repair_json_passed["job_parameters"] == {"k": "v"}
        assert mock_handle_exec.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_sync_repair_reads_job_parameters_from_merged_json(self, db_mock_class):
        """Exercise the synchronous (non-deferrable) repair branch in
        ``_handle_databricks_operator_execution`` -- the only path that reads ``operator._merged_json`` --
        so a regression there (e.g. the attribute being unset) fails loudly instead of passing CI."""
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            json={"job_parameters": {"k": "v"}},
            repair_run=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")
        db_mock.get_latest_repair_id.return_value = None

        with pytest.raises(AirflowException):
            op.execute(None)

        db_mock.repair_run.assert_called_once()
        repair_json_passed = db_mock.repair_run.call_args.args[0]
        assert repair_json_passed["job_parameters"] == {"k": "v"}
        assert repair_json_passed["run_id"] == RUN_ID
        assert repair_json_passed["rerun_all_failed_tasks"] is True

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_success(self, db_mock_class):
        """
        Test the execute function in case where the run is successful.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_failure(self, db_mock_class):
        """
        Test the execute function in case where the run failed.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")

        with pytest.raises(AirflowException):
            op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_failure_with_message(self, db_mock_class):
        """
        Test the execute function in case where the run failed.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = mock_dict(
            {
                "job_id": JOB_ID,
                "run_id": 1,
                "state": {
                    "life_cycle_state": "TERMINATED",
                    "result_state": "FAILED",
                    "state_message": "failed",
                },
                "tasks": [
                    {
                        "run_id": 2,
                        "task_key": "first_task",
                        "state": {
                            "life_cycle_state": "TERMINATED",
                            "result_state": "FAILED",
                            "state_message": "failed",
                        },
                    }
                ],
            }
        )
        db_mock.get_run_output = mock_dict({"error": "Exception: Something went wrong..."})

        with pytest.raises(AirflowException, match="Exception: Something went wrong"):
            op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_multiple_failures_with_message(self, db_mock_class):
        """
        Test the execute function in case where the run failed.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = mock_dict(
            {
                "job_id": JOB_ID,
                "run_id": 1,
                "state": {
                    "life_cycle_state": "TERMINATED",
                    "result_state": "FAILED",
                    "state_message": "failed",
                },
                "tasks": [
                    {
                        "run_id": 2,
                        "task_key": "first_task",
                        "state": {
                            "life_cycle_state": "TERMINATED",
                            "result_state": "FAILED",
                            "state_message": "failed",
                        },
                    },
                    {
                        "run_id": 3,
                        "task_key": "second_task",
                        "state": {
                            "life_cycle_state": "TERMINATED",
                            "result_state": "FAILED",
                            "state_message": "failed",
                        },
                    },
                ],
            }
        )
        db_mock.get_run_output = mock_dict({"error": "Exception: Something went wrong..."})

        with pytest.raises(
            AirflowException,
            match="(?=.*Exception: Something went wrong.*)(?=.*Exception: Something went wrong.*)",
        ):
            op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )
        db_mock.get_run_output.assert_called()
        assert db_mock.get_run_output.call_count == 2
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run)
        db_mock = db_mock_class.return_value
        op.run_id = RUN_ID

        op.on_kill()
        db_mock.cancel_run.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_wait_for_termination(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        assert op.wait_for_termination

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_no_wait_for_termination(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(
            task_id=TASK_ID, job_id=JOB_ID, wait_for_termination=False, json=run, durable=False
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID

        assert not op.wait_for_termination

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_init_exception_with_job_name_and_job_id(self, db_mock_class):
        exception_message = "Argument 'job_name' is not allowed with argument 'job_id'"

        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, job_name=JOB_NAME, durable=False)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        run = {"job_id": JOB_ID, "job_name": JOB_NAME}
        op = DatabricksRunNowOperator(task_id=TASK_ID, json=run, durable=False)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        run = {"job_id": JOB_ID}
        op = DatabricksRunNowOperator(task_id=TASK_ID, json=run, job_name=JOB_NAME, durable=False)
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        db_mock_class.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_exception_with_rendered_job_name_and_job_id(self, db_mock_class):
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            json='{"job_id": "42", "job_name": "job-name"}',
        )

        with pytest.raises(
            AirflowException, match="Argument 'job_name' is not allowed with argument 'job_id'"
        ):
            op.execute(None)

        db_mock_class.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_with_job_name(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_name=JOB_NAME, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = JOB_ID
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )
        db_mock.find_job_id_by_name.assert_called_once_with(JOB_NAME)
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_failure_if_job_id_not_found(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_name=JOB_NAME, json=run, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = None

        exception_message = f"Job ID for job name {JOB_NAME} can not be found"
        with pytest.raises(AirflowException, match=exception_message):
            op.execute(None)

        db_mock.find_job_id_by_name.assert_called_once_with(JOB_NAME)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_cancel_previous_runs(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            cancel_previous_runs=True,
            wait_for_termination=False,
            json=run,
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID

        assert op.cancel_previous_runs

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.cancel_all_runs.assert_called_once_with(JOB_ID)
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_no_cancel_previous_runs(self, db_mock_class):
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            cancel_previous_runs=False,
            wait_for_termination=False,
            json=run,
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID

        assert not op.cancel_previous_runs

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )
        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.cancel_all_runs.assert_not_called()
        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        db_mock.get_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_cancel_previous_runs_without_job_id_raises(self, db_mock_class):
        run = {
            "notebook_params": NOTEBOOK_PARAMS,
            "notebook_task": NOTEBOOK_TASK,
            "jar_params": JAR_PARAMS,
        }

        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            json=run,
            cancel_previous_runs=True,
        )

        db_mock = db_mock_class.return_value

        with pytest.raises(
            ValueError,
            match="cancel_previous_runs=True requires either job_id or job_name",
        ):
            op.execute(None)

        assert db_mock_class.mock_calls == [
            call(
                DEFAULT_CONN_ID,
                retry_limit=op.databricks_retry_limit,
                retry_delay=op.databricks_retry_delay,
                retry_args=None,
                caller="DatabricksRunNowOperator",
            )
        ]
        assert db_mock.cancel_all_runs.mock_calls == []
        assert db_mock.run_now.mock_calls == []

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_task_deferred(self, db_mock_class):
        """
        Test the execute function in case where the run is successful.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("RUNNING", "RUNNING")

        with pytest.raises(TaskDeferred) as exc:
            op.execute(None)
        assert isinstance(exc.value.trigger, DatabricksExecutionTrigger)
        assert exc.value.method_name == "execute_complete"

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID

    def test_execute_complete_success(self):
        """
        Test `execute_complete` function in case the Trigger has returned a successful completion event.
        """
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": RunState("TERMINATED", "SUCCESS", "").to_json(),
            "repair_run": False,
            "errors": [],
        }

        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        assert op.execute_complete(context=None, event=event) is None

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_complete_failure(self, db_mock_class):
        """
        Test `execute_complete` function in case the Trigger has returned a failure completion event.
        """
        run_state_failed = RunState("TERMINATED", "FAILED", "")
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": run_state_failed.to_json(),
            "repair_run": False,
            "errors": [],
        }

        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        with pytest.raises(AirflowException):
            op.execute_complete(context=None, event=event)

        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")

        with pytest.raises(AirflowException, match=f"Job run failed with terminal state: {run_state_failed}"):
            op.execute_complete(context=None, event=event)

    @mock.patch(
        "airflow.providers.databricks.operators.databricks._handle_deferrable_databricks_operator_execution"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_complete_failure_and_repair_run(
        self, db_mock_class, mock_handle_deferrable_databricks_operator_execution
    ):
        """
        Test `execute_complete` function in case the Trigger has returned a failure event with repair_run=True.
        """
        run_state_failed = RunState("TERMINATED", "FAILED", "")
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": run_state_failed.to_json(),
            "repair_run": True,
            "errors": [],
        }

        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        op.execute_complete(context=None, event=event)

        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")
        db_mock.get_latest_repair_id.assert_called_once()
        db_mock.repair_run.assert_called_once()
        mock_handle_deferrable_databricks_operator_execution.assert_called_once()

    @mock.patch(
        "airflow.providers.databricks.operators.databricks._handle_deferrable_databricks_operator_execution"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_deferrable_exec_with_databricks_repair_reason_new_settings(
        self, db_mock_class, mock_handle_deferrable_databricks_operator_execution
    ):
        """
        Test the deferrable execute function in case where user want to repair with new settings
        """
        state_message = f"""Task {TASK_ID} failed with message: Cluster {EXISTING_CLUSTER_ID} was terminated.
            Reason: AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE (CLIENT_ERROR).
            Parameters: aws_api_error_code:InsufficientInstanceCapacity, aws_error_message:There is no Spot
            capacity available that matches your request..
                   """
        run_state_failed = RunState(
            "TERMINATED",
            "FAILED",
            state_message,
        )
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": run_state_failed.to_json(),
            "repair_run": True,
            "errors": [],
        }

        op = DatabricksRunNowOperator(
            deferrable=True,
            task_id=TASK_ID,
            job_id=JOB_ID,
            json=run,
            databricks_repair_reason_new_settings=DATABRICKS_REPAIR_REASON_NEW_SETTINGS,
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_job_id.return_value = JOB_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED", state_message)

        op.execute_complete(context=None, event=event)

        db_mock.update_job.assert_called_once()
        db_mock.update_job.assert_called_with(
            job_id=JOB_ID,
            json=utils.normalise_json_content(
                DATABRICKS_REPAIR_REASON_NEW_SETTINGS["AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE"]
            ),
        )
        db_mock.repair_run.assert_called_once()
        mock_handle_deferrable_databricks_operator_execution.assert_called_once()

    @mock.patch("airflow.providers.databricks.operators.databricks.is_repair_reason_match_exist")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks._handle_deferrable_databricks_operator_execution"
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_deferrable_exec_with_none_databricks_repair_reason_new_settings(
        self,
        db_mock_class,
        mock_handle_deferrable_databricks_operator_execution,
        mock_handle_is_repair_reason_match_exist,
    ):
        """
        Test the deferrable execute function where user does not want to repair with new settings
        """
        state_message = f"""Task {TASK_ID} failed with message: Cluster {EXISTING_CLUSTER_ID} was terminated.
                Reason: AWS_INSUFFICIENT_INSTANCE_CAPACITY_FAILURE (CLIENT_ERROR).
                Parameters: aws_api_error_code:InsufficientInstanceCapacity, aws_error_message:There is no Spot
                capacity available that matches your request..
                       """
        run_state_failed = RunState(
            "TERMINATED",
            "FAILED",
            state_message,
        )
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        event = {
            "run_id": RUN_ID,
            "run_page_url": RUN_PAGE_URL,
            "run_state": run_state_failed.to_json(),
            "repair_run": True,
            "errors": [],
        }

        op = DatabricksRunNowOperator(
            deferrable=True,
            task_id=TASK_ID,
            job_id=JOB_ID,
            json=run,
            databricks_repair_reason_new_settings=None,
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_job_id.return_value = JOB_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED", state_message)

        op.execute_complete(context=None, event=event)

        db_mock.update_job.assert_not_called()
        db_mock.repair_run.assert_called_once()
        mock_handle_deferrable_databricks_operator_execution.assert_called_once()
        mock_handle_is_repair_reason_match_exist.assert_not_called()

    def test_execute_complete_incorrect_event_validation_failure(self):
        event = {"event_id": "no such column"}
        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID)
        with pytest.raises(AirflowException):
            op.execute_complete(context=None, event=event)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksSubmitRunOperator.defer")
    def test_databricks_run_now_deferrable_operator_failed_before_defer(self, mock_defer, db_mock_class):
        """Asserts that terminal failures before deferral fail the task immediately."""
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "FAILED")

        with pytest.raises(AirflowException, match="Job run failed with terminal state"):
            op.execute(None)
        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID
        assert not mock_defer.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksSubmitRunOperator.defer")
    def test_databricks_run_now_deferrable_operator_success_before_defer(self, mock_defer, db_mock_class):
        """Asserts that a task is not deferred when its succeeds"""
        run = {"notebook_params": NOTEBOOK_PARAMS, "notebook_task": NOTEBOOK_TASK, "jar_params": JAR_PARAMS}
        op = DatabricksRunNowOperator(deferrable=True, task_id=TASK_ID, job_id=JOB_ID, json=run)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        expected = utils.normalise_json_content(
            {
                "notebook_params": NOTEBOOK_PARAMS,
                "notebook_task": NOTEBOOK_TASK,
                "jar_params": JAR_PARAMS,
                "job_id": JOB_ID,
            }
        )

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksRunNowOperator",
        )

        db_mock.run_now.assert_called_once_with(expected)
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        assert op.run_id == RUN_ID
        assert not mock_defer.called

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_run_now_injects_airflow_params_when_job_parameters_missing(self, db_mock_class):
        """
        When ``job_parameters`` is not set in ``json`` and the operator's ``params`` dict is
        non-empty, the operator's ``params`` should be forwarded as ``job_parameters``
        (regression test for GH-39002).
        """
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            params={"env": "prod", "batch_size": 100},
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.run_now.call_args.args[0]
        assert actual["job_parameters"] == {"env": "prod", "batch_size": 100}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_run_now_does_not_override_existing_job_parameters(self, db_mock_class):
        """
        When ``job_parameters`` is already set in ``json``, the operator's ``params`` should
        not override it.
        """
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            json={"job_parameters": {"explicit": "value"}},
            params={"env": "prod"},
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.run_now.call_args.args[0]
        assert actual["job_parameters"] == {"explicit": "value"}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_run_now_does_not_inject_airflow_params_when_forward_dag_params_is_false(self, db_mock_class):
        """
        When ``forward_dag_params`` is False, the operator's ``params`` should
        not be forwarded as ``job_parameters``.
        """
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            forward_dag_params=False,
            params={"env": "prod", "batch_size": 100},
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.run_now.call_args.args[0]
        assert "job_parameters" not in actual

    @pytest.mark.parametrize(
        ("slot_param", "slot_val"),
        [
            ("notebook_params", {"foo": "bar"}),
            ("python_params", ["foo", "bar"]),
            ("jar_params", ["foo", "bar"]),
            ("spark_submit_params", ["--class", "Foo"]),
            ("python_named_params", {"foo": "bar"}),
            ("dbt_commands", ["dbt deps", "dbt run"]),
        ],
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_run_now_skips_param_injection_with_legacy_param_slots(self, db_mock_class, slot_param, slot_val):
        """
        When any legacy param slot (notebook_params, etc.) is set, auto-injection of ``self.params``
        into ``job_parameters`` must be skipped because the Databricks API rejects combining them.
        """
        op = DatabricksRunNowOperator(
            durable=False,
            task_id=TASK_ID,
            job_id=JOB_ID,
            params={"env": "prod"},
            **{slot_param: slot_val},
        )
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(None)

        actual = db_mock.run_now.call_args.args[0]
        assert slot_param in actual
        assert "job_parameters" not in actual


@pytest.mark.skipif(
    not AIRFLOW_V_3_3_PLUS, reason="task_state_store (durable execution) requires Airflow 3.3+"
)
class TestDatabricksRunNowOperatorDurable:
    @staticmethod
    def _context(task_store=None):
        ctx: dict = {"ti": MagicMock(stats_tags={})}
        if task_store is not None:
            ctx["task_state_store"] = task_store
        return ctx

    @staticmethod
    def _state(lifecycle: str, result: str = ""):
        return {"state": {"life_cycle_state": lifecycle, "result_state": result, "state_message": ""}}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_persists_run_id_to_task_state_store_on_fresh_submit(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = None

        op.execute(self._context(task_store))

        db_mock.run_now.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_now_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reconnects_to_active_run_without_resubmitting(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        # status check sees the stored run still RUNNING, the poll then sees it finish.
        db_mock.get_run.side_effect = [self._state("RUNNING"), self._state("TERMINATED", "SUCCESS")]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID

        op.execute(self._context(task_store))

        db_mock.run_now.assert_not_called()
        task_store.set.assert_not_called()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reconnects_to_blocked_run_without_resubmitting(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        # A gated run sits in BLOCKED; the durable retry must reconnect and wait, not resubmit.
        db_mock.get_run.side_effect = [self._state("BLOCKED"), self._state("TERMINATED", "SUCCESS")]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID

        op.execute(self._context(task_store))

        db_mock.run_now.assert_not_called()
        task_store.set.assert_not_called()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reconnect_with_job_name_resolves_job_id_for_repair(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_name=JOB_NAME)
        db_mock = db_mock_class.return_value
        db_mock.find_job_id_by_name.return_value = JOB_ID
        db_mock.get_run.side_effect = [self._state("RUNNING"), self._state("TERMINATED", "SUCCESS")]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID

        op.execute(self._context(task_store))

        # The reconnect rebuilds the payload and resolves job_name -> job_id so repair_run has it,
        # without resubmitting the run.
        db_mock.run_now.assert_not_called()
        db_mock.find_job_id_by_name.assert_called_once_with(JOB_NAME)
        assert op._merged_json["job_id"] == JOB_ID
        assert "job_name" not in op._merged_json

    @mock.patch("airflow.providers.databricks.operators.databricks._handle_databricks_operator_execution")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_already_succeeded_pushes_xcoms_without_polling(self, db_mock_class, mock_poll):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        db_mock.get_run_page_url.return_value = RUN_PAGE_URL
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = RUN_ID
        ti = MagicMock(stats_tags={})

        op.execute({"ti": ti, "task_state_store": task_store})

        # No duplicate run and no poll loop, but the run xcoms are still pushed for parity.
        db_mock.run_now.assert_not_called()
        mock_poll.assert_not_called()
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)
        ti.xcom_push.assert_any_call(key="run_id", value=RUN_ID)
        ti.xcom_push.assert_any_call(key="run_page_url", value=RUN_PAGE_URL)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_fresh_submit_pushes_run_xcoms_exactly_once(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        db_mock.get_run_page_url.return_value = RUN_PAGE_URL
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = None
        ti = MagicMock(stats_tags={})

        op.execute({"ti": ti, "task_state_store": task_store})

        # Poll helper pushes run_id + run_page_url; get_job_result must not push them again.
        assert ti.xcom_push.call_count == 2
        db_mock.get_run_page_url.assert_called_once_with(RUN_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_resubmits_when_stored_run_in_terminal_failure(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run.side_effect = [
            self._state("TERMINATED", "FAILED"),
            self._state("TERMINATED", "SUCCESS"),
        ]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = 999

        op.execute(self._context(task_store))

        db_mock.run_now.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_now_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_resubmits_when_stored_run_no_longer_exists(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        # the stored run's history has expired -> get_run 404s; the fresh run then polls to success.
        db_mock.get_run.side_effect = [
            DatabricksApiError("Response: RESOURCE_DOES_NOT_EXIST, Status Code: 404", http_status_code=404),
            self._state("TERMINATED", "SUCCESS"),
        ]
        task_store = MagicMock(spec_set=["get", "set"])
        task_store.get.return_value = 999

        op.execute(self._context(task_store))

        db_mock.run_now.assert_called_once()
        task_store.set.assert_called_once_with("databricks_run_now_id", RUN_ID)
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_durable_false_never_touches_task_state_store(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, durable=False)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")
        task_store = MagicMock(spec_set=["get", "set"])

        op.execute(self._context(task_store))

        db_mock.run_now.assert_called_once()
        task_store.get.assert_not_called()
        task_store.set.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_durable_true_submits_fresh_missing_task_state_store(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.run_now.return_value = RUN_ID
        db_mock.get_run = make_run_with_state_mock("TERMINATED", "SUCCESS")

        op.execute(self._context())  # no task_state_store in context

        db_mock.run_now.assert_called_once()
        assert op.run_id == RUN_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_job_status_encodes_life_cycle_and_result(self, db_mock_class):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        db_mock = db_mock_class.return_value
        db_mock.get_run.return_value = self._state("TERMINATED", "SUCCESS")

        assert op.get_job_status(RUN_ID, {}) == "TERMINATED:SUCCESS"

    @pytest.mark.parametrize(
        ("status", "expected"),
        [
            ("RUNNING:", True),
            ("PENDING:", True),
            ("QUEUED:", True),
            ("TERMINATING:", True),
            ("BLOCKED:", True),
            ("WAITING_FOR_RETRY:", True),
            ("TERMINATED:SUCCESS", False),
            ("TERMINATED:FAILED", False),
            ("SKIPPED:", False),
            ("INTERNAL_ERROR:", False),
            ("NOT_FOUND:", False),
        ],
    )
    def test_is_job_active(self, status, expected):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        assert op.is_job_active(status) is expected

    @pytest.mark.parametrize(
        ("status", "expected"),
        [
            ("TERMINATED:SUCCESS", True),
            ("TERMINATED:FAILED", False),
            ("RUNNING:", False),
            ("SKIPPED:", False),
        ],
    )
    def test_is_job_succeeded(self, status, expected):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID)
        assert op.is_job_succeeded(status) is expected

    def test_default_args_durable_reaches_operator(self):
        op = DatabricksRunNowOperator(task_id=TASK_ID, job_id=JOB_ID, default_args={"durable": False})
        assert op.durable is False


class TestDatabricksSQLStatementsOperator:
    def test_init(self):
        """
        Test the initializer.
        """
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )

        assert op.statement == "select * from test.test;"
        assert op.warehouse_id == WAREHOUSE_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_success(self, db_mock_class):
        """
        Test the execute function in case where the statement is successful.
        """
        expected_json = {
            "statement": "select * from test.test;",
            "warehouse_id": WAREHOUSE_ID,
            "catalog": None,
            "schema": None,
            "parameters": None,
            "wait_timeout": "0s",
        }
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID

        op.execute(None)

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSQLStatementsOperator",
        )

        db_mock.post_sql_statement.assert_called_once_with(expected_json)
        db_mock.get_sql_statement_state.assert_called_once_with(STATEMENT_ID)
        assert op.statement_id == STATEMENT_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_exec_failure(self, db_mock_class):
        """
        Test the execute function in case where the statement failed.
        """
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.get_sql_statement_state.return_value = SQLStatementState(
            state="FAILED", error_code="500", error_message="Something went wrong"
        )

        with pytest.raises(AirflowException):
            op.execute(None)

        db_mock_class.assert_called_once_with(
            DEFAULT_CONN_ID,
            retry_limit=op.databricks_retry_limit,
            retry_delay=op.databricks_retry_delay,
            retry_args=None,
            caller="DatabricksSQLStatementsOperator",
        )
        db_mock.get_sql_statement_state.assert_called_once_with(STATEMENT_ID)
        assert op.statement_id == STATEMENT_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill(self, db_mock_class):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )
        db_mock = db_mock_class.return_value
        op.statement_id = STATEMENT_ID

        op.on_kill()

        db_mock.cancel_sql_statement.assert_called_once_with(STATEMENT_ID)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_wait_for_termination_is_default(self, db_mock_class):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )

        assert op.wait_for_termination

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_no_wait_for_termination(self, db_mock_class):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            wait_for_termination=False,
        )
        db_mock = db_mock_class.return_value

        assert not op.wait_for_termination

        op.execute(None)

        db_mock.get_sql_statement_state.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_task_deferred(self, db_mock_class):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            deferrable=True,
        )
        db_mock = db_mock_class.return_value
        db_mock.get_sql_statement_state.return_value = SQLStatementState("RUNNING")

        with pytest.raises(TaskDeferred) as exc:
            op.execute(None)
        assert isinstance(exc.value.trigger, DatabricksSQLStatementExecutionTrigger)
        assert exc.value.method_name == "execute_complete"

    def test_execute_complete_success(self):
        """
        Test `execute_complete` function in case the Trigger has returned a successful completion event.
        """
        event = {
            "statement_id": STATEMENT_ID,
            "state": SQLStatementState("SUCCEEDED").to_json(),
            "error": {},
        }

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            deferrable=True,
        )
        assert op.execute_complete(context=None, event=event) is None

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_complete_failure(self, db_mock_class):
        """
        Test `execute_complete` function in case the Trigger has returned a failure completion event.
        """
        event = {
            "statement_id": STATEMENT_ID,
            "state": SQLStatementState("FAILED").to_json(),
            "error": SQLStatementState(
                state="FAILED", error_code="500", error_message="Something Went Wrong"
            ).to_json(),
        }
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            deferrable=True,
        )

        with pytest.raises(AirflowException, match="^SQL Statement execution failed with terminal state: .*"):
            op.execute_complete(context=None, event=event)

    def test_execute_complete_sets_statement_id(self):
        """
        Test `execute_complete` function is setting statement_id as operator attribute.
        """
        event = {
            "statement_id": STATEMENT_ID,
            "state": SQLStatementState("SUCCEEDED").to_json(),
            "error": {},
        }

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            deferrable=True,
        )
        assert op.statement_id is None
        op.execute_complete(context=None, event=event)
        assert op.statement_id == STATEMENT_ID

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_openlineage_facets(self, db_mock_class):
        query = "insert into dest_schema.dest_table select * from source_schema.source_table"
        op = DatabricksSQLStatementsOperator(task_id=TASK_ID, statement=query, warehouse_id=WAREHOUSE_ID)
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.host = "host"

        op.execute(None)

        result = op.get_openlineage_facets_on_complete(None)
        assert result.inputs == [Dataset(namespace="databricks://host", name="source_schema.source_table")]
        assert result.outputs == [Dataset(namespace="databricks://host", name="dest_schema.dest_table")]
        assert result.run_facets == {
            "externalQuery": ExternalQueryRunFacet(externalQueryId=STATEMENT_ID, source="databricks://host")
        }
        assert result.job_facets == {"sql": SQLJobFacet(query=query)}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_openlineage_facets_with_parametrized_query(self, db_mock_class):
        query = "insert into dest_schema.:dest select * from source_schema.:src"
        filled_query = "insert into dest_schema.dest_table select * from source_schema.source_table"
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement=query,
            warehouse_id=WAREHOUSE_ID,
            parameters=[{"name": "dest", "value": "dest_table"}, {"name": "src", "value": "source_table"}],
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.host = "host"

        op.execute(None)

        result = op.get_openlineage_facets_on_complete(None)
        assert result.inputs == [Dataset(namespace="databricks://host", name="source_schema.source_table")]
        assert result.outputs == [Dataset(namespace="databricks://host", name="dest_schema.dest_table")]
        assert result.run_facets == {
            "externalQuery": ExternalQueryRunFacet(externalQueryId=STATEMENT_ID, source="databricks://host")
        }
        assert result.job_facets == {"sql": SQLJobFacet(query=filled_query)}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_openlineage_facets_with_default_catalog_and_schema(self, db_mock_class):
        query = "insert into dest_cat.dest_schema.dest_table select * from source_table"
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement=query,
            warehouse_id=WAREHOUSE_ID,
            catalog="default_catalog",
            schema="default_schema",
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.host = "host"

        op.execute(None)

        result = op.get_openlineage_facets_on_complete(None)
        assert result.inputs == [
            Dataset(namespace="databricks://host", name="default_catalog.default_schema.source_table")
        ]
        assert result.outputs == [
            Dataset(namespace="databricks://host", name="dest_cat.dest_schema.dest_table")
        ]
        assert result.run_facets == {
            "externalQuery": ExternalQueryRunFacet(externalQueryId=STATEMENT_ID, source="databricks://host")
        }
        assert result.job_facets == {"sql": SQLJobFacet(query=query)}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_get_openlineage_facets_without_statement_id(self, db_mock_class):
        """Test missing statement_id, even though that should not happen."""
        query = "insert into dest_cat.dest_schema.dest_table select * from source_table"
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement=query,
            warehouse_id=WAREHOUSE_ID,
            catalog="default_catalog",
            schema="default_schema",
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.host = "host"

        op.execute(None)
        op.statement_id = None

        result = op.get_openlineage_facets_on_complete(None)
        assert result.inputs == [
            Dataset(namespace="databricks://host", name="default_catalog.default_schema.source_table")
        ]
        assert result.outputs == [
            Dataset(namespace="databricks://host", name="dest_cat.dest_schema.dest_table")
        ]
        assert result.run_facets == {}
        assert result.job_facets == {"sql": SQLJobFacet(query=query)}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch("airflow.providers.openlineage.sqlparser.SQLParser")
    def test_get_openlineage_facets_with_sql_parser_error(self, mock_sql_parser, db_mock_class):
        def raise_func():
            raise ValueError("sql parsing error")

        query = (
            "insert into dest_cat.dest_schema.dest_table select * from source_cat.source_schema.source_table"
        )
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement=query,
            warehouse_id=WAREHOUSE_ID,
        )
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID
        db_mock.host = "host"
        mock_sql_parser().generate_openlineage_metadata_from_sql.side_effect = raise_func
        mock_sql_parser().create_namespace.return_value = "dbx_namespace"
        mock_sql_parser.normalize_sql.side_effect = lambda x: "normalized" + x

        op.execute(None)

        result = op.get_openlineage_facets_on_complete(None)
        assert result.inputs == []
        assert result.outputs == []
        assert result.run_facets == {
            "externalQuery": ExternalQueryRunFacet(externalQueryId=STATEMENT_ID, source="dbx_namespace")
        }
        assert result.job_facets == {"sql": SQLJobFacet(query="normalized" + query)}

    def test_query_tags_defaults(self):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID, statement="select * from test.test;", warehouse_id=WAREHOUSE_ID
        )
        assert op.query_tags == {}
        assert op.include_airflow_query_tags is True

    def test_query_tags_in_template_fields(self):
        assert "query_tags" in DatabricksSQLStatementsOperator.template_fields

    def test_query_tags_stored(self):
        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            query_tags={"env": "prod"},
        )
        assert op.query_tags == {"env": "prod"}

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_passes_query_tags_to_post_sql_statement(self, db_mock_class):
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            query_tags={"team": "data"},
            include_airflow_query_tags=False,
        )
        op.execute(None)

        posted_json = db_mock.post_sql_statement.call_args[0][0]
        assert posted_json["query_tags"] == [{"key": "team", "value": "data"}]

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_omits_query_tags_when_none(self, db_mock_class):
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            include_airflow_query_tags=False,
        )
        op.execute(None)

        posted_json = db_mock.post_sql_statement.call_args[0][0]
        assert "query_tags" not in posted_json

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_includes_airflow_query_tags(self, db_mock_class):
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            query_tags={"custom": "value"},
        )
        mock_ti = mock.MagicMock(spec=["dag_id", "task_id", "run_id", "try_number", "map_index", "xcom_push"])
        mock_ti.dag_id = "my_dag"
        mock_ti.task_id = "my_task"
        mock_ti.run_id = "run_1"
        mock_ti.try_number = 1
        mock_ti.map_index = -1

        op.execute(context={"ti": mock_ti})

        posted_json = db_mock.post_sql_statement.call_args[0][0]
        tag_keys = {t["key"] for t in posted_json["query_tags"]}
        assert "airflow_dag_id" in tag_keys
        assert "custom" in tag_keys

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_custom_query_tags_override_airflow_tags(self, db_mock_class):
        db_mock = db_mock_class.return_value
        db_mock.post_sql_statement.return_value = STATEMENT_ID

        op = DatabricksSQLStatementsOperator(
            task_id=TASK_ID,
            statement="select * from test.test;",
            warehouse_id=WAREHOUSE_ID,
            query_tags={"airflow_dag_id": "overridden"},
        )
        mock_ti = mock.MagicMock(spec=["dag_id", "task_id", "run_id", "try_number", "map_index", "xcom_push"])
        mock_ti.dag_id = "original"
        mock_ti.task_id = "t"
        mock_ti.run_id = "r"
        mock_ti.try_number = 1
        mock_ti.map_index = -1

        op.execute(context={"ti": mock_ti})

        posted_json = db_mock.post_sql_statement.call_args[0][0]
        tag_map = {t["key"]: t["value"] for t in posted_json["query_tags"]}
        assert tag_map["airflow_dag_id"] == "overridden"


class TestDatabricksNotebookOperator:
    def test_is_instance_of_databricks_task_base_operator(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )

        assert isinstance(operator, DatabricksTaskBaseOperator)

    def test_execute_with_wait_for_termination(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )
        operator._launch_job = MagicMock(return_value=12345)
        operator.monitor_databricks_job = MagicMock()

        operator.execute({})

        assert operator.wait_for_termination is True
        operator._launch_job.assert_called_once()
        operator.monitor_databricks_job.assert_called_once()

    def test_execute_without_wait_for_termination(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=False,
        )
        operator._launch_job = MagicMock(return_value=12345)
        operator.monitor_databricks_job = MagicMock()

        operator.execute({})

        assert operator.wait_for_termination is False
        operator._launch_job.assert_called_once()
        operator.monitor_databricks_job.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_execute_with_deferrable(self, mock_get_current_task, mock_databricks_hook):
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "PENDING"},
            "run_page_url": "test_url",
        }
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=True,
            deferrable=True,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(TaskDeferred) as exec_info:
            operator.monitor_databricks_job()
        assert isinstance(exec_info.value.trigger, DatabricksExecutionTrigger), (
            "Trigger is not a DatabricksExecutionTrigger"
        )
        assert exec_info.value.method_name == "execute_complete"
        # Without native retries configured, the trigger keeps its original parent-unaware behavior.
        assert exec_info.value.trigger.workflow_run_id is None
        assert exec_info.value.trigger.databricks_task_key is None

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_execute_standalone_with_retries_defers_on_submit_run(self, mock_databricks_hook):
        # A standalone operator with native retries follows its own submit run to a terminal state,
        # so the defer targets that run directly (no per-task workflow context).
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "PENDING"},
            "run_page_url": "test_url",
        }
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=True,
            deferrable=True,
            max_retries=2,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(TaskDeferred) as exec_info:
            operator.monitor_databricks_job()
        assert exec_info.value.trigger.run_id == 12345
        assert exec_info.value.trigger.workflow_run_id is None
        assert exec_info.value.trigger.databricks_task_key is None

    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._databricks_workflow_task_group",
        new_callable=mock.PropertyMock,
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_execute_with_deferrable_passes_workflow_context_when_retries_configured(
        self, mock_get_current_task, mock_databricks_hook, mock_workflow_tg
    ):
        # Inside a workflow task group the run is shared, so the defer carries the workflow context
        # and the trigger tracks this task's own attempt within that run.
        mock_workflow_tg.return_value = MagicMock()
        mock_get_current_task.return_value = {"run_id": "attempt-1"}
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "PENDING"},
            "run_page_url": "test_url",
        }
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=True,
            deferrable=True,
            max_retries=2,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(TaskDeferred) as exec_info:
            operator.monitor_databricks_job()
        assert exec_info.value.trigger.workflow_run_id == 12345
        assert exec_info.value.trigger.databricks_task_key == operator.databricks_task_key

    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._databricks_workflow_task_group",
        new_callable=mock.PropertyMock,
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_execute_with_deferrable_and_max_retries_zero_keeps_single_attempt_monitoring(
        self, mock_get_current_task, mock_databricks_hook, mock_workflow_tg
    ):
        mock_workflow_tg.return_value = MagicMock()
        mock_get_current_task.return_value = {"run_id": "attempt-1"}
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "PENDING"},
            "run_page_url": "test_url",
        }
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=True,
            deferrable=True,
            max_retries=0,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(TaskDeferred) as exec_info:
            operator.monitor_databricks_job()
        assert exec_info.value.trigger.run_id == "attempt-1"
        assert exec_info.value.trigger.workflow_run_id is None
        assert exec_info.value.trigger.databricks_task_key is None

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_execute_with_deferrable_early_termination(self, mock_get_current_task, mock_databricks_hook):
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "FAILURE",
            },
            "run_page_url": "test_url",
        }
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            wait_for_termination=True,
            deferrable=True,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException) as exec_info:
            operator.monitor_databricks_job()
        exception_message = "Task failed. Final state FAILED. Reason: FAILURE. Errors: []"
        assert exception_message == str(exec_info.value)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_databricks_job_successful_raises_no_exception(
        self, mock_get_current_task, mock_databricks_hook
    ):
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            "run_page_url": "test_url",
        }

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )

        operator.databricks_run_id = 12345
        operator.monitor_databricks_job()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_databricks_job_failed(self, mock_get_current_task, mock_databricks_hook):
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "TERMINATED", "result_state": "FAILED", "state_message": "FAILURE"},
            "run_page_url": "test_url",
        }

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )

        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException) as exc_info:
            operator.monitor_databricks_job()
        exception_message = "Task failed. Final state FAILED. Reason: FAILURE. Errors: []"
        assert exception_message == str(exc_info.value)

    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._databricks_workflow_task_group",
        new_callable=mock.PropertyMock,
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_databricks_job_retry_in_flight_succeeds(
        self, mock_get_current_task, mock_databricks_hook, mock_sleep, mock_workflow_tg
    ):
        # Inside a workflow task group the run is shared, so the task tracks its own attempt: the
        # first attempt fails while the workflow run is still active; a retried attempt then
        # succeeds and the Airflow task must not fail.
        mock_workflow_tg.return_value = MagicMock()
        mock_get_current_task.side_effect = [{"run_id": "attempt-1"}, {"run_id": "attempt-2"}]
        runs = {
            "attempt-1": {
                "state": {
                    "life_cycle_state": "TERMINATED",
                    "result_state": "FAILED",
                    "state_message": "first attempt failed",
                },
                "run_page_url": "url-1",
            },
            12345: {"state": {"life_cycle_state": "RUNNING"}, "run_page_url": "parent"},
            "attempt-2": {
                "state": {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
                "run_page_url": "url-2",
            },
        }
        mock_databricks_hook.return_value.get_run.side_effect = lambda run_id: runs[run_id]

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            max_retries=1,
        )
        operator.databricks_run_id = 12345

        operator.monitor_databricks_job()
        mock_sleep.assert_called_once()

    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_monitor_standalone_submit_run_follows_run_to_terminal_state(
        self, mock_databricks_hook, mock_sleep
    ):
        # A standalone submit run stays active while Databricks retries the task; the operator
        # follows the run (not an attempt) and reports only once the run itself terminates.
        run_states = iter(
            [
                {"life_cycle_state": "RUNNING"},
                {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            ]
        )
        mock_databricks_hook.return_value.get_run.side_effect = lambda run_id: {
            "state": next(run_states),
            "run_page_url": "url",
        }

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            max_retries=1,
        )
        operator.databricks_run_id = 12345

        operator.monitor_databricks_job()
        # Only the submit run is polled; the per-attempt resolver is never used.
        mock_databricks_hook.return_value.get_run.assert_called_with(12345)
        mock_databricks_hook.return_value.get_run_tasks.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_databricks_job_without_retries_fails_immediately(
        self, mock_get_current_task, mock_databricks_hook, mock_sleep
    ):
        # Without native retries configured the task fails as soon as its own attempt terminates,
        # even if the parent run is still active. The parent run state must not be polled.
        mock_get_current_task.return_value = {"run_id": "attempt-1"}
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "attempt failed",
            },
            "run_page_url": "url",
        }

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )
        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException):
            operator.monitor_databricks_job()
        mock_sleep.assert_not_called()
        # Only the attempt run is polled (once, before the loop); the parent run is never fetched.
        mock_databricks_hook.return_value.get_run.assert_called_once_with("attempt-1")

    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._databricks_workflow_task_group",
        new_callable=mock.PropertyMock,
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_workflow_task_reports_failure_once_retries_exhausted(
        self, mock_get_current_task, mock_databricks_hook, mock_sleep, mock_workflow_tg
    ):
        mock_workflow_tg.return_value = MagicMock()
        mock_get_current_task.return_value = {"run_id": "attempt-2", "attempt_number": 1}
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "final attempt failed",
            },
            "run_page_url": "url",
        }

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            max_retries=1,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException):
            operator.monitor_databricks_job()
        mock_sleep.assert_not_called()
        mock_databricks_hook.return_value.get_run.assert_called_once_with("attempt-2")

    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._databricks_workflow_task_group",
        new_callable=mock.PropertyMock,
    )
    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksNotebookOperator._get_current_databricks_task"
    )
    def test_monitor_workflow_task_unlimited_retries_waits_for_parent(
        self, mock_get_current_task, mock_databricks_hook, mock_sleep, mock_workflow_tg
    ):
        mock_workflow_tg.return_value = MagicMock()
        mock_get_current_task.return_value = {"run_id": "attempt-1", "attempt_number": 5}
        parent_states = iter(
            [
                {"life_cycle_state": "RUNNING"},
                {"life_cycle_state": "TERMINATED", "result_state": "FAILED", "state_message": "failed"},
            ]
        )

        def fake_get_run(run_id):
            if run_id == 12345:
                return {"state": next(parent_states), "run_page_url": "parent"}
            return {
                "state": {
                    "life_cycle_state": "TERMINATED",
                    "result_state": "FAILED",
                    "state_message": "failed",
                },
                "run_page_url": "url",
            }

        mock_databricks_hook.return_value.get_run.side_effect = fake_get_run

        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            max_retries=-1,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException):
            operator.monitor_databricks_job()
        mock_sleep.assert_called_once()
        mock_databricks_hook.return_value.get_run.assert_any_call(12345)

    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_reshaped_submit_run_without_native_retries_resolves_task_for_monitoring(
        self, mock_databricks_hook, mock_sleep
    ):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            min_retry_interval_millis=2000,
        )
        run_json = operator._get_run_json()
        assert "tasks" in run_json
        assert run_json["tasks"][0]["task_key"] == operator.databricks_task_key
        assert operator._resolved_max_retries() is None

        operator.databricks_run_id = 12345
        mock_databricks_hook.return_value.get_run_tasks.return_value = [
            {"task_key": operator.databricks_task_key, "run_id": "attempt-1", "start_time": 1}
        ]
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            "run_page_url": "url",
        }

        operator.monitor_databricks_job()
        mock_databricks_hook.return_value.get_run_tasks.assert_called_once_with(12345)
        mock_databricks_hook.return_value.get_run.assert_called_once_with("attempt-1")

    @pytest.mark.parametrize(
        "operator",
        [
            DatabricksNotebookOperator(
                task_id="test_task",
                notebook_path="test_path",
                source="WORKSPACE",
                databricks_conn_id="test_conn_id",
                existing_cluster_id="existing_cluster_id",
                max_retries="{{ params.max_retries }}",
                min_retry_interval_millis="{{ params.min_retry_interval_millis }}",
                retry_on_timeout="{{ params.retry_on_timeout }}",
            ),
            DatabricksTaskOperator(
                task_id="test_task",
                databricks_conn_id="test_conn_id",
                task_config={},
                max_retries="{{ params.max_retries }}",
                min_retry_interval_millis="{{ params.min_retry_interval_millis }}",
                retry_on_timeout="{{ params.retry_on_timeout }}",
            ),
        ],
    )
    def test_retry_params_render_from_templates(self, operator):
        """Retry fields are templatable: Jinja values render and coerce to typed retry settings.

        Guards the ``template_fields`` membership on both subclasses (which keep separate tuples):
        an un-templated field would keep its literal ``{{ ... }}`` string and fail coercion.
        """
        operator.render_template_fields(
            context={
                "params": {
                    "max_retries": 3,
                    "min_retry_interval_millis": 2000,
                    "retry_on_timeout": "true",
                }
            }
        )
        assert operator._retry_settings() == {
            "max_retries": 3,
            "min_retry_interval_millis": 2000,
            "retry_on_timeout": True,
        }

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_launch_notebook_job(self, mock_databricks_hook):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="test_cluster_id",
        )
        operator._hook.submit_run.return_value = 12345

        run_id = operator._launch_job()

        assert run_id == 12345

    def test_both_new_and_existing_cluster_set(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            new_cluster={"new_cluster_config_key": "new_cluster_config_value"},
            existing_cluster_id="existing_cluster_id",
            databricks_conn_id="test_conn_id",
        )
        with pytest.raises(
            ValueError, match="Both new_cluster and existing_cluster_id are set. Only one should be set."
        ):
            operator._get_run_json()

    def test_both_new_and_existing_cluster_unset(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
        )
        with pytest.raises(ValueError, match="Must specify either existing_cluster_id or new_cluster."):
            operator._get_run_json()

    def test_job_runs_forever_by_default(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
        )
        run_json = operator._get_run_json()
        assert operator.execution_timeout is None
        assert run_json["timeout_seconds"] == 0

    def test_zero_execution_timeout_raises_error(self):
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            execution_timeout=timedelta(seconds=0),
        )
        with pytest.raises(
            ValueError,
            match="If you've set an `execution_timeout` for the task, ensure it's not `0`. "
            "Set it instead to `None` if you desire the task to run indefinitely.",
        ):
            operator._get_run_json()

    def test_extend_workflow_notebook_packages(self):
        """Test that the operator can extend the notebook packages of a Databricks workflow task group."""
        databricks_workflow_task_group = MagicMock()
        databricks_workflow_task_group.notebook_packages = [
            {"pypi": {"package": "numpy"}},
            {"pypi": {"package": "pandas"}},
        ]

        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            notebook_packages=[
                {"pypi": {"package": "numpy"}},
                {"pypi": {"package": "scipy"}},
            ],
        )

        operator._extend_workflow_notebook_packages(databricks_workflow_task_group)

        assert operator.notebook_packages == [
            {"pypi": {"package": "numpy"}},
            {"pypi": {"package": "scipy"}},
            {"pypi": {"package": "pandas"}},
        ]

    def test_convert_to_databricks_workflow_task(self):
        """Test that the operator can convert itself to a Databricks workflow task."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=datetime.now())
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            notebook_packages=[
                {"pypi": {"package": "numpy"}},
                {"pypi": {"package": "scipy"}},
            ],
            dag=dag,
        )

        databricks_workflow_task_group = MagicMock()
        databricks_workflow_task_group.notebook_packages = [
            {"pypi": {"package": "numpy"}},
        ]
        databricks_workflow_task_group.notebook_params = {"param1": "value1"}

        operator.notebook_packages = [{"pypi": {"package": "pandas"}}]
        operator.notebook_params = {"param2": "value2"}
        operator.task_group = databricks_workflow_task_group
        operator.task_id = "test_task"
        operator.upstream_task_ids = ["upstream_task"]
        upstream_task = DatabricksNotebookOperator(
            notebook_path="/path/to/upstream",
            source="WORKSPACE",
            task_id="upstream_task",
            dag=dag,
        )
        relevant_upstreams = ["upstream_task"]
        task_dict = {"upstream_task": upstream_task}

        task_json = operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)

        task_key = hashlib.md5(b"example_dag__test_task").hexdigest()
        upstream_task_key = hashlib.md5(b"example_dag__upstream_task").hexdigest()
        expected_json = {
            "task_key": task_key,
            "depends_on": [{"task_key": upstream_task_key}],
            "timeout_seconds": 0,
            "email_notifications": {},
            "notebook_task": {
                "notebook_path": "/path/to/notebook",
                "source": "WORKSPACE",
                "base_parameters": {
                    "param2": "value2",
                    "param1": "value1",
                },
            },
            "libraries": [
                {"pypi": {"package": "pandas"}},
                {"pypi": {"package": "numpy"}},
            ],
        }

        assert task_json == expected_json

    @pytest.mark.parametrize(
        ("retry_kwargs", "expected"),
        [
            (
                {"max_retries": -1, "min_retry_interval_millis": 2000, "retry_on_timeout": True},
                {"max_retries": -1, "min_retry_interval_millis": 2000, "retry_on_timeout": True},
            ),
            ({"max_retries": 0}, {"max_retries": 0}),
            ({"retry_on_timeout": False}, {"retry_on_timeout": False}),
        ],
    )
    def test_get_run_json_retry_settings(self, retry_kwargs, expected):
        """Retry settings are added to the submitted task only when explicitly provided.

        They must live inside ``tasks[0]`` (a Databricks ``SubmitTask``); at the top level of a
        runs/submit payload Databricks silently ignores them.
        """
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            **retry_kwargs,
        )
        run_json = operator._get_run_json()
        assert "tasks" in run_json
        task = run_json["tasks"][0]
        assert task["task_key"] == operator.databricks_task_key
        assert task["existing_cluster_id"] == "existing_cluster_id"
        assert task["notebook_task"]["notebook_path"] == "test_path"
        assert "existing_cluster_id" not in run_json
        for key in ("max_retries", "min_retry_interval_millis", "retry_on_timeout"):
            assert key not in run_json
            if key in expected:
                assert task[key] == expected[key]
            else:
                assert key not in task

    def test_get_run_json_without_retries_uses_legacy_top_level_shape(self):
        """Without native retries the payload is the legacy single-task runs/submit shape (unchanged)."""
        operator = DatabricksNotebookOperator(
            task_id="test_task",
            notebook_path="test_path",
            source="test_source",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
        )
        run_json = operator._get_run_json()
        assert run_json["run_name"] == operator.databricks_task_key
        assert run_json["existing_cluster_id"] == "existing_cluster_id"
        assert run_json["notebook_task"]["notebook_path"] == "test_path"
        # No reshape into the multi-task form when retries are not configured.
        assert "tasks" not in run_json

    def test_convert_to_databricks_workflow_task_includes_retry_settings(self):
        """Retry settings provided to the operator are included in the workflow task JSON."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=DEFAULT_DATE)
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            max_retries=2,
            min_retry_interval_millis=1000,
            retry_on_timeout=True,
            dag=dag,
        )

        databricks_workflow_task_group = MagicMock()
        databricks_workflow_task_group.notebook_packages = []
        databricks_workflow_task_group.notebook_params = {}

        operator.task_group = databricks_workflow_task_group
        relevant_upstreams = []
        task_dict = {}

        task_json = operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)

        assert task_json["max_retries"] == 2
        assert task_json["min_retry_interval_millis"] == 1000
        assert task_json["retry_on_timeout"] is True

    @pytest.mark.parametrize(
        ("trigger_rule", "expected_run_if"),
        [
            ("all_failed", "ALL_FAILED"),
            ("all_done", "ALL_DONE"),
            ("one_success", "AT_LEAST_ONE_SUCCESS"),
            ("one_failed", "AT_LEAST_ONE_FAILED"),
            ("none_failed", "NONE_FAILED"),
            ("none_failed_min_one_success", "NONE_FAILED"),
            ("always", "ALL_DONE"),
        ],
    )
    def test_convert_to_databricks_workflow_task_with_trigger_rule(self, trigger_rule, expected_run_if):
        """Test that trigger_rule is mapped to Databricks run_if in the workflow task JSON."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=datetime.now())
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            trigger_rule=trigger_rule,
            dag=dag,
        )

        databricks_workflow_task_group = MagicMock()
        databricks_workflow_task_group.notebook_packages = []
        databricks_workflow_task_group.notebook_params = {}

        operator.task_group = databricks_workflow_task_group
        relevant_upstreams = []
        task_dict = {}

        task_json = operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)

        assert task_json["run_if"] == expected_run_if

    def test_convert_to_databricks_workflow_task_default_trigger_rule_no_run_if(self):
        """Test that the default trigger_rule (all_success) does not add run_if to the task JSON."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=datetime.now())
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            dag=dag,
        )

        databricks_workflow_task_group = MagicMock()
        databricks_workflow_task_group.notebook_packages = []
        databricks_workflow_task_group.notebook_params = {}

        operator.task_group = databricks_workflow_task_group
        relevant_upstreams = []
        task_dict = {}

        task_json = operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)

        assert "run_if" not in task_json

    def test_convert_to_databricks_workflow_task_no_task_group(self):
        """Test that an error is raised if the operator is not in a TaskGroup."""
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            notebook_packages=[
                {"pypi": {"package": "numpy"}},
                {"pypi": {"package": "scipy"}},
            ],
        )
        operator.task_group = None
        relevant_upstreams = [MagicMock(task_id="upstream_task")]
        task_dict = {"upstream_task": MagicMock(task_id="upstream_task")}

        with pytest.raises(
            AirflowException,
            match="Calling `_convert_to_databricks_workflow_task` without a parent TaskGroup.",
        ):
            operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)

    def test_convert_to_databricks_workflow_task_cluster_conflict(self):
        """Test that an error is raised if both `existing_cluster_id` and `job_cluster_key` are set."""
        operator = DatabricksNotebookOperator(
            notebook_path="/path/to/notebook",
            source="WORKSPACE",
            task_id="test_task",
            notebook_packages=[
                {"pypi": {"package": "numpy"}},
                {"pypi": {"package": "scipy"}},
            ],
        )
        databricks_workflow_task_group = MagicMock()
        operator.existing_cluster_id = "existing-cluster-id"
        operator.job_cluster_key = "job-cluster-key"
        operator.task_group = databricks_workflow_task_group
        relevant_upstreams = [MagicMock(task_id="upstream_task")]
        task_dict = {"upstream_task": MagicMock(task_id="upstream_task")}

        with pytest.raises(
            ValueError,
            match="Both existing_cluster_id and job_cluster_key are set. Only one can be set per task.",
        ):
            operator._convert_to_databricks_workflow_task(relevant_upstreams, task_dict)


class TestDatabricksTaskOperator:
    def test_is_instance_of_databricks_task_base_operator(self):
        task_config = {
            "sql_task": {
                "query": {
                    "query_id": "c9cf6468-babe-41a6-abc3-10ac358c71ee",
                },
                "warehouse_id": "cf414a2206dfb397",
            }
        }
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config=task_config,
        )

        assert isinstance(operator, DatabricksTaskBaseOperator)

    def test_get_task_base_json(self):
        task_config = {
            "sql_task": {
                "query": {
                    "query_id": "c9cf646-8babe-41a6-abc3-10ac358c71ee",
                },
                "warehouse_id": "cf414a2206dfb397",
            }
        }
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config=task_config,
        )
        task_base_json = operator._get_task_base_json()

        assert operator.task_config == task_config
        assert task_base_json == task_config

    def test_get_run_json_operator_task_key_wins_over_task_config(self):
        """A task_key in task_config must not shadow the operator-managed key used for monitoring.

        The operator only injects its own task_key in the reshaped (native-retry) payload, where
        monitoring re-resolves the task by that key, so the guarantee is exercised with retries set.
        """
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            max_retries=2,
            task_config={"task_key": "user_supplied_key", "notebook_task": {"notebook_path": "/p"}},
        )
        task = operator._get_run_json()["tasks"][0]
        assert task["task_key"] == operator.databricks_task_key

    def test_convert_to_databricks_workflow_task_includes_task_config_retry_settings(self):
        """Retry settings supplied via task_config surface in the workflow task JSON."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=DEFAULT_DATE)
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config={
                "notebook_task": {"notebook_path": "/path"},
                "max_retries": 5,
                "min_retry_interval_millis": 1000,
                "retry_on_timeout": True,
            },
            dag=dag,
        )
        operator.task_group = MagicMock()

        task_json = operator._convert_to_databricks_workflow_task([], {})

        assert task_json["max_retries"] == 5
        assert task_json["min_retry_interval_millis"] == 1000
        assert task_json["retry_on_timeout"] is True

    def test_convert_to_databricks_workflow_task_operator_retry_overrides_task_config(self):
        """An operator-level retry value overrides the task_config value in the workflow task JSON."""
        dag = DAG(dag_id="example_dag", schedule=None, start_date=DEFAULT_DATE)
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config={
                "notebook_task": {"notebook_path": "/path"},
                "max_retries": 5,
                "min_retry_interval_millis": 1000,
                "retry_on_timeout": False,
            },
            max_retries=2,
            min_retry_interval_millis=2000,
            retry_on_timeout=True,
            dag=dag,
        )
        operator.task_group = MagicMock()

        task_json = operator._convert_to_databricks_workflow_task([], {})

        assert task_json["max_retries"] == 2
        assert task_json["min_retry_interval_millis"] == 2000
        assert task_json["retry_on_timeout"] is True

    def test_generate_databricks_task_key(self):
        task_config = {}
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config=task_config,
        )

        task_key = f"{operator.dag_id}__{operator.task_id}".encode()
        expected_task_key = hashlib.md5(task_key).hexdigest()
        assert expected_task_key == operator.databricks_task_key

    def test_generate_databricks_task_key_requires_task_dict_when_task_id_passed(self):
        """Looking up a parent task's key without a ``task_dict`` is a programmer error."""
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            task_config={},
        )
        with pytest.raises(
            ValueError,
            match="Must pass task_dict if task_id is provided in _generate_databricks_task_key.",
        ):
            operator._generate_databricks_task_key(task_id="upstream_task")

    def test_user_databricks_task_key(self):
        task_config = {}
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            databricks_task_key="test_task_key",
            task_config=task_config,
        )
        expected_task_key = "test_task_key"

        assert expected_task_key == operator.databricks_task_key

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill_cancels_run(self, db_mock_class):
        operator = DatabricksTaskOperator(
            task_id="task",
            task_config={"sql_task": {"query": {"query_id": "abc"}}},
        )
        db_mock = db_mock_class.return_value
        operator.databricks_run_id = 1
        operator.on_kill()
        db_mock.cancel_run.assert_called_once_with(1)

    def test_on_kill_does_nothing_when_run_id_is_none(self):
        operator = DatabricksTaskOperator(
            task_id="task",
            task_config={"sql_task": {"query": {"query_id": "abc"}}},
        )
        with mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook") as db_mock_class:
            operator.on_kill()
            db_mock_class.return_value.cancel_run.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill_workflow_member_cancels_child_run(self, db_mock_class):
        operator = DatabricksTaskOperator(
            task_id="task",
            task_config={"sql_task": {"query": {"query_id": "abc"}}},
        )
        db_mock = db_mock_class.return_value
        operator.databricks_run_id = 1
        with mock.patch.object(
            operator,
            "_get_current_databricks_task",
            return_value={"run_id": 999, "task_key": "task"},
        ):
            with mock.patch(
                "airflow.providers.databricks.operators.databricks"
                ".DatabricksTaskBaseOperator._databricks_workflow_task_group",
                new_callable=mock.PropertyMock,
                return_value=object(),
            ):
                operator.on_kill()
        db_mock.cancel_run.assert_called_once_with(999)

    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_on_kill_workflow_member_get_task_raises_does_not_cancel_parent(self, db_mock_class):
        operator = DatabricksTaskOperator(
            task_id="task",
            task_config={"sql_task": {"query": {"query_id": "abc"}}},
        )
        db_mock = db_mock_class.return_value
        operator.databricks_run_id = 1
        with mock.patch.object(
            operator,
            "_get_current_databricks_task",
            side_effect=Exception("API error"),
        ):
            with mock.patch(
                "airflow.providers.databricks.operators.databricks"
                ".DatabricksTaskBaseOperator._databricks_workflow_task_group",
                new_callable=mock.PropertyMock,
                return_value=object(),
            ):
                operator.on_kill()
        db_mock.cancel_run.assert_not_called()

    @pytest.mark.parametrize(
        ("field", "task_config_retries", "retry_kwargs", "expected"),
        [
            ("max_retries", {"max_retries": 1}, {}, 1),
            ("max_retries", {"max_retries": 1}, {"max_retries": 0}, 0),
            (
                "min_retry_interval_millis",
                {"min_retry_interval_millis": 1000},
                {"min_retry_interval_millis": 5000},
                5000,
            ),
            ("retry_on_timeout", {"retry_on_timeout": True}, {"retry_on_timeout": False}, False),
        ],
    )
    def test_get_run_json_retry_settings(self, field, task_config_retries, retry_kwargs, expected):
        """Operator-level retry settings are applied and take precedence over task_config values."""
        task_config = {
            "notebook_task": {"notebook_path": "/path", "source": "WORKSPACE", "base_parameters": {}},
            **task_config_retries,
        }
        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            task_config=task_config,
            **retry_kwargs,
        )
        run_json = operator._get_run_json()
        assert run_json["tasks"][0][field] == expected
        assert field not in run_json

    @pytest.mark.parametrize("max_retries", [2, "2"])
    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_monitor_uses_retry_strategy_when_retries_set_in_task_config(
        self, mock_databricks_hook, mock_sleep, max_retries
    ):
        # max_retries supplied only through task_config must still select retry-aware monitoring
        # (follow the submit run), not the single-attempt path.
        run_states = iter(
            [
                {"life_cycle_state": "RUNNING"},
                {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            ]
        )
        mock_databricks_hook.return_value.get_run.side_effect = lambda run_id: {
            "state": next(run_states),
            "run_page_url": "url",
        }

        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            task_config={
                "notebook_task": {"notebook_path": "/path", "source": "WORKSPACE", "base_parameters": {}},
                "max_retries": max_retries,
            },
        )
        operator.databricks_run_id = 12345

        operator.monitor_databricks_job()
        mock_databricks_hook.return_value.get_run.assert_called_with(12345)
        mock_databricks_hook.return_value.get_run_tasks.assert_not_called()

    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    @mock.patch(
        "airflow.providers.databricks.operators.databricks.DatabricksTaskOperator._get_current_databricks_task"
    )
    def test_monitor_max_retries_zero_operator_arg_overrides_task_config_retries(
        self, mock_get_current_task, mock_databricks_hook, mock_sleep
    ):
        mock_get_current_task.return_value = {"run_id": "attempt-1"}
        mock_databricks_hook.return_value.get_run.return_value = {
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "attempt failed",
            },
            "run_page_url": "url",
        }

        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            task_config={
                "notebook_task": {"notebook_path": "/path", "source": "WORKSPACE", "base_parameters": {}},
                "max_retries": 2,
            },
            max_retries=0,
        )
        operator.databricks_run_id = 12345

        with pytest.raises(AirflowException):
            operator.monitor_databricks_job()
        mock_sleep.assert_not_called()
        mock_databricks_hook.return_value.get_run.assert_called_once_with("attempt-1")

    @mock.patch("airflow.providers.databricks.operators.databricks.time.sleep")
    @mock.patch("airflow.providers.databricks.operators.databricks.DatabricksHook")
    def test_monitor_waits_out_waiting_for_retry_state(self, mock_databricks_hook, mock_sleep):
        # A native retry surfaces WAITING_FOR_RETRY between attempts; the poll must keep waiting
        # rather than crash on an unexpected life cycle state.
        run_states = iter(
            [
                {"life_cycle_state": "RUNNING"},
                {"life_cycle_state": "WAITING_FOR_RETRY"},
                {"life_cycle_state": "TERMINATED", "result_state": "SUCCESS"},
            ]
        )
        mock_databricks_hook.return_value.get_run.side_effect = lambda run_id: {
            "state": next(run_states),
            "run_page_url": "url",
        }

        operator = DatabricksTaskOperator(
            task_id="test_task",
            databricks_conn_id="test_conn_id",
            existing_cluster_id="existing_cluster_id",
            task_config={
                "notebook_task": {"notebook_path": "/path", "source": "WORKSPACE", "base_parameters": {}},
                "max_retries": 2,
            },
        )
        operator.databricks_run_id = 12345

        operator.monitor_databricks_job()
        assert mock_databricks_hook.return_value.get_run.call_count == 3


class TestWarnAndDisableDurableAirflowPre3_3:
    def test_no_warning_when_unset(self):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = _warn_and_disable_durable_pre_3_3(_DURABLE_UNSET)
        assert result is False
        assert caught == []

    @pytest.mark.parametrize("value", [True, False])
    def test_warns_and_disables_when_explicitly_set(self, value):
        with pytest.warns(UserWarning, match="durable.*no effect"):
            result = _warn_and_disable_durable_pre_3_3(value)
        assert result is False
