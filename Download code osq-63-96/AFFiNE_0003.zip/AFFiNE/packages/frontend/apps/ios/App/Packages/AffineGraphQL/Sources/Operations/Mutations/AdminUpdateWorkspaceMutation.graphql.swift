// @generated
// This file was automatically generated and should not be edited.

@_exported import ApolloAPI

public class AdminUpdateWorkspaceMutation: GraphQLMutation {
  public static let operationName: String = "adminUpdateWorkspace"
  public static let operationDocument: ApolloAPI.OperationDocument = .init(
    definition: .init(
      #"mutation adminUpdateWorkspace($input: AdminUpdateWorkspaceInput!) { adminUpdateWorkspace(input: $input) { __typename id public createdAt name avatarKey enableAi enableSharing enableUrlPreview enableDocEmbedding owner { __typename id name email avatarUrl } memberCount publicPageCount snapshotCount snapshotSize blobCount blobSize } }"#
    ))

  public var input: AdminUpdateWorkspaceInput

  public init(input: AdminUpdateWorkspaceInput) {
    self.input = input
  }

  public var __variables: Variables? { ["input": input] }

  public struct Data: AffineGraphQL.SelectionSet {
    public let __data: DataDict
    public init(_dataDict: DataDict) { __data = _dataDict }

    public static var __parentType: any ApolloAPI.ParentType { AffineGraphQL.Objects.Mutation }
    public static var __selections: [ApolloAPI.Selection] { [
      .field("adminUpdateWorkspace", AdminUpdateWorkspace?.self, arguments: ["input": .variable("input")]),
    ] }
    public static var __fulfilledFragments: [any ApolloAPI.SelectionSet.Type] { [
      AdminUpdateWorkspaceMutation.Data.self
    ] }

    /// Update workspace flags for admin
    public var adminUpdateWorkspace: AdminUpdateWorkspace? { __data["adminUpdateWorkspace"] }

    /// AdminUpdateWorkspace
    ///
    /// Parent Type: `AdminWorkspace`
    public struct AdminUpdateWorkspace: AffineGraphQL.SelectionSet {
      public let __data: DataDict
      public init(_dataDict: DataDict) { __data = _dataDict }

      public static var __parentType: any ApolloAPI.ParentType { AffineGraphQL.Objects.AdminWorkspace }
      public static var __selections: [ApolloAPI.Selection] { [
        .field("__typename", String.self),
        .field("id", String.self),
        .field("public", Bool.self),
        .field("createdAt", AffineGraphQL.DateTime.self),
        .field("name", String?.self),
        .field("avatarKey", String?.self),
        .field("enableAi", Bool.self),
        .field("enableSharing", Bool.self),
        .field("enableUrlPreview", Bool.self),
        .field("enableDocEmbedding", Bool.self),
        .field("owner", Owner?.self),
        .field("memberCount", Int.self),
        .field("publicPageCount", Int.self),
        .field("snapshotCount", Int.self),
        .field("snapshotSize", AffineGraphQL.SafeInt.self),
        .field("blobCount", Int.self),
        .field("blobSize", AffineGraphQL.SafeInt.self),
      ] }
      public static var __fulfilledFragments: [any ApolloAPI.SelectionSet.Type] { [
        AdminUpdateWorkspaceMutation.Data.AdminUpdateWorkspace.self
      ] }

      public var id: String { __data["id"] }
      public var `public`: Bool { __data["public"] }
      public var createdAt: AffineGraphQL.DateTime { __data["createdAt"] }
      public var name: String? { __data["name"] }
      public var avatarKey: String? { __data["avatarKey"] }
      public var enableAi: Bool { __data["enableAi"] }
      public var enableSharing: Bool { __data["enableSharing"] }
      public var enableUrlPreview: Bool { __data["enableUrlPreview"] }
      public var enableDocEmbedding: Bool { __data["enableDocEmbedding"] }
      public var owner: Owner? { __data["owner"] }
      public var memberCount: Int { __data["memberCount"] }
      public var publicPageCount: Int { __data["publicPageCount"] }
      public var snapshotCount: Int { __data["snapshotCount"] }
      public var snapshotSize: AffineGraphQL.SafeInt { __data["snapshotSize"] }
      public var blobCount: Int { __data["blobCount"] }
      public var blobSize: AffineGraphQL.SafeInt { __data["blobSize"] }

      /// AdminUpdateWorkspace.Owner
      ///
      /// Parent Type: `WorkspaceUserType`
      public struct Owner: AffineGraphQL.SelectionSet {
        public let __data: DataDict
        public init(_dataDict: DataDict) { __data = _dataDict }

        public static var __parentType: any ApolloAPI.ParentType { AffineGraphQL.Objects.WorkspaceUserType }
        public static var __selections: [ApolloAPI.Selection] { [
          .field("__typename", String.self),
          .field("id", String.self),
          .field("name", String.self),
          .field("email", String.self),
          .field("avatarUrl", String?.self),
        ] }
        public static var __fulfilledFragments: [any ApolloAPI.SelectionSet.Type] { [
          AdminUpdateWorkspaceMutation.Data.AdminUpdateWorkspace.Owner.self
        ] }

        public var id: String { __data["id"] }
        public var name: String { __data["name"] }
        public var email: String { __data["email"] }
        public var avatarUrl: String? { __data["avatarUrl"] }
      }
    }
  }
}
