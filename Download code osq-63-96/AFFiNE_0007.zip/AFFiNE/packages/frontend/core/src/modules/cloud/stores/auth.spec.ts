import { AuthProvider } from '@affine/core/modules/cloud/provider/auth';
import { FetchService } from '@affine/core/modules/cloud/services/fetch';
import { GraphQLService } from '@affine/core/modules/cloud/services/graphql';
import { ServerService } from '@affine/core/modules/cloud/services/server';
import { AuthStore } from '@affine/core/modules/cloud/stores/auth';
import { GlobalState, NbstoreService } from '@affine/core/modules/storage';
import { Framework } from '@toeverything/infra';
import { describe, expect, test, vi } from 'vitest';

function createStore({
  fetch,
  gql = vi.fn(),
}: {
  fetch: (input: string, init?: RequestInit) => Promise<Response>;
  gql?: () => Promise<unknown>;
}) {
  const framework = new Framework();
  framework.service(FetchService, { fetch } as any);
  framework.service(GraphQLService, { gql } as any);
  framework.impl(GlobalState, {} as any);
  framework.service(ServerService, {
    server: {
      id: 'test-server',
      ['config$']: { value: { version: '0.27.0' } },
    },
  } as any);
  framework.impl(AuthProvider, {} as any);
  framework.service(NbstoreService, {
    realtime: {},
  } as any);
  framework.store(AuthStore, [
    FetchService,
    GraphQLService,
    GlobalState,
    ServerService,
    AuthProvider,
    NbstoreService,
  ]);
  return framework.provider().get(AuthStore);
}

describe('AuthStore', () => {
  test('validates login preflight responses', async () => {
    const validResponse = {
      registered: true,
      methods: {
        password: { available: true },
        magicLink: { available: true },
        oauth: { available: false, providers: [] },
        passkey: { available: false, discoverable: false },
      },
    };
    const fetch = vi
      .fn()
      .mockResolvedValueOnce({ ok: true, json: async () => validResponse })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => ({ registered: true, methods: {} }),
      });
    const store = createStore({ fetch });

    await expect(store.checkUserByEmail('user@affine.pro')).resolves.toEqual(
      validResponse
    );
    await expect(
      store.checkUserByEmail('user@affine.pro')
    ).rejects.toMatchObject({
      name: 'UNSUPPORTED_SERVER_VERSION',
      data: { serverVersion: '0.27.0' },
    });
  });

  test('loads account profile from scoped GraphQL after auth session bootstrap', async () => {
    const authMethods = {
      password: { bound: true },
      oauth: { bound: false, providers: [] },
      passkey: { bound: false, count: 0 },
    };
    const fetch = vi.fn(async (input: string) => {
      if (input === '/api/auth/session') {
        return {
          json: async () => ({ user: { id: 'u1' } }),
        } as Response;
      }
      if (input === '/api/auth/methods') {
        return {
          ok: true,
          json: async () => authMethods,
        } as Response;
      }
      throw new Error(`Unexpected request: ${input}`);
    });
    const gql = vi.fn(async () => ({
      currentUser: {
        id: 'u1',
        email: 'u1@affine.pro',
        name: 'User',
        emailVerified: true,
        hasPassword: true,
        avatarUrl: null,
        features: ['Admin'],
      },
    }));
    const store = createStore({ fetch, gql });

    await expect(store.fetchSession()).resolves.toEqual({
      user: {
        id: 'u1',
        email: 'u1@affine.pro',
        name: 'User',
        emailVerified: true,
        hasPassword: true,
        avatarUrl: null,
        features: ['Admin'],
        authMethods,
      },
    });
    expect(gql).toHaveBeenCalledOnce();
  });

  test('rejects mismatched GraphQL profile and auth session', async () => {
    const fetch = vi.fn(async () => {
      return {
        json: async () => ({ user: { id: 'u1' } }),
      } as Response;
    });
    const gql = vi.fn(async () => ({
      currentUser: {
        id: 'u2',
        email: 'u2@affine.pro',
        name: 'User',
        emailVerified: true,
        hasPassword: true,
        avatarUrl: null,
        features: [],
      },
    }));
    const store = createStore({ fetch, gql });

    await expect(store.fetchSession()).rejects.toThrow(
      'User profile does not match auth session'
    );
  });
});
