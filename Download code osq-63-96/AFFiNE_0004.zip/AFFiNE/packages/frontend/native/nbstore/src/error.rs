use affine_doc_loader::ParseError;

pub type Result<T> = std::result::Result<T, Error>;

#[derive(Debug, thiserror::Error)]
pub enum Error {
  #[error("Sqlite Error: {0}")]
  SqlxError(#[from] sqlx::Error),
  #[error("Migrate Error: {0}")]
  MigrateError(#[from] sqlx::migrate::MigrateError),
  #[error("Connection in progress")]
  ConnectionInProgress,
  #[error("Invalid operation")]
  InvalidOperation,
  #[error("Index is rebuilding")]
  IndexNotReady,
  #[error("Serialization Error: {0}")]
  Serialization(String),
  #[error(transparent)]
  Indexer(#[from] memory_indexer::Error),
  #[error(transparent)]
  Parse(#[from] ParseError),
}
