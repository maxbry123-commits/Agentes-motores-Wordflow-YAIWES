import type { Authenticator } from "remix-auth";
import { GitHubStrategy } from "remix-auth-github";
import { env } from "~/env.server";
import { findOrCreateUser } from "~/models/user.server";
import type { AuthUser } from "./authUser";
import { logger } from "./logger.server";
import { postAuthentication } from "./postAuth.server";
import { SsoRequiredError, ssoRedirectForEmail } from "./ssoAutoDiscovery.server";

export function addGitHubStrategy(
  authenticator: Authenticator<AuthUser>,
  clientID: string,
  clientSecret: string
) {
  const gitHubStrategy = new GitHubStrategy(
    {
      clientID,
      clientSecret,
      callbackURL: `${env.LOGIN_ORIGIN}/auth/github/callback`,
    },
    async ({ extraParams, profile }) => {
      const emails = profile.emails;

      if (!emails?.length) {
        throw new Error("GitHub login requires an email address");
      }

      const email = emails[0].value;

      // SSO auto-discovery gate — BEFORE findOrCreateUser, so an
      // SSO-enforced domain never gets this GitHub identity linked onto
      // an existing account.
      const ssoRedirect = await ssoRedirectForEmail(email, "oauth_blocked");
      if (ssoRedirect) {
        throw new SsoRequiredError(ssoRedirect);
      }

      try {
        logger.debug("GitHub login", {
          emails,
          profile,
          extraParams,
        });

        const { user, isNewUser } = await findOrCreateUser({
          email,
          authenticationMethod: "GITHUB",
          authenticationProfile: profile,
          authenticationExtraParams: extraParams,
        });

        await postAuthentication({ user, isNewUser, loginMethod: "GITHUB" });

        return {
          userId: user.id,
        };
      } catch (error) {
        logger.error("GitHub login failed", { error: JSON.stringify(error) });
        throw error;
      }
    }
  );

  authenticator.use(gitHubStrategy);
}
