import { createCookie } from "@remix-run/node";
import { env } from "~/env.server";

export type LastAuthMethod = "github" | "google" | "email" | "sso";

// Cookie that persists for 1 year to remember the user's last login method
const lastAuthMethodCookie = createCookie("last-auth-method", {
  maxAge: 60 * 60 * 24 * 365, // 1 year
  httpOnly: true,
  sameSite: "lax",
  secure: env.NODE_ENV === "production",
});

export async function getLastAuthMethod(request: Request): Promise<LastAuthMethod | null> {
  const cookie = request.headers.get("Cookie");
  const value = await lastAuthMethodCookie.parse(cookie);
  if (value === "github" || value === "google" || value === "email" || value === "sso") {
    return value;
  }
  return null;
}

export async function setLastAuthMethodHeader(method: LastAuthMethod): Promise<string> {
  return lastAuthMethodCookie.serialize(method);
}
