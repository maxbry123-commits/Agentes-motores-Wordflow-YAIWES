(ns frontend.extensions.zotero
  (:require [clojure.edn :refer [read-string]]
            [clojure.string :as string]
            [frontend.context.i18n :refer [t]]
            [frontend.extensions.pdf.assets :as pdf-assets]
            [frontend.rfx :as rfx]
            [frontend.state :as state]
            [frontend.storage :as storage]
            [frontend.ui :as ui]
            [frontend.util :as util]
            [io.factorhouse.hsx.core :as hsx]))

(defn open-button [full-path]
  (if (string/ends-with? (string/lower-case full-path) "pdf")
    (ui/button
     (t :ui/open)
     :small? true
     :on-click
     (fn [e]
       (when-let [current (pdf-assets/inflate-asset full-path)]
         (util/stop e)
         (state/set-state! :pdf/current current))))
    (ui/button
     (t :ui/open)
     :small? true
     :target "_blank"
     :href full-path)))

(defn use-zotero-config
  []
  (:zotero/settings-v2
   (state/config-for-repo (rfx/use-sub [:config])
                          (state/get-current-repo))))

(def default-settings
  {:type                                    :user
   :prefer-citekey?                         true
   :include-attachments?                    true
   :include-notes?                          true
   :overwrite-mode?                         false
   :zotero-data-directory                   ""
   :zotero-linked-attachment-base-directory ""
   :extra-tags                              ""
   :page-insert-prefix                      "@"})

(defn default-setting
  [k]
  (case k
    :attachments-block-text (t :zotero/attachments)
    :notes-block-text (t :zotero/notes)
    (get default-settings k)))

(defn all-profiles [config]
  (let [profiles (-> config keys set)
        default #{"default"}]
    (if (empty? profiles) default profiles)))

(defn get-profile [config]
  (let [profile (storage/get :zotero/setting-profile)]
    (if (and profile (contains? (all-profiles config) profile))
      profile
      (first (all-profiles config)))))

(defn setting [config k]
  (let [profile (get-profile config)]
    (-> config
        (get profile)
        (get k (default-setting k)))))

(defn zotero-full-path
  [config item-key filename]
  (str "file://"
       (util/node-path.join
        (setting config :zotero-data-directory)
        "storage"
        item-key
        filename)))

(hsx/defc zotero-imported-file
  [item-key filename]
  (let [config (use-zotero-config)
        data-directory (setting config :zotero-data-directory)]
    (if (string/blank? data-directory)
      [:p.warning (t :zotero/imported-file-warning)]
      (let [filename (read-string filename)
            full-path (zotero-full-path config item-key filename)]
        (open-button full-path)))))

(hsx/defc zotero-linked-file
  [path]
  (let [config (use-zotero-config)
        attachment-directory (setting config :zotero-linked-attachment-base-directory)]
    (if (string/blank? attachment-directory)
      [:p.warning (t :zotero/linked-file-warning)]
      (let [path (read-string path)
            full-path
            (str "file://"
                 (util/node-path.join
                  attachment-directory
                  (string/replace-first path "attachments:" "")))]
        (open-button full-path)))))
