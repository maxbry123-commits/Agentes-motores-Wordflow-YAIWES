(ns frontend.worker.sync.handle-message
  "WebSocket message handlers for db sync."
  (:require [frontend.worker.shared-service :as shared-service]
            [frontend.worker.state :as worker-state]
            [frontend.worker.sync.apply-txs :as sync-apply]
            [frontend.worker.sync.assets :as sync-assets]
            [frontend.worker.sync.auth :as sync-auth]
            [frontend.worker.sync.client-op :as client-op]
            [frontend.worker.sync.crypt :as sync-crypt]
            [frontend.worker.sync.log-and-state :as sync-log-state]
            [frontend.worker.sync.presence :as sync-presence]
            [frontend.worker.sync.transport :as sync-transport]
            [frontend.worker.sync.util :as sync-util]
            [lambdaisland.glogi :as log]
            [promesa.core :as p]
            [frontend.worker-common.util :as worker-util]))

(defn- fail-fast
  [tag data]
  (log/error tag data)
  (throw (ex-info (name tag) data)))

(defn- sync-counts
  [repo]
  (sync-presence/sync-counts
   {:get-datascript-conn worker-state/get-datascript-conn
    :get-client-ops-conn worker-state/get-client-ops-conn
    :get-pending-local-tx-count client-op/get-pending-local-tx-count
    :get-unpushed-asset-ops-count client-op/get-unpushed-asset-ops-count
    :get-missing-asset-upload-files sync-assets/get-missing-asset-upload-files
    :get-local-tx client-op/get-local-tx
    :get-local-checksum client-op/get-local-checksum
    :get-graph-uuid client-op/get-graph-uuid
    :latest-remote-tx @sync-apply/*repo->latest-remote-tx
    :latest-remote-checksum @sync-apply/*repo->latest-remote-checksum}
   repo))

(defn- broadcast-rtc-state!
  [client]
  (when client
    (shared-service/broadcast-to-clients!
     :rtc-sync-state
     (sync-presence/rtc-state-payload sync-counts client))))

(defn- update-online-users!
  [client users]
  (sync-presence/update-online-users! broadcast-rtc-state! client users))

(defn- update-user-presence!
  [client user-id* editing-block-uuid]
  (sync-presence/update-user-presence! broadcast-rtc-state! client user-id* editing-block-uuid))

(defn- get-user-uuid
  []
  (sync-auth/get-user-uuid (worker-state/get-id-token)))

(defn- send!
  [ws message]
  (sync-transport/send! sync-transport/coerce-ws-client-message ws message))

(defn- ws-open?
  [ws]
  (sync-transport/ws-open? ws))

(defn- enqueue-asset-task!
  [client task]
  (when-let [queue (:asset-queue client)]
    (swap! queue
           (fn [prev]
             (p/then prev (fn [_] (task)))))))

(defn- enqueue-send-task!
  [client task]
  (if-let [queue (:send-queue client)]
    (swap! queue
           (fn [prev]
             (-> (or prev (p/resolved nil))
                 (p/catch (fn [_] nil))
                 (p/then (fn [_] (task)))
                 (p/catch (fn [error]
                            (log/error :db-sync/send-queue-task-failed
                                       {:repo (:repo client)
                                        :error error}))))))
    (task)))

(defn- current-client
  [repo]
  (sync-presence/current-client worker-state/*db-sync-client repo))

(defn- require-number
  [value context]
  (when-not (number? value)
    (fail-fast :db-sync/invalid-field (assoc context :value value))))

(defn- require-non-negative
  [value context]
  (require-number value context)
  (when (neg? value)
    (fail-fast :db-sync/invalid-field (assoc context :value value))))

(defn- require-seq
  [value context]
  (when-not (sequential? value)
    (fail-fast :db-sync/invalid-field (assoc context :value value))))

(defn- require-uuid
  [value context]
  (when-not (uuid? value)
    (fail-fast :db-sync/invalid-field (assoc context :value value))))

(defn- parse-transit
  [value context]
  (sync-transport/parse-transit fail-fast value context))

(defn- request-pull!
  [client since]
  (when (and (:ws client) (ws-open? (:ws client)))
    (enqueue-send-task!
     client
     (fn []
       (when (and (:ws client) (ws-open? (:ws client)))
         (if-let [*pending (:pending-pull-since client)]
           (let [pending @*pending]
             (when (or (nil? pending) (< since pending))
               (reset! *pending since)
               (send! (:ws client) {:type "pull" :since since})))
           (send! (:ws client) {:type "pull" :since since})))))))

(defn- clear-pending-pull!
  [client]
  (when-let [*pending (:pending-pull-since client)]
    (reset! *pending nil)))

(defn- pending-local-tx?
  [repo]
  (pos? (or (client-op/get-pending-local-tx-count repo) 0)))

(defn- synced-checksum-ready?
  [repo client local-t remote-t]
  (and (= local-t remote-t)
       (not (pending-local-tx? repo))
       (empty? @(:inflight client))))

(defn- checksum-compare-ready?
  [repo client local-t remote-t]
  (and (synced-checksum-ready? repo client local-t remote-t)
       (string? (client-op/get-local-checksum repo))))

(defn- verify-sync-checksum!
  [repo client local-tx remote-tx remote-checksum context]
  (when worker-util/dev-or-test?
    (when (and (string? remote-checksum)
               (checksum-compare-ready? repo client local-tx remote-tx))
      (let [local-checksum (client-op/get-local-checksum repo)]
        (when-not (= local-checksum remote-checksum)
          (let [mismatch-data (merge context
                                     {:type :db-sync/checksum-mismatch
                                      :repo repo
                                      :message-type (:type context)
                                      :local-tx local-tx
                                      :remote-tx remote-tx
                                      :local-checksum local-checksum
                                      :remote-checksum remote-checksum})]
            (sync-log-state/rtc-log :rtc.log/checksum-mismatch mismatch-data)
            (log/warn :db-sync/checksum-mismatch mismatch-data)))))))

(defn- handle-tx-reject!
  [repo client message local-tx]
  (sync-apply/clear-upload-response-timeout! client)
  (let [reason (:reason message)
        remote-tx (:t message)
        success-tx-ids (:success-tx-ids message)
        failed-tx-id (:failed-tx-id message)
        missing-block-uuids (:missing-block-uuids message)]
    (when (nil? reason)
      (fail-fast :db-sync/missing-field
                 {:repo repo :type "tx/reject" :field :reason}))
    (when (contains? message :t)
      (require-non-negative remote-tx {:repo repo :type "tx/reject"}))
    (when (contains? message :success-tx-ids)
      (require-seq success-tx-ids {:repo repo :type "tx/reject" :field :success-tx-ids})
      (doseq [tx-id success-tx-ids]
        (require-uuid tx-id {:repo repo :type "tx/reject" :field :success-tx-ids})))
    (when (contains? message :failed-tx-id)
      (require-uuid failed-tx-id {:repo repo :type "tx/reject" :field :failed-tx-id}))
    (when (contains? message :missing-block-uuids)
      (require-seq missing-block-uuids {:repo repo :type "tx/reject" :field :missing-block-uuids})
      (doseq [block-uuid missing-block-uuids]
        (require-uuid block-uuid {:repo repo :type "tx/reject" :field :missing-block-uuids})))
    (case reason
      "stale"
      (request-pull! client local-tx)

      (let [inflight @(:inflight client)
            inflight-set (set inflight)
            successful-tx-ids (->> (or success-tx-ids [])
                                   (filter inflight-set)
                                   vec)
            failed-tx-id (when (and failed-tx-id (contains? inflight-set failed-tx-id))
                           failed-tx-id)
            data (when-let [raw-data (:data message)]
                   (parse-transit raw-data
                                  {:repo repo
                                   :type "tx/reject"
                                   :reason reason
                                   :field :data}))
            rejected-data (cond-> {:type :db-sync/tx-rejected
                                   :repo repo
                                   :message-type "tx/reject"
                                   :reason reason}
                            (contains? message :t) (assoc :t remote-tx)
                            (seq successful-tx-ids) (assoc :success-tx-ids successful-tx-ids)
                            (some? failed-tx-id) (assoc :failed-tx-id failed-tx-id)
                            (seq missing-block-uuids) (assoc :missing-block-uuids (vec missing-block-uuids))
                            (some? data) (assoc :data data))]
        (if (or (contains? message :success-tx-ids)
                (contains? message :failed-tx-id))
          (do
            (sync-apply/mark-pending-txs-false! repo successful-tx-ids)
            (when failed-tx-id
              (sync-apply/rollback-and-mark-failed-txs! repo [failed-tx-id])))
          ;; Backward compatibility for older servers without per-tx reject metadata.
          (sync-apply/rollback-and-mark-failed-txs! repo inflight))
        (reset! (:inflight client) [])
        (broadcast-rtc-state! client)
        (sync-log-state/rtc-log :rtc.log/tx-rejected rejected-data)
        (fail-fast :db-sync/tx-rejected
                   rejected-data)))))

(defn- handle-hello!
  [repo client local-tx remote-tx remote-checksum]
  (require-non-negative remote-tx {:repo repo :type "hello"})
  (verify-sync-checksum! repo client local-tx remote-tx remote-checksum {:type "hello"})
  (broadcast-rtc-state! client)
  (when (> remote-tx local-tx)
    (request-pull! client local-tx))
  (sync-assets/enqueue-asset-sync!
   repo client
   {:enqueue-asset-task-f enqueue-asset-task!
    :current-client-f current-client
    :broadcast-rtc-state!-f broadcast-rtc-state!
    :fail-fast-f fail-fast})
  (log/info :db-sync/handle-hello
            {:empty-inflight? (empty? @(:inflight client))
             :online? (worker-state/online?)
             :ws-open? (when-let [ws (:ws client)]
                         (ws-open? ws))
             :pending-txs-count (count (sync-apply/pending-txs repo {:limit 50}))})
  (sync-apply/enqueue-flush-pending! repo client))

(defn- handle-online-users!
  [repo client message]
  (let [users (:online-users message)]
    (when (and (some? users) (not (sequential? users)))
      (fail-fast :db-sync/invalid-field
                 {:repo repo :type "online-users" :field :online-users}))
    (update-online-users! client (or users []))))

(defn- handle-presence!
  [client message]
  (let [{:keys [user-id editing-block-uuid]} message]
    (when-not (= (get-user-uuid) user-id)
      (update-user-presence! client user-id editing-block-uuid))))

(defn- handle-tx-batch-ok!
  [repo client remote-tx remote-checksum]
  (require-non-negative remote-tx {:repo repo :type "tx/batch/ok"})
  (sync-apply/ack-upload-response! repo client)
  (let [current-local-tx (client-op/get-local-tx repo)
        next-local-tx (max current-local-tx remote-tx)]
    (client-op/update-local-tx repo next-local-tx)
    (sync-util/clear-last-sync-error! client)
    (sync-apply/mark-pending-txs-false! repo @(:inflight client))
    (reset! (:inflight client) [])
    (broadcast-rtc-state! client)
    (verify-sync-checksum! repo client next-local-tx remote-tx remote-checksum {:type "tx/batch/ok"})
    (sync-apply/enqueue-flush-pending! repo client)))

(defn- update-latest-remote-state!
  [repo message]
  (let [message-type (:type message)
        remote-tx (:t message)
        remote-checksum (:checksum message)
        has-checksum? (contains? message :checksum)
        latest-remote-tx (get @sync-apply/*repo->latest-remote-tx repo)
        authoritative? (contains? #{"hello" "changed"} message-type)
        stale-remote-tx? (and (number? remote-tx)
                              (number? latest-remote-tx)
                              (< remote-tx latest-remote-tx)
                              (not authoritative?))]
    (when (number? remote-tx)
      (if authoritative?
        (swap! sync-apply/*repo->latest-remote-tx assoc repo remote-tx)
        (swap! sync-apply/*repo->latest-remote-tx
               update repo
               (fn [prev]
                 (if (number? prev)
                   (max prev remote-tx)
                   remote-tx)))))
    (when (and has-checksum? (not stale-remote-tx?))
      (swap! sync-apply/*repo->latest-remote-checksum assoc repo remote-checksum))
    {:stale-remote-tx? stale-remote-tx?
     :latest-remote-tx-before latest-remote-tx}))

(declare handle-pull-ok! handle-changed!)

(defn- validate-local-tx!
  [repo message local-tx]
  (let [message-type (:type message)]
    (when (contains? #{"hello" "tx/batch/ok" "pull/ok" "changed" "tx/reject"} message-type)
      (let [validate? (and (integer? local-tx) (>= local-tx 0))]
       (when-not validate?
         (throw (ex-info "Invalid local tx"
                         {:repo repo
                          :message-type message-type
                          :local-tx local-tx})))))))
(defn handle-message!
  [repo client raw]
  (let [message (-> raw
                    sync-transport/parse-message
                    sync-transport/coerce-ws-server-message)]
    (when-not (map? message)
      (fail-fast :db-sync/response-parse-failed {:repo repo :raw raw}))
    (let [local-tx (client-op/get-local-tx repo)
          remote-tx (:t message)
          remote-checksum (:checksum message)]
      (validate-local-tx! repo message local-tx)
      (update-latest-remote-state! repo message)
      (case (:type message)
        "hello" (handle-hello! repo client local-tx remote-tx remote-checksum)
        "online-users" (handle-online-users! repo client message)
        "presence" (handle-presence! client message)
        "tx/batch/ok" (handle-tx-batch-ok! repo client remote-tx remote-checksum)
        "pull/ok" (handle-pull-ok! repo client local-tx remote-tx remote-checksum message)
        "changed" (handle-changed! repo client local-tx remote-tx)
        "tx/reject" (handle-tx-reject! repo client message local-tx)
        "pong" nil
        (fail-fast :db-sync/invalid-field
                   {:repo repo :type (:type message)})))))

(defn- handle-pull-ok!
  [repo client local-tx remote-tx remote-checksum message]
  (clear-pending-pull! client)
  ;; (log/info ::handle-pull-ok! {:repo repo
  ;;                              :remote-tx remote-tx
  ;;                              :local-tx local-tx})
  (when (> remote-tx local-tx)
    (let [txs (:txs message)]
      (require-non-negative remote-tx {:repo repo :type "pull/ok"})
      (require-seq txs {:repo repo :type "pull/ok" :field :txs})
      (let [remote-txs (mapv (fn [data]
                               {:t (:t data)
                                :outliner-op (:outliner-op data)
                                :tx-data (parse-transit (:tx data) {:repo repo :type "pull/ok"})})
                             txs)]
        ;; (log/info ::handle-pull-remote-txs-count {:count (count remote-txs)})
        (when (seq remote-txs)
          (->
           (p/let [graph-e2ee? (sync-crypt/graph-e2ee? repo)
                   ;; _ (log/info ::handle-pull-request-aes-key {})
                   aes-key (sync-crypt/<ensure-graph-aes-key repo (:graph-id client))
                   ;; _ (when (some? aes-key)
                   ;;     (log/info ::handle-pull-request-aes-key-success {}))
                   _ (when (and graph-e2ee? (nil? aes-key))
                       (fail-fast :db-sync/missing-field {:repo repo :field :aes-key}))
                   remote-txs* (if aes-key
                                 (p/all (mapv (fn [{:keys [tx-data] :as remote-tx}]
                                                (p/let [tx-data* (sync-crypt/<decrypt-tx-data aes-key tx-data)]
                                                  (assoc remote-tx :tx-data tx-data*)))
                                              remote-txs))
                                 (p/resolved remote-txs))
                   _ (try
                       (sync-apply/apply-remote-txs! repo client remote-txs*)
                       (catch :default e
                         (log/error ::apply-remote-tx e)
                         (throw e)))]
             (client-op/update-local-tx repo remote-tx)
             (broadcast-rtc-state! client)
             (verify-sync-checksum! repo client remote-tx remote-tx remote-checksum {:type "pull/ok"})
             (sync-apply/enqueue-flush-pending! repo client))
           (p/then (fn [_]
                     (sync-util/clear-last-sync-error! client)))
           (p/catch (fn [error]
                      (sync-util/set-last-sync-error! client error)))))))))

(defn- handle-changed!
  [repo client local-tx remote-tx]
  (require-non-negative remote-tx {:repo repo :type "changed"})
  (broadcast-rtc-state! client)
  (when (< local-tx remote-tx)
    (request-pull! client local-tx)))
