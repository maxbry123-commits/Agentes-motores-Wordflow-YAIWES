(ns frontend.worker.db.migrate
  "Handles SQLite and datascript migrations for DB graphs"
  (:require [clojure.string :as string]
            [clojure.walk :as walk]
            [datascript.core :as d]
            [datascript.impl.entity :as de]
            [frontend.worker-common.util :as worker-util]
            [logseq.common.config :as common-config]
            [logseq.common.util :as common-util]
            [logseq.db :as ldb]
            [logseq.db.common.delete-blocks :as delete-blocks]
            [logseq.db.frontend.class :as db-class]
            [logseq.db.frontend.property :as db-property]
            [logseq.db.frontend.schema :as db-schema]
            [logseq.db.sqlite.create-graph :as sqlite-create-graph]
            [logseq.db.sqlite.util :as sqlite-util]
            [logseq.outliner.page :as outliner-page]))

;; Frontend migrations
;; ===================

(defn- add-quick-add-page
  [_db]
  (let [page (-> (-> (sqlite-util/build-new-page common-config/quick-add-page-name)
                     sqlite-create-graph/mark-block-as-built-in))]
    [page]))

(defn- add-missing-page-name
  [db]
  (let [pages (d/datoms db :avet :block/name "")]
    (keep
     (fn [d]
       (let [page (d/entity db (:e d))]
         (when-not (string/blank? (:block/title page))
           {:db/id (:db/id page)
            :block/name (common-util/page-name-sanity-lc (:block/title page))})))
     pages)))

(defn delete-property
  [db property-key]
  (let [property-entity (d/entity db property-key)
        property-page? (ldb/property? property-entity)
        direct-property-datoms (map
                                (fn [eid]
                                  [:db/retract eid property-key])
                                (d/q '[:find [?e ...]
                                       :in $ ?property-key
                                       :where
                                       [?e ?property-key ?v]]
                                     db
                                     property-key))
        remove-datoms (if property-page?
                        (outliner-page/build-page-retract-tx db property-entity)
                        (concat direct-property-datoms
                                (when property-entity
                                  [[:db/retractEntity property-key]])))]
    (->>
     (concat
      (delete-blocks/update-refs-history db remove-datoms {})
      remove-datoms)
     distinct)))

(defn remove-block-path-refs
  [db]
  (delete-property db :block/path-refs))

(defn- remove-position-property-from-url-properties
  [db]
  (->> (d/datoms db :avet :logseq.property/type :url)
       (keep (fn [d]
               (let [e (d/entity db (:e d))]
                 (when (:logseq.property/ui-position e)
                   [:db/retract (:e d) :logseq.property/ui-position]))))))

(defn- deprecated-ensure-graph-uuid
  [_db])

(defn- tag-comment-blocks
  [db]
  (when (d/entity db :logseq.class/Comments)
    (->> (d/q '[:find [?comment ...]
                :where
                [?comments-area :block/tags :logseq.class/Comments]
                [?comment :block/parent ?comments-area]]
              db)
         (map (fn [comment-id]
                [:db/add comment-id :block/tags :logseq.class/Comment])))))

(defn- add-single-block-comment-targets
  [db]
  (when (d/entity db :logseq.class/Comments)
    (->> (d/q '[:find ?comments-area-id ?parent-id
                :where
                [?comments-area-id :block/tags :logseq.class/Comments]
                [?comments-area-id :block/parent ?parent-id]]
              db)
         (keep (fn [[comments-area-id parent-id]]
                 (let [comments-area (d/entity db comments-area-id)]
                   (when-not (seq (:logseq.property.comments/blocks comments-area))
                     [:db/add comments-area-id :logseq.property.comments/blocks parent-id])))))))

(defn- missing-class-extends?
  [class]
  (let [extends (:logseq.property.class/extends class)]
    (or (nil? extends)
        (and (coll? extends) (empty? extends)))))

(defn- repair-comment-classes-and-targets
  [db]
  (let [root-id (:db/id (d/entity db :logseq.class/Root))]
    (concat
     (add-single-block-comment-targets db)
     (mapcat
      (fn [class-ident]
        (when-let [class (d/entity db class-ident)]
          (concat
           (when (and root-id (missing-class-extends? class))
             [[:db/add (:db/id class) :logseq.property.class/extends root-id]])
           (when (:block/order class)
             [[:db/retract (:db/id class) :block/order (:block/order class)]]))))
      [:logseq.class/Comments :logseq.class/Comment]))))

(def schema-version->updates
  "A vec of tuples defining datascript migrations. Each tuple consists of the
   schema version integer and a migration map. A migration map can have keys of :properties, :classes
   and :fix."
  [["65.7" {:fix add-quick-add-page}]
   ["65.8" {:fix add-missing-page-name}]
   ["65.10" {:properties [:block/journal-day :logseq.property.view/sort-groups-by-property :logseq.property.view/sort-groups-desc?]}]
   ["65.11" {:fix remove-block-path-refs}]
   ["65.12" {:fix remove-position-property-from-url-properties}]
   ["65.13" {:properties [:logseq.property.asset/width
                          :logseq.property.asset/height]}]
   ["65.14" {:properties [:logseq.property.asset/external-src]}]
   ["65.16" {:properties [:logseq.property.asset/external-file-name]}]
   ["65.17" {:properties [:logseq.property.publish/published-url]}]
   ["65.18" {:fix deprecated-ensure-graph-uuid}]
   ["65.19" {:properties [:logseq.property/choice-classes :logseq.property/choice-exclusions]}]
   ["65.20" {:properties [:logseq.property.class/bidirectional-property-title :logseq.property.class/enable-bidirectional?]}]
   ["65.21" {:properties [:logseq.property.sync/large-title-object]}]
   ["65.22" {:properties [:logseq.property.reaction/emoji-id
                          :logseq.property.reaction/target]}]
   ["65.23" {:properties [:logseq.property.asset/align]}]
   ["65.24" {:properties [:logseq.property/deleted-at
                          :logseq.property/deleted-by-ref
                          :logseq.property.recycle/original-parent
                          :logseq.property.recycle/original-page
                          :logseq.property.recycle/original-order]}]
   ["65.25" {:delete-properties [:block/pre-block?
                                 :logseq.property.embedding/hnsw-label
                                 :logseq.property.embedding/hnsw-label-updated-at]}]
   ["65.26" {:properties [:logseq.property.repeat/repeat-type]}]
   ["65.27" {:classes [:logseq.class/Comments]
             :properties [:logseq.property.comments/blocks]}]
   ["65.28" {:classes [:logseq.class/Comment]
             :fix tag-comment-blocks}]
   ["65.29" {:fix add-single-block-comment-targets}]
   ["65.30" {:properties [:logseq.property/assignee]}]
   ["65.31" {:properties [:logseq.property.agent/session-id]}]
   ["65.32" {:fix repair-comment-classes-and-targets}]
   ["65.33" {:properties [:logseq.property.view/gallery-asset-property
                          :logseq.property.view/gallery-display-properties
                          :logseq.property.view/gallery-card-size
                          :logseq.property.view/gallery-card-width
                          :logseq.property.view/gallery-card-height]}]])

(let [[major minor] (last (sort (map (comp (juxt :major :minor) db-schema/parse-schema-version first)
                                     schema-version->updates)))]
  (when major
    (let [max-schema-version {:major major :minor minor}
          compare-result (db-schema/compare-schema-version db-schema/version max-schema-version)]
      (assert (>= 0 compare-result) [db-schema/version max-schema-version])
      (when (neg? compare-result)
        (js/console.warn (str "Current db schema-version is " db-schema/version ", max available schema-version is " max-schema-version))))))

(defn ensure-built-in-data-exists!
  "Return tx-data"
  [conn]
  (let [*uuids (atom {})
        initial-data (sqlite-create-graph/build-db-initial-data "")
        data (->> initial-data
                  (keep (fn [data]
                          (cond
                            ;; Already created db-idents like :logseq.kv/graph-initial-schema-version should not be overwritten
                            (= "logseq.kv" (some-> (:db/ident data) namespace))
                            nil

                            (= (:block/title data) "Contents")
                            nil

                            (:file/path data)
                            (if-let [block (d/entity @conn [:file/path (:file/path data)])]
                              (let [existing-data (assoc (into {} block) :db/id (:db/id block))]
                                (merge data existing-data))
                              data)

                            (= [:block/uuid :logseq.property/built-in?] (keys data))
                            data

                            (:block/uuid data)
                            (if-let [block (d/entity @conn [:block/uuid (:block/uuid data)])]
                              (do
                                (swap! *uuids assoc (:block/uuid data) (:block/uuid block))
                                (let [existing-data (assoc (into {} block) :db/id (:db/id block))]
                                  (reduce
                                   (fn [data [k existing-value]]
                                     (update data k
                                             (fn [v]
                                               (cond
                                                 (= k :logseq.property/built-in?)
                                                 true
                                                 (= k :logseq.property/type)
                                                 v
                                                 (coll? v)
                                                 v

                                                 :else
                                                 (let [existing-value (if (and (coll? existing-value) (not (map? existing-value)))
                                                                        (remove nil? existing-value)
                                                                        existing-value)]
                                                   (cond
                                                     (contains? #{:block/title :block/name} k)
                                                     v
                                                     (some? existing-value)
                                                     existing-value
                                                     :else
                                                     v))))))
                                   data
                                   existing-data)))
                              data)

                            :else
                            data)))
                  common-util/fast-remove-nils)
        ;; using existing page's uuid
        data' (->>
               (walk/prewalk
                (fn [f]
                  (cond
                    (and (de/entity? f) (:block/uuid f))
                    (or (:db/ident f) [:block/uuid (:block/uuid f)])
                    (and (vector? f) (= :block/uuid (first f)) (@*uuids (second f)))
                    [:block/uuid (@*uuids (second f))]
                    :else
                    f))
                data)
               (map (fn [m] (dissoc m :db/id))))

        r (ldb/transact! conn data' {:fix-db? true
                                     :db-migrate? true})]
    (assoc r :migrate-updates
           ;; fake it as a normal :fix type migration
           {:fix (constantly :ensure-built-in-data-exists!)})))

(defn- upgrade-version!
  "Return tx-data"
  [conn version {:keys [properties classes fix delete-properties] :as migrate-updates}]
  (let [version (db-schema/parse-schema-version version)
        db @conn
        new-properties (->> (select-keys db-property/built-in-properties properties)
                            ;; property already exists, this should never happen
                            (remove (fn [[k _]]
                                      (when (d/entity db k)
                                        (assert (str "DB migration: property already exists " k)))))
                            (into {})
                            sqlite-create-graph/build-properties
                            (map (fn [b] (assoc b :logseq.property/built-in? true))))
        classes' (->> (concat [:logseq.class/Property :logseq.class/Tag :logseq.class/Page :logseq.class/Journal :logseq.class/Whiteboard] classes)
                      distinct)
        new-classes (->> (select-keys db-class/built-in-classes classes')
                         ;; class already exists, this should never happen
                         (remove (fn [[k _]] (d/entity db k)))
                         (into {})
                         (#(sqlite-create-graph/build-initial-classes* % (zipmap properties properties)))
                         (map (fn [b] (assoc b :logseq.property/built-in? true))))
        new-class-idents (keep (fn [class]
                                 (when-let [db-ident (:db/ident class)]
                                   {:db/ident db-ident})) new-classes)
        fixes (when (fn? fix)
                (fix db))
        delete-properties-tx (mapcat
                               (fn [property]
                                 (delete-property db property))
                               delete-properties)
        tx-data (concat new-class-idents new-properties new-classes fixes delete-properties-tx)
        tx-data' (concat
                  [(sqlite-util/kv :logseq.kv/schema-version version)]
                  tx-data)
        r (ldb/transact! conn tx-data' {:db-migrate? true
                                        :skip-validate-db? true})]
    (println "DB schema migrated to" version)
    (assoc r :migrate-updates migrate-updates)))

(defn migrate
  "Migrate 'frontend' datascript schema and data. To add a new migration,
  add an entry to schema-version->updates and bump db-schema/version"
  [conn & {:keys [target-version] :or {target-version db-schema/version}}]
  (let [db @conn
        version-in-db (db-schema/parse-schema-version (or (:kv/value (d/entity db :logseq.kv/schema-version)) 0))
        compare-result (db-schema/compare-schema-version target-version version-in-db)]
    (cond
      (zero? compare-result)
      nil

      (neg? compare-result) ; outdated client, db version could be synced from server
      (worker-util/post-message :notification ["Your app is using an outdated version that is incompatible with your current graph. Please update your app before editing this graph." :error false])

      (pos? compare-result)
      (try
        (let [updates (keep (fn [[v updates]]
                              (let [v* (db-schema/parse-schema-version v)]
                                (when (and (neg? (db-schema/compare-schema-version version-in-db v*))
                                           (not (pos? (db-schema/compare-schema-version v* target-version))))
                                  [v updates])))
                            schema-version->updates)
              result-ks [:tx-data :db-before :db-after :migrate-updates]
              *upgrade-result-coll (atom [])]
          (println "DB schema migrated from" version-in-db)
          (doseq [[v m] updates]
            (let [r (upgrade-version! conn v m)]
              (swap! *upgrade-result-coll conj (select-keys r result-ks))))
          (swap! *upgrade-result-coll conj
                 (select-keys (ensure-built-in-data-exists! conn) result-ks))
          {:from-version version-in-db
           :to-version target-version
           :upgrade-result-coll @*upgrade-result-coll})
        (catch :default e
          (prn :error (str "DB migration failed to migrate to " target-version " from " version-in-db ":"))
          (js/console.error e)
          (throw e))))))
