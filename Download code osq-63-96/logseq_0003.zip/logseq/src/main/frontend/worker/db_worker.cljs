(ns frontend.worker.db-worker
  "Browser worker entrypoint."
  (:require ["comlink" :as Comlink]
            [frontend.common.idb :as idb]
            [frontend.worker.db-core :as db-core]
            [frontend.worker.platform.browser :as platform-browser]
            [frontend.worker.state :as worker-state]
            [goog.object :as gobj]
            [lambdaisland.glogi :as log]
            [lambdaisland.glogi.console :as glogi-console]
            [logseq.db :as ldb]
            [promesa.core :as p]))

(def ^:private worker-bootstrap-loaded-key "__logseq_db_worker_bootstrap_loaded__")

(defn- ensure-worker-bootstrap!
  []
  (when-not (gobj/get js/self worker-bootstrap-loaded-key)
    (gobj/set js/self worker-bootstrap-loaded-key true)
    (.importScripts js/self "worker.js")))

(ensure-worker-bootstrap!)

(defn- check-worker-scope!
  []
  (when (or (gobj/get js/self "React")
            (gobj/get js/self "module$react"))
    (throw (js/Error. "[db-worker] React is forbidden in worker scope!"))))

(defn init
  "web worker entry"
  []
  (let [platform (platform-browser/browser-platform)
        proxy-object (db-core/init-core! platform)]
    (idb/start)
    (glogi-console/install!)
    (log/set-levels {:glogi/root :info})
    (log/add-handler worker-state/log-append!)
    (check-worker-scope!)
    ((get-in platform [:timers :set-interval!])
     #(.postMessage js/self "keepAliveResponse")
     (* 1000 25))
    (Comlink/expose proxy-object)
    (let [^js wrapped-main-thread* (Comlink/wrap js/self)
          wrapped-main-thread (fn [qkw & args]
                                (p/let [result (.remoteInvoke wrapped-main-thread*
                                                              (str (namespace qkw) "/" (name qkw))
                                                              (ldb/write-transit-str args))]
                                  (ldb/read-transit-str result)))]
      (reset! worker-state/*main-thread wrapped-main-thread))))
