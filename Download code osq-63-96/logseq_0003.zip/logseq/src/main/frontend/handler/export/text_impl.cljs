(ns frontend.handler.export.text-impl
  "Markdown export implementation for frontend exports."
  (:require [clojure.string :as string]
            [frontend.handler.export.common-impl :as common-impl :refer
             [*state* newline* indent raw-text space simple-asts->string]]
            [frontend.handler.export.util :refer-macros [removev concatv mapcatv]]
            [logseq.graph-parser.mldoc :as gp-mldoc]
            [logseq.graph-parser.schema.mldoc :as mldoc-schema]))

;;; block-ast, inline-ast -> simple-ast

(defn ^:api indent-with-2-spaces
  "also consider (get-in *state* [:export-options :indent-style])"
  [level]
  (let [indent-style (get-in *state* [:export-options :indent-style])]
    (case indent-style
      "dashes"               (indent level 2)
      ("spaces" "no-indent") (indent level 0)
      (assert false (print-str "unknown indent-style:" indent-style)))))

(declare inline-ast->simple-ast
         block-ast->simple-ast)

(defn- block-heading-prefix
  [{:keys [marker level priority size]}]
  (let [indent-style (get-in *state* [:export-options :indent-style])
        priority* (and priority (raw-text (common-impl/priority->string priority)))
        heading* (if (= indent-style "dashes")
                   [(indent (dec level) 0) (raw-text "-")]
                   [(indent (dec level) 0)])
        size* (and size [space (raw-text (reduce str (repeat size "#")))])
        marker* (and marker (raw-text marker))]
    (set! *state* (assoc *state* :current-level level))
    (removev nil? (concatv heading* size*
                           [space marker* space priority* space]))))

(defn- heading-continuation-indent
  [{:keys [level]}]
  (case (get-in *state* [:export-options :indent-style])
    "dashes" (indent (dec level) 2)
    ("spaces" "no-indent") (indent (dec level) 0)
    (assert false (print-str "unknown indent-style:" (get-in *state* [:export-options :indent-style])))))

(defn- block-heading
  [{:keys [title] :as heading}]
  (let [simple-asts
        (removev nil? (concatv
                       (when (and (get-in *state* [:export-options :newline-after-block])
                                  (not (get-in *state* [:newline-after-block :current-block-is-first-heading-block?])))
                         [(newline* 2)])
                       (block-heading-prefix heading)
                       (mapcatv inline-ast->simple-ast title)
                       [(newline* 1)]))]
      (set! *state* (assoc-in *state* [:newline-after-block :current-block-is-first-heading-block?] false))
      simple-asts))

(declare block-list)

(defn- list-continuation-indent
  [current-level]
  (indent-with-2-spaces (dec current-level)))

(defn- src-in-list-item
  [{:keys [lines language]} continuation-indent]
  (concatv [(raw-text "```")]
           (when language [(raw-text language)])
           [(newline* 1)]
           (mapv raw-text lines)
           [continuation-indent (raw-text "```") (newline* 1)]))

(defn- quote-line
  [line]
  (let [line (string/trimr line)]
    (if (string/blank? line)
      ">"
      (str "> " line))))

(defn- quote-in-list-item
  [block-coll continuation-indent]
  (let [lines (->> block-coll
                   (mapcatv block-ast->simple-ast)
                   simple-asts->string
                   string/split-lines)
        lines (if (seq lines) lines [""])]
    (mapcatv (fn [idx line]
               (concatv (when (pos? idx) [continuation-indent])
                        [(raw-text (quote-line line))
                         (newline* 1)]))
             (range)
             lines)))

(defn- block-level-content-in-list-item
  [content continuation-indent]
  (when (= 1 (count content))
    (let [[ast-type ast-content] (first content)]
      (case ast-type
        "Src"
        (src-in-list-item ast-content continuation-indent)

        "Quote"
        (quote-in-list-item ast-content continuation-indent)

        nil))))

(defn- block-list-item
  [{:keys [content items number _name checkbox]}]
  (let [number* (raw-text
                 (if number
                   (str number ". ")
                   "* "))
        checkbox* (raw-text
                   (if (some? checkbox)
                     (if (boolean checkbox)
                       "[X]" "[ ]")
                     ""))
        current-level (get *state* :current-level 1)
        indent' (when (> current-level 1)
                  (indent (dec current-level) 0))
        continuation-indent (list-continuation-indent current-level)
        content* (or (block-level-content-in-list-item content continuation-indent)
                     (mapcatv block-ast->simple-ast content))
        items* (block-list items :in-list? true)]
    (concatv [indent' number* checkbox* space]
             content*
             [(newline* 1)]
             items*
             [(newline* 1)])))

(defn- block-list
  [l & {:keys [in-list?]}]
  (binding [*state* (update *state* :current-level inc)]
    (concatv (mapcatv block-list-item l)
             (when (and (pos? (count l))
                        (not in-list?))
               [(newline* 2)]))))

(defn- block-property-drawer
  [properties]
  (when-not (get-in *state* [:export-options :remove-properties?])
    (let [level (dec (get *state* :current-level 1))
          indent' (indent-with-2-spaces level)]
      (reduce
       (fn [r [k v]]
         (conj r indent' (raw-text k "::") space (raw-text v) (newline* 1)))
       [] properties))))

(defn- block-example
  [l]
  (let [level (dec (get *state* :current-level 1))]
    (mapcatv
     (fn [line]
       [(indent-with-2-spaces level)
        (raw-text "    ")
        (raw-text line)
        (newline* 1)])
     l)))

(defn- remove-max-prefix-spaces
  [lines]
  (let [common-prefix-spaces
        (reduce
         (fn [r line]
           (if (string/blank? line)
             r
             (let [leading-spaces (re-find #"^\s+" line)]
               (if (nil? r)
                 leading-spaces
                 (if (string/starts-with? r leading-spaces)
                   leading-spaces
                   r)))))
         nil
         lines)
        pattern (re-pattern (str "^" common-prefix-spaces))]
    (mapv (fn [line] (string/replace-first line pattern "")) lines)))

(defn- block-src
  [{:keys [lines language]} {:keys [heading-prefix]}]
  (let [level (dec (get *state* :current-level 1))
        lines* (if (= "no-indent" (get-in *state* [:export-options :indent-style]))
                 (remove-max-prefix-spaces lines)
                 lines)]
    (if heading-prefix
      (concatv
       (block-heading-prefix heading-prefix)
       [(raw-text "```")]
       (when language [(raw-text language)])
       [(newline* 1)]
       (mapv raw-text lines*)
       [(heading-continuation-indent heading-prefix) (raw-text "```") (newline* 1)])
      (concatv
       [(indent-with-2-spaces level) (raw-text "```")]
       (when language [(raw-text language)])
       [(newline* 1)]
       (mapv raw-text lines*)
       [(indent-with-2-spaces level) (raw-text "```") (newline* 1)]))))

(defn- quote-block-lines
  [block-coll]
  (let [lines (->> block-coll
                   (mapcatv block-ast->simple-ast)
                   simple-asts->string
                   string/split-lines)]
    (if (seq lines) lines [""])))

(defn- quote-lines-with-prefix
  [lines prefix continuation-indent]
  (mapcatv (fn [idx line]
             (concatv (if (zero? idx) prefix [continuation-indent])
                      [(raw-text (quote-line line))
                       (newline* 1)]))
           (range)
           lines))

(defn- block-quote
  [block-coll {:keys [heading-prefix]}]
  (let [level (dec (get *state* :current-level 1))]
    (if heading-prefix
      (binding [*state* (assoc *state* :indent-after-break-line? true)]
        (quote-lines-with-prefix (quote-block-lines block-coll)
                                 (block-heading-prefix heading-prefix)
                                 (heading-continuation-indent heading-prefix)))
      (binding [*state* (assoc *state* :indent-after-break-line? true)]
        (concatv (mapcatv (fn [block]
                            (let [block-simple-ast (block-ast->simple-ast block)]
                              (when (seq block-simple-ast)
                                (concatv [(indent-with-2-spaces level) (raw-text ">") space]
                                         block-simple-ast))))
                          block-coll)
                 [(newline* 2)])))))

(declare inline-latex-fragment)
(defn- block-latex-fragment
  [ast-content]
  (inline-latex-fragment ast-content))

(defn- block-latex-env
  [[name options content]]
  (let [level (dec (get *state* :current-level 1))]
    [(indent-with-2-spaces level) (raw-text "\\begin{" name "}" options)
     (newline* 1)
     (indent-with-2-spaces level) (raw-text content)
     (newline* 1)
     (indent-with-2-spaces level) (raw-text "\\end{" name "}")
     (newline* 1)]))

(defn- block-displayed-math
  [ast-content]
  [space (raw-text "$$" ast-content "$$") space])

(defn- block-drawer
  [[name lines]]
  (let [level (dec (get *state* :current-level))]
    (concatv
     [(raw-text ":" name ":")
      (newline* 1)]
     (mapcatv (fn [line] [(indent-with-2-spaces level) (raw-text line)]) lines)
     [(newline* 1) (raw-text ":END:") (newline* 1)])))

(defn- block-footnote-definition
  [[name content]]
  (concatv
   [(raw-text "[^" name "]:") space]
   (mapcatv inline-ast->simple-ast content)
   [(newline* 1)]))

(def ^:private block-horizontal-rule [(newline* 1) (raw-text "---") (newline* 1)])

(defn- block-table
  [{:keys [header groups]}]
  (let [level    (dec (get *state* :current-level 1))
        sep-line (raw-text "|" (string/join "|" (repeat (count header) "---")) "|")
        header-line
        (concatv (mapcatv
                  (fn [h] (concatv [space (raw-text "|") space] (mapcatv inline-ast->simple-ast h)))
                  header)
                 [space (raw-text "|")])
        group-lines
        (mapcatv
         (fn [group]
           (mapcatv
            (fn [row]
              (concatv [(indent-with-2-spaces level)]
                       (mapcatv
                        (fn [col]
                          (concatv [(raw-text "|") space]
                                   (mapcatv inline-ast->simple-ast col)
                                   [space]))
                        row)
                       [(raw-text "|") (newline* 1)]))
            group))
         groups)]
    (concatv [(newline* 1) (indent-with-2-spaces level)]
             (when (seq header) header-line)
             (when (seq header) [(newline* 1) (indent-with-2-spaces level) sep-line (newline* 1)])
             group-lines)))

(defn- block-comment
  [s]
  (let [level (dec (get *state* :current-level 1))]
    [(indent-with-2-spaces level) (raw-text "<!---") (newline* 1)
     (indent-with-2-spaces level) (raw-text s) (newline* 1)
     (indent-with-2-spaces level) (raw-text "-->") (newline* 1)]))

(defn- block-raw-html
  [s]
  (let [level (dec (get *state* :current-level 1))]
    [(indent-with-2-spaces level) (raw-text s) (newline* 1)]))

(defn- block-hiccup
  [s]
  (let [level (dec (get *state* :current-level 1))]
    [(indent-with-2-spaces level) (raw-text s) space]))

(defn- inline-link
  [{full-text :full_text}]
  [(raw-text full-text)])

(defn- inline-nested-link
  [{content :content}]
  [(raw-text content)])

(defn- inline-subscript
  [inline-coll]
  (concatv [(raw-text "_{")]
           (mapcatv (fn [inline] (cons space (inline-ast->simple-ast inline))) inline-coll)
           [(raw-text "}")]))

(defn- inline-superscript
  [inline-coll]
  (concatv [(raw-text "^{")]
           (mapcatv (fn [inline] (cons space (inline-ast->simple-ast inline))) inline-coll)
           [(raw-text "}")]))

(defn- inline-footnote-reference
  [{name :name}]
  [(raw-text  "[" name "]")])

(defn- inline-cookie
  [ast-content]
  [(raw-text
    (case (first ast-content)
      "Absolute"
      (let [[_ current total] ast-content]
        (str "[" current "/" total "]"))
      "Percent"
      (str "[" (second ast-content) "%]")))])

(defn- inline-latex-fragment
  [ast-content]
  (let [[type content] ast-content
        wrapper (case type
                  "Inline" "$"
                  "Displayed" "$$")]
    [space (raw-text (str wrapper content wrapper)) space]))

(defn- inline-macro
  [{:keys [name arguments]}]
  (->
   (if (= name "cloze")
     (string/join "," arguments)
     (let [l (cond-> ["{{" name]
               (pos? (count arguments)) (conj "(" (string/join "," arguments) ")")
               true (conj "}}"))]
       (string/join l)))
   raw-text
   vector))

(defn- inline-entity
  [{unicode :unicode}]
  [(raw-text unicode)])

(defn- inline-timestamp
  [ast-content]
  (let [[type timestamp-content] ast-content]
    (-> (case type
          "Scheduled" ["SCHEDULED: " (common-impl/timestamp-to-string timestamp-content)]
          "Deadline" ["DEADLINE: " (common-impl/timestamp-to-string timestamp-content)]
          "Date" [(common-impl/timestamp-to-string timestamp-content)]
          "Closed" ["CLOSED: " (common-impl/timestamp-to-string timestamp-content)]
          "Clock" ["CLOCK: " (common-impl/timestamp-to-string (second timestamp-content))]
          "Range" (let [{:keys [start stop]} timestamp-content]
                    [(str (common-impl/timestamp-to-string start) "--" (common-impl/timestamp-to-string stop))]))
        string/join
        raw-text
        vector)))

(defn- inline-email
  [{:keys [local_part domain]}]
  [(raw-text (str "<" local_part "@" domain ">"))])

(defn- emphasis-wrap-with
  [inline-coll em-symbol]
  (binding [*state* (assoc *state* :outside-em-symbol (first em-symbol))]
    (concatv [(raw-text em-symbol)]
             (mapcatv inline-ast->simple-ast inline-coll)
             [(raw-text em-symbol)])))

(defn- inline-emphasis
  [emphasis]
  (let [[[type] inline-coll] emphasis
        outside-em-symbol (:outside-em-symbol *state*)]
    (case type
      "Bold"
      (emphasis-wrap-with inline-coll (if (= outside-em-symbol "*") "__" "**"))
      "Italic"
      (emphasis-wrap-with inline-coll (if (= outside-em-symbol "*") "_" "*"))
      "Underline"
      (binding [*state* (assoc *state* :outside-em-symbol outside-em-symbol)]
        (mapcatv (fn [inline] (cons space (inline-ast->simple-ast inline))) inline-coll))
      "Strike_through"
      (emphasis-wrap-with inline-coll "~~")
      "Highlight"
      (emphasis-wrap-with inline-coll "^^")
      ;; else
      (assert false (print-str :inline-emphasis emphasis "is invalid")))))

(defn- inline-break-line
  []
  [(if (= "no-indent" (get-in *state* [:export-options :indent-style]))
     (raw-text "\n")
     (raw-text "  \n"))
   (when (:indent-after-break-line? *state*)
     (let [current-level (get *state* :current-level 1)]
       (when (> current-level 1)
         (indent-with-2-spaces (dec current-level)))))])

;; {:malli/schema ...} only works on public vars so make this public
(defn ^:large-vars/cleanup-todo ^:api block-ast->simple-ast
  {:malli/schema [:=> [:cat mldoc-schema/block-ast-schema] [:sequential common-impl/simple-ast-malli-schema]]}
  [block]
  (let [newline-after-block? (get-in *state* [:export-options :newline-after-block])]
    (removev
     nil?
     (let [[ast-type ast-content] block]
       (case ast-type
         "Paragraph"
         (let [{:keys [origin-ast]} (meta block)
               current-block-is-first-heading-block? (get-in *state* [:newline-after-block :current-block-is-first-heading-block?])]
           (set! *state* (assoc-in *state* [:newline-after-block :current-block-is-first-heading-block?] false))
           (concatv
            (when (and origin-ast newline-after-block? (not current-block-is-first-heading-block?))
              [(newline* 2)])
            (mapcatv inline-ast->simple-ast ast-content)
            (let [last-element (last ast-content)
                  [last-element-type] last-element]
              (when (and newline-after-block? (= "Break_Line" last-element-type))
                (inline-break-line)))
            [(newline* 1)]))
         "Paragraph_line"
         (assert false "Paragraph_line is mldoc internal ast")
         "Paragraph_Sep"
         [(newline* ast-content)]
         "Heading"
         (block-heading ast-content)
         "List"
         (block-list ast-content)
         ("Directive" "Results" "Export" "CommentBlock" "Custom")
         nil
         "Example"
         (block-example ast-content)
         "Src"
         (block-src ast-content (meta block))
         "Quote"
         (block-quote ast-content (meta block))
         "Latex_Fragment"
         (block-latex-fragment ast-content)
         "Latex_Environment"
         (block-latex-env (rest block))
         "Displayed_Math"
         (block-displayed-math ast-content)
         "Drawer"
         (block-drawer (rest block))
         "Property_Drawer"
         (block-property-drawer ast-content)
         "Footnote_Definition"
         (block-footnote-definition (rest block))
         "Horizontal_Rule"
         block-horizontal-rule
         "Table"
         (block-table ast-content)
         "Comment"
         (block-comment ast-content)
         "Raw_Html"
         (block-raw-html ast-content)
         "Hiccup"
         (block-hiccup ast-content)
         (assert false (print-str :block-ast->simple-ast ast-type "not implemented yet")))))))

(defn- ^:large-vars/cleanup-todo inline-ast->simple-ast
  [inline]
  (let [[ast-type ast-content] inline]
    (case ast-type
      "Emphasis"
      (inline-emphasis ast-content)
      ("Break_Line" "Hard_Break_Line")
      (inline-break-line)
      "Verbatim"
      [(raw-text ast-content)]
      "Code"
      [(raw-text "`" ast-content "`")]
      "Tag"
      [(raw-text (str "#" (common-impl/hashtag-value->string ast-content)))]
      "Spaces"                          ; what's this ast-type for ?
      nil
      "Plain"
      [(raw-text ast-content)]
      "Link"
      (inline-link ast-content)
      "Nested_link"
      (inline-nested-link ast-content)
      "Target"
      [(raw-text (str "<<" ast-content ">>"))]
      "Subscript"
      (inline-subscript ast-content)
      "Superscript"
      (inline-superscript ast-content)
      "Footnote_Reference"
      (inline-footnote-reference ast-content)
      "Cookie"
      (inline-cookie ast-content)
      "Latex_Fragment"
      (inline-latex-fragment ast-content)
      "Macro"
      (inline-macro ast-content)
      "Entity"
      (inline-entity ast-content)
      "Timestamp"
      (inline-timestamp ast-content)
      "Radio_Target"
      [(raw-text (str "<<<" ast-content ">>>"))]
      "Email"
      (inline-email ast-content)
      "Inline_Hiccup"
      [(raw-text ast-content)]
      "Inline_Html"
      [(raw-text ast-content)]
      ("Export_Snippet" "Inline_Source_Block")
      nil
      (assert false (print-str :inline-ast->simple-ast ast-type "not implemented yet")))))

;;; block-ast, inline-ast -> simple-ast (ends)

(defn ^:large-vars/cleanup-todo export-helper
  [content format options]
  (let [remove-options (set (:remove-options options))
        other-options (:other-options options)]
    (binding [*state* (merge *state*
                             {:export-options
                              {:indent-style (or (:indent-style options) "dashes")
                               :remove-emphasis? (contains? remove-options :emphasis)
                               :remove-page-ref-brackets? (contains? remove-options :page-ref)
                               :remove-tags? (contains? remove-options :tag)
                               :remove-properties? (contains? remove-options :property)
                               :keep-only-level<=N (:keep-only-level<=N other-options)
                               :newline-after-block (:newline-after-block other-options)}})]
      (let [ast (gp-mldoc/->db-edn content format)
            ast (mapv common-impl/remove-block-ast-pos ast)
            ast (removev common-impl/Properties-block-ast? ast)
            ast* (common-impl/replace-block&page-reference&embed ast)
            keep-level<=n (get-in *state* [:export-options :keep-only-level<=N])
            ast* (if (pos? keep-level<=n)
                   (common-impl/keep-only-level<=n ast* keep-level<=n)
                   ast*)
            ast** (if (= "no-indent" (get-in *state* [:export-options :indent-style]))
                    (mapv common-impl/replace-Heading-with-Paragraph ast*)
                    ast*)
            config-for-walk-block-ast (cond-> {}
                                        (get-in *state* [:export-options :remove-emphasis?])
                                        (update :mapcat-fns-on-inline-ast conj common-impl/remove-emphasis)

                                        (get-in *state* [:export-options :remove-page-ref-brackets?])
                                        (update :map-fns-on-inline-ast conj common-impl/remove-page-ref-brackets)

                                        (get-in *state* [:export-options :remove-tags?])
                                        (update :mapcat-fns-on-inline-ast conj common-impl/remove-tags)

                                        (= "no-indent" (get-in *state* [:export-options :indent-style]))
                                        (update :fns-on-inline-coll conj common-impl/remove-prefix-spaces-in-Plain))
            ast*** (if-not (empty? config-for-walk-block-ast)
                     (mapv (partial common-impl/walk-block-ast config-for-walk-block-ast) ast**)
                     ast**)
            ast**** (loop [remaining ast***
                           result []]
                      (if-let [block (first remaining)]
                        (let [[ast-type ast-content] block
                              next-block (second remaining)
                              [next-ast-type] next-block]
                          (if (and (= "Heading" ast-type)
                                   (empty? (:title ast-content))
                                   (contains? #{"Quote" "Src"} next-ast-type))
                            (recur (nnext remaining)
                                   (conj result (with-meta next-block (assoc (meta next-block) :heading-prefix ast-content))))
                            (recur (rest remaining)
                                   (conj result block))))
                        result))
            simple-asts (mapcatv block-ast->simple-ast ast****)]
        (simple-asts->string simple-asts)))))
