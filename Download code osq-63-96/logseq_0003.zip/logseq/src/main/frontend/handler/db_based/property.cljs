(ns frontend.handler.db-based.property
  "db based property handler"
  (:require [frontend.db.async :as db-async]
            [frontend.modules.outliner.op :as outliner-op]
            [frontend.modules.outliner.ui :as ui-outliner-tx]
            [frontend.state :as state]
            [logseq.db.frontend.property :as db-property]
            [logseq.outliner.op]
            [promesa.core :as p]))

(defn- <block-uuid
  [block-id]
  (if (integer? block-id)
    (p/let [block (db-async/<get-block (state/get-current-repo) block-id {:children? false})]
      (:block/uuid block))
    (p/resolved block-id)))

(defn- <property-ident
  [property-id]
  (if (integer? property-id)
    (p/let [property (db-async/<get-block (state/get-current-repo) property-id {:children? false})]
      (:db/ident property))
    (p/resolved property-id)))

(defn- <block-uuids
  [block-ids]
  (p/all (map <block-uuid block-ids)))

(defn upsert-property!
  [property-id schema property-opts]
  (p/let [property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :upsert-property}
     (outliner-op/upsert-property! property-id schema property-opts))))

(defn set-block-property!
  [block-id property-id value]
  (p/let [block-id (<block-uuid block-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :set-block-property}
     (outliner-op/set-block-property! block-id property-id value))))

(defn set-block-properties!
  [block-id properties]
  (p/let [block-id (<block-uuid block-id)
          properties (p/all (map (fn [[property-id value]]
                                   (p/let [property-id (<property-ident property-id)]
                                     [property-id value]))
                                 properties))]
    (ui-outliner-tx/transact!
     {:outliner-op :set-block-properties}
     (doseq [[property-id value] properties]
       (outliner-op/set-block-property! block-id property-id value)))))

(defn remove-block-property!
  [block-id property-id]
  (p/let [block-id (<block-uuid block-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :remove-block-property}
     (outliner-op/remove-block-property! block-id property-id))))

(defn delete-property-value!
  [block-id property-id property-value]
  (p/let [block-id (<block-uuid block-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :delete-property-value}
     (outliner-op/delete-property-value! block-id property-id property-value))))

(defn batch-delete-property-value!
  [block-ids property-id property-value]
  (p/let [block-ids (<block-uuids block-ids)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :batch-delete-property-value}
     (outliner-op/batch-delete-property-value! block-ids property-id property-value))))

(defn create-property-text-block!
  [block-id property-id value opts]
  (p/let [block-id (<block-uuid block-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :create-property-text-block}
     (outliner-op/create-property-text-block! block-id property-id value opts))))

(defn batch-set-property!
  [block-ids property-id value opts]
  (p/let [block-ids (<block-uuids block-ids)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :batch-set-property}
     (outliner-op/batch-set-property! block-ids property-id value opts))))

(defn batch-remove-property!
  [block-ids property-id]
  (p/let [block-ids (<block-uuids block-ids)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :batch-remove-property}
     (outliner-op/batch-remove-property! block-ids property-id))))

(defn class-add-property!
  [class-id property-id]
  (p/let [class-id (<block-uuid class-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :class-add-property}
     (outliner-op/class-add-property! class-id property-id))))

(defn class-remove-property!
  [class-id property-id]
  (p/let [class-id (<block-uuid class-id)
          property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :class-remove-property}
     (outliner-op/class-remove-property! class-id property-id))))

(defn batch-set-property-closed-value!
  [block-ids db-ident closed-value]
  (p/let [closed-values (db-async/<get-property-closed-values (state/get-current-repo) db-ident)]
    (if-let [closed-value-entity (some (fn [entity]
                                         (when (= (db-property/closed-value-content entity) closed-value)
                                           entity))
                                       closed-values)]
      (batch-set-property! block-ids
                           db-ident
                           (:db/id closed-value-entity)
                           {:entity-id? true})
      (js/console.error (str "No entity found for closed value " (pr-str closed-value))))))

(defn upsert-closed-value!
  [property-id closed-value-config]
  (p/let [property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :upsert-closed-value}
     (outliner-op/upsert-closed-value! property-id closed-value-config))))

(defn delete-closed-value!
  [property-id value]
  (p/let [property-id (<property-ident property-id)
          value (<block-uuid value)]
    (ui-outliner-tx/transact!
     {:outliner-op :delete-closed-value}
     (outliner-op/delete-closed-value! property-id value))))

(defn add-existing-values-to-closed-values!
  [property-id values]
  (p/let [property-id (<property-ident property-id)]
    (ui-outliner-tx/transact!
     {:outliner-op :add-existing-values-to-closed-values}
     (outliner-op/add-existing-values-to-closed-values! property-id values))))
