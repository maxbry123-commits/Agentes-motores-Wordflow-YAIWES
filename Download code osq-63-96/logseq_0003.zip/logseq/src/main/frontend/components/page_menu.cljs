(ns frontend.components.page-menu
  (:require [frontend.commands :as commands]
            [frontend.components.export :as export]
            [frontend.config :as config]
            [frontend.context.i18n :refer [t]]
            [frontend.date :as date]
            [frontend.handler.common.developer :as dev-common-handler]
            [frontend.handler.db-based.page :as db-page-handler]
            [frontend.handler.notification :as notification]
            [frontend.handler.page :as page-handler]
            [frontend.handler.publish :as publish-handler]
            [frontend.mobile.util :as mobile-util]
            [frontend.modules.shortcut.data-helper :as shortcut-dh]
            [frontend.state :as state]
            [frontend.util :as util]
            [frontend.util.entity :as entity]
            [logseq.shui.hooks :as hooks]
            [logseq.shui.ui :as shui]
            [promesa.core :as p]
            [io.factorhouse.hsx.core :as hsx]))

(defn- today-journal-page?
  [page]
  (and (entity/journal? page)
       (= (:block/journal-day page) (date/today-journal-day))))

(hsx/defc publish-page-dialog
  [page]
  (let [[password set-password!] (hooks/use-state "")
        [publishing? set-publishing!] (hooks/use-state false)
        submit! (fn []
                  (when-not publishing?
                    (set-publishing! true)
                    (-> (publish-handler/publish-page! page {:password password})
                        (p/finally (fn []
                                     (set-publishing! false)
                                     (shui/dialog-close!))))))]
    [:form.flex.flex-col.gap-4.p-2
     {:on-submit (fn [e]
                   (.preventDefault e)
                   (submit!))}
     [:div.text-lg.font-medium (t :publish/dialog-title)]
     [:div.text-sm.opacity-70
      (t :publish/dialog-desc)]
     (shui/toggle-password
      {:placeholder (t :publish/password-optional-placeholder)
       :value password
       :on-change (fn [e]
                    (set-password! (util/evalue e)))})
     [:div.flex.justify-end.gap-2
      (shui/button
       {:variant "ghost"
        :type "button"
        :on-click #(shui/dialog-close!)}
       (t :ui/cancel))
      (shui/button
       {:type "submit"
        :auto-focus true
        :disabled publishing?}
       (if publishing?
         (t :publish/publishing)
         (t :publish/action)))]]))

(defn- delete-page!
  [page]
  (page-handler/<delete! (:block/uuid page)
                         (fn []
                           (notification/show!
	                            (if (today-journal-page? page)
                              (t :page.delete/today-journal-truncate-success)
                              (t :page.delete/success (:block/title page)))
                            :success))
                         {:error-handler (fn [{:keys [msg]}]
                                           (when msg
                                             (notification/show! msg :warning)))}))

(defn delete-page-confirm!
  [page]
  (when page
    (-> (shui/dialog-confirm!
         {:title [:span.flex.gap-2.items-center
                  [:span.relative
                   (shui/tabler-icon "alert-triangle")]
	                  (if (or (entity/class? page) (entity/property? page) (today-journal-page? page))
                    (t :page.delete/permanent-confirm-title)
                    (t :page.delete/confirm-title))]
          :content [:p.opacity-60 (str "- " (:block/title page))]
          :outside-cancel? true
          :cancel-label (t :ui/cancel)
          :ok-label (t :ui/confirm)})
        (p/then #(delete-page! page))
        (p/catch #()))))

(defn- latest-page
  [page]
  page)

(defn- toggle-public-attribute!
  [page]
  (when-let [page' (latest-page page)]
    (page-handler/update-public-attribute!
     page'
     (not (true? (:logseq.property/publishing-public? page'))))))

(defn ^:large-vars/cleanup-todo page-menu
  [page favorited?]
  (when-let [page' (latest-page page)]
    (when-let [page-name (and (entity/page? page') (:block/name page'))]
      (let [page-title (str (:block/uuid page'))
            block? (util/uuid-string? page-name)
            contents? (= page-name "contents")
            public? (true? (:logseq.property/publishing-public? page'))
            developer-mode? (state/developer-mode?)]
        (when (not block?)
          (->>
           [(when-not config/publishing?
              {:title   (if favorited?
                          (t :page/unfavorite)
                          (t :page/add-to-favorites))
               :options {:on-click
                         (fn []
                           (if favorited?
                             (page-handler/<unfavorite-page! page-title)
                             (page-handler/<favorite-page! page-title)))}})

            (when (or (util/electron?)
                      (mobile-util/native-platform?))
              {:title   (t :page/copy-url)
               :options {:on-click #(page-handler/copy-page-url (:block/uuid page'))}})

            (when-not (or contents?
                          config/publishing?
                          (:logseq.property/built-in? page'))
              {:title   (t :page/delete)
               :options {:on-click #(delete-page-confirm! page')}})

            {:title   (t :export/page)
             :options {:on-click #(shui/dialog-open!
                                   (fn []
                                     (export/export-blocks [(:block/uuid page')] {:export-type :page}))
                                   {:class "w-auto md:max-w-4xl max-h-[80vh] overflow-y-auto"})}}

            (when-not config/publishing?
              {:title   (t :publish/dialog-title)
               :options {:on-click #(shui/dialog-open! (fn [] (publish-page-dialog page'))
                                                       {:class "w-auto max-w-md"})}})

            (when (util/electron?)
              {:title   (t (if public? :page/make-private :page/make-public))
               :options {:on-click #(toggle-public-attribute! page')}})

            (when config/lsp-enabled?
              (for [[_ {:keys [label] :as cmd} action pid] (state/get-plugins-commands-with-type :page-menu-item)]
                {:title label
                 :options {:on-click #(commands/exec-plugin-simple-command!
                                       pid (assoc cmd :page page-name) action)}}))

            (when (and (entity/internal-page? page') (not (:logseq.property/built-in? page')))
              {:title (t :page/convert-to-tag)
               :options {:on-click (fn []
                                     (db-page-handler/convert-page-to-tag! page'))}})

            (when (and (entity/class? page') (not (:logseq.property/built-in? page')))
              {:title (t :page.convert/tag-to-page-action)
               :options {:on-click (fn []
                                     (db-page-handler/convert-tag-to-page! page'))}})

            (when developer-mode?
              {:title   (shortcut-dh/shortcut-desc-by-id :dev/show-page-data)
               :options {:on-click (fn []
                                     (dev-common-handler/show-entity-data (:db/id page')))}})]
           (flatten)
           (remove nil?)))))))
