(ns frontend.components.header
  (:require ["react" :as react]
            [cljs-bean.core :as bean]
            [cljs-time.coerce :as tc]
            [cljs-time.core :as t]
            [clojure.string :as string]
            [dommy.core :as d]
            [electron.ipc :as ipc]
            [frontend.components.avatar :as avatar]
            [frontend.components.block :as component-block]
            [frontend.components.email :as email-component]
            [frontend.components.export :as export]
            [frontend.components.page-menu :as page-menu]
            [frontend.components.plugins :as plugins]
            [frontend.components.repo :as repo]
            [frontend.components.right-sidebar :as sidebar]
            [frontend.components.rtc.indicator :as rtc-indicator]
            [frontend.components.server :as server]
            [frontend.components.settings :as settings]
            [frontend.components.svg :as svg]
            [frontend.config :as config]
            [frontend.context.i18n :as i18n :refer [t]]
            [frontend.db.async :as db-async]
            [frontend.db.hooks :as db-hooks]
            [frontend.handler :as handler]
            [frontend.handler.page :as page-handler]
            [frontend.handler.plugin :as plugin-handler]
            [frontend.handler.route :as route-handler]
            [frontend.handler.user :as user-handler]
            [frontend.mobile.util :as mobile-util]
            [frontend.rfx :as rfx]
            [frontend.state :as state]
            [frontend.ui :as ui]
            [frontend.util :as util]
            [frontend.util.email :as email-util]
            [frontend.util.entity :as entity]
            [frontend.version :refer [version]]
            [logseq.common.config :as common-config]
            [logseq.common.util :as common-util]
            [logseq.common.version :as build-version]
            [logseq.shui.hooks :as hooks]
            [logseq.shui.ui :as shui]
            [promesa.core :as p]
            [reitit.frontend.easy :as rfe]
            [io.factorhouse.hsx.core :as hsx]))

(hsx/defc home-button
  []
  (ui/tooltip
   (shui/button-ghost-icon :home
                           {:on-click #(do
                                         (when (mobile-util/native-iphone?)
                                           (state/set-left-sidebar-open! false))
                                         (route-handler/redirect-to-home!))})
   (t :nav/home)
   {:trigger-props {:as-child true}}))

(defn current-local-uploadable-graph
  [db-rtc-uuid]
  (let [current-repo (state/get-current-repo)]
    (some (fn [{:keys [url] :as graph}]
            (when (and (= current-repo url)
                       (repo/local-uploadable-graph?
                        (assoc graph :rtc-graph?
                               (boolean db-rtc-uuid))))
              graph))
          (state/get-repos))))

(defn- use-db-rtc-uuid
  [repo]
  (let [[db-rtc-uuid set-db-rtc-uuid!] (hooks/use-state nil)]
    (hooks/use-effect!
     (fn []
       (when repo
         (p/let [graph-uuid (state/<invoke-db-worker :thread-api/get-rtc-graph-uuid repo)]
           (set-db-rtc-uuid! graph-uuid)))
       nil)
     [repo])
    db-rtc-uuid))

(defn- current-remote-rtc-graph
  [current-repo rtc-graphs]
  (some #(when (= current-repo (:url %)) %) rtc-graphs))

(defn- rtc-indicator-visible?
  [{:keys [current-repo rtc-graphs db-rtc-uuid rtc-state logged-in? rtc-group?]}]
  (let [remote-graph (current-remote-rtc-graph current-repo rtc-graphs)
        remote-graph-uuid (some-> (:GraphUUID remote-graph) str)
        state-graph-uuid (some-> (:graph-uuid rtc-state) str)]
    (and current-repo
         logged-in?
         rtc-group?
         remote-graph
         (or db-rtc-uuid
             (and (seq state-graph-uuid)
                  (= state-graph-uuid remote-graph-uuid))))))

(defn local-graph-sync-button
  [graph]
  (ui/tooltip
   (shui/button-ghost-icon :cloud
                           {:class "local-graph-sync-btn"
                            :on-click #(repo/upload-local-graph-with-confirm! graph)})
   (t :graph/use-sync-beta)
   {:trigger-props {:as-child true}}))

(hsx/defc rtc-collaborators
  []
  (let [rtc-graph-id (use-db-rtc-uuid (state/get-current-repo))
        config (rfx/use-sub [:config])
        online-users (rfx/use-sub [:rtc/state :online-users])]
    (when rtc-graph-id
      [:div.rtc-collaborators.flex.gap-1.text-sm.bg-gray-01.items-center
       (shui/button-ghost-icon :user-plus
                               {:on-click #(shui/dialog-open!
                                            (fn []
                                              [:div.p-2.-mb-8
                                               [:h1.text-3xl.-mt-2.-ml-2 (t :collaboration/members)]
                                               (settings/settings-collaboration)])
                                            {:id :rtc-collaborators})})

       (when (seq online-users)
         (for [{user-email :user/email
                user-name :user/name
                user-uuid :user/uuid} online-users
               :when user-name
               :let [key (str "rtc-user-" (or user-uuid user-email user-name))]]
           ^{:key key}
           [:<>
            (avatar/user-avatar
             {:class "w-5 h-5"
              :style {:app-region "no-drag"}
              :title (email-util/display-email user-email config)
              :name user-name
              :uuid user-uuid
              :fallback-props {:style {:font-size 11}}})]))])))

(hsx/defc left-menu-button
  [{:keys [on-click]}]
  (ui/with-shortcut :ui/toggle-left-sidebar "bottom"
    (shui/button-ghost-icon
     :menu-2 {:id "left-menu"
              :class "cp__header-left-menu"
              :on-click on-click})
    (t :header/toggle-left-sidebar)
    {:trigger-props {:id "left-menu"}}))

(defn bug-report-url []
  (let [ua (.-userAgent js/navigator)
        safe-ua (string/replace ua #"[^_/a-zA-Z0-9\.\(\)]+" " ")
        installed-plugins (state/get-state :plugin/installed-plugins)
        platform (str "App Version: " version "\n"
                      "Git Revision: " (build-version/revision) "\n"
                      "Platform: " safe-ua "\n"
                      "Language: " (.-language js/navigator) "\n"
                      "Plugins: " (string/join ", " (map (fn [[k v]]
                                                           (str (name k) " (" (:version v) ")"))
                                                         installed-plugins)))]
    (str "https://github.com/logseq/db-test/issues/new?"
         "title=&"
         "template=bug_report.yaml&"
         "labels=from:in-app&"
         "platform="
         (js/encodeURIComponent platform))))

(defn- stop-event!
  [^js e]
  (.preventDefault e)
  (.stopPropagation e))

(hsx/defc ^:large-vars/cleanup-todo toolbar-dots-menu-content
  [{:keys [current-repo t]} page favorited? recycle-page?]
  (let [db-restoring? (rfx/use-sub [:db/restoring?])
        working-page? (not db-restoring?)
        page-menu (when page
                    (if (and working-page? (entity/page? page))
                      (page-menu/page-menu page favorited?)
                      (when-not config/publishing?
                      (let [block-id-str (str (:block/uuid page))]
                        [{:title   (if favorited?
                                     (t :page/unfavorite)
                                     (t :page/add-to-favorites))
                          :options {:on-click
                                    (fn []
                                      (if favorited?
                                        (page-handler/<unfavorite-page! block-id-str)
                                     (page-handler/<favorite-page! block-id-str)))}}
                         {:title   (t :publish/dialog-title)
                          :options {:on-click #(shui/dialog-open! (fn [] (page-menu/publish-page-dialog page))
                                                                  {:class "w-auto max-w-md"})}}]))))
        page-menu-and-hr (concat page-menu [{:hr true}])
        login? (and (rfx/use-sub [:auth/id-token]) (user-handler/logged-in?))
        items (fn []
                (->>
                 [(when (state/enable-editing?)
                    {:title (t :nav/settings)
                     :options {:on-click state/open-settings!}
                     :icon (ui/icon "settings")})

                  (when config/lsp-enabled?
                    {:title (t :nav/plugins)
                     :options {:on-click #(plugin-handler/goto-plugins-dashboard!)}
                     :icon (ui/icon "apps")})

                  {:title (t :nav/appearance)
                   :options {:on-click #(state/pub-event! [:ui/toggle-appearance])}
                   :icon (ui/icon "color-swatch")}

                  (when recycle-page?
                    {:title (t :storage.recycle/title)
                     :options {:on-click page-handler/open-recycle!}
                     :icon (ui/icon "trash")})

                  (when current-repo
                    {:title (t :export/graph)
                     :options {:on-click #(shui/dialog-open! export/export)}
                     :icon (ui/icon "database-export")})

                  (when (and current-repo (state/enable-editing?))
                    {:title (t :import/title)
                     :options {:href (rfe/href :import)}
                     :icon (ui/icon "file-upload")})

                  (when config/publishing?
                    {:title (t :ui/toggle-theme)
                     :options {:on-click #(state/toggle-theme!)}
                     :icon (ui/icon "bulb")})

                  (when-not (or config/publishing? login?)
                    {:title (t :ui/login)
                     :options {:on-click #(state/pub-event! [:user/login])}
                     :icon (ui/icon "user")})

                  (when login? {:hr true})
                  (when login?
                    {:item [:span.flex.flex-col.relative.group.pt-1.w-full
                            [:b.leading-none (user-handler/username)]
                            [:small.opacity-70
                             (email-component/email-address {:email (user-handler/email)})]
                            (ui/tooltip
                             (shui/button
                              {:type "button"
                               :variant :ghost
                               :size :icon
                               :class "absolute right-1 top-3 h-auto w-auto min-w-0 border-0 bg-transparent p-0 text-red-rx-09 opacity-0 group-hover:opacity-100"
                               :aria-label (t :ui/logout)
                               :on-pointer-down stop-event!
                               :on-click (fn [e]
                                           (stop-event! e)
                                           (user-handler/logout)
                                           (shui/popup-hide!))}
                              (ui/icon "logout"))
                             (t :ui/logout))]
                     :options {:on-select (fn [^js e] (.preventDefault e))
                               :class "w-full"}})]
                 (concat page-menu-and-hr)
                 (remove nil?)))]
    (ui/tooltip
     (shui/button-ghost-icon
      :dots {:class "toolbar-dots-btn"
             :on-click (fn [^js e]
                         (shui/popup-show! (.-currentTarget e)
                                           (fn [{:keys [id]}]
                                             (for [[idx {:keys [hr item title options icon]}] (map-indexed vector (items))]
                                               (let [on-click' (:on-click options)
                                                     href (:href options)
                                                     key (or (:key options)
                                                             (str (if hr "separator-" "item-") idx))]
                                                 (if hr
                                                   (react/cloneElement
                                                    (shui/dropdown-menu-separator {})
                                                    #js {:key (str key)})
                                                   (react/cloneElement
                                                    (shui/dropdown-menu-item
                                                     (assoc options
                                                            :on-click (fn [^js e]
                                                                        (when on-click'
                                                                          (when-not (false? (on-click' e))
                                                                            (shui/popup-hide! id)))))
                                                     (or item
                                                         (if href
                                                           [:a.flex.items-center.w-full
                                                            {:href href :on-click #(shui/popup-hide! id)
                                                             :style {:color "inherit"}}
                                                            [:span.flex.items-center.gap-1.w-full
                                                             icon [:div title]]]
                                                           [:span.flex.items-center.gap-1.w-full
                                                            icon [:div title]])))
                                                    #js {:key (str key)})))))
                                           {:align "end"
                                            :as-dropdown? true
                                            :focus-trigger? false
                                            :content-props {:class "w-64"
                                                            :align-offset -32}}))})
     (t :header/more)
     {:trigger-props {:as-child true}})))

(hsx/defc toolbar-dots-menu-page
  [opts page-uuid recycle-page?]
  (let [page (db-hooks/use-block page-uuid)
        favorited? (db-hooks/use-resource [:favorite-status page-uuid])]
    (toolbar-dots-menu-content opts page favorited? recycle-page?)))

(hsx/defc toolbar-dots-menu-lookup
  [opts page-lookup recycle-page?]
  (let [page-uuid (db-hooks/use-resource [:page-identity page-lookup])]
    (if page-uuid
      (toolbar-dots-menu-page opts page-uuid recycle-page?)
      (toolbar-dots-menu-content opts nil false recycle-page?))))

(hsx/defc toolbar-dots-menu-ready
  [opts]
  (let [_route-match (rfx/use-sub [:route-match])
        current-page (sidebar/get-current-page)
        page-lookup (when current-page
                      (if (util/uuid-string? current-page)
                        (uuid current-page)
                        current-page))
        recycle-page-uuid
        (db-hooks/use-resource [:page-identity common-config/recycle-page-name])
        recycle-page? (some? recycle-page-uuid)]
    (if page-lookup
      (toolbar-dots-menu-lookup opts page-lookup recycle-page?)
      (toolbar-dots-menu-content opts nil false recycle-page?))))

(hsx/defc toolbar-dots-menu
  [opts]
  (let [db-restoring? (rfx/use-sub [:db/restoring?])]
    (if db-restoring?
      (toolbar-dots-menu-content opts nil false false)
      (toolbar-dots-menu-ready opts))))

(hsx/defc back-and-forward
  []
  [:div.flex.flex-row
   (ui/with-shortcut :go/backward "bottom"
     (shui/button-ghost-icon
      :arrow-left {:on-click #(js/window.history.back)
                   :class "it navigation nav-left"})
     (t :header/go-back))

   (ui/with-shortcut :go/forward "bottom"
     (shui/button-ghost-icon
      :arrow-right {:on-click #(js/window.history.forward)
                    :class "it navigation nav-right"})
     (t :header/go-forward))])

(hsx/defc updater-tips-new-version
  [t]
  (let [[downloaded, set-downloaded] (hooks/use-state nil)
        _ (hooks/use-effect!
           (fn []
             (when (util/electron?)
               (-> (ipc/invoke "get-downloaded-update")
                   (p/then
                    (fn [args]
                      (when args
                        (let [args (bean/->clj args)]
                          (set-downloaded args)
                          (state/set-state! :electron/auto-updater-downloaded args)))))
                   (p/catch (fn [_] nil)))
               (let [channel "auto-updater-downloaded"
                     callback (fn [_ args]
                                (js/console.debug "[new-version downloaded] args:" args)
                                (let [args (bean/->clj args)]
                                  (set-downloaded args)
                                  (state/set-state! :electron/auto-updater-downloaded args))
                                nil)]
                 (js/apis.addListener channel callback)
                 #(js/apis.removeListener channel callback))))
           [])]

    (when downloaded
      [:div.cp__header-tips
       [:p (t :updater/update-ready-to-install)
        [:a.restart.ml-2
         {:on-click #(handler/quit-and-install-new-version!)}
         (svg/reload 16) [:strong (t :updater/quit-and-install)]]]])))

(defn- clear-recent-highlight!
  []
  (let [nodes (d/by-class "recent-block")]
    (when (seq nodes)
      (doseq [node nodes]
        (d/remove-class! node "recent-block")))))

(hsx/defc recent-slider-inner
  []
  (let [[recent-days set-recent-days!] (hooks/use-state (state/get-highlight-recent-days))
        [thumb-ref set-thumb-ref!] (hooks/use-state nil)]
    (hooks/use-effect!
     (fn []
       (when thumb-ref
         (.focus ^js thumb-ref)))
     [thumb-ref])
            (hooks/use-effect!
             (fn []
               (let [all-nodes (d/by-class "ls-block")
                     node-ids (->> all-nodes
                                   (keep #(some-> (d/attr % "blockid") uuid))
                                   vec)]
                 (p/let [results (db-async/<get-blocks (state/get-current-repo) node-ids {:children? false})
                         id->block (into {} (keep (fn [{:keys [block]}]
                                                    (when-let [id (:block/uuid block)]
                                                      [id block]))
                                                  results))
                         recent-node (fn [node]
                                       (let [id (some-> (d/attr node "blockid") uuid)
                                             block (get id->block id)]
                                         (when block
                                           (t/after?
                                            (tc/from-long (:block/updated-at block))
                                            (t/ago (t/days recent-days))))))
                         recent-nodes (filter recent-node all-nodes)
                         old-nodes (remove recent-node all-nodes)]
                   (when (seq recent-nodes)
                     (doseq [node recent-nodes]
                       (d/add-class! node "recent-block")))
                   (when (seq old-nodes)
                     (doseq [node old-nodes]
                       (d/remove-class! node "recent-block")))))
               nil)
             [recent-days])
    [:div.recent-slider.flex.flex-row.gap-1.items-center
     {:class "w-[32%]"}
     (shui/slider
      {:class "relative flex w-full touch-none select-none items-center "
       :default-value #js [3 100]
       :on-value-change (fn [result]
                          (set-recent-days! (first result))
                          (state/set-highlight-recent-days! (first result)))
       :minStepsBetweenThumbs 1}
      (shui/slider-track
       {:class "relative h-2 w-full grow overflow-hidden rounded-full bg-secondary"})
      (shui/tooltip-provider
       (shui/tooltip
        (shui/tooltip-trigger
         {:as-child true
          :on-click (fn [e] (.preventDefault e))}
         (shui/slider-thumb
          {:ref set-thumb-ref!
           :class "block h-4 w-4 rounded-full border-2 border-primary bg-background ring-offset-background transition-colors focus-visible:outline-none"}))
        (shui/tooltip-content
         {:onPointerDownOutside (fn [e] (.preventDefault e))}
         (if (zero? recent-days)
           (t :header/highlight-recent-blocks)
           (t :header/highlight-recent-blocks-days-ago recent-days))))))
     (shui/button
      {:variant :ghost
       :size :sm
       :title (t :header/quit-highlight-recent-blocks)
       :class "opacity-50 hover:opacity-100"
       :on-click (fn [] (state/toggle-highlight-recent-blocks!))}
      (ui/icon "x" {:size 16}))]))

(hsx/defc recent-slider
  []
  (let [highlight? (rfx/use-sub [:ui/toggle-highlight-recent-blocks?])]
    (hooks/use-effect!
     (fn []
       (when-not highlight?
         (clear-recent-highlight!)))
     [highlight?])
    (when highlight?
      (recent-slider-inner))))

(hsx/defc ready-block-breadcrumb
  [page-uuid]
  (let [page (db-hooks/use-block page-uuid)]
    (when page
      (when (and (entity/page? page) (:block/parent page))
        [:div.ls-block-breadcrumb
         [:div.text-sm
          (component-block/breadcrumb {}
                                      (state/get-current-repo)
                                      (:block/uuid page)
                                      {:header? true
                                       :block page})]]))))

(hsx/defc block-breadcrumb
  [page-name]
  (let [db-restoring? (rfx/use-sub [:db/restoring?])]
    (when (and (false? db-restoring?)
               page-name
               (common-util/uuid-string? page-name))
      (ready-block-breadcrumb (uuid page-name)))))

(hsx/defc search-index-progress
  []
  (let [current-repo (state/get-current-repo)
        {:keys [visible? running? repo progress]} (or (rfx/use-sub [:search/index-build]) {})
        progress' (-> (or progress 0)
                      (max 0)
                      (min 100))]
    (when (and (or visible? running?) (= repo current-repo))
      [:div.search-index-progress
       (ui/loading "")
       [:span.search-index-progress__text (t :search/index-progress progress')]
       [:div.search-index-progress__bar
        [:div.search-index-progress__bar-fill {:style {:width (str progress' "%")}}]]])))

(hsx/defc ^:large-vars/cleanup-todo header-aux
  [{:keys [current-repo default-home new-block-mode]}]
  (let [electron-mac? (and util/mac? (util/electron?))
        rtc-graphs (rfx/use-sub [:rtc/graphs])
        rtc-state (rfx/use-sub [:rtc/state])
        db-rtc-uuid (use-db-rtc-uuid current-repo)
        default-home-page (get-in (state/config-for-repo (rfx/use-sub [:config])
                                                         (state/get-current-repo))
                                  [:default-home :page] "")
        left-menu (left-menu-button {:on-click (fn []
                                                 (state/set-left-sidebar-open!
                                                  (not (state/get-state :ui/left-sidebar-open?))))})
        custom-home-page? (and (state/custom-home-page?)
                               (= default-home-page (state/get-current-page)))]
    [:div.cp__header.drag-region#head
     {:class           (util/classnames [{:electron-mac   electron-mac?
                                          :native-ios     (mobile-util/native-ios?)
                                          :native-android (mobile-util/native-android?)}])
      :on-double-click (fn [^js e]
                         (when-let [target (.-target e)]
                           (cond
                             (and (util/electron?)
                                  (.. target -classList (contains "drag-region")))
                             (js/window.apis.toggleMaxOrMinActiveWindow)

                             (mobile-util/native-platform?)
                             (util/scroll-to-top true))))
      :style           {:fontSize 50}}
     [:div.l.flex.items-center.drag-region
      left-menu
      (if (mobile-util/native-platform?)
        ;; back button for mobile
        (when-not (or (state/home?) custom-home-page?)
          (ui/with-shortcut :go/backward "bottom"
            [:button.it.navigation.nav-left.button.icon.opacity-70
             {:on-click #(js/window.history.back)}
             (ui/icon "chevron-left" {:size 26})]
            (t :header/go-back)))
        ;; search button for non-mobile
        (when current-repo
          (ui/with-shortcut :go/search "right"
            (shui/button-ghost-icon
             :search {:id "search-button"
                      :data-keep-selection true
                      :on-click #(do (when (or (mobile-util/native-android?)
                                               (mobile-util/native-iphone?))
                                       (state/set-left-sidebar-open! false))
                                     (state/pub-event! [:go/search]))})
            (t :nav/search)
            {:trigger-props {:id "search-button"}})))]

     [:div.r.flex.drag-region.justify-between.items-center.gap-2.overflow-x-hidden.w-full
      [:div.flex.flex-1
       (block-breadcrumb (state/get-current-page))]
      [:div.flex.items-center
       (when (rtc-indicator-visible?
              {:current-repo current-repo
               :rtc-graphs rtc-graphs
               :db-rtc-uuid db-rtc-uuid
               :rtc-state rtc-state
               :logged-in? (user-handler/logged-in?)
               :rtc-group? (user-handler/rtc-group?)})
         [:<>
          (recent-slider)
          ^{:key (str "collab-" current-repo)}
          [rtc-collaborators]
          (rtc-indicator/indicator)])

       (when (user-handler/logged-in?)
         (rtc-indicator/downloading-detail))
       (when (user-handler/logged-in?)
         (rtc-indicator/uploading-detail))
       (search-index-progress)

       (when-let [graph (current-local-uploadable-graph db-rtc-uuid)]
         (local-graph-sync-button graph))

       (when (and (not= (state/get-current-route) :home)
                  (not custom-home-page?))
         (home-button))

       (when config/lsp-enabled?
         [:<>
          (plugins/hook-ui-items :toolbar)
          (plugins/updates-notifications)])

       (when (state/feature-http-server-enabled?)
         (server/server-indicator (rfx/use-sub [:electron/server])))

       (when (util/electron?)
         (back-and-forward))

       (when-not (mobile-util/native-platform?)
         (new-block-mode))

       (when config/publishing?
         [:a.text-sm.font-medium.button {:href (rfe/href :graph)}
          (t :nav/graph)])

       (toolbar-dots-menu {:t            t
                           :current-repo current-repo
                           :default-home default-home})

       (sidebar/toggle)

       (updater-tips-new-version t)]]]))

(hsx/defc header
  [opts]
  (let [_user-groups (rfx/use-sub [:user/info :UserGroups])
        _rtc-running? (rfx/use-sub [:rtc/state :rtc-lock])]
    (header-aux opts)))
