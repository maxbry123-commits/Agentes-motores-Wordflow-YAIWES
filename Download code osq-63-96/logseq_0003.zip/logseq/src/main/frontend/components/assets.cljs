(ns frontend.components.assets
  (:require
   [cljs-bean.core :as bean]
   [clojure.set :refer [difference]]
   [clojure.string :as string]
   [electron.ipc :as ipc]
   [frontend.components.select :as cp-select]
   [frontend.config :as config]
   [frontend.context.i18n :refer [t]]
   [frontend.handler.assets :as assets-handler]
   [frontend.handler.db-based.property :as db-property-handler]
   [frontend.handler.editor :as editor-handler]
   [frontend.handler.notification :as notification]
   [frontend.handler.route :as route-handler]
   [frontend.rfx :as rfx]
   [frontend.state :as state]
   [frontend.ui :as ui]
   [frontend.util :as util]
   [logseq.shui.hooks :as hooks]
   [logseq.shui.ui :as shui]
   [medley.core :as medley]
   [promesa.core :as p]
   [io.factorhouse.hsx.core :as hsx]))

(defn -get-all-formats
  []
  (->> (concat config/doc-formats
               config/audio-formats
               config/video-formats
               config/image-formats
               config/markup-formats)
       (map #(hash-map :id % :value (name %)))))

(hsx/defc input-auto-complete
  [{:keys [items item-cp class
           on-chosen on-keydown input-opts]}]

  (let [[*input-val, set-*input-val] (hooks/use-state (atom nil))
        [input-empty?, set-input-empty?] (hooks/use-state true)]

    (hooks/use-effect!
     #(set-input-empty? (string/blank? @*input-val))
     [@*input-val])

    (cp-select/select
     {:items          items
      :close-modal?   false
      :item-cp        item-cp
      :on-chosen      on-chosen
      :on-input       #(set-input-empty? (string/blank? %))
      :tap-*input-val #(set-*input-val %)
      :transform-fn   (fn [results]
                        (if (and *input-val
                                 (not (string/blank? @*input-val))
                                 (not (seq results)))
                          [{:id nil :value @*input-val}]
                          results))
      :host-opts      {:class (util/classnames [:cp__input-ac class {:is-empty-input input-empty?}])}
      :input-opts     (cond-> input-opts
                        (fn? on-keydown)
                        (assoc :on-key-down #(on-keydown % *input-val)))})))

(hsx/defc confirm-dir-with-alias-name
  [dir set-dir!]

  (let [[val set-val!] (hooks/use-state "")
        on-submit (fn []
                    (when-not (string/blank? val)
                      (if-not (assets-handler/get-alias-by-name val)
                        (do (set-dir! val dir nil)
                            (shui/dialog-close!))
                        (notification/show!
                         (t :asset/alias-already-exists val) :warning))))]

    [:div.cp__assets-alias-name-content
     [:h1.text-2xl.opacity-90.mb-6 (t :asset/alias-name-dialog-title)]
     [:p [:strong (t :asset/alias-directory-path-label)]
      [:a {:on-click #(when (util/electron?)
                        (js/apis.openPath dir))} dir]]
     [:p [:strong (t :asset/alias-name-label)]
      [:input.px-1.border.rounded
       {:autoFocus   true
        :value       val
        :placeholder (t :asset/alias-name-placeholder)
        :on-change   (fn [^js e]
                       (set-val! (util/trim-safe (.. e -target -value))))
        :on-key-up   (fn [^js e]
                       (when (and (= 13 (.-which e))
                                  (not (string/blank? val)))
                         (on-submit)))}]]

     [:div.pt-6.flex.justify-end
      (ui/button
       (t :ui/save)
       :disabled (string/blank? val)
       :on-click on-submit)]]))

(hsx/defc restart-button
  []
  (ui/button (t :plugin/restart)
             :on-click #(js/logseq.api.relaunch)
             :small? true :intent "logseq"))

(hsx/defc ^:large-vars/data-var alias-directories
  []
  (let [[ext-editing-dir set-ext-editing-dir!] (hooks/use-state nil)
        directories      (into [] (rfx/use-sub [:assets/alias-dirs]))
        pick-exist       assets-handler/get-alias-by-dir
        set-dir!         (fn [name dir exts]
                           (when (and name dir)
                             (state/set-assets-alias-dirs!
                              (let [exist (pick-exist dir)]
                                (if exist
                                  (assoc directories (first exist) {:name name :dir dir :exts (set exts)})
                                  (conj directories {:dir dir :name name :exts (set exts)}))))))

        rm-dir           (fn [dir]
                           (when-let [exist (pick-exist dir)]
                             (state/set-assets-alias-dirs!
                              (medley/remove-nth (first exist) directories))))

        del-ext          (fn [dir ext]
                           (when-let [exist (and ext (pick-exist dir))]
                             (let [exts (:exts (second exist))
                                   exts (difference exts (hash-set ext))
                                   name (:name (second exist))]
                               (set-dir! name dir exts))))

        add-ext          (fn [dir ext]
                           (when-let [exist (and ext (pick-exist dir))]
                             (let [exts (:exts (second exist))
                                   exts (conj exts (util/safe-lower-case ext))
                                   name (:name (second exist))]
                               (set-dir! name dir exts))))

        confirm-dir      (fn [dir set-dir!]
                           (shui/dialog-open!
                            #(confirm-dir-with-alias-name dir set-dir!)))]

    [:div.cp__assets-alias-directories
     [:ul
      (for [{:keys [name dir exts]} directories]
        [:li.item.px-2.py-2
         [:div.flex.justify-between.items-center
          [:span.font-semibold
           (str "@" name)]

          [:div.flex.items-center.space-x-2
           [:a.opacity-90.active:opacity-50.text-sm.flex.space-x-1
            {:on-click #(when (util/electron?)
                          (js/apis.openPath dir))}
            (ui/icon "folder") dir]]]

         [:div.flex.justify-between.items-center
          [:div.flex.mt-2.space-x-2.pr-6
           (for [ext exts]
             [:small.ext-label.is-del
              {:key ext :on-click #(del-ext dir ext)}
              [:span ext]
              (ui/icon "circle-minus")])
           (if (= dir ext-editing-dir)
             (input-auto-complete
              {:items        (-get-all-formats)

               :close-modal? false
               :item-cp      (fn [{:keys [value]}]
                               [:div.ext-select-item value])

               :on-chosen    (fn [{:keys [value]}]
                               (add-ext dir value)
                               (set-ext-editing-dir! nil))
               :on-keydown   (fn [^js e *input-val]
                               (let [^js input (.-target e)]
                                 (case (.-which e)
                                   27                       ;; esc
                                   (do (if-not (string/blank? (.-value input))
                                         (reset! *input-val "")
                                         (set-ext-editing-dir! nil))
                                       (util/stop e))

                                   :dune)))
                              :input-opts   {:class       "cp__assets-alias-ext-input"
                              :placeholder (t :asset/file-extension-placeholder)
                              :on-blur
                              #(set-ext-editing-dir! nil)}})

             [:small.ext-label.is-plus
              {:on-click #(set-ext-editing-dir! dir)}
              (ui/icon "plus") (t :asset/acceptable-file-extensions)])]

          [:span.ctrls.flex.space-x-3.text-xs.opacity-30.hover:opacity-100.whitespace-nowrap.hidden.mt-1
           [:a {:on-click #(rm-dir dir)} (ui/icon "trash-x")]]]])]

     [:p.pt-2
      (ui/button
       (t :asset/add-directory)
       :on-click #(p/let [path (ipc/ipc :openDialog)]
                    (when-not (or (string/blank? path)
                                  (pick-exist path))
                      (confirm-dir path set-dir!)))
       :small? true)]]))

(hsx/defc settings-content
  []
  (let [alias-enabled?         (rfx/use-sub [:assets/alias-enabled?])
        [pre-alias-enabled?]   (hooks/use-state alias-enabled?)
        alias-enabled-changed? (not= pre-alias-enabled? alias-enabled?)]

    [:div.cp__assets-settings.panel-wrap
     [:div.it
      [:label.block.text-sm.font-medium.leading-5.opacity-70
      (t :asset/alias-directories)]
      [:div (ui/toggle
             alias-enabled?
             #(state/set-assets-alias-enabled! (not alias-enabled?))
             true)]
      [:span
       (when alias-enabled-changed? (restart-button))]]

     (when alias-enabled?
       [:div.pt-4
        [:h2.font-bold.opacity-80 (t :asset/selected-directories)]
        (alias-directories)])]))

(hsx/defc edit-external-url-form
  [asset-block {:keys [url title on-saved]}]
  (let [[saving? set-saving?] (hooks/use-state false)
        create? (nil? asset-block)]
    [:form.pt-3.flex.flex-col.gap-2
     {:on-submit (fn [^js e]
                   (.preventDefault e)
                   (let [^js form-data (js/FormData. (.-currentTarget e))
                         repo (state/get-current-repo)
                         title (.get form-data "title")
                         src (.get form-data "src")
                         err-handle (fn [^js e]
                                      (js/console.error e)
                                      (notification/show! (str e)))]
                     (if create?
                       (-> (do (set-saving? true)
                               (editor-handler/db-based-save-assets! repo [{:title title :src src}]))
                           (p/then (fn [res]
                                     (when-let [asset-block (some-> (seq res) (first))]
                                       (when on-saved (on-saved asset-block)))))
                           (p/catch err-handle)
                           (p/finally #(set-saving? false)))
                       ;; update asset block
                       (-> (do (set-saving? true)
                               (p/all
                                [(editor-handler/save-block-if-changed! asset-block title)
                                 (p/let [src (util/trim-safe src)
                                         checksum (assets-handler/get-file-checksum src)]
                                   (db-property-handler/set-block-properties!
                                    (:db/id asset-block)
                                    {:logseq.property.asset/external-url src
                                     :logseq.property.asset/checksum checksum}))]))
                           (p/then #(when on-saved (on-saved asset-block false)))
                           (p/catch err-handle)
                           (p/finally #(set-saving? false))))))}
     [:label [:span.block.pb-2.text-sm.opacity-60 (t :asset/title-label)]
      (shui/input {:small true :default-value title :name "title"})]
     [:label [:span.block.pb-2.text-sm.opacity-60 (t :asset/external-url-label)]
      [:span.flex.items-center.gap-2
       (shui/input {:small true :default-value url :name "src"})
       (when (util/electron?)
         (shui/button
          {:size "sm" :variant :secondary :class "h-8"
           :on-click (fn [^js e]
                       (.preventDefault e)
                       (p/let [^js ret (ipc/ipc :showOpenDialog {:properties ["openFile"]
                                                                 :title (t :asset/select-file)})]
                         (let [file-path (some-> ret (bean/->clj) :filePaths (first))]
                           (when (not (string/blank? file-path))
                             (let [^js input (-> (.-target e) (.closest "form") (.querySelector "input[name='src']"))]
                               (set! (.-value input) file-path))))))}
          (t :asset/select-from-disk)))]]
     [:div.flex.justify-end.pt-3
      (ui/button (if create? (t :ui/create) (t :ui/save)) {:disabled saving?})]]))

(hsx/defc edit-external-url-content
  [asset-block pdf-current]
  [:div.edit-external-url-content
   (let [on-saved! (fn [asset-block update?]
                     (when-let [uuid' (and pdf-current (:block/uuid asset-block))]
                       (when pdf-current (state/set-current-pdf! nil))
                       (when (not update?) (route-handler/redirect-to-page! uuid')))
                     (shui/dialog-close!))]
     (if asset-block
       [:div.pb-2.-mt-2
        (let [url (:logseq.property.asset/external-url asset-block)
              title (:block/title asset-block)]
          (edit-external-url-form asset-block {:url url :title title :on-saved on-saved!}))]

       (when-let [url (:url pdf-current)]
         [:div.pb-2
          (shui/alert
           {:variant "warning"}
           (shui/alert-description
            (t :asset/create-local-copy-warning)))

          (let [title (util/node-path.basename url)]
            (edit-external-url-form asset-block {:url url :title title :on-saved on-saved!}))])))])
