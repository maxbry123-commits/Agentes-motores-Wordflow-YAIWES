(ns frontend.mobile.intent
  (:require ["/frontend/utils" :as utils]
            ["@capacitor/action-sheet" :refer [ActionSheet]]
            ["@capacitor/filesystem" :refer [Filesystem]]
            ["@capacitor/share" :refer [^js Share]]
            ["path" :as node-path]
            ["send-intent" :refer [^js SendIntent]]
            [clojure.pprint :as pprint]
            [clojure.set :as set]
            [clojure.string :as string]
            [frontend.config :as config]
            [frontend.context.i18n :refer [interpolate-rich-text-node t]]
            [frontend.date :as date]
            [frontend.db.async :as db-async]
            [frontend.handler.assets :as assets-handler]
            [frontend.handler.editor :as editor-handler]
            [frontend.handler.notification :as notification]
            [frontend.mobile.util :as mobile-util]
            [frontend.state :as state]
            [frontend.util :as util]
            [goog.string :as gstring]
            [lambdaisland.glogi :as log]
            [logseq.common.util :as common-util]
            [promesa.core :as p]))

(defn- normalize-native-file-path
  "Normalize iOS shared file URLs to paths that Capacitor Filesystem can read.
  iOS share extensions commonly provide `file://` URLs."
  [url]
  (let [url (some-> url common-util/safe-decode-uri-component)]
    (cond
      (string/blank? url)
      url

      (string/starts-with? url "file://")
      (subs url (count "file://"))

      ;; Some Capacitor APIs may provide `_capacitor_file_` URLs.
      (string/starts-with? url "capacitor://localhost/_capacitor_file_")
      (string/replace url "capacitor://localhost/_capacitor_file_" "")

      :else
      url)))

(defn- <filesystem-read-file
  [url]
  (let [path (normalize-native-file-path url)]
    (-> (.readFile Filesystem #js {:path path})
        (p/catch (fn [error]
                   ;; Fallback to the original string for older plugin versions.
                   (if (= path url)
                     (p/rejected error)
                     (.readFile Filesystem #js {:path url})))))))

(defn open-or-share-file
  "Share file to mobile platform"
  [uri]
  (p/let [options [{:title (t :ui/open)
                    :style "DEFAULT"}
                   {:title (t :mobile.intent/share)}
                   {:title (t :ui/cancel)
                    :style "CANCEL"}]
          result (.showActions ActionSheet (clj->js {:title (t :mobile.intent/file-options)
                                                     :message (t :mobile.intent/select-option-prompt)
                                                     :options options}))
          index (.-index result)]

    (when (not= index 2)
      (if (and (= index 0) (mobile-util/native-android?))
        (.openFile mobile-util/folder-picker (clj->js {:uri uri}))
        (.share Share (clj->js {:url uri
                                :dialogTitle (t :mobile.intent/open-with-app)
                                :title (t :mobile.intent/open-with-app)}))))))

(defn- is-link
  [url]
  (when (not-empty url)
    (re-matches #"^[a-zA-Z0-9]+://.*$" url)))

(defn- extract-highlight
  "Extract highlighted text and url from mobile browser intent share.
   - url can be prefixed with the highlighted text.
   - url can be highlighted text only in some cases."
  [url]
  (let [[_ link] (re-find #"\s+([a-zA-Z0-9]+://[\S]*)$" url)
        highlight (when (not-empty link)
                    (let [quoted (string/replace url link "")
                          quoted (gstring/trimRight quoted)]
                      (gstring/stripQuotes quoted "\"")))]
    (cond
      (not-empty highlight)
      [highlight link]

      (is-link url)
      [nil url]

      :else
      [url nil])))

(defn- transform-args
  [args]
  (let [{:keys [url]} args]
    (if (is-link url)
      args
      (let [[highlight url'] (extract-highlight url)]
        (assoc args :url url' :content highlight)))))

(defn- handle-received-text [args]
  ;; Keys: :title :type :url
  ;; :content is added if there's highlighted text
  (let [args (transform-args args)]
    (state/pub-event! [:editor/quick-capture args])))

(defn- embed-asset-file [url _format]
  (p/let [basename (node-path/basename url)
          file (<filesystem-read-file url)
          file-base64-str (some-> file (.-data))
          file (some-> file-base64-str (utils/base64ToUint8Array)
                       (vector) (clj->js) (js/File. basename #js {}))
          result (editor-handler/db-based-save-assets!
                  (state/get-current-repo) [file] {})]
    (first result)))

(defn- handle-received-media [result]
  (p/let [{:keys [url]} result
          format :markdown]
    (-> (embed-asset-file url format)
        (p/catch (fn [error]
                   (log/error :share-import-media-failed {:error error :url url})
                   (notification/show! (t :mobile.share/media-import-error) :error false))))))

(defn- handle-received-application [result]
  (p/let [{:keys [url type]} result
          today-page-title (db-async/<get-today-journal-title (state/get-current-repo))
          page (or (state/get-current-page) (string/lower-case today-page-title))
          format :markdown
          application-type (last (string/split type "/"))
          content (cond
                    (contains? (set/union config/doc-formats config/media-formats)
                               (keyword application-type))
                    (do
                      (embed-asset-file url format)
                      nil)

                    :else
                    (notification/show!
                     [:div
                      (interpolate-rich-text-node
                       (t :mobile.share/unsupported-import-type)
                       [application-type
                        [:a {:href "https://github.com/logseq/db-test/issues"
                             :target "_blank"} "GitHub"]])]
                     :warning false))]
    (when content
      (if (state/get-edit-block)
        (editor-handler/insert content)
        (editor-handler/api-insert-new-block! content {:page page
                                                       :edit-block? false
                                                       :replace-empty-target? true})))))

(defn decode-received-result [m]
  (into {} (for [[k v] m]
             [k (cond (vector? v)
                      (vec (map decode-received-result v))

                      (string/blank? v)
                      nil

                      :else
                      (if (mobile-util/native-ios?)
                        (common-util/safe-decode-uri-component v)
                        v))])))

(defn- handle-asset-file [url _format]
  (-> (p/let [basename (node-path/basename url)
              _label (-> basename util/node-path.name)
              _path (assets-handler/get-asset-path basename)
              file (<filesystem-read-file url)
              file-base64-str (some-> file (.-data))
              file (some-> file-base64-str (utils/base64ToUint8Array)
                           (vector) (clj->js) (js/File. basename #js {}))
              result (editor-handler/db-based-save-assets!
                      (state/get-current-repo) [file] {})]
        result)
      (p/catch (fn [error]
                 (log/error :handle-asset-file {:error error :url url})
                 (notification/show! (t :mobile.share/file-import-error) :error false)))))

(defn- handle-payload-resource
  [{:keys [type name ext url] :as resource} format]
  (if url
    (cond
      (contains? (set/union config/doc-formats config/media-formats)
                 (keyword ext))
      (handle-asset-file url format)

      :else
      (notification/show!
       [:div
        (interpolate-rich-text-node
         (t :mobile.share/unsupported-content-warning)
         [[:a {:href "https://github.com/logseq/db-test/issues/new?labels=from:in-app&template=bug_report.yaml"
               :target "_blank"} "GitHub"]])
        [:pre.code (with-out-str (pprint/pprint resource))]] :warning false))

    (cond
      (= type "text/plain")
      name

      :else
      (notification/show!
       [:div
        (interpolate-rich-text-node
         (t :mobile.share/unsupported-content-warning)
         [[:a {:href "https://github.com/logseq/db-test/issues/new?labels=from:in-app&template=bug_report.yaml"
               :target "_blank"} "GitHub"]])
        [:pre.code (with-out-str (pprint/pprint resource))]] :warning false))))

(defn handle-payload
  "Mobile share intent handler v2, use complex payload to support more types of content."
  [payload]
  ;; use :text template, use {url} as rich text placeholder
  (p/let [today-page-title (db-async/<get-today-journal-title (state/get-current-repo))
          page (or (state/get-current-page) (string/lower-case today-page-title))
          format :markdown

          template (get-in (state/get-config)
                           [:quick-capture-templates :text]
                           "**{time}** [[quick capture]]​ {text} {url}")
          {:keys [text resources]} payload
          text (or text "")
          rich-content (-> (p/all (map (fn [resource]
                                         (handle-payload-resource resource format))
                                       resources))
                           (p/then (fn [result]
                                     (when (every? string? result)
                                       (string/join "\n" result)))))]
    (when (and (or (not-empty text) (not-empty rich-content))
               (not (every?
                     (fn [resource]
                       (contains? (set/union config/doc-formats config/media-formats)
                                  (keyword (:ext resource))))
                     resources)))
      (let [time (date/get-current-time)
            date-ref-name today-page-title
            content (-> template
                        (string/replace "{time}" time)
                        (string/replace "{date}" date-ref-name)
                        (string/replace "{text}" text)
                        (string/replace "{url}" rich-content))
            edit-content (state/get-edit-content)
            edit-content-blank? (string/blank? edit-content)
            edit-content-include-capture? (and (not-empty edit-content)
                                               (string/includes? edit-content "[[quick capture]]"))]
        (if (and (state/editing?) (not edit-content-include-capture?))
          (if edit-content-blank?
            (editor-handler/insert content)
            (editor-handler/insert (str "\n" content)))

          (do
            (editor-handler/escape-editing)
            (js/setTimeout #(editor-handler/api-insert-new-block! content {:page page
                                                                           :edit-block? true
                                                                           :replace-empty-target? true})
                           100)))))))

(defn handle-result
  "Mobile share intent handler v1, legacy. Only for Android"
  [result]
  (let [result (decode-received-result result)]
    (when-let [type (:type result)]
      (cond
        (string/starts-with? type "text/")
        (handle-received-text result)

        (or (string/starts-with? type "image/")
            (string/starts-with? type "video/")
            (string/starts-with? type "audio/"))
        (handle-received-media result)

        (string/starts-with? type "application/")
        (handle-received-application result)

        :else
        (notification/show!
         [:div
          (interpolate-rich-text-node
           (t :mobile.share/unsupported-content-warning)
           [[:a {:href "https://github.com/logseq/db-test/issues/new?labels=from:in-app&template=bug_report.yaml"
                 :target "_blank"} "GitHub"]])
          [:pre.code (with-out-str (pprint/pprint result))]] :warning false)))))

(defn handle-received []
  (p/let [received (p/catch
                    (.checkSendIntentReceived SendIntent)
                    (fn [error]
                      (prn :intent-received-error {:error error})))]
    (when received
      (let [result (js->clj received :keywordize-keys true)]
        (handle-result result)))))
