/*
 * Copyright 2026 Conductor Authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package org.conductoross.conductor.dao;

import java.util.List;
import java.util.Optional;

/**
 * Persistence for Conductor-Agents skill <b>metadata</b>: the per-version manifest plus a per-skill
 * "latest" pointer. Skill package <b>bytes</b> are stored separately via {@link SkillPackageDAO}.
 *
 * <p>This DAO is the Conductor-native backing store for Conductor-Agents' {@code
 * dev.agentspan.runtime.spi.SkillMetadataDAO} SPI; an adapter in the {@code conductor-ai} module
 * bridges the two so skills persist through whichever Conductor backend is configured (Postgres,
 * MySQL, SQLite, Redis). It deliberately stores the manifest as an opaque JSON document ({@code
 * detailJson}) so the persistence layer carries no dependency on Conductor-Agents model types.
 *
 * <p>Skills share a single global namespace (OSS Conductor is single-tenant). Authorization
 * (whether the caller may read a given skill) is the caller's concern, not this DAO's. Implemented
 * per supported DB.
 */
public interface SkillMetadataDAO {

    /**
     * Inserts or replaces the metadata for a single skill version (keyed by {@code name +
     * version}). When {@code makeLatest} is {@code true}, this version becomes the skill's recorded
     * latest and any previously-latest version for the same {@code name} is cleared.
     *
     * @param detailJson the serialized skill manifest/detail document
     * @param createdAt epoch milliseconds the version was first created (may be {@code null})
     * @param updatedAt epoch milliseconds of this write (may be {@code null})
     */
    void save(
            String name,
            String version,
            boolean makeLatest,
            String detailJson,
            Long createdAt,
            Long updatedAt);

    /** Exact-version lookup; returns the stored {@code detailJson} or empty when absent. */
    Optional<String> find(String name, String version);

    /** The recorded latest version string for a skill, if any. */
    Optional<String> latestVersion(String name);

    /** The stored {@code detailJson} for every recorded version of a single skill (unordered). */
    List<String> listVersions(String name);

    /**
     * The stored {@code detailJson} for all skills. When {@code allVersions} is {@code false},
     * returns only each skill's latest version; when {@code true}, returns every version of every
     * skill.
     */
    List<String> list(boolean allVersions);

    /** Removes a single version and recomputes the skill's latest pointer when needed. */
    void delete(String name, String version);
}
