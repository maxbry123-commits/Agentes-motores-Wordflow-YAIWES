import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import { Suspense, useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { queryKeyFactory as artifactsQueryKeyFactory } from "@/api/artifacts";
import {
	buildGetFlowRunDetailsQuery,
	queryKeyFactory as flowRunsQueryKeyFactory,
	isPendingLikeState,
	isTerminalState,
	useDeleteFlowRun,
} from "@/api/flow-runs";
import { queryKeyFactory as logsQueryKeyFactory } from "@/api/logs";
import { queryKeyFactory as taskRunsQueryKeyFactory } from "@/api/task-runs";
import { FlowRunGraph } from "@/components/flow-runs/flow-run-graph";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ErrorBoundary } from "@/components/ui/error-boundary";
import { Icon } from "@/components/ui/icons";
import { LazyJsonInput } from "@/components/ui/json-input-lazy";
import { Skeleton } from "@/components/ui/skeleton";
import { TabErrorState } from "@/components/ui/tab-error-state";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useStateFavicon } from "@/hooks/use-state-favicon";
import { FlowRunArtifacts } from "./flow-run-artifacts";
import { FlowRunDetails } from "./flow-run-details";
import { FlowRunHeader } from "./flow-run-header";
import { FlowRunLogs } from "./flow-run-logs";
import { FlowRunSubflows } from "./flow-run-subflows";
import { FlowRunTaskRuns } from "./flow-run-task-runs";

type FlowRunDetailsTabOptions =
	| "Logs"
	| "TaskRuns"
	| "SubflowRuns"
	| "Artifacts"
	| "Details"
	| "Parameters"
	| "JobVariables";

type FlowRunDetailsPageProps = {
	id: string;
	tab: FlowRunDetailsTabOptions;
	onTabChange: (tab: FlowRunDetailsTabOptions) => void;
};

export const FlowRunDetailsPage = ({
	id,
	tab,
	onTabChange,
}: FlowRunDetailsPageProps) => {
	const [refetchInterval, setRefetchInterval] = useState<number | false>(false);
	const [fullscreen, setFullscreen] = useState(false);
	const queryClient = useQueryClient();
	const { data: flowRun } = useSuspenseQuery({
		...buildGetFlowRunDetailsQuery(id),
		refetchInterval,
	});
	const { deleteFlowRun } = useDeleteFlowRun();
	const { navigate } = useRouter();
	const isPending = isPendingLikeState(flowRun.state_type, flowRun.state_name);

	// Set favicon based on flow run state
	useStateFavicon(flowRun?.state_type);

	useEffect(() => {
		setRefetchInterval(isTerminalState(flowRun.state_type) ? false : 5000);
	}, [flowRun]);

	const onDeleteRunClicked = () => {
		deleteFlowRun(flowRun.id, {
			onSuccess: () => {
				setRefetchInterval(false);
				toast.success("Flow run deleted");
				void navigate({ to: "/runs", replace: true });
			},
			onError: (error) => {
				const message =
					error.message || "Unknown error while deleting flow run.";
				toast.error(message);
			},
		});
	};

	const retryLogs = useCallback(() => {
		void queryClient.invalidateQueries({
			queryKey: logsQueryKeyFactory.all(),
		});
	}, [queryClient]);

	const retryTaskRuns = useCallback(() => {
		void queryClient.invalidateQueries({
			queryKey: taskRunsQueryKeyFactory.all(),
		});
	}, [queryClient]);

	const retrySubflows = useCallback(() => {
		void queryClient.invalidateQueries({
			queryKey: flowRunsQueryKeyFactory.lists(),
		});
	}, [queryClient]);

	const retryArtifacts = useCallback(() => {
		void queryClient.invalidateQueries({
			queryKey: artifactsQueryKeyFactory.all(),
		});
	}, [queryClient]);

	return (
		<div className="flex flex-col gap-4">
			<div className="flex flex-col gap-2">
				<FlowRunHeader flowRun={flowRun} onDeleteClick={onDeleteRunClicked} />
			</div>
			{!isPending && (
				<Card className="py-0">
					<CardContent className="p-0">
						<FlowRunGraph
							flowRunId={flowRun.id}
							stateType={flowRun.state_type ?? undefined}
							fullscreen={fullscreen}
							onFullscreenChange={setFullscreen}
						/>
					</CardContent>
				</Card>
			)}
			<div className="flex flex-col gap-4">
				<TabsLayout
					currentTab={tab}
					onTabChange={onTabChange}
					isPending={isPending}
					logsContent={
						<ErrorBoundary
							fallback={
								<TabErrorState
									error={{
										type: "unknown-error",
										message: "Failed to load logs",
										details:
											"An error occurred while loading log data. Please try again.",
									}}
									onRetry={retryLogs}
								/>
							}
						>
							<Suspense fallback={<LogsSkeleton />}>
								<FlowRunLogs flowRun={flowRun} />
							</Suspense>
						</ErrorBoundary>
					}
					taskRunsContent={
						<ErrorBoundary
							fallback={
								<TabErrorState
									error={{
										type: "unknown-error",
										message: "Failed to load task runs",
										details:
											"An error occurred while loading task run data. Please try again.",
									}}
									onRetry={retryTaskRuns}
								/>
							}
						>
							<Suspense fallback={<TaskRunsSkeleton />}>
								<FlowRunTaskRuns flowRunId={id} />
							</Suspense>
						</ErrorBoundary>
					}
					subflowRunsContent={
						<ErrorBoundary
							fallback={
								<TabErrorState
									error={{
										type: "unknown-error",
										message: "Failed to load subflow runs",
										details:
											"An error occurred while loading subflow run data. Please try again.",
									}}
									onRetry={retrySubflows}
								/>
							}
						>
							<Suspense fallback={<SubflowsSkeleton />}>
								<FlowRunSubflows parentFlowRunId={id} />
							</Suspense>
						</ErrorBoundary>
					}
					artifactsContent={
						<ErrorBoundary
							fallback={
								<TabErrorState
									error={{
										type: "unknown-error",
										message: "Failed to load artifacts",
										details:
											"An error occurred while loading artifact data. Please try again.",
									}}
									onRetry={retryArtifacts}
								/>
							}
						>
							<Suspense fallback={<ArtifactsSkeleton />}>
								<FlowRunArtifacts flowRun={flowRun} />
							</Suspense>
						</ErrorBoundary>
					}
					detailsContent={
						<Suspense fallback={<DetailsSkeleton />}>
							<FlowRunDetails flowRun={flowRun} />
						</Suspense>
					}
					parametersContent={
						<div className="space-y-4">
							<div className="flex justify-end">
								<Button
									variant="outline"
									size="sm"
									onClick={() => {
										toast.success("Copied parameters to clipboard");
										void navigator.clipboard.writeText(
											JSON.stringify(flowRun.parameters ?? {}, null, 2),
										);
									}}
								>
									<Icon id="Copy" className="size-4 mr-2" />
									Copy parameters
								</Button>
							</div>
							<LazyJsonInput
								value={JSON.stringify(flowRun.parameters ?? {}, null, 2)}
								disabled
							/>
						</div>
					}
					jobVariablesContent={
						<div className="space-y-4">
							<div className="flex justify-end">
								<Button
									variant="outline"
									size="sm"
									onClick={() => {
										toast.success("Copied job variables to clipboard");
										void navigator.clipboard.writeText(
											JSON.stringify(flowRun.job_variables ?? {}, null, 2),
										);
									}}
								>
									<Icon id="Copy" className="size-4 mr-2" />
									Copy job variables
								</Button>
							</div>
							<LazyJsonInput
								value={JSON.stringify(flowRun.job_variables ?? {}, null, 2)}
								disabled
							/>
						</div>
					}
				/>
			</div>
		</div>
	);
};

const TabsLayout = ({
	currentTab,
	onTabChange,
	isPending,
	logsContent,
	taskRunsContent,
	subflowRunsContent,
	artifactsContent,
	detailsContent,
	parametersContent,
	jobVariablesContent,
}: {
	currentTab: FlowRunDetailsTabOptions;
	onTabChange: (tab: FlowRunDetailsTabOptions) => void;
	isPending: boolean;
	logsContent: React.ReactNode;
	taskRunsContent: React.ReactNode;
	subflowRunsContent: React.ReactNode;
	artifactsContent: React.ReactNode;
	detailsContent: React.ReactNode;
	parametersContent: React.ReactNode;
	jobVariablesContent: React.ReactNode;
}) => {
	return (
		<Tabs
			value={currentTab}
			onValueChange={(value) => onTabChange(value as FlowRunDetailsTabOptions)}
		>
			<TabsList>
				<TabsTrigger value="Details">Details</TabsTrigger>
				<TabsTrigger value="Logs">Logs</TabsTrigger>
				{!isPending && <TabsTrigger value="TaskRuns">Task Runs</TabsTrigger>}
				{!isPending && (
					<TabsTrigger value="SubflowRuns">Subflow Runs</TabsTrigger>
				)}
				{!isPending && <TabsTrigger value="Artifacts">Artifacts</TabsTrigger>}
				<TabsTrigger value="Parameters">Parameters</TabsTrigger>
				<TabsTrigger value="JobVariables">Job Variables</TabsTrigger>
			</TabsList>
			<TabsContent value="Details">{detailsContent}</TabsContent>
			<TabsContent value="Logs">{logsContent}</TabsContent>
			<TabsContent value="TaskRuns">{taskRunsContent}</TabsContent>
			<TabsContent value="SubflowRuns">{subflowRunsContent}</TabsContent>
			<TabsContent value="Artifacts">{artifactsContent}</TabsContent>
			<TabsContent value="Parameters">{parametersContent}</TabsContent>
			<TabsContent value="JobVariables">{jobVariablesContent}</TabsContent>
		</Tabs>
	);
};

const LogsSkeleton = () => {
	return (
		<div className="flex flex-col gap-2">
			<div className="flex flex-row gap-2 justify-end">
				<Skeleton className="h-8 w-25" />
				<Skeleton className="h-8 w-32" />
				<Skeleton className="h-8 w-8" /> {/* Download button placeholder */}
			</div>
			<Skeleton className="h-32" />
		</div>
	);
};

const TaskRunsSkeleton = () => {
	return (
		<div className="flex flex-col gap-4">
			<div className="flex items-center justify-between">
				<Skeleton className="h-4 w-24" />
			</div>
			<div className="flex flex-col sm:flex-row gap-2">
				<Skeleton className="h-9 flex-1" />
				<div className="flex gap-2">
					<Skeleton className="h-9 w-48" />
					<Skeleton className="h-9 w-40" />
				</div>
			</div>
			<div className="flex flex-col gap-2">
				<Skeleton className="h-24" />
				<Skeleton className="h-24" />
				<Skeleton className="h-24" />
			</div>
		</div>
	);
};

const ArtifactsSkeleton = () => {
	return (
		<div className="flex flex-col gap-2">
			<div className="flex flex-row justify-end">
				<Skeleton className="h-8 w-12" />
			</div>
			<div className="grid grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
				<Skeleton className="h-40" />
				<Skeleton className="h-40" />
				<Skeleton className="h-40" />
				<Skeleton className="h-40" />
			</div>
		</div>
	);
};

const SubflowsSkeleton = () => {
	return (
		<div className="flex flex-col gap-4">
			<div className="flex items-center justify-between">
				<Skeleton className="h-4 w-24" />
			</div>
			<div className="flex flex-col sm:flex-row gap-2">
				<Skeleton className="h-9 flex-1" />
				<div className="flex gap-2">
					<Skeleton className="h-9 w-48" />
					<Skeleton className="h-9 w-40" />
				</div>
			</div>
			<div className="flex flex-col gap-2">
				<Skeleton className="h-24" />
				<Skeleton className="h-24" />
				<Skeleton className="h-24" />
			</div>
		</div>
	);
};

const DetailsSkeleton = () => {
	return (
		<div className="space-y-4">
			<div className="flex flex-col gap-1">
				<Skeleton className="h-4 w-20" />
				<Skeleton className="h-5 w-12" />
			</div>
			<div className="flex flex-col gap-1">
				<Skeleton className="h-4 w-16" />
				<Skeleton className="h-5 w-32" />
			</div>
			<div className="flex flex-col gap-1">
				<Skeleton className="h-4 w-24" />
				<Skeleton className="h-5 w-32" />
			</div>
			<div className="flex flex-col gap-1">
				<Skeleton className="h-4 w-24" />
				<Skeleton className="h-5 w-64" />
			</div>
		</div>
	);
};
