#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import threading
import time
from contextlib import suppress
from importlib import import_module
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, call, mock_open, patch
from uuid import uuid4

import pendulum
import pytest
from sqlalchemy import Column, Integer, MetaData, Table, func, inspect, literal, select, text
from sqlalchemy.exc import IntegrityError, OperationalError, SQLAlchemyError
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm import Session

from airflow import DAG
from airflow._shared.timezones import timezone
from airflow.exceptions import AirflowException
from airflow.models import DagModel, DagRun, TaskInstance
from airflow.models.dag_version import DagVersion
from airflow.models.dagbundle import DagBundleModel
from airflow.models.serialized_dag import SerializedDagModel
from airflow.models.task_state_store import TaskStateStoreModel
from airflow.providers.standard.operators.python import PythonOperator
from airflow.serialization.serialized_objects import LazyDeserializedDAG
from airflow.utils.db_cleanup import (
    ARCHIVE_TABLE_PREFIX,
    CreateTableAs,
    _build_query,
    _cleanup_table,
    _confirm_drop_archives,
    _do_delete,
    _dump_table_to_file,
    _get_archived_table_names,
    _TableConfig,
    config_dict,
    drop_archived_tables,
    export_archived_records,
    run_cleanup,
)
from airflow.utils.session import create_session
from airflow.utils.types import DagRunType

from tests_common.test_utils.db import (
    clear_db_assets,
    clear_db_dag_bundles,
    clear_db_dags,
    clear_db_runs,
    drop_tables_with_prefix,
)
from tests_common.test_utils.taskinstance import create_task_instance

pytestmark = pytest.mark.db_test


@pytest.fixture(autouse=True)
def clean_database():
    """Fixture that cleans the database before and after every test."""
    clear_db_runs()
    clear_db_assets()
    clear_db_dags()
    clear_db_dag_bundles()
    yield  # Test runs here
    clear_db_dags()
    clear_db_assets()
    clear_db_runs()
    clear_db_dag_bundles()


class TestDBCleanup:
    @pytest.fixture(autouse=True)
    def clear_airflow_tables(self):
        drop_tables_with_prefix("_airflow_")

    @pytest.mark.parametrize(
        ("kwargs", "called"),
        [
            pytest.param(dict(confirm=True), True, id="true"),
            pytest.param(dict(), True, id="not supplied"),
            pytest.param(dict(confirm=False), False, id="false"),
        ],
    )
    @patch("airflow.utils.db_cleanup._cleanup_table", new=MagicMock())
    @patch("airflow.utils.db_cleanup._confirm_delete")
    def test_run_cleanup_confirm(self, confirm_delete_mock, kwargs, called):
        """Test that delete confirmation input is called when appropriate"""
        run_cleanup(
            clean_before_timestamp=None,
            table_names=None,
            dry_run=None,
            verbose=None,
            **kwargs,
        )
        if called:
            confirm_delete_mock.assert_called()
        else:
            confirm_delete_mock.assert_not_called()

    @pytest.mark.parametrize(
        ("kwargs", "should_skip"),
        [
            pytest.param(dict(skip_archive=True), True, id="true"),
            pytest.param(dict(), False, id="not supplied"),
            pytest.param(dict(skip_archive=False), False, id="false"),
        ],
    )
    @patch("airflow.utils.db_cleanup._cleanup_table")
    def test_run_cleanup_skip_archive(self, cleanup_table_mock, kwargs, should_skip):
        """Test that delete confirmation input is called when appropriate"""
        run_cleanup(
            clean_before_timestamp=None,
            table_names=["log"],
            dry_run=None,
            verbose=None,
            confirm=False,
            **kwargs,
        )
        assert cleanup_table_mock.call_args.kwargs["skip_archive"] is should_skip

    @patch("airflow.utils.db_cleanup._cleanup_table")
    def test_run_cleanup_batch_size_propagation(self, cleanup_table_mock):
        """Ensure batch_size is forwarded from run_cleanup to _cleanup_table."""
        run_cleanup(
            clean_before_timestamp=None,
            table_names=["log"],
            dry_run=None,
            verbose=None,
            confirm=False,
            batch_size=1234,
        )
        cleanup_table_mock.assert_called_once()
        assert cleanup_table_mock.call_args.kwargs["batch_size"] == 1234

    @patch("airflow.utils.db_cleanup.reflect_tables")
    @patch("airflow.utils.db_cleanup._cleanup_table")
    def test_run_cleanup_does_not_commit_after_cleanup_table(self, cleanup_table_mock, reflect_tables_mock):
        """run_cleanup should not add an extra commit after _cleanup_table handles its own transaction."""
        reflect_tables_mock.return_value.tables = {"log": object()}
        session = MagicMock()

        run_cleanup(
            clean_before_timestamp=None,
            table_names=["log"],
            dry_run=False,
            verbose=False,
            confirm=False,
            session=session,
        )

        cleanup_table_mock.assert_called_once()
        session.commit.assert_not_called()

    @pytest.mark.parametrize(
        "table_names",
        [
            ["xcom", "log"],
            None,
        ],
    )
    @patch("airflow.utils.db_cleanup._cleanup_table")
    @patch("airflow.utils.db_cleanup._confirm_delete", new=MagicMock())
    def test_run_cleanup_tables(self, clean_table_mock, table_names):
        """
        ``_cleanup_table`` should be called for each table in subset if one
        is provided else should be called for all tables.
        """
        base_kwargs = dict(
            clean_before_timestamp=None,
            dry_run=None,
            verbose=None,
        )
        run_cleanup(**base_kwargs, table_names=table_names)
        assert clean_table_mock.call_count == len(table_names) if table_names else len(config_dict)

    @patch("airflow.utils.db_cleanup._cleanup_table")
    @patch("airflow.utils.db_cleanup._confirm_delete")
    def test_validate_tables_all_invalid(self, confirm_delete_mock, clean_table_mock):
        """If only invalid tables are provided, don't try cleaning anything"""
        base_kwargs = dict(
            clean_before_timestamp=None,
            dry_run=None,
            verbose=None,
        )
        with pytest.raises(SystemExit) as execinfo:
            run_cleanup(**base_kwargs, table_names=["all", "fake"])
        assert "No tables selected for db cleanup" in str(execinfo.value)
        confirm_delete_mock.assert_not_called()

    @pytest.mark.parametrize(
        "dry_run",
        [None, True, False],
    )
    @patch("airflow.utils.db_cleanup._build_query", MagicMock())
    @patch("airflow.utils.db_cleanup._confirm_delete", MagicMock())
    @patch("airflow.utils.db_cleanup._check_for_rows")
    @patch("airflow.utils.db_cleanup._do_delete")
    def test_run_cleanup_dry_run(self, do_delete, check_rows_mock, dry_run):
        """Delete should only be called when not dry_run"""
        check_rows_mock.return_value = 10
        base_kwargs = dict(
            table_names=["log"],
            clean_before_timestamp=None,
            dry_run=dry_run,
            verbose=None,
        )
        run_cleanup(
            **base_kwargs,
        )
        if dry_run:
            do_delete.assert_not_called()
        else:
            do_delete.assert_called()

    @pytest.mark.parametrize(
        ("table_name", "date_add_kwargs", "expected_to_delete", "run_type"),
        [
            pytest.param("task_instance", dict(days=0), 0, DagRunType.SCHEDULED, id="beginning"),
            pytest.param("task_instance", dict(days=4), 4, DagRunType.SCHEDULED, id="middle"),
            pytest.param("task_instance", dict(days=9), 9, DagRunType.SCHEDULED, id="end_exactly"),
            pytest.param(
                "task_instance", dict(days=9, microseconds=1), 10, DagRunType.SCHEDULED, id="beyond_end"
            ),
            pytest.param(
                "dag_run", dict(days=9, microseconds=1), 9, DagRunType.SCHEDULED, id="beyond_end_dr"
            ),
            pytest.param(
                "dag_run", dict(days=9, microseconds=1), 10, DagRunType.MANUAL, id="beyond_end_dr_external"
            ),
        ],
    )
    def test__build_query(self, table_name, date_add_kwargs, expected_to_delete, run_type):
        """
        Verify that ``_build_query`` produces a query that would delete the right
        task instance records depending on the value of ``clean_before_timestamp``.

        DagRun is a special case where we always keep the last dag run even if
        the ``clean_before_timestamp`` is in the future, except for
        externally-triggered dag runs. That is, only the last non-externally-triggered
        dag run is kept.

        """
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        create_tis(
            base_date=base_date,
            num_tis=10,
            run_type=run_type,
        )
        target_table_name = "_airflow_temp_table_name"
        with create_session() as session:
            clean_before_date = base_date.add(**date_add_kwargs)
            query = _build_query(
                **config_dict[table_name].__dict__,
                clean_before_timestamp=clean_before_date,
                session=session,
            )
            stmt = CreateTableAs(target_table_name, query.selectable)
            session.execute(stmt)
            res = session.execute(text(f"SELECT COUNT(1) FROM {target_table_name}"))
            for row in res:
                assert row[0] == expected_to_delete

    @pytest.mark.parametrize(
        ("table_name", "date_add_kwargs", "expected_to_delete", "run_type"),
        [
            pytest.param("task_instance", dict(days=0), 0, DagRunType.SCHEDULED, id="beginning"),
            pytest.param("task_instance", dict(days=4), 4, DagRunType.SCHEDULED, id="middle"),
            pytest.param("task_instance", dict(days=9), 9, DagRunType.SCHEDULED, id="end_exactly"),
            pytest.param(
                "task_instance", dict(days=9, microseconds=1), 10, DagRunType.SCHEDULED, id="beyond_end"
            ),
            pytest.param(
                "dag_run", dict(days=9, microseconds=1), 9, DagRunType.SCHEDULED, id="beyond_end_dr"
            ),
            pytest.param(
                "dag_run", dict(days=9, microseconds=1), 10, DagRunType.MANUAL, id="beyond_end_dr_external"
            ),
        ],
    )
    def test__cleanup_table(self, table_name, date_add_kwargs, expected_to_delete, run_type):
        """
        Verify that _cleanup_table actually deletes the rows it should.

        TaskInstance represents the "normal" case.  DagRun is the odd case where we want
        to keep the last non-externally-triggered DagRun record even if it should be
        deleted according to the provided timestamp.

        We also verify that the "on delete cascade" behavior is as expected.  Some tables
        have foreign keys defined so for example if we delete a dag run, all its associated
        task instances should be purged as well.  But if we delete task instances the
        associated dag runs should remain.

        """
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        num_tis = 10
        create_tis(
            base_date=base_date,
            num_tis=num_tis,
            run_type=run_type,
        )
        with create_session() as session:
            clean_before_date = base_date.add(**date_add_kwargs)
            _cleanup_table(
                **config_dict[table_name].__dict__,
                clean_before_timestamp=clean_before_date,
                dry_run=False,
                session=session,
                table_names=["dag_run", "task_instance"],
            )
            model = config_dict[table_name].orm_model
            expected_remaining = num_tis - expected_to_delete
            assert session.scalar(select(func.count()).select_from(model)) == expected_remaining
            if model.name == "task_instance":
                assert session.scalar(select(func.count()).select_from(DagRun)) == num_tis
            elif model.name == "dag_run":
                assert session.scalar(select(func.count()).select_from(TaskInstance)) == expected_remaining
            else:
                raise Exception("unexpected")

    @pytest.mark.parametrize(
        ("table_name", "expected_archived"),
        [
            (
                "dag_run",
                {"dag_run", "task_instance"},  # Only these are populated
            ),
        ],
    )
    def test_run_cleanup_archival_integration(self, table_name, expected_archived):
        """
        Integration test that verifies:
        1. Recursive FK-dependent tables are resolved via _effective_table_names().
        2. run_cleanup() archives only tables with data.
        3. Archive tables are not created for empty dependent tables.
        """
        base_date = pendulum.datetime(2022, 1, 1, tz="UTC")
        num_tis = 5

        # Create test data for DAG Run and TIs
        if table_name in {"dag_run", "task_instance"}:
            create_tis(base_date=base_date, num_tis=num_tis, run_type=DagRunType.MANUAL)

        clean_before_date = base_date.add(days=10)

        with create_session() as session:
            run_cleanup(
                clean_before_timestamp=clean_before_date,
                table_names=[table_name],
                dry_run=False,
                confirm=False,
                session=session,
            )

            # Inspect archive tables created
            inspector = inspect(session.bind)
            archive_tables = {
                name for name in inspector.get_table_names() if name.startswith(ARCHIVE_TABLE_PREFIX)
            }
            actual_archived = {t.split("__", 1)[-1].split("__")[0] for t in archive_tables}

            assert expected_archived <= actual_archived, (
                f"Expected archive tables not found: {expected_archived - actual_archived}"
            )

    @pytest.mark.parametrize(
        ("dag_ids", "exclude_dag_ids", "expected_remaining_dag_ids"),
        [
            pytest.param(["dag1"], None, {"dag2", "dag3"}, id="include_single_dag"),
            pytest.param(["dag1", "dag2"], None, {"dag3"}, id="include_multiple_dags"),
            pytest.param(None, ["dag3"], {"dag3"}, id="exclude_single_dag"),
            pytest.param(None, ["dag2", "dag3"], {"dag2", "dag3"}, id="exclude_multiple_dags"),
            pytest.param(["dag1", "dag2"], ["dag2"], {"dag2", "dag3"}, id="include_and_exclude"),
            pytest.param(None, None, set(), id="no_filtering_all_deleted"),
        ],
    )
    def test_cleanup_with_dag_id_filtering(self, dag_ids, exclude_dag_ids, expected_remaining_dag_ids):
        """
        Verify that dag_ids and exclude_dag_ids parameters correctly include/exclude
        specific DAGs during cleanup
        """
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))

        with create_session() as session:
            bundle_name = "testing"
            session.add(DagBundleModel(name=bundle_name))
            session.flush()

            for dag_id in ["dag1", "dag2", "dag3"]:
                dag = DAG(dag_id=dag_id)
                dm = DagModel(dag_id=dag_id, bundle_name=bundle_name)
                session.add(dm)
                SerializedDagModel.write_dag(LazyDeserializedDAG.from_dag(dag), bundle_name=bundle_name)
                dag_version = DagVersion.get_latest_version(dag.dag_id)

                start_date = base_date
                dag_run = DagRun(
                    dag.dag_id,
                    run_id=f"{dag_id}_run",
                    run_type=DagRunType.MANUAL,
                    start_date=start_date,
                )
                ti = create_task_instance(
                    PythonOperator(task_id="dummy-task", python_callable=print),
                    run_id=dag_run.run_id,
                    dag_version_id=dag_version.id,
                )
                ti.dag_id = dag.dag_id
                ti.start_date = start_date
                session.add(dag_run)
                session.add(ti)
            session.commit()

            clean_before_date = base_date.add(days=10)
            run_cleanup(
                clean_before_timestamp=clean_before_date,
                table_names=["task_instance"],
                dag_ids=dag_ids,
                exclude_dag_ids=exclude_dag_ids,
                dry_run=False,
                confirm=False,
                session=session,
            )

            remaining_tis = session.scalars(select(TaskInstance)).all()
            remaining_dag_ids = {ti.dag_id for ti in remaining_tis}

            assert remaining_dag_ids == expected_remaining_dag_ids, (
                f"Expected {expected_remaining_dag_ids} to remain, but got {remaining_dag_ids}"
            )

    @pytest.mark.parametrize(
        ("skip_archive", "expected_archives"),
        [pytest.param(True, 0, id="skip_archive"), pytest.param(False, 1, id="do_archive")],
    )
    def test__skip_archive(self, skip_archive, expected_archives):
        """
        Verify that running cleanup_table with drops the archives when requested.

        Archived tables from DB migration should be kept when skip_archive is True.
        """
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        num_tis = 10
        create_tis(
            base_date=base_date,
            num_tis=num_tis,
        )
        with create_session() as session:
            # cleanup any existing archived tables
            for name in _get_archived_table_names(["dag_run"], session):
                session.execute(text(f"DROP TABLE IF EXISTS {name}"))
            clean_before_date = base_date.add(days=5)
            _cleanup_table(
                **config_dict["dag_run"].__dict__,
                clean_before_timestamp=clean_before_date,
                dry_run=False,
                session=session,
                table_names=["dag_run"],
                skip_archive=skip_archive,
            )
            model = config_dict["dag_run"].orm_model
            assert session.scalar(select(func.count()).select_from(model)) == 5
            assert len(_get_archived_table_names(["dag_run"], session)) == expected_archives

    def test_dag_version_cleanup_skips_versions_pinned_by_task_instance(self):
        """db clean must skip dag_version rows still referenced by a task instance.

        ``task_instance.dag_version_id`` is ``ON DELETE RESTRICT``, so deleting a referenced
        ``dag_version`` fails the foreign key. Cleanup must skip those rows while still pruning
        genuinely orphaned older versions.
        """
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        bundle_name = f"testing-{uuid4()}"
        dag_id = f"test_dag_{uuid4()}"

        with create_session() as session:
            session.add(DagBundleModel(name=bundle_name))
            session.flush()
            session.add(DagModel(dag_id=dag_id, bundle_name=bundle_name))
            session.flush()

            pinned_old = DagVersion(
                dag_id=dag_id,
                version_number=1,
                bundle_name=bundle_name,
                created_at=base_date,
                last_updated=base_date,
            )
            orphan_old = DagVersion(
                dag_id=dag_id,
                version_number=2,
                bundle_name=bundle_name,
                created_at=base_date.add(minutes=1),
                last_updated=base_date.add(minutes=1),
            )
            latest = DagVersion(
                dag_id=dag_id,
                version_number=3,
                bundle_name=bundle_name,
                created_at=base_date.add(minutes=2),
                last_updated=base_date.add(minutes=2),
            )
            session.add_all([pinned_old, orphan_old, latest])
            session.flush()

            dag = DAG(dag_id=dag_id)
            dag_run = DagRun(dag_id, run_id="run-1", run_type=DagRunType.MANUAL, start_date=base_date)
            ti = create_task_instance(
                PythonOperator(task_id="dummy-task", python_callable=print),
                run_id=dag_run.run_id,
                dag_version_id=pinned_old.id,
            )
            ti.dag_id = dag.dag_id
            ti.start_date = base_date
            session.add_all([dag_run, ti])
            session.commit()

            pinned_id, orphan_id, latest_id = pinned_old.id, orphan_old.id, latest.id

            # Previously this raised an IntegrityError on the FK; it must now succeed.
            _cleanup_table(
                **config_dict["dag_version"].__dict__,
                clean_before_timestamp=base_date.add(days=10),
                dry_run=False,
                session=session,
                table_names=["dag_version"],
                skip_archive=True,
            )

            remaining = set(session.scalars(select(DagVersion.id).where(DagVersion.dag_id == dag_id)).all())

        assert pinned_id in remaining  # still referenced by a task instance -> skipped
        assert latest_id in remaining  # kept by keep_last
        assert orphan_id not in remaining  # old and unreferenced -> pruned

    def test_table_config_skip_if_referenced_requires_pk_column(self):
        """A misconfigured skip_if_referenced (pk not in columns) must fail fast at construction."""
        with pytest.raises(ValueError, match="referenced_pk_column"):
            _TableConfig(
                table_name="dag_version",
                recency_column_name="created_at",
                dag_id_column_name="dag_id",
                skip_if_referenced=[("task_instance", "dag_version_id")],
                # "id" intentionally omitted from extra_columns
            )

    def test_do_delete_rolls_back_before_drop_on_failure(self):
        session = MagicMock(spec=Session)
        session.get_bind.return_value.dialect.name = "mysql"
        session.connection.return_value = object()
        session.scalars.return_value.one.side_effect = [1, 0]
        tracker = MagicMock()
        tracker.attach_mock(session, "session")

        metadata, source_table, target_table, query = _build_do_delete_test_objects()
        delete_failure = IntegrityError("DELETE FROM dag_version", {}, Exception("fk violation"))
        session.execute.side_effect = [None, None, delete_failure]

        with (
            patch("airflow.utils.db_cleanup.reflect_tables", return_value=metadata),
            patch("airflow.utils.db_cleanup.timezone.utcnow", return_value=_delete_test_timestamp()),
            patch.object(target_table, "drop") as drop_mock,
        ):
            tracker.attach_mock(drop_mock, "drop")
            with pytest.raises(IntegrityError) as exc_info:
                _do_delete(
                    query=query,
                    orm_model=source_table,
                    skip_archive=True,
                    session=session,
                    batch_size=None,
                )

        assert exc_info.value is delete_failure
        session.rollback.assert_called_once_with()
        session.connection.assert_called_once_with()
        assert session.get_bind.call_count == 1
        drop_mock.assert_called_once_with(bind=session.connection.return_value)

        rollback_call_index = tracker.mock_calls.index(call.session.rollback())
        drop_call_index = tracker.mock_calls.index(call.drop(bind=session.connection.return_value))
        commit_call_index = tracker.mock_calls.index(call.session.commit(), drop_call_index)
        assert rollback_call_index < drop_call_index < commit_call_index

    def test_do_delete_propagates_original_error_when_rollback_fails(self):
        session = MagicMock(spec=Session)
        session.get_bind.return_value.dialect.name = "mysql"
        session.connection.return_value = object()
        session.scalars.return_value.one.side_effect = [1, 0]

        metadata, source_table, target_table, query = _build_do_delete_test_objects()
        delete_failure = IntegrityError("DELETE FROM dag_version", {}, Exception("fk violation"))
        session.execute.side_effect = [None, None, delete_failure]
        session.rollback.side_effect = OperationalError("ROLLBACK", {}, Exception("connection lost"))

        with (
            patch("airflow.utils.db_cleanup.reflect_tables", return_value=metadata),
            patch("airflow.utils.db_cleanup.timezone.utcnow", return_value=_delete_test_timestamp()),
            patch.object(target_table, "drop") as drop_mock,
        ):
            with pytest.raises(IntegrityError) as exc_info:
                _do_delete(
                    query=query,
                    orm_model=source_table,
                    skip_archive=True,
                    session=session,
                    batch_size=None,
                )

        assert exc_info.value is delete_failure
        session.rollback.assert_called_once_with()
        drop_mock.assert_called_once_with(bind=session.connection.return_value)

    @pytest.mark.parametrize(
        ("skip_archive", "expected_commit_count"),
        [pytest.param(True, 3, id="skip_archive"), pytest.param(False, 2, id="keep_archive")],
    )
    def test_do_delete_success_does_not_call_rollback(self, skip_archive, expected_commit_count):
        session = MagicMock(spec=Session)
        session.get_bind.return_value.dialect.name = "mysql"
        session.connection.return_value = object()
        session.scalars.return_value.one.side_effect = [1, 0]
        session.execute.side_effect = [None, None, None]

        metadata, source_table, target_table, query = _build_do_delete_test_objects()

        with (
            patch("airflow.utils.db_cleanup.reflect_tables", return_value=metadata),
            patch("airflow.utils.db_cleanup.timezone.utcnow", return_value=_delete_test_timestamp()),
            patch.object(target_table, "drop") as drop_mock,
        ):
            _do_delete(
                query=query,
                orm_model=source_table,
                skip_archive=skip_archive,
                session=session,
                batch_size=None,
            )

        session.rollback.assert_not_called()
        assert session.commit.call_count == expected_commit_count
        if skip_archive:
            session.connection.assert_called_once_with()
            drop_mock.assert_called_once_with(bind=session.connection.return_value)
        else:
            session.connection.assert_not_called()
            drop_mock.assert_not_called()

    def test_do_delete_original_error_survives_archive_drop_failure(self):
        """On the failure path, a drop/commit error in the finally block must not
        replace the original delete error (nailo2c review, #66296)."""
        session = MagicMock(spec=Session)
        session.get_bind.return_value.dialect.name = "mysql"
        session.connection.return_value = object()
        session.scalars.return_value.one.side_effect = [1, 0]

        metadata, source_table, target_table, query = _build_do_delete_test_objects()
        delete_failure = IntegrityError("DELETE FROM dag_version", {}, Exception("fk violation"))
        session.execute.side_effect = [None, None, delete_failure]
        drop_failure = OperationalError("DROP TABLE", {}, Exception("server has gone away"))

        with (
            patch("airflow.utils.db_cleanup.reflect_tables", return_value=metadata),
            patch("airflow.utils.db_cleanup.timezone.utcnow", return_value=_delete_test_timestamp()),
            patch.object(target_table, "drop", side_effect=drop_failure) as drop_mock,
        ):
            with pytest.raises(IntegrityError) as exc_info:
                _do_delete(
                    query=query,
                    orm_model=source_table,
                    skip_archive=True,
                    session=session,
                    batch_size=None,
                )

        assert exc_info.value is delete_failure
        drop_mock.assert_called_once_with(bind=session.connection.return_value)

    def test_do_delete_success_propagates_archive_drop_error(self):
        """On the success path, a drop/commit failure is a real error and must
        still surface (the failure-path guard must not swallow it)."""
        session = MagicMock(spec=Session)
        session.get_bind.return_value.dialect.name = "mysql"
        session.connection.return_value = object()
        session.scalars.return_value.one.side_effect = [1, 0]
        session.execute.side_effect = [None, None, None]

        metadata, source_table, target_table, query = _build_do_delete_test_objects()
        drop_failure = OperationalError("DROP TABLE", {}, Exception("disk full"))

        with (
            patch("airflow.utils.db_cleanup.reflect_tables", return_value=metadata),
            patch("airflow.utils.db_cleanup.timezone.utcnow", return_value=_delete_test_timestamp()),
            patch.object(target_table, "drop", side_effect=drop_failure),
        ):
            with pytest.raises(OperationalError) as exc_info:
                _do_delete(
                    query=query,
                    orm_model=source_table,
                    skip_archive=True,
                    session=session,
                    batch_size=None,
                )

        assert exc_info.value is drop_failure
        session.rollback.assert_not_called()

    @patch("airflow.utils.db.reflect_tables")
    def test_skip_archive_failure_will_remove_table(self, reflect_tables_mock):
        """
        Verify that running cleanup_table with skip_archive = True, and failure happens.

        The archive table should be removed from db if any exception.
        """
        reflect_tables_mock.side_effect = SQLAlchemyError("Deletion failed")
        base_date = pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        num_tis = 10
        create_tis(
            base_date=base_date,
            num_tis=num_tis,
        )
        try:
            with create_session() as session:
                # cleanup any existing archived tables
                for name in _get_archived_table_names(["dag_run"], session):
                    session.execute(text(f"DROP TABLE IF EXISTS {name}"))
                clean_before_date = base_date.add(days=5)
                _cleanup_table(
                    **config_dict["dag_run"].__dict__,
                    clean_before_timestamp=clean_before_date,
                    dry_run=False,
                    session=session,
                    table_names=["dag_run"],
                    skip_archive=True,
                )
        except SQLAlchemyError:
            pass
        archived_table_names = _get_archived_table_names(["dag_run"], session)
        assert len(archived_table_names) == 0

    @pytest.mark.backend("mysql")
    def test_db_clean_does_not_deadlock_on_fk_violation_mysql(self):
        clean_before_date = _create_pinned_dag_version_cleanup_data(
            base_date=pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        )
        timeout_seconds = 15
        finished = threading.Event()
        result: dict[str, BaseException] = {}

        def cleanup_in_thread():
            try:
                with create_session() as session:
                    _cleanup_table(
                        **_dag_version_config_without_row_exclusion(),
                        clean_before_timestamp=clean_before_date,
                        dry_run=False,
                        session=session,
                        table_names=["dag_version"],
                        skip_archive=True,
                    )
            except BaseException as exc:
                result["exception"] = exc
            finally:
                finished.set()

        worker = threading.Thread(target=cleanup_in_thread, daemon=True)
        start_time = time.monotonic()
        worker.start()

        assert finished.wait(timeout_seconds), (
            "dag_version cleanup timed out after "
            f"{time.monotonic() - start_time:.2f} seconds waiting for the FK violation to surface"
        )

        worker.join(timeout=1)
        assert not worker.is_alive()
        assert isinstance(result.get("exception"), IntegrityError)

        with create_session() as session:
            assert _get_dag_version_archive_table_names(session=session) == []

    @pytest.mark.backend("postgres")
    def test_db_clean_failure_path_does_not_break_postgres(self):
        clean_before_date = _create_pinned_dag_version_cleanup_data(
            base_date=pendulum.DateTime(2022, 1, 1, tzinfo=pendulum.timezone("UTC"))
        )

        with pytest.raises(IntegrityError):
            with create_session() as session:
                _cleanup_table(
                    **_dag_version_config_without_row_exclusion(),
                    clean_before_timestamp=clean_before_date,
                    dry_run=False,
                    session=session,
                    table_names=["dag_version"],
                    skip_archive=True,
                )

        with create_session() as session:
            assert _get_dag_version_archive_table_names(session=session) == []

    def test_no_models_missing(self):
        """
        1. Verify that for all tables in `airflow.models`, we either have them enabled in db cleanup,
        or documented in the exclusion list in this test.
        2. Verify that no table is enabled for db cleanup and also in exclusion list.
        """
        import pkgutil

        proj_root = Path(__file__).parents[2].resolve()
        mods = list(
            f"airflow.models.{name}"
            for _, name, _ in pkgutil.iter_modules([str(proj_root / "airflow/models")])
        )

        all_models = {}
        for mod_name in mods:
            mod = import_module(mod_name)

            for class_ in mod.__dict__.values():
                if isinstance(class_, DeclarativeMeta):
                    with suppress(AttributeError):
                        all_models.update({class_.__tablename__: class_})
        exclusion_list = {
            "backfill",  # todo: AIP-78
            "backfill_dag_run",  # todo: AIP-78
            "ab_user",
            "variable",  # leave alone
            "asset_active",  # not good way to know if "stale"
            "asset",  # not good way to know if "stale"
            "asset_alias",  # not good way to know if "stale"
            "task_map",  # keys to TI, so no need
            "serialized_dag",  # handled through FK to Dag
            "log_template",  # not a significant source of data; age not indicative of staleness
            "dag_tag",  # not a significant source of data; age not indicative of staleness,
            "dag_owner_attributes",  # not a significant source of data; age not indicative of staleness,
            "dag_code",  # self-maintaining
            "dag_warning",  # self-maintaining
            "connection",  # leave alone
            "slot_pool",  # leave alone
            "dag_schedule_asset_reference",  # leave alone for now
            "dag_schedule_asset_alias_reference",  # leave alone for now
            "dag_schedule_asset_name_reference",  # leave alone for now
            "dag_schedule_asset_uri_reference",  # leave alone for now
            "task_outlet_asset_reference",  # leave alone for now
            "asset_dag_run_queue",  # self-managed
            "asset_event_dag_run",  # foreign keys
            "task_instance_note",  # foreign keys
            "dag_run_note",  # foreign keys
            "rendered_task_instance_fields",  # foreign key with TI
            "dag_priority_parsing_request",  # Records are purged once per DAG Processing loop, not a
            # significant source of data.
            "dag_bundle",  # leave alone - not appropriate for cleanup
        }

        from airflow.utils.db_cleanup import config_dict

        print(f"all_models={set(all_models)}")
        print(f"excl+conf={exclusion_list.union(config_dict)}")
        assert set(all_models) - exclusion_list.union(config_dict) == set()
        assert exclusion_list.isdisjoint(config_dict)

    def test_no_failure_warnings(self):
        """
        Ensure every table we have configured (and that is present in the db) can be cleaned successfully.
        For example, this checks that the recency column is actually a column.
        """
        with patch("airflow.utils.db_cleanup.logger") as mock_logger:
            run_cleanup(clean_before_timestamp=timezone.utcnow(), dry_run=True)
            for call in mock_logger.warning.call_args_list:
                assert "Encountered error when attempting to clean table" not in str(call)

        # Lets check we have the right error message just in case
        with (
            patch("airflow.utils.db_cleanup.logger") as mock_logger,
            patch("airflow.utils.db_cleanup._cleanup_table", side_effect=OperationalError("oops", {}, None)),
        ):
            run_cleanup(clean_before_timestamp=timezone.utcnow(), table_names=["task_instance"], dry_run=True)
            mock_logger.warning.assert_any_call(
                "Encountered error when attempting to clean table '%s'. ", "task_instance"
            )

    @pytest.mark.parametrize(
        "drop_archive",
        [True, False],
    )
    @patch("airflow.utils.db_cleanup._dump_table_to_file")
    @patch("airflow.utils.db_cleanup._confirm_drop_archives")
    @patch("airflow.utils.db_cleanup.inspect")
    def test_confirm_drop_called_when_drop_archives_is_true_and_archive_exists(
        self, inspect_mock, confirm_drop_mock, _dump_table_to_file_mock, drop_archive
    ):
        """Test that drop confirmation input is called when appropriate"""
        inspector = inspect_mock.return_value
        inspector.get_table_names.return_value = [f"{ARCHIVE_TABLE_PREFIX}dag_run__233"]
        export_archived_records(
            export_format="csv", output_path="path", drop_archives=drop_archive, session=MagicMock()
        )
        if drop_archive:
            confirm_drop_mock.assert_called()
        else:
            confirm_drop_mock.assert_not_called()

    @pytest.mark.parametrize(
        "tables",
        [
            ["table1", "table2"],
            ["table1", "table2", "table3"],
            ["table1", "table2", "table3", "table4"],
        ],
    )
    @patch("airflow.utils.db_cleanup.ask_yesno")
    def test_confirm_drop_archives(self, mock_ask_yesno, tables):
        expected = (
            f"You have requested that we drop the following archived tables: {', '.join(tables)}.\n"
            "This is irreversible. Consider backing up the tables first."
        )
        if len(tables) > 3:
            expected = (
                f"You have requested that we drop {len(tables)} archived tables prefixed with "
                f"_airflow_deleted__.\n"
                "This is irreversible. Consider backing up the tables first.\n"
            )
            for table in tables:
                expected += f"\n  {table}"

        mock_ask_yesno.return_value = True
        with (
            patch("sys.stdout", new=StringIO()) as fake_out,
            patch("builtins.input", side_effect=["drop archived tables"]),
        ):
            _confirm_drop_archives(tables=tables)
            output = fake_out.getvalue().strip()

        assert output == expected

    def test_user_did_not_confirm(self):
        tables = ["table1", "table2"]
        with (
            pytest.raises(SystemExit) as cm,
            patch("builtins.input", side_effect=["not drop archived tables"]),
        ):
            _confirm_drop_archives(tables=tables)
        assert str(cm.value) == "User did not confirm; exiting."

    @pytest.mark.parametrize("drop_archive", [True, False])
    @patch("airflow.utils.db_cleanup._dump_table_to_file")
    @patch("airflow.utils.db_cleanup.inspect")
    @patch("builtins.input", side_effect=["drop archived tables"])
    def test_export_archived_records_only_archived_tables(
        self, mock_input, inspect_mock, dump_mock, caplog, drop_archive
    ):
        """Test export_archived_records and show that only tables with the archive prefix are exported."""
        session_mock = MagicMock()
        inspector = inspect_mock.return_value
        inspector.get_table_names.return_value = [f"{ARCHIVE_TABLE_PREFIX}dag_run__233", "task_instance"]
        export_archived_records(
            export_format="csv", output_path="path", drop_archives=drop_archive, session=session_mock
        )
        dump_mock.assert_called_once_with(
            target_table=f"{ARCHIVE_TABLE_PREFIX}dag_run__233",
            file_path=f"path/{ARCHIVE_TABLE_PREFIX}dag_run__233.csv",
            export_format="csv",
            session=session_mock,
        )
        assert f"Exporting table {ARCHIVE_TABLE_PREFIX}dag_run__233" in caplog.text

        if drop_archive:
            assert "Total exported tables: 1, Total dropped tables: 1" in caplog.text
        else:
            assert "Total exported tables: 1, Total dropped tables: 0" in caplog.text

    @pytest.mark.parametrize("drop_archive", [True, False])
    @patch("airflow.utils.db_cleanup._dump_table_to_file")
    @patch("airflow.utils.db_cleanup.inspect")
    @patch("airflow.utils.db_cleanup._confirm_drop_archives")
    @patch("builtins.input", side_effect=["drop archived tables"])
    def test_export_archived_no_confirm_if_no_tables(
        self, mock_input, mock_confirm, inspect_mock, dump_mock, caplog, drop_archive
    ):
        """Test no confirmation if no archived tables found"""
        session_mock = MagicMock()
        inspector = inspect_mock.return_value
        # No tables with the archive prefix
        inspector.get_table_names.return_value = ["dag_run", "task_instance"]
        export_archived_records(
            export_format="csv", output_path="path", drop_archives=drop_archive, session=session_mock
        )
        mock_confirm.assert_not_called()
        dump_mock.assert_not_called()
        assert "Total exported tables: 0, Total dropped tables: 0" in caplog.text

    @patch("airflow.utils.db_cleanup.csv")
    def test_dump_table_to_file_function_for_csv(self, mock_csv):
        mockopen = mock_open()
        mock_cursor = MagicMock()
        mock_session = MagicMock()
        mock_session.execute.return_value = mock_cursor
        mock_cursor.keys.return_value = ["test-col-1", "test-col-2"]
        mock_cursor.fetchmany.side_effect = [
            [("testval-1.1", "testval-1.2"), ("testval-2.1", "testval-2.2")],
            [],
        ]
        with patch("airflow.utils.db_cleanup.open", mockopen, create=True):
            _dump_table_to_file(
                target_table="mytable", file_path="dags/myfile.csv", export_format="csv", session=mock_session
            )
            mockopen.assert_called_once_with("dags/myfile.csv", "w")
            writer = mock_csv.writer
            writer.assert_called_once()
            writer.return_value.writerow.assert_called_once_with(["test-col-1", "test-col-2"])
            writer.return_value.writerows.assert_called_once_with(
                [("testval-1.1", "testval-1.2"), ("testval-2.1", "testval-2.2")]
            )

    def test_dump_table_to_file_raises_if_format_not_supported(self):
        with pytest.raises(AirflowException) as exc_info:
            _dump_table_to_file(
                target_table="mytable",
                file_path="dags/myfile.json",
                export_format="json",
                session=MagicMock(),
            )
        assert "Export format json is not supported" in str(exc_info.value)

    @pytest.mark.parametrize("tables", [["log", "dag"], ["dag_run", "task_instance"]])
    @patch("airflow.utils.db_cleanup._confirm_drop_archives")
    @patch("airflow.utils.db_cleanup.inspect")
    def test_drop_archived_tables_no_confirm_if_no_archived_tables(
        self, inspect_mock, mock_confirm, tables, caplog
    ):
        """
        Test no confirmation if no archived tables found.
        Archived tables starts with a prefix defined in ARCHIVE_TABLE_PREFIX.
        """
        inspector = inspect_mock.return_value
        inspector.get_table_names.return_value = tables
        drop_archived_tables(tables, needs_confirm=True, session=MagicMock())
        mock_confirm.assert_not_called()
        assert "Total dropped tables: 0" in caplog.text

    @pytest.mark.parametrize("confirm", [True, False])
    @patch("airflow.utils.db_cleanup.inspect")
    @patch("airflow.utils.db_cleanup._confirm_drop_archives")
    @patch("builtins.input", side_effect=["drop archived tables"])
    def test_drop_archived_tables(self, mock_input, confirm_mock, inspect_mock, caplog, confirm):
        """Test drop_archived_tables"""
        archived_table = f"{ARCHIVE_TABLE_PREFIX}dag_run__233"
        normal_table = "dag_run"
        inspector = inspect_mock.return_value
        inspector.get_table_names.return_value = [archived_table, normal_table]
        drop_archived_tables([normal_table], needs_confirm=confirm, session=MagicMock())
        assert f"Dropping archived table {archived_table}" in caplog.text
        assert f"Dropping archived table {normal_table}" not in caplog.text
        assert "Total dropped tables: 1" in caplog.text
        if confirm:
            confirm_mock.assert_called()
        else:
            confirm_mock.assert_not_called()

    @patch(
        "airflow.utils.db_cleanup._cleanup_table",
        side_effect=OperationalError("", {}, Exception("mock db error")),
    )
    def test_error_on_cleanup_failure_raises_when_flag_set(self, cleanup_table_mock):
        """When error_on_cleanup_failure=True and a table fails, RuntimeError should be raised."""
        with patch("airflow.utils.db_cleanup.logger") as mock_logger:
            with pytest.raises(RuntimeError, match="airflow db clean encountered errors"):
                run_cleanup(
                    clean_before_timestamp=None,
                    table_names=["log"],
                    dry_run=False,
                    verbose=False,
                    confirm=False,
                    error_on_cleanup_failure=True,
                )

            mock_logger.warning.assert_any_call(
                "Encountered error when attempting to clean table '%s'. ", "log"
            )
            assert (
                "The following tables were not cleaned due to errors: %s. Check the logs above for details.",
                ["log"],
            ) not in [call.args for call in mock_logger.warning.call_args_list]

    @patch(
        "airflow.utils.db_cleanup._cleanup_table",
        side_effect=OperationalError("", {}, Exception("mock db error")),
    )
    def test_error_on_cleanup_failure_no_raise_by_default(self, cleanup_table_mock):
        """When error_on_cleanup_failure=False (default) and a table fails, no exception is raised."""
        with patch("airflow.utils.db_cleanup.logger") as mock_logger:
            run_cleanup(
                clean_before_timestamp=None,
                table_names=["log"],
                dry_run=False,
                verbose=False,
                confirm=False,
                error_on_cleanup_failure=False,
            )
            mock_logger.warning.assert_any_call(
                "The following tables were not cleaned due to errors: %s. Check the logs above for details.",
                ["log"],
            )

    @patch(
        "airflow.utils.db_cleanup._cleanup_table",
        side_effect=OperationalError("", {}, Exception("mock db error")),
    )
    def test_error_on_cleanup_failure_lists_failed_tables_in_warning(self, cleanup_table_mock):
        """A warning naming the failed tables is emitted when error_on_cleanup_failure is not set."""
        with patch("airflow.utils.db_cleanup.logger") as mock_logger:
            run_cleanup(
                clean_before_timestamp=None,
                table_names=["log"],
                dry_run=False,
                verbose=False,
                confirm=False,
            )
            mock_logger.warning.assert_any_call(
                "The following tables were not cleaned due to errors: %s. Check the logs above for details.",
                ["log"],
            )

    @patch("airflow.utils.db_cleanup._cleanup_table")
    def test_error_on_cleanup_failure_propagated_from_run_cleanup(self, cleanup_table_mock):
        """Ensure error_on_cleanup_failure is accepted by run_cleanup without errors when no failures occur."""
        run_cleanup(
            clean_before_timestamp=None,
            table_names=["log"],
            dry_run=False,
            verbose=False,
            confirm=False,
            error_on_cleanup_failure=True,
        )
        cleanup_table_mock.assert_called_once()


def create_tis(base_date, num_tis, run_type=DagRunType.SCHEDULED):
    from tests_common.test_utils.taskinstance import create_task_instance

    with create_session() as session:
        bundle_name = "testing"
        session.add(DagBundleModel(name=bundle_name))
        session.flush()

        dag_id = f"test-dag_{uuid4()}"
        dag = DAG(dag_id=dag_id)
        dm = DagModel(dag_id=dag_id, bundle_name=bundle_name)
        session.add(dm)
        SerializedDagModel.write_dag(LazyDeserializedDAG.from_dag(dag), bundle_name=bundle_name)
        dag_version = DagVersion.get_latest_version(dag.dag_id)
        for num in range(num_tis):
            start_date = base_date.add(days=num)
            dag_run = DagRun(
                dag.dag_id,
                run_id=f"abc_{num}",
                run_type=run_type,
                start_date=start_date,
            )
            ti = create_task_instance(
                PythonOperator(task_id="dummy-task", python_callable=print),
                run_id=dag_run.run_id,
                dag_version_id=dag_version.id,
            )
            ti.dag_id = dag.dag_id
            ti.start_date = start_date
            session.add(dag_run)
            session.add(ti)
        session.commit()


@pytest.mark.db_test
class TestTaskStoreCleanup:
    def test_expired_rows_deleted(self):
        cfg = config_dict["task_state_store"]
        now = pendulum.now(tz="UTC")
        past = now.subtract(days=30)
        future = now.add(days=30)

        with create_session() as session:
            bundle = DagBundleModel(name="ts_test_bundle")
            session.add(bundle)
            session.flush()

            dag = DAG(dag_id="ts_test_dag")
            dm = DagModel(dag_id="ts_test_dag", bundle_name="ts_test_bundle")
            session.add(dm)
            SerializedDagModel.write_dag(LazyDeserializedDAG.from_dag(dag), bundle_name="ts_test_bundle")

            dag_run = DagRun(
                "ts_test_dag",
                run_id="ts_test_run",
                run_type=DagRunType.SCHEDULED,
                start_date=past,
            )
            session.add(dag_run)
            session.flush()

            expired = TaskStateStoreModel(
                dag_run_id=dag_run.id,
                task_id="t1",
                map_index=-1,
                key="job_id",
                dag_id="ts_test_dag",
                run_id="ts_test_run",
                value="job-expired",
                updated_at=past,
                expires_at=past.subtract(days=1),
            )
            never_expire = TaskStateStoreModel(
                dag_run_id=dag_run.id,
                task_id="t1",
                map_index=-1,
                key="result",
                dag_id="ts_test_dag",
                run_id="ts_test_run",
                value="job-never-expire",
                updated_at=past,
                expires_at=None,
            )
            not_yet_expired = TaskStateStoreModel(
                dag_run_id=dag_run.id,
                task_id="t1",
                map_index=-1,
                key="future_key",
                dag_id="ts_test_dag",
                run_id="ts_test_run",
                value="job-future",
                updated_at=past,
                expires_at=future,
            )
            session.add_all([expired, never_expire, not_yet_expired])
            session.commit()

        cutoff = now.subtract(hours=1)
        with create_session() as session:
            _cleanup_table(
                **cfg.__dict__,
                clean_before_timestamp=cutoff,
                dry_run=False,
                verbose=False,
                confirm=False,
                skip_archive=True,
                session=session,
            )

        with create_session() as session:
            not_deleted = {
                row.key
                for row in session.scalars(
                    select(TaskStateStoreModel).where(TaskStateStoreModel.dag_id == "ts_test_dag")
                ).all()
            }

        assert "job_id" not in not_deleted, "expired row should be deleted"
        assert "result" in not_deleted, "NEVER_EXPIRE row (expires_at=NULL) must survive"
        assert "future_key" in not_deleted, "not-yet-expired row must survive"


@pytest.mark.db_test
class TestConnectionTestRequestCleanup:
    """Verify db_cleanup never deletes in-flight connection tests (kaxil r3169602754)."""

    def setup_method(self):
        from tests_common.test_utils.db import clear_db_connection_tests

        clear_db_connection_tests()

    def teardown_method(self):
        from tests_common.test_utils.db import clear_db_connection_tests

        clear_db_connection_tests()

    def test_extra_filters_keep_in_flight_rows(self):
        """Even past the cutoff, PENDING/QUEUED/RUNNING rows survive cleanup; SUCCESS/FAILED don't."""
        from datetime import timezone

        import uuid6

        from airflow.models.connection_test import ConnectionTestRequest, ConnectionTestState
        from airflow.utils.db_cleanup import config_dict
        from airflow.utils.session import create_session

        cfg = config_dict["connection_test_request"]
        old = pendulum.now(tz="UTC").subtract(days=30)
        seeded: dict[str, str] = {}
        with create_session() as s:
            for state in ConnectionTestState:
                ct = ConnectionTestRequest(connection_id=f"cleanup_probe_{state.value}", conn_type="http")
                ct.id = uuid6.uuid7()
                ct.state = state
                ct.updated_at = old.in_timezone(timezone.utc)
                s.add(ct)
                seeded[state.value] = str(ct.id)
            s.commit()

        # Run cleanup with a cutoff well past every seeded row.
        cutoff = pendulum.now(tz="UTC").subtract(days=1)
        with create_session() as session:
            _cleanup_table(
                **cfg.__dict__,
                clean_before_timestamp=cutoff,
                dry_run=False,
                verbose=False,
                confirm=False,
                skip_archive=True,
                session=session,
            )

        with create_session() as s:
            survivors = {
                str(row.id)
                for row in s.scalars(
                    select(ConnectionTestRequest).where(
                        ConnectionTestRequest.connection_id.like("cleanup_probe_%")
                    )
                ).all()
            }

        # In-flight states must still be present; terminal states must be gone.
        for state in ("pending", "queued", "running"):
            assert seeded[state] in survivors, f"{state} row should NOT be cleaned up"
        for state in ("success", "failed"):
            assert seeded[state] not in survivors, f"{state} row should be cleaned up"


def _delete_test_timestamp():
    return pendulum.DateTime(2024, 1, 2, 3, 4, 5, tzinfo=pendulum.timezone("UTC"))


def _build_do_delete_test_objects():
    metadata = MetaData()
    source_table = Table("dag_version", metadata, Column("id", Integer, primary_key=True))
    target_table = Table(
        f"{ARCHIVE_TABLE_PREFIX}{source_table.name}__20240102030405",
        metadata,
        Column("id", Integer, primary_key=True),
    )
    query = select(literal(1).label("id"))
    return metadata, source_table, target_table, query


def _create_pinned_dag_version_cleanup_data(*, base_date):
    bundle_name = f"testing-{uuid4()}"
    dag_id = f"test-dag_{uuid4()}"

    with create_session() as session:
        session.add(DagBundleModel(name=bundle_name))
        session.flush()

        dag = DAG(dag_id=dag_id)
        session.add(DagModel(dag_id=dag_id, bundle_name=bundle_name))

        old_dag_version = DagVersion(
            dag_id=dag_id,
            version_number=1,
            bundle_name=bundle_name,
            created_at=base_date,
            last_updated=base_date,
        )
        new_dag_version = DagVersion(
            dag_id=dag_id,
            version_number=2,
            bundle_name=bundle_name,
            created_at=base_date.add(minutes=1),
            last_updated=base_date.add(minutes=1),
        )
        session.add_all([old_dag_version, new_dag_version])
        session.flush()

        dag_run = DagRun(
            dag_id,
            run_id="run-1",
            run_type=DagRunType.MANUAL,
            start_date=base_date,
        )
        task = PythonOperator(task_id="dummy-task", dag=dag, python_callable=print)
        ti = create_task_instance(task, run_id=dag_run.run_id, dag_version_id=old_dag_version.id)
        ti.dag_id = dag_id
        ti.start_date = base_date

        session.add_all([dag_run, ti])
        session.commit()

    return base_date.add(days=1)


def _get_dag_version_archive_table_names(*, session):
    return [
        table_name
        for table_name in _get_archived_table_names(["dag_version"], session)
        if table_name.startswith(f"{ARCHIVE_TABLE_PREFIX}dag_version__")
    ]


def _dag_version_config_without_row_exclusion():
    """Live dag_version cleanup config with row-exclusion filters disabled.

    The backend regression tests above pin ``_do_delete``'s rollback-before-drop
    behaviour, which requires the
    DELETE to actually hit the ``task_instance.dag_version_id`` FK violation.
    The live config may exclude FK-pinned rows from the deletion query (see
    PR #68339), which would turn these tests into no-ops -- so strip any such
    filters from a copy of the config.
    """
    config = dict(config_dict["dag_version"].__dict__)
    for key in ("extra_filters", "skip_if_referenced"):
        if key in config:
            config[key] = None
    return config


class TestSchemaQualifiedTableConfig:
    """
    ``_TableConfig`` / ``reflect_tables`` support for schema-qualified table names.

    A table config may be schema-qualified with ``schema.table`` dot notation so that
    ``airflow db clean`` can reach a table living in a schema other than the metadata
    connection's default (for example a result backend provisioned into its own schema),
    instead of silently skipping it.
    """

    def test_table_config_parses_schema_qualified_table_name(self):
        config = _TableConfig(table_name="my_schema.some_table", recency_column_name="date_done")
        assert config.schema_name == "my_schema"
        assert config.bare_table_name == "some_table"
        assert config.table_name == "my_schema.some_table"
        assert config.orm_model.schema == "my_schema"
        assert config.orm_model.name == "some_table"

    def test_table_config_without_schema_prefix(self):
        config = _TableConfig(table_name="some_table", recency_column_name="date_done")
        assert config.schema_name is None
        assert config.bare_table_name == "some_table"
        assert config.table_name == "some_table"
        assert config.orm_model.schema is None


@pytest.mark.backend("postgres")
class TestSchemaQualifiedTableCleanupIntegration:
    """
    End-to-end db clean + archive + export/drop against a schema-qualified table config --
    the scenario a table provisioned into a non-default schema (e.g. a schema-split result
    backend) hits.
    """

    SCHEMA = "test_schema_qualified_cleanup"
    TABLE = "schema_qualified_cleanup_test"

    def setup_method(self):
        with create_session() as session:
            session.execute(text(f"DROP SCHEMA IF EXISTS {self.SCHEMA} CASCADE"))
            session.execute(text(f"CREATE SCHEMA {self.SCHEMA}"))
            session.execute(
                text(
                    f"CREATE TABLE {self.SCHEMA}.{self.TABLE} "
                    "(id serial primary key, task_id varchar(155), date_done timestamp)"
                )
            )
            session.commit()

    def teardown_method(self):
        with create_session() as session:
            session.execute(text(f"DROP SCHEMA IF EXISTS {self.SCHEMA} CASCADE"))
            session.commit()

    def test_clean_archive_export_and_drop_schema_qualified_table(self, tmp_path):
        old_date = pendulum.now("UTC").subtract(days=400)
        new_date = pendulum.now("UTC")
        with create_session() as session:
            session.execute(
                text(
                    f"INSERT INTO {self.SCHEMA}.{self.TABLE} (task_id, date_done) "
                    "VALUES ('old-task', :old_date), ('new-task', :new_date)"
                ),
                {"old_date": old_date, "new_date": new_date},
            )
            session.commit()

        qualified_name = f"{self.SCHEMA}.{self.TABLE}"
        # Register a schema-qualified table config for the duration of the test rather than
        # relying on any provider-specific configuration -- this exercises the generic
        # schema-qualified support directly.
        test_config = _TableConfig(table_name=qualified_name, recency_column_name="date_done")
        with patch.dict(config_dict, {qualified_name: test_config}):
            assert qualified_name in config_dict

            with create_session() as session:
                run_cleanup(
                    clean_before_timestamp=pendulum.now("UTC").subtract(days=300),
                    table_names=[qualified_name],
                    dry_run=False,
                    confirm=False,
                    session=session,
                )

                remaining = session.execute(text(f"SELECT task_id FROM {qualified_name}")).scalars().all()
                assert remaining == ["new-task"]

                archived = _get_archived_table_names([qualified_name], session)
                assert len(archived) == 1
                assert archived[0].startswith(f"{self.SCHEMA}.")

                archived_rows = session.execute(text(f"SELECT task_id FROM {archived[0]}")).scalars().all()
                assert archived_rows == ["old-task"]

                export_archived_records(
                    export_format="csv",
                    output_path=str(tmp_path),
                    table_names=[qualified_name],
                    drop_archives=True,
                    needs_confirm=False,
                    session=session,
                )
                # export_archived_records takes a caller-owned session and does not commit it;
                # commit here so the reflection-based existence check below, which may use a
                # separate connection, observes the DROP TABLE.
                session.commit()

                assert _get_archived_table_names([qualified_name], session) == []
