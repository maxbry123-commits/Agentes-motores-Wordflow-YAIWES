#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

from unittest import mock

import pytest

from airflow.configuration import ensure_secrets_loaded, initialize_secrets_backends
from airflow.models import Connection, Variable
from airflow.sdk import SecretCache
from airflow.sdk.exceptions import AirflowNotFoundException
from airflow.secrets import BaseSecretsBackend

from tests_common.test_utils.config import conf_vars
from tests_common.test_utils.db import clear_db_variables
from tests_common.test_utils.fake_secrets_backend import FAKE_BACKEND_PATH, FakeSecretsBackend


class TestConnectionsFromSecrets:
    def setup_method(self) -> None:
        SecretCache.reset()

    @mock.patch("airflow.secrets.metastore.MetastoreBackend.get_connection")
    @mock.patch("airflow.secrets.environment_variables.EnvironmentVariablesBackend.get_connection")
    def test_get_connection_second_try(self, mock_env_get, mock_meta_get):
        mock_env_get.side_effect = [None]  # return None
        Connection.get_connection_from_secrets("fake_conn_id")
        mock_meta_get.assert_called_once_with(conn_id="fake_conn_id", team_name=None)
        mock_env_get.assert_called_once_with(conn_id="fake_conn_id", team_name=None)

    @mock.patch("airflow.secrets.metastore.MetastoreBackend.get_connection")
    @mock.patch("airflow.secrets.environment_variables.EnvironmentVariablesBackend.get_connection")
    def test_get_connection_first_try(self, mock_env_get, mock_meta_get):
        mock_env_get.return_value = Connection("something")  # returns something
        Connection.get_connection_from_secrets("fake_conn_id")
        mock_env_get.assert_called_once_with(conn_id="fake_conn_id", team_name=None)
        mock_meta_get.assert_not_called()

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"connections_prefix": "/airflow"}',
        }
    )
    def test_initialize_secrets_backends(self):
        backends = initialize_secrets_backends()
        backend_classes = [backend.__class__.__name__ for backend in backends]

        assert len(backends) == 3
        assert "FakeSecretsBackend" in backend_classes

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"use_ssl": false}',
        }
    )
    def test_backends_kwargs(self):
        backends = initialize_secrets_backends()
        fake_backend = next(
            backend for backend in backends if backend.__class__.__name__ == "FakeSecretsBackend"
        )
        assert fake_backend.kwargs == {}
        assert fake_backend.use_ssl is False

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"connections_prefix": "/airflow"}',
        }
    )
    @mock.patch.dict(
        "os.environ",
        {
            "AIRFLOW_CONN_TEST_MYSQL": "mysql://airflow:airflow@host:5432/airflow",
        },
    )
    @mock.patch.object(FakeSecretsBackend, "get_connection")
    def test_backend_fallback_to_env_var(self, mock_get_connection):
        mock_get_connection.return_value = None

        backends = ensure_secrets_loaded()
        backend_classes = [backend.__class__.__name__ for backend in backends]
        assert "FakeSecretsBackend" in backend_classes

        conn = Connection.get_connection_from_secrets(conn_id="test_mysql")

        mock_get_connection.assert_called_once_with(conn_id="test_mysql", team_name=None)

        assert conn.get_uri() == "mysql://airflow:airflow@host:5432/airflow"

    @pytest.mark.db_test
    @conf_vars({("core", "multi_team"): "True"})
    @mock.patch.dict(
        "os.environ",
        {
            "AIRFLOW_CONN__TEAM___TEST_MYSQL": "mysql://airflow:airflow@host:5432/airflow",
        },
    )
    def test_connection_env_var_do_not_access_team_specific(self):
        with pytest.raises(AirflowNotFoundException, match=r"The conn_id `_team___test_mysql` isn't defined"):
            Connection.get_connection_from_secrets(conn_id="_team___test_mysql")


@pytest.mark.db_test
class TestVariableFromSecrets:
    def setup_method(self) -> None:
        clear_db_variables()
        SecretCache.reset()

    def teardown_method(self) -> None:
        clear_db_variables()

    @mock.patch("airflow.secrets.metastore.MetastoreBackend.get_variable")
    @mock.patch("airflow.secrets.environment_variables.EnvironmentVariablesBackend.get_variable")
    def test_get_variable_second_try(self, mock_env_get, mock_meta_get):
        """
        Test if Variable is not present in Environment Variable, it then looks for it in
        Metastore DB
        """
        mock_env_get.return_value = None
        mock_meta_get.return_value = "val"

        Variable.get_variable_from_secrets("fake_var_key")

        mock_meta_get.assert_called_once_with(key="fake_var_key", team_name=None)
        mock_env_get.assert_called_once_with(key="fake_var_key", team_name=None)

    @mock.patch("airflow.secrets.metastore.MetastoreBackend.get_variable")
    @mock.patch("airflow.secrets.environment_variables.EnvironmentVariablesBackend.get_variable")
    def test_get_variable_first_try(self, mock_env_get, mock_meta_get):
        """
        Test if Variable is present in Environment Variable, it does not look for it in
        Metastore DB
        """
        mock_env_get.return_value = "something"
        Variable.get_variable_from_secrets("fake_var_key")
        mock_env_get.assert_called_once_with(key="fake_var_key", team_name=None)
        mock_meta_get.assert_not_called()

    def test_backend_fallback_to_default_var(self):
        """
        Test if a default_var is defined and no backend has the Variable,
        the value returned is default_var
        """
        variable_value = Variable.get(key="test_var", default_var="new")
        assert variable_value == "new"

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"variables_prefix": "/airflow"}',
        }
    )
    @mock.patch.dict(
        "os.environ",
        {
            "AIRFLOW_VAR_MYVAR": "a_venv_value",
        },
    )
    @mock.patch("airflow.secrets.metastore.MetastoreBackend.get_variable")
    @mock.patch.object(FakeSecretsBackend, "get_variable")
    def test_backend_variable_order(self, mock_secret_get, mock_meta_get):
        backends = ensure_secrets_loaded()
        backend_classes = [backend.__class__.__name__ for backend in backends]
        assert "FakeSecretsBackend" in backend_classes

        mock_secret_get.return_value = None
        mock_meta_get.return_value = None

        assert Variable.get(key="MYVAR") == "a_venv_value"
        mock_secret_get.assert_called_with(key="MYVAR", team_name=None)
        mock_meta_get.assert_not_called()

        mock_secret_get.return_value = None
        mock_meta_get.return_value = "a_metastore_value"
        assert Variable.get(key="not_myvar") == "a_metastore_value"
        mock_meta_get.assert_called_once_with(key="not_myvar", team_name=None)

        mock_secret_get.return_value = "a_secret_value"
        assert Variable.get(key="not_myvar") == "a_secret_value"

    @conf_vars({("core", "multi_team"): "True"})
    @mock.patch.dict(
        "os.environ",
        {
            "AIRFLOW_VAR__TEAM___MYVAR": "value",
        },
    )
    def test_variable_env_var_do_not_access_team_specific(self):
        assert Variable.get_variable_from_secrets(key="_team___myvar") is None


class _TeamUnawareGetConnectionBackend(BaseSecretsBackend):
    """Backend overriding ``get_connection`` with the pre-3.2 ``(self, conn_id)`` signature (e.g. Vault)."""

    def __init__(self, conns: dict[str, Connection]):
        self._conns = conns

    def get_connection(self, conn_id):
        return self._conns.get(conn_id)


class _TeamUnawareGetVariableBackend(BaseSecretsBackend):
    """Backend overriding ``get_variable`` with the pre-3.2 ``(self, key)`` signature."""

    def __init__(self, variables: dict[str, str]):
        self._vars = variables

    def get_variable(self, key):
        return self._vars.get(key)


class TestTeamUnawareBackendSignatureCompat:
    """Backends whose overrides predate the ``team_name`` keyword must keep working (issue #1333)."""

    def setup_method(self) -> None:
        SecretCache.reset()

    @pytest.mark.parametrize("team_name", [None, "team_a"])
    @conf_vars({("core", "multi_team"): "True"})
    @mock.patch.dict("sys.modules", {"airflow.sdk.execution_time.task_runner": None})
    def test_get_connection_with_team_unaware_override(self, team_name):
        backend = _TeamUnawareGetConnectionBackend(
            {"team_unaware_conn": Connection(conn_id="team_unaware_conn", conn_type="mysql", host="h")}
        )
        with mock.patch("airflow.configuration.ensure_secrets_loaded", return_value=[backend]):
            conn = Connection.get_connection_from_secrets("team_unaware_conn", team_name=team_name)

        assert conn.conn_id == "team_unaware_conn"
        assert conn.conn_type == "mysql"

    @pytest.mark.parametrize("team_name", [None, "team_a"])
    def test_get_variable_with_team_unaware_override(self, team_name):
        backend = _TeamUnawareGetVariableBackend({"team_unaware_var": "secret_value"})
        with mock.patch("airflow.models.variable.ensure_secrets_loaded", return_value=[backend]):
            value = Variable.get_variable_from_secrets("team_unaware_var", team_name=team_name)

        assert value == "secret_value"


class TestSecretBackendKwargEnvVars:
    """Test per-key env var overrides for secrets backend kwargs."""

    def setup_method(self) -> None:
        SecretCache.reset()

    @conf_vars({("secrets", "backend"): FAKE_BACKEND_PATH})
    @mock.patch.dict(
        "os.environ",
        {"AIRFLOW__SECRETS__BACKEND_KWARG__CONNECTIONS_PREFIX": "/airflow/connections"},
    )
    def test_backend_kwarg_env_vars_basic(self):
        """Per-key env var is picked up when no JSON blob is set."""
        backends = initialize_secrets_backends()
        fake_backend = next(b for b in backends if b.__class__.__name__ == "FakeSecretsBackend")
        assert fake_backend.connections_prefix == "/airflow/connections"

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"connections_prefix": "/old"}',
        }
    )
    @mock.patch.dict(
        "os.environ",
        {"AIRFLOW__SECRETS__BACKEND_KWARG__CONNECTIONS_PREFIX": "/new"},
    )
    def test_backend_kwarg_env_vars_override_json(self):
        """Per-key env var overrides the same key in the JSON blob."""
        backends = initialize_secrets_backends()
        fake_backend = next(b for b in backends if b.__class__.__name__ == "FakeSecretsBackend")
        assert fake_backend.connections_prefix == "/new"

    @conf_vars(
        {
            ("secrets", "backend"): FAKE_BACKEND_PATH,
            ("secrets", "backend_kwargs"): '{"connections_prefix": "/airflow"}',
        }
    )
    @mock.patch.dict(
        "os.environ",
        {"AIRFLOW__SECRETS__BACKEND_KWARG__VARIABLES_PREFIX": "/airflow/variables"},
    )
    def test_backend_kwarg_env_vars_merge_with_json(self):
        """Per-key env var is merged with (not replacing) the JSON blob."""
        backends = initialize_secrets_backends()
        fake_backend = next(b for b in backends if b.__class__.__name__ == "FakeSecretsBackend")
        assert fake_backend.connections_prefix == "/airflow"
        assert fake_backend.variables_prefix == "/airflow/variables"
