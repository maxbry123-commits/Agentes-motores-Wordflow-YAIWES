# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import logging
import os
import socket
import subprocess
import time
from typing import TYPE_CHECKING, Any

import pytest
import requests
from sqlalchemy import select

from airflow.models.taskinstance import TaskInstance
from airflow.utils.session import create_session
from airflow.utils.state import State

from tests_common.test_utils.integration_setup import (
    serialize_and_get_dags,
    start_scheduler,
    terminate_process,
    unpause_trigger_dag_and_get_run_id,
    wait_for_dag_run,
)
from tests_common.test_utils.otel_utils import (
    dump_airflow_metadata_db,
    extract_metrics_from_output,
)

if TYPE_CHECKING:
    from airflow.serialization.definitions.dag import SerializedDAG

log = logging.getLogger("integration.otel.test_otel")


def wait_for_otel_collector(host: str, port: int, timeout: int = 120) -> None:
    """
    Wait for the OTel collector to be reachable before running tests.

    This prevents flaky test failures caused by transient DNS resolution issues
    (e.g., 'Temporary failure in name resolution' for breeze-otel-collector).

    Note: If the collector is not reachable after timeout, logs a warning but
    does not fail - allows tests to run and fail naturally if needed.
    """
    deadline = time.monotonic() + timeout
    last_error = None
    while time.monotonic() < deadline:
        try:
            # Test DNS resolution and TCP connectivity
            with socket.create_connection((host, port), timeout=5):
                pass
            log.info("OTel collector at %s:%d is reachable.", host, port)
            return
        except (socket.gaierror, TimeoutError, OSError) as e:
            last_error = e
            log.debug(
                "OTel collector at %s:%d not reachable: %s. Retrying...",
                host,
                port,
                e,
            )
            time.sleep(2)
    log.warning(
        "OTel collector at %s:%d is not reachable after %ds. Last error: %s. "
        "Tests will proceed but may fail if collector is required.",
        host,
        port,
        timeout,
        last_error,
    )


def print_ti_output_for_dag_run(dag_id: str, run_id: str):
    breeze_logs_dir = "/root/airflow/logs"

    # For structured logs, the path is:
    #   '/root/airflow/logs/dag_id=.../run_id=.../task_id=.../attempt=1.log'
    # TODO: if older airflow versions start throwing errors,
    #   then check if the path needs to be adjusted to something like
    #   '/root/airflow/logs/<dag_id>/<task_id>/<run_id>/...'
    dag_run_path = os.path.join(breeze_logs_dir, f"dag_id={dag_id}", f"run_id={run_id}")

    for root, _dirs, files in os.walk(dag_run_path):
        for filename in files:
            if filename.endswith(".log"):
                full_path = os.path.join(root, filename)
                print("\n===== LOG FILE: %s - START =====\n", full_path)
                try:
                    with open(full_path) as f:
                        print(f.read())
                except Exception as e:
                    log.error("Could not read %s: %s", full_path, e)

                print("\n===== END =====\n")


@pytest.mark.integration("otel")
@pytest.mark.backend("postgres")
class TestOtelIntegration:
    """
    This test is using a ConsoleSpanExporter so that it can capture
    the spans from the stdout and run assertions on them.

    It can also be used with otel and jaeger for manual testing.
    To export the spans to otel and visualize them with jaeger,
    - start breeze with '--integration otel'
    - run on the shell 'export use_otel=true'
    - run the test
    - check 'http://localhost:26686/'

    To get a db dump on the stdout, run 'export log_level=debug'.
    """

    test_dir = os.path.dirname(os.path.abspath(__file__))
    dag_folder = os.path.join(test_dir, "dags")

    use_otel = os.getenv("use_otel", default="false")
    log_level = os.getenv("log_level", default="none")

    dags: dict[str, SerializedDAG] = {}

    @classmethod
    def setup_class(cls):
        otel_host = "breeze-otel-collector"
        otel_port = 4318

        # Wait for OTel collector to be reachable before running tests.
        # This prevents flaky test failures caused by transient DNS resolution issues
        # during scheduler handoff (see https://github.com/apache/airflow/issues/61070).
        wait_for_otel_collector(otel_host, otel_port)

        # The pytest plugin strips AIRFLOW__*__* env vars (including the JWT secret set
        # by Breeze). Both the scheduler and api-server subprocesses must share the same
        # secret; otherwise each generates its own random key and token verification fails.
        os.environ["AIRFLOW__API_AUTH__JWT_SECRET"] = "test-secret-key-for-testing"
        os.environ["AIRFLOW__API_AUTH__JWT_ISSUER"] = "airflow"
        os.environ["AIRFLOW__TRACES__OTEL_ON"] = "True"
        os.environ["OTEL_EXPORTER_OTLP_PROTOCOL"] = "http/protobuf"
        os.environ["OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"] = "http://breeze-otel-collector:4318/v1/traces"

        os.environ["AIRFLOW__SCHEDULER__STANDALONE_DAG_PROCESSOR"] = "False"
        os.environ["AIRFLOW__SCHEDULER__PROCESSOR_POLL_INTERVAL"] = "2"

        # The heartrate is determined by the conf "AIRFLOW__SCHEDULER__SCHEDULER_HEARTBEAT_SEC".
        # By default, the heartrate is 5 seconds. Every iteration of the scheduler loop, checks the
        # time passed since the last heartbeat and if it was longer than the 5 second heartrate,
        # it performs a heartbeat update.
        # If there hasn't been a heartbeat for an amount of time longer than the
        # SCHEDULER_HEALTH_CHECK_THRESHOLD, then the scheduler is considered unhealthy.
        # Approximately, there is a scheduler heartbeat every 5-6 seconds. Set the threshold to 15.
        os.environ["AIRFLOW__SCHEDULER__SCHEDULER_HEALTH_CHECK_THRESHOLD"] = "15"

        os.environ["AIRFLOW__CORE__DAGS_FOLDER"] = f"{cls.dag_folder}"

        os.environ["AIRFLOW__CORE__LOAD_EXAMPLES"] = "False"
        os.environ["AIRFLOW__CORE__PLUGINS_FOLDER"] = "/dev/null"
        os.environ["AIRFLOW__CORE__UNIT_TEST_MODE"] = "False"

        if cls.log_level == "debug":
            log.setLevel(logging.DEBUG)

        # Reset the DB once at the beginning and serialize the dags.
        reset_command = ["airflow", "db", "reset", "--yes"]
        subprocess.run(reset_command, check=True, env=os.environ.copy())

        migrate_command = ["airflow", "db", "migrate"]
        subprocess.run(migrate_command, check=True, env=os.environ.copy())

        cls.dags = serialize_and_get_dags(dag_folder=cls.dag_folder)

    def dag_execution_for_testing_metrics(self, capfd):
        # Metrics.
        os.environ["AIRFLOW__METRICS__OTEL_ON"] = "True"
        os.environ["OTEL_EXPORTER_OTLP_METRICS_ENDPOINT"] = "http://breeze-otel-collector:4318/v1/metrics"
        os.environ["OTEL_METRIC_EXPORT_INTERVAL"] = "5000"

        if self.use_otel != "true":
            os.environ["OTEL_METRICS_EXPORTER"] = "console"

        scheduler_process = None
        apiserver_process = None
        try:
            # Start the processes here and not as fixtures or in a common setup,
            # so that the test can capture their output.
            scheduler_process, apiserver_process = start_scheduler(capture_output=True)

            dag_id = "otel_test_dag"

            assert len(self.dags) > 0
            dag = self.dags[dag_id]

            assert dag is not None

            run_id = unpause_trigger_dag_and_get_run_id(dag_id=dag_id)

            state = wait_for_dag_run(dag_id=dag_id, run_id=run_id, max_wait_time=90)
            assert state == State.SUCCESS, f"Dag run did not complete successfully. Final state: {state}."

            # wait_for_dag_run returns on the dag_run DB state, but OTel metrics are exported
            # asynchronously, so wait for them to reach stdout before we capture it below.
            time.sleep(10)

            task_dict = dag.task_dict
            task_dict_ids = task_dict.keys()

            for task_id in task_dict_ids:
                ti = self._get_ti(dag_id, run_id, task_id)
                assert ti is not None
                assert ti.state == State.SUCCESS

            print_ti_output_for_dag_run(dag_id=dag_id, run_id=run_id)
        finally:
            # Terminate the processes.

            terminate_process(scheduler_process)
            scheduler_status = scheduler_process.poll()
            assert scheduler_status is not None, (
                "The scheduler_1 process status is None, which means that it hasn't terminated as expected."
            )

            terminate_process(apiserver_process)
            apiserver_status = apiserver_process.poll()
            assert apiserver_status is not None, (
                "The apiserver process status is None, which means that it hasn't terminated as expected."
            )

        out, _err = capfd.readouterr()
        return out, dag

    def _get_ti(self, dag_id: str, run_id: str, task_id: str) -> Any | None:
        with create_session() as session:
            ti = session.scalar(
                select(TaskInstance).where(
                    TaskInstance.task_id == task_id,
                    TaskInstance.dag_id == dag_id,
                    TaskInstance.run_id == run_id,
                )
            )
        return ti

    # 160s = 10s startup + 90s dag-run wait + 10s post-run sleep + 30s shutdown grace + 20s CI buffer
    @pytest.mark.execution_timeout(160)
    @pytest.mark.parametrize(
        ("legacy_names_on_bool", "legacy_names_exported"),
        [
            pytest.param(True, True, id="export_legacy_names"),
            pytest.param(False, False, id="dont_export_legacy_names"),
        ],
    )
    def test_export_legacy_metric_names(self, legacy_names_on_bool, legacy_names_exported, capfd):
        assert isinstance(legacy_names_on_bool, bool)
        os.environ["AIRFLOW__METRICS__LEGACY_NAMES_ON"] = str(legacy_names_on_bool)
        out, dag = self.dag_execution_for_testing_metrics(capfd)
        if self.use_otel != "true":
            assert isinstance(legacy_names_exported, bool)
            output_lines = out.splitlines()
            metrics_dict = extract_metrics_from_output(output_lines)

            legacy_metric_names = [
                f"airflow.dagrun.dependency-check.{dag.dag_id}",
                f"airflow.dagrun.duration.success.{dag.dag_id}",
            ]

            for task_id in dag.task_ids:
                legacy_metric_names.append(f"airflow.dag.{dag.dag_id}.{task_id}.scheduled_duration")

            new_metric_names = [
                "airflow.dagrun.dependency-check",
                "airflow.dagrun.duration.success",
                "airflow.task.scheduled_duration",
            ]

            assert set(new_metric_names).issubset(metrics_dict.keys())

            if legacy_names_exported:
                assert set(legacy_metric_names).issubset(metrics_dict.keys())

    @pytest.mark.execution_timeout(160)
    def test_export_metrics_during_process_shutdown(self, capfd):
        out, dag = self.dag_execution_for_testing_metrics(capfd)

        if self.use_otel != "true":
            # Test the metrics from the output.
            metrics_to_check = [
                "airflow.ti_successes",
                "airflow.operator_successes",
                "airflow.executor.running_tasks",
                "airflow.executor.queued_tasks",
                "airflow.executor.open_slots",
            ]
            output_lines = out.splitlines()

            metrics_dict = extract_metrics_from_output(output_lines)

            assert set(metrics_to_check).issubset(metrics_dict.keys())

    @pytest.mark.execution_timeout(160)
    @pytest.mark.parametrize(
        ("task_span_detail_level", "expected_hierarchy"),
        [
            pytest.param(
                None,
                {
                    "dag_run.otel_test_dag": None,
                    "sub_span1": "worker.task1",
                    "task_run.task1": "dag_run.otel_test_dag",
                    "worker.task1": "task_run.task1",
                },
                id="default_spans",
            ),
            pytest.param(
                2,
                # Additional detail spans are deferred to follow-up PRs; tracked
                # at https://linear.app/astronomer/issue/ACD-157.
                {
                    "_verify_bundle_access": "parse",
                    "parse": "startup",
                    "get_template_context": "startup",
                    "startup": "worker.task1",
                    "render_templates": "_prepare",
                    "_serialize_rendered_fields": "_prepare",
                    "_validate_task_inlets_and_outlets": "_prepare",
                    "_prepare": "run",
                    "_execute_task": "run",
                    "task.execute": "_execute_task",
                    "finalize": "worker.task1",
                    "run": "worker.task1",
                    "sub_span1": "task.execute",
                    "dag_run.otel_test_dag": None,
                    "task_run.task1": "dag_run.otel_test_dag",
                    "worker.task1": "task_run.task1",
                    # OpenLineage registers a listener by default, so its
                    # on_task_instance_running / on_task_instance_success hook
                    # calls get wrapped in spans at detail level > 1.
                    "listener.on_task_instance_running": "_prepare",
                    "listener.on_task_instance_success": "finalize",
                },
                id="detail_spans",
            ),
        ],
    )
    def test_dag_execution_succeeds(self, capfd, task_span_detail_level, expected_hierarchy):
        """The same scheduler will start and finish the dag processing."""
        scheduler_process = None
        apiserver_process = None
        try:
            # Start the processes here and not as fixtures or in a common setup,
            # so that the test can capture their output.
            scheduler_process, apiserver_process = start_scheduler()

            dag_id = "otel_test_dag"

            assert len(self.dags) > 0
            dag = self.dags[dag_id]

            assert dag is not None

            conf = None
            if task_span_detail_level is not None:
                from airflow_shared.observability.traces import TASK_SPAN_DETAIL_LEVEL_KEY

                conf = {TASK_SPAN_DETAIL_LEVEL_KEY: task_span_detail_level}

            run_id = unpause_trigger_dag_and_get_run_id(dag_id=dag_id, conf=conf)

            wait_for_dag_run(dag_id=dag_id, run_id=run_id, max_wait_time=90)

            # wait_for_dag_run returns on the dag_run DB state, but spans reach Jaeger
            # asynchronously via the BatchSpanProcessor, so wait before querying the trace below.
            time.sleep(10)

            print_ti_output_for_dag_run(dag_id=dag_id, run_id=run_id)
        finally:
            if self.log_level == "debug":
                with create_session() as session:
                    dump_airflow_metadata_db(session)

            # Terminate the processes.
            terminate_process(scheduler_process)
            scheduler_status = scheduler_process.poll()
            assert scheduler_status is not None, (
                "The scheduler_1 process status is None, which means that it hasn't terminated as expected."
            )

            terminate_process(apiserver_process)
            apiserver_status = apiserver_process.poll()
            assert apiserver_status is not None, (
                "The apiserver process status is None, which means that it hasn't terminated as expected."
            )

        capfd.readouterr()

        host = "jaeger"
        service_name = os.environ.get("OTEL_SERVICE_NAME", "test")
        r = requests.get(f"http://{host}:16686/api/traces?service={service_name}")
        data = r.json()
        # Find the trace for *this* dag run; selecting by position in the
        # response is flaky because earlier-test traces accumulate in Jaeger.
        matching = [
            t
            for t in data["data"]
            if any(
                tag.get("key") == "airflow.dag_run.run_id" and tag.get("value") == run_id
                for span in t["spans"]
                for tag in span.get("tags", [])
            )
        ]
        assert len(matching) == 1, f"expected exactly one trace for run_id={run_id}, got {len(matching)}"
        trace = matching[0]
        spans = trace["spans"]

        def get_span_hierarchy():
            spans_dict = {x["spanID"]: x for x in spans}

            def get_parent_span_id(span):
                parents = [x["spanID"] for x in span["references"] if x["refType"] == "CHILD_OF"]
                if parents:
                    parent_id = parents[0]
                    return spans_dict[parent_id]["operationName"]

            nested = {x["operationName"]: get_parent_span_id(x) for x in spans}
            return nested

        nested = get_span_hierarchy()
        assert nested == expected_hierarchy
