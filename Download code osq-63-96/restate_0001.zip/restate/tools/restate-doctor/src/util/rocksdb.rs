// Copyright (c) 2023 - 2026 Restate Software, Inc., Restate GmbH.
// All rights reserved.
//
// Use of this software is governed by the Business Source License
// included in the LICENSE file.
//
// As of the Change Date specified in that file, in accordance with
// the Business Source License, use of this software will be governed
// by the Apache License, Version 2.0.

//! Utilities for opening RocksDB databases in read-only mode for analysis.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use anyhow::{Context, Result, bail};
use restate_cli_util::c_warn;
use restate_cli_util::ui::console::confirm_or_exit;
use restate_partition_store::keys::KeyKind;
use rocksdb::{ColumnFamilyDescriptor, DB, LiveFile, Options};

/// Mode for opening the database.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum OpenMode {
    /// Open as a secondary instance (default). Safe to run while the primary
    /// (Restate server) has the database open read-write, and equally fine when
    /// the server is stopped.
    #[default]
    Secondary,
    /// Open in RocksDB read-only mode.
    ///
    /// DANGEROUS: this WILL corrupt the database if a Restate server currently
    /// has it open. Only use when the server is fully stopped.
    ReadOnly,
}

/// The default column family name in RocksDB (not used for partition data)
pub const DEFAULT_CF: &str = "default";

/// Extended information from `live_files()` that isn't available in column family metadata
#[derive(Debug, Clone)]
pub struct LiveFileInfo {
    /// Column family this file belongs to
    pub column_family_name: String,
    /// Level in the LSM tree
    pub level: i32,
    /// Number of live entries in the file
    pub num_entries: u64,
    /// Number of deletion tombstones in the file
    pub num_deletions: u64,
    /// Smallest sequence number in the file
    #[allow(dead_code)]
    pub smallest_seqno: u64,
    /// Largest sequence number in the file
    #[allow(dead_code)]
    pub largest_seqno: u64,
}

impl From<&LiveFile> for LiveFileInfo {
    fn from(lf: &LiveFile) -> Self {
        Self {
            column_family_name: lf.column_family_name.clone(),
            level: lf.level,
            num_entries: lf.num_entries,
            num_deletions: lf.num_deletions,
            smallest_seqno: lf.smallest_seqno,
            largest_seqno: lf.largest_seqno,
        }
    }
}

/// Information about an opened RocksDB database
pub struct DbInfo {
    pub db: DB,
    pub column_families: Vec<String>,
    /// Live file info keyed by filename (e.g., "012345.sst")
    live_files: HashMap<String, LiveFileInfo>,
}

impl DbInfo {
    /// Returns an iterator over data column families (excludes "default")
    pub fn data_cfs(&self) -> impl Iterator<Item = &String> {
        self.column_families
            .iter()
            .filter(|name| name.as_str() != DEFAULT_CF)
    }

    /// Get live file info by filename (e.g., "012345.sst")
    pub fn get_live_file_info(&self, filename: &str) -> Option<&LiveFileInfo> {
        self.live_files.get(filename)
    }

    /// Find a file by its number (e.g., 12345), returns (filename, info) if found
    #[allow(dead_code)] // Used by sst command
    pub fn find_file_by_number(&self, file_num: u64) -> Option<(&str, &LiveFileInfo)> {
        // Search all filenames for a matching file number
        self.live_files.iter().find_map(|(name, info)| {
            extract_file_number(name)
                .filter(|&num| num == file_num)
                .map(|_| (name.as_str(), info))
        })
    }
}

/// Extract the file number from an SST filename (e.g., "012345.sst" -> 12345)
pub fn extract_file_number(filename: &str) -> Option<u64> {
    filename
        .strip_suffix(".sst")
        .and_then(|s| s.parse::<u64>().ok())
}

/// Open a RocksDB database for analysis with default CF options.
///
/// See [`OpenMode`] for the trade-offs between secondary (default, safe) and
/// read-only mode. If `max_open_files` is `Some`, limits the number of open
/// file handles RocksDB will use in read-only mode; it is ignored in secondary
/// mode as it requires setting this to `-1` (unlimited).
pub fn open_partition_store_db(
    path: impl AsRef<Path>,
    mode: OpenMode,
    max_open_files: Option<i32>,
) -> Result<DbInfo> {
    open_db_with_cf_options(path, mode, max_open_files, |_| {
        let mut opts = Options::default();
        opts.set_merge_operator(
            "PartitionMerge",
            KeyKind::full_merge,
            KeyKind::partial_merge,
        );
        opts
    })
}

/// Open a RocksDB database for analysis with per-CF options.
///
/// `cf_opts_fn` is called for each column family name and should return the
/// `Options` to use when opening that CF. This is required when the database
/// was created with CF-specific settings (e.g., prefix extractor, merge
/// operators) that must match at open time.
pub fn open_db_with_cf_options(
    path: impl AsRef<Path>,
    mode: OpenMode,
    max_open_files: Option<i32>,
    cf_opts_fn: impl Fn(&str) -> Options,
) -> Result<DbInfo> {
    let path = path.as_ref().to_path_buf();

    if !path.exists() {
        bail!("Database path does not exist: {}", path.display());
    }

    // Discover column families
    let cf_names = DB::list_cf(&Options::default(), &path)
        .context("Failed to list column families. Is this a valid RocksDB database?")?;

    tracing::info!(
        "Opening database at {} with {} column families",
        path.display(),
        cf_names.len()
    );

    let mut opts = Options::default();
    match mode {
        // A secondary reading mode must set `max_open_files` must be -1 (unlimited). Reject
        // any other explicit value.
        OpenMode::Secondary => {
            if let Some(limit) = max_open_files
                && limit != -1
            {
                bail!(
                    "--limit-open-files must be -1 (unlimited) in secondary mode; \
                     a secondary instance needs load all the files in case the primary \
                     unlinks them. Got {limit}."
                );
            }
            opts.set_max_open_files(-1);
        }
        OpenMode::ReadOnly => {
            if let Some(limit) = max_open_files {
                opts.set_max_open_files(limit);
            }
        }
    }

    opts.set_disable_auto_compactions(true);

    let descriptors: Vec<ColumnFamilyDescriptor> = cf_names
        .iter()
        .map(|name| ColumnFamilyDescriptor::new(name, cf_opts_fn(name)))
        .collect();

    let db = match mode {
        OpenMode::Secondary => {
            // Secondary mode requires a secondary path for WAL replay / catch-up.
            let secondary_path = std::env::temp_dir()
                .join(format!("restate-doctor-secondary-{}", std::process::id()));
            std::fs::create_dir_all(&secondary_path)?;

            DB::open_cf_descriptors_as_secondary(&opts, &path, &secondary_path, descriptors)
                .context("Failed to open database as secondary instance.")?
        }
        OpenMode::ReadOnly => {
            c_warn!(
                "Opening the database in READ-ONLY mode. This is UNSAFE if a Restate server \
                 currently has this database open and WILL corrupt a running server's database. Only \
                 use read-only mode when the server is fully stopped. The default secondary mode \
                 is always safe."
            );
            confirm_or_exit("Are you sure you want to open the database in read-only mode?")?;
            DB::open_cf_descriptors_read_only(&opts, &path, descriptors, false).context(
                "Failed to open database in read-only mode. This requires exclusive access - is \
                 the Restate server running? Omit --read-only to open a safe secondary instance \
                 instead.",
            )?
        }
    };

    // Collect live file info for tombstone analysis and file lookup
    // Note: LiveFile.name includes a leading '/' (e.g., "/012345.sst"), but
    // column family metadata returns relative filenames without the slash.
    // We normalize by stripping the leading slash.
    let live_files = db
        .live_files()
        .map(|files| {
            files
                .iter()
                .map(|lf| {
                    let normalized_name = lf.name.strip_prefix('/').unwrap_or(&lf.name);
                    (normalized_name.to_string(), LiveFileInfo::from(lf))
                })
                .collect()
        })
        .unwrap_or_default();

    Ok(DbInfo {
        db,
        column_families: cf_names,
        live_files,
    })
}

/// Resolve the log store path from data directory or explicit path
pub fn resolve_log_store_path(
    data_dir: Option<&Path>,
    explicit_path: Option<&Path>,
) -> Result<PathBuf> {
    if let Some(path) = explicit_path {
        return Ok(path.to_path_buf());
    }

    if let Some(data_dir) = data_dir {
        let db_path = data_dir.join("log-store");
        if db_path.exists() {
            return Ok(db_path);
        }
        bail!(
            "Could not find log store at {}/log-store. Specify --path explicitly.",
            data_dir.display()
        );
    }

    bail!("Either --data-dir or --path must be specified");
}

/// Resolve the partition store path from data directory or explicit path
pub fn resolve_partition_store_path(
    data_dir: Option<&Path>,
    explicit_path: Option<&Path>,
) -> Result<PathBuf> {
    if let Some(path) = explicit_path {
        return Ok(path.to_path_buf());
    }

    if let Some(data_dir) = data_dir {
        let db_path = data_dir.join("db");
        if db_path.exists() {
            return Ok(db_path);
        }
        bail!(
            "Could not find partition store at {}/db. Specify --path explicitly.",
            data_dir.display()
        );
    }

    bail!("Either --data-dir or --path must be specified");
}
