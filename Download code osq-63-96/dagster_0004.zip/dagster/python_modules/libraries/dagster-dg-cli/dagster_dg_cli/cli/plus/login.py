import webbrowser

import click
from dagster_dg_core.utils import DgClickCommand
from dagster_dg_core.utils.telemetry import cli_telemetry_wrapper
from dagster_shared.plus.config import DagsterPlusCliConfig

from dagster_dg_cli.utils.plus.gql import FULL_DEPLOYMENTS_QUERY

EU_DAGSTER_CLOUD_URL = "https://eu.dagster.cloud"


@click.command(name="login", cls=DgClickCommand)
@click.option(
    "--region",
    type=click.Choice(["us", "eu"]),
    default=None,
    help="Dagster Cloud region to login to. Use 'eu' for European region.",
)
@cli_telemetry_wrapper
def login_command(region: str | None) -> None:
    """Login to Dagster Plus."""
    from dagster_rest_resources.gql_client import DagsterPlusGraphQLClient

    # Determine the base URL based on region
    if region == "eu":
        org_url = EU_DAGSTER_CLOUD_URL
    elif DagsterPlusCliConfig.exists():
        org_url = DagsterPlusCliConfig.get().url
    else:
        org_url = None

    from dagster_shared.plus.login_server import start_login_server

    server, url = start_login_server(org_url)

    try:
        webbrowser.open(url, new=0, autoraise=True)
        click.echo(
            f"Opening browser...\nIf a window does not open automatically, visit {url} to"
            " finish authorization"
        )
    except webbrowser.Error as e:
        click.echo(f"Error launching web browser: {e}\n\nTo finish authorization, visit {url}\n")

    server.serve_forever()
    new_org = server.get_organization()
    new_api_token = server.get_token()

    config = DagsterPlusCliConfig(
        organization=new_org,
        user_token=new_api_token,
        url=org_url,
    )
    config.write()
    click.echo(f"Authorized for organization {new_org}\n")

    gql_client = DagsterPlusGraphQLClient(
        url=config.organization_url,
        api_token=config.user_token,
        organization=config.organization,
        deployment=config.default_deployment,
    )
    result = gql_client.execute_arbitrary(FULL_DEPLOYMENTS_QUERY)
    deployment_names = [d["deploymentName"] for d in result["fullDeployments"]]

    click.echo("Available deployments: " + ", ".join(deployment_names))

    selected_deployment = None
    while selected_deployment not in deployment_names:
        if selected_deployment is not None:
            click.echo(f"{selected_deployment} is not a valid deployment")
        selected_deployment = click.prompt(
            "Select a default deployment", default=deployment_names[0]
        )

    config = DagsterPlusCliConfig(
        organization=config.organization,
        user_token=config.user_token,
        default_deployment=selected_deployment,
        url=org_url,
    )
    config.write()
