######################################################################

#                          /v1/files Endpoints

# Equivalent of https://platform.openai.com/docs/api-reference/files
######################################################################

import asyncio
import traceback
from collections.abc import Mapping
from typing import Any, BinaryIO, Final, TypedDict, cast, get_args

import httpx
from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
    status,
)
from pydantic import TypeAdapter
from typing_extensions import ReadOnly

import litellm
from litellm import CreateFileRequest, get_secret_str
from litellm._logging import verbose_proxy_logger
from litellm.litellm_core_utils.cloud_storage_security import (
    is_managed_cloud_storage_uri,
)
from litellm.litellm_core_utils.core_helpers import get_or_create_metadata_bucket
from litellm.llms.base_llm.files.transformation import BaseFileEndpoints
from litellm.proxy._types import *
from litellm.proxy.auth.user_api_key_auth import user_api_key_auth
from litellm.proxy.common_request_processing import ProxyBaseLLMRequestProcessing
from litellm.proxy.common_utils.http_parsing_utils import (
    _read_request_body,
    extract_nested_form_metadata,
)
from litellm.proxy.common_utils.openai_endpoint_utils import (
    get_custom_llm_provider_from_request_body,
    get_custom_llm_provider_from_request_headers,
    get_custom_llm_provider_from_request_query,
)
from litellm.proxy.openai_files_endpoints.batch_file_validation import (
    check_batch_file_upload,
    raise_batch_file_validation_failure,
)
from litellm.proxy.openai_files_endpoints.batch_guardrails import (
    EMPTY_MAPPING,
    BatchScanResult,
    raise_nothing_to_submit,
    raise_public,
    rewrite_batch_input_file,
    scan_batch_input_file,
)
from litellm.proxy.openai_files_endpoints.common_utils import (
    _is_base64_encoded_unified_file_id,
    add_internal_model_credentials,
    apply_team_provider_credentials,
    encode_file_id_with_model,
    extract_file_creation_params,
    get_credentials_for_model,
    handle_model_based_routing,
    prepare_data_with_credentials,
    validate_file_list_limit,
    validate_managed_files_requirement,
    validate_managed_id_requirement,
)
from litellm.proxy.utils import ProxyLogging, is_known_model
from litellm.repositories.table_repositories import ManagedFileRepository
from litellm.router import Router
from litellm.types.llms.openai import (
    CREATE_FILE_REQUESTS_PURPOSE,
    FileExpiresAfter,
    OpenAIFileObject,
    OpenAIFilesPurpose,
)

router: Final = APIRouter()

_MAX_BATCH_FILE_SIZE_MB_ADAPTER: Final = TypeAdapter(int | None)


class UploadedFileInfo(TypedDict):
    filename: ReadOnly[str | None]
    content_type: ReadOnly[str | None]
    size: ReadOnly[int | None]


files_config = None


def set_files_config(config):
    global files_config
    if config is None:
        return

    if not isinstance(config, list):
        raise ValueError("invalid files config, expected a list is not a list")

    for element in config:
        if isinstance(element, dict):
            for key, value in element.items():
                if isinstance(value, str) and value.startswith("os.environ/"):
                    element[key] = get_secret_str(value)

    files_config = config


def get_files_provider_config(
    custom_llm_provider: str,
):
    global files_config
    if custom_llm_provider == "vertex_ai":
        return None
    if files_config is None:
        raise ValueError("files_settings is not set, set it on your config.yaml file.")
    for setting in files_config:
        if setting.get("custom_llm_provider") == custom_llm_provider:
            return setting
    return None


async def _scan_batch_upload(
    *,
    file_source: bytes | BinaryIO,
    purpose: str,
    request_metadata: Mapping[str, object],
    user_api_key_dict: UserAPIKeyAuth,
    proxy_logging_obj: ProxyLogging,
) -> BatchScanResult | None:
    """Guardrail the records of a batch input file, or None when this upload has nothing to scan."""
    if (
        purpose != "batch"
        or isinstance(file_source, bytes)
        or not proxy_logging_obj.has_pre_call_guardrails(request_metadata)
    ):
        return None
    outcome: Final = await scan_batch_input_file(
        file_source=file_source,
        request_metadata=request_metadata,
        user_api_key_dict=user_api_key_dict,
        proxy_logging_obj=proxy_logging_obj,
    )
    if not isinstance(outcome, BatchScanResult):
        raise_public(outcome)
    if outcome.changes and outcome.submitted_records == 0:
        raise_nothing_to_submit()
    return outcome


def get_first_json_object(file_source: bytes | BinaryIO) -> dict | None:
    """
    The first record, used to pick a deployment when batch load balancing is on.

    Read the way the upload validation reads it, since a file it accepted must not lose its
    routing here: blank lines are not records and are skipped, and the line is parsed as bytes so
    the json module sniffs the encoding rather than rejecting a leading byte order mark. Either
    difference makes this return None, which silently sends the batch to the default provider.
    """
    try:
        if isinstance(file_source, (bytes, bytearray)):
            first_record: bytes | None = next((line for line in file_source.splitlines() if line.strip()), None)
        else:
            # lazily, so a batch file that can be gigabytes is not read past its first record
            file_source.seek(0)
            first_record = next((line for line in file_source if line.strip()), None)
            file_source.seek(0)
        return None if first_record is None else json.loads(first_record.strip())
    except (json.JSONDecodeError, UnicodeDecodeError, OSError, ValueError):
        return None


def get_model_from_json_obj(json_object: dict) -> str | None:
    """
    The model a record names, or None when it does not name one readably.

    The upload validation only checks that `body` is present, not that it is an object, so a
    record can carry a string there and reach this. Returning None sends the upload down the
    default-provider branch, which is what a record with no resolvable model already did.
    """
    body: Final = json_object.get("body")
    return body.get("model") if isinstance(body, dict) else None


async def _deprecated_loadbalanced_create_file(
    llm_router: Router | None,
    router_model: str,
    _create_file_request: CreateFileRequest,
) -> OpenAIFileObject:
    if llm_router is None:
        raise HTTPException(
            status_code=500,
            detail={"error": "LLM Router not initialized. Ensure models added to proxy."},
        )

    response: Final = await llm_router.acreate_file(model=router_model, **_create_file_request)
    return response


async def route_create_file(
    llm_router: Router | None,
    _create_file_request: CreateFileRequest,
    purpose: OpenAIFilesPurpose,
    proxy_logging_obj: ProxyLogging,
    user_api_key_dict: UserAPIKeyAuth,
    target_model_names_list: list[str],
    is_router_model: bool,
    router_model: str | None,
    custom_llm_provider: str,
    model: str | None = None,
    target_storage: str | None = "default",
) -> OpenAIFileObject:
    """
    Route file creation request to the appropriate provider.

    Priority:
    1. If target_storage is specified and not "default" -> use storage backend
    2. If model parameter provided -> use model credentials and encode ID
    3. If target_model_names_list -> managed files (requires DB, supports loadbalancing)
    4. If enable_loadbalancing_on_batch_endpoints -> deprecated loadbalancing
    5. Else -> use custom_llm_provider with files_settings
    """

    # Handle custom storage backend
    if target_storage and target_storage != "default":
        from litellm.litellm_core_utils.prompt_templates.common_utils import (
            extract_file_data,
        )
        from litellm.proxy.openai_files_endpoints.storage_backend_service import (
            StorageBackendFileService,
        )

        # Extract file data
        file_data: Final = extract_file_data(cast(Any, _create_file_request.get("file")))

        # Use storage backend service to handle upload
        file_object: Final = await StorageBackendFileService.upload_file_to_storage_backend(
            file_data=file_data,
            target_storage=target_storage,
            target_model_names=target_model_names_list,
            purpose=purpose,
            proxy_logging_obj=proxy_logging_obj,
            user_api_key_dict=user_api_key_dict,
        )

        return file_object

    # NEW: Handle model-based routing (no DB required)
    if model is not None:
        # Get credentials from model_list via router
        credentials: Final = get_credentials_for_model(
            llm_router=llm_router,
            model_id=model,
            operation_context="file upload",
        )

        # Merge credentials into the request
        prepare_data_with_credentials(
            data=_create_file_request,
            credentials=credentials,
        )

        # Create the file with model credentials
        response = await litellm.acreate_file(
            **_create_file_request,
            custom_llm_provider=credentials["custom_llm_provider"],
        )

        # Encode the file ID with model information
        if response and hasattr(response, "id") and response.id:
            original_id: Final = response.id
            encoded_id: Final = encode_file_id_with_model(file_id=original_id, model=model)
            response.id = encoded_id
            verbose_proxy_logger.debug("Encoded file ID: %s -> %s (model: %s)", original_id, encoded_id, model)

        return response

    # Handle managed files (supports loadbalancing via llm_router.acreate_file)
    # Priority: Check for managed files BEFORE deprecated loadbalancing
    if target_model_names_list:
        managed_files_obj: Final = proxy_logging_obj.get_proxy_hook("managed_files")
        if managed_files_obj is None:
            raise ProxyException(
                message="Managed files hook not found",
                type="None",
                param="None",
                code=500,
            )
        if llm_router is None:
            raise ProxyException(
                message="LLM Router not found",
                type="None",
                param="None",
                code=500,
            )
        if not isinstance(managed_files_obj, BaseFileEndpoints):
            raise ProxyException(
                message="Managed files hook is not a BaseFileEndpoints",
                type="None",
                param="None",
                code=500,
            )
        # Managed files internally calls llm_router.acreate_file() which includes loadbalancing
        response = await managed_files_obj.acreate_file(
            llm_router=llm_router,
            create_file_request=_create_file_request,
            target_model_names_list=target_model_names_list,
            litellm_parent_otel_span=user_api_key_dict.parent_otel_span,
            user_api_key_dict=user_api_key_dict,
        )
    # EXISTING: Deprecated loadbalancing approach (for backwards compatibility when not using managed files)
    elif litellm.enable_loadbalancing_on_batch_endpoints is True and is_router_model and router_model is not None:
        response = await _deprecated_loadbalanced_create_file(
            llm_router=llm_router,
            router_model=router_model,
            _create_file_request=_create_file_request,
        )
    else:
        apply_team_provider_credentials(
            data=cast(dict, _create_file_request),  # cast-ok: TypedDict is a plain dict at runtime; merged in place
            llm_router=llm_router,
            user_api_key_dict=user_api_key_dict,
            custom_llm_provider=custom_llm_provider,
        )
        # get configs for custom_llm_provider
        llm_provider_config: Final = get_files_provider_config(custom_llm_provider=custom_llm_provider)
        if llm_provider_config is not None:
            # add llm_provider_config to data
            _create_file_request.update(llm_provider_config)
        _create_file_request.pop("custom_llm_provider", None)
        # for now use custom_llm_provider=="openai" -> this will change as LiteLLM adds more providers for acreate_batch
        response = await litellm.acreate_file(**_create_file_request, custom_llm_provider=custom_llm_provider)

    return response


@router.post(
    "/{provider}/v1/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.post(
    "/v1/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.post(
    "/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
async def create_file(
    request: Request,
    fastapi_response: Response,
    purpose: str = Form(...),
    target_model_names: str = Form(default=""),
    target_storage: str = Form(default="default"),
    provider: str | None = None,
    custom_llm_provider: str = Form(default="openai"),
    file: UploadFile = File(...),
    litellm_metadata: str | None = Form(default=None),
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Upload a file that can be used across - Assistants API, Batch API 
    This is the equivalent of POST https://api.openai.com/v1/files

    Supports Identical Params as: https://platform.openai.com/docs/api-reference/files/create

    Example Curl
    ```
    curl http://localhost:4000/v1/files \
        -H "Authorization: Bearer sk-1234" \
        -F purpose="batch" \
        -F file="@mydata.jsonl"
        -F expires_after[anchor]="created_at" \
        -F expires_after[seconds]=2592000
    ```
    """
    from litellm.proxy.proxy_server import (
        add_litellm_data_to_request,
        general_settings,
        llm_router,
        proxy_config,
        proxy_logging_obj,
        version,
    )

    data: dict = {}
    # Spools this request owns. Starlette owns the upload handle; anything the guardrail scan
    # opens is ours, and a batch upload that fails after the scan would otherwise hold the
    # descriptor and its disk blocks until the collector runs.
    spools: Final[list[BinaryIO]] = []  # mutable-ok: filled as the scan opens handles
    try:
        # Batch uploads can be gigabytes. Starlette has already spooled the upload
        # to disk, so stream from that handle instead of reading it into memory.
        # Other uploads are small and stay in-memory bytes.
        file_source: bytes | BinaryIO
        if purpose == "batch":
            await file.seek(0)
            file_source = file.file
        else:
            file_source = await file.read()
        custom_llm_provider = (
            provider
            or get_custom_llm_provider_from_request_headers(request=request)
            or get_custom_llm_provider_from_request_query(request=request)
            or await get_custom_llm_provider_from_request_body(request=request)
            or "openai"
        )

        # Extract file creation parameters using utility function
        request_body: Final = await _read_request_body(request=request) or {}
        file_params: Final = await extract_file_creation_params(
            request=request,
            request_body=request_body,
            target_model_names_form=target_model_names,
            target_storage_form=target_storage,
        )

        target_storage = file_params.target_storage
        target_model_names_list: Final = file_params.target_model_names
        model_param: Final = file_params.model

        validate_managed_files_requirement(target_model_names=target_model_names_list, model=model_param)

        # Prepare the data for forwarding

        valid_purposes: Final = get_args(OpenAIFilesPurpose)
        if purpose not in valid_purposes:
            raise ProxyException(
                message=f"Invalid purpose: {purpose}. Must be one of: {valid_purposes}",
                type="invalid_request_error",
                param="purpose",
                code=400,
            )
        # Cast purpose to OpenAIFilesPurpose type
        purpose = cast(OpenAIFilesPurpose, purpose)

        if purpose == "batch":
            batch_file_failure: Final = await asyncio.to_thread(
                check_batch_file_upload,
                file.filename,
                file_source,
                _MAX_BATCH_FILE_SIZE_MB_ADAPTER.validate_python(general_settings.get("max_batch_file_size_mb")),
            )
            if batch_file_failure is not None:
                raise_batch_file_validation_failure(batch_file_failure)

        data = {}

        # Parse expires_after if provided
        expires_after: FileExpiresAfter | None = None
        form_data_raw: Final = await request.form()
        form_data_dict: Final[dict[str, Any]] = dict(form_data_raw)
        extracted_litellm_metadata: Final[dict[str, Any] | None] = extract_nested_form_metadata(
            form_data=form_data_dict, prefix="litellm_metadata["
        )
        expires_after_anchor: Final = form_data_raw.get("expires_after[anchor]")
        expires_after_seconds_str: Final = form_data_raw.get("expires_after[seconds]")

        # Add litellm_metadata to data if provided (from form field)
        if extracted_litellm_metadata is not None:
            data["litellm_metadata"] = extracted_litellm_metadata

        if expires_after_anchor is not None or expires_after_seconds_str is not None:
            if expires_after_anchor is None or expires_after_seconds_str is None:
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "Both expires_after[anchor] and expires_after[seconds] must be provided if expires_after is specified",
                    },
                )

            # Validate expires_after[anchor] is a string (not UploadFile)
            if isinstance(expires_after_anchor, UploadFile):
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "expires_after[anchor] must be a string, not a file upload",
                    },
                )

            # Validate expires_after[seconds] is a string (not UploadFile)
            # Use positive isinstance check for proper type narrowing (matches codebase pattern)
            if not isinstance(expires_after_seconds_str, str):
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": "expires_after[seconds] must be a string, not a file upload",
                    },
                )
            # After this check, mypy knows expires_after_seconds_str is str
            expires_after_seconds_str_validated: Final[str] = expires_after_seconds_str

            # Validate anchor is "created_at"
            if expires_after_anchor != "created_at":
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": f"expires_after[anchor] must be 'created_at', got '{expires_after_anchor}'",
                    },
                )

            # Convert seconds to int
            try:
                expires_after_seconds: Final = int(expires_after_seconds_str_validated)
            except (ValueError, TypeError) as e:
                raise HTTPException(
                    status_code=400,
                    detail={
                        "error": f"expires_after[seconds] must be a valid integer, got '{expires_after_seconds_str}': {e}",
                    },
                )

            # Use literal "created_at" (not variable) for TypedDict to satisfy Literal type
            expires_after = FileExpiresAfter(
                anchor="created_at",  # Literal, not expires_after_anchor variable
                seconds=expires_after_seconds,
            )

        # Include original request and headers in the data
        data = await add_litellm_data_to_request(
            data=data,
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_config=proxy_config,
        )

        uploaded_file_info: Final[UploadedFileInfo] = {
            "filename": file.filename,
            "content_type": file.content_type,
            "size": file.size,
        }
        data["purpose"] = purpose
        data["file"] = uploaded_file_info
        hooked_data: Final = await proxy_logging_obj.pre_call_hook(
            user_api_key_dict=user_api_key_dict,
            data=data,
            call_type="acreate_file",
        )
        data = hooked_data if hooked_data is not None else data
        data.pop("purpose", None)
        data.pop("file", None)

        # /v1/files stores its proxy metadata under litellm_metadata, not metadata
        request_metadata: Final = data.get("metadata") or data.get("litellm_metadata") or EMPTY_MAPPING
        scan_result: Final = await _scan_batch_upload(
            file_source=file_source,
            purpose=purpose,
            request_metadata=request_metadata,
            user_api_key_dict=user_api_key_dict,
            proxy_logging_obj=proxy_logging_obj,
        )
        if scan_result is not None and scan_result.changes:
            # The caller sees this in the response; a proxy admin needs it server side too,
            # and it has to land before the post-call hook for logging callbacks to pick it up.
            get_or_create_metadata_bucket(data)[1]["batch_guardrail"] = scan_result.report().model_dump()
            verbose_proxy_logger.warning(
                "batch guardrails changed %s of %s records in %s: %s",
                len(scan_result.changes),
                scan_result.scanned_records,
                file.filename,
                scan_result.summary(),
            )

        # Prepare the file data according to FileTypes
        if scan_result is not None:
            spools.append(scan_result.redactions)
        upload_source: Final = (
            await asyncio.to_thread(rewrite_batch_input_file, file_source, scan_result)
            if scan_result is not None and scan_result.changes
            else file_source
        )
        if upload_source is not file_source:
            spools.append(upload_source)
        file_data: Final = (file.filename, upload_source, file.content_type)

        ## check if model is a loadbalanced model
        router_model: str | None = None
        is_router_model = False
        if litellm.enable_loadbalancing_on_batch_endpoints is True:
            json_obj: Final = get_first_json_object(upload_source)
            if json_obj:
                router_model = get_model_from_json_obj(json_object=json_obj)
                is_router_model = is_known_model(model=router_model, llm_router=llm_router)

        # Apply team-level file expiry enforcement
        team_metadata: Final = user_api_key_dict.team_metadata or {}
        enforced_file_expiry: Final = team_metadata.get("enforced_file_expires_after")
        if enforced_file_expiry is not None:
            if "anchor" not in enforced_file_expiry or "seconds" not in enforced_file_expiry:
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": "Server configuration error: team metadata field 'enforced_file_expires_after' is malformed - must contain 'anchor' and 'seconds' keys. Contact your team or proxy admin to fix this setting.",
                    },
                )
            if enforced_file_expiry["anchor"] != "created_at":
                raise HTTPException(
                    status_code=500,
                    detail={
                        "error": f"Server configuration error: team metadata field 'enforced_file_expires_after' has invalid anchor '{enforced_file_expiry['anchor']}' - must be 'created_at'. Contact your team or proxy admin to fix this setting.",
                    },
                )
            expires_after = FileExpiresAfter(
                anchor="created_at",
                seconds=int(enforced_file_expiry["seconds"]),
            )

        verbose_proxy_logger.debug("create_file expires_after: %s", expires_after)

        _create_file_request: Final = CreateFileRequest(
            file=file_data,
            purpose=cast(CREATE_FILE_REQUESTS_PURPOSE, purpose),
            expires_after=expires_after,
            **data,
        )

        response = await route_create_file(
            llm_router=llm_router,
            _create_file_request=_create_file_request,
            purpose=purpose,
            proxy_logging_obj=proxy_logging_obj,
            user_api_key_dict=user_api_key_dict,
            target_model_names_list=target_model_names_list,
            is_router_model=is_router_model,
            router_model=router_model,
            custom_llm_provider=custom_llm_provider,
            model=model_param,
            target_storage=target_storage,
        )

        if response is None:
            raise HTTPException(
                status_code=500,
                detail={"error": "Failed to create file. Please try again."},
            )
        ### ALERTING ###
        asyncio.create_task(
            proxy_logging_obj.update_request_status(litellm_call_id=data.get("litellm_call_id", ""), status="success")
        )

        ## POST CALL HOOKS ###
        _response: Final = await proxy_logging_obj.post_call_success_hook(
            data=data, user_api_key_dict=user_api_key_dict, response=response
        )
        if _response is not None and isinstance(_response, OpenAIFileObject):
            response = _response

        if scan_result is not None and scan_result.changes:
            response.litellm_batch_guardrail = scan_result.report()

        ### RESPONSE HEADERS ###
        hidden_params: Final = getattr(response, "_hidden_params", {}) or {}
        model_id: Final = hidden_params.get("model_id", None) or ""
        cache_key: Final = hidden_params.get("cache_key", None) or ""
        api_base: Final = hidden_params.get("api_base", None) or ""

        fastapi_response.headers.update(
            ProxyBaseLLMRequestProcessing.get_custom_headers(
                user_api_key_dict=user_api_key_dict,
                model_id=model_id,
                cache_key=cache_key,
                api_base=api_base,
                version=version,
                model_region=getattr(user_api_key_dict, "allowed_model_region", ""),
            )
        )
        return response
    except Exception as e:
        await proxy_logging_obj.post_call_failure_hook(
            user_api_key_dict=user_api_key_dict, original_exception=e, request_data=data
        )
        verbose_proxy_logger.exception("litellm.proxy.proxy_server.create_file(): Exception occured - %s", e)
        if isinstance(e, ProxyException):
            raise e
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "message", str(e.detail)),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        else:
            error_msg: Final = f"{e}"
            raise ProxyException(
                message=getattr(e, "message", error_msg),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", 500),
            )
    finally:
        for spool in spools:
            spool.close()


@router.get(
    "/{provider}/v1/files/{file_id:path}/content",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/v1/files/{file_id:path}/content",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/files/{file_id:path}/content",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
async def get_file_content(
    request: Request,
    fastapi_response: Response,
    file_id: str,
    provider: str | None = None,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Returns information about a specific file. that can be used across - Assistants API, Batch API 
    This is the equivalent of GET https://api.openai.com/v1/files/{file_id}/content

    Supports Identical Params as: https://platform.openai.com/docs/api-reference/files/retrieve-contents

    Example Curl
    ```
    curl http://localhost:4000/v1/files/file-abc123/content \
        -H "Authorization: Bearer sk-1234"

    ```
    """
    from litellm.proxy.proxy_server import (
        general_settings,
        llm_router,
        proxy_config,
        proxy_logging_obj,
        version,
    )

    data: dict = {"file_id": file_id}
    try:
        await validate_managed_id_requirement(
            resource_id=file_id,
            resource_kind="file",
            user_api_key_dict=user_api_key_dict,
            managed_files_obj=proxy_logging_obj.get_proxy_hook("managed_files"),
        )

        # Include original request and headers in the data
        base_llm_response_processor: Final = ProxyBaseLLMRequestProcessing(data=data)
        (
            data,
            litellm_logging_obj,
        ) = await base_llm_response_processor.common_processing_pre_call_logic(
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_logging_obj=proxy_logging_obj,
            proxy_config=proxy_config,
            route_type="afile_content",
        )

        custom_llm_provider: Final = (
            provider
            or get_custom_llm_provider_from_request_headers(request=request)
            or get_custom_llm_provider_from_request_query(request=request)
            or await get_custom_llm_provider_from_request_body(request=request)
            or "openai"
        )

        ## check if file_id is a litellm managed file
        is_base64_unified_file_id: Final = _is_base64_encoded_unified_file_id(file_id)
        if is_base64_unified_file_id:
            managed_files_obj: Final = proxy_logging_obj.get_proxy_hook("managed_files")
            if managed_files_obj is None:
                raise ProxyException(
                    message="Managed files hook not found",
                    type="None",
                    param="None",
                    code=500,
                )
            if llm_router is None:
                raise ProxyException(
                    message="LLM Router not found",
                    type="None",
                    param="None",
                    code=500,
                )
            if not isinstance(managed_files_obj, BaseFileEndpoints):
                raise ProxyException(
                    message="Managed files hook is not a BaseFileEndpoints",
                    type="None",
                    param="None",
                    code=500,
                )

            # Check if file is stored in a storage backend (check DB)
            if hasattr(managed_files_obj, "prisma_client") and getattr(managed_files_obj, "prisma_client", None):
                prisma_client: Final = getattr(managed_files_obj, "prisma_client")
                db_file: Final = await ManagedFileRepository(prisma_client).table.find_first(
                    where={"unified_file_id": file_id}
                )
                if db_file and db_file.storage_backend and db_file.storage_url:
                    # File is stored in a storage backend, download it
                    from litellm.llms.base_llm.files.storage_backend_factory import (
                        get_storage_backend,
                    )

                    storage_backend_name: Final = db_file.storage_backend
                    storage_url: Final = db_file.storage_url

                    try:
                        # Get storage backend (uses same env vars as callback)
                        storage_backend: Final = get_storage_backend(storage_backend_name)
                        file_content: Final = await storage_backend.download_file(storage_url)

                        # Return file content
                        from fastapi.responses import Response as FastAPIResponse

                        return FastAPIResponse(
                            content=file_content,
                            media_type="application/octet-stream",
                        )
                    except ValueError as e:
                        raise ProxyException(
                            message=f"Storage backend error: {e}",
                            type="invalid_request_error",
                            param="file_id",
                            code=400,
                        )

            model: Final = cast(str | None, data.get("model"))
            if model:
                add_internal_model_credentials(data=data, llm_router=llm_router, model_id=model)
                response = await llm_router.afile_content(
                    **{
                        "model": model,
                        "file_id": file_id,
                        **data,
                    }
                )

            else:
                response = await managed_files_obj.afile_content(
                    **{
                        "file_id": file_id,
                        "litellm_parent_otel_span": user_api_key_dict.parent_otel_span,
                        "llm_router": llm_router,
                        **data,
                    }
                )
        else:
            # A raw cloud-storage URI (s3://, gs://) supplied here would skip the
            # managed-file owner/team check that only runs for unified ids, letting
            # a caller read another tenant's object by its key. Such objects are only
            # reachable through their managed unified id.
            if is_managed_cloud_storage_uri(file_id):
                raise HTTPException(
                    status_code=400,
                    detail="Raw cloud storage file ids cannot be retrieved directly. Use the LiteLLM managed file id returned when the file was created.",
                )
            # Check for model-based credential routing
            (
                should_route,
                model_used,
                original_file_id,
                credentials,
            ) = handle_model_based_routing(
                file_id=file_id,
                request=request,
                llm_router=llm_router,
                data=data,
                check_file_id_encoding=True,
            )

            if not should_route:
                apply_team_provider_credentials(
                    data=data,
                    llm_router=llm_router,
                    user_api_key_dict=user_api_key_dict,
                    custom_llm_provider=custom_llm_provider,
                )

            from litellm.proxy.openai_files_endpoints.file_content_streaming_handler import (
                FileContentStreamingHandler,
            )

            (
                resolved_custom_llm_provider,
                resolved_file_id,
                resolved_streaming_data,
            ) = FileContentStreamingHandler.resolve_streaming_request_params(
                custom_llm_provider=custom_llm_provider,
                file_id=file_id,
                data=data,
                should_route=should_route,
                original_file_id=original_file_id,
                credentials=credentials,
            )

            if FileContentStreamingHandler.should_stream_file_content(
                custom_llm_provider=resolved_custom_llm_provider,
            ):
                verbose_proxy_logger.debug(
                    "Using streaming file content helper for custom_llm_provider=%s, original_file_id=%s, file_id=%s, model_used=%s",
                    resolved_custom_llm_provider,
                    original_file_id,
                    resolved_file_id,
                    model_used,
                )
                return await FileContentStreamingHandler.get_streaming_file_content_response(
                    custom_llm_provider=resolved_custom_llm_provider,
                    file_id=resolved_file_id,
                    data=resolved_streaming_data,
                    proxy_logging_obj=proxy_logging_obj,
                    user_api_key_dict=user_api_key_dict,
                    version=version,
                )

            if should_route and credentials is not None:
                # Use model-based routing with credentials from config
                prepare_data_with_credentials(
                    data=data,
                    credentials=credentials,
                    file_id=original_file_id,  # Use decoded file ID if from encoded ID
                    include_internal_credentials=True,
                )
                response = await litellm.afile_content(
                    custom_llm_provider=credentials["custom_llm_provider"],
                    **data,
                )

                verbose_proxy_logger.debug(
                    f"Retrieved file content using model: {model_used}"
                    + (f", file_id: {file_id} -> {original_file_id}" if original_file_id else "")
                )
            else:
                # Fallback to default behavior (uses env variables or provider-based routing)
                response = await litellm.afile_content(
                    **{
                        "custom_llm_provider": custom_llm_provider,
                        "file_id": file_id,
                        **data,
                    }
                )

        ### ALERTING ###
        asyncio.create_task(
            proxy_logging_obj.update_request_status(litellm_call_id=data.get("litellm_call_id", ""), status="success")
        )

        ### RESPONSE HEADERS ###
        hidden_params: Final = getattr(response, "_hidden_params", {}) or {}
        model_id: Final = hidden_params.get("model_id", None) or ""
        cache_key: Final = hidden_params.get("cache_key", None) or ""
        api_base: Final = hidden_params.get("api_base", None) or ""

        fastapi_response.headers.update(
            ProxyBaseLLMRequestProcessing.get_custom_headers(
                user_api_key_dict=user_api_key_dict,
                model_id=model_id,
                cache_key=cache_key,
                api_base=api_base,
                version=version,
                model_region=getattr(user_api_key_dict, "allowed_model_region", ""),
            )
        )
        httpx_response: Final[httpx.Response | None] = getattr(response, "response", None)
        if httpx_response is None:
            raise ValueError(f"Invalid response - response.response is None - got {response}")

        return Response(
            content=httpx_response.content,
            status_code=httpx_response.status_code,
            headers=httpx_response.headers,
        )

    except Exception as e:
        await proxy_logging_obj.post_call_failure_hook(
            user_api_key_dict=user_api_key_dict, original_exception=e, request_data=data
        )
        verbose_proxy_logger.exception("litellm.proxy.proxy_server.retrieve_file_content(): Exception occured - %s", e)
        verbose_proxy_logger.debug(traceback.format_exc())
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "message", str(e.detail)),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        else:
            error_msg: Final = f"{e}"
            raise ProxyException(
                message=getattr(e, "message", error_msg),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", 500),
            )


@router.get(
    "/{provider}/v1/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/v1/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
async def get_file(
    request: Request,
    fastapi_response: Response,
    file_id: str,
    provider: str | None = None,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Returns information about a specific file. that can be used across - Assistants API, Batch API 
    This is the equivalent of GET https://api.openai.com/v1/files/{file_id}

    Supports Identical Params as: https://platform.openai.com/docs/api-reference/files/retrieve

    Example Curl
    ```
    curl http://localhost:4000/v1/files/file-abc123 \
        -H "Authorization: Bearer sk-1234"

    ```
    """
    from litellm.proxy.proxy_server import (
        general_settings,
        proxy_config,
        proxy_logging_obj,
        version,
    )

    data: dict = {"file_id": file_id}
    try:
        await validate_managed_id_requirement(
            resource_id=file_id,
            resource_kind="file",
            user_api_key_dict=user_api_key_dict,
            managed_files_obj=proxy_logging_obj.get_proxy_hook("managed_files"),
        )

        custom_llm_provider: Final = (
            provider
            or get_custom_llm_provider_from_request_headers(request=request)
            or get_custom_llm_provider_from_request_query(request=request)
            or await get_custom_llm_provider_from_request_body(request=request)
            or "openai"
        )

        # Include original request and headers in the data
        base_llm_response_processor: Final = ProxyBaseLLMRequestProcessing(data=data)
        (
            data,
            litellm_logging_obj,
        ) = await base_llm_response_processor.common_processing_pre_call_logic(
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_logging_obj=proxy_logging_obj,
            proxy_config=proxy_config,
            route_type="afile_retrieve",
        )

        ## Check for model-based credential routing
        from litellm.proxy.proxy_server import llm_router

        (
            should_route,
            model_used,
            original_file_id,
            credentials,
        ) = handle_model_based_routing(
            file_id=file_id,
            request=request,
            llm_router=llm_router,
            data=data,
            check_file_id_encoding=True,
        )

        if should_route:
            # Use model-based routing with credentials from config
            prepare_data_with_credentials(
                data=data,
                credentials=credentials,
                file_id=original_file_id,
                include_internal_credentials=True,
            )

            response = await litellm.afile_retrieve(**data)

            # Keep the encoded ID in response if it was originally encoded
            if original_file_id and response and hasattr(response, "id") and response.id:
                response.id = file_id

            verbose_proxy_logger.debug(
                f"Retrieved file using model: {model_used}"
                + (f", original_id: {original_file_id}" if original_file_id else "")
            )

        ## EXISTING: check if file_id is a litellm managed file
        elif _is_base64_encoded_unified_file_id(file_id):
            managed_files_obj: Final = proxy_logging_obj.get_proxy_hook("managed_files")
            if managed_files_obj is None:
                raise ProxyException(
                    message="Managed files hook not found",
                    type="None",
                    param="None",
                    code=500,
                )
            if not isinstance(managed_files_obj, BaseFileEndpoints):
                raise ProxyException(
                    message="Managed files hook is not a BaseFileEndpoints",
                    type="None",
                    param="None",
                    code=500,
                )
            response = await managed_files_obj.afile_retrieve(
                file_id=file_id,
                litellm_parent_otel_span=user_api_key_dict.parent_otel_span,
                llm_router=llm_router,
            )
        else:
            # Remove file_id from data to avoid "multiple values for keyword argument" error
            # data was initialized with {"file_id": file_id}
            data.pop("file_id", None)
            apply_team_provider_credentials(
                data=data,
                llm_router=llm_router,
                user_api_key_dict=user_api_key_dict,
                custom_llm_provider=custom_llm_provider,
            )
            response = await litellm.afile_retrieve(
                custom_llm_provider=custom_llm_provider,
                file_id=file_id,
                **data,
            )

        ### ALERTING ###
        asyncio.create_task(
            proxy_logging_obj.update_request_status(litellm_call_id=data.get("litellm_call_id", ""), status="success")
        )

        ### RESPONSE HEADERS ###
        hidden_params: Final = getattr(response, "_hidden_params", {}) or {}
        model_id: Final = hidden_params.get("model_id", None) or ""
        cache_key: Final = hidden_params.get("cache_key", None) or ""
        api_base: Final = hidden_params.get("api_base", None) or ""

        fastapi_response.headers.update(
            ProxyBaseLLMRequestProcessing.get_custom_headers(
                user_api_key_dict=user_api_key_dict,
                model_id=model_id,
                cache_key=cache_key,
                api_base=api_base,
                version=version,
                model_region=getattr(user_api_key_dict, "allowed_model_region", ""),
            )
        )
        return response

    except Exception as e:
        await proxy_logging_obj.post_call_failure_hook(
            user_api_key_dict=user_api_key_dict, original_exception=e, request_data=data
        )
        verbose_proxy_logger.error("litellm.proxy.proxy_server.retrieve_file(): Exception occured - %s", e)
        verbose_proxy_logger.debug(traceback.format_exc())
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "message", str(e.detail)),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        else:
            error_msg: Final = f"{e}"
            raise ProxyException(
                message=getattr(e, "message", error_msg),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", 500),
            )


@router.delete(
    "/{provider}/v1/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.delete(
    "/v1/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.delete(
    "/files/{file_id:path}",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
async def delete_file(
    request: Request,
    fastapi_response: Response,
    file_id: str,
    provider: str | None = None,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Deletes a specified file. that can be used across - Assistants API, Batch API 
    This is the equivalent of DELETE https://api.openai.com/v1/files/{file_id}

    Supports Identical Params as: https://platform.openai.com/docs/api-reference/files/delete

    Example Curl
    ```
    curl http://localhost:4000/v1/files/file-abc123 \
    -X DELETE \
    -H "Authorization: Bearer $OPENAI_API_KEY"

    ```
    """
    from litellm.proxy.proxy_server import (
        add_litellm_data_to_request,
        general_settings,
        llm_router,
        proxy_config,
        proxy_logging_obj,
        version,
    )

    data: dict = {"file_id": file_id}
    try:
        await validate_managed_id_requirement(
            resource_id=file_id,
            resource_kind="file",
            user_api_key_dict=user_api_key_dict,
            managed_files_obj=proxy_logging_obj.get_proxy_hook("managed_files"),
        )

        custom_llm_provider: Final = (
            provider
            or get_custom_llm_provider_from_request_headers(request=request)
            or get_custom_llm_provider_from_request_query(request=request)
            or await get_custom_llm_provider_from_request_body(request=request)
            or "openai"
        )

        # Call common_processing_pre_call_logic to trigger permission checks
        base_llm_response_processor: Final = ProxyBaseLLMRequestProcessing(data=data)
        (
            data,
            litellm_logging_obj,
        ) = await base_llm_response_processor.common_processing_pre_call_logic(
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_logging_obj=proxy_logging_obj,
            proxy_config=proxy_config,
            route_type="afile_delete",
        )

        # Include original request and headers in the data
        data = await add_litellm_data_to_request(
            data=data,
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_config=proxy_config,
        )

        # Check for model-based credential routing
        (
            should_route,
            model_used,
            original_file_id,
            credentials,
        ) = handle_model_based_routing(
            file_id=file_id,
            request=request,
            llm_router=llm_router,
            data=data,
            check_file_id_encoding=True,
        )

        if should_route and credentials is not None:
            # Use model-based routing with credentials from config
            prepare_data_with_credentials(
                data=data,
                credentials=credentials,
                file_id=original_file_id,
                include_internal_credentials=True,
            )

            response = await litellm.afile_delete(
                custom_llm_provider=credentials["custom_llm_provider"],
                **data,
            )

            verbose_proxy_logger.debug(
                f"Deleted file using model: {model_used}"
                + (f", original_id: {original_file_id}" if original_file_id else "")
            )

        ## EXISTING: check if file_id is a litellm managed file
        elif _is_base64_encoded_unified_file_id(file_id):
            managed_files_obj: Final = proxy_logging_obj.get_proxy_hook("managed_files")
            if managed_files_obj is None:
                raise ProxyException(
                    message="Managed files hook not found",
                    type="None",
                    param="None",
                    code=500,
                )
            if llm_router is None:
                raise ProxyException(
                    message="LLM Router not found",
                    type="None",
                    param="None",
                    code=500,
                )
            if not isinstance(managed_files_obj, BaseFileEndpoints):
                raise ProxyException(
                    message="Managed files hook is not a BaseFileEndpoints",
                    type="None",
                    param="None",
                    code=500,
                )

            # Remove file_id from data to avoid duplicate keyword argument
            data_without_file_id: Final = {k: v for k, v in data.items() if k != "file_id"}
            response = await managed_files_obj.afile_delete(
                file_id=file_id,
                litellm_parent_otel_span=user_api_key_dict.parent_otel_span,
                llm_router=llm_router,
                **data_without_file_id,
            )
        else:
            data.pop("file_id", None)
            apply_team_provider_credentials(
                data=data,
                llm_router=llm_router,
                user_api_key_dict=user_api_key_dict,
                custom_llm_provider=custom_llm_provider,
            )
            response = await litellm.afile_delete(
                custom_llm_provider=custom_llm_provider,
                file_id=file_id,
                **data,
            )

        ### ALERTING ###
        asyncio.create_task(
            proxy_logging_obj.update_request_status(litellm_call_id=data.get("litellm_call_id", ""), status="success")
        )

        ### RESPONSE HEADERS ###
        hidden_params: Final = getattr(response, "_hidden_params", {}) or {}
        model_id: Final = hidden_params.get("model_id", None) or ""
        cache_key: Final = hidden_params.get("cache_key", None) or ""
        api_base: Final = hidden_params.get("api_base", None) or ""

        fastapi_response.headers.update(
            ProxyBaseLLMRequestProcessing.get_custom_headers(
                user_api_key_dict=user_api_key_dict,
                model_id=model_id,
                cache_key=cache_key,
                api_base=api_base,
                version=version,
                model_region=getattr(user_api_key_dict, "allowed_model_region", ""),
            )
        )
        return response

    except Exception as e:
        await proxy_logging_obj.post_call_failure_hook(
            user_api_key_dict=user_api_key_dict, original_exception=e, request_data=data
        )
        verbose_proxy_logger.exception("litellm.proxy.proxy_server.delete_file(): Exception occured - %s", e)
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "message", str(e.detail)),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        else:
            error_msg: Final = f"{e}"
            raise ProxyException(
                message=getattr(e, "message", error_msg),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", 500),
            )


@router.get(
    "/{provider}/v1/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/v1/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
@router.get(
    "/files",
    dependencies=[Depends(user_api_key_auth)],
    tags=["files"],
)
async def list_files(
    request: Request,
    fastapi_response: Response,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
    provider: str | None = None,
    target_model_names: str | None = None,
    purpose: str | None = None,
    limit: int | None = None,
    after: str | None = None,
):
    """
    Returns information about a specific file. that can be used across - Assistants API, Batch API 
    This is the equivalent of GET https://api.openai.com/v1/files/

    Supports Identical Params as: https://platform.openai.com/docs/api-reference/files/list

    Example Curl
    ```
    curl http://localhost:4000/v1/files\
        -H "Authorization: Bearer sk-1234"

    ```
    """
    from litellm.proxy.proxy_server import (
        general_settings,
        llm_router,
        proxy_config,
        proxy_logging_obj,
        version,
    )

    data: dict = {}
    try:
        validate_file_list_limit(limit)

        # Include original request and headers in the data
        base_llm_response_processor: Final = ProxyBaseLLMRequestProcessing(data=data)
        (
            data,
            litellm_logging_obj,
        ) = await base_llm_response_processor.common_processing_pre_call_logic(
            request=request,
            general_settings=general_settings,
            user_api_key_dict=user_api_key_dict,
            version=version,
            proxy_logging_obj=proxy_logging_obj,
            proxy_config=proxy_config,
            route_type=CallTypes.alist_fine_tuning_jobs.value,
        )

        response: Any | None = None

        # Check for model-based credential routing (no file_id encoding check for list)
        should_route, model_used, _, credentials = handle_model_based_routing(
            file_id="",  # No file_id for list endpoint
            request=request,
            llm_router=llm_router,
            data=data,
            check_file_id_encoding=False,
        )

        if should_route and credentials is not None:
            # Use model-based routing with credentials from config
            prepare_data_with_credentials(data=data, credentials=credentials)
            response = await litellm.afile_list(
                custom_llm_provider=credentials["custom_llm_provider"],
                purpose=purpose,
                **data,
            )

            verbose_proxy_logger.debug("Listed files using model: %s", model_used)

        elif target_model_names and isinstance(target_model_names, str):
            target_model_names_list: Final = target_model_names.split(",")
            if len(target_model_names_list) != 1:
                raise HTTPException(
                    status_code=400,
                    detail="target_model_names on list files must be a list of one model name. Example: ['gpt-4o']",
                )
            if llm_router is None:
                raise HTTPException(
                    status_code=500,
                    detail="LLM Router not initialized. Ensure models added to proxy.",
                )
            credentials = get_credentials_for_model(
                llm_router=llm_router,
                model_id=target_model_names_list[0],
                operation_context="file list",
            )
            prepare_data_with_credentials(data=data, credentials=credentials)
            response = await litellm.afile_list(
                custom_llm_provider=credentials["custom_llm_provider"],
                purpose=purpose,
                **data,
            )
        else:
            custom_llm_provider: Final = (
                provider
                or get_custom_llm_provider_from_request_headers(request=request)
                or get_custom_llm_provider_from_request_query(request=request)
                or await get_custom_llm_provider_from_request_body(request=request)
            )
            managed_files_obj: Final = proxy_logging_obj.get_proxy_hook("managed_files")
            if custom_llm_provider is None and isinstance(managed_files_obj, BaseFileEndpoints):
                response = await managed_files_obj.afile_list(
                    purpose=purpose,
                    litellm_parent_otel_span=user_api_key_dict.parent_otel_span,
                    user_api_key_dict=user_api_key_dict,
                    limit=limit,
                    after=after,
                )
            else:
                resolved_custom_llm_provider: Final = custom_llm_provider or "openai"
                apply_team_provider_credentials(
                    data=data,
                    llm_router=llm_router,
                    user_api_key_dict=user_api_key_dict,
                    custom_llm_provider=resolved_custom_llm_provider,
                )

                response = await litellm.afile_list(
                    custom_llm_provider=resolved_custom_llm_provider,
                    purpose=purpose,
                    **data,
                )

        if response is None:
            raise HTTPException(
                status_code=500,
                detail="Either 'provider' or 'target_model_names' must be provided e.g. `?target_model_names=gpt-4o`",
            )

        ## POST CALL HOOKS ###
        _response: Final = await proxy_logging_obj.post_call_success_hook(
            data=data, user_api_key_dict=user_api_key_dict, response=response
        )
        if _response is not None and isinstance(_response, OpenAIFileObject):
            response = _response

        ### ALERTING ###
        asyncio.create_task(
            proxy_logging_obj.update_request_status(litellm_call_id=data.get("litellm_call_id", ""), status="success")
        )

        ### RESPONSE HEADERS ###
        hidden_params: Final = getattr(response, "_hidden_params", {}) or {}
        model_id: Final = hidden_params.get("model_id", None) or ""
        cache_key: Final = hidden_params.get("cache_key", None) or ""
        api_base: Final = hidden_params.get("api_base", None) or ""

        fastapi_response.headers.update(
            ProxyBaseLLMRequestProcessing.get_custom_headers(
                user_api_key_dict=user_api_key_dict,
                model_id=model_id,
                cache_key=cache_key,
                api_base=api_base,
                version=version,
                model_region=getattr(user_api_key_dict, "allowed_model_region", ""),
            )
        )
        return response

    except Exception as e:
        await proxy_logging_obj.post_call_failure_hook(
            user_api_key_dict=user_api_key_dict, original_exception=e, request_data=data
        )
        verbose_proxy_logger.error("litellm.proxy.proxy_server.list_files(): Exception occured - %s", e)
        verbose_proxy_logger.debug(traceback.format_exc())
        if isinstance(e, ProxyException):
            raise
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "message", str(e.detail)),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        else:
            error_msg: Final = f"{e}"
            raise ProxyException(
                message=getattr(e, "message", error_msg),
                type=getattr(e, "type", "None"),
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", 500),
            )
