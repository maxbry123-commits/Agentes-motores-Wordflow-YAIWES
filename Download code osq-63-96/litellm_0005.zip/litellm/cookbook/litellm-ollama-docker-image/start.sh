ollama serve &
litellm