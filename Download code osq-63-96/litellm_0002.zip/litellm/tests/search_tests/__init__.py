"""
Search API tests.
"""
