import clsx from 'clsx';
import {forwardRef, useCallback, useImperativeHandle, useRef, useState} from 'react';

import styles from './css/SplitPanelContainer.module.css';

interface SplitPanelContainerProps {
  axis?: 'horizontal' | 'vertical';
  identifier: string;
  first: React.ReactNode | null;
  firstInitialPercent: number;
  firstMinSize?: number;
  secondMinSize?: number;
  second: React.ReactNode | null; // Note: pass null to hide / animate away the second panel

  // Prevents an extra 1px line when the split is 0% or 100%. Should only be used when
  // there is another mechanism for re-opening the hidden panel. (Eg: expand/collapse button)
  hideHandleWhenCollapsed?: boolean;
}

export type SplitPanelContainerHandle = {
  getSize: () => number;
  changeSize: (value: number) => void;
};

function getStorageKey(identifier: string) {
  return `dagster.panel-width.${identifier}`;
}

export function getFirstPanelSizeFromStorage(identifier: string, firstInitialPercent: number) {
  const storedSize = window.localStorage.getItem(getStorageKey(identifier));
  const parsed = storedSize === null ? null : parseFloat(storedSize);
  return parsed === null || isNaN(parsed) ? firstInitialPercent : parsed;
}

const DIVIDER_THICKNESS = 2;

export const SplitPanelContainer = forwardRef<SplitPanelContainerHandle, SplitPanelContainerProps>(
  (props, ref) => {
    const {
      axis = 'horizontal',
      identifier,
      first,
      firstInitialPercent,
      firstMinSize,
      secondMinSize = 0,
      second,
    } = props;

    const [_, setTrigger] = useState(0);
    const [resizing, setResizing] = useState(false);

    const getSize = useCallback(() => {
      if (!second) {
        return 100;
      }
      return getFirstPanelSizeFromStorage(identifier, firstInitialPercent);
    }, [firstInitialPercent, identifier, second]);

    const onChangeSize = useCallback(
      (newValue: number) => {
        window.localStorage.setItem(getStorageKey(identifier), `${newValue}`);
        setTrigger((current) => (current ? 0 : 1));
      },
      [identifier],
    );

    useImperativeHandle(ref, () => ({getSize, changeSize: onChangeSize}), [onChangeSize, getSize]);

    const firstSize = getSize();

    const firstPaneStyles: React.CSSProperties = {flexShrink: 0};

    const dividerReservedSpace = first && second ? DIVIDER_THICKNESS : 0;

    // Note: The divider appears after the first panel, so making the first panel 100% wide
    // hides the divider offscreen. To prevent this, we subtract the divider depth.
    if (axis === 'horizontal') {
      if (!first) {
        firstPaneStyles.minWidth = 0;
        firstPaneStyles.width = 0;
      } else {
        firstPaneStyles.minWidth = firstMinSize;
        firstPaneStyles.width = `calc(${firstSize / 100} * (100% - ${
          dividerReservedSpace + (second ? secondMinSize : 0)
        }px))`;
      }
    } else {
      if (!first) {
        firstPaneStyles.minHeight = 0;
        firstPaneStyles.height = 0;
      } else {
        firstPaneStyles.minHeight = firstMinSize;
        firstPaneStyles.height = `calc(${firstSize / 100} * (100% - ${
          dividerReservedSpace + (second ? secondMinSize : 0)
        }px))`;
      }
    }

    const hideHandle =
      props.hideHandleWhenCollapsed && (firstSize <= 0 || firstSize >= 100) && !resizing;

    return (
      <div
        className={clsx(
          styles.container,
          axis === 'horizontal' ? styles.horizontal : styles.vertical,
          resizing && styles.resizing,
          'split-panel-container',
        )}
      >
        <div className={styles.splitPanel} style={firstPaneStyles}>
          {first}
        </div>
        {first && second && !hideHandle ? (
          <PanelDivider
            axis={axis}
            resizing={resizing}
            secondMinSize={secondMinSize}
            onSetResizing={setResizing}
            onMove={onChangeSize}
          />
        ) : undefined}
        <div className={styles.splitPanel} style={{flex: 1}}>
          {second}
        </div>
      </div>
    );
  },
);

interface IDividerProps {
  axis: 'horizontal' | 'vertical';
  resizing: boolean;
  secondMinSize: number;
  onSetResizing: (resizing: boolean) => void;
  onMove: (vw: number) => void;
}

const PanelDivider = (props: IDividerProps) => {
  const {axis, resizing, secondMinSize, onSetResizing, onMove} = props;
  const ref = useRef<HTMLDivElement>(null);

  const onMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();

    onSetResizing(true);

    const onMouseMove = (event: MouseEvent) => {
      const parent = ref.current?.closest('.split-panel-container');
      if (!parent) {
        return;
      }
      const parentRect = parent.getBoundingClientRect();

      const firstPanelPercent =
        axis === 'horizontal'
          ? ((event.clientX - parentRect.left) * 100) /
            (parentRect.width - secondMinSize - DIVIDER_THICKNESS)
          : ((event.clientY - parentRect.top) * 100) /
            (parentRect.height - secondMinSize - DIVIDER_THICKNESS);

      onMove(Math.min(100, Math.max(0, firstPanelPercent)));
    };

    const onMouseUp = () => {
      onSetResizing(false);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  const hitArea =
    axis === 'horizontal' ? (
      <div className={styles.horizontalHitArea} onMouseDown={onMouseDown} />
    ) : (
      <div className={styles.verticalHitArea} onMouseDown={onMouseDown} />
    );

  return axis === 'horizontal' ? (
    <div className={clsx(styles.horizontalDivider, resizing && styles.resizing)} ref={ref}>
      {hitArea}
    </div>
  ) : (
    <div className={clsx(styles.verticalDivider, resizing && styles.resizing)} ref={ref}>
      {hitArea}
    </div>
  );
};
