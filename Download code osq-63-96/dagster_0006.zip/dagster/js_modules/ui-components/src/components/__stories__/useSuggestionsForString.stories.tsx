import * as React from 'react';

import {Box} from '../Box';
import {ButtonLink} from '../ButtonLink';
import {Colors} from '../Color';
import {useSuggestionsForString} from '../useSuggestionsForString';

// eslint-disable-next-line import/no-default-export
export default {
  title: 'useSuggestionsForString',
};

const empties = ['query:', 'prez:', 'state:'];

const values = [
  ...empties,
  'prez:washington',
  'prez:adams',
  'prez:jefferson',
  'state:hull',
  'state:rusk',
  'state:shultz',
];

export const Example = () => {
  const [value, setValue] = React.useState('');
  const buildSuggestions = React.useCallback(
    (queryString: string): string[] =>
      queryString
        ? values.filter((value) => value.toLowerCase().startsWith(queryString))
        : [...empties],
    [],
  );

  const {suggestions, onSelectSuggestion} = useSuggestionsForString(buildSuggestions, value);

  const onChange = React.useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => setValue(e.target.value),
    [setValue],
  );

  return (
    <Box flex={{direction: 'column', gap: 12, alignItems: 'flex-start'}}>
      <input
        type="text"
        value={value}
        onChange={onChange}
        style={{
          border: `1px solid ${Colors.borderDefault()}`,
          borderRadius: '3px',
          padding: '8px',
          fontSize: '14px',
          width: '500px',
        }}
        placeholder="Type something…"
      />
      <div>
        {suggestions.map((suggestion) => (
          <div key={suggestion}>
            <ButtonLink
              onMouseDown={(e: React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                setValue(onSelectSuggestion(suggestion));
              }}
            >
              {suggestion}
            </ButtonLink>
          </div>
        ))}
      </div>
    </Box>
  );
};
