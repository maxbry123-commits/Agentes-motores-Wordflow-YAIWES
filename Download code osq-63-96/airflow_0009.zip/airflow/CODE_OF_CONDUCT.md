<!--
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
-->

# Contributor Covenant Code of Conduct

The Apache Airflow project follows the [Apache Software Foundation code of conduct](https://www.apache.org/foundation/policies/conduct.html).

If you observe behavior that violates those rules please follow the [ASF reporting guidelines](https://www.apache.org/foundation/policies/conduct#reporting-guidelines).

For how the Airflow community responds to repeated Code of Conduct
breaches, spamming, or other sustained disruptive behaviour — and how
affected contributors can appeal a decision via
`private@airflow.apache.org` — see the
[Community escalation process](COMMUNITY_ESCALATION.md).
