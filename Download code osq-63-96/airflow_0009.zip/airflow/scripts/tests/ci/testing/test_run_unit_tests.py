# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import subprocess
from pathlib import Path

SCRIPT_PATH = Path(__file__).resolve().parents[4] / "scripts" / "ci" / "testing" / "run_unit_tests.sh"

# Deliberately excludes the directory holding breeze, so a regression that lets the script run on
# past the guard cannot start a real test run - it fails to find breeze instead.
MINIMAL_ENVIRONMENT = {"PATH": "/usr/bin:/bin"}


def test_run_unit_tests_aborts_when_the_job_budget_is_missing_in_github_actions():
    result = subprocess.run(
        ["bash", str(SCRIPT_PATH), "core", "DB"],
        env={**MINIMAL_ENVIRONMENT, "GITHUB_ACTIONS": "true"},
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 1
    assert "JOB_START_EPOCH and JOB_TIMEOUT_MINUTES must both be set" in result.stdout
