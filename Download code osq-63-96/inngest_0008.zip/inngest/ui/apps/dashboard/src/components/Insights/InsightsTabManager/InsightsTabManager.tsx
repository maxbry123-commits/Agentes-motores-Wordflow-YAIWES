import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { Resizable } from '@inngest/components/Resizable/Resizable';
import { useUser } from '@clerk/tanstack-react-start';
import { ulid } from 'ulid';
import { v4 as uuidv4 } from 'uuid';

import { CellDetailProvider } from '@/components/Insights/CellDetailContext';
import { InsightsStateMachineContextProvider } from '@/components/Insights/InsightsStateMachineContext/InsightsStateMachineContext';
import { SQLEditorProvider } from '@/components/Insights/InsightsSQLEditor/SQLEditorContext';
import type {
  QuerySnapshot,
  QueryTemplate,
  Tab,
} from '@/components/Insights/types';
import type { InsightsQueryStatement } from '@/gql/graphql';
import { isQuerySnapshot, isQueryTemplate } from '../queries';
import { SHOW_DOCS_CONTROL_PANEL_BUTTON } from '../temp-flags';
import { InsightsAIHelperProvider } from '../InsightsAIHelperContext';
import { InsightsHelperPanel } from './InsightsHelperPanel/InsightsHelperPanel';
import {
  InsightsHelperPanelControl,
  type HelperItem,
} from './InsightsHelperPanel/InsightsHelperPanelControl';
import { InsightsHelperPanelIcon } from './InsightsHelperPanel/InsightsHelperPanelIcon';
import {
  CELL_DETAIL,
  DOCUMENTATION,
  INSIGHTS_AI,
  SCHEMA_EXPLORER,
  type HelperTitle,
} from './InsightsHelperPanel/constants';
import {
  InsightsChatProvider,
  useInsightsChatProvider,
} from './InsightsHelperPanel/features/InsightsChat/InsightsChatProvider';
import { InsightsTabPanel } from './InsightsTabPanel';
import { InsightsTabsList } from './InsightsTabsList';
import { HOME_TAB, TEMPLATES_TAB, UNTITLED_QUERY } from './constants';

const TABS_STORAGE_KEY = 'insights-tabs-state';

interface TabsStorageState {
  tabs: Tab[];
  activeTabId: string;
}

function getStoredTabs(): TabsStorageState | null {
  // Skip during SSR - localStorage only exists in browser
  if (typeof window === 'undefined') return null;
  try {
    const stored = localStorage.getItem(TABS_STORAGE_KEY);
    if (!stored) return null;
    return JSON.parse(stored);
  } catch {
    return null;
  }
}

function saveTabsToStorage(tabs: Tab[], activeTabId: string) {
  // Skip during SSR - localStorage only exists in browser
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(
      TABS_STORAGE_KEY,
      JSON.stringify({ tabs, activeTabId }),
    );
  } catch {}
}

export interface CreateTabFromQueryOptions {
  // Auto-run the seeded query after the new tab mounts. Used by deep-link
  // entry points (e.g. the Failed Functions "Open in Insights" button).
  runOnMount?: boolean;
}

export interface TabManagerActions {
  breakQueryAssociation: (savedQueryId: string) => void;
  closeTab: (id: string) => void;
  createNewTab: () => void;
  createTabFromQuery: (
    query: InsightsQueryStatement | QuerySnapshot | QueryTemplate,
    options?: CreateTabFromQueryOptions,
  ) => void;
  focusTab: (id: string) => void;
  openTemplatesTab: () => void;
  updateTab: (id: string, patch: Partial<Omit<Tab, 'id'>>) => void;
}

export interface UseInsightsTabManagerReturn {
  actions: TabManagerActions;
  activeTabId: string;
  isHydrated: boolean;
  tabManager: JSX.Element;
  tabs: Tab[];
}

export interface UseInsightsTabManagerProps {
  historyWindow?: number;
  isQueryHelperPanelVisible: boolean;
  onToggleQueryHelperPanelVisibility: () => void;
  isSavedQueriesFetching: boolean;
  deepLinkQueryId?: string;
}

export function useInsightsTabManager(
  props: UseInsightsTabManagerProps,
): UseInsightsTabManagerReturn {
  // Always initialize with default state to ensure SSR and hydration match
  const [tabs, setTabs] = useState<Tab[]>([HOME_TAB]);
  const [activeTabId, setActiveTabId] = useState<string>(HOME_TAB.id);
  const hasHydratedRef = useRef(false);
  const [isHydrated, setIsHydrated] = useState(false);

  // Wait for saved queries to load before restoring tabs (prevents race condition)
  useEffect(() => {
    if (hasHydratedRef.current || props.isSavedQueriesFetching) return;

    const stored = getStoredTabs();
    if (stored) {
      setTabs(stored.tabs);

      // Handle activeTabId based on deep link
      if (props.deepLinkQueryId) {
        // If there's a deep link, check if the query is already in restored tabs
        const existingTab = stored.tabs.find(
          (tab) => tab.savedQueryId === props.deepLinkQueryId,
        );
        if (existingTab) {
          // Focus the existing tab
          setActiveTabId(existingTab.id);
        }
        // If not found, useDeepLinkHandler will create it and focus it
        // See: ui/apps/dashboard/src/components/Insights/useDeepLinkHandler.ts
      } else {
        // No deep link, restore the previous activeTabId
        setActiveTabId(stored.activeTabId);
      }
    }

    hasHydratedRef.current = true;
    setIsHydrated(true);
  }, [props.isSavedQueriesFetching, props.deepLinkQueryId]);

  // Save tabs to local storage whenever they change (skip first render)
  useEffect(() => {
    if (!hasHydratedRef.current) return;
    saveTabsToStorage(tabs, activeTabId);
  }, [tabs, activeTabId]);

  // Map each UI tab to a stable agent thread id
  const agentThreadIdByTabRef = useRef<Record<string, string>>({});
  const getAgentThreadIdForTab = useCallback((tabId: string): string => {
    const existing = agentThreadIdByTabRef.current[tabId];
    if (existing) return existing;
    const id = uuidv4();
    agentThreadIdByTabRef.current[tabId] = id;
    return id;
  }, []);

  const createTabBase = useCallback(
    (tab: Tab) => {
      setTabs((prev) => [...prev, tab]);
      setActiveTabId(tab.id);
    },
    [setActiveTabId],
  );

  const actions = useMemo(
    () => ({
      breakQueryAssociation: (savedQueryId: string) => {
        setTabs((prevTabs) => {
          // Find the tab associated with this savedQueryId
          const tabToClose = prevTabs.find(
            (tab) => tab.savedQueryId === savedQueryId,
          );

          if (tabToClose) {
            // Close the tab entirely when query is deleted
            const newTabs = prevTabs.filter((tab) => tab.id !== tabToClose.id);
            const newActiveTabId = getNewActiveTabAfterClose(
              prevTabs,
              tabToClose.id,
              activeTabId,
            );
            if (newActiveTabId !== undefined) setActiveTabId(newActiveTabId);
            return newTabs;
          }

          return prevTabs;
        });
      },
      closeTab: (id: string) => {
        setTabs((prevTabs) => {
          const newTabs = prevTabs.filter((tab) => tab.id !== id);

          const newActiveTabId = getNewActiveTabAfterClose(
            prevTabs,
            id,
            activeTabId,
          );
          if (newActiveTabId !== undefined) setActiveTabId(newActiveTabId);

          return newTabs;
        });
      },
      createNewTab: () => {
        createTabBase(makeEmptyUnsavedTab());
      },
      createTabFromQuery: (
        query: InsightsQueryStatement | QuerySnapshot | QueryTemplate,
        options?: CreateTabFromQueryOptions,
      ) => {
        const runOnMount = options?.runOnMount ? true : undefined;

        if (isQueryTemplate(query)) {
          createTabBase({
            ...makeEmptyUnsavedTab(),
            query: query.query,
            name: query.name,
            runOnMount,
          });
          return;
        }

        if (isQuerySnapshot(query)) {
          createTabBase({
            ...makeEmptyUnsavedTab(),
            query: query.query,
            runOnMount,
          });
          return;
        }

        const tabWithSameSavedQueryId = tabs.find(
          (tab) => tab.savedQueryId === query.id,
        );
        if (tabWithSameSavedQueryId !== undefined) {
          setActiveTabId(tabWithSameSavedQueryId.id);
          return;
        }

        createTabBase({
          id: ulid(),
          name: query.name,
          query: query.sql,
          savedQueryId: query.id,
          runOnMount,
        });
      },
      focusTab: setActiveTabId,
      openTemplatesTab: () => {
        const hasTemplatesTab = tabs.some((tab) => tab.id === TEMPLATES_TAB.id);
        if (!hasTemplatesTab) {
          createTabBase(TEMPLATES_TAB);
        } else {
          setActiveTabId(TEMPLATES_TAB.id);
        }
      },
      updateTab: (id: string, tab: Partial<Omit<Tab, 'id'>>) => {
        setTabs((prevTabs) =>
          prevTabs.map((t) => (t.id === id ? { ...t, ...tab } : t)),
        );
      },
    }),
    [activeTabId, createTabBase, tabs],
  );

  const tabManager = useMemo(
    () => (
      <InsightsTabManagerInternal
        actions={actions}
        activeTabId={activeTabId}
        tabs={tabs}
        getAgentThreadIdForTab={getAgentThreadIdForTab}
        historyWindow={props.historyWindow}
        isQueryHelperPanelVisible={props.isQueryHelperPanelVisible}
        onToggleQueryHelperPanelVisibility={
          props.onToggleQueryHelperPanelVisibility
        }
      />
    ),
    [
      actions,
      activeTabId,
      tabs,
      getAgentThreadIdForTab,
      props.historyWindow,
      props.isQueryHelperPanelVisible,
      props.onToggleQueryHelperPanelVisibility,
    ],
  );

  return { actions, activeTabId, isHydrated, tabManager, tabs };
}

interface SingleTabRendererProps {
  tab: Tab;
  activeTabId: string;
  actions: TabManagerActions;
  activeHelper: HelperTitle | null;
  setActiveHelper: (helper: HelperTitle | null) => void;
  isHelperPanelOpen: boolean;
  getAgentThreadIdForTab: (tabId: string) => string;
  helperItems: HelperItem[];
  historyWindow?: number;
}

// Renders a single tab with all its content
function SingleTabRenderer({
  tab,
  activeTabId,
  actions,
  activeHelper,
  setActiveHelper,
  isHelperPanelOpen,
  getAgentThreadIdForTab,
  helperItems,
  historyWindow,
}: SingleTabRendererProps) {
  const isActive = tab.id === activeTabId;

  const handleOpenCellDetailPanel = useCallback(() => {
    setActiveHelper(CELL_DETAIL);
  }, [setActiveHelper]);

  return (
    <InsightsStateMachineContextProvider
      key={tab.id}
      onAutoRunConsumed={() =>
        actions.updateTab(tab.id, { runOnMount: undefined })
      }
      onQueryChange={(query) => actions.updateTab(tab.id, { query })}
      onQueryNameChange={(name) => actions.updateTab(tab.id, { name })}
      query={tab.query}
      queryName={tab.name}
      renderChildren={isActive}
      runOnMount={tab.runOnMount}
      tabId={tab.id}
    >
      <CellDetailProvider onOpenPanel={handleOpenCellDetailPanel}>
        {isQueryTab(tab.id) ? (
          <SQLEditorProvider>
            <div
              className={
                isActive ? 'h-full w-full' : 'h-0 w-full overflow-hidden'
              }
            >
              <div className="flex h-full w-full">
                <div className="h-full min-w-0 flex-1 overflow-hidden">
                  {isHelperPanelOpen && activeHelper ? (
                    <Resizable
                      defaultSplitPercentage={75}
                      minSplitPercentage={20}
                      maxSplitPercentage={85}
                      orientation="horizontal"
                      splitKey="insights-helper-split"
                      first={
                        <div className="h-full min-w-0 overflow-hidden">
                          <InsightsTabPanel
                            isHomeTab={tab.id === HOME_TAB.id}
                            isTemplatesTab={tab.id === TEMPLATES_TAB.id}
                            tab={tab}
                            historyWindow={historyWindow}
                          />
                        </div>
                      }
                      second={
                        <InsightsHelperPanel
                          active={activeHelper}
                          agentThreadId={getAgentThreadIdForTab(tab.id)}
                          onClose={() => {
                            setActiveHelper(null);
                          }}
                        />
                      }
                    />
                  ) : (
                    <InsightsTabPanel
                      isHomeTab={tab.id === HOME_TAB.id}
                      isTemplatesTab={tab.id === TEMPLATES_TAB.id}
                      tab={tab}
                      historyWindow={historyWindow}
                    />
                  )}
                </div>
                {isQueryTab(tab.id) && helperItems.length > 0 ? (
                  <InsightsHelperPanelControl
                    items={helperItems}
                    activeTitle={activeHelper}
                  />
                ) : null}
              </div>
            </div>
          </SQLEditorProvider>
        ) : (
          <div
            className={
              isActive ? 'h-full w-full' : 'h-0 w-full overflow-hidden'
            }
          >
            <InsightsTabPanel
              isHomeTab={tab.id === HOME_TAB.id}
              isTemplatesTab={tab.id === TEMPLATES_TAB.id}
              tab={tab}
              historyWindow={historyWindow}
            />
          </div>
        )}
      </CellDetailProvider>
    </InsightsStateMachineContextProvider>
  );
}

interface TabsWithAIHelperProps {
  tabs: Tab[];
  activeTabId: string;
  actions: TabManagerActions;
  activeHelper: HelperTitle | null;
  setActiveHelper: (helper: HelperTitle | null) => void;
  isHelperPanelOpen: boolean;
  getAgentThreadIdForTab: (tabId: string) => string;
  helperItems: HelperItem[];
  historyWindow?: number;
}

function TabsWithAIHelper({
  tabs,
  activeTabId,
  actions,
  activeHelper,
  setActiveHelper,
  isHelperPanelOpen,
  getAgentThreadIdForTab,
  helperItems,
  historyWindow,
}: TabsWithAIHelperProps) {
  // Access the chat provider context to send messages to AI helper
  const chatProvider = useInsightsChatProvider();

  // Open AI helper by default on mount (now that provider is ready)
  useEffect(() => {
    if (activeHelper === null) {
      setActiveHelper(INSIGHTS_AI);
    }
  }, []); // Only run on mount - setActiveHelper is stable

  const openAIHelperWithPrompt = useCallback(
    async (prompt: string) => {
      // Get the thread ID for the active tab
      const threadId = getAgentThreadIdForTab(activeTabId);

      // Set the current thread ID FIRST, before opening the panel
      // This ensures the InsightsChat component has the correct thread ID when it mounts
      chatProvider.setCurrentThreadId(threadId);

      // Open the AI helper panel (even if already open, this ensures it's visible)
      setActiveHelper(INSIGHTS_AI);

      // Wait a tick to ensure the panel is rendered and state is synced
      await new Promise((resolve) => setTimeout(resolve, 0));

      // Send the prompt message to the thread
      await chatProvider.sendMessageToThread(threadId, prompt);
    },
    [activeTabId, getAgentThreadIdForTab, chatProvider, setActiveHelper],
  );

  return (
    <InsightsAIHelperProvider openAIHelperWithPrompt={openAIHelperWithPrompt}>
      <div className="h-full w-full">
        {tabs.map((tab) => (
          <SingleTabRenderer
            key={tab.id}
            tab={tab}
            activeTabId={activeTabId}
            actions={actions}
            activeHelper={activeHelper}
            setActiveHelper={setActiveHelper}
            isHelperPanelOpen={isHelperPanelOpen}
            getAgentThreadIdForTab={getAgentThreadIdForTab}
            helperItems={helperItems}
            historyWindow={historyWindow}
          />
        ))}
      </div>
    </InsightsAIHelperProvider>
  );
}

interface InsightsTabManagerInternalProps {
  actions: TabManagerActions;
  activeTabId: string;
  getAgentThreadIdForTab: (tabId: string) => string;
  historyWindow?: number;
  isQueryHelperPanelVisible: boolean;
  onToggleQueryHelperPanelVisibility: () => void;
  tabs: Tab[];
}

function InsightsTabManagerInternal({
  tabs,
  activeTabId,
  actions,
  getAgentThreadIdForTab,
  historyWindow,
  isQueryHelperPanelVisible,
  onToggleQueryHelperPanelVisibility,
}: InsightsTabManagerInternalProps) {
  const [activeHelper, setActiveHelper] = useState<HelperTitle | null>(null);

  const handleSelectHelper = useCallback(
    (title: HelperTitle) => {
      if (activeHelper === title) {
        setActiveHelper(null);
      } else {
        setActiveHelper(title);
      }
    },
    [activeHelper],
  );

  const isHelperPanelOpen = activeHelper !== null;

  const helperItems = useMemo<HelperItem[]>(() => {
    const items: HelperItem[] = [];

    items.push({
      title: INSIGHTS_AI,
      label: 'INSIGHTS AI',
      icon: <InsightsHelperPanelIcon title={INSIGHTS_AI} />,
      action: () => handleSelectHelper(INSIGHTS_AI),
    });

    if (SHOW_DOCS_CONTROL_PANEL_BUTTON) {
      items.push({
        title: DOCUMENTATION,
        icon: <InsightsHelperPanelIcon title={DOCUMENTATION} />,
        action: () => handleSelectHelper(DOCUMENTATION),
      });
    }

    items.push({
      title: SCHEMA_EXPLORER,
      label: 'SCHEMA EXPLORER',
      icon: <InsightsHelperPanelIcon title={SCHEMA_EXPLORER} />,
      action: () => handleSelectHelper(SCHEMA_EXPLORER),
    });

    return items;
  }, [handleSelectHelper]);
  const { user } = useUser();

  const tabsProps = {
    tabs,
    activeTabId,
    actions,
    activeHelper,
    setActiveHelper,
    isHelperPanelOpen,
    getAgentThreadIdForTab,
    helperItems,
    historyWindow,
  };
  return (
    <div className="flex h-full w-full flex-1 flex-col overflow-hidden">
      <InsightsTabsList
        activeTabId={activeTabId}
        isQueryHelperPanelVisible={isQueryHelperPanelVisible}
        onToggleQueryHelperPanelVisibility={onToggleQueryHelperPanelVisibility}
        tabs={tabs}
      />
      <div className="flex h-full w-full flex-1 overflow-hidden">
        <InsightsChatProvider
          userId={user?.id || undefined}
          channelKey={user?.id ? `insights:${user.id}` : undefined}
        >
          <ActiveThreadBridge
            activeTabId={activeTabId}
            getAgentThreadIdForTab={getAgentThreadIdForTab}
          />
          <TabsWithAIHelper {...tabsProps} />
        </InsightsChatProvider>
      </div>
    </div>
  );
}

function getNewActiveTabAfterClose(
  existingTabs: Tab[],
  tabIdToClose: string,
  currentActiveTabId: string,
): undefined | string {
  if (tabIdToClose !== currentActiveTabId) return currentActiveTabId;

  const closingTabIndex = existingTabs.findIndex(
    (tab) => tab.id === tabIdToClose,
  );
  if (closingTabIndex === -1) return currentActiveTabId;

  // 1: Try to select the next tab (now where the closed tab was).
  // 2: Try to select the tab before the closed tab.
  const remainingTabs = existingTabs.filter((tab) => tab.id !== tabIdToClose);
  const newlySelectedTabId =
    remainingTabs[closingTabIndex]?.id ??
    remainingTabs[closingTabIndex - 1]?.id;
  return newlySelectedTabId;
}

export function hasDiffWithSavedQuery(
  savedQueries: InsightsQueryStatement[] | undefined,
  tab: Tab,
): boolean {
  if (tab.savedQueryId === undefined || savedQueries === undefined)
    return false;
  const savedQuery = savedQueries.find((q) => q.id === tab.savedQueryId);
  if (!savedQuery) return false;
  return savedQuery.name !== tab.name || savedQuery.sql !== tab.query;
}

/**
 * Determines if a tab has unsaved changes by comparing against either:
 * - The saved query state (if tab.savedQueryId exists), or
 * - The blank state (for new unsaved queries)
 */
export function hasUnsavedChanges(
  savedQueries: InsightsQueryStatement[] | undefined,
  tab: Tab,
): boolean {
  // If tab is associated with a saved query, check diff with saved state
  if (tab.savedQueryId !== undefined) {
    return hasDiffWithSavedQuery(savedQueries, tab);
  }

  // For new queries, check if there's any content different from blank state
  return tab.name !== UNTITLED_QUERY || tab.query !== '';
}

/**
 * Determines whether the given tab represents a saved query.
 *
 * Note on slow/failed query list updates:
 *   - We set `tab.savedQueryId` immediately after a successful create mutation, so
 *   the tab is considered "saved" on the very next render, even before the
 *   saved queries list refetch completes.
 */
export function getIsSavedQuery(tab: Tab): boolean {
  return tab.savedQueryId !== undefined;
}

function makeEmptyUnsavedTab(): Tab {
  return { id: ulid(), name: UNTITLED_QUERY, query: '' };
}

function ActiveThreadBridge({
  activeTabId,
  getAgentThreadIdForTab,
}: {
  activeTabId: string;
  getAgentThreadIdForTab: (tabId: string) => string;
}) {
  const { currentThreadId, setCurrentThreadId } = useInsightsChatProvider();
  const targetThreadId = useMemo(
    () => getAgentThreadIdForTab(activeTabId),
    [activeTabId, getAgentThreadIdForTab],
  );

  useEffect(() => {
    if (currentThreadId !== targetThreadId) {
      try {
        setCurrentThreadId(targetThreadId);
      } catch {}
    }
  }, [currentThreadId, targetThreadId, setCurrentThreadId]);

  return null;
}

function isQueryTab(tabId: string): boolean {
  return tabId !== HOME_TAB.id && tabId !== TEMPLATES_TAB.id;
}
