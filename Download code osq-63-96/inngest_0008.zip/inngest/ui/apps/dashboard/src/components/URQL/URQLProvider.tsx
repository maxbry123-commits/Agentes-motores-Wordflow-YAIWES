import { useEffect, useMemo, useRef } from 'react';
import { authExchange } from '@urql/exchange-auth';
import { requestPolicyExchange } from '@urql/exchange-request-policy';
import { retryExchange } from '@urql/exchange-retry';
import {
  CombinedError,
  Provider,
  cacheExchange,
  createClient,
  fetchExchange,
  mapExchange,
} from 'urql';
import SignInRedirectErrors from '../SignIn/Errors';
import { useNavigate } from '@tanstack/react-router';
import { useAuth } from '@clerk/tanstack-react-start';
import * as Sentry from '@sentry/tanstackstart-react';

/**
 * This is used to ensure that the URQL client is re-created (cache reset) whenever the user signs
 * out or switches organizations.
 * @param {React.ReactNode} children
 * @returns {JSX.Element}
 * @constructor
 */
export default function URQLProviderWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isSignedIn, orgId, userId } = useAuth();
  const prevOrgId = useRef(orgId);

  useEffect(() => {
    if (prevOrgId.current && orgId && prevOrgId.current !== orgId) {
      //
      // Force hard reload on org switch to ensure server-side session sync
      window.location.reload();
    }
    prevOrgId.current = orgId;
  }, [orgId]);

  return (
    <URQLProvider key={`${isSignedIn}-${orgId}-${userId}`}>
      {children}
    </URQLProvider>
  );
}

export function URQLProvider({ children }: { children: React.ReactNode }) {
  const { getToken, signOut } = useAuth();
  const navigate = useNavigate();

  const client = useMemo(() => {
    return createClient({
      url: `${import.meta.env.VITE_API_URL}/gql`,
      fetchOptions: {
        // Necessary to include HTTP-only cookies. This is used for non-Clerk
        // auth.
        credentials: 'include',
      },
      exchanges: [
        requestPolicyExchange({
          // The amount of time in ms that has to go by before we upgrade the operation's request policy to `cache-and-network`.
          ttl: 30_000, // 30 seconds (same value as Next.js’ Full Route Cache)
          // Only upgrade if the request policy is not `cache-only`
          shouldUpgrade: (operation) =>
            operation.context.requestPolicy !== 'cache-only',
        }),
        cacheExchange,
        mapExchange({
          onError(error) {
            // Handle unauthenticated errors after (1) trying to refresh the token and (2) retrying the operation.
            if (isUnauthenticatedError(error)) {
              // Log to Sentry if it still fails after trying to refresh the token and retrying the operation.
              Sentry.captureException(error);
              signOut(() => {
                navigate({
                  to: `${process.env.CLERK_SIGN_IN_URL || '/sign-in'}?error=${
                    SignInRedirectErrors.Unauthenticated
                  }`,
                });
              });
            }
          },
        }),
        retryExchange({
          maxNumberAttempts: 3,
          retryIf: isUnauthenticatedError,
        }),
        authExchange(async (utils) => {
          //
          // Use skipCache to ensure we get a fresh token, especially after org switches
          let sessionToken = await getToken({ skipCache: true });
          return {
            addAuthToOperation: (operation) => {
              if (!sessionToken) return operation;
              return utils.appendHeaders(operation, {
                Authorization: `Bearer ${sessionToken}`,
              });
            },
            didAuthError: isUnauthenticatedError,
            refreshAuth: async () => {
              sessionToken = await getToken({ skipCache: true });
            },
          };
        }),
        fetchExchange,
      ],
    });
  }, [getToken, navigate, signOut]);

  return <Provider value={client}>{children}</Provider>;
}

function isUnauthenticatedError(error: CombinedError): boolean {
  return (
    error.response?.status === 401 ||
    error.graphQLErrors.some((e) => e.extensions.code === 'UNAUTHENTICATED')
  );
}
