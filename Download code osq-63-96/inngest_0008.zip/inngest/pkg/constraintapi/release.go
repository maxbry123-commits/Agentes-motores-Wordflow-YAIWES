package constraintapi

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/google/uuid"
	"github.com/inngest/inngest/pkg/logger"
	"github.com/inngest/inngest/pkg/util/errs"
)

type releaseScriptResponse struct {
	Status int                 `json:"s"`
	Debug  flexibleStringArray `json:"d"`

	// Remaining specifies the number of remaining leases
	// generated in the same Acquire operation
	Remaining int `json:"r"`

	// EnvID from the request state
	EnvID string `json:"e,omitempty"`

	// FunctionID from the request state
	FunctionID string `json:"f,omitempty"`

	// AppID from the request state
	AppID string `json:"ai,omitempty"`

	// Metadata from the request state
	Metadata *struct {
		SourceService           int `json:"ss,omitempty"`
		SourceLocation          int `json:"sl,omitempty"`
		SourceRunProcessingMode int `json:"sm,omitempty"`
	} `json:"m,omitempty"`

	ConstraintUsage         flexibleConstraintUsageArray `json:"cu"`
	StoredConstraints       []SerializedConstraintItem   `json:"sc"`
	OperationIdempotencyHit int                          `json:"oih"`
}

// Release implements CapacityManager.
func (r *redisCapacityManager) Release(ctx context.Context, req *CapacityReleaseRequest) (*CapacityReleaseResponse, errs.InternalError) {
	l := logger.StdlibLogger(ctx)

	// Validate request
	if err := req.Valid(); err != nil {
		return nil, errs.Wrap(0, false, "invalid request: %w", err)
	}

	l = l.With(
		"account_id", req.AccountID,
		"lease_id", req.LeaseID,
		"source", req.Source,
		"shard", r.shardName,
	)

	now := r.clock.Now()

	keys := []string{
		r.keyOperationIdempotency(req.AccountID, "rel", req.IdempotencyKey),
		r.keyScavengerShard(),
		r.keyAccountLeases(req.AccountID),
		r.keyLeaseDetails(req.AccountID, req.LeaseID),
	}

	enableDebugLogsVal := "0"
	if enableDebugLogs || r.enableDebugLogs {
		enableDebugLogsVal = "1"
	}

	enableCacheInvalidation := "0"
	if r.enableAcquireCache != nil {
		enableCacheInvalidation = "1"
	}

	scopedKeyPrefix := fmt.Sprintf("{cs}:%s", accountScope(req.AccountID))

	// Force-release semaphores when the scavenger is reclaiming an expired lease.
	// Without this, manual-release semaphores would be permanently held after a crash.
	forceReleaseSemaphores := "0"
	if req.Source.Location == CallerLocationLeaseScavenge {
		forceReleaseSemaphores = "1"
	}

	args, err := strSlice([]any{
		scopedKeyPrefix,
		req.AccountID,
		req.LeaseID.String(),
		now.UnixMilli(),
		int(r.operationIdempotencyTTL.Seconds()),
		enableDebugLogsVal,
		forceReleaseSemaphores,
		enableCacheInvalidation,
	})
	if err != nil {
		return nil, errs.Wrap(0, false, "invalid args: %w", err)
	}

	l.Trace(
		"prepared release call",
		"req", req,
		"keys", keys,
		"args", args,
	)

	rawRes, operationIdempotencyHit, internalErr := executeLuaScript(
		ctx,
		"release",
		r.shardName,
		req.Source,
		r.client,
		r.clock,
		keys,
		args,
	)
	if internalErr != nil {
		return nil, internalErr
	}

	parsedResponse := releaseScriptResponse{}
	err = json.Unmarshal(rawRes, &parsedResponse)
	if err != nil {
		return nil, errs.Wrap(0, false, "invalid response structure: %w", err)
	}
	if operationIdempotencyHit {
		parsedResponse.OperationIdempotencyHit = 1
	}

	res := &CapacityReleaseResponse{
		AccountID:               req.AccountID,
		Usage:                   constraintUsageFromScript([]scriptConstraintUsage(parsedResponse.ConstraintUsage), constraintItemsFromSerialized(parsedResponse.StoredConstraints)),
		OperationIdempotencyHit: parsedResponse.OperationIdempotencyHit != 0,
		internalDebugState:      parsedResponse,
	}

	// Parse EnvID if present
	if parsedResponse.EnvID != "" {
		envID, err := uuid.Parse(parsedResponse.EnvID)
		if err != nil {
			return nil, errs.Wrap(0, false, "invalid env_id in response: %w", err)
		}
		res.EnvID = envID
	}

	// Parse FunctionID if present
	if parsedResponse.FunctionID != "" {
		functionID, err := uuid.Parse(parsedResponse.FunctionID)
		if err != nil {
			return nil, errs.Wrap(0, false, "invalid function_id in response: %w", err)
		}
		res.FunctionID = functionID
	}

	if parsedResponse.AppID != "" {
		appID, err := uuid.Parse(parsedResponse.AppID)
		if err != nil {
			return nil, errs.Wrap(0, false, "invalid app_id in response: %w", err)
		}
		res.AppID = appID
	}

	// Parse metadata if present
	if parsedResponse.Metadata != nil {
		res.CreationSource = LeaseSource{
			Service:           LeaseService(parsedResponse.Metadata.SourceService),
			Location:          CallerLocation(parsedResponse.Metadata.SourceLocation),
			RunProcessingMode: RunProcessingMode(parsedResponse.Metadata.SourceRunProcessingMode),
		}
	}

	switch parsedResponse.Status {
	case 1, 2:
		l.Trace("capacity lease already cleaned up in release")
	case 3:
		if r.enableHighCardinalityInstrumentation != nil && r.enableHighCardinalityInstrumentation(ctx, req.AccountID, uuid.Nil, uuid.Nil) {
			l.Debug("capacity released")
		}
	default:
		return nil, errs.Wrap(0, false, "unexpected status code %v", parsedResponse.Status)
	}

	if len(r.lifecycles) > 0 {
		for _, hook := range r.lifecycles {
			err := hook.OnCapacityLeaseReleased(ctx, OnCapacityLeaseReleasedData{
				AccountID:               req.AccountID,
				EnvID:                   res.EnvID,
				AppID:                   res.AppID,
				FunctionID:              res.FunctionID,
				LeaseID:                 req.LeaseID,
				Usage:                   res.Usage,
				OperationIdempotencyHit: res.OperationIdempotencyHit,
			})
			if err != nil {
				return nil, errs.Wrap(0, false, "release lifecycle failed: %w", err)
			}
		}
	}

	return res, nil
}
