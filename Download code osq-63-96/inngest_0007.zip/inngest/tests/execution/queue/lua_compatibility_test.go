package queue

import (
	"context"
	"crypto/rand"
	"strconv"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/inngest/inngest/pkg/constraintapi"
	"github.com/inngest/inngest/pkg/consts"
	"github.com/inngest/inngest/pkg/enums"
	"github.com/inngest/inngest/pkg/execution/queue"
	"github.com/inngest/inngest/pkg/execution/state"
	"github.com/inngest/inngest/pkg/execution/state/redis_state"
	"github.com/inngest/inngest/pkg/util"
	"github.com/inngest/inngest/tests/execution/queue/helper"
	"github.com/inngest/inngest/tests/testutil"
	"github.com/jonboulle/clockwork"
	"github.com/oklog/ulid/v2"
	"github.com/stretchr/testify/require"
)

// getItemIDsFromBacklog is a helper function to peek items from a backlog and extract their IDs
func getItemIDsFromBacklog(ctx context.Context, mgr queue.ShardOperations, backlog *queue.QueueBacklog, refillUntil time.Time, limit int64) ([]string, error) {
	res, err := mgr.BacklogPeek(ctx, backlog, time.Time{}, refillUntil, limit)
	if err != nil {
		return nil, err
	}

	itemIDs := make([]string, len(res.Items))
	for i, item := range res.Items {
		itemIDs[i] = item.ID
	}
	return itemIDs, nil
}

// LuaCompatibilityTestCase defines a test case for Lua compatibility against Valkey
type LuaCompatibilityTestCase struct {
	Name       string                // Test case name
	ValkeyOpts []helper.ValkeyOption // Optional Valkey configuration
}

func TestLuaCompatibility(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping functional tests")
	}

	testCases := []LuaCompatibilityTestCase{
		{
			Name: "Basic Valkey",
			ValkeyOpts: []helper.ValkeyOption{
				helper.WithValkeyImage(testutil.ValkeyDefaultImage),
			},
		},
	}

	for _, tc := range testCases {
		t.Run(tc.Name, func(t *testing.T) {
			ctx := context.Background()

			setup := func(t *testing.T, opts ...queue.QueueOpt) redis_state.RedisQueueShard {
				container, err := helper.StartValkey(t, tc.ValkeyOpts...)
				require.NoError(t, err)
				t.Cleanup(func() {
					_ = container.Terminate(ctx)
				})

				client, err := helper.NewValkeyClient(container.Addr, container.Username, container.Password, false)
				require.NoError(t, err)
				t.Cleanup(func() {
					client.Close()
				})

				shard := redis_state.NewQueueShard(
					consts.DefaultQueueShardName,
					redis_state.NewQueueClient(client, redis_state.QueueDefaultKey),
					opts...,
				)

				return shard
			}

			serverType := "valkey"

			t.Run("basic operations", func(t *testing.T) {
				shard := setup(t)

				// Initialize queue
				shardRegistry, err := queue.NewSingleShardRegistry(shard)
				require.NoError(t, err)
				q, err := queue.New(
					context.Background(),
					"test-queue",
					shardRegistry)
				require.NoError(t, err)

				// Test data setup
				accountID := uuid.New()
				functionID := uuid.New()
				runID := ulid.Make()
				now := time.Now().Truncate(time.Second)

				// Create a queue item for testing
				queueItem := queue.QueueItem{
					FunctionID: functionID,
					Data: queue.Item{
						Kind: queue.KindStart,
						Identifier: state.Identifier{
							AccountID: accountID,
							RunID:     runID,
						},
					},
				}

				// - Enqueue item
				enqueuedItem, err := shard.EnqueueItem(ctx, queueItem, now, queue.EnqueueOpts{})
				require.NoError(t, err, "Failed to enqueue item on %s", serverType)
				require.NotEqual(t, enqueuedItem.ID, ulid.Zero, "Enqueued item should have valid ID on %s", serverType)
				require.Equal(t, enqueuedItem.FunctionID, functionID, "Function ID should match on %s", serverType)

				// - Peek partition
				partitions, err := shard.PartitionPeek(ctx, true, now.Add(time.Minute), 10)
				require.NoError(t, err)
				require.Len(t, partitions, 1)
				qp := partitions[0]

				// - Peek item
				peekedItems, err := shard.Peek(ctx, qp, now, 10)
				require.NoError(t, err, "Failed to peek partition on %s", serverType)
				require.NotEmpty(t, peekedItems, "Should find items in partition on %s", serverType)

				// Verify the item is in the peeked results
				var foundItem *queue.QueueItem
				for i := range peekedItems {
					if peekedItems[i].ID == enqueuedItem.ID {
						foundItem = peekedItems[i]
						break
					}
				}
				require.NotNil(t, foundItem, "Should find our enqueued item in partition on %s", serverType)
				require.Equal(t, foundItem.FunctionID, functionID, "Found item should have correct function ID on %s", serverType)

				// - Lease item
				leaseDuration := 30 * time.Second
				leaseID, err := shard.Lease(ctx, enqueuedItem, leaseDuration, now)
				require.NoError(t, err, "Failed to lease item on %s", serverType)
				require.NotNil(t, leaseID, "Lease ID should not be nil on %s", serverType)

				// - Requeue item
				requeueTime := now.Add(5 * time.Second)
				err = q.Requeue(ctx, shard.Name(), enqueuedItem, requeueTime)
				require.NoError(t, err)

				// - Requeue partition
				err = shard.PartitionRequeue(ctx, qp, requeueTime, false)
				require.NoError(t, err, "Failed to requeue partition on %s", serverType)

				// Verify the item is available for leasing again after requeue
				peekedAfterRequeue, err := shard.Peek(ctx, qp, requeueTime.Add(5*time.Second), 10)
				require.NoError(t, err, "Failed to peek partition after requeue on %s", serverType)
				require.NotEmpty(t, peekedAfterRequeue, "Should find items in partition after requeue on %s", serverType)

				err = q.Dequeue(ctx, shard.Name(), enqueuedItem)
				require.NoError(t, err)

				peekedAfterDequeue, err := shard.Peek(ctx, qp, requeueTime.Add(5*time.Second), 10)
				require.NoError(t, err, "Failed to peek partition after requeue on %s", serverType)
				require.Empty(t, peekedAfterDequeue, "Should not find items in partition after dequeue on %s", serverType)
			})

			t.Run("lease with throttle", func(t *testing.T) {
				expr := "event.data.customerID"
				exprHash := util.XXHash(expr)

				opts := []queue.QueueOpt{
					queue.WithPartitionConstraintConfigGetter(func(ctx context.Context, p queue.PartitionIdentifier) queue.PartitionConstraintConfig {
						return queue.PartitionConstraintConfig{
							Throttle: &queue.PartitionThrottle{
								ThrottleKeyExpressionHash: exprHash,
								Limit:                     5,
								Burst:                     0,
								Period:                    60,
							},
						}
					}),
				}

				shard := setup(t, opts...)

				// Test data setup
				accountID := uuid.New()
				functionID := uuid.New()
				runID := ulid.Make()
				now := time.Now().Truncate(time.Second)

				throttleKey := "customer-test"
				keyHash := util.XXHash(throttleKey)

				// Initialize queue
				shardRegistry, err := queue.NewSingleShardRegistry(shard)
				require.NoError(t, err)
				_, err = queue.New(
					context.Background(),
					"test-queue",
					shardRegistry,
					opts...,
				)
				require.NoError(t, err)

				// Create a queue item for testing
				queueItem := queue.QueueItem{
					FunctionID: functionID,
					Data: queue.Item{
						Kind: queue.KindStart,
						Identifier: state.Identifier{
							AccountID: accountID,
							RunID:     runID,
						},
						Throttle: &queue.Throttle{
							Limit:               5,
							Burst:               0,
							Period:              60,
							Key:                 keyHash,
							UnhashedThrottleKey: throttleKey,
							KeyExpressionHash:   exprHash,
						},
					},
				}

				qi, err := shard.EnqueueItem(ctx, queueItem, now, queue.EnqueueOpts{})
				require.NoError(t, err)

				leaseID, err := shard.Lease(ctx, qi, 5*time.Second, now)
				require.NoError(t, err)
				require.NotNil(t, leaseID)
			})

			t.Run("backlog refill with throttle", func(t *testing.T) {
				// Test data setup
				accountID := uuid.New()
				functionID := uuid.New()
				runID := ulid.Make()
				now := time.Now().Truncate(time.Second)

				expr := "event.data.customerID"
				exprHash := util.XXHash(expr)
				throttleKey := "customer-test"
				keyHash := util.XXHash(throttleKey)

				constraints := queue.PartitionConstraintConfig{
					Throttle: &queue.PartitionThrottle{
						ThrottleKeyExpressionHash: exprHash,
						Limit:                     5,
						Burst:                     0,
						Period:                    60,
					},
				}

				opts := []queue.QueueOpt{
					queue.WithPartitionConstraintConfigGetter(func(ctx context.Context, p queue.PartitionIdentifier) queue.PartitionConstraintConfig {
						return constraints
					}),
					queue.WithAllowKeyQueues(func(ctx context.Context, acctID, envID, fnID uuid.UUID) bool {
						return true
					}),
				}

				shard := setup(t, opts...)

				shardRegistry, err := queue.NewSingleShardRegistry(shard)
				require.NoError(t, err)
				q, err := queue.New(
					context.Background(),
					"test-queue",
					shardRegistry,
					opts...,
				)
				require.NoError(t, err)

				// Create a queue item for testing
				queueItem := queue.QueueItem{
					FunctionID: functionID,
					Data: queue.Item{
						Kind: queue.KindStart,
						Identifier: state.Identifier{
							AccountID: accountID,
							RunID:     runID,
						},
						Throttle: &queue.Throttle{
							Limit:               5,
							Burst:               0,
							Period:              60,
							Key:                 keyHash,
							UnhashedThrottleKey: throttleKey,
							KeyExpressionHash:   exprHash,
						},
					},
				}

				// Enqueue to backlog
				qi, err := shard.EnqueueItem(ctx, queueItem, now, queue.EnqueueOpts{})
				require.NoError(t, err)

				backlog := queue.ItemBacklog(ctx, qi)
				sp := queue.ItemShadowPartition(ctx, qi)

				// Use BacklogManager interface to peek items and get their IDs
				refillUntil := now.Add(time.Minute)
				refillItems, err := getItemIDsFromBacklog(ctx, shard, &backlog, refillUntil, 10)
				require.NoError(t, err)

				res, err := shard.BacklogRefill(ctx, &backlog, &sp, refillUntil, refillItems)
				require.NoError(t, err)
				require.NotNil(t, res)
				require.Equal(t, 1, len(res.RefilledItems))

				// Add second item with capacity lease
				capacityLeaseID := ulid.MustNew(ulid.Timestamp(refillUntil.Add(5*time.Second)), rand.Reader)
				item2 := queue.QueueItem{
					FunctionID: functionID,
					Data: queue.Item{
						Kind: queue.KindStart,
						Identifier: state.Identifier{
							AccountID: accountID,
							RunID:     runID,
						},
						Throttle: &queue.Throttle{
							Limit:               5,
							Burst:               0,
							Period:              60,
							Key:                 keyHash,
							UnhashedThrottleKey: throttleKey,
							KeyExpressionHash:   exprHash,
						},
					},
				}

				// Enqueue to backlog
				qi2, err := shard.EnqueueItem(ctx, item2, now, queue.EnqueueOpts{})
				require.NoError(t, err)

				refillItems, err = getItemIDsFromBacklog(ctx, shard, &backlog, refillUntil, 10)
				require.NoError(t, err)

				// Refill with capacity lease awareness
				res, err = shard.BacklogRefill(
					ctx,
					&backlog,
					&sp,
					refillUntil,
					refillItems,
					queue.WithBacklogRefillItemCapacityLeases([]queue.CapacityLease{{
						LeaseID: capacityLeaseID,
					}}),
				)
				require.NoError(t, err)
				require.NotNil(t, res)
				require.Equal(t, 1, len(res.RefilledItems))

				refilled, err := q.LoadQueueItem(ctx, shard.Name(), qi2.ID)
				require.NoError(t, err)
				require.NotNil(t, refilled.CapacityLease)
				require.Equal(t, capacityLeaseID.String(), refilled.CapacityLease.LeaseID.String())
			})

			t.Run("current time is returned for rate limiting", func(t *testing.T) {
				shard := setup(t)

				rc := shard.Client().Client()

				cmd := rc.B().Time().Build()
				res, err := rc.Do(ctx, cmd).AsStrSlice()
				require.NoError(t, err)
				require.Len(t, res, 2)

				t.Log(res)

				parsed, err := strconv.Atoi(res[0])
				require.NoError(t, err)

				t.Log(res[0], parsed)

				parsed, err = strconv.Atoi(res[1])
				require.NoError(t, err)

				t.Log(res[1], parsed)
			})

			t.Run("acquiring capacity works", func(t *testing.T) {
				shard := setup(t)

				rc := shard.Client().Client()

				cm, err := constraintapi.NewRedisCapacityManager(
					constraintapi.WithClock(clockwork.NewRealClock()),
					constraintapi.WithEnableDebugLogs(false),
					constraintapi.WithClient(rc),
					constraintapi.WithShardName("test"),
				)
				require.NoError(t, err)

				config := constraintapi.ConstraintConfig{
					FunctionVersion: 1,
					Concurrency: constraintapi.ConcurrencyConfig{
						AccountConcurrency:  10,
						FunctionConcurrency: 5,
					},
				}

				accountID := uuid.New()
				envID := uuid.New()
				functionID := uuid.New()

				constraints := []constraintapi.ConstraintItem{
					{
						Kind: constraintapi.ConstraintKindConcurrency,
						Concurrency: &constraintapi.ConcurrencyConstraint{
							Scope: enums.ConcurrencyScopeAccount,
							Mode:  enums.ConcurrencyModeStep,
						},
					},
					{
						Kind: constraintapi.ConstraintKindConcurrency,
						Concurrency: &constraintapi.ConcurrencyConstraint{
							Scope: enums.ConcurrencyScopeFn,
							Mode:  enums.ConcurrencyModeStep,
						},
					},
				}

				checkResp, userErr, internalErr := cm.Check(ctx, &constraintapi.CapacityCheckRequest{
					AccountID:     accountID,
					EnvID:         envID,
					FunctionID:    functionID,
					Configuration: config,
					Constraints:   constraints,
				})
				require.NoError(t, internalErr)
				require.NoError(t, userErr)
				require.NotNil(t, checkResp)
				require.Equal(t, 5, checkResp.AvailableCapacity)
				require.Len(t, checkResp.Usage, 2)
				require.Equal(t, 10, checkResp.Usage[0].Limit)
				require.Equal(t, 0, checkResp.Usage[0].Used)
				require.Equal(t, 5, checkResp.Usage[1].Limit)
				require.Equal(t, 0, checkResp.Usage[1].Used)

				acquireResp, err := cm.Acquire(ctx, &constraintapi.CapacityAcquireRequest{
					IdempotencyKey:       "acquire-test",
					AccountID:            accountID,
					EnvID:                envID,
					FunctionID:           functionID,
					Configuration:        config,
					Constraints:          constraints,
					Amount:               1,
					LeaseIdempotencyKeys: []string{"item1"},
					LeaseRunIDs:          nil,
					CurrentTime:          time.Now(),
					Duration:             5 * time.Second,
					MaximumLifetime:      time.Hour,
					Source: constraintapi.LeaseSource{
						Service:           constraintapi.ServiceAPI,
						Location:          constraintapi.CallerLocationItemLease,
						RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
					},
				})

				require.NoError(t, err)
				require.NotNil(t, acquireResp)
				require.Equal(t, 1, len(acquireResp.Leases))

				// Verify that ExhaustedConstraints is empty when capacity is available
				require.Empty(t, acquireResp.ExhaustedConstraints, "ExhaustedConstraints should be empty when leases are granted")

				extendResp, err := cm.ExtendLease(ctx, &constraintapi.CapacityExtendLeaseRequest{
					IdempotencyKey: "extend-test",
					AccountID:      accountID,
					Duration:       5 * time.Second,
					LeaseID:        acquireResp.Leases[0].LeaseID,
				})

				require.NoError(t, err)
				require.NotNil(t, extendResp)
				require.NotNil(t, extendResp.LeaseID)

				releaseResp, err := cm.Release(ctx, &constraintapi.CapacityReleaseRequest{
					IdempotencyKey: "release-test",
					AccountID:      accountID,
					LeaseID:        *extendResp.LeaseID,
					Source: constraintapi.LeaseSource{
						Service:           constraintapi.ServiceAPI,
						Location:          constraintapi.CallerLocationItemLease,
						RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
					},
				})

				require.NoError(t, err)
				require.NotNil(t, releaseResp)

				// Verify release response contains correct metadata
				require.Equal(t, accountID, releaseResp.AccountID)
				require.Equal(t, envID, releaseResp.EnvID)
				require.Equal(t, functionID, releaseResp.FunctionID)
				require.Equal(t, constraintapi.ServiceAPI, releaseResp.CreationSource.Service)
				require.Equal(t, constraintapi.CallerLocationItemLease, releaseResp.CreationSource.Location)
				require.Equal(t, constraintapi.RunProcessingModeDurableEndpoint, releaseResp.CreationSource.RunProcessingMode)
			})

			t.Run("constraint API accepts empty usage arrays", func(t *testing.T) {
				shard := setup(t)

				rc := shard.Client().Client()

				cm, err := constraintapi.NewRedisCapacityManager(
					constraintapi.WithClock(clockwork.NewRealClock()),
					constraintapi.WithEnableDebugLogs(false),
					constraintapi.WithClient(rc),
					constraintapi.WithShardName("test"),
				)
				require.NoError(t, err)

				t.Run("acquire", func(t *testing.T) {
					accountID, envID, functionID := uuid.New(), uuid.New(), uuid.New()
					config, constraints := constraintAPIEmptyUsageConfig()

					firstReq := constraintAPIEmptyUsageAcquireRequest(accountID, envID, functionID, config, constraints, "empty-usage-acquire")
					firstResp, err := cm.Acquire(ctx, firstReq)
					require.NoError(t, err)
					require.Len(t, firstResp.Leases, 1)
					require.NotEmpty(t, firstResp.Usage)

					// Reuse the same idempotency key with a different request
					// fingerprint. Operation idempotency misses, while the real
					// constraint-check idempotency marker from firstReq makes
					// acquire.lua skip GCRA and return an empty Lua table for cu.
					skippedConfig := config
					skippedConfig.FunctionVersion++
					skippedReq := constraintAPIEmptyUsageAcquireRequest(accountID, envID, functionID, skippedConfig, constraints, firstReq.IdempotencyKey)

					resp, err := cm.Acquire(ctx, skippedReq)
					require.NoError(t, err)
					require.Len(t, resp.Leases, 1)
					require.Empty(t, resp.Usage)
				})

				t.Run("extend", func(t *testing.T) {
					accountID, envID, functionID := uuid.New(), uuid.New(), uuid.New()
					config, constraints := constraintAPIEmptyUsageConfig()

					acquireResp, err := cm.Acquire(ctx, constraintAPIEmptyUsageAcquireRequest(accountID, envID, functionID, config, constraints, "empty-usage-extend-acquire"))
					require.NoError(t, err)
					require.Len(t, acquireResp.Leases, 1)

					extendResp, err := cm.ExtendLease(ctx, &constraintapi.CapacityExtendLeaseRequest{
						IdempotencyKey: "empty-usage-extend",
						AccountID:      accountID,
						LeaseID:        acquireResp.Leases[0].LeaseID,
						Duration:       5 * time.Second,
					})
					require.NoError(t, err)
					require.NotNil(t, extendResp.LeaseID)
					require.Empty(t, extendResp.Usage)
				})

				t.Run("release", func(t *testing.T) {
					accountID, envID, functionID := uuid.New(), uuid.New(), uuid.New()
					config, constraints := constraintAPIEmptyUsageConfig()

					acquireResp, err := cm.Acquire(ctx, constraintAPIEmptyUsageAcquireRequest(accountID, envID, functionID, config, constraints, "empty-usage-release-acquire"))
					require.NoError(t, err)
					require.Len(t, acquireResp.Leases, 1)

					releaseResp, err := cm.Release(ctx, &constraintapi.CapacityReleaseRequest{
						IdempotencyKey: "empty-usage-release",
						AccountID:      accountID,
						LeaseID:        acquireResp.Leases[0].LeaseID,
					})
					require.NoError(t, err)
					require.Empty(t, releaseResp.Usage)
				})
			})

			t.Run("acquire cache hit on exhausted constraint", func(t *testing.T) {
				shard := setup(t)

				rc := shard.Client().Client()

				enableCache := func(_ context.Context, _, _, _ uuid.UUID, _ constraintapi.ConstraintItem) bool {
					return true
				}

				cm, err := constraintapi.NewRedisCapacityManager(
					constraintapi.WithClock(clockwork.NewRealClock()),
					constraintapi.WithEnableDebugLogs(true),
					constraintapi.WithClient(rc),
					constraintapi.WithShardName("test"),
					constraintapi.WithEnableAcquireCache(enableCache),
					constraintapi.WithAcquireCacheTTL(func(_ context.Context, _, _, _ uuid.UUID) (time.Duration, time.Duration) {
						return constraintapi.MinCacheTTL, constraintapi.MaxCacheTTL
					}),
				)
				require.NoError(t, err)

				config := constraintapi.ConstraintConfig{
					FunctionVersion: 1,
					Concurrency: constraintapi.ConcurrencyConfig{
						FunctionConcurrency: 1, // Single slot so we can exhaust easily
					},
				}

				accountID := uuid.New()
				envID := uuid.New()
				functionID := uuid.New()

				constraints := []constraintapi.ConstraintItem{
					{
						Kind: constraintapi.ConstraintKindConcurrency,
						Concurrency: &constraintapi.ConcurrencyConstraint{
							Scope: enums.ConcurrencyScopeFn,
							Mode:  enums.ConcurrencyModeStep,
						},
					},
				}

				makeReq := func(idempotencyKey string) *constraintapi.CapacityAcquireRequest {
					return &constraintapi.CapacityAcquireRequest{
						IdempotencyKey:       idempotencyKey,
						AccountID:            accountID,
						EnvID:                envID,
						FunctionID:           functionID,
						Configuration:        config,
						Constraints:          constraints,
						Amount:               1,
						LeaseIdempotencyKeys: []string{"item-" + idempotencyKey},
						CurrentTime:          time.Now(),
						Duration:             30 * time.Second,
						MaximumLifetime:      time.Hour,
						Source: constraintapi.LeaseSource{
							Service:           constraintapi.ServiceAPI,
							Location:          constraintapi.CallerLocationItemLease,
							RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
						},
					}
				}

				// First acquire: fills the single concurrency slot, no cache exists yet
				resp1, err := cm.Acquire(ctx, makeReq("fill-slot"))
				require.NoError(t, err)
				require.Len(t, resp1.Leases, 1, "first acquire should grant one lease")
				// CacheHit is internal; verify behavior via lease count instead

				// Second acquire: constraint is exhausted, Lua writes cache entry
				resp2, err := cm.Acquire(ctx, makeReq("exhaust"))
				require.NoError(t, err)
				require.Empty(t, resp2.Leases, "second acquire should be denied — capacity exhausted")
				require.NotEmpty(t, resp2.ExhaustedConstraints, "should report exhausted constraint")

				// Third acquire: cache entry now exists, should short-circuit via cache
				resp3, err := cm.Acquire(ctx, makeReq("cached"))
				require.NoError(t, err)
				require.Empty(t, resp3.Leases, "third acquire should be denied from cache")
				require.NotEmpty(t, resp3.ExhaustedConstraints, "cached response should report exhausted constraint")
				// CacheHit is internal; verified by empty leases + exhausted constraints above
			})

			t.Run("acquiring capacity when exhausted", func(t *testing.T) {
				shard := setup(t)

				rc := shard.Client().Client()

				cm, err := constraintapi.NewRedisCapacityManager(
					constraintapi.WithClock(clockwork.NewRealClock()),
					constraintapi.WithEnableDebugLogs(false),
					constraintapi.WithClient(rc),
					constraintapi.WithShardName("test"),
				)
				require.NoError(t, err)

				// Set up a low function concurrency limit that we can easily exhaust
				config := constraintapi.ConstraintConfig{
					FunctionVersion: 1,
					Concurrency: constraintapi.ConcurrencyConfig{
						AccountConcurrency:  10,
						FunctionConcurrency: 2, // Low limit to easily exhaust
					},
				}

				accountID := uuid.New()
				envID := uuid.New()
				functionID := uuid.New()

				constraints := []constraintapi.ConstraintItem{
					{
						Kind: constraintapi.ConstraintKindConcurrency,
						Concurrency: &constraintapi.ConcurrencyConstraint{
							Scope: enums.ConcurrencyScopeAccount,
							Mode:  enums.ConcurrencyModeStep,
						},
					},
					{
						Kind: constraintapi.ConstraintKindConcurrency,
						Concurrency: &constraintapi.ConcurrencyConstraint{
							Scope: enums.ConcurrencyScopeFn,
							Mode:  enums.ConcurrencyModeStep,
						},
					},
				}

				// Acquire first lease (should succeed)
				acquire1Resp, err := cm.Acquire(ctx, &constraintapi.CapacityAcquireRequest{
					IdempotencyKey:       "acquire-1",
					AccountID:            accountID,
					EnvID:                envID,
					FunctionID:           functionID,
					Configuration:        config,
					Constraints:          constraints,
					Amount:               1,
					LeaseIdempotencyKeys: []string{"item1"},
					LeaseRunIDs:          nil,
					CurrentTime:          time.Now(),
					Duration:             30 * time.Second,
					MaximumLifetime:      time.Hour,
					Source: constraintapi.LeaseSource{
						Service:           constraintapi.ServiceAPI,
						Location:          constraintapi.CallerLocationItemLease,
						RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
					},
				})
				require.NoError(t, err)
				require.NotNil(t, acquire1Resp)
				require.Equal(t, 1, len(acquire1Resp.Leases))

				// Acquire second lease (should succeed, reaching the limit)
				acquire2Resp, err := cm.Acquire(ctx, &constraintapi.CapacityAcquireRequest{
					IdempotencyKey:       "acquire-2",
					AccountID:            accountID,
					EnvID:                envID,
					FunctionID:           functionID,
					Configuration:        config,
					Constraints:          constraints,
					Amount:               1,
					LeaseIdempotencyKeys: []string{"item2"},
					LeaseRunIDs:          nil,
					CurrentTime:          time.Now(),
					Duration:             30 * time.Second,
					MaximumLifetime:      time.Hour,
					Source: constraintapi.LeaseSource{
						Service:           constraintapi.ServiceAPI,
						Location:          constraintapi.CallerLocationItemLease,
						RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
					},
				})
				require.NoError(t, err)
				require.NotNil(t, acquire2Resp)
				require.Equal(t, 1, len(acquire2Resp.Leases))

				// Verify that function concurrency is now exhausted
				require.Len(t, acquire2Resp.ExhaustedConstraints, 1, "Function concurrency should be exhausted after acquiring 2 leases")
				require.Equal(t, constraintapi.ConstraintKindConcurrency, acquire2Resp.ExhaustedConstraints[0].Kind)
				require.Equal(t, enums.ConcurrencyScopeFn, acquire2Resp.ExhaustedConstraints[0].Concurrency.Scope)

				// Acquire third lease (should fail due to exhaustion)
				acquire3Resp, err := cm.Acquire(ctx, &constraintapi.CapacityAcquireRequest{
					IdempotencyKey:       "acquire-3",
					AccountID:            accountID,
					EnvID:                envID,
					FunctionID:           functionID,
					Configuration:        config,
					Constraints:          constraints,
					Amount:               1,
					LeaseIdempotencyKeys: []string{"item3"},
					LeaseRunIDs:          nil,
					CurrentTime:          time.Now(),
					Duration:             30 * time.Second,
					MaximumLifetime:      time.Hour,
					Source: constraintapi.LeaseSource{
						Service:           constraintapi.ServiceAPI,
						Location:          constraintapi.CallerLocationItemLease,
						RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
					},
				})
				require.NoError(t, err)
				require.NotNil(t, acquire3Resp)
				require.Empty(t, acquire3Resp.Leases, "No leases should be granted when capacity is exhausted")

				// Verify that ExhaustedConstraints is populated when acquisition fails
				require.Len(t, acquire3Resp.ExhaustedConstraints, 1, "ExhaustedConstraints should identify the blocking constraint")
				require.Equal(t, constraintapi.ConstraintKindConcurrency, acquire3Resp.ExhaustedConstraints[0].Kind)
				require.Equal(t, enums.ConcurrencyScopeFn, acquire3Resp.ExhaustedConstraints[0].Concurrency.Scope)

				// Verify RetryAfter is set
				require.False(t, acquire3Resp.RetryAfter.IsZero(), "RetryAfter should be set when capacity is exhausted")
			})
		})
	}
}

func constraintAPIEmptyUsageConfig() (constraintapi.ConstraintConfig, []constraintapi.ConstraintItem) {
	config := constraintapi.ConstraintConfig{
		FunctionVersion: 1,
		RateLimit: []constraintapi.RateLimitConfig{
			{
				Scope:             enums.RateLimitScopeFn,
				KeyExpressionHash: "expr",
				Limit:             120,
				Period:            60,
			},
		},
	}
	constraints := []constraintapi.ConstraintItem{
		{
			Kind: constraintapi.ConstraintKindRateLimit,
			RateLimit: &constraintapi.RateLimitConstraint{
				Scope:             enums.RateLimitScopeFn,
				KeyExpressionHash: "expr",
				EvaluatedKeyHash:  "value",
			},
		},
	}
	return config, constraints
}

func constraintAPIEmptyUsageAcquireRequest(
	accountID uuid.UUID,
	envID uuid.UUID,
	functionID uuid.UUID,
	config constraintapi.ConstraintConfig,
	constraints []constraintapi.ConstraintItem,
	idempotencyKey string,
) *constraintapi.CapacityAcquireRequest {
	return &constraintapi.CapacityAcquireRequest{
		IdempotencyKey:       idempotencyKey,
		AccountID:            accountID,
		EnvID:                envID,
		FunctionID:           functionID,
		Configuration:        config,
		Constraints:          constraints,
		Amount:               1,
		LeaseIdempotencyKeys: []string{"item-" + idempotencyKey},
		CurrentTime:          time.Now(),
		Duration:             5 * time.Second,
		MaximumLifetime:      time.Hour,
		Source: constraintapi.LeaseSource{
			Service:           constraintapi.ServiceAPI,
			Location:          constraintapi.CallerLocationItemLease,
			RunProcessingMode: constraintapi.RunProcessingModeDurableEndpoint,
		},
	}
}
