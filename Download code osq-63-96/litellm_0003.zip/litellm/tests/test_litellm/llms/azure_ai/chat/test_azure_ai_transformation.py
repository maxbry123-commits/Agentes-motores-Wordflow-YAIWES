import json
from unittest.mock import MagicMock, patch

import pytest

from litellm.llms.azure_ai.azure_model_router.transformation import (
    AzureModelRouterConfig,
)
from litellm.llms.azure_ai.chat.transformation import AzureAIStudioConfig


@pytest.mark.asyncio
async def test_get_openai_compatible_provider_info():
    """
    Test that Azure AI requests are formatted correctly with the proper endpoint and parameters
    for both synchronous and asynchronous calls
    """
    config = AzureAIStudioConfig()

    (
        api_base,
        dynamic_api_key,
        custom_llm_provider,
    ) = config._get_openai_compatible_provider_info(
        model="azure_ai/gpt-4o-mini",
        api_base="https://my-base",
        api_key="my-key",
        custom_llm_provider="azure_ai",
    )

    assert custom_llm_provider == "azure"


def test_azure_ai_validate_environment():
    config = AzureAIStudioConfig()
    headers = config.validate_environment(
        headers={},
        model="azure_ai/gpt-4o-mini",
        messages=[],
        optional_params={},
        litellm_params={},
    )
    assert headers["Content-Type"] == "application/json"


def test_azure_ai_validate_environment_with_api_key():
    """
    Test that when api_key is provided, it is set in the api-key header
    for Azure Foundry endpoints (.services.ai.azure.com).
    """
    config = AzureAIStudioConfig()
    headers = config.validate_environment(
        headers={},
        model="Kimi-K2.5",
        messages=[],
        optional_params={},
        litellm_params={},
        api_key="test-api-key",
        api_base="https://my-endpoint.services.ai.azure.com",
    )
    assert headers["api-key"] == "test-api-key"
    assert headers["Content-Type"] == "application/json"


def test_azure_ai_validate_environment_with_azure_ad_token():
    """
    Test that when no api_key is provided but Azure AD credentials are available,
    the Authorization header is set with a Bearer token.

    Regression test for https://github.com/BerriAI/litellm/issues/20759
    """
    import litellm

    config = AzureAIStudioConfig()
    with (
        patch(
            "litellm.llms.azure.common_utils.get_azure_ad_token",
            return_value="fake-azure-ad-token",
        ),
        patch(
            "litellm.llms.azure.common_utils.get_secret_str",
            return_value=None,
        ),
        patch.object(litellm, "api_key", None),
        patch.object(litellm, "azure_key", None),
    ):
        headers = config.validate_environment(
            headers={},
            model="Kimi-K2.5",
            messages=[],
            optional_params={},
            litellm_params={},
            api_key=None,
            api_base="https://my-endpoint.services.ai.azure.com",
        )
    assert headers.get("Authorization") == "Bearer fake-azure-ad-token"
    assert "api-key" not in headers
    assert headers["Content-Type"] == "application/json"


def test_azure_ai_grok_stop_parameter_handling():
    """
    Test that Grok models properly handle stop parameter filtering in Azure AI Studio.
    """
    config = AzureAIStudioConfig()

    # Test Grok model detection
    assert config._supports_stop_reason("grok-4-fast") is False
    assert config._supports_stop_reason("grok-4.3") is False
    assert config._supports_stop_reason("grok-4") is False
    assert config._supports_stop_reason("grok-3-mini") is False
    assert config._supports_stop_reason("grok-code-fast") is False
    assert config._supports_stop_reason("gpt-4") is True

    # Test supported parameters for Grok models
    for model in ("grok-4-fast", "grok-4.3"):
        grok_params = config.get_supported_openai_params(model)
        assert (
            "stop" not in grok_params
        ), "Grok models should not support stop parameter"

    # Test supported parameters for non-Grok models
    gpt_params = config.get_supported_openai_params("gpt-4")
    assert "stop" in gpt_params, "GPT models should support stop parameter"


def test_azure_model_router_response_shows_actual_model():
    """
    Test that Azure Model Router returns the actual model used in the response,
    not the router model.

    According to the documentation, when using Azure Model Router, the response
    should show the actual model that handled the request (e.g., gpt-5-nano-2025-08-07)
    rather than the router model (e.g., model-router).

    Regression test for: Azure Model Router should show actual model in response
    """
    from httpx import Response

    from litellm.llms.base_llm.chat.transformation import LiteLLMLoggingObj
    from litellm.types.utils import ModelResponse

    config = AzureModelRouterConfig()

    # Mock raw response from Azure that includes the actual model used
    raw_response_json = {
        "id": "chatcmpl-test123",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "gpt-5-nano-2025-08-07",  # Actual model used by the router
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": "Hello!",
                },
                "finish_reason": "stop",
            }
        ],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 5,
            "total_tokens": 15,
        },
    }

    # Create mock Response object
    mock_response = MagicMock(spec=Response)
    mock_response.json.return_value = raw_response_json
    mock_response.text = json.dumps(raw_response_json)
    mock_response.headers = {}

    # Create ModelResponse object
    model_response = ModelResponse()

    # Create mock logging object with required methods
    logging_obj = MagicMock(spec=LiteLLMLoggingObj)
    logging_obj.post_call = MagicMock()
    logging_obj.model_call_details = {}

    # Call transform_response with router model
    result = config.transform_response(
        model="model-router",  # This is the router model (without prefix)
        raw_response=mock_response,
        model_response=model_response,
        logging_obj=logging_obj,
        request_data={},
        messages=[{"role": "user", "content": "Hello"}],
        optional_params={},
        litellm_params={"model": "azure_ai/model-router"},  # Original request model
        encoding=None,
        api_key="test-key",
        json_mode=False,
    )

    # Verify that the response contains the actual model used, not the router model
    assert result.model == "azure_ai/gpt-5-nano-2025-08-07", (
        f"Expected model to be 'azure_ai/gpt-5-nano-2025-08-07' (actual model used), "
        f"but got '{result.model}'"
    )


def test_azure_model_router_stamps_selected_model_on_hidden_params():
    """
    The selected model must be stamped on _hidden_params, not left for downstream code to
    re-derive by looking for "model-router" in the model string. Deployments whose alias
    does not contain that text are invisible to the string check.
    """
    from httpx import Response

    from litellm.llms.azure_ai.common_utils import (
        AZURE_MODEL_ROUTER_SELECTED_MODEL_KEY,
        AzureFoundryModelInfo,
    )
    from litellm.llms.base_llm.chat.transformation import LiteLLMLoggingObj
    from litellm.types.utils import ModelResponse

    raw_response_json = {
        "id": "chatcmpl-test456",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "grok-4-1-fast-reasoning",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "pong"},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }

    mock_response = MagicMock(spec=Response)
    mock_response.json.return_value = raw_response_json
    mock_response.text = json.dumps(raw_response_json)
    mock_response.headers = {}

    logging_obj = MagicMock(spec=LiteLLMLoggingObj)
    logging_obj.post_call = MagicMock()
    logging_obj.model_call_details = {}

    result = AzureModelRouterConfig().transform_response(
        model="smart-pick",
        raw_response=mock_response,
        model_response=ModelResponse(),
        logging_obj=logging_obj,
        request_data={},
        messages=[{"role": "user", "content": "Reply with just pong"}],
        optional_params={},
        litellm_params={"model": "azure_ai/model_router/smart-pick"},
        encoding=None,
        api_key="test-key",
        json_mode=False,
    )

    assert result._hidden_params[AZURE_MODEL_ROUTER_SELECTED_MODEL_KEY] == result.model
    assert (
        result._hidden_params[AZURE_MODEL_ROUTER_SELECTED_MODEL_KEY]
        == "azure_ai/grok-4-1-fast-reasoning"
    )
    assert AzureFoundryModelInfo.get_model_router_selected_model(
        result._hidden_params
    ) == ("azure_ai/grok-4-1-fast-reasoning")
    assert (
        AzureFoundryModelInfo.is_model_router_call(
            model="smart-pick", hidden_params=result._hidden_params
        )
        is True
    )


def test_azure_model_router_stamp_does_not_leak_across_responses():
    """
    ModelResponse declares _hidden_params as a class-level dict, so the stamp has to be written
    as a fresh dict. Mutating in place would bleed the selected model into unrelated responses.
    """
    from litellm.llms.azure_ai.common_utils import (
        AZURE_MODEL_ROUTER_SELECTED_MODEL_KEY,
    )
    from litellm.types.utils import ModelResponse

    untouched = ModelResponse()

    assert AZURE_MODEL_ROUTER_SELECTED_MODEL_KEY not in (untouched._hidden_params or {})


def test_drop_tool_level_extra_fields_strips_copilot_mcp_server_name():
    """
    Regression test: Azure AI returns 400 when tools contain copilot_mcp_server_name.
    LiteLLM should strip the field and retry automatically.
    """
    import httpx

    config = AzureAIStudioConfig()

    error_text = json.dumps(
        {
            "error": {
                "message": "2 request validation errors: Extra inputs are not permitted, field: 'tools[0].copilot_mcp_server_name', value: 'github-mcp-server'; Extra inputs are not permitted, field: 'tools[1].copilot_mcp_server_name', value: 'ide'"
            }
        }
    )
    mock_response = MagicMock(spec=httpx.Response)
    mock_response.text = error_text
    mock_response.json.return_value = json.loads(error_text)
    mock_response.status_code = 400
    e = httpx.HTTPStatusError(
        message="400", request=MagicMock(), response=mock_response
    )

    assert config._error_has_tool_level_extra_fields(error_text) is True
    assert (
        config.should_retry_llm_api_inside_llm_translation_on_http_error(e, {}) is True
    )

    request_data = {
        "model": "FW-Kimi-K2.6",
        "messages": [{"role": "user", "content": "Say hi."}],
        "tools": [
            {
                "type": "function",
                "copilot_mcp_server_name": "github-mcp-server",
                "function": {
                    "name": "github_search_code",
                    "description": "Search code",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
            {
                "type": "function",
                "copilot_mcp_server_name": "ide",
                "function": {
                    "name": "read_file",
                    "description": "Read a file",
                    "parameters": {"type": "object", "properties": {}},
                },
            },
        ],
    }

    result = config.transform_request_on_unprocessable_entity_error(e, request_data)

    for tool in result["tools"]:
        assert "copilot_mcp_server_name" not in tool
    assert result["tools"][0]["type"] == "function"
    assert result["tools"][1]["function"]["name"] == "read_file"


def _find_key_anywhere(obj, key: str) -> bool:
    if isinstance(obj, dict):
        if key in obj:
            return True
        return any(_find_key_anywhere(v, key) for v in obj.values())
    if isinstance(obj, list):
        return any(_find_key_anywhere(item, key) for item in obj)
    return False


def test_azure_ai_strips_non_openai_spec_message_fields():
    """
    Regression for https://github.com/BerriAI/litellm/issues/33961.

    Azure AI Foundry backends set additionalProperties=false, so any message
    field outside the OpenAI chat-completions schema causes a 400 "Extra inputs
    are not permitted". Anthropic-format clients (e.g. Claude Code) echo prior
    assistant turns back as history carrying thinking_blocks, a nested thought
    signature at tool_calls[].function.provider_specific_fields, and Anthropic
    cache_control annotations. transform_request must strip all of these before
    the request reaches the upstream.
    """
    config = AzureAIStudioConfig()

    messages = [
        {"role": "user", "content": "Read a file."},
        {
            "role": "assistant",
            "content": "I can help.",
            "thinking_blocks": [
                {
                    "type": "thinking",
                    "thinking": "The user wants me to read a file.",
                    "signature": "",
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            "reasoning_content": "The user wants me to read a file.",
            "provider_specific_fields": {"thought_signature": "sig-top"},
            "tool_calls": [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {
                        "name": "read_file",
                        "arguments": "{}",
                        "provider_specific_fields": {"thought_signature": "sig-nested"},
                    },
                }
            ],
        },
        {"role": "user", "content": "go ahead"},
    ]

    request = config.transform_request(
        model="fw-glm-5.2",
        messages=messages,
        optional_params={},
        litellm_params={},
        headers={},
    )

    transformed_messages = request["messages"]

    assert not _find_key_anywhere(transformed_messages, "thinking_blocks")
    assert not _find_key_anywhere(transformed_messages, "reasoning_content")
    assert not _find_key_anywhere(transformed_messages, "provider_specific_fields")
    assert not _find_key_anywhere(transformed_messages, "cache_control")

    assistant_message = transformed_messages[1]
    assert assistant_message["content"] == "I can help."
    assert assistant_message["tool_calls"][0]["function"]["name"] == "read_file"


def test_azure_ai_stripping_does_not_mutate_caller_messages():
    """
    The stripping must not touch the caller's messages. LiteLLM reuses the same
    message objects when falling back to another provider, so stripping in place
    would hand the fallback a conversation history with its thinking blocks and
    provider metadata already destroyed.
    """
    config = AzureAIStudioConfig()

    messages = [
        {"role": "user", "content": "Read a file."},
        {
            "role": "assistant",
            "content": "I can help.",
            "thinking_blocks": [
                {"type": "thinking", "thinking": "Reading the file.", "signature": "sig"}
            ],
            "provider_specific_fields": {"thought_signature": "sig-top"},
            "tool_calls": [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {
                        "name": "read_file",
                        "arguments": "{}",
                        "provider_specific_fields": {"thought_signature": "sig-nested"},
                    },
                }
            ],
        },
    ]

    request = config.transform_request(
        model="fw-glm-5.2",
        messages=messages,
        optional_params={},
        litellm_params={},
        headers={},
    )

    assert not _find_key_anywhere(request["messages"], "thinking_blocks")

    original_assistant = messages[1]
    assert original_assistant["thinking_blocks"][0]["thinking"] == "Reading the file."
    assert original_assistant["provider_specific_fields"] == {"thought_signature": "sig-top"}
    assert original_assistant["tool_calls"][0]["function"]["provider_specific_fields"] == {
        "thought_signature": "sig-nested"
    }
