# MiniMax chat tests
