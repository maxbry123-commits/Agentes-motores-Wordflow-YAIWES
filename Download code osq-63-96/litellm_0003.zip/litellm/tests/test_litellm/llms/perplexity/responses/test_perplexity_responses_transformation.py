"""
Tests for Perplexity Responses API transformation

Tests the PerplexityResponsesConfig class that handles Perplexity-specific
transformations for the Agent API (Responses API).

Source: litellm/llms/perplexity/responses/transformation.py
"""

import json

import httpx
import pytest


from litellm.litellm_core_utils.litellm_logging import Logging as LiteLLMLoggingObj
from litellm.llms.base_llm.chat.transformation import BaseLLMException
from litellm.llms.perplexity.responses.transformation import PerplexityResponsesConfig
from litellm.types.llms.openai import ResponsesAPIOptionalRequestParams
from litellm.types.utils import LlmProviders
from litellm.utils import ProviderConfigManager


class TestPerplexityResponsesTransformation:
    """Test Perplexity Responses API configuration and transformations"""

    def test_function_tool_passthrough(self):
        """Function tools with name/description/parameters are preserved"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            tools=[
                {
                    "type": "function",
                    "function": {
                        "name": "get_weather",
                        "description": "Get the current weather",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "location": {"type": "string"},
                                "unit": {
                                    "type": "string",
                                    "enum": ["celsius", "fahrenheit"],
                                },
                            },
                        },
                    },
                }
            ]
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert "tools" in result
        assert len(result["tools"]) == 1
        assert result["tools"][0]["type"] == "function"
        assert result["tools"][0]["function"]["name"] == "get_weather"
        assert (
            result["tools"][0]["function"]["description"] == "Get the current weather"
        )
        assert "parameters" in result["tools"][0]["function"]

    def test_web_search_tool_passthrough(self):
        """web_search tools are passed through unchanged"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(tools=[{"type": "web_search"}])

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert "tools" in result
        assert len(result["tools"]) == 1
        assert result["tools"][0]["type"] == "web_search"

    def test_fetch_url_tool_passthrough(self):
        """fetch_url tools are passed through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(tools=[{"type": "fetch_url"}])

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert "tools" in result
        assert len(result["tools"]) == 1
        assert result["tools"][0]["type"] == "fetch_url"

    def test_mixed_tools_function_and_web_search(self):
        """Mixed function and web_search tools are transformed correctly"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            tools=[
                {"type": "web_search"},
                {
                    "type": "function",
                    "function": {
                        "name": "custom_tool",
                        "description": "A custom tool",
                        "parameters": {"type": "object"},
                    },
                },
            ]
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert len(result["tools"]) == 2
        assert result["tools"][0]["type"] == "web_search"
        assert result["tools"][1]["type"] == "function"
        assert result["tools"][1]["function"]["name"] == "custom_tool"

    def test_tool_choice_mapping(self):
        """tool_choice passes through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            tool_choice="required", temperature=0.7
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("tool_choice") == "required"

    def test_parallel_tool_calls(self):
        """parallel_tool_calls passes through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            parallel_tool_calls=True, temperature=0.7
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("parallel_tool_calls") is True

    def test_max_tool_calls_mapping(self):
        """max_tool_calls passes through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(max_tool_calls=5, temperature=0.7)

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("max_tool_calls") == 5

    def test_text_passthrough(self):
        """text param passes through as-is (Perplexity accepts Open Responses format directly)"""
        config = PerplexityResponsesConfig()

        text_value = {
            "format": {
                "type": "json_schema",
                "name": "weather_response",
                "schema": {
                    "type": "object",
                    "properties": {"temp": {"type": "number"}},
                },
                "strict": True,
            }
        }

        params = ResponsesAPIOptionalRequestParams(
            text=text_value,
            temperature=0.7,
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert "text" in result
        assert result["text"] == text_value
        assert "response_format" not in result

    def test_previous_response_id(self):
        """previous_response_id passes through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            previous_response_id="resp_abc123",
            temperature=0.7,
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("previous_response_id") == "resp_abc123"

    def test_store_background_truncation(self):
        """Lifecycle params pass through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            store=True,
            background=False,
            truncation="auto",
            temperature=0.7,
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("store") is True
        assert result.get("background") is False
        assert result.get("truncation") == "auto"

    def test_metadata_safety_identifier_user(self):
        """Metadata params pass through"""
        config = PerplexityResponsesConfig()

        params = ResponsesAPIOptionalRequestParams(
            metadata={"request_id": "req_123"},
            safety_identifier="safety_123",
            user="user_456",
            temperature=0.7,
        )

        result = config.map_openai_params(
            response_api_optional_params=params,
            model="perplexity/openai/gpt-5.2",
            drop_params=False,
        )

        assert result.get("metadata") == {"request_id": "req_123"}
        assert result.get("safety_identifier") == "safety_123"
        assert result.get("user") == "user_456"

    def test_all_supported_params_declared(self):
        """get_supported_openai_params returns Perplexity-specific restricted list"""
        config = PerplexityResponsesConfig()
        supported = config.get_supported_openai_params("perplexity/openai/gpt-5.2")

        # Perplexity Responses API supports a restricted set of params
        # Ref: https://docs.perplexity.ai/api-reference/responses-post
        expected = [
            "max_output_tokens",
            "stream",
            "temperature",
            "top_p",
            "tools",
            "reasoning",
            "instructions",
            "models",
        ]

        for param in expected:
            assert param in supported, f"Missing supported param: {param}"

    def test_cost_dict_to_float_via_validator(self):
        """Perplexity cost dict is parsed by generic ResponseAPIUsage.parse_cost validator"""
        from litellm.types.llms.openai import ResponseAPIUsage

        usage = ResponseAPIUsage(
            input_tokens=100,
            output_tokens=200,
            total_tokens=300,
            cost={
                "currency": "USD",
                "input_cost": 0.0001,
                "output_cost": 0.0002,
                "total_cost": 0.0003,
            },
        )

        assert usage.input_tokens == 100
        assert usage.output_tokens == 200
        assert usage.total_tokens == 300
        assert usage.cost == 0.0003

    def test_cost_float_passthrough_via_validator(self):
        """Cost already float passes through validator unchanged"""
        from litellm.types.llms.openai import ResponseAPIUsage

        usage = ResponseAPIUsage(
            input_tokens=100,
            output_tokens=200,
            total_tokens=300,
            cost=0.0005,
        )

        assert usage.cost == 0.0005

    def test_preset_handling(self):
        """Preset model names work"""
        config = PerplexityResponsesConfig()

        data = config.transform_responses_api_request(
            model="preset/pro-search",
            input="What is AI?",
            response_api_optional_request_params={"temperature": 0.7},
            litellm_params={},
            headers={},
        )

        assert data["preset"] == "pro-search"
        assert data["input"] == "What is AI?"
        assert "temperature" in data

    def test_preset_handling_list_input(self):
        """Preset with list input preserves type field"""
        config = PerplexityResponsesConfig()

        list_input = [
            {"type": "message", "role": "user", "content": "What is AI?"},
        ]

        data = config.transform_responses_api_request(
            model="preset/pro-search",
            input=list_input,
            response_api_optional_request_params={"temperature": 0.7},
            litellm_params={},
            headers={},
        )

        assert data["preset"] == "pro-search"
        assert isinstance(data["input"], list)
        assert data["input"][0]["type"] == "message"
        assert data["input"][0]["role"] == "user"

    def test_non_preset_list_input(self):
        """Non-preset with list input preserves type field"""
        config = PerplexityResponsesConfig()

        list_input = [
            {"type": "message", "role": "user", "content": "Hello"},
        ]

        data = config.transform_responses_api_request(
            model="openai/gpt-5.2",
            input=list_input,
            response_api_optional_request_params={},
            litellm_params={},
            headers={},
        )

        assert data["model"] == "openai/gpt-5.2"
        assert isinstance(data["input"], list)
        assert data["input"][0]["type"] == "message"

    def test_list_input_adds_type_message_when_missing(self):
        """Input items without type get type='message' added automatically"""
        config = PerplexityResponsesConfig()

        list_input = [
            {"role": "user", "content": "Hello"},
        ]

        data = config.transform_responses_api_request(
            model="openai/gpt-5.2",
            input=list_input,
            response_api_optional_request_params={},
            litellm_params={},
            headers={},
        )

        assert data["input"][0]["type"] == "message"
        assert data["input"][0]["role"] == "user"
        assert data["input"][0]["content"] == "Hello"

    def test_list_input_preserves_existing_type(self):
        """Input items that already have type are not modified"""
        config = PerplexityResponsesConfig()

        list_input = [
            {"type": "function_call_output", "call_id": "123", "output": "{}"},
        ]

        data = config.transform_responses_api_request(
            model="openai/gpt-5.2",
            input=list_input,
            response_api_optional_request_params={},
            litellm_params={},
            headers={},
        )

        assert data["input"][0]["type"] == "function_call_output"

    def test_get_complete_url(self):
        """Correct endpoint URL"""
        config = PerplexityResponsesConfig()

        url = config.get_complete_url(api_base=None, litellm_params={})
        assert url == "https://api.perplexity.ai/v1/responses"

        custom_url = config.get_complete_url(
            api_base="https://custom.perplexity.ai",
            litellm_params={},
        )
        assert custom_url == "https://custom.perplexity.ai/v1/responses"

        url_with_slash = config.get_complete_url(
            api_base="https://api.perplexity.ai/",
            litellm_params={},
        )
        assert url_with_slash == "https://api.perplexity.ai/v1/responses"

    def test_perplexity_provider_config_registration(self):
        """Test that Perplexity provider returns PerplexityResponsesConfig"""
        config = ProviderConfigManager.get_provider_responses_api_config(
            model="perplexity/openai/gpt-5.2",
            provider=LlmProviders.PERPLEXITY,
        )

        assert config is not None
        assert isinstance(config, PerplexityResponsesConfig)
        assert config.custom_llm_provider == LlmProviders.PERPLEXITY

    def test_failed_status_raises_exception(self):
        """Perplexity HTTP 200 with status:'failed' must raise BaseLLMException"""
        config = PerplexityResponsesConfig()

        failed_body = {
            "status": "failed",
            "error": {"message": "Model quota exceeded"},
        }

        raw_response = httpx.Response(
            status_code=200,
            json=failed_body,
            request=httpx.Request("POST", "https://api.perplexity.ai/v1/responses"),
        )

        logging_obj = LiteLLMLoggingObj(
            model="perplexity/openai/gpt-5.2",
            messages=[],
            stream=False,
            call_type="responses",
            start_time=None,
            litellm_call_id="test",
            function_id="test",
        )

        with pytest.raises(BaseLLMException) as exc_info:
            config.transform_response_api_response(
                model="perplexity/openai/gpt-5.2",
                raw_response=raw_response,
                logging_obj=logging_obj,
            )

        assert "Model quota exceeded" in str(exc_info.value.message)

    def test_successful_response_passes_through(self):
        """Normal completed response delegates to base OpenAI handler"""
        config = PerplexityResponsesConfig()

        success_body = {
            "id": "resp_123",
            "object": "response",
            "created_at": 1700000000,
            "status": "completed",
            "model": "openai/gpt-5.2",
            "output": [
                {
                    "type": "message",
                    "id": "msg_123",
                    "role": "assistant",
                    "status": "completed",
                    "content": [
                        {"type": "output_text", "text": "Hello!", "annotations": []}
                    ],
                }
            ],
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
                "total_tokens": 15,
            },
        }

        raw_response = httpx.Response(
            status_code=200,
            json=success_body,
            request=httpx.Request("POST", "https://api.perplexity.ai/v1/responses"),
        )

        logging_obj = LiteLLMLoggingObj(
            model="perplexity/openai/gpt-5.2",
            messages=[],
            stream=False,
            call_type="responses",
            start_time=None,
            litellm_call_id="test",
            function_id="test",
        )

        response = config.transform_response_api_response(
            model="perplexity/openai/gpt-5.2",
            raw_response=raw_response,
            logging_obj=logging_obj,
        )

        assert response.id == "resp_123"
        assert response.status == "completed"

    def test_streaming_cost_dict_to_float_via_validator(self):
        """Cost dict in a streaming response.completed chunk is converted to float
        end-to-end through transform_streaming_response via pydantic's recursive
        construction of ResponsesAPIResponse → ResponseAPIUsage.parse_cost."""
        config = PerplexityResponsesConfig()

        completed_chunk = {
            "type": "response.completed",
            "response": {
                "id": "resp_streaming_123",
                "object": "response",
                "created_at": 1700000000,
                "status": "completed",
                "model": "openai/gpt-5.2",
                "output": [
                    {
                        "type": "message",
                        "id": "msg_123",
                        "role": "assistant",
                        "status": "completed",
                        "content": [
                            {"type": "output_text", "text": "Hello!", "annotations": []}
                        ],
                    }
                ],
                "usage": {
                    "input_tokens": 100,
                    "output_tokens": 200,
                    "total_tokens": 300,
                    "cost": {
                        "currency": "USD",
                        "input_cost": 0.0001,
                        "output_cost": 0.0002,
                        "total_cost": 0.0003,
                    },
                },
            },
        }

        logging_obj = LiteLLMLoggingObj(
            model="perplexity/openai/gpt-5.2",
            messages=[],
            stream=True,
            call_type="responses",
            start_time=None,
            litellm_call_id="test",
            function_id="test",
        )

        result = config.transform_streaming_response(
            model="perplexity/openai/gpt-5.2",
            parsed_chunk=completed_chunk,
            logging_obj=logging_obj,
        )

        assert result.type == "response.completed"
        assert result.response.usage.cost == 0.0003
        assert isinstance(result.response.usage.cost, float)
