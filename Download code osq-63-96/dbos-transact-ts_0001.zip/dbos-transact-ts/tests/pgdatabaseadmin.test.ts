import { Client } from 'pg';
import { PostgreSqlContainer, type StartedPostgreSqlContainer } from '@testcontainers/postgresql';
import net from 'net';

import { deriveDatabaseUrl, dropPGDatabase, ensurePGDatabase, maskDatabaseUrl } from '../src/database_utils';
import { spawn } from 'child_process';
import { DBOS } from '../src';

// Test routine to see if psql can contact container
async function execHostPsql(
  container: StartedPostgreSqlContainer,
  sql: string,
  opts?: {
    db?: string;
    user?: string;
    psqlPath?: string;
    sslmode?: 'disable' | 'prefer' | 'require' | 'verify-ca' | 'verify-full';
  },
): Promise<{ exitCode: number; stdout: string; stderr: string; args: string[] }> {
  const host = container.getHost();
  const port = container.getPort();
  const db = opts?.db ?? container.getDatabase();
  const user = opts?.user ?? container.getUsername();
  const sslmode = opts?.sslmode ?? 'disable'; // local PG images don’t use TLS

  const args = [
    '-h',
    host,
    '-p',
    String(port),
    '-U',
    user,
    '-d',
    db,
    '-v',
    'ON_ERROR_STOP=1',
    '-tA', // tuples-only, unaligned
    '-w', // never prompt for password
    '-c',
    sql,
  ];
  const env = { ...process.env, PGPASSWORD: container.getPassword(), PGSSLMODE: sslmode };

  const cmd = opts?.psqlPath ?? 'psql';

  return await new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { env });
    let stdout = '',
      stderr = '';
    child.stdout.on('data', (d) => (stdout += String(d)));
    child.stderr.on('data', (d) => (stderr += String(d)));
    child.on('error', reject);
    child.on('close', (code) => resolve({ exitCode: code ?? -1, stdout, stderr, args }));
  });
}

// Try direct within container
async function execPsqlInContainer(container: StartedPostgreSqlContainer, sql?: string) {
  const res1 = await container.exec([
    'psql',
    '-v',
    'ON_ERROR_STOP=1',
    '-U',
    container.getUsername(),
    '-d',
    container.getDatabase(),
    '-tA',
    '-w',
    '-c',
    sql ?? 'SELECT 1;',
  ]);
  return res1.stdout;
}

async function tryTCPConnection(container: StartedPostgreSqlContainer) {
  await new Promise<void>((resolve, reject) => {
    const s = net.createConnection({ host: container.getHost(), port: container.getPort() });
    s.once('connect', () => {
      s.end();
      resolve();
    });
    s.once('error', reject);
  });
}

function makePGConnStr(
  username: string,
  password: string,
  host: string,
  port: string | number,
  database: string,
  timeout: number,
) {
  return `postgresql://${username}:${password}@${host}:${port}/${database}?connect_timeout=${timeout}`;
}

async function databaseExists(adminUrl: string, dbName: string): Promise<boolean> {
  const client = new Client({ connectionString: adminUrl });
  // An 'error' event with no listener would take down the jest worker.
  client.on('error', () => {});
  try {
    await client.connect();
    const { rowCount } = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
    return rowCount === 1;
  } finally {
    await client.end().catch(() => {});
  }
}

// A logger that discards everything, for calls whose output no assertion depends on.
const silentLogger = { info: () => {}, warn: () => {} };
const silentDropLogger = { warn: () => {} };

// ensurePGDatabase reports failures only through its logger, so negative tests assert on what it logged.
function collectingLogger() {
  const lines: string[] = [];
  const record = (m: string) => {
    lines.push(m);
  };
  return { lines, info: record, warn: record };
}

describe('PG16 drop/create e2e', () => {
  let testShouldRun = false;

  beforeAll(async () => {
    if (!process.env.RUN_PGDATABASE_ADMIN_TEST) return;

    let container: StartedPostgreSqlContainer | undefined = undefined;
    try {
      container = await new PostgreSqlContainer('postgres:16')
        .withUsername('dbos')
        .withPassword('dbos')
        .withDatabase('foobar')
        .start();

      // Enable test container logs for debugging
      if (false) {
        const stream = await container!.logs();
        stream
          .on('data', (line: string) => console.log('[pg]', line.toString()))
          .on('err', (line: string) => console.error('[pg-err]', line.toString()));
      }

      // Check that the container is configured and can execute to the DB
      const s1 = await execPsqlInContainer(container);
      if (s1.trim() !== '1') throw new Error(`Unable to 'SELECT 1' in container; got ${s1}`);

      // Try plain TCP to make sure networking works
      await tryTCPConnection(container);

      // Try psql from host
      const { exitCode, stdout, stderr, args } = await execHostPsql(container, 'SELECT 1');
      if (exitCode !== 0 || stdout.trim() !== '1')
        throw new Error(`Could not use psql to reach container: ${stderr}, ${JSON.stringify(args)}`);

      // Try a PG connection
      const adminClient = new Client({
        connectionString: container.getConnectionUri(),
      });
      try {
        await adminClient.connect();
        await adminClient.query('SELECT 1;');
      } finally {
        try {
          await adminClient.end();
        } catch (e2) {}
      }

      testShouldRun = true;
    } catch (e) {
      console.error(`Unable to run PG container; skipping tests: ${e as Error}`);
    }

    if (container) {
      await container.stop();
    }
  }, 120_000);

  afterAll(async () => {}, 120_000);

  test('url masking', () => {
    expect(maskDatabaseUrl('postgres://postgres:secret@localhost:5432/dbostest?connect_timeout=7')).toBe(
      'postgres://postgres:***@localhost:5432/dbostest?connect_timeout=7',
    );
  });

  test('using url plus database', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('notpostgres')
      .start();

    try {
      const adminUri = container.getConnectionUri();

      // Creation is idempotent: the second call must find the database and not attempt another CREATE
      const dbName = 'idle_db1';
      const firstRun = collectingLogger();
      await ensurePGDatabase(deriveDatabaseUrl(adminUri, dbName), firstRun);
      expect(await databaseExists(adminUri, dbName)).toBe(true);
      expect(firstRun.lines).toEqual([`Created database ${dbName}`]);

      const secondRun = collectingLogger();
      await ensurePGDatabase(deriveDatabaseUrl(adminUri, dbName), secondRun);
      expect(await databaseExists(adminUri, dbName)).toBe(true);
      expect(secondRun.lines).toEqual([]);

      // Dropping is idempotent
      await dropPGDatabase(deriveDatabaseUrl(adminUri, dbName), silentDropLogger);
      expect(await databaseExists(adminUri, dbName)).toBe(false);
      await dropPGDatabase(deriveDatabaseUrl(adminUri, dbName), silentDropLogger);
      expect(await databaseExists(adminUri, dbName)).toBe(false);

      // A name needing percent-encoding in the URL must round-trip back to the literal name
      const dbNameYuck = `do"not;name-your$db.this!'`;
      await ensurePGDatabase(deriveDatabaseUrl(adminUri, dbNameYuck), silentLogger);
      expect(await databaseExists(adminUri, dbNameYuck)).toBe(true);
      await dropPGDatabase(deriveDatabaseUrl(adminUri, dbNameYuck), silentDropLogger);
      expect(await databaseExists(adminUri, dbNameYuck)).toBe(false);
    } finally {
      await container.stop();
    }
  }, 120_000);

  test('using url with postgres fallback', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('postgres')
      .start();

    try {
      // Creation via the target URL (derives 'postgres' as the admin database)
      const dbName = 'idle_db2';
      const target = deriveDatabaseUrl(container.getConnectionUri(), dbName);
      await ensurePGDatabase(target, silentLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(true);
      await ensurePGDatabase(target, silentLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(true);

      // Drop via the target URL (derives 'postgres' as the admin database)
      await dropPGDatabase(target, silentDropLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(false);
      await dropPGDatabase(target, silentDropLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(false);
    } finally {
      await container.stop();
    }
  }, 120_000);

  test('ensure drop db negative', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('foobar')
      .start();

    try {
      // This version of it is using a bogus URL but is somewhat valid
      const targetWithPerms = makePGConnStr(
        'myuser',
        'mypassword',
        container.getHost(),
        container.getPort(),
        'mydatabase',
        1000,
      );
      const target = deriveDatabaseUrl(targetWithPerms, 'never_existed');
      await expect(dropPGDatabase(target, silentDropLogger)).rejects.toThrow(/password authentication failed/i);

      const ensure1 = collectingLogger();
      await ensurePGDatabase(target, ensure1);
      expect(ensure1.lines.some((s) => s.includes('Could not verify the existence of database never_existed'))).toBe(
        true,
      );
      expect(ensure1.lines.some((s) => s.toLowerCase().includes('password authentication failed'))).toBe(true);

      // An unreachable server surfaces the connection error
      const bogusServer = makePGConnStr('myuser', 'mypassword', container.getHost(), 59999, 'mydatabase', 1000);
      await expect(dropPGDatabase(bogusServer, silentDropLogger)).rejects.toThrow(/ECONNREFUSED/);
      const ensure3 = collectingLogger();
      await ensurePGDatabase(bogusServer, ensure3);
      expect(ensure3.lines.some((s) => s.includes('Could not verify the existence of database mydatabase'))).toBe(true);

      // Dropping a database that never existed is a no-op, not an error
      await expect(
        dropPGDatabase(deriveDatabaseUrl(container.getConnectionUri(), 'never_existed'), silentDropLogger),
      ).resolves.toBeUndefined();
    } finally {
      await container.stop();
    }
  }, 120_000);

  test('drop a busy DB (new PG uses WITH (FORCE))', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('foobar')
      .start();

    try {
      const dbName = 'busy_db';
      await ensurePGDatabase(deriveDatabaseUrl(container.getConnectionUri(), dbName), silentLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(true);

      // open a blocker connection
      const busy = new Client({ connectionString: deriveDatabaseUrl(container.getConnectionUri(), dbName) });
      await busy.connect();
      busy.on('error', (err: { code?: string; message?: string }) => {
        if (err?.code === '57P01' || /terminat/i.test(err?.message ?? '')) return;
        if (err?.code === '08006' || err?.code === '08003') return;
        console.error('busy client unexpected error:', err);
      });
      await busy.query('BEGIN'); // keep a transaction open

      // the dropper should terminate our backend and succeed
      await dropPGDatabase(deriveDatabaseUrl(container.getConnectionUri(), dbName), silentDropLogger);

      // cleanup if still connected (should be terminated by drop)
      try {
        await busy.end();
      } catch {}

      const adminClient = new Client({ connectionString: container.getConnectionUri() });
      await adminClient.connect();
      const check = await adminClient.query<{ one: number }>('SELECT 1 as one FROM pg_database WHERE datname=$1', [
        dbName,
      ]);
      expect(check.rowCount).toBe(0);
      try {
        await adminClient.end();
      } catch {}
    } finally {
      await container.stop();
    }
  }, 120_000);

  test('helpful failure when admin connect not possible', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('foobar')
      .start();

    try {
      const adminClient = new Client({ connectionString: container.getConnectionUri() });
      await adminClient.connect();

      // Create a non-superuser owner + DB
      await adminClient.query(`CREATE ROLE appuser LOGIN PASSWORD 's3cret'`);
      const noAdminDb = 'blocked_admin';
      await adminClient.query(`CREATE DATABASE "${noAdminDb}" OWNER appuser`);

      // revoke CONNECT to /postgres for appuser
      await adminClient.query(`REVOKE CONNECT ON DATABASE postgres FROM PUBLIC`);
      await adminClient.query(`REVOKE CONNECT ON DATABASE postgres FROM appuser`);

      // Try creating (2 ways to fail, OK if already exists)
      const userDb = makePGConnStr('appuser', 's3cret', container.getHost(), container.getPort(), noAdminDb, 1000);
      const createUserDb = deriveDatabaseUrl(userDb, 'cant_create');
      const ensure1 = collectingLogger();
      await ensurePGDatabase(createUserDb, ensure1);
      expect(ensure1.lines.some((s) => s.includes('permission denied for database "postgres"'))).toBe(true);
      expect(await databaseExists(container.getConnectionUri(), 'cant_create')).toBe(false);

      // A restricted role whose database already exists: warn, never throw, and leave the database alone
      const ensure2 = collectingLogger();
      await expect(ensurePGDatabase(userDb, ensure2)).resolves.toBeUndefined();
      expect(ensure2.lines.some((s) => s.includes('permission denied for database "postgres"'))).toBe(true);
      expect(await databaseExists(container.getConnectionUri(), noAdminDb)).toBe(true);

      // Dropping needs the same admin connection, so it fails the same way
      await expect(dropPGDatabase(createUserDb, silentDropLogger)).rejects.toThrow(
        /permission denied for database "postgres"/,
      );

      // Create a database appuser does not own
      const dropUserDb = deriveDatabaseUrl(userDb, 'cant_drop');
      await ensurePGDatabase(deriveDatabaseUrl(container.getConnectionUri(), 'cant_drop'), silentLogger);
      expect(await databaseExists(container.getConnectionUri(), 'cant_drop')).toBe(true);

      // With admin access restored, the DROP itself reports the privilege failure
      await adminClient.query(`GRANT CONNECT ON DATABASE postgres TO appuser`);
      await expect(dropPGDatabase(dropUserDb, silentDropLogger)).rejects.toThrow(/must be owner/);
      expect(await databaseExists(container.getConnectionUri(), 'cant_drop')).toBe(true);

      try {
        await adminClient.end();
      } catch {}
    } finally {
      await container.stop();
    }
  }, 120_000);

  test('launch DBOS with weird sysdb name', async () => {
    if (!testShouldRun) return;

    const container = await new PostgreSqlContainer('postgres:16')
      .withUsername('dbos')
      .withPassword('dbos')
      .withDatabase('foobar')
      .start();

    try {
      const dbName = `"db".'v1'-a$6`;
      const sysDbUrl = makePGConnStr(
        container.getUsername(),
        container.getPassword(),
        container.getHost(),
        container.getPort(),
        dbName,
        3000,
      );

      // The name is percent-encoded in the URL; it must be created under the literal name
      await ensurePGDatabase(sysDbUrl, silentLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(true);

      DBOS.setConfig({ name: 'weird-sysdb-test', systemDatabaseUrl: sysDbUrl });

      const testWorkflow = DBOS.registerWorkflow(
        async (testValue: string) => {
          const step1 = await DBOS.runStep(async () => {
            return Promise.resolve('1');
          });
          const step2 = await DBOS.runStep(async () => {
            return Promise.resolve('2');
          });
          return testValue + step1 + step2;
        },
        { name: 'weird-sysdb-test-workflow' },
      );

      await DBOS.launch();
      try {
        const res = await testWorkflow('a');
        expect(res).toBe('a12');
      } finally {
        await DBOS.shutdown();
      }
      await dropPGDatabase(sysDbUrl, silentDropLogger);
      expect(await databaseExists(container.getConnectionUri(), dbName)).toBe(false);
    } finally {
      await container.stop();
    }
  }, 120_000);
});
