-- This file should undo anything in `up.sql`
ALTER TABLE user_table
DROP COLUMN auth_type;