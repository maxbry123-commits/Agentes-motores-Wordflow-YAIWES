# Dependency release evidence

Generated for `v2026.6.5-beta.6` at `1514dc740a2e74c47e87cb7436a88a412044a3bd`.

## Summary

- npm advisory vulnerability hard blockers: 0
- npm advisory vulnerability total findings: 4
- Transitive manifest reported risk signals: 1834
- Workspace-policy excluded transitive signals: 0
- Transitive manifest metadata failures: 2
- Lockfile packages inspected for ownership/install surface: 1231
- Packages with install-time or platform-specific behavior: 251
- Dependency change baseline: `v2026.6.5-beta.5`
- Dependency file changes: 166
- Resolved package changes: +0 -0 changed 0

## Reports

- `dependency-vulnerability-gate.md`
- `transitive-manifest-risk-report.md`
- `dependency-ownership-surface-report.md`
- `dependency-changes-report.md`
