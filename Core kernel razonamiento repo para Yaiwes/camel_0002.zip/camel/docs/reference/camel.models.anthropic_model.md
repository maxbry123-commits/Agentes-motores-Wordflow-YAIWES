<a id="camel.models.anthropic_model"></a>

<a id="camel.models.anthropic_model.strip_trailing_whitespace_from_messages"></a>

## strip_trailing_whitespace_from_messages

```python
def strip_trailing_whitespace_from_messages(messages: List[OpenAIMessage]):
```

Strip trailing whitespace from all message contents in a list of
messages. This is necessary because the Anthropic API doesn't allow
trailing whitespace in message content.

**Parameters:**

- **messages** (List[OpenAIMessage]): List of messages to process

**Returns:**

  List[OpenAIMessage]: The processed messages with trailing whitespace
removed

<a id="camel.models.anthropic_model.AnthropicModel"></a>

## AnthropicModel

```python
class AnthropicModel(BaseModelBackend):
```

Anthropic API in a unified BaseModelBackend interface.

**Parameters:**

- **model_type** (Union[ModelType, str]): Model for which a backend is created, one of CLAUDE_* series.
- **model_config_dict** (Optional[Dict[str, Any]], optional): A dictionary that will be fed into Anthropic API. If :obj:`None`, :obj:`AnthropicConfig().as_dict()` will be used. (default: :obj:`None`)
- **api_key** (Optional[str], optional): The API key for authenticating with the Anthropic service. (default: :obj:`None`)
- **url** (Optional[str], optional): The url to the Anthropic service. (default: :obj:`None`)
- **token_counter** (Optional[BaseTokenCounter], optional): Token counter to use for the model. If not provided, :obj:`AnthropicTokenCounter` will be used. (default: :obj:`None`)
- **timeout** (Optional[float], optional): The timeout value in seconds for API calls. If not provided, will fall back to the MODEL_TIMEOUT environment variable or default to 180 seconds. (default: :obj:`None`)
- **max_retries** (int, optional): Maximum number of retries for API calls. (default: :obj:`3`)
- **client** (Optional[Any], optional): A custom synchronous Anthropic client instance. If provided, this client will be used instead of creating a new one. (default: :obj:`None`)
- **async_client** (Optional[Any], optional): A custom asynchronous Anthropic client instance. If provided, this client will be used instead of creating a new one. (default: :obj:`None`)
- **kwargs** (Any): Additional arguments to pass to the client initialization.

<a id="camel.models.anthropic_model.AnthropicModel.__init__"></a>

### __init__

```python
def __init__(
    self,
    model_type: Union[ModelType, str],
    model_config_dict: Optional[Dict[str, Any]] = None,
    api_key: Optional[str] = None,
    url: Optional[str] = None,
    token_counter: Optional[BaseTokenCounter] = None,
    timeout: Optional[float] = None,
    max_retries: int = 3,
    client: Optional[Any] = None,
    async_client: Optional[Any] = None,
    **kwargs: Any
):
```

<a id="camel.models.anthropic_model.AnthropicModel.token_counter"></a>

### token_counter

```python
def token_counter(self):
```

**Returns:**

  AnthropicTokenCounter: The token counter following the model's
tokenization style.

<a id="camel.models.anthropic_model.AnthropicModel._convert_openai_to_anthropic_messages"></a>

### _convert_openai_to_anthropic_messages

```python
def _convert_openai_to_anthropic_messages(self, messages: List[OpenAIMessage]):
```

Convert OpenAI format messages to Anthropic format.

**Parameters:**

- **messages** (List[OpenAIMessage]): Messages in OpenAI format.

**Returns:**

  tuple[Optional[str], List[Dict[str, Any]]]: A tuple containing
the system message (if any) and the list of messages in
Anthropic format.

<a id="camel.models.anthropic_model.AnthropicModel._extract_usage"></a>

### _extract_usage

```python
def _extract_usage(usage_obj: Any):
```

Extract usage information from an Anthropic usage object.

<a id="camel.models.anthropic_model.AnthropicModel._convert_anthropic_to_openai_response"></a>

### _convert_anthropic_to_openai_response

```python
def _convert_anthropic_to_openai_response(self, response: Any, model: str):
```

Convert Anthropic API response to OpenAI ChatCompletion format.

**Parameters:**

- **response**: The response object from Anthropic API.
- **model** (str): The model name.

**Returns:**

  ChatCompletion: Response in OpenAI format.

<a id="camel.models.anthropic_model.AnthropicModel._convert_anthropic_stream_to_openai_chunk"></a>

### _convert_anthropic_stream_to_openai_chunk

```python
def _convert_anthropic_stream_to_openai_chunk(
    self,
    chunk: Any,
    model: str,
    tool_call_index: Dict[str, int],
    finish_reason_sent: bool = False
):
```

Convert Anthropic streaming chunk to OpenAI ChatCompletionChunk.

**Parameters:**

- **chunk**: The streaming chunk from Anthropic API.
- **model** (str): The model name.
- **tool_call_index** (Dict[str, int]): A mutable dict tracking tool call indices by their IDs, used to maintain consistent indexing across streaming chunks.

**Returns:**

  ChatCompletionChunk: Chunk in OpenAI format.

<a id="camel.models.anthropic_model.AnthropicModel._convert_openai_tools_to_anthropic"></a>

### _convert_openai_tools_to_anthropic

```python
def _convert_openai_tools_to_anthropic(self, tools: Optional[List[Dict[str, Any]]]):
```

Convert OpenAI tools format to Anthropic tools format.

**Parameters:**

- **tools** (Optional[List[Dict[str, Any]]]): Tools in OpenAI format.

**Returns:**

  Optional[List[Dict[str, Any]]]: Tools in Anthropic format.

<a id="camel.models.anthropic_model.AnthropicModel._run"></a>

### _run

```python
def _run(
    self,
    messages: List[OpenAIMessage],
    response_format: Optional[Type[BaseModel]] = None,
    tools: Optional[List[Dict[str, Any]]] = None
):
```

Runs inference of Anthropic chat completion.

**Parameters:**

- **messages** (List[OpenAIMessage]): Message list with the chat history in OpenAI API format.
- **response_format** (Optional[Type[BaseModel]]): The format of the response. (Not supported by Anthropic API directly)
- **tools** (Optional[List[Dict[str, Any]]]): The schema of the tools to use for the request.

**Returns:**

  Union[ChatCompletion, Stream[ChatCompletionChunk]]:
`ChatCompletion` in the non-stream mode, or
`Stream[ChatCompletionChunk]` in the stream mode.

<a id="camel.models.anthropic_model.AnthropicModel._wrap_anthropic_stream"></a>

### _wrap_anthropic_stream

```python
def _wrap_anthropic_stream(self, stream: Any, model: str):
```

Wrap Anthropic streaming response to OpenAI Stream format.

**Parameters:**

- **stream**: The streaming response from Anthropic API.
- **model** (str): The model name.

**Returns:**

  Stream[ChatCompletionChunk]: Stream in OpenAI format.

<a id="camel.models.anthropic_model.AnthropicModel._wrap_anthropic_async_stream"></a>

### _wrap_anthropic_async_stream

```python
def _wrap_anthropic_async_stream(self, stream: Any, model: str):
```

Wrap Anthropic async streaming response to OpenAI AsyncStream.

**Parameters:**

- **stream**: The async streaming response from Anthropic API.
- **model** (str): The model name.

**Returns:**

  AsyncStream[ChatCompletionChunk]: AsyncStream in OpenAI format.

<a id="camel.models.anthropic_model.AnthropicModel.stream"></a>

### stream

```python
def stream(self):
```

**Returns:**

  bool: Whether the model is in stream mode.
