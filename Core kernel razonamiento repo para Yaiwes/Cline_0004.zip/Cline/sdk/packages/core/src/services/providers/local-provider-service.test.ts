import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import * as LlmsModels from "@cline/llms";
import { CLINE_DEFAULT_MODEL_ID } from "@cline/shared";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
	FALLBACK_CLINE_RECOMMENDED_MODELS,
	getCachedClineRecommendedModels,
	resetClineRecommendedModelsCacheForTests,
} from "../llms/cline-recommended-models";
import { clearLiveModelsCatalogCache } from "../llms/provider-defaults";
import { ProviderSettingsManager } from "../storage/provider-settings-manager";
import {
	parseModelsFile,
	readModelsFile,
	registerCustomProvider,
	resolveModelsRegistryPath,
	toProviderModel,
} from "./local-provider-registry";
import {
	addLocalProvider,
	createConfiguredStreamingTranscriptionSession,
	deleteLocalProvider,
	getLocalProviderModels,
	isDedicatedTranscriptionModel,
	listLocalProviders,
	markLocalProviderEnabled,
	normalizeOAuthProvider,
	refreshProviderModelsFromSource,
	resolveLocalClineAuthToken,
	saveLocalProviderSettings,
	saveVoiceInputSettings,
	transcribeConfiguredVoiceInput,
	transcribeLocalAudio,
	updateLocalProvider,
} from "./local-provider-service";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeTempManager(): {
	manager: ProviderSettingsManager;
	cleanup: () => void;
} {
	const dir = mkdtempSync(
		path.join(os.tmpdir(), "local-provider-service-test-"),
	);
	const manager = new ProviderSettingsManager({
		filePath: path.join(dir, "providers.json"),
	});
	return {
		manager,
		cleanup: () => rmSync(dir, { recursive: true, force: true }),
	};
}

// ---------------------------------------------------------------------------
// Shared state reset
// ---------------------------------------------------------------------------

afterEach(() => {
	clearLiveModelsCatalogCache();
	resetClineRecommendedModelsCacheForTests();
	LlmsModels.resetRegistry();
	vi.restoreAllMocks();
	vi.unstubAllGlobals();
});

describe("models registry parsing", () => {
	it("accepts model entries that use the record key as the model id", async () => {
		const parsed = parseModelsFile({
			version: 1,
			providers: {
				"schema-provider": {
					provider: {
						name: "Schema Provider",
						baseUrl: "https://schema.example.invalid/v1",
						defaultModelId: "alpha",
						protocol: "openai-responses",
					},
					models: {
						alpha: {
							name: "Alpha",
							capabilities: ["reasoning"],
							inputPrice: 1.25,
							outputPrice: 3.5,
							cacheReadsPrice: 0.25,
							cacheWritesPrice: 1.5,
							temperature: 0.2,
						},
					},
				},
			},
		});

		const entry = parsed.providers["schema-provider"];
		expect(entry?.models?.alpha?.id).toBeUndefined();
		if (!entry) {
			throw new Error("expected parsed provider entry");
		}

		registerCustomProvider("schema-provider", entry);

		await expect(
			LlmsModels.getProvider("schema-provider"),
		).resolves.toMatchObject({
			id: "schema-provider",
			protocol: "openai-responses",
			client: "openai",
		});
		await expect(
			LlmsModels.getModelsForProvider("schema-provider"),
		).resolves.toMatchObject({
			alpha: {
				pricing: {
					input: 1.25,
					output: 3.5,
					cacheRead: 0.25,
					cacheWrite: 1.5,
				},
				temperature: 0.2,
			},
		});
	});

	it("drops invalid model numbers and lets explicit capability booleans win", async () => {
		const parsed = parseModelsFile({
			version: 1,
			providers: {
				"normalized-provider": {
					provider: {
						name: "Normalized Provider",
						baseUrl: "https://normalized.example.invalid/v1",
					},
					models: {
						alpha: {
							maxTokens: -1,
							contextWindow: Number.POSITIVE_INFINITY,
							maxInputTokens: 0,
							capabilities: ["images", "files", "reasoning", "tools"],
							supportsVision: false,
							supportsAttachments: false,
							supportsReasoning: false,
							inputPrice: Number.NaN,
							outputPrice: 2,
							cacheReadsPrice: -1,
							temperature: -1,
							apiFormat: "openai-responses",
						},
					},
				},
			},
		});

		const entry = parsed.providers["normalized-provider"];
		expect(entry?.models?.alpha).toEqual({
			capabilities: ["images", "files", "reasoning", "tools"],
			supportsVision: false,
			supportsAttachments: false,
			supportsReasoning: false,
			outputPrice: 2,
			apiFormat: "openai-responses",
		});
		if (!entry) {
			throw new Error("expected normalized provider entry");
		}

		registerCustomProvider("normalized-provider", entry);

		await expect(
			LlmsModels.getModelsForProvider("normalized-provider"),
		).resolves.toMatchObject({
			alpha: {
				capabilities: ["tools"],
				apiFormat: "openai-responses",
				pricing: { output: 2 },
			},
		});
		const model = (await LlmsModels.getModelsForProvider("normalized-provider"))
			.alpha;
		expect(model).not.toHaveProperty("maxTokens");
		expect(model).not.toHaveProperty("contextWindow");
		expect(model).not.toHaveProperty("maxInputTokens");
		expect(model).not.toHaveProperty("temperature");
	});

	it("seeds tool calling when capabilities are synthesized purely from boolean flags", async () => {
		const parsed = parseModelsFile({
			version: 1,
			providers: {
				"boolean-only-provider": {
					provider: {
						name: "Boolean Only Provider",
						baseUrl: "https://boolean-only.example.invalid/v1",
					},
					models: {
						// No explicit capabilities list: the entry only carries the
						// boolean convenience flag. The synthesized list must include
						// "tools", otherwise a non-empty list without it reads as an
						// authoritative denial to modelSupportsToolCalling (#13463).
						reasoner: {
							contextWindow: 16000,
							supportsReasoning: true,
						},
						// No flags at all: the capability list must stay absent so the
						// runtime keeps its fail-open behavior.
						bare: {
							contextWindow: 16000,
						},
						// Explicit partial list on a non-catalog model: nothing can
						// author a "no tools" stored entry (the VS Code legacy
						// migration writes exactly this shape), so "tools" must be
						// seeded here too.
						"partial-list": {
							capabilities: ["prompt-cache"],
						},
						// Non-language models must not gain a tools claim.
						"image-gen": {
							operation: "image-generation",
							capabilities: ["images"],
						},
					},
				},
			},
		});

		const entry = parsed.providers["boolean-only-provider"];
		if (!entry) {
			throw new Error("expected boolean-only provider entry");
		}

		registerCustomProvider("boolean-only-provider", entry);

		const models = await LlmsModels.getModelsForProvider(
			"boolean-only-provider",
		);
		expect(models.reasoner?.capabilities).toEqual(
			expect.arrayContaining(["reasoning", "tools"]),
		);
		expect(models.bare).not.toHaveProperty("capabilities");
		expect(models["partial-list"]?.capabilities).toEqual(
			expect.arrayContaining(["prompt-cache", "tools"]),
		);
		expect(models["image-gen"]?.capabilities).not.toContain("tools");
	});

	it("keeps generated tool support when stale OpenCode Go metadata shadows a catalog model", async () => {
		const generatedModel =
			LlmsModels.getGeneratedModelsForProvider("opencode-go")["glm-5.3"];
		expect(generatedModel?.capabilities).toContain("tools");

		const parsed = parseModelsFile({
			version: 1,
			providers: {
				"opencode-go": {
					models: {
						"glm-5.3": {
							// Older clients persisted only capability projections they
							// understood. Once v4.1.11 began gating tools, this partial
							// list shadowed the catalog's "tools" capability and disabled
							// every edit/read tool for the model.
							capabilities: ["reasoning", "prompt-cache"],
						},
					},
				},
			},
		});

		const entry = parsed.providers["opencode-go"];
		if (!entry) {
			throw new Error("expected OpenCode Go provider entry");
		}

		registerCustomProvider("opencode-go", entry);

		const model = (await LlmsModels.getModelsForProvider("opencode-go"))[
			"glm-5.3"
		];
		expect(model?.capabilities).toEqual(
			expect.arrayContaining([
				"tools",
				"reasoning",
				"prompt-cache",
				"structured_output",
			]),
		);
	});

	it("skips malformed provider entries while preserving valid providers", () => {
		expect(
			parseModelsFile({
				version: 1,
				providers: {
					valid: {
						provider: {
							name: "Valid",
							baseUrl: "https://valid.example.invalid/v1",
						},
						models: {
							alpha: {
								name: "Alpha",
							},
						},
					},
					broken: {
						provider: {
							name: "Broken",
							baseUrl: 42,
						},
					},
				},
			}),
		).toEqual({
			version: 1,
			providers: {
				valid: {
					provider: {
						name: "Valid",
						baseUrl: "https://valid.example.invalid/v1",
					},
					models: {
						alpha: {
							name: "Alpha",
						},
					},
				},
			},
		});
	});

	it("falls back to an empty registry when the file shape is malformed", () => {
		expect(
			parseModelsFile({
				version: 1,
				providers: [],
			}),
		).toEqual({ version: 1, providers: {} });
	});
});

// ===========================================================================
// extractModelIdsFromPayload is tested indirectly via addLocalProvider
// ===========================================================================

describe("addLocalProvider – model ID parsing via modelsSourceUrl", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("parses a flat array payload from modelsSourceUrl", async () => {
		const mockFetch = vi.fn().mockResolvedValue({
			ok: true,
			json: async () => ["alpha", "beta", "gamma"],
		});
		vi.stubGlobal("fetch", mockFetch);

		const result = await addLocalProvider(manager, {
			providerId: "flat-array-provider",
			name: "Flat Array",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/models",
		});

		expect(result.modelsCount).toBe(3);
		const { models } = await getLocalProviderModels("flat-array-provider");
		expect(models.map((m) => m.id).sort()).toEqual(["alpha", "beta", "gamma"]);
	});

	it("parses a { data: [...] } payload from modelsSourceUrl", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ({ data: [{ id: "model-x" }, { id: "model-y" }] }),
			}),
		);

		await addLocalProvider(manager, {
			providerId: "data-array-provider",
			name: "Data Array",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/models",
		});

		const { models } = await getLocalProviderModels("data-array-provider");
		expect(models.map((m) => m.id).sort()).toEqual(["model-x", "model-y"]);
	});

	it("parses Ollama-style { models: [{ name }] } payloads", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ({
					models: [{ name: "llama3.1" }, { model: "qwen3:8b" }],
				}),
			}),
		);

		await addLocalProvider(manager, {
			providerId: "ollama-shaped-provider",
			name: "Ollama Shaped",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/api/tags",
		});

		const { models } = await getLocalProviderModels("ollama-shaped-provider");
		expect(models.map((m) => m.id).sort()).toEqual(["llama3.1", "qwen3:8b"]);
	});

	it("merges live Cline models into the registered catalog", async () => {
		const liveModelId = "vendor/live-cline-model";
		const fetchMock = vi.fn(async (url: string) => {
			if (url === "https://models.dev/api.json") {
				return new Response(
					JSON.stringify({
						openrouter: {
							models: {
								[liveModelId]: {
									name: "Live Cline Model",
									tool_call: true,
									reasoning: true,
									limit: {
										context: 256_000,
										input: 200_000,
										output: 32_000,
									},
								},
							},
						},
					}),
					{
						status: 200,
						headers: { "content-type": "application/json" },
					},
				);
			}

			return new Response(
				JSON.stringify({
					recommended: [
						{
							id: liveModelId,
							name: liveModelId,
							description: "Fresh from the live catalog",
							tags: ["NEW"],
						},
					],
					free: [],
					clinePass: [],
				}),
				{
					status: 200,
					headers: { "content-type": "application/json" },
				},
			);
		});
		vi.stubGlobal("fetch", fetchMock);

		const { models } = await getLocalProviderModels("cline");

		// models.dev and the recommended feed populate the live catalog; the
		// recommended feed is fetched once more for the featured-tier overlay.
		expect(fetchMock).toHaveBeenCalledTimes(3);
		expect(models.find((model) => model.id === liveModelId)).toMatchObject({
			id: liveModelId,
			name: "Live Cline Model",
			supportsReasoning: true,
			description: "Fresh from the live catalog",
			featured: { tier: "recommended", rank: 0, tags: ["NEW"] },
		});
	});

	it("uses only live ClinePass models when live models are found", async () => {
		const fetchMock = vi.fn(async (url: string) => {
			if (url === "https://models.dev/api.json") {
				return new Response(
					JSON.stringify({
						openrouter: {
							models: {
								"vendor/live-pass-model": {
									name: "Live Pass Model",
									tool_call: true,
									reasoning: true,
									limit: { context: 256_000, input: 200_000, output: 32_000 },
								},
								"vendor/live-free-model": {
									name: "Live Free Model",
									tool_call: true,
									reasoning: true,
									limit: { context: 512_000, input: 400_000, output: 64_000 },
								},
							},
						},
					}),
					{
						status: 200,
						headers: { "content-type": "application/json" },
					},
				);
			}

			return new Response(
				JSON.stringify({
					clinePass: [
						{
							id: "cline-pass/live-pass-model",
							name: "vendor/live-pass-model",
						},
					],
					free: [{ id: "cline-free/live-free-model" }],
				}),
				{
					status: 200,
					headers: { "content-type": "application/json" },
				},
			);
		});
		vi.stubGlobal("fetch", fetchMock);

		const { models } = await getLocalProviderModels("cline-pass");

		// models.dev, the recommended-models feed via the live catalog, and
		// the recommended-models feed again for the featured-tier overlay
		// (separately cached; both caches are cold here).
		expect(fetchMock).toHaveBeenCalledTimes(3);
		expect(models.map((model) => model.id)).toEqual(
			expect.arrayContaining([
				"cline-pass/live-pass-model",
				"cline-free/live-free-model",
			]),
		);
		expect(
			models.find((model) => model.id === "cline-pass/live-pass-model"),
		).toMatchObject({
			id: "cline-pass/live-pass-model",
			name: "Live Pass Model",
			supportsReasoning: true,
		});
		expect(
			models.find((model) => model.id === "cline-free/live-free-model"),
		).toMatchObject({
			id: "cline-free/live-free-model",
			name: "Live Free Model (free)",
			supportsReasoning: true,
		});
	});

	it("falls back to generated ClinePass models when no live ClinePass models are found", async () => {
		const fetchMock = vi.fn(async (url: string) => {
			if (url === "https://models.dev/api.json") {
				return new Response(
					JSON.stringify({
						openrouter: {
							models: {
								"vendor/live-openrouter-model": {
									name: "Live OpenRouter Model",
									tool_call: true,
								},
							},
						},
					}),
					{
						status: 200,
						headers: { "content-type": "application/json" },
					},
				);
			}

			return new Response(JSON.stringify({ clinePass: [] }), {
				status: 200,
				headers: { "content-type": "application/json" },
			});
		});
		vi.stubGlobal("fetch", fetchMock);

		const { models } = await getLocalProviderModels("cline-pass");

		// models.dev, the recommended-models feed via the live catalog, and
		// the recommended-models feed again for the featured-tier overlay
		// (separately cached; both caches are cold here).
		expect(fetchMock).toHaveBeenCalledTimes(3);
		expect(models.map((model) => model.id)).toContain(
			"cline-pass/mimo-v2.5-pro",
		);
		expect(models.map((model) => model.id)).not.toContain(
			"vendor/live-openrouter-model",
		);
	});

	it("parses a { models: { id1: {}, id2: {} } } object-keyed payload", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ({ models: { "key-a": {}, "key-b": {} } }),
			}),
		);

		await addLocalProvider(manager, {
			providerId: "obj-keys-provider",
			name: "Object Keys",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/models",
		});

		const { models } = await getLocalProviderModels("obj-keys-provider");
		expect(models.map((m) => m.id).sort()).toEqual(["key-a", "key-b"]);
	});

	it("parses a { providers: { <id>: { models: [...] } } } nested payload", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ({
					providers: {
						"nested-provider": { models: ["nested-a", "nested-b"] },
					},
				}),
			}),
		);

		await addLocalProvider(manager, {
			providerId: "nested-provider",
			name: "Nested Provider",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/models",
		});

		const { models } = await getLocalProviderModels("nested-provider");
		expect(models.map((m) => m.id).sort()).toEqual(["nested-a", "nested-b"]);
	});

	it("merges manually specified models with fetched models and deduplicates", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ["fetched-1", "fetched-2", "manual-1"],
			}),
		);

		const result = await addLocalProvider(manager, {
			providerId: "merged-provider",
			name: "Merged",
			baseUrl: "https://example.invalid/v1",
			models: ["manual-1", "manual-2"],
			modelsSourceUrl: "https://example.invalid/models",
		});

		// manual-1, manual-2, fetched-1, fetched-2, manual-1 → Set → 4
		expect(result.modelsCount).toBe(4);
		const { models } = await getLocalProviderModels("merged-provider");
		const ids = models.map((m) => m.id).sort();
		expect(ids).toEqual(["fetched-1", "fetched-2", "manual-1", "manual-2"]);
	});

	it("throws when fetch returns non-OK status", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: false,
				status: 404,
			}),
		);

		await expect(
			addLocalProvider(manager, {
				providerId: "fail-fetch-provider",
				name: "Fail",
				baseUrl: "https://example.invalid/v1",
				models: [],
				modelsSourceUrl: "https://example.invalid/models",
			}),
		).rejects.toThrow("HTTP 404");
	});

	it("ignores empty string entries in array payloads", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ["good-model", "", "  "],
			}),
		);

		await addLocalProvider(manager, {
			providerId: "empty-strings-provider",
			name: "Empty Strings",
			baseUrl: "https://example.invalid/v1",
			models: [],
			modelsSourceUrl: "https://example.invalid/models",
		});

		const { models } = await getLocalProviderModels("empty-strings-provider");
		expect(models.map((m) => m.id)).toEqual(["good-model"]);
	});

	it("ignores non-array, non-object payload shapes and falls back to manual models", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => "just a string",
			}),
		);

		await addLocalProvider(manager, {
			providerId: "fallback-provider",
			name: "Fallback",
			baseUrl: "https://example.invalid/v1",
			models: ["fallback-model"],
			modelsSourceUrl: "https://example.invalid/models",
		});

		const { models } = await getLocalProviderModels("fallback-provider");
		expect(models.map((m) => m.id)).toEqual(["fallback-model"]);
	});
});

// ===========================================================================
// addLocalProvider – validation guards
// ===========================================================================

describe("addLocalProvider – validation", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("throws when providerId is empty", async () => {
		await expect(
			addLocalProvider(manager, {
				providerId: "   ",
				name: "X",
				baseUrl: "https://example.invalid",
				models: ["m"],
			}),
		).rejects.toThrow("providerId is required");
	});

	it("throws when name is empty", async () => {
		await expect(
			addLocalProvider(manager, {
				providerId: "my-provider",
				name: "   ",
				baseUrl: "https://example.invalid",
				models: ["m"],
			}),
		).rejects.toThrow("name is required");
	});

	it("throws when baseUrl is empty and apiKey is provided", async () => {
		await expect(
			addLocalProvider(manager, {
				providerId: "my-provider2",
				name: "My Provider",
				baseUrl: "   ",
				apiKey: "present-key",
				models: ["m"],
			}),
		).rejects.toThrow("baseUrl is required");
	});

	it("throws when no models are provided and no modelsSourceUrl", async () => {
		await expect(
			addLocalProvider(manager, {
				providerId: "no-models-provider",
				name: "No Models",
				baseUrl: "https://example.invalid",
				models: [],
			}),
		).rejects.toThrow("at least one model is required");
	});

	it("throws when provider already exists", async () => {
		// Register a provider first
		await addLocalProvider(manager, {
			providerId: "duplicate-provider",
			name: "First",
			baseUrl: "https://example.invalid/v1",
			models: ["m1"],
		});

		await expect(
			addLocalProvider(manager, {
				providerId: "duplicate-provider",
				name: "Second",
				baseUrl: "https://example.invalid/v1",
				models: ["m2"],
			}),
		).rejects.toThrow('"duplicate-provider" already exists');
	});
});

// ===========================================================================
// addLocalProvider – delete compatibility path
// ===========================================================================

describe("addLocalProvider – delete compatibility", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(async () => {
		({ manager, cleanup } = makeTempManager());
		await addLocalProvider(manager, {
			providerId: "legacy-delete-provider",
			name: "Legacy Delete Provider",
			baseUrl: "https://example.invalid/v1",
			models: ["legacy-model"],
		});
		manager.saveProviderSettings(
			{
				provider: "legacy-delete-provider",
				baseUrl: "https://example.invalid/v1",
				model: "legacy-model",
			},
			{ setLastUsed: true },
		);
	});

	afterEach(() => cleanup());

	it("treats empty baseUrl and apiKey as a delete request for existing provider", async () => {
		const result = await addLocalProvider(manager, {
			providerId: "legacy-delete-provider",
			name: "Ignored",
			baseUrl: "   ",
			apiKey: "   ",
			models: [],
		});

		expect(result.providerId).toBe("legacy-delete-provider");
		expect(result.modelsCount).toBe(0);
		expect(LlmsModels.hasProvider("legacy-delete-provider")).toBe(false);
		expect(
			manager.getProviderSettings("legacy-delete-provider"),
		).toBeUndefined();
		expect(manager.getLastUsedProviderSettings()).toBeUndefined();
	});

	it("is a no-op delete when provider is already missing", async () => {
		await deleteLocalProvider(manager, {
			providerId: "legacy-delete-provider",
		});

		await expect(
			addLocalProvider(manager, {
				providerId: "legacy-delete-provider",
				name: "Ignored",
				baseUrl: "   ",
				models: [],
			}),
		).resolves.toMatchObject({
			providerId: "legacy-delete-provider",
			modelsCount: 0,
		});
	});
});

// ===========================================================================
// addLocalProvider – defaultModelId selection
// ===========================================================================

describe("addLocalProvider – defaultModelId selection", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("uses explicit defaultModelId when it is in the model list", async () => {
		await addLocalProvider(manager, {
			providerId: "default-model-provider",
			name: "Test",
			baseUrl: "https://example.invalid/v1",
			models: ["model-a", "model-b", "model-c"],
			defaultModelId: "model-b",
		});

		const settings = manager.getProviderSettings("default-model-provider");
		expect(settings?.model).toBe("model-b");
	});

	it("falls back to the first model when defaultModelId is not in the list", async () => {
		await addLocalProvider(manager, {
			providerId: "fallback-default-provider",
			name: "Test",
			baseUrl: "https://example.invalid/v1",
			models: ["model-a", "model-b"],
			defaultModelId: "not-in-list",
		});

		const settings = manager.getProviderSettings("fallback-default-provider");
		expect(settings?.model).toBe("model-a");
	});
});

// ===========================================================================
// addLocalProvider – capabilities → vision / reasoning flags
// ===========================================================================

describe("addLocalProvider – capabilities", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("exposes the model context window to provider catalog consumers", () => {
		expect(
			toProviderModel("wide-model", {
				name: "Wide Model",
				contextWindow: 1_000_000,
			}),
		).toMatchObject({
			id: "wide-model",
			name: "Wide Model",
			contextWindow: 1_000_000,
		});
	});

	it("preserves operation routing facts for provider catalog consumers", () => {
		expect(
			toProviderModel("realtime-whisper", {
				name: "Realtime Whisper",
				operation: "transcription",
				operationModes: ["streaming"],
				modalities: { input: ["audio"], output: ["text"] },
			}),
		).toMatchObject({
			operation: "transcription",
			operationModes: ["streaming"],
			inputModalities: ["audio"],
			outputModalities: ["text"],
		});
	});

	it.each([
		["absent", undefined],
		["empty", [] as const],
	])("leaves capability support undeclared when the list is %s", (_label, capabilities) => {
		expect(
			toProviderModel("sparse-model", {
				name: "Sparse Model",
				...(capabilities === undefined
					? {}
					: { capabilities: [...capabilities] }),
			}),
		).toMatchObject({
			supportsVision: undefined,
			supportsAttachments: undefined,
			supportsReasoning: undefined,
		});
	});

	it("reports a populated capability list as authoritative", () => {
		expect(
			toProviderModel("vision-only", {
				name: "Vision Only",
				capabilities: ["images"],
			}),
		).toMatchObject({
			supportsVision: true,
			supportsAttachments: false,
			supportsReasoning: false,
		});
	});

	it("sets supportsVision and supportsAttachments when capability is 'vision'", async () => {
		await addLocalProvider(manager, {
			providerId: "vision-provider",
			name: "Vision",
			baseUrl: "https://example.invalid/v1",
			models: ["vis-model"],
			capabilities: ["vision"],
		});

		const { models } = await getLocalProviderModels("vision-provider");
		expect(models).toHaveLength(1);
		expect(models[0].supportsVision).toBe(true);
		expect(models[0].supportsAttachments).toBe(true);
	});

	it("sets supportsReasoning when capability is 'reasoning'", async () => {
		await addLocalProvider(manager, {
			providerId: "reasoning-provider",
			name: "Reasoning",
			baseUrl: "https://example.invalid/v1",
			models: ["r-model"],
			capabilities: ["reasoning"],
		});

		const { models } = await getLocalProviderModels("reasoning-provider");
		expect(models[0].supportsReasoning).toBe(true);
		expect(models[0].supportsVision).toBeFalsy();
	});

	it("does not set vision/reasoning flags when capabilities are absent", async () => {
		await addLocalProvider(manager, {
			providerId: "plain-provider",
			name: "Plain",
			baseUrl: "https://example.invalid/v1",
			models: ["plain-model"],
		});

		const { models } = await getLocalProviderModels("plain-provider");
		expect(models[0].supportsVision).toBeFalsy();
		expect(models[0].supportsReasoning).toBeFalsy();
	});

	it("uses LiteLLM private models as the authoritative provider model listing when auth is configured", async () => {
		manager.saveProviderSettings(
			{
				provider: "litellm",
				apiKey: "test-key-catalog",
				baseUrl: "http://localhost:4010",
				model: "gpt-4o",
			},
			{ setLastUsed: false },
		);
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue({
				ok: true,
				json: async () => ({
					data: [
						{
							model_name: "private-proxy-model",
							litellm_params: { model: "openai/gpt-4o-mini" },
							model_info: {
								supports_vision: true,
								supports_reasoning: true,
							},
						},
					],
				}),
			}),
		);

		const { models } = await getLocalProviderModels(
			"litellm",
			manager.getProviderConfig("litellm"),
		);

		expect(models.map((model) => model.id).sort()).toEqual([
			"openai/gpt-4o-mini",
			"private-proxy-model",
		]);
		expect(models.map((model) => model.id)).not.toContain("gpt-5.4");
		expect(
			models.find((model) => model.id === "private-proxy-model"),
		).toMatchObject({
			supportsVision: true,
			supportsReasoning: true,
		});
	});

	it("uses an empty LiteLLM model list when no private model list is fetched", async () => {
		manager.saveProviderSettings(
			{
				provider: "litellm",
				baseUrl: "http://localhost:4010",
				model: "gpt-4o",
			},
			{ setLastUsed: false },
		);
		const fetchMock = vi.fn();
		vi.stubGlobal("fetch", fetchMock);

		const { models } = await getLocalProviderModels(
			"litellm",
			manager.getProviderConfig("litellm"),
		);

		expect(fetchMock).not.toHaveBeenCalled();
		expect(models).toEqual([]);
	});
});

describe("audio transcription", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(async () => {
		({ manager, cleanup } = makeTempManager());
		await addLocalProvider(manager, {
			providerId: "audio-provider",
			name: "Audio Provider",
			baseUrl: "https://audio.example.invalid/v1",
			apiKey: "audio-key",
			models: ["whisper-large-v3"],
		});
		LlmsModels.registerModel("audio-provider", "whisper-large-v3", {
			id: "whisper-large-v3",
			name: "Whisper Large v3",
			operation: "transcription",
			operationModes: ["batch"],
			modalities: { input: ["audio"], output: ["text"] },
		});
	});

	afterEach(() => cleanup());

	it("recognizes only the explicit transcription operation", () => {
		expect(
			isDedicatedTranscriptionModel({
				operation: "transcription",
			}),
		).toBe(true);
		expect(
			isDedicatedTranscriptionModel({
				operation: "speech-generation",
			}),
		).toBe(false);
		expect(
			isDedicatedTranscriptionModel({
				operation: "language",
			}),
		).toBe(false);
	});

	it("transcribes with the configured provider and requested model", async () => {
		const transcribeSpy = vi
			.spyOn(LlmsModels, "transcribeAudio")
			.mockResolvedValue({ text: "transcribed text" });

		await expect(
			transcribeLocalAudio(manager, {
				providerId: "audio-provider",
				modelId: "whisper-large-v3",
				audio: new Uint8Array([1, 2, 3]),
				mediaType: "audio/webm",
			}),
		).resolves.toEqual({ text: "transcribed text" });
		expect(transcribeSpy).toHaveBeenCalledWith(
			expect.objectContaining({
				modelId: "whisper-large-v3",
				audio: new Uint8Array([1, 2, 3]),
				mediaType: "audio/webm",
				providerConfig: expect.objectContaining({
					providerId: "audio-provider",
					apiKey: "audio-key",
				}),
			}),
		);
	});

	it("persists and uses the configured voice input model", async () => {
		await expect(
			saveVoiceInputSettings(manager, {
				providerId: "audio-provider",
				modelId: "whisper-large-v3",
			}),
		).resolves.toMatchObject({
			voiceInput: {
				providerId: "audio-provider",
				modelId: "whisper-large-v3",
			},
		});

		const transcribeSpy = vi
			.spyOn(LlmsModels, "transcribeAudio")
			.mockResolvedValue({ text: "configured transcript" });
		await expect(
			transcribeConfiguredVoiceInput(manager, {
				audio: new Uint8Array([4, 5, 6]),
				mediaType: "audio/webm",
			}),
		).resolves.toEqual({ text: "configured transcript" });
		expect(transcribeSpy).toHaveBeenCalledWith(
			expect.objectContaining({
				modelId: "whisper-large-v3",
				providerConfig: expect.objectContaining({
					providerId: "audio-provider",
				}),
			}),
		);
	});

	it("creates a streaming session only for a streaming transcription model", async () => {
		LlmsModels.registerModel("audio-provider", "realtime-whisper", {
			id: "realtime-whisper",
			name: "Realtime Whisper",
			operation: "transcription",
			operationModes: ["streaming"],
			modalities: { input: ["audio"], output: ["text"] },
		});
		await saveVoiceInputSettings(manager, {
			providerId: "audio-provider",
			modelId: "realtime-whisper",
		});
		const createSessionSpy = vi
			.spyOn(LlmsModels, "createStreamingAudioTranscriptionSession")
			.mockResolvedValue({
				token: "short-lived-token",
				url: "wss://audio.example.invalid/transcription",
			});

		await expect(
			createConfiguredStreamingTranscriptionSession(manager),
		).resolves.toMatchObject({ token: "short-lived-token" });
		expect(createSessionSpy).toHaveBeenCalledWith(
			expect.objectContaining({
				modelId: "realtime-whisper",
				providerConfig: expect.objectContaining({
					providerId: "audio-provider",
				}),
			}),
		);
	});

	it("rejects a voice input selection that is not an audio-to-text model", async () => {
		await expect(
			saveVoiceInputSettings(manager, {
				providerId: "audio-provider",
				modelId: "missing-model",
			}),
		).rejects.toThrow(
			'Model "missing-model" is not a dedicated audio-to-text transcription model',
		);
		expect(manager.getVoiceInputSettings()).toBeUndefined();
	});

	it("resolves the built-in ElevenLabs endpoint from providers.json", async () => {
		manager.saveProviderSettings(
			{
				provider: "elevenlabs",
				model: "scribe_v2",
				apiKey: "eleven-key",
			},
			{ setLastUsed: false },
		);
		const transcribeSpy = vi
			.spyOn(LlmsModels, "transcribeAudio")
			.mockResolvedValue({ text: "ElevenLabs transcript" });

		await expect(
			transcribeLocalAudio(manager, {
				providerId: "elevenlabs",
				modelId: "scribe_v2",
				audio: new Uint8Array([1, 2, 3]),
				mediaType: "audio/webm",
			}),
		).resolves.toEqual({ text: "ElevenLabs transcript" });
		expect(transcribeSpy).toHaveBeenCalledWith(
			expect.objectContaining({
				modelId: "scribe_v2",
				providerConfig: expect.objectContaining({
					providerId: "elevenlabs",
					apiKey: "eleven-key",
					baseUrl: "https://api.elevenlabs.io/v1",
				}),
			}),
		);
	});
});

// ===========================================================================
// models.json – built-in provider model overlays
// ===========================================================================

describe("models.json model overlays", () => {
	it("loads model-only entries for built-in providers", async () => {
		vi.stubGlobal(
			"fetch",
			vi.fn().mockResolvedValue(
				new Response(JSON.stringify({}), {
					status: 200,
					headers: { "content-type": "application/json" },
				}),
			),
		);
		const dir = mkdtempSync(
			path.join(os.tmpdir(), "local-provider-overlay-test-"),
		);
		try {
			const settingsDir = path.join(dir, "settings");
			mkdirSync(settingsDir, { recursive: true });
			writeFileSync(
				path.join(settingsDir, "models.json"),
				`${JSON.stringify(
					{
						version: 1,
						providers: {
							cline: {
								models: {
									"openai/gpt-5.5": {
										id: "openai/gpt-5.5",
										name: "OpenAI GPT-5.5",
									},
								},
							},
						},
					},
					null,
					2,
				)}\n`,
			);

			const manager = new ProviderSettingsManager({
				filePath: path.join(settingsDir, "providers.json"),
			});

			const provider = await LlmsModels.getProvider("cline");
			expect(provider).toMatchObject({
				id: "cline",
				baseUrl: "https://api.cline.bot/api/v1",
				defaultModelId: CLINE_DEFAULT_MODEL_ID,
			});

			const { models } = await getLocalProviderModels("cline");
			expect(
				models.find((model) => model.id === "openai/gpt-5.5"),
			).toMatchObject({
				id: "openai/gpt-5.5",
				name: "OpenAI GPT-5.5",
			});
			expect(manager.getFilePath()).toBe(
				path.join(settingsDir, "providers.json"),
			);
		} finally {
			rmSync(dir, { recursive: true, force: true });
		}
	});
});

// ===========================================================================
// saveLocalProviderSettings
// ===========================================================================

describe("saveLocalProviderSettings", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(async () => {
		({ manager, cleanup } = makeTempManager());
		// Seed a provider so there is something to operate on
		await addLocalProvider(manager, {
			providerId: "test-provider",
			name: "Test",
			baseUrl: "https://example.invalid/v1",
			models: ["m1"],
		});
	});

	afterEach(() => cleanup());

	it("disabling a provider removes it from settings", () => {
		manager.setVoiceInputSettings({
			providerId: "test-provider",
			modelId: "m1",
		});
		const result = saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: false,
		});

		expect(result.enabled).toBe(false);
		expect(manager.getProviderSettings("test-provider")).toBeUndefined();
		expect(manager.getVoiceInputSettings()).toBeUndefined();
	});

	it("updates apiKey", () => {
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			apiKey: "new-key",
		});

		expect(manager.getProviderSettings("test-provider")?.apiKey).toBe(
			"new-key",
		);
	});

	it("clears apiKey when empty string is provided", () => {
		// First set a key
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			apiKey: "some-key",
		});
		// Then clear it
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			apiKey: "",
		});

		const settings = manager.getProviderSettings("test-provider");
		expect(settings).not.toHaveProperty("apiKey");
	});

	it("merges auth object rather than replacing it", () => {
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			auth: { accessToken: "tok1" },
		});
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			auth: { refreshToken: "ref1" },
		});

		const settings = manager.getProviderSettings("test-provider") as Record<
			string,
			unknown
		>;
		const auth = settings?.auth as Record<string, unknown>;
		expect(auth?.accessToken).toBe("tok1");
		expect(auth?.refreshToken).toBe("ref1");
	});

	it("merges and clears nested provider config fields", () => {
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			gcp: { projectId: "project-a", region: "us-central1" },
		});
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			gcp: { projectId: "" },
		});

		const settings = manager.getProviderSettings("test-provider");
		expect(settings?.gcp?.projectId).toBeUndefined();
		expect(settings?.gcp?.region).toBe("us-central1");
	});

	it("passes through scalar fields like maxTokens and timeout", () => {
		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: true,
			maxTokens: 4096,
			timeout: 30_000,
		});

		const settings = manager.getProviderSettings("test-provider") as Record<
			string,
			unknown
		>;
		expect(settings?.maxTokens).toBe(4096);
		expect(settings?.timeout).toBe(30_000);
	});

	it("disabling a last-used provider also clears lastUsedProvider", async () => {
		// Set test-provider as last used
		manager.saveProviderSettings(
			{ provider: "test-provider", model: "m1" },
			{ setLastUsed: true },
		);
		expect(manager.getLastUsedProviderSettings()?.provider).toBe(
			"test-provider",
		);

		saveLocalProviderSettings(manager, {
			providerId: "test-provider",
			enabled: false,
		});

		expect(manager.getLastUsedProviderSettings()).toBeUndefined();
	});
});

// ===========================================================================
// updateLocalProvider
// ===========================================================================

describe("updateLocalProvider", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(async () => {
		({ manager, cleanup } = makeTempManager());
		await addLocalProvider(manager, {
			providerId: "editable-provider",
			name: "Editable Provider",
			baseUrl: "https://example.invalid/v1",
			apiKey: "seed-key",
			models: ["model-a", "model-b"],
			defaultModelId: "model-a",
		});
	});

	afterEach(() => cleanup());

	it("updates provider metadata and model registry", async () => {
		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			name: "Renamed Provider",
			baseUrl: "https://api.example.invalid/v2",
			models: ["model-c", "model-d"],
			defaultModelId: "model-d",
			capabilities: ["vision", "reasoning"],
		});

		const provider = await LlmsModels.getProvider("editable-provider");
		expect(provider?.name).toBe("Renamed Provider");
		expect(provider?.baseUrl).toBe("https://api.example.invalid/v2");
		expect(provider?.defaultModelId).toBe("model-d");

		const { models } = await getLocalProviderModels("editable-provider");
		expect(models.map((model) => model.id).sort()).toEqual([
			"model-c",
			"model-d",
		]);
		expect(models.find((model) => model.id === "model-c")?.supportsVision).toBe(
			true,
		);
		expect(
			models.find((model) => model.id === "model-c")?.supportsReasoning,
		).toBe(true);
	});

	it("updates provider settings and can clear optional fields", async () => {
		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			baseUrl: "https://api.example.invalid/v3",
			apiKey: "",
			headers: null,
			timeoutMs: null,
		});

		const settings = manager.getProviderSettings("editable-provider");
		expect(settings?.baseUrl).toBe("https://api.example.invalid/v3");
		expect(settings).not.toHaveProperty("apiKey");
		expect(settings).not.toHaveProperty("headers");
		expect(settings).not.toHaveProperty("timeout");
	});

	it("clears capabilities with null and does not treat [] as a clear sentinel", async () => {
		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			capabilities: ["vision"],
		});
		const modelsPath = resolveModelsRegistryPath(manager);
		let modelsState = await readModelsFile(modelsPath);
		expect(
			modelsState.providers["editable-provider"]?.provider?.capabilities,
		).toEqual(["vision"]);

		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			capabilities: [],
		});
		modelsState = await readModelsFile(modelsPath);
		expect(
			modelsState.providers["editable-provider"]?.provider?.capabilities,
		).toEqual([]);

		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			capabilities: null,
		});
		modelsState = await readModelsFile(modelsPath);
		expect(
			modelsState.providers["editable-provider"]?.provider?.capabilities,
		).toBeUndefined();
	});

	it("allows modelsSourceUrl: null to clear URL while preserving existing models", async () => {
		const fetchMock = vi.fn().mockResolvedValue({
			ok: true,
			json: async () => ["remote-a", "remote-b"],
		});
		vi.stubGlobal("fetch", fetchMock);

		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			models: ["model-a", "model-b"],
			modelsSourceUrl: "https://example.invalid/models",
		});

		await updateLocalProvider(manager, {
			providerId: "editable-provider",
			modelsSourceUrl: null,
		});

		const modelsState = await readModelsFile(
			resolveModelsRegistryPath(manager),
		);
		expect(
			modelsState.providers["editable-provider"]?.provider?.modelsSourceUrl,
		).toBeUndefined();

		const { models } = await getLocalProviderModels("editable-provider");
		expect(models.map((model) => model.id).sort()).toEqual([
			"model-a",
			"model-b",
			"remote-a",
			"remote-b",
		]);
		expect(fetchMock).toHaveBeenCalledTimes(1);
	});

	it("updates a provider that exists in settings but not models registry", async () => {
		manager.saveProviderSettings(
			{
				provider: "settings-only-provider",
				baseUrl: "https://settings.example.invalid/v1",
				model: "saved-model",
			},
			{ setLastUsed: false },
		);

		const result = await updateLocalProvider(manager, {
			providerId: "settings-only-provider",
			models: ["new-model-a", "new-model-b"],
			defaultModelId: "new-model-b",
		});

		expect(result.modelsCount).toBe(2);
		const provider = await LlmsModels.getProvider("settings-only-provider");
		expect(provider?.name).toBe("Settings Only Provider");
		expect(provider?.baseUrl).toBe("https://settings.example.invalid/v1");
		expect(provider?.defaultModelId).toBe("new-model-b");

		const settings = manager.getProviderSettings("settings-only-provider");
		expect(settings?.baseUrl).toBe("https://settings.example.invalid/v1");
		expect(settings?.model).toBe("new-model-b");

		const { models } = await getLocalProviderModels("settings-only-provider");
		expect(models.map((model) => model.id).sort()).toEqual([
			"new-model-a",
			"new-model-b",
		]);
	});

	it("throws when updating a provider that does not exist in custom registry", async () => {
		await expect(
			updateLocalProvider(manager, {
				providerId: "missing-provider",
				name: "Nope",
			}),
		).rejects.toThrow('"missing-provider" does not exist');
	});
});

// ===========================================================================
// deleteLocalProvider
// ===========================================================================

describe("deleteLocalProvider", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(async () => {
		({ manager, cleanup } = makeTempManager());
		await addLocalProvider(manager, {
			providerId: "delete-me-provider",
			name: "Delete Me",
			baseUrl: "https://example.invalid/v1",
			models: ["delete-model"],
		});
		manager.saveProviderSettings(
			{
				provider: "delete-me-provider",
				baseUrl: "https://example.invalid/v1",
				model: "delete-model",
			},
			{ setLastUsed: true },
		);
	});

	afterEach(() => cleanup());

	it("removes provider from registry and local settings", async () => {
		await deleteLocalProvider(manager, {
			providerId: "delete-me-provider",
		});

		expect(LlmsModels.hasProvider("delete-me-provider")).toBe(false);
		expect(manager.getProviderSettings("delete-me-provider")).toBeUndefined();
		expect(manager.getLastUsedProviderSettings()).toBeUndefined();
	});

	it("throws when deleting an unknown provider", async () => {
		await expect(
			deleteLocalProvider(manager, { providerId: "missing-provider" }),
		).rejects.toThrow('"missing-provider" does not exist');
	});
});

// ===========================================================================
// listLocalProviders
// ===========================================================================

describe("listLocalProviders", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("includes all registered providers", async () => {
		await addLocalProvider(manager, {
			providerId: "list-provider-a",
			name: "Provider A",
			baseUrl: "https://example.invalid/a",
			models: ["ma1"],
		});
		await addLocalProvider(manager, {
			providerId: "list-provider-b",
			name: "Provider B",
			baseUrl: "https://example.invalid/b",
			models: ["mb1"],
		});

		const { providers } = await listLocalProviders(manager);
		const ids = providers.map((p) => p.id);
		expect(ids).toContain("list-provider-a");
		expect(ids).toContain("list-provider-b");
	});

	it("hides ClinePass when the ClinePass feature flag is disabled", async () => {
		const { providers } = await listLocalProviders(manager, {
			isClinePassEnabled: false,
		});

		expect(providers.map((p) => p.id)).not.toContain("cline-pass");
	});

	it("includes ClinePass when the ClinePass feature flag is enabled", async () => {
		const { providers } = await listLocalProviders(manager, {
			isClinePassEnabled: true,
		});

		expect(providers.map((p) => p.id)).toContain("cline-pass");
	});

	it("stamps featured tiers from the bundled fallback without a feed fetch", async () => {
		const fetchMock = vi.fn();
		vi.stubGlobal("fetch", fetchMock);

		const { providers } = await listLocalProviders(manager);
		const modelList =
			providers.find((provider) => provider.id === "cline")?.modelList ?? [];
		const stampedIds = modelList
			.filter((model) => model.featured?.tier === "recommended")
			.map((model) => model.id);
		const expectedIds = FALLBACK_CLINE_RECOMMENDED_MODELS.recommended
			.map((model) => model.id)
			.filter((id) => modelList.some((model) => model.id === id));

		// A cold boot must still paint tiered sections: the catalog stamps
		// synchronously from the bundled fallback instead of waiting on (or
		// triggering) a feed fetch.
		expect(stampedIds.length).toBeGreaterThan(0);
		expect(new Set(stampedIds)).toEqual(new Set(expectedIds));
		expect(fetchMock).not.toHaveBeenCalled();
	});

	it("stamps featured tiers from the cached live feed once warmed", async () => {
		const clineModelIds = Object.keys(
			await LlmsModels.getModelsForProvider("cline"),
		);
		const [recommendedId, freeId] = clineModelIds;
		await getCachedClineRecommendedModels({
			baseUrl: "https://api.example.test",
			fetchImpl: async () =>
				new Response(
					JSON.stringify({
						recommended: [
							{
								id: recommendedId,
								name: "Live Pick",
								description: "Live description",
								tags: ["NEW"],
							},
						],
						free: [{ id: freeId, name: "Live Free", description: "" }],
						clinePass: [],
					}),
					{ status: 200, headers: { "Content-Type": "application/json" } },
				),
			catalogLoader: async () => ({}),
		});

		const { providers } = await listLocalProviders(manager);
		const modelList =
			providers.find((provider) => provider.id === "cline")?.modelList ?? [];

		expect(
			modelList.find((model) => model.id === recommendedId)?.featured,
		).toEqual({ tier: "recommended", rank: 0, tags: ["NEW"] });
		expect(modelList.find((model) => model.id === freeId)?.featured).toEqual({
			tier: "free",
			rank: 0,
			tags: [],
		});
	});

	it("marks enabled providers correctly", async () => {
		await addLocalProvider(manager, {
			providerId: "enabled-check-provider",
			name: "Enabled Check",
			baseUrl: "https://example.invalid/v1",
			models: ["m1"],
		});

		const { providers } = await listLocalProviders(manager);
		const p = providers.find((x) => x.id === "enabled-check-provider");
		expect(p?.enabled).toBe(true);
	});

	it("returns the configured voice input selection", async () => {
		await addLocalProvider(manager, {
			providerId: "voice-list-provider",
			name: "Voice List Provider",
			baseUrl: "https://example.invalid/v1",
			models: ["whisper"],
		});
		LlmsModels.registerModel("voice-list-provider", "whisper", {
			id: "whisper",
			name: "Whisper",
			operation: "transcription",
			operationModes: ["batch"],
			modalities: { input: ["audio"], output: ["text"] },
		});
		await saveVoiceInputSettings(manager, {
			providerId: "voice-list-provider",
			modelId: "whisper",
		});

		const catalog = await listLocalProviders(manager);
		expect(catalog.voiceInput).toEqual({
			providerId: "voice-list-provider",
			modelId: "whisper",
		});
	});

	it("marks alias providers enabled without copying shared OAuth credentials", async () => {
		manager.saveProviderSettings(
			{
				provider: "cline",
				auth: {
					accessToken: "shared-token",
					refreshToken: "shared-refresh",
				},
			},
			{ setLastUsed: false, tokenSource: "oauth" },
		);

		markLocalProviderEnabled(manager, "cline-pass", { tokenSource: "oauth" });

		const state = manager.read();
		expect(state.providers["cline-pass"]?.settings).toEqual({
			provider: "cline-pass",
		});
		expect(state.providers["cline-pass"]?.tokenSource).toBe("oauth");
	});

	it("resolves shared OAuth metadata for ClinePass catalog entries", async () => {
		manager.saveProviderSettings(
			{
				provider: "cline",
				auth: {
					accessToken: "shared-token",
					refreshToken: "shared-refresh",
				},
			},
			{ setLastUsed: false, tokenSource: "oauth" },
		);
		markLocalProviderEnabled(manager, "cline-pass", { tokenSource: "oauth" });

		const { providers } = await listLocalProviders(manager, {
			isClinePassEnabled: true,
		});
		const clinePass = providers.find(
			(provider) => provider.id === "cline-pass",
		);

		expect(clinePass).toMatchObject({
			enabled: true,
			oauthAccessTokenPresent: true,
		});
	});

	it("exposes model count", async () => {
		await addLocalProvider(manager, {
			providerId: "count-provider",
			name: "Count",
			baseUrl: "https://example.invalid/v1",
			models: ["x", "y", "z"],
		});

		const { providers } = await listLocalProviders(manager);
		const p = providers.find((x) => x.id === "count-provider");
		expect(p?.models).toBe(3);
	});

	it("generates a stable color and letter for each provider", async () => {
		await addLocalProvider(manager, {
			providerId: "color-letter-provider",
			name: "Color Letter",
			baseUrl: "https://example.invalid/v1",
			models: ["m1"],
		});

		const { providers } = await listLocalProviders(manager);
		const p = providers.find((x) => x.id === "color-letter-provider");
		expect(p?.color).toMatch(/^#[0-9a-f]{6}$/i);
		expect(p?.letter).toBeTruthy();
	});

	it("includes built-in model lists in the provider catalog path", async () => {
		manager.saveProviderSettings(
			{
				provider: "openai-native",
				apiKey: "test-key",
				baseUrl: "https://api.openai.com/v1",
				model: "gpt-5.3-codex",
			},
			{ setLastUsed: false },
		);

		const { providers } = await listLocalProviders(manager);
		const openai = providers.find(
			(provider) => provider.id === "openai-native",
		);

		expect(openai?.modelList?.length).toBeGreaterThan(0);
		expect(
			openai?.modelList?.some((model) => model.id === "gpt-5.3-codex"),
		).toBe(true);
	});

	it("exposes provider-specific config fields for Vertex", async () => {
		manager.saveProviderSettings(
			{
				provider: "vertex",
				gcp: { projectId: "gcp-project", region: "us-west1" },
				model: "claude-sonnet-4-6@default",
			},
			{ setLastUsed: false },
		);

		const { providers } = await listLocalProviders(manager);
		const vertex = providers.find((provider) => provider.id === "vertex");

		expect(vertex?.configFields?.map((field) => field.path)).toEqual([
			"gcp.projectId",
			"gcp.region",
			"apiKey",
		]);
		expect(vertex?.configValues?.["gcp.projectId"]).toBe("gcp-project");
		expect(vertex?.configValues?.["gcp.region"]).toBe("us-west1");
		expect(
			vertex?.configFields?.some((field) => field.path === "baseUrl"),
		).toBe(false);
	});

	it("uses Cline-specific Z.ai aliases in the built-in model list", async () => {
		manager.saveProviderSettings(
			{
				provider: "cline",
				apiKey: "test-key",
				baseUrl: "https://api.cline.bot/api/v1",
				model: "anthropic/claude-sonnet-4.6",
			},
			{ setLastUsed: false },
		);

		const { providers } = await listLocalProviders(manager);
		const cline = providers.find((provider) => provider.id === "cline");
		const openrouter = providers.find(
			(provider) => provider.id === "openrouter",
		);
		const clineModelIds = new Set(
			cline?.modelList?.map((model) => model.id) ?? [],
		);
		const openrouterModelIds = new Set(
			openrouter?.modelList?.map((model) => model.id) ?? [],
		);

		expect(cline?.modelList?.length).toBeGreaterThan(0);
		expect(clineModelIds).toContain("zai/glm-5.2");
		expect(clineModelIds).not.toContain("z-ai/glm-5.2");
		expect(openrouterModelIds).toContain("z-ai/glm-5.2");
	});

	it("does not eagerly fetch LiteLLM private models while listing providers", async () => {
		manager.saveProviderSettings(
			{
				provider: "litellm",
				apiKey: "test-key",
				baseUrl: "http://localhost:4000",
				model: "gpt-4o",
			},
			{ setLastUsed: false },
		);
		const fetchMock = vi.fn().mockResolvedValue({
			ok: true,
			json: async () => ({
				data: [
					{
						model_name: "team-private-model",
						litellm_params: { model: "team/private-model" },
						model_info: {},
					},
				],
			}),
		});
		vi.stubGlobal("fetch", fetchMock);

		const { providers } = await listLocalProviders(manager);
		const litellm = providers.find((provider) => provider.id === "litellm");

		expect(fetchMock).not.toHaveBeenCalled();
		expect(litellm?.modelList?.length).toBeGreaterThan(0);
		expect(
			litellm?.modelList?.some((model) => model.id === "team/private-model"),
		).toBe(false);
	});
});

// ===========================================================================
// normalizeOAuthProvider
// ===========================================================================

describe("normalizeOAuthProvider", () => {
	it("normalizes 'cline' to 'cline'", () => {
		expect(normalizeOAuthProvider("cline")).toBe("cline");
		expect(normalizeOAuthProvider("  CLINE  ")).toBe("cline");
	});

	it("normalizes 'oca' to 'oca'", () => {
		expect(normalizeOAuthProvider("oca")).toBe("oca");
		expect(normalizeOAuthProvider("OCA")).toBe("oca");
	});

	it("normalizes 'openai-codex' to 'openai-codex'", () => {
		expect(normalizeOAuthProvider("openai-codex")).toBe("openai-codex");
		expect(normalizeOAuthProvider("OPENAI-CODEX")).toBe("openai-codex");
	});

	it("throws for unsupported providers", () => {
		expect(() => normalizeOAuthProvider("anthropic")).toThrow(
			"does not support OAuth login",
		);
		expect(() => normalizeOAuthProvider("")).toThrow();
	});
});

// ===========================================================================
// resolveLocalClineAuthToken
// ===========================================================================

describe("resolveLocalClineAuthToken", () => {
	it("returns undefined when settings is undefined", () => {
		expect(resolveLocalClineAuthToken(undefined)).toBeUndefined();
	});

	it("returns accessToken when present", () => {
		expect(
			resolveLocalClineAuthToken({
				provider: "cline" as never,
				auth: { accessToken: "tok123" },
			}),
		).toBe("tok123");
	});

	it("falls back to apiKey when accessToken is absent", () => {
		expect(
			resolveLocalClineAuthToken({
				provider: "cline" as never,
				apiKey: "api-key-456",
			}),
		).toBe("api-key-456");
	});

	it("prefers accessToken over apiKey", () => {
		expect(
			resolveLocalClineAuthToken({
				provider: "cline" as never,
				apiKey: "api-key",
				auth: { accessToken: "access-token" },
			}),
		).toBe("access-token");
	});

	it("returns undefined when both accessToken and apiKey are empty strings", () => {
		expect(
			resolveLocalClineAuthToken({
				provider: "cline" as never,
				apiKey: "   ",
				auth: { accessToken: "  " },
			}),
		).toBeUndefined();
	});

	it("returns undefined when both fields are absent", () => {
		expect(
			resolveLocalClineAuthToken({ provider: "cline" as never }),
		).toBeUndefined();
	});
});

describe("refreshProviderModelsFromSource", () => {
	let manager: ProviderSettingsManager;
	let cleanup: () => void;

	beforeEach(() => {
		({ manager, cleanup } = makeTempManager());
	});

	afterEach(() => cleanup());

	it("refreshes built-in Ollama models through modelsSourceUrl using the saved base URL", async () => {
		const fetchMock = vi.fn().mockResolvedValue({
			ok: true,
			json: async () => ({ models: [{ name: "remote-llama" }] }),
		});
		vi.stubGlobal("fetch", fetchMock);
		saveLocalProviderSettings(manager, {
			providerId: "ollama",
			baseUrl: "http://tailscale-host:11434/v1",
		});

		const result = await refreshProviderModelsFromSource(manager, "ollama");

		expect(result).toMatchObject({ providerId: "ollama", refreshed: true });
		expect(fetchMock).toHaveBeenCalledWith(
			"http://tailscale-host:11434/api/tags",
			{
				method: "GET",
			},
		);
		const modelsState = await readModelsFile(
			resolveModelsRegistryPath(manager),
		);
		expect(modelsState.providers.ollama?.provider?.modelsSourceUrl).toBe(
			"http://tailscale-host:11434/api/tags",
		);
		const { models } = await getLocalProviderModels("ollama");
		expect(models.map((model) => model.id)).toContain("remote-llama");
	});
});
