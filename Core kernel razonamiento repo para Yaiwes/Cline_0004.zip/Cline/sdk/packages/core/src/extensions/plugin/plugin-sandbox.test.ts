import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type {
	AgentConfig,
	AgentExtensionMessageBuilder,
	AgentExtensionRule,
	AgentTool,
	AgentToolContext,
	Message,
} from "@cline/shared";
import {
	afterAll,
	beforeAll,
	beforeEach,
	describe,
	expect,
	it,
	vi,
} from "vitest";
import {
	CLINE_PLUGIN_IDLE_TIMEOUT_MS_ENV,
	loadSandboxedPlugins,
} from "./plugin-sandbox";

function createApiCapture() {
	const tools: AgentTool[] = [];
	const rules: AgentExtensionRule[] = [];
	const messageBuilders: AgentExtensionMessageBuilder<Message[]>[] = [];
	const automationEventTypes: unknown[] = [];
	const api = {
		registerTool: (tool: AgentTool) => tools.push(tool),
		registerCommand: () => {},
		registerMessageBuilder: (
			builder: AgentExtensionMessageBuilder<Message[]>,
		) => messageBuilders.push(builder),
		registerRule: (rule: AgentExtensionRule) => rules.push(rule),
		registerProvider: () => {},
		registerAutomationEventType: (eventType: unknown) =>
			automationEventTypes.push(eventType),
		registerMcpServer: () => {},
	};
	return { tools, rules, messageBuilders, automationEventTypes, api };
}

function makeSnapshot() {
	return {
		agentId: "agent-1",
		status: "running" as const,
		iteration: 1,
		messages: [],
		pendingToolCalls: [],
		usage: {
			inputTokens: 0,
			outputTokens: 0,
			cacheReadTokens: 0,
			cacheWriteTokens: 0,
		},
	};
}

describe("plugin-sandbox", () => {
	let dir = "";
	let sharedSandbox:
		| Awaited<ReturnType<typeof loadSandboxedPlugins>>
		| undefined;
	let sharedExtensions = new Map<
		string,
		NonNullable<AgentConfig["extensions"]>[number]
	>();
	const forwardedEvents: Array<{ name: string; payload?: unknown }> = [];

	// Allow generous time for jiti transpilation of multiple TS plugins in CI.
	beforeAll(async () => {
		dir = await mkdtemp(join(tmpdir(), "core-plugin-sandbox-"));

		await writeFile(
			join(dir, "plugin.mjs"),
			[
				"export default {",
				"  name: 'sandbox-test',",
				"  manifest: { capabilities: ['hooks','tools'] },",
				"  setup(api) {",
				"    api.registerTool({",
				"      name: 'sandbox_echo',",
				"      description: 'echo',",
				"      inputSchema: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] },",
				"      execute: async (input) => ({ echoed: input.value }),",
				"    });",
				"  },",
				"  hooks: { beforeRun() { return { reason: 'sandbox-before-run' }; } },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-events.mjs"),
			[
				"export default {",
				"  name: 'sandbox-events',",
				"  manifest: { capabilities: ['tools'] },",
				"  setup(api) {",
				"    api.registerTool({",
				"      name: 'emit_event',",
				"      description: 'emit host event',",
				"      inputSchema: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] },",
				"      execute: async (input) => {",
				"        globalThis.__clinePluginHost?.emitEvent?.('test_event', { value: input.value });",
				"        return { ok: true };",
				"      },",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-run-end.mjs"),
			[
				"export default {",
				"  name: 'sandbox-run-end',",
				"  manifest: { capabilities: ['hooks'] },",
				"  hooks: { afterRun(ctx) {",
				"    globalThis.__clinePluginHost?.emitEvent?.('run_end_hook', {",
				"      finishReason: ctx.result?.status,",
				"      iterations: ctx.result?.iterations,",
				"    });",
				"  } },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-message-builder.mjs"),
			[
				"export default {",
				"  name: 'sandbox-message-builder',",
				"  manifest: { capabilities: ['messageBuilders'] },",
				"  setup(api) {",
				"    api.registerMessageBuilder({",
				"      name: 'append-system-context',",
				"      build: async (messages) => messages.concat([{ role: 'user', content: [{ type: 'text', text: 'from sandbox builder' }] }]),",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-rules.mjs"),
			[
				"let resolveCount = 0;",
				"export default {",
				"  name: 'sandbox-rules',",
				"  manifest: { capabilities: ['rules'] },",
				"  setup(api) {",
				"    api.registerRule({",
				"      id: 'sandbox-rules:static',",
				"      source: 'sandbox-rules',",
				"      content: 'Static sandbox rule',",
				"    });",
				"    api.registerRule({",
				"      id: 'sandbox-rules:lazy',",
				"      source: 'sandbox-rules',",
				"      content: async () => {",
				"        resolveCount += 1;",
				"        return 'Lazy sandbox rule ' + resolveCount;",
				"      },",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-automation-events.mjs"),
			[
				"export default {",
				"  name: 'sandbox-automation-events',",
				"  manifest: { capabilities: ['automationEvents','tools'] },",
				"  setup(api, ctx) {",
				"    api.registerAutomationEventType({",
				"      eventType: 'local.plugin_event',",
				"      source: 'local-plugin',",
				"      description: 'Local event emitted by a sandbox plugin',",
				"      attributesSchema: { type: 'object', properties: { topic: { type: 'string' } } },",
				"    });",
				"    api.registerTool({",
				"      name: 'emit_automation_event',",
				"      description: 'emit automation event',",
				"      inputSchema: { type: 'object', properties: { topic: { type: 'string' } }, required: ['topic'] },",
				"      execute: async (input) => {",
				"        await ctx.automation?.ingestEvent?.({",
				"          eventId: 'plugin-' + input.topic,",
				"          eventType: 'local.plugin_event',",
				"          source: 'local-plugin',",
				"          subject: input.topic,",
				"          occurredAt: '2026-04-24T10:00:00.000Z',",
				"          attributes: { topic: input.topic },",
				"        });",
				"        return { ok: true };",
				"      },",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-telemetry.mjs"),
			[
				"export default {",
				"  name: 'sandbox-telemetry',",
				"  manifest: { capabilities: ['tools'] },",
				"  setup(api, ctx) {",
				"    api.registerTool({",
				"      name: 'emit_plugin_telemetry',",
				"      description: 'emit plugin telemetry',",
				"      inputSchema: { type: 'object', properties: { topic: { type: 'string' } }, required: ['topic'] },",
				"      execute: async (input) => {",
				"        ctx.telemetry?.capture({",
				"          event: 'sandbox_topic_used',",
				"          properties: { topic: input.topic },",
				"        });",
				"        ctx.telemetry?.recordCounter('sandbox_topics', 1, { topic: input.topic });",
				"        return { enabled: ctx.telemetry?.isEnabled() ?? false };",
				"      },",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-ts.ts"),
			[
				"const TOOL_NAME: string = 'sandbox_ts_echo';",
				"export default {",
				"  name: 'sandbox-ts',",
				"  manifest: { capabilities: ['tools'] },",
				"  setup(api) {",
				"    api.registerTool({",
				"      name: TOOL_NAME,",
				"      description: 'echo',",
				"      inputSchema: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] },",
				"      execute: async (input) => ({ echoed: input.value }),",
				"    });",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		const localDepDir = join(dir, "node_modules", "sandbox-local-dep");
		await mkdir(localDepDir, { recursive: true });
		await writeFile(
			join(localDepDir, "package.json"),
			JSON.stringify({
				name: "sandbox-local-dep",
				type: "module",
				exports: "./index.js",
			}),
			"utf8",
		);
		await writeFile(
			join(localDepDir, "index.js"),
			"export const depName = 'sandbox-local-dep';\n",
			"utf8",
		);
		await writeFile(
			join(dir, "plugin-dep.ts"),
			[
				"import { depName } from 'sandbox-local-dep';",
				"export default {",
				"  name: depName,",
				"  manifest: { capabilities: ['tools'] },",
				"};",
			].join("\n"),
			"utf8",
		);

		const sdkDepDir = join(dir, "node_modules", "@cline", "shared");
		await mkdir(sdkDepDir, { recursive: true });
		await writeFile(
			join(sdkDepDir, "package.json"),
			JSON.stringify({
				name: "@cline/shared",
				type: "module",
				exports: "./index.js",
			}),
			"utf8",
		);
		await writeFile(
			join(sdkDepDir, "index.js"),
			"export const sdkMarker = 'sandbox-plugin-installed-sdk';\n",
			"utf8",
		);
		await writeFile(
			join(dir, "plugin-sdk.ts"),
			[
				"import { sdkMarker } from '@cline/shared';",
				"export default {",
				"  name: sdkMarker,",
				"  manifest: { capabilities: ['tools'] },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-host-dep.ts"),
			[
				"import { resolveClineDataDir } from '@cline/shared/storage';",
				"import YAML from 'yaml';",
				"export default {",
				"  name: YAML.stringify({ host: !!resolveClineDataDir() }).trim(),",
				"  manifest: { capabilities: ['tools'] },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-create-tool.ts"),
			[
				"import { createTool } from '@cline/agents';",
				"export default {",
				"  name: 'sandbox-create-tool',",
				"  manifest: { capabilities: ['tools'] },",
				"  setup(api) {",
				"    api.registerTool(createTool({",
				"      name: 'created_tool',",
				"      description: 'created via agents export',",
				"      inputSchema: { type: 'object', properties: { value: { type: 'string' } }, required: ['value'] },",
				"      execute: async (input) => ({ echoed: input.value }),",
				"    }));",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-broken-setup.mjs"),
			[
				"export default {",
				"  name: 'sandbox-broken-setup',",
				"  manifest: { capabilities: ['tools'] },",
				"  async setup() {",
				"    throw new Error('broken setup');",
				"  },",
				"};",
			].join("\n"),
			"utf8",
		);

		await writeFile(
			join(dir, "plugin-duplicate-a.mjs"),
			"export default { name: 'sandbox-duplicate', manifest: { capabilities: ['tools'] } };",
			"utf8",
		);
		await writeFile(
			join(dir, "plugin-duplicate-b.mjs"),
			"export default { name: 'sandbox-duplicate', manifest: { capabilities: ['commands'] } };",
			"utf8",
		);
		await writeFile(
			join(dir, "plugin-targeted.mjs"),
			[
				"export default {",
				"  name: 'sandbox-targeted',",
				"  manifest: { capabilities: ['tools'], providerIds: ['openai'], modelIds: ['gpt-5.4'] },",
				"};",
			].join("\n"),
			"utf8",
		);

		sharedSandbox = await loadSandboxedPlugins({
			pluginPaths: [
				join(dir, "plugin.mjs"),
				join(dir, "plugin-events.mjs"),
				join(dir, "plugin-run-end.mjs"),
				join(dir, "plugin-automation-events.mjs"),
				join(dir, "plugin-telemetry.mjs"),
				join(dir, "plugin-message-builder.mjs"),
				join(dir, "plugin-rules.mjs"),
				join(dir, "plugin-ts.ts"),
				join(dir, "plugin-dep.ts"),
				join(dir, "plugin-sdk.ts"),
				join(dir, "plugin-host-dep.ts"),
				join(dir, "plugin-create-tool.ts"),
			],
			// CI environments are significantly slower for jiti transpilation;
			// the default 4 000 ms is too tight for 7 plugins.
			importTimeoutMs: 30_000,
			telemetryAvailable: true,
			onEvent: (event) => {
				forwardedEvents.push(event);
			},
		});
		sharedExtensions = new Map(
			(sharedSandbox.extensions ?? []).map((extension) => [
				extension.name,
				extension,
			]),
		);
	}, 60_000);

	beforeEach(() => {
		forwardedEvents.length = 0;
	});

	afterAll(async () => {
		await sharedSandbox?.shutdown();
		if (dir) {
			await rm(dir, { recursive: true, force: true });
		}
	});

	it("runs plugin hooks and tool contributions in sandbox process", async () => {
		expect(sharedSandbox?.extensions).toBeDefined();
		const extension = sharedExtensions.get("sandbox-test");
		expect(extension?.name).toBe("sandbox-test");
		const control = await extension?.hooks?.beforeRun?.({
			snapshot: makeSnapshot(),
		});
		expect(control?.reason).toBe("sandbox-before-run");

		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		expect(tools.map((tool) => tool.name)).toContain("sandbox_echo");
		const echoTool = tools.find((tool) => tool.name === "sandbox_echo");
		expect(echoTool).toBeDefined();
		const result = await echoTool?.execute({ value: "ok" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(result).toEqual({ echoed: "ok" });
	});

	it("strips non-serializable host values from the tool context before IPC", async () => {
		const extension = sharedExtensions.get("sandbox-test");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const echoTool = tools.find((tool) => tool.name === "sandbox_echo");
		expect(echoTool).toBeDefined();

		// The production orchestrator attaches the live telemetry service
		// (cyclic: PostHog client) under this metadata key. Without
		// sanitization, child.send() throws and every plugin tool call fails.
		const cyclicTelemetry: Record<string, unknown> = { capture: () => {} };
		cyclicTelemetry.self = cyclicTelemetry;
		const result = await echoTool?.execute({ value: "ok" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
			signal: new AbortController().signal,
			emitUpdate: () => {},
			metadata: {
				modelSupportsImages: true,
				__clineInternalTelemetry: cyclicTelemetry,
			},
		} as unknown as AgentToolContext);
		expect(result).toEqual({ echoed: "ok" });
	});

	it("bridges ctx.telemetry calls to the host as plugin_telemetry events", async () => {
		const extension = sharedExtensions.get("sandbox-telemetry");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const tool = tools.find((t) => t.name === "emit_plugin_telemetry");
		expect(tool).toBeDefined();

		const result = await tool?.execute({ topic: "weather" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(result).toEqual({ enabled: true });

		const telemetryEvents = forwardedEvents.filter(
			(event) => event.name === "plugin_telemetry",
		);
		expect(telemetryEvents).toHaveLength(2);
		expect(telemetryEvents[0]?.payload).toMatchObject({
			pluginName: "sandbox-telemetry",
			kind: "event",
			event: "sandbox_topic_used",
			properties: { topic: "weather" },
		});
		expect(telemetryEvents[1]?.payload).toMatchObject({
			pluginName: "sandbox-telemetry",
			kind: "metric",
			metric: "counter",
			name: "sandbox_topics",
			value: 1,
			attributes: { topic: "weather" },
		});
	});

	it("omits ctx.telemetry when the host reports no telemetry service", async () => {
		const noTelemetryDir = await mkdtemp(
			join(tmpdir(), "core-plugin-sandbox-no-telemetry-"),
		);
		try {
			const pluginPath = join(noTelemetryDir, "plugin-telemetry.mjs");
			await writeFile(
				pluginPath,
				[
					"export default {",
					"  name: 'sandbox-no-telemetry',",
					"  manifest: { capabilities: ['tools'] },",
					"  setup(api, ctx) {",
					"    api.registerTool({",
					"      name: 'probe_telemetry',",
					"      description: 'probe telemetry availability',",
					"      inputSchema: { type: 'object', properties: {}, required: [] },",
					"      execute: async () => ({ present: ctx.telemetry !== undefined }),",
					"    });",
					"  },",
					"};",
				].join("\n"),
				"utf8",
			);
			const events: Array<{ name: string; payload?: unknown }> = [];
			const sandbox = await loadSandboxedPlugins({
				pluginPaths: [pluginPath],
				importTimeoutMs: 30_000,
				// telemetryAvailable intentionally omitted: no host service.
				onEvent: (event) => events.push(event),
			});
			try {
				const { tools, api } = createApiCapture();
				await sandbox.extensions?.[0]?.setup?.(api, {});
				const tool = tools.find((t) => t.name === "probe_telemetry");
				const result = await tool?.execute({}, {
					agentId: "agent-1",
					iteration: 1,
				} as AgentToolContext);
				expect(result).toEqual({ present: false });
				expect(
					events.filter((event) => event.name === "plugin_telemetry"),
				).toHaveLength(0);
			} finally {
				await sandbox.shutdown();
			}
		} finally {
			await rm(noTelemetryDir, { recursive: true, force: true });
		}
	}, 60_000);

	it("strips non-serializable tool input via the same fallback", async () => {
		const extension = sharedExtensions.get("sandbox-test");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const echoTool = tools.find((tool) => tool.name === "sandbox_echo");
		expect(echoTool).toBeDefined();

		// beforeTool hooks and programmatic callers can rewrite the input, so
		// it can carry non-serializable values just like the context can.
		const cyclicInput: Record<string, unknown> = { value: "ok" };
		cyclicInput.self = cyclicInput;
		const result = await echoTool?.execute(cyclicInput, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(result).toEqual({ echoed: "ok" });

		// BigInts raise a different serialization error message than cycles do
		// in both Bun and Node; the fallback must classify those too.
		const bigintInput: Record<string, unknown> = {
			value: "ok",
			blockNumber: 123n,
		};
		const bigintResult = await echoTool?.execute(bigintInput, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 2,
		} as AgentToolContext);
		expect(bigintResult).toEqual({ echoed: "ok" });
	});

	it("enforces hook timeout and cancels sandbox process", async () => {
		const timeoutDir = await mkdtemp(
			join(tmpdir(), "core-plugin-sandbox-timeout-"),
		);
		try {
			const pluginPath = join(timeoutDir, "plugin-timeout.mjs");
			await writeFile(
				pluginPath,
				[
					"export default {",
					"  name: 'sandbox-timeout',",
					"  manifest: { capabilities: ['hooks'] },",
					"  hooks: { beforeRun() { return new Promise(() => {}); } },",
					"};",
				].join("\n"),
				"utf8",
			);

			const sandboxed = await loadSandboxedPlugins({
				pluginPaths: [pluginPath],
				hookTimeoutMs: 50,
			});
			const extension = sandboxed.extensions?.[0];
			await expect(
				extension?.hooks?.beforeRun?.({ snapshot: makeSnapshot() }),
			).rejects.toThrow(/timed out/i);
			await sandboxed.shutdown();
		} finally {
			await rm(timeoutDir, { recursive: true, force: true });
		}
	});

	it("respects CLINE_PLUGIN_IMPORT_TIMEOUT_MS env var when options.importTimeoutMs is unset", async () => {
		const envDir = await mkdtemp(
			join(tmpdir(), "core-plugin-sandbox-import-env-"),
		);
		try {
			const pluginPath = join(envDir, "plugin-import-hang.mjs");
			// Top-level await that never resolves — module import never
			// completes, so the initialize call must hit the timeout.
			await writeFile(
				pluginPath,
				[
					"await new Promise(() => {});",
					"export default {",
					"  name: 'sandbox-import-hang',",
					"  manifest: { capabilities: ['tools'] },",
					"};",
				].join("\n"),
				"utf8",
			);

			// Set env override well below the 4000 ms hardcoded default.
			// If the env var isn't read, this test would block for ~4 s and
			// the per-test timeout (3000 ms below) would fail it.
			vi.stubEnv("CLINE_PLUGIN_IMPORT_TIMEOUT_MS", "150");
			await expect(
				loadSandboxedPlugins({ pluginPaths: [pluginPath] }),
			).rejects.toThrow(/timed out/i);
		} finally {
			vi.unstubAllEnvs();
			await rm(envDir, { recursive: true, force: true });
		}
	}, 3000);

	it("reclaims an idle plugin process and reinitializes it on the next call", async () => {
		const idleDir = await mkdtemp(join(tmpdir(), "core-plugin-sandbox-idle-"));
		let sandboxed: Awaited<ReturnType<typeof loadSandboxedPlugins>> | undefined;
		try {
			const pluginPath = join(idleDir, "plugin-idle.mjs");
			await writeFile(
				pluginPath,
				[
					"export default {",
					"  name: 'sandbox-idle',",
					"  manifest: { capabilities: ['tools'] },",
					"  setup(api) {",
					"    api.registerTool({",
					"      name: 'sandbox_process_id',",
					"      description: 'return the sandbox process id',",
					"      inputSchema: { type: 'object', properties: {}, required: [] },",
					"      execute: async () => ({ pid: process.pid }),",
					"    });",
					"  },",
					"};",
				].join("\n"),
				"utf8",
			);

			vi.stubEnv(CLINE_PLUGIN_IDLE_TIMEOUT_MS_ENV, "1000");
			vi.useFakeTimers();
			sandboxed = await loadSandboxedPlugins({
				pluginPaths: [pluginPath],
				importTimeoutMs: 30_000,
			});
			const { tools, api } = createApiCapture();
			await sandboxed.extensions?.[0]?.setup?.(api, {});
			const tool = tools.find((entry) => entry.name === "sandbox_process_id");
			expect(tool).toBeDefined();

			const context = {
				agentId: "agent-1",
				conversationId: "conv-1",
				iteration: 1,
			} as AgentToolContext;
			const first = (await tool?.execute({}, context)) as { pid: number };

			await vi.advanceTimersByTimeAsync(1001);

			const second = (await tool?.execute({}, context)) as { pid: number };
			expect(second.pid).not.toBe(first.pid);
		} finally {
			vi.useRealTimers();
			vi.unstubAllEnvs();
			await sandboxed?.shutdown();
			await rm(idleDir, { recursive: true, force: true });
		}
	}, 60_000);

	it("forwards sandbox plugin events to the host", async () => {
		const extension = sharedExtensions.get("sandbox-events");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const tool = tools.find((entry) => entry.name === "emit_event");
		await tool?.execute({ value: "hello" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(forwardedEvents).toEqual([
			{
				name: "test_event",
				payload: { value: "hello" },
			},
		]);
	});

	it("selects sibling, then source, then installed bootstrap candidates", async () => {
		const { selectBootstrapCandidate } = await import("./plugin-sandbox");
		const makeExists = (existing: string[]) => (path: string) =>
			existing.includes(path);

		// Compiled bundle: the sibling bootstrap matches the host build.
		expect(
			selectBootstrapCandidate({
				siblingCandidates: ["/dist/extensions/plugin-sandbox-bootstrap.js"],
				sourceBootstrapPath: "/src/plugin-sandbox-bootstrap.ts",
				installedCandidates: ["/wrapper/extensions/bootstrap.js"],
				exists: makeExists([
					"/dist/extensions/plugin-sandbox-bootstrap.js",
					"/wrapper/extensions/bootstrap.js",
				]),
			}),
		).toEqual({ file: "/dist/extensions/plugin-sandbox-bootstrap.js" });

		// Source host: the source bootstrap must win over a separately
		// installed CLI package's compiled bootstrap. A published bootstrap
		// resolves modules against the other installation's layout and
		// silently breaks plugin loading for the source host.
		expect(
			selectBootstrapCandidate({
				siblingCandidates: ["/src/plugin-sandbox-bootstrap.js"],
				sourceBootstrapPath: "/src/plugin-sandbox-bootstrap.ts",
				installedCandidates: ["/wrapper/extensions/bootstrap.js"],
				exists: makeExists([
					"/src/plugin-sandbox-bootstrap.ts",
					"/wrapper/extensions/bootstrap.js",
				]),
			}),
		).toEqual({ sourcePath: "/src/plugin-sandbox-bootstrap.ts" });

		// Compiled binary (bunfs import.meta): nothing exists on disk next to
		// the module, so the installed wrapper bootstrap is the right one.
		expect(
			selectBootstrapCandidate({
				siblingCandidates: ["/$bunfs/root/plugin-sandbox-bootstrap.js"],
				sourceBootstrapPath: "/$bunfs/root/plugin-sandbox-bootstrap.ts",
				installedCandidates: [undefined, "/wrapper/extensions/bootstrap.js"],
				exists: makeExists(["/wrapper/extensions/bootstrap.js"]),
			}),
		).toEqual({ file: "/wrapper/extensions/bootstrap.js" });
	});

	it("ignores the npm wrapper platform package bootstrap when running from source", async () => {
		const previousWrapperPath = process.env.CLINE_WRAPPER_PATH;
		const wrapperRoot = await mkdtemp(
			join(tmpdir(), "core-plugin-sandbox-wrapper-"),
		);
		const platform =
			process.platform === "win32" ? "windows" : process.platform;
		const packageRoot = join(
			wrapperRoot,
			"node_modules",
			"@cline",
			`cli-${platform}-${process.arch}`,
		);
		const wrapperBinDir = join(wrapperRoot, "bin");
		const bootstrapPath = join(
			packageRoot,
			"extensions",
			"plugin-sandbox-bootstrap.js",
		);
		const wrapperPath = join(wrapperBinDir, "cline");
		const events: Array<{ name: string; payload?: unknown }> = [];

		try {
			await mkdir(join(packageRoot, "extensions"), { recursive: true });
			await mkdir(wrapperBinDir, { recursive: true });
			await writeFile(wrapperPath, "#!/usr/bin/env node\n", "utf8");
			await writeFile(
				join(packageRoot, "package.json"),
				JSON.stringify({
					name: `@cline/cli-${platform}-${process.arch}`,
					version: "0.0.0-test",
					type: "module",
				}),
				"utf8",
			);
			await writeFile(
				bootstrapPath,
				[
					"process.on('message', (message) => {",
					"  if (!message || message.type !== 'call') return;",
					"  if (message.method !== 'initialize') throw new Error('Unexpected method: ' + message.method);",
					"  process.send?.({ type: 'event', name: 'wrapper_bootstrap_selected', payload: { ok: true } });",
					"  process.send?.({",
					"    type: 'response',",
					"    id: message.id,",
					"    ok: true,",
					"    result: {",
					"      plugins: [{",
					"        pluginId: 'plugin_1',",
					"        pluginPath: 'wrapper-bootstrap',",
					"        name: 'wrapper-bootstrap',",
					"        manifest: { capabilities: ['tools'] },",
					"        contributions: { tools: [], commands: [], messageBuilders: [], providers: [], automationEventTypes: [] },",
					"      }],",
					"      failures: [],",
					"      warnings: [],",
					"    },",
					"  });",
					"});",
				].join("\n"),
				"utf8",
			);

			process.env.CLINE_WRAPPER_PATH = wrapperPath;
			vi.resetModules();
			const { loadSandboxedPlugins: loadSandboxedPluginsFromWrapper } =
				await import("./plugin-sandbox");
			const sandboxed = await loadSandboxedPluginsFromWrapper({
				pluginPaths: [join(wrapperRoot, "unused-plugin.mjs")],
				onEvent: (event) => events.push(event),
			});

			try {
				// Regression: this host runs from source, so the sandbox must run
				// the source bootstrap, NOT the wrapper package's compiled one. The
				// fake wrapper bootstrap would report a "wrapper-bootstrap" plugin
				// and emit wrapper_bootstrap_selected; with the source bootstrap in
				// charge, the (nonexistent) plugin path simply fails to load.
				expect(
					sandboxed.extensions?.map((extension) => extension.name) ?? [],
				).toEqual([]);
				expect(events).not.toContainEqual({
					name: "wrapper_bootstrap_selected",
					payload: { ok: true },
				});
				expect(sandboxed.failures.length).toBeGreaterThan(0);
			} finally {
				await sandboxed.shutdown();
			}
		} finally {
			if (previousWrapperPath === undefined) {
				delete process.env.CLINE_WRAPPER_PATH;
			} else {
				process.env.CLINE_WRAPPER_PATH = previousWrapperPath;
			}
			vi.resetModules();
			await rm(wrapperRoot, { recursive: true, force: true });
		}
	});

	it("registers automation event types and forwards sandbox automation events", async () => {
		const extension = sharedExtensions.get("sandbox-automation-events");
		const { tools, automationEventTypes, api } = createApiCapture();
		await extension?.setup?.(api, {});
		expect(automationEventTypes).toEqual([
			expect.objectContaining({
				eventType: "local.plugin_event",
				source: "local-plugin",
			}),
		]);

		const tool = tools.find((entry) => entry.name === "emit_automation_event");
		await tool?.execute({ topic: "cron-feature-2" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(forwardedEvents).toEqual([
			{
				name: "automation_event",
				payload: expect.objectContaining({
					eventId: "plugin-cron-feature-2",
					eventType: "local.plugin_event",
					source: "local-plugin",
				}),
			},
		]);
	});

	it("runs run_end hooks in sandbox process", async () => {
		const extension = sharedExtensions.get("sandbox-run-end");
		expect(typeof extension?.hooks?.afterRun).toBe("function");
		await extension?.hooks?.afterRun?.({
			snapshot: makeSnapshot(),
			result: {
				agentId: "agent-1",
				runId: "run-1",
				status: "completed",
				iterations: 2,
				outputText: "done",
				messages: [],
				usage: {
					inputTokens: 1,
					outputTokens: 2,
					cacheReadTokens: 0,
					cacheWriteTokens: 0,
				},
			},
		});
		expect(forwardedEvents).toEqual([
			{
				name: "run_end_hook",
				payload: { finishReason: "completed", iterations: 2 },
			},
		]);
	});

	it("runs message builders in the sandbox process", async () => {
		const extension = sharedExtensions.get("sandbox-message-builder");
		const { messageBuilders, api } = createApiCapture();
		await extension?.setup?.(api, {});
		expect(messageBuilders).toHaveLength(1);
		const result = await messageBuilders[0]?.build([
			{ role: "user", content: [{ type: "text", text: "original" }] },
		]);
		expect(result).toEqual([
			{ role: "user", content: [{ type: "text", text: "original" }] },
			{
				role: "user",
				content: [{ type: "text", text: "from sandbox builder" }],
			},
		]);
	});

	it("registers prompt rules from sandbox plugins", async () => {
		const extension = sharedExtensions.get("sandbox-rules");
		const { rules, api } = createApiCapture();
		await extension?.setup?.(api, {});

		expect(rules).toHaveLength(2);
		expect(rules[0]).toEqual({
			id: "sandbox-rules:static",
			source: "sandbox-rules",
			content: "Static sandbox rule",
		});
		expect(rules[1]?.id).toBe("sandbox-rules:lazy");
		expect(rules[1]?.source).toBe("sandbox-rules");
		expect(typeof rules[1]?.content).toBe("function");
		if (typeof rules[1]?.content !== "function") {
			throw new Error("Expected lazy sandbox rule content handler");
		}
		const content = await rules[1].content();
		expect(content).toBe("Lazy sandbox rule 1");
	});

	it("loads TypeScript plugins in the sandbox process", async () => {
		const extension = sharedExtensions.get("sandbox-ts");
		expect(extension?.name).toBe("sandbox-ts");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const tool = tools.find((entry) => entry.name === "sandbox_ts_echo");
		expect(tool).toBeDefined();
		const result = await tool?.execute({ value: "ok" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(result).toEqual({ echoed: "ok" });
	});

	it("continues loading remaining sandbox plugins when one setup fails", async () => {
		const sandboxed = await loadSandboxedPlugins({
			pluginPaths: [
				join(dir, "plugin.mjs"),
				join(dir, "plugin-broken-setup.mjs"),
				join(dir, "plugin-events.mjs"),
			],
		});

		try {
			expect(sandboxed.extensions?.map((extension) => extension.name)).toEqual([
				"sandbox-test",
				"sandbox-events",
			]);
			expect(sandboxed.failures).toHaveLength(1);
			expect(sandboxed.failures[0]?.pluginName).toBe("sandbox-broken-setup");
			expect(sandboxed.failures[0]?.phase).toBe("setup");
		} finally {
			await sandboxed.shutdown();
		}
	});

	it("keeps the later duplicate sandbox plugin and reports the override", async () => {
		const sandboxed = await loadSandboxedPlugins({
			pluginPaths: [
				join(dir, "plugin-duplicate-a.mjs"),
				join(dir, "plugin-duplicate-b.mjs"),
			],
		});

		try {
			expect(sandboxed.extensions).toHaveLength(1);
			expect(sandboxed.extensions?.[0]?.name).toBe("sandbox-duplicate");
			expect(sandboxed.extensions?.[0]?.manifest.capabilities).toEqual([
				"commands",
			]);
			expect(sandboxed.warnings).toHaveLength(1);
			expect(sandboxed.warnings[0]?.overriddenPluginPath).toBe(
				join(dir, "plugin-duplicate-a.mjs"),
			);
		} finally {
			await sandboxed.shutdown();
		}
	});

	it("resolves plugin-local dependencies in the sandbox process", async () => {
		expect(sharedExtensions.get("sandbox-local-dep")?.name).toBe(
			"sandbox-local-dep",
		);
	});

	it("prefers plugin-installed SDK packages in the sandbox process", async () => {
		expect(sharedExtensions.get("sandbox-plugin-installed-sdk")?.name).toBe(
			"sandbox-plugin-installed-sdk",
		);
	});

	it("allows standalone file plugins to use host runtime dependencies in the sandbox", async () => {
		expect(sharedExtensions.get("host: true")?.name).toBe("host: true");
	});

	it("supports createTool through the agents package export in the sandbox", async () => {
		const extension = sharedExtensions.get("sandbox-create-tool");
		const { tools, api } = createApiCapture();
		await extension?.setup?.(api, {});
		const tool = tools.find((entry) => entry.name === "created_tool");
		expect(tool).toBeDefined();
		const result = await tool?.execute({ value: "ok" }, {
			agentId: "agent-1",
			conversationId: "conv-1",
			iteration: 1,
		} as AgentToolContext);
		expect(result).toEqual({ echoed: "ok" });
	});

	it("loads sandbox plugins matching manifest providerIds and modelIds", async () => {
		const matched = await loadSandboxedPlugins({
			pluginPaths: [join(dir, "plugin-targeted.mjs")],
			providerId: "openai",
			modelId: "gpt-5.4",
			importTimeoutMs: 30_000,
		});

		try {
			expect(matched.extensions?.map((extension) => extension.name)).toEqual([
				"sandbox-targeted",
			]);
		} finally {
			await matched.shutdown();
		}
	}, 15_000);

	it("filters sandbox plugins with non-matching manifest providerIds and modelIds", async () => {
		const filtered = await loadSandboxedPlugins({
			pluginPaths: [join(dir, "plugin-targeted.mjs")],
			providerId: "anthropic",
			modelId: "claude-sonnet-4.5",
			importTimeoutMs: 30_000,
		});

		try {
			expect(filtered.extensions).toEqual([]);
		} finally {
			await filtered.shutdown();
		}
	}, 15_000);
});
