// Replaces classic src/services/auth/AuthService.ts (see origin/main)
//
// SDK-backed authentication service. Uses @cline/core OAuth functions
// for login flows and ProviderSettingsManager (providers.json) as the
// single source of truth for credentials.
//
// User profile info (email, displayName, organizations) is NOT stored on
// disk — it's fetched from the Cline API on startup and cached in memory.
// This matches the CLI's pattern (see apps/cli/src/runtime/interactive-welcome.ts).

import type { ITelemetryService, OAuthCredentials, ProviderSettings } from "@cline/core"
import {
	createOAuthClientCallbacks,
	getProviderAuthStorageId,
	getValidClineCredentials,
	hashSecret,
	loginClineOAuth,
	loginOcaOAuth,
	loginOpenAICodex,
	sdkDebug,
} from "@cline/core"
import type { ApiProvider } from "@shared/api"
import { AuthState, UserInfo } from "@shared/proto/cline/account"
import type { EmptyRequest, String } from "@shared/proto/cline/common"
import { ShowMessageType } from "@shared/proto/host/window"
import axios from "axios"
import { ClineEnv } from "@/config"
import type { Controller } from "@/core/controller"
import { getRequestRegistry, type StreamingResponseHandler } from "@/core/controller/grpc-handler"
import { StateManager } from "@/core/storage/StateManager"
import { HostProvider } from "@/hosts/host-provider"
import { openAiCodexOAuthManager } from "@/integrations/openai-codex/oauth"
import { LogoutReason } from "@/services/auth/types"
import { BannerService } from "@/services/banner/BannerService"
import { buildBasicClineHeaders } from "@/services/EnvUtils"
import { featureFlagsService } from "@/services/feature-flags"
import { telemetryService } from "@/services/telemetry"
import { CLINE_API_ENDPOINT } from "@/shared/cline/api"
import { fetch, getAxiosSettings } from "@/shared/net"
import { Logger } from "@/shared/services/Logger"
import { openExternal } from "@/utils/env"
import { getProviderSettingsManager } from "./provider-migration"

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Shape of the auth info cached in memory (NOT persisted to disk). */
export interface ClineAuthInfo {
	idToken: string
	refreshToken?: string
	expiresAt?: number // seconds since epoch
	userInfo: ClineAccountUserInfo
	provider: string
	startedAt?: number
}

export interface ClineAccountUserInfo {
	createdAt?: string
	displayName: string
	email: string
	id: string
	organizations: ClineAccountOrganization[]
	appBaseUrl?: string
	subject?: string
}

export interface ClineAccountOrganization {
	active: boolean
	memberId: string
	name: string
	organizationId: string
	roles: string[]
}

// Single source for the logout-reason vocabulary; re-exported here so SDK-side
// callers (SdkController, extension.ts) keep importing it from this module.
export { LogoutReason }

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const WORKOS_TOKEN_PREFIX = "workos:"

type AuthMetadata = Record<string, unknown>

function getAuthMetadata(auth: ProviderSettings["auth"]): AuthMetadata | undefined {
	if (!auth) return undefined

	const metadata = (auth as { metadata?: unknown }).metadata
	return metadata && typeof metadata === "object" && !Array.isArray(metadata) ? (metadata as AuthMetadata) : undefined
}

function readSessionStartedAtMs(metadata: AuthMetadata | undefined): number | undefined {
	if (!metadata) return undefined

	const value = metadata.sessionStartedAtMs
	return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined
}

// ---------------------------------------------------------------------------
// providers.json helpers
// ---------------------------------------------------------------------------

/**
 * Read Cline OAuth credentials from providers.json.
 * Returns { accessToken, refreshToken, expiresAt, accountId } or null.
 */
function readClineCredentials(): {
	accessToken: string
	refreshToken?: string
	expiresAt?: number // milliseconds since epoch (providers.json convention)
	accountId?: string
	sessionStartedAtMs?: number // milliseconds since epoch
} | null {
	try {
		const manager = getProviderSettingsManager()
		const settings = manager.getProviderSettings("cline")
		if (!settings?.auth?.accessToken) {
			sdkDebug("[SdkAuthService] readClineCredentials: no auth.accessToken found")
			return null
		}

		// Strip workos: prefix if present (providers.json stores it with prefix)
		let accessToken = settings.auth.accessToken
		if (accessToken.toLowerCase().startsWith(WORKOS_TOKEN_PREFIX)) {
			accessToken = accessToken.slice(WORKOS_TOKEN_PREFIX.length)
		}

		const result = {
			accessToken,
			refreshToken: settings.auth.refreshToken,
			expiresAt: (settings.auth as { expiresAt?: number }).expiresAt,
			accountId: settings.auth.accountId,
			sessionStartedAtMs: readSessionStartedAtMs(getAuthMetadata(settings.auth)),
		}
		sdkDebug(
			`[SdkAuthService] readClineCredentials: found credentials (accessHash=${hashSecret(result.accessToken)}, refreshHash=${hashSecret(result.refreshToken)}, expiresAt=${result.expiresAt}, sessionStartedAtMs=${result.sessionStartedAtMs})`,
		)
		return result
	} catch (error) {
		Logger.error("[SdkAuthService] Failed to read credentials from providers.json:", error)
		return null
	}
}

/**
 * Write Cline OAuth credentials to providers.json.
 */
function writeClineCredentials(credentials: {
	accessToken: string
	refreshToken?: string
	expiresAt?: number // milliseconds since epoch
	accountId?: string
	metadata?: AuthMetadata
	sessionStartedAtMs?: number // milliseconds since epoch
}): void {
	try {
		const manager = getProviderSettingsManager()
		const existing = manager.getProviderSettings("cline")
		const existingMetadata = getAuthMetadata(existing?.auth)
		const sessionStartedAtMs =
			credentials.sessionStartedAtMs ??
			readSessionStartedAtMs(credentials.metadata) ??
			readSessionStartedAtMs(existingMetadata)

		const auth = {
			...(existing?.auth ?? {}),
			accessToken: `${WORKOS_TOKEN_PREFIX}${credentials.accessToken}`,
			refreshToken: credentials.refreshToken,
			accountId: credentials.accountId,
		} as Record<string, unknown>
		const incomingMetadata = Object.fromEntries(
			Object.entries(credentials.metadata ?? {}).filter(([, value]) => value !== undefined),
		)
		const metadata = { ...(existingMetadata ?? {}), ...incomingMetadata }
		delete metadata.startedAt
		if (sessionStartedAtMs !== undefined) {
			metadata.sessionStartedAtMs = sessionStartedAtMs
		}
		if (Object.keys(metadata).length > 0) {
			auth.metadata = metadata
		}
		if (credentials.expiresAt !== undefined) {
			auth.expiresAt = credentials.expiresAt
		}

		// Token refreshes and startup restores also land here. Only claim the
		// last-used slot when the current selection isn't already a provider
		// backed by this credential entry (cline-pass stores under "cline") —
		// otherwise every refresh resets a ClinePass selection back to
		// usage-billing in the shared providers.json (#13501).
		const lastUsedProvider = manager.read().lastUsedProvider
		const setLastUsed = getProviderAuthStorageId(lastUsedProvider ?? "") !== "cline"

		manager.saveProviderSettings(
			{
				...(existing ?? { provider: "cline" }),
				provider: "cline",
				auth: auth as { accessToken?: string; refreshToken?: string; accountId?: string; metadata?: AuthMetadata },
			},
			{ tokenSource: "oauth", setLastUsed },
		)
		sdkDebug(
			`[SdkAuthService] writeClineCredentials: wrote (accessHash=${hashSecret(credentials.accessToken)}, refreshHash=${hashSecret(credentials.refreshToken)}, expiresAt=${credentials.expiresAt}, sessionStartedAtMs=${sessionStartedAtMs})`,
		)
	} catch (error) {
		Logger.error("[SdkAuthService] Failed to write credentials to providers.json:", error)
	}
}

/**
 * Clear Cline OAuth credentials from providers.json.
 */
function clearClineCredentials(): void {
	try {
		const manager = getProviderSettingsManager()
		const existing = manager.getProviderSettings("cline")
		if (existing) {
			sdkDebug("[SdkAuthService] clearClineCredentials: clearing auth from providers.json")
			manager.saveProviderSettings(
				{
					...existing,
					provider: "cline",
					auth: undefined,
				},
				{ tokenSource: "manual" },
			)
		}
	} catch (error) {
		Logger.error("[SdkAuthService] Failed to clear credentials from providers.json:", error)
	}
}

// ---------------------------------------------------------------------------
// AuthService
// ---------------------------------------------------------------------------

export class AuthService {
	private static instance: AuthService | null = null

	private _authenticated = false
	private _clineAuthInfo: ClineAuthInfo | null = null
	private _activeAuthStatusUpdateHandlers = new Set<StreamingResponseHandler<AuthState>>()
	private _handlerToController = new Map<StreamingResponseHandler<AuthState>, Controller>()
	private _refreshPromise: Promise<string | undefined> | null = null
	private _telemetry?: ITelemetryService

	private constructor() {}

	/**
	 * Gets the singleton instance of AuthService.
	 * On first call with a controller, initializes BannerService.
	 */
	public static getInstance(controller?: Controller, telemetry?: ITelemetryService): AuthService {
		if (!AuthService.instance) {
			AuthService.instance = new AuthService()
		}
		if (telemetry) {
			AuthService.instance._telemetry = telemetry
		}
		// Initialize BannerService on first call with a controller
		// (mirrors classic AuthService behavior)
		if (controller) {
			try {
				BannerService.initialize(controller)
			} catch {
				// BannerService may already be initialized — that's fine
			}
		}
		return AuthService.instance
	}

	set controller(_controller: Controller) {
		// Kept for interface compatibility — not needed in SDK-backed version
	}

	// ---- SDK OAuth → ClineAuthInfo conversion ----

	/**
	 * Convert SDK OAuthCredentials to our ClineAuthInfo format.
	 * Also fetches full user info from the Cline API.
	 */
	private async credentialsToAuthInfo(credentials: OAuthCredentials, provider: string): Promise<ClineAuthInfo> {
		// Fetch full user info from the API using the access token
		const userInfo = await this.fetchUserInfoFromApi(credentials.access)
		const startedAt = readSessionStartedAtMs(credentials.metadata)

		return {
			idToken: credentials.access,
			refreshToken: credentials.refresh,
			expiresAt: credentials.expires ? credentials.expires / 1000 : undefined, // SDK uses ms, we store seconds
			userInfo: userInfo ?? {
				id: credentials.accountId ?? "",
				email: credentials.email ?? "",
				displayName: "",
				organizations: [],
			},
			provider,
			startedAt,
		}
	}

	/**
	 * Fetch user info from the Cline API using an access token.
	 */
	private async fetchUserInfoFromApi(accessToken: string): Promise<ClineAccountUserInfo | null> {
		try {
			const apiBaseUrl = ClineEnv.config().apiBaseUrl
			// Ensure the token has the workos: prefix for the API
			const bearerToken = accessToken.toLowerCase().startsWith(WORKOS_TOKEN_PREFIX)
				? accessToken
				: `${WORKOS_TOKEN_PREFIX}${accessToken}`
			sdkDebug(
				`[SdkAuthService] fetchUserInfoFromApi: GET ${apiBaseUrl}/api/v1/users/me (tokenHash=${hashSecret(accessToken)})`,
			)
			const response = await axios.get(`${apiBaseUrl}/api/v1/users/me`, {
				headers: {
					Authorization: `Bearer ${bearerToken}`,
					"Content-Type": "application/json",
					...(await buildBasicClineHeaders()),
				},
				...getAxiosSettings(),
			})
			sdkDebug(`[SdkAuthService] fetchUserInfoFromApi: response status=${response.status}`)
			return response.data?.data ?? null
		} catch (error) {
			Logger.error("[SdkAuthService] Failed to fetch user info from API:", error)
			return null
		}
	}

	private toOAuthCredentials(authInfo: ClineAuthInfo): OAuthCredentials {
		return {
			access: authInfo.idToken,
			refresh: authInfo.refreshToken ?? "",
			expires: authInfo.expiresAt ? authInfo.expiresAt * 1000 : 0,
			accountId: authInfo.userInfo.id || undefined,
			email: authInfo.userInfo.email || undefined,
			metadata: authInfo.startedAt ? { sessionStartedAtMs: authInfo.startedAt } : undefined,
		}
	}

	private async resolveValidClineCredentials(
		authInfo: ClineAuthInfo,
		options?: { forceRefresh?: boolean },
	): Promise<OAuthCredentials | null> {
		if (options?.forceRefresh && !authInfo.refreshToken) {
			return null
		}

		return getValidClineCredentials(
			this.toOAuthCredentials(authInfo),
			{ apiBaseUrl: ClineEnv.config().apiBaseUrl, telemetry: this._telemetry },
			{ forceRefresh: options?.forceRefresh },
		)
	}

	// ---- Public API (used by gRPC handlers) ----

	/**
	 * Returns the current authentication token with the `workos:` prefix.
	 * Refreshes if necessary using the SDK's token management.
	 */
	async getAuthToken(): Promise<string | null> {
		if (!this._clineAuthInfo?.idToken) {
			return null
		}

		// Check if we need to refresh
		const expiresAt = this._clineAuthInfo.expiresAt
		if (expiresAt) {
			const currentTime = Date.now() / 1000
			const bufferSeconds = 5 * 60 // 5 minute buffer
			if (currentTime + bufferSeconds >= expiresAt) {
				// Token is expired or about to expire — try to refresh
				const refreshed = await this.refreshAccessToken()
				if (!refreshed) {
					return null
				}
			}
		}

		// Verify the token is still valid (not past expiry). Re-read the expiry:
		// a successful refresh above replaces _clineAuthInfo, and the expiry
		// captured before it belongs to the old token — which has already passed
		// whenever the process sat idle beyond token lifetime.
		const currentExpiresAt = this._clineAuthInfo.expiresAt
		if (currentExpiresAt && Date.now() / 1000 >= currentExpiresAt) {
			return null
		}

		return `${WORKOS_TOKEN_PREFIX}${this._clineAuthInfo.idToken}`
	}

	/**
	 * Refresh the access token using the SDK's shared Cline credential validator.
	 * Persists refreshed credentials to providers.json when credentials change.
	 */
	private async refreshAccessToken(): Promise<boolean> {
		if (this._refreshPromise) {
			await this._refreshPromise
			return this._clineAuthInfo?.idToken !== undefined
		}

		if (!this._clineAuthInfo?.refreshToken) {
			sdkDebug("[SdkAuthService] refreshAccessToken: no refresh token available")
			return false
		}

		sdkDebug(`[SdkAuthService] refreshAccessToken: starting (currentTokenHash=${hashSecret(this._clineAuthInfo.idToken)})`)
		this._refreshPromise = (async () => {
			try {
				const currentInfo = this._clineAuthInfo
				if (!currentInfo) {
					return undefined
				}
				const newCredentials = await this.resolveValidClineCredentials(currentInfo, { forceRefresh: true })
				if (!newCredentials) {
					// null means the refresh token was rejected (transient failures
					// throw). The SDK resolver already emitted user.auth_logged_out
					// (reason=token_invalid) for this — don't double-report here.
					sdkDebug("[SdkAuthService] refreshAccessToken: refresh returned null — clearing credentials")
					this._clineAuthInfo = null
					this._authenticated = false
					clearClineCredentials()
					setImmediate(() => {
						this.sendAuthStatusUpdate().catch(() => {})
					})
					return undefined
				}

				const credentialsChanged =
					newCredentials.access !== currentInfo.idToken ||
					newCredentials.refresh !== (currentInfo.refreshToken ?? "") ||
					(newCredentials.expires ? newCredentials.expires / 1000 : undefined) !== currentInfo.expiresAt ||
					(newCredentials.accountId ?? "") !== currentInfo.userInfo.id

				const userInfo = credentialsChanged
					? await this.fetchUserInfoFromApi(newCredentials.access)
					: currentInfo.userInfo
				this._clineAuthInfo = {
					idToken: newCredentials.access,
					refreshToken: newCredentials.refresh,
					expiresAt: newCredentials.expires ? newCredentials.expires / 1000 : undefined,
					userInfo: userInfo ?? currentInfo.userInfo,
					provider: currentInfo.provider,
					startedAt: currentInfo.startedAt,
				}
				this._authenticated = true

				if (credentialsChanged) {
					sdkDebug(
						`[SdkAuthService] refreshAccessToken: credentials changed (newTokenHash=${hashSecret(newCredentials.access)})`,
					)
					writeClineCredentials({
						accessToken: newCredentials.access,
						refreshToken: newCredentials.refresh,
						expiresAt: newCredentials.expires,
						accountId: this._clineAuthInfo.userInfo.id,
						metadata: newCredentials.metadata,
						sessionStartedAtMs: readSessionStartedAtMs(newCredentials.metadata),
					})

					setImmediate(() => {
						this.sendAuthStatusUpdate().catch((err) => {
							Logger.error("[SdkAuthService] Error sending auth status update after refresh:", err)
						})
					})
				} else {
					sdkDebug("[SdkAuthService] refreshAccessToken: credentials unchanged after refresh")
				}

				return this._clineAuthInfo.idToken
			} catch (error) {
				Logger.error("[SdkAuthService] Token refresh failed:", error)
				return undefined
			} finally {
				this._refreshPromise = null
			}
		})()

		const result = await this._refreshPromise
		return result !== undefined
	}

	/**
	 * Gets the active organization ID from the authenticated user's info.
	 */
	getActiveOrganizationId(): string | null {
		if (!this._clineAuthInfo?.userInfo?.organizations) return null
		const activeOrg = this._clineAuthInfo.userInfo.organizations.find((org) => org.active)
		return activeOrg?.organizationId ?? null
	}

	/**
	 * Gets all organizations from the authenticated user's info.
	 */
	getUserOrganizations(): ClineAccountOrganization[] | undefined {
		return this._clineAuthInfo?.userInfo?.organizations
	}

	/**
	 * Gets the provider name for the current authentication.
	 */
	getProviderName(): string | null {
		return this._clineAuthInfo?.provider ?? null
	}

	/**
	 * Returns the current auth state for the webview.
	 */
	getInfo(): AuthState {
		if (this._clineAuthInfo && this._authenticated) {
			const userInfo = this._clineAuthInfo.userInfo
			userInfo.appBaseUrl = ClineEnv.config().appBaseUrl

			const user = UserInfo.create({
				uid: userInfo?.id,
				displayName: userInfo?.displayName,
				email: userInfo?.email,
				photoUrl: undefined,
				appBaseUrl: userInfo?.appBaseUrl,
			})
			return AuthState.create({ user })
		}

		return AuthState.create({})
	}

	// ---- Login flows ----

	/**
	 * A successful login completes onboarding. The onboarding webview does NOT
	 * set this flag for OAuth sign-ups — it waits on the "Almost there!" step
	 * until the host confirms authentication (parity with the classic
	 * extension, where Controller.handleAuthCallback set it post-exchange).
	 */
	private markWelcomeViewCompleted(): void {
		try {
			StateManager.get().setGlobalState("welcomeViewCompleted", true)
		} catch (error) {
			Logger.error("[SdkAuthService] Failed to mark welcome view completed:", error)
		}
	}

	/**
	 * Initiate Cline OAuth login.
	 * Uses SDK's loginClineOAuth() which spawns a local callback server.
	 * Persists credentials to providers.json.
	 */
	async createAuthRequest(strict = false): Promise<String> {
		// In strict mode, don't open a new auth window if already authenticated
		if (strict && this._authenticated) {
			await this.sendAuthStatusUpdate()
			const { String: ProtoString } = await import("@shared/proto/cline/common")
			return ProtoString.create({ value: "Already authenticated" })
		}

		// E2E test mode: authenticate against the local mock API server instead
		// of loginClineOAuth(), which opens a real browser window the tests can't
		// interact with. Replaces classic AuthServiceMock (see origin/main
		// src/services/auth/AuthServiceMock.ts).
		if (process.env.E2E_TEST === "true") {
			return this.createMockAuthRequest()
		}

		let resolveAuthMessage!: (message: string) => void
		let rejectAuthMessage!: (error: unknown) => void
		const authMessagePromise = new Promise<string>((resolve, reject) => {
			resolveAuthMessage = resolve
			rejectAuthMessage = reject
		})

		void (async () => {
			try {
				const apiBaseUrl = ClineEnv.config().apiBaseUrl
				const credentials = await loginClineOAuth({
					apiBaseUrl,
					// Use WorkOS device auth so the browser confirmation code can be surfaced in the extension.
					useWorkOSDeviceAuth: true,
					headers: await buildBasicClineHeaders(),
					callbacks: createOAuthClientCallbacks({
						onOutput: (message) => {
							resolveAuthMessage(message)
						},
						onPrompt: async (prompt) => prompt.defaultValue ?? "",
						openUrl: async (url: string) => {
							resolveAuthMessage(url)
							await openExternal(url)
						},
						onOpenUrlError: ({ url, error }) => {
							Logger.error(`[SdkAuthService] Failed to open browser for ${url}:`, error)
						},
					}),
				})

				// Convert and persist to providers.json
				const authInfo = await this.credentialsToAuthInfo(credentials, "cline")
				this._clineAuthInfo = authInfo
				this._authenticated = true

				writeClineCredentials({
					accessToken: credentials.access,
					refreshToken: credentials.refresh,
					expiresAt: credentials.expires,
					accountId: authInfo.userInfo.id || credentials.accountId,
					metadata: credentials.metadata,
					sessionStartedAtMs: authInfo.startedAt,
				})

				// Set before pushing state so the same update moves the webview
				// from the welcome view to chat.
				this.markWelcomeViewCompleted()

				// Push auth state update
				await this.sendAuthStatusUpdate()

				// Notify BannerService of auth change (mirrors classic AuthService)
				BannerService.onAuthUpdate(authInfo.userInfo?.id || null).catch((error) => {
					Logger.error("[SdkAuthService] Banner update failed after login", error)
				})
			} catch (error) {
				rejectAuthMessage(error)
				Logger.error("[SdkAuthService] Cline OAuth login failed:", error)
			}
		})()

		const { String: ProtoString } = await import("@shared/proto/cline/common")
		return ProtoString.create({ value: await authMessagePromise })
	}

	/**
	 * E2E test login: exchange a well-known test code with the local mock API
	 * server (src/test/e2e/fixtures/server) for tokens, with no browser
	 * interaction. Replaces classic AuthServiceMock.createAuthRequest().
	 */
	private async createMockAuthRequest(): Promise<String> {
		if (ClineEnv.config().environment !== "local") {
			throw new Error("E2E mock auth is only available when CLINE_ENVIRONMENT=local")
		}

		const apiBaseUrl = ClineEnv.config().apiBaseUrl
		const tokenUrl = new URL(CLINE_API_ENDPOINT.TOKEN_EXCHANGE, apiBaseUrl)
		const response = await fetch(tokenUrl.toString(), {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...(await buildBasicClineHeaders()),
			},
			body: JSON.stringify({
				code: "test-personal-token",
				grantType: "authorization_code",
			}),
		})
		if (!response.ok) {
			throw new Error(`Mock server authentication failed: ${response.status} ${response.statusText}`)
		}
		const responseJSON = await response.json()
		const tokenData = responseJSON?.data
		if (!responseJSON?.success || !tokenData?.accessToken) {
			throw new Error("Invalid response from mock server")
		}

		const sessionStartedAtMs = Date.now()
		this._clineAuthInfo = {
			idToken: tokenData.accessToken,
			refreshToken: tokenData.refreshToken,
			expiresAt: new Date(tokenData.expiresAt).getTime() / 1000,
			userInfo: {
				id: tokenData.userInfo?.clineUserId || tokenData.userInfo?.subject || "",
				email: tokenData.userInfo?.email || "",
				displayName: tokenData.userInfo?.name || "",
				createdAt: new Date().toISOString(),
				organizations: tokenData.userInfo?.organizations ?? [],
				appBaseUrl: ClineEnv.config().appBaseUrl,
				subject: tokenData.userInfo?.subject,
			},
			provider: "cline",
			startedAt: sessionStartedAtMs,
		}
		this._authenticated = true

		// Persist to providers.json so session config resolution
		// (resolveApiKey) and provider-usability checks see the credentials.
		writeClineCredentials({
			accessToken: tokenData.accessToken,
			refreshToken: tokenData.refreshToken,
			expiresAt: new Date(tokenData.expiresAt).getTime(),
			accountId: this._clineAuthInfo.userInfo.id,
			metadata: { sessionStartedAtMs },
			sessionStartedAtMs,
		})

		this.markWelcomeViewCompleted()

		await this.sendAuthStatusUpdate()
		Logger.log(`[SdkAuthService] E2E mock login completed as ${this._clineAuthInfo.userInfo.email}`)

		const { String: ProtoString } = await import("@shared/proto/cline/common")
		return ProtoString.create({ value: apiBaseUrl })
	}

	/**
	 * Initiate OCA OAuth login.
	 */
	async ocaLogin(): Promise<String> {
		try {
			const callbacks = createOAuthClientCallbacks({
				onPrompt: async (prompt) => prompt.defaultValue ?? "",
				openUrl: async (url: string) => {
					await openExternal(url)
				},
				onOpenUrlError: ({ url, error }) => {
					Logger.error(`[SdkAuthService] Failed to open browser for OCA: ${url}:`, error)
				},
			})

			const credentials = await loginOcaOAuth({ callbacks })

			const authInfo = await this.credentialsToAuthInfo(credentials, "oca")
			this._clineAuthInfo = authInfo
			this._authenticated = true

			writeClineCredentials({
				accessToken: credentials.access,
				refreshToken: credentials.refresh,
				expiresAt: credentials.expires,
				accountId: authInfo.userInfo.id || credentials.accountId,
				metadata: credentials.metadata,
				sessionStartedAtMs: authInfo.startedAt,
			})

			await this.sendAuthStatusUpdate()

			const { String: ProtoString } = await import("@shared/proto/cline/common")
			return ProtoString.create({ value: "Authenticated" })
		} catch (error) {
			Logger.error("[SdkAuthService] OCA OAuth login failed:", error)
			throw error
		}
	}

	/**
	 * Initiate OpenAI Codex OAuth login.
	 */
	async openAiCodexLogin(): Promise<void> {
		try {
			const callbacks = createOAuthClientCallbacks({
				onPrompt: async (prompt) => prompt.defaultValue ?? "",
				openUrl: async (url: string) => {
					// E2E drives the OAuth callback itself (codex-oauth.test.ts).
					// Opening a real browser on the runner leaves an orphaned
					// process holding the Playwright<->Electron pipes, which
					// wedges the worker teardown until its 60s timeout fails
					// the job.
					if (process.env.E2E_TEST === "true") {
						return
					}
					await openExternal(url)
				},
				onOpenUrlError: ({ url, error }) => {
					// Same recovery the CLI offers ("open the URL above manually") —
					// the toast is the extension's only place to surface the URL.
					Logger.error(`[SdkAuthService] Failed to open browser for Codex: ${url}:`, error)
					HostProvider.window.showMessage({
						type: ShowMessageType.ERROR,
						message: `Couldn't open your browser for OpenAI sign-in. Open this URL manually: ${url}`,
					})
				},
			})

			const credentials = await loginOpenAICodex(callbacks)

			// Store Codex credentials in providers.json
			await this.saveCodexCredentials(credentials)
			await openAiCodexOAuthManager.saveCredentials({
				type: "openai-codex",
				access_token: credentials.access,
				refresh_token: credentials.refresh,
				expires: credentials.expires,
				email: credentials.email,
				accountId: credentials.accountId,
			})

			// Notify webview of state change
			await this.sendAuthStatusUpdate()
		} catch (error) {
			Logger.error("[SdkAuthService] OpenAI Codex OAuth login failed:", error)
			throw error
		}
	}

	/**
	 * Save Codex OAuth credentials to provider settings.
	 */
	private async saveCodexCredentials(credentials: OAuthCredentials): Promise<void> {
		try {
			const manager = getProviderSettingsManager()
			const existing = manager.getProviderSettings("openai-codex")

			manager.saveProviderSettings(
				{
					...(existing ?? { provider: "openai-codex" }),
					provider: "openai-codex",
					auth: {
						accessToken: credentials.access,
						refreshToken: credentials.refresh,
						accountId: credentials.accountId,
					},
				},
				{ tokenSource: "oauth" },
			)
		} catch (error) {
			Logger.error("[SdkAuthService] Failed to save Codex credentials:", error)
		}
	}

	/**
	 * Clear Codex credentials from provider settings.
	 */
	async clearCodexCredentials(): Promise<void> {
		try {
			await openAiCodexOAuthManager.clearCredentials()

			const manager = getProviderSettingsManager()
			const existing = manager.getProviderSettings("openai-codex")
			if (existing) {
				manager.saveProviderSettings(
					{
						...existing,
						provider: "openai-codex",
						auth: undefined,
					},
					{ tokenSource: "manual" },
				)
			}
		} catch (error) {
			Logger.error("[SdkAuthService] Failed to clear Codex credentials:", error)
		}
	}

	// ---- Logout ----

	/**
	 * Handle deauthentication — clear tokens from providers.json and push unauthenticated state.
	 */
	async handleDeauth(reason: LogoutReason = LogoutReason.UNKNOWN): Promise<void> {
		try {
			telemetryService.captureAuthLoggedOut("cline", reason)
			this._clineAuthInfo = null
			this._authenticated = false
			clearClineCredentials()
			await this.sendAuthStatusUpdate()

			// Notify BannerService of auth change (mirrors classic AuthService)
			BannerService.onAuthUpdate(null).catch((error) => {
				Logger.error("[SdkAuthService] Banner update failed after logout", error)
			})
		} catch (error) {
			Logger.error("[SdkAuthService] Error signing out:", error)
			throw error
		}
	}

	/**
	 * Handle auth callback from URI handler.
	 * This is called when the browser redirects back to the extension after OAuth.
	 */
	async handleAuthCallback(authorizationCode: string, provider: string): Promise<void> {
		try {
			// Exchange the authorization code for tokens using the Cline API
			const apiBaseUrl = ClineEnv.config().apiBaseUrl
			const callbackUrl = await HostProvider.get().getCallbackUrl("/auth")

			const tokenUrl = new URL(CLINE_API_ENDPOINT.TOKEN_EXCHANGE, apiBaseUrl)
			const response = await fetch(tokenUrl.toString(), {
				method: "POST",
				headers: {
					Accept: "application/json",
					"Content-Type": "application/json",
					...(await buildBasicClineHeaders()),
				},
				body: JSON.stringify({
					grant_type: "authorization_code",
					code: authorizationCode,
					client_type: "extension",
					redirect_uri: callbackUrl,
					provider: provider,
				}),
			})

			if (!response.ok) {
				const errorData = await response.json().catch(() => ({}))
				throw new Error(errorData.error_description || "Failed to exchange authorization code for tokens")
			}

			const responseJSON = await response.json()
			const tokenData = responseJSON.data

			if (!tokenData.accessToken || !tokenData.refreshToken || !tokenData.userInfo) {
				throw new Error("Invalid token response from server")
			}

			// Fetch full user info
			const userInfo = await this.fetchUserInfoFromApi(tokenData.accessToken)

			const sessionStartedAtMs = Date.now()
			const authInfo: ClineAuthInfo = {
				idToken: tokenData.accessToken,
				refreshToken: tokenData.refreshToken,
				userInfo: userInfo ?? {
					id: tokenData.userInfo.clineUserId || "",
					email: tokenData.userInfo.email || "",
					displayName: tokenData.userInfo.name || "",
					createdAt: new Date().toISOString(),
					organizations: [],
				},
				expiresAt: new Date(tokenData.expiresAt).getTime() / 1000,
				provider: "cline",
				startedAt: sessionStartedAtMs,
			}

			this._clineAuthInfo = authInfo
			this._authenticated = true

			// Persist to providers.json
			writeClineCredentials({
				accessToken: tokenData.accessToken,
				refreshToken: tokenData.refreshToken,
				expiresAt: new Date(tokenData.expiresAt).getTime(),
				accountId: authInfo.userInfo.id,
				metadata: {
					provider,
					sessionStartedAtMs,
					tokenType: tokenData.tokenType,
					userInfo: tokenData.userInfo,
				},
				sessionStartedAtMs,
			})

			this.markWelcomeViewCompleted()

			await this.sendAuthStatusUpdate()
		} catch (error) {
			Logger.error("[SdkAuthService] Error handling auth callback:", error)
			throw error
		}
	}

	/**
	 * Handle OCA auth callback.
	 */
	async handleOcaAuthCallback(_code: string, _state: string): Promise<void> {
		// OCA uses SDK's local callback server, so this shouldn't normally be called.
		// Keeping it as a stub for interface compatibility.
		Logger.warn("[SdkAuthService] handleOcaAuthCallback called — OCA uses SDK callback server")
	}

	// ---- Restore auth on startup ----

	/**
	 * Restore authentication from providers.json on startup.
	 *
	 * Reads tokens from providers.json, refreshes if needed, then fetches
	 * user profile from the API. This matches the CLI's pattern — credentials
	 * live in providers.json, user info is fetched fresh each session.
	 */
	async restoreRefreshTokenAndRetrieveAuthInfo(): Promise<void> {
		try {
			const creds = readClineCredentials()
			if (!creds) {
				this._authenticated = false
				this._clineAuthInfo = null
				return
			}

			const restoredAuthInfo: ClineAuthInfo = {
				idToken: creds.accessToken,
				refreshToken: creds.refreshToken,
				expiresAt: creds.expiresAt ? creds.expiresAt / 1000 : undefined, // providers.json uses ms, we use seconds
				userInfo: {
					id: creds.accountId ?? "",
					email: "",
					displayName: "",
					organizations: [],
				},
				provider: "cline",
				startedAt: creds.sessionStartedAtMs,
			}

			let validCredentials: OAuthCredentials | null
			try {
				validCredentials = await this.resolveValidClineCredentials(restoredAuthInfo)
			} catch (error) {
				// The resolver throws only on transient failures (network,
				// timeout, 5xx) — stored credentials stay untouched and the next
				// refresh recovers automatically, so this is not a logout. The
				// SDK already books it as user.auth_refresh_soft_failure; only
				// the in-memory state is reset for this session.
				Logger.error("[SdkAuthService] Transient failure refreshing stored session on restore:", error)
				this._authenticated = false
				this._clineAuthInfo = null
				return
			}
			if (!validCredentials) {
				// null means the stored refresh token was rejected. The SDK
				// resolver already emitted user.auth_logged_out
				// (reason=token_invalid) for this — don't double-report here.
				this._authenticated = false
				this._clineAuthInfo = null
				clearClineCredentials()
				await this.sendAuthStatusUpdate()
				return
			}

			writeClineCredentials({
				accessToken: validCredentials.access,
				refreshToken: validCredentials.refresh,
				expiresAt: validCredentials.expires,
				accountId: validCredentials.accountId ?? restoredAuthInfo.userInfo.id,
				metadata: validCredentials.metadata,
				sessionStartedAtMs: readSessionStartedAtMs(validCredentials.metadata),
			})

			this._clineAuthInfo = {
				idToken: validCredentials.access,
				refreshToken: validCredentials.refresh,
				expiresAt: validCredentials.expires ? validCredentials.expires / 1000 : undefined,
				userInfo: {
					...restoredAuthInfo.userInfo,
					id: validCredentials.accountId ?? restoredAuthInfo.userInfo.id,
					email: validCredentials.email ?? restoredAuthInfo.userInfo.email,
				},
				provider: restoredAuthInfo.provider,
				startedAt: restoredAuthInfo.startedAt,
			}
			this._authenticated = true

			// Fetch full user info from the API (the key step — fills in
			// email, displayName, organizations that providers.json doesn't store)
			if (this._authenticated && this._clineAuthInfo) {
				const userInfo = await this.fetchUserInfoFromApi(this._clineAuthInfo.idToken)
				if (userInfo) {
					this._clineAuthInfo.userInfo = userInfo
				} else {
					Logger.warn("[SdkAuthService] Could not fetch user info on restore — UI will show limited profile")
				}
			}

			await this.sendAuthStatusUpdate()

			// Notify BannerService of auth change (mirrors classic AuthService)
			BannerService.onAuthUpdate(this._clineAuthInfo?.userInfo?.id || null).catch((error) => {
				Logger.error("[SdkAuthService] Banner update failed after restore", error)
			})
		} catch (error) {
			// Unexpected failure outside the credential refresh (reading or
			// writing providers.json, pushing auth state, …). Transient refresh
			// failures are handled above and never reach this reason.
			Logger.error("[SdkAuthService] Error restoring auth token:", error)
			telemetryService.captureAuthLoggedOut("cline", LogoutReason.RESTORE_ERROR)
			this._authenticated = false
			this._clineAuthInfo = null
		}
	}

	// ---- Streaming subscriptions ----

	/**
	 * Subscribe to authStatusUpdate events.
	 * Pushes initial auth state immediately on subscribe.
	 */
	async subscribeToAuthStatusUpdate(
		controller: Controller,
		_request: EmptyRequest,
		responseStream: StreamingResponseHandler<AuthState>,
		requestId?: string,
	): Promise<void> {
		this._activeAuthStatusUpdateHandlers.add(responseStream)
		this._handlerToController.set(responseStream, controller)

		const cleanup = () => {
			this._activeAuthStatusUpdateHandlers.delete(responseStream)
			this._handlerToController.delete(responseStream)
		}

		if (requestId) {
			getRequestRegistry().registerRequest(requestId, cleanup, { type: "authStatusUpdate_subscription" }, responseStream)
		}

		// Push initial auth state immediately (prevents race condition)
		try {
			await this.sendAuthStatusUpdate()
		} catch (error) {
			Logger.error("[SdkAuthService] Error sending initial auth status:", error)
			this._activeAuthStatusUpdateHandlers.delete(responseStream)
			this._handlerToController.delete(responseStream)
		}
	}

	/**
	 * Send an authStatusUpdate event to all active subscribers.
	 */
	async sendAuthStatusUpdate(): Promise<void> {
		const authState: AuthState = this.getInfo()
		const uniqueControllers = new Set<Controller>()

		const streamSends = Array.from(this._activeAuthStatusUpdateHandlers).map(async (responseStream) => {
			const controller = this._handlerToController.get(responseStream)
			if (controller) {
				uniqueControllers.add(controller)
			}
			try {
				await responseStream(authState, false)
			} catch (error) {
				Logger.error("[SdkAuthService] Error sending authStatusUpdate event:", error)
				this._activeAuthStatusUpdateHandlers.delete(responseStream)
				this._handlerToController.delete(responseStream)
			}
		})

		await Promise.all(streamSends)

		// Poll feature flags immediately for the current auth context so cache-only
		// consumers (for example BannerService) see the latest remote config.
		const authInfo = this._clineAuthInfo
		if (authInfo?.userInfo) {
			await telemetryService.identifyAccount(authInfo.userInfo)
		}
		const userId = authInfo?.userInfo?.id || null
		await featureFlagsService.poll(userId)
		for (const controller of uniqueControllers) {
			controller.invalidateProviderListings()
		}

		// Update state in webviews once per unique controller
		await Promise.all(Array.from(uniqueControllers).map((c) => c.postStateToWebview()))
	}

	// ---- Provider-specific auth callbacks ----

	/**
	 * Shared helper: set a provider's API key and switch both plan/act modes to it.
	 */
	private setProviderApiKey(provider: ApiProvider, apiKeyField: string, apiKey: string): void {
		const stateManager = StateManager.get()
		const currentApiConfiguration = stateManager.getApiConfiguration()
		const updatedConfig = {
			...currentApiConfiguration,
			planModeApiProvider: provider,
			actModeApiProvider: provider,
			[apiKeyField]: apiKey,
		}
		stateManager.setApiConfiguration(updatedConfig)
	}

	/**
	 * Handle OpenRouter OAuth callback.
	 */
	async handleOpenRouterCallback(code: string): Promise<void> {
		let apiKey: string
		try {
			const response = await fetch("https://openrouter.ai/api/v1/auth/keys", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ code }),
			})
			if (!response.ok) {
				throw new Error(`OpenRouter API responded with status ${response.status}`)
			}
			const data = (await response.json()) as { key?: string }
			if (data?.key) {
				apiKey = data.key
			} else {
				throw new Error("Invalid response from OpenRouter API")
			}
		} catch (error) {
			Logger.error("[SdkAuthService] Error exchanging code for API key:", error)
			throw error
		}

		this.setProviderApiKey("openrouter", "openRouterApiKey", apiKey)
	}

	/**
	 * Handle Requesty OAuth callback.
	 */
	async handleRequestyCallback(code: string): Promise<void> {
		this.setProviderApiKey("requesty", "requestyApiKey", code)
	}

	/**
	 * Handle Hicap OAuth callback.
	 */
	async handleHicapCallback(code: string): Promise<void> {
		this.setProviderApiKey("hicap", "hicapApiKey", code)
	}
}
