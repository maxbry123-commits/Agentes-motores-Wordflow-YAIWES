import { createTelegramAdapter } from "@chat-adapter/telegram";
import type { ChatStartSessionRequest } from "@cline/core";
import {
	createUserInstructionConfigService,
	HubSessionClient,
} from "@cline/core";
import type {
	ConnectTelegramOptions,
	TelegramConnectorState,
} from "@cline/shared";
import { Chat, ConsoleLogger, type Thread } from "chat";
import type { Command } from "commander";
import type { CliLoggerAdapter } from "../../logging/adapter";
import { createCliLoggerAdapter } from "../../logging/adapter";
import {
	ensureCliHubServer,
	parseHubEndpointOverride,
	resolveDefaultCliRpcAddress,
} from "../../utils/hub-runtime";
import { createWorkspaceChatCommandHost } from "../../utils/plugin-chat-commands";
import { ConnectorBase } from "../base";
import { createChatSdkLogger, enqueueThreadTurn } from "../chat-runtime";
import { CONNECT_ALREADY_RUNNING_EXIT_CODE, isProcessRunning } from "../common";
import {
	type ActiveConnectorTurn,
	handleConnectorUserTurn,
	maybeHandleConnectorApprovalReply,
} from "../connector-host";
import { dispatchConnectorHook } from "../hooks";
import {
	type PendingConnectorApproval,
	truncateConnectorText,
} from "../runtime-turn";
import {
	buildConnectorStartRequest,
	readSessionReplyText,
	stopConnectorSessions,
} from "../session-runtime";
import { InMemoryStateAdapter } from "../stores/memory-state";
import { startConnectorTaskUpdateRelay } from "../task-updates";
import {
	type ConnectorBindingStore,
	type ConnectorThreadState,
	clearBindingSessionIds,
	findBindingForDeliveryTarget,
	findBindingForThread,
	loadThreadState,
	persistMergedThreadState,
	readBindings,
	resolveThreadTurnQueueKey,
} from "../thread-bindings";
import type {
	ConnectCommandDefinition,
	ConnectIo,
	ConnectRunContext,
	ConnectStopResult,
} from "../types";
import {
	getConnectorFirstContactMessage,
	getConnectorSystemPrompt,
	getConnectorSystemRules,
} from "./prompts";
import { postTelegramFormattedReply } from "./telegram-format";

const TELEGRAM_SYSTEM_RULES = getConnectorSystemRules("Telegram");

const TELEGRAM_FIRST_CONTACT_MESSAGE = getConnectorFirstContactMessage();
const TELEGRAM_API_BASE = "https://api.telegram.org";

type TelegramThreadState = ConnectorThreadState;
type ResolvedTelegramOptions = ConnectTelegramOptions & { botUsername: string };
type TelegramGetMeResponse = {
	ok?: boolean;
	description?: string;
	result?: {
		username?: string;
	};
};
type FetchLike = (input: string | URL, init?: RequestInit) => Promise<Response>;

function truncateText(value: string, maxLength = 160): string {
	return truncateConnectorText(value, maxLength);
}

function normalizeTelegramBotUsername(value: string): string {
	return value.trim().replace(/^@+/, "");
}

function readTelegramBotId(botToken: string): string | undefined {
	const [botId] = botToken.trim().split(":", 1);
	return /^\d+$/.test(botId) ? botId : undefined;
}

function normalizeAllowedTelegramUserId(value: string): string {
	const userId = value.trim();
	if (!/^\d+$/.test(userId)) {
		throw new Error(
			"connect telegram --allowed-user-id must contain digits only",
		);
	}
	return userId;
}

function buildTelegramAllowedUserHookCommand(userId: string): string {
	return `jq -r ".payload.actor.participantKey" | grep -qx "telegram:id:${userId}" && echo '{"action":"allow"}' || echo '{"action":"deny","message":"unauthorized","reason":"not_on_allowlist"}'`;
}

function describeTelegramGetMeFailure(
	response: Response,
	body: string,
	parsed: TelegramGetMeResponse | undefined,
): string {
	const detail = parsed?.description || body.trim().slice(0, 240);
	return detail
		? `Telegram getMe failed (${response.status} ${response.statusText}): ${detail}`
		: `Telegram getMe failed (${response.status} ${response.statusText})`;
}

async function readTelegramGetMeResponse(
	response: Response,
): Promise<TelegramGetMeResponse> {
	const text = await response.text();
	let parsed: TelegramGetMeResponse;
	try {
		parsed = JSON.parse(text) as TelegramGetMeResponse;
	} catch {
		throw new Error(describeTelegramGetMeFailure(response, text, undefined));
	}
	if (!response.ok || parsed.ok !== true) {
		throw new Error(describeTelegramGetMeFailure(response, text, parsed));
	}
	return parsed;
}

async function fetchTelegramBotUsername(
	botToken: string,
	fetchImpl: FetchLike = fetch,
	apiBaseUrl = TELEGRAM_API_BASE,
): Promise<string> {
	const response = await fetchImpl(`${apiBaseUrl}/bot${botToken}/getMe`);
	const payload = await readTelegramGetMeResponse(response);
	const username = normalizeTelegramBotUsername(payload.result?.username ?? "");
	if (!username) {
		throw new Error(
			"Telegram getMe did not return a bot username; pass --bot-username explicitly",
		);
	}
	return username;
}

async function resolveTelegramBotUsername(
	options: ConnectTelegramOptions,
	fetchImpl?: FetchLike,
): Promise<string> {
	const configured = normalizeTelegramBotUsername(options.botUsername ?? "");
	if (configured) {
		return configured;
	}
	return fetchTelegramBotUsername(options.botToken, fetchImpl);
}

async function stopSessionsForBot(
	state: TelegramConnectorState,
): Promise<number> {
	return stopConnectorSessions({
		rpcAddress: state.rpcAddress,
		rpcMatcher: (metadata) =>
			metadata?.transport === "telegram" &&
			metadata?.botUserName === state.botUsername,
		localMatcher: (metadata) =>
			metadata?.transport === "telegram" &&
			metadata?.botUserName === state.botUsername,
	});
}

async function buildTelegramStartRequest(
	options: ConnectTelegramOptions,
	io: ConnectIo,
	loggerConfig: Parameters<
		typeof buildConnectorStartRequest
	>[0]["loggerConfig"],
): Promise<ChatStartSessionRequest> {
	return buildConnectorStartRequest({
		options,
		io,
		loggerConfig,
		systemRules: TELEGRAM_SYSTEM_RULES,
	});
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
	return value && typeof value === "object"
		? (value as Record<string, unknown>)
		: undefined;
}

function readString(value: unknown): string | undefined {
	return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function readIdentifier(value: unknown): string | undefined {
	if (typeof value === "string" && value.trim()) {
		return value.trim();
	}
	if (typeof value === "number" && Number.isFinite(value)) {
		return String(value);
	}
	return undefined;
}

function resolveTelegramParticipant(
	rawMessage: unknown,
): { key: string; label?: string } | undefined {
	const raw = asRecord(rawMessage);
	const message =
		asRecord(raw?.message) ??
		asRecord(raw?.edited_message) ??
		asRecord(raw?.channel_post) ??
		raw;
	const from = asRecord(message?.from);
	const username = readString(from?.username)?.toLowerCase();
	const userId = readIdentifier(from?.id);
	const firstName = readString(from?.first_name);
	const lastName = readString(from?.last_name);
	const label =
		username || [firstName, lastName].filter(Boolean).join(" ") || userId;
	if (userId) {
		return { key: `telegram:id:${userId}`, label };
	}
	if (username) {
		return { key: `telegram:user:${username}`, label };
	}
	return undefined;
}

async function persistTelegramThreadContext(input: {
	thread: Thread<TelegramThreadState>;
	bindingsPath: string;
	baseStartRequest: ChatStartSessionRequest;
	rawMessage: unknown;
	errorLabel: string;
}): Promise<void> {
	const participant = resolveTelegramParticipant(input.rawMessage);
	if (!participant) {
		return;
	}
	const currentState = await loadThreadState(
		input.thread,
		input.bindingsPath,
		input.baseStartRequest,
	);
	if (
		currentState.participantKey === participant.key &&
		currentState.participantLabel === participant.label
	) {
		return;
	}
	await persistMergedThreadState(
		input.thread,
		input.bindingsPath,
		{
			...currentState,
			participantKey: participant.key,
			participantLabel: participant.label,
		},
		input.errorLabel,
	);
}

type TelegramSlashCommandEvent = {
	channel: { id: string };
	command: string;
	text: string;
	raw: unknown;
};

/**
 * The Telegram chat adapter intercepts any message whose leading entity is a
 * `bot_command` and delivers it to slash-command handlers instead of the
 * normal mention/subscribed-message handlers. Without a registered handler
 * the command is consumed and dropped, so connector commands like /clear
 * never reach the chat command host. Rebuild the originating chat thread and
 * forward the original message text (preserving any `@bot` addressing used
 * in group chats) into the same turn pipeline as regular messages.
 */
function createTelegramSlashCommandHandler(input: {
	bot: Pick<Chat, "thread">;
	bindingsPath: string;
	baseStartRequest: ChatStartSessionRequest;
	handleTurn: (
		thread: Thread<TelegramThreadState>,
		text: string,
	) => Promise<void>;
}): (event: TelegramSlashCommandEvent) => Promise<void> {
	return async (event) => {
		const raw = asRecord(event.raw);
		const commandText =
			readString(raw?.text) ??
			readString(raw?.caption) ??
			[event.command.trim(), event.text.trim()].filter(Boolean).join(" ");
		if (!commandText) {
			return;
		}
		const thread = input.bot.thread(
			event.channel.id,
		) as Thread<TelegramThreadState>;
		await thread.subscribe();
		await persistTelegramThreadContext({
			thread,
			bindingsPath: input.bindingsPath,
			baseStartRequest: input.baseStartRequest,
			rawMessage: event.raw,
			errorLabel: "Telegram",
		});
		await input.handleTurn(thread, commandText);
	};
}

async function deliverScheduledResult(input: {
	bot: Chat;
	client: HubSessionClient;
	logger: CliLoggerAdapter;
	bindingsPath: string;
	botUsername: string;
	scheduleId: string;
	executionId: string;
	sessionId?: string;
	status: string;
	errorMessage?: string;
	hookCommand?: string;
}): Promise<void> {
	const schedule = await input.client.getSchedule(input.scheduleId);
	const delivery = schedule?.metadata?.delivery as
		| Record<string, unknown>
		| undefined;
	if (!delivery || delivery.adapter !== "telegram") {
		return;
	}
	const targetBot =
		typeof delivery.userName === "string" ? delivery.userName.trim() : "";
	if (targetBot && targetBot !== input.botUsername) {
		return;
	}
	const threadId =
		typeof delivery.threadId === "string" ? delivery.threadId.trim() : "";
	const bindingKey =
		typeof delivery.bindingKey === "string" ? delivery.bindingKey.trim() : "";
	const participantKey =
		typeof delivery.participantKey === "string"
			? delivery.participantKey.trim()
			: "";
	if (!threadId && !bindingKey && !participantKey) {
		return;
	}
	const bindings = readBindings<TelegramThreadState>(input.bindingsPath);
	const match = findBindingForDeliveryTarget(bindings, {
		bindingKey,
		threadId,
		participantKey,
	});
	const binding = match?.binding;
	const deliveryThreadId = match?.key || threadId;
	if (!binding?.serializedThread) {
		input.logger.core.log(
			"Scheduled Telegram delivery skipped: missing thread binding",
			{
				severity: "warn",
				transport: "telegram",
				scheduleId: input.scheduleId,
				executionId: input.executionId,
				threadId: deliveryThreadId,
				bindingKey: bindingKey || undefined,
			},
		);
		return;
	}
	await dispatchConnectorHook(
		input.hookCommand,
		{
			adapter: "telegram",
			botUserName: input.botUsername,
			event: "schedule.delivery.started",
			payload: {
				threadId: deliveryThreadId,
				scheduleId: input.scheduleId,
				executionId: input.executionId,
				sessionId: input.sessionId,
				status: input.status,
			},
			ts: new Date().toISOString(),
		},
		input.logger,
	);
	const thread = JSON.parse(
		binding.serializedThread,
		input.bot.reviver(),
	) as Thread<TelegramThreadState>;
	let body = "";
	if (input.status === "success" && input.sessionId) {
		const text = await readSessionReplyText(input.client, input.sessionId);
		body = text?.trim()
			? text
			: `Schedule "${schedule?.name ?? input.scheduleId}" completed, but no assistant reply text was found.`;
	} else {
		body = `Schedule "${schedule?.name ?? input.scheduleId}" ${input.status}.${input.errorMessage ? `\n\n${input.errorMessage}` : ""}`;
	}
	try {
		await thread.post({ raw: body.trim() ? body : " " });
		input.logger.core.log("Scheduled Telegram delivery sent", {
			transport: "telegram",
			threadId: deliveryThreadId,
			scheduleId: input.scheduleId,
			executionId: input.executionId,
			status: input.status,
			outputPreview: truncateText(body),
		});
		await dispatchConnectorHook(
			input.hookCommand,
			{
				adapter: "telegram",
				botUserName: input.botUsername,
				event: "schedule.delivery.sent",
				payload: {
					threadId: deliveryThreadId,
					scheduleId: input.scheduleId,
					executionId: input.executionId,
					status: input.status,
					outputPreview: truncateText(body),
				},
				ts: new Date().toISOString(),
			},
			input.logger,
		);
	} catch (error) {
		input.logger.core.error?.("Scheduled Telegram delivery failed", {
			transport: "telegram",
			threadId: deliveryThreadId,
			scheduleId: input.scheduleId,
			executionId: input.executionId,
			error,
		});
		await dispatchConnectorHook(
			input.hookCommand,
			{
				adapter: "telegram",
				botUserName: input.botUsername,
				event: "schedule.delivery.failed",
				payload: {
					threadId: deliveryThreadId,
					scheduleId: input.scheduleId,
					executionId: input.executionId,
					error: error instanceof Error ? error.message : String(error),
				},
				ts: new Date().toISOString(),
			},
			input.logger,
		);
	}
}

class TelegramConnector extends ConnectorBase<
	ConnectTelegramOptions,
	TelegramConnectorState
> {
	constructor() {
		super("telegram", "Bridge Telegram bot messages into RPC chat sessions");
	}

	protected override createCommand(): Command {
		return (
			super
				.createCommand()
				.usage("-k <TELEGRAM_BOT_TOKEN> [options]")
				.option(
					"-m, --bot-username <name>",
					"Telegram bot username; fetched from token if omitted",
				)
				.option("-k, --bot-token <token>", "Telegram bot token")
				.option("--provider <id>", "Provider override")
				.option("--model <id>", "Model override")
				.option("--api-key <key>", "Provider API key override")
				.option("--system <prompt>", "System prompt override")
				.option("--cwd <path>", "Workspace / cwd for runtime")
				.option("--mode <act|plan>", "Agent mode", "act")
				.option("-i, --interactive", "Keep connector in foreground")
				.option("--no-tools", "Disable tools for Telegram sessions")
				// Retained so existing invocations and persisted autostart arguments
				// keep parsing; tools are on unless --no-tools is passed.
				.option("--enable-tools", "Enable tools (default)")
				.option(
					"--allowed-user-id <id>",
					"Only allow this Telegram user ID to use the bot",
				)
				.option(
					"--hook-command <command>",
					"Run a shell command for connector events",
				)
				.option(
					"--rpc-address <host:port>",
					"RPC address",
					process.env.CLINE_RPC_ADDRESS?.trim() ||
						resolveDefaultCliRpcAddress(),
				)
				.addHelpText(
					"after",
					[
						"",
						"Notes:",
						"  - Without -i, the connector is launched in the background.",
						"  - Tools are enabled by default for Telegram sessions.",
						"  - Use --allowed-user-id or `cline connect` to restrict Telegram access.",
						"  - Bot username is discovered from the Telegram bot token when omitted.",
						"  - Provider/model default to the CLI's last-used provider settings.",
					].join("\n"),
				)
		);
	}

	protected override readOptions(command: Command): ConnectTelegramOptions {
		const opts = command.opts<{
			botUsername?: string;
			botToken?: string;
			cwd?: string;
			model?: string;
			provider?: string;
			apiKey?: string;
			system?: string;
			mode?: string;
			interactive?: boolean;
			tools?: boolean;
			rpcAddress?: string;
			hookCommand?: string;
			allowedUserId?: string;
		}>();
		const botUsername =
			normalizeTelegramBotUsername(opts.botUsername ?? "") ||
			normalizeTelegramBotUsername(
				process.env.TELEGRAM_BOT_USERNAME?.trim() ?? "",
			);
		const botToken =
			opts.botToken?.trim() || process.env.TELEGRAM_BOT_TOKEN?.trim();
		if (!botToken) {
			throw new Error("connect telegram requires -k/--bot-token <token>");
		}
		const hookCommand =
			opts.hookCommand?.trim() ||
			process.env.CLINE_CONNECT_HOOK_COMMAND?.trim();
		const allowedUserId = opts.allowedUserId?.trim();
		if (hookCommand && allowedUserId) {
			throw new Error(
				"connect telegram accepts either --allowed-user-id or --hook-command, not both",
			);
		}
		return {
			botToken,
			...(botUsername ? { botUsername } : {}),
			cwd: opts.cwd || process.cwd(),
			model: opts.model,
			provider: opts.provider,
			apiKey: opts.apiKey,
			systemPrompt: opts.system,
			mode: this.parseMode(opts.mode),
			interactive: Boolean(opts.interactive),
			enableTools: opts.tools !== false,
			rpcAddress:
				opts.rpcAddress?.trim() ||
				process.env.CLINE_RPC_ADDRESS?.trim() ||
				resolveDefaultCliRpcAddress(),
			hookCommand: allowedUserId
				? buildTelegramAllowedUserHookCommand(
						normalizeAllowedTelegramUserId(allowedUserId),
					)
				: hookCommand,
		};
	}

	private resolveConnectorStatePath(botUsername: string): string {
		return this.resolveConnectorPath(`${this.sanitizeKey(botUsername)}.json`);
	}

	private resolveBindingsPath(botUsername: string): string {
		return this.resolveConnectorPath(
			`${this.sanitizeKey(botUsername)}.threads.json`,
		);
	}

	private listConnectorStatePaths(): string[] {
		return this.listJsonStatePaths([".threads.json"]);
	}

	private readConnectorState(
		statePath: string,
	): TelegramConnectorState | undefined {
		return this.readStateFile(
			statePath,
			(value): value is TelegramConnectorState =>
				Boolean(
					value &&
						typeof value === "object" &&
						typeof (value as TelegramConnectorState).pid === "number" &&
						typeof (value as TelegramConnectorState).botUsername === "string",
				),
		);
	}

	private writeConnectorState(
		statePath: string,
		state: TelegramConnectorState,
	): void {
		this.writeStateFile(statePath, state);
	}

	private findRunningConnectorStateByBotId(
		botId: string | undefined,
	): TelegramConnectorState | undefined {
		if (!botId) {
			return undefined;
		}
		for (const statePath of this.listConnectorStatePaths()) {
			const state = this.readConnectorState(statePath);
			if (!state) {
				continue;
			}
			if (!isProcessRunning(state.pid)) {
				this.removeStateFile(statePath);
				continue;
			}
			if (state.botId === botId) {
				return state;
			}
		}
		return undefined;
	}

	private async stopTelegramConnectorInstance(
		statePath: string,
		io: ConnectIo,
	): Promise<ConnectStopResult> {
		return this.stopManagedProcess({
			io,
			statePath,
			readState: (path) => this.readConnectorState(path),
			describeStoppedProcess: (state) =>
				`[telegram] stopped pid=${state.pid} bot=@${state.botUsername}`,
			getPid: (state) => state.pid,
			stopSessions: stopSessionsForBot,
			clearBindings: (state) => {
				clearBindingSessionIds<TelegramThreadState>(
					this.resolveBindingsPath(state.botUsername),
				);
			},
		});
	}

	override async stopAll(io: ConnectIo): Promise<ConnectStopResult> {
		return this.stopAllFromStatePaths(
			io,
			this.listConnectorStatePaths(),
			(statePath, stopIo) =>
				this.stopTelegramConnectorInstance(statePath, stopIo),
		);
	}

	override async stopInstance(
		instanceId: string,
		io: ConnectIo,
	): Promise<ConnectStopResult> {
		return await this.stopTelegramConnectorInstance(
			this.resolveConnectorStatePath(instanceId),
			io,
		);
	}

	protected override async validateOptions(
		options: ConnectTelegramOptions,
		io: ConnectIo,
	): Promise<number> {
		try {
			await resolveTelegramBotUsername({
				...options,
				botUsername: undefined,
			});
			return 0;
		} catch (error) {
			io.writeErr(error instanceof Error ? error.message : String(error));
			return 1;
		}
	}

	/**
	 * Only knowable up front when `--bot-username` was supplied; otherwise the
	 * username is resolved from Telegram's API during startup, and the caller
	 * has to start this connector locally instead of through the hub.
	 */
	protected override instanceIdFromOptions(
		options: ConnectTelegramOptions,
	): string | undefined {
		return options.botUsername;
	}

	protected override async runWithOptions(
		inputOptions: ConnectTelegramOptions,
		rawArgs: string[],
		io: ConnectIo,
		context: ConnectRunContext,
	): Promise<number> {
		if (
			!inputOptions.botUsername &&
			!inputOptions.interactive &&
			process.env.CLINE_TELEGRAM_CONNECT_CHILD !== "1"
		) {
			const runningState = this.findRunningConnectorStateByBotId(
				readTelegramBotId(inputOptions.botToken),
			);
			if (runningState) {
				io.writeln(
					`[telegram] connector already running pid=${runningState.pid} rpc=${runningState.rpcAddress}`,
				);
				return CONNECT_ALREADY_RUNNING_EXIT_CODE;
			}
		}
		let resolvedBotUsername: string;
		try {
			resolvedBotUsername = await resolveTelegramBotUsername(inputOptions);
		} catch (error) {
			io.writeErr(error instanceof Error ? error.message : String(error));
			return 1;
		}
		const options: ResolvedTelegramOptions = {
			...inputOptions,
			botUsername: resolvedBotUsername,
		};
		const backgroundArgs = inputOptions.botUsername
			? rawArgs
			: [...rawArgs, "--bot-username", resolvedBotUsername];
		context.setPersistenceArgs(backgroundArgs);
		context.setPersistenceInstanceId(options.botUsername);
		const statePath = this.resolveConnectorStatePath(options.botUsername);
		const bindingsPath = this.resolveBindingsPath(options.botUsername);
		const staleState = this.removeStaleState(
			statePath,
			(path) => this.readConnectorState(path),
			(state) => state.pid,
		);
		if (staleState) {
			clearBindingSessionIds<TelegramThreadState>(bindingsPath);
		}
		const backgroundExitCode = await this.maybeRunInBackground({
			rawArgs: backgroundArgs,
			io,
			interactive: options.interactive,
			childEnvVar: "CLINE_TELEGRAM_CONNECT_CHILD",
			statePath,
			readState: (path) => this.readConnectorState(path),
			isRunning: (state) => isProcessRunning(state.pid),
			formatAlreadyRunningMessage: (state) =>
				`[telegram] connector already running pid=${state.pid} rpc=${state.rpcAddress}`,
			formatBackgroundStartMessage: (pid) =>
				`[telegram] starting background connector pid=${pid} bot=@${options.botUsername}`,
			foregroundHint:
				"[telegram] use `cline connect telegram -i ...` to run in the foreground",
			launchFailureMessage: "failed to launch Telegram connector in background",
		});
		if (backgroundExitCode !== undefined) {
			return backgroundExitCode;
		}

		const loggerAdapter = createCliLoggerAdapter({
			runtime: "cli",
			component: "telegram-connect",
		});
		const logger = createChatSdkLogger(loggerAdapter);
		const consoleLogger = new ConsoleLogger("info", "telegram-connect");
		const telegram = createTelegramAdapter({
			mode: "polling",
			botToken: options.botToken,
			userName: options.botUsername,
			logger,
		});
		const bot = new Chat({
			userName: options.botUsername,
			adapters: { telegram },
			state: new InMemoryStateAdapter(),
			logger,
			fallbackStreamingPlaceholderText: null,
			streamingUpdateIntervalMs: 500,
		}).registerSingleton();
		const threadQueues = new Map<string, Promise<void>>();
		const activeTurns = new Map<string, ActiveConnectorTurn>();
		const pendingApprovals = new Map<string, PendingConnectorApproval>();
		const startRequest = await buildTelegramStartRequest(options, io, {
			enabled: loggerAdapter.runtimeConfig.enabled,
			level: loggerAdapter.runtimeConfig.level,
			destination: loggerAdapter.runtimeConfig.destination,
			bindings: {
				transport: "telegram",
				botUserName: options.botUsername,
			},
		});
		const userInstructionService = createUserInstructionConfigService({
			skills: { workspacePath: startRequest.cwd },
			rules: { workspacePath: startRequest.cwd },
			workflows: { workspacePath: startRequest.cwd },
		});
		await userInstructionService.start().catch(() => undefined);
		const commandCwd = startRequest.cwd || process.cwd();
		const { host: chatCommandHost } = await createWorkspaceChatCommandHost({
			cwd: commandCwd,
			workspaceRoot: startRequest.workspaceRoot || commandCwd,
		});
		const { url: rpcAddress, authToken: rpcAuthToken } =
			await ensureCliHubServer(
				startRequest.workspaceRoot || startRequest.cwd || process.cwd(),
				parseHubEndpointOverride(options.rpcAddress),
			);

		const clientId = `telegram-${process.pid}-${Date.now()}`;
		const client = new HubSessionClient({
			address: rpcAddress,
			authToken: rpcAuthToken,
			clientId,
			clientType: "cli",
			displayName: "telegram connector",
			workspaceRoot: startRequest.workspaceRoot || startRequest.cwd,
			cwd: startRequest.cwd,
			metadata: {
				transport: "telegram",
				botUserName: options.botUsername,
			},
		});
		await client.connect();
		this.writeConnectorState(statePath, {
			botUsername: options.botUsername,
			botId: readTelegramBotId(options.botToken),
			pid: process.pid,
			rpcAddress,
			startedAt: new Date().toISOString(),
		});
		loggerAdapter.core.log("Telegram connector started", {
			transport: "telegram",
			botUserName: options.botUsername,
			pid: process.pid,
			rpcAddress,
			mode: telegram.runtimeMode,
			interactive: options.interactive,
		});
		await dispatchConnectorHook(
			options.hookCommand,
			{
				adapter: "telegram",
				botUserName: options.botUsername,
				event: "connector.started",
				payload: {
					pid: process.pid,
					rpcAddress,
					mode: telegram.runtimeMode,
				},
				ts: new Date().toISOString(),
			},
			loggerAdapter,
		);

		let stopping = false;
		let resolveStop: (() => void) | undefined;
		const stopPromise = new Promise<void>((resolve) => {
			resolveStop = resolve;
		});
		const requestStop = (reason: string) => {
			if (stopping) {
				return;
			}
			stopping = true;
			loggerAdapter.core.log("Telegram connector stopping", {
				severity: "warn",
				transport: "telegram",
				reason,
				pid: process.pid,
			});
			resolveStop?.();
		};

		const handleTurn = async (
			thread: Thread<TelegramThreadState>,
			text: string,
		) => {
			const queueKey = resolveThreadTurnQueueKey(thread);
			const enqueueTurn = (work: () => Promise<void>) =>
				enqueueThreadTurn(threadQueues, queueKey, work);
			const runTurn = async () => {
				try {
					await handleConnectorUserTurn({
						thread,
						text,
						client,
						pendingApprovals,
						baseStartRequest: startRequest,
						explicitSystemPrompt:
							options.systemPrompt?.trim() ||
							getConnectorSystemPrompt("Telegram"),
						clientId,
						logger: loggerAdapter,
						transport: "telegram",
						botUserName: options.botUsername,
						requestStop,
						bindingsPath,
						hookCommand: options.hookCommand,
						systemRules: TELEGRAM_SYSTEM_RULES,
						errorLabel: "Telegram",
						firstContactMessage: TELEGRAM_FIRST_CONTACT_MESSAGE,
						userInstructionService,
						chatCommandHost,
						activeTurns,
						enqueueTurn,
						turnKey: queueKey,
						forceDisableTools: !options.enableTools,
						postFinalReply: async ({
							thread: currentThread,
							text: replyText,
						}) => {
							await postTelegramFormattedReply({
								thread: currentThread,
								text: replyText,
								botToken: options.botToken,
								logger: loggerAdapter,
							});
						},
						getSessionMetadata: (currentThread, _clientId, currentState) => ({
							botUserName: options.botUsername,
							telegramThreadId: currentThread.id,
							telegramChannelId: currentThread.channelId,
							...(currentState.participantKey
								? { telegramParticipantKey: currentState.participantKey }
								: {}),
							...(currentState.participantLabel
								? { telegramParticipantLabel: currentState.participantLabel }
								: {}),
						}),
						reusedLogMessage: "Telegram thread reusing RPC session",
						startedLogMessage: "Telegram thread started RPC session",
						messageReceivedLogMessage: "Telegram message received",
						threadResetLogMessage: "Telegram thread reset",
						connectorStopLogMessage:
							"Telegram connector stop requested from chat",
						onMessageReceived: async (details) => {
							await dispatchConnectorHook(
								options.hookCommand,
								{
									adapter: "telegram",
									botUserName: options.botUsername,
									event: "message.received",
									payload: details,
									ts: new Date().toISOString(),
								},
								loggerAdapter,
							);
						},
						onReplyCompleted: async (result) => {
							loggerAdapter.core.log("Telegram reply completed", {
								transport: "telegram",
								threadId: result.threadId,
								sessionId: result.sessionId,
								outputLength: result.text.length,
								outputPreview: truncateText(result.text),
								finishReason: result.finishReason,
								iterations: result.iterations,
							});
							await dispatchConnectorHook(
								options.hookCommand,
								{
									adapter: "telegram",
									botUserName: options.botUsername,
									event: "message.completed",
									payload: {
										threadId: result.threadId,
										sessionId: result.sessionId,
										finishReason: result.finishReason,
										iterations: result.iterations,
										outputPreview: truncateText(result.text),
										outputLength: result.text.length,
									},
									ts: new Date().toISOString(),
								},
								loggerAdapter,
							);
						},
						onReplyFailed: async (details) => {
							loggerAdapter.core.error?.("Telegram reply failed", {
								transport: "telegram",
								threadId: details.threadId,
								sessionId: details.sessionId,
								error: details.error,
							});
							await dispatchConnectorHook(
								options.hookCommand,
								{
									adapter: "telegram",
									botUserName: options.botUsername,
									event: "message.failed",
									payload: {
										threadId: details.threadId,
										sessionId: details.sessionId,
										error: details.error.message,
									},
									ts: new Date().toISOString(),
								},
								loggerAdapter,
							);
						},
					});
				} catch (error) {
					const message =
						error instanceof Error ? error.message : String(error);
					loggerAdapter.core.error?.("Telegram turn handling failed", {
						transport: "telegram",
						threadId: thread.id,
						error,
					});
					await thread.post({ raw: `Telegram bridge error: ${message}` });
				}
			};
			if (activeTurns.has(queueKey)) {
				await runTurn();
				return;
			}
			await enqueueTurn(runTurn);
		};

		bot.onNewMention(async (thread, message) => {
			await thread.subscribe();
			await persistTelegramThreadContext({
				thread,
				bindingsPath,
				baseStartRequest: startRequest,
				rawMessage: message.raw,
				errorLabel: "Telegram",
			});
			if (
				await maybeHandleConnectorApprovalReply({
					thread,
					text: message.text,
					client,
					clientId,
					pendingApprovals,
					deniedReason: "Denied by Telegram user",
					transport: "telegram",
				})
			) {
				return;
			}
			await handleTurn(thread, message.text);
		});

		bot.onSubscribedMessage(async (thread, message) => {
			await persistTelegramThreadContext({
				thread,
				bindingsPath,
				baseStartRequest: startRequest,
				rawMessage: message.raw,
				errorLabel: "Telegram",
			});
			if (
				await maybeHandleConnectorApprovalReply({
					thread,
					text: message.text,
					client,
					clientId,
					pendingApprovals,
					deniedReason: "Denied by Telegram user",
					transport: "telegram",
				})
			) {
				return;
			}
			await handleTurn(thread, message.text);
		});

		bot.onSlashCommand(
			createTelegramSlashCommandHandler({
				bot,
				bindingsPath,
				baseStartRequest: startRequest,
				handleTurn,
			}),
		);

		await bot.initialize();
		const stopTaskUpdateStream =
			startConnectorTaskUpdateRelay<TelegramThreadState>({
				client,
				clientId,
				bot,
				logger: loggerAdapter,
				bindingsPath,
				transport: "telegram",
				postToThread: async ({ thread, body }) => {
					await thread.post({ raw: body.trim() ? body : " " });
				},
			});

		const stopEventStream = client.streamEvents(
			{ clientId: `${clientId}-server-events` },
			{
				onEvent: (event) => {
					if (event.eventType === "rpc.server.shutting_down") {
						loggerAdapter.core.log(
							"Telegram connector stopping because the RPC server is shutting down",
							{
								severity: "warn",
								transport: "telegram",
								eventType: event.eventType,
							},
						);
						requestStop("rpc_server_shutting_down");
						return;
					}
					if (
						event.eventType !== "schedule.execution.completed" &&
						event.eventType !== "schedule.execution.failed"
					) {
						return;
					}
					const scheduleId =
						typeof event.payload.scheduleId === "string"
							? event.payload.scheduleId.trim()
							: "";
					const executionId =
						typeof event.payload.executionId === "string"
							? event.payload.executionId.trim()
							: "";
					const sessionId =
						typeof event.payload.sessionId === "string"
							? event.payload.sessionId.trim()
							: undefined;
					const status =
						typeof event.payload.status === "string"
							? event.payload.status.trim()
							: "";
					const errorMessage =
						typeof event.payload.errorMessage === "string"
							? event.payload.errorMessage
							: undefined;
					if (!scheduleId || !executionId || !status) {
						return;
					}
					void deliverScheduledResult({
						bot,
						client,
						logger: loggerAdapter,
						bindingsPath,
						botUsername: options.botUsername,
						scheduleId,
						executionId,
						sessionId,
						status,
						errorMessage,
						hookCommand: options.hookCommand,
					});
				},
				onError: (error) => {
					loggerAdapter.core.log(
						"Telegram connector server event stream failed",
						{
							severity: "warn",
							transport: "telegram",
							error,
						},
					);
					requestStop("rpc_server_event_stream_failed");
				},
			},
		);

		consoleLogger.info("Telegram connector ready", {
			rpcAddress,
			mode: telegram.runtimeMode,
		});
		io.writeln(
			`[telegram] connected as @${options.botUsername} mode=${telegram.runtimeMode} rpc=${rpcAddress} provider=${startRequest.provider} model=${startRequest.model} tools=${startRequest.enableTools ? "on" : "off"}`,
		);
		io.writeln("[telegram] send /clear in a chat to start a fresh RPC session");
		io.writeln(
			"[telegram] send /whereami in a chat to get its delivery thread id",
		);
		io.writeln(
			"[telegram] use /tools, /yolo, or /cwd <path> to update runtime settings",
		);
		io.writeln("[telegram] send /exit in a chat or press Ctrl+C to stop");

		const shutdown = () => {
			process.off("SIGINT", shutdown);
			process.off("SIGTERM", shutdown);
			requestStop("signal");
		};
		process.on("SIGINT", shutdown);
		process.on("SIGTERM", shutdown);

		await stopPromise;
		clearBindingSessionIds<TelegramThreadState>(bindingsPath);

		stopTaskUpdateStream();
		stopEventStream();
		userInstructionService.stop();
		await dispatchConnectorHook(
			options.hookCommand,
			{
				adapter: "telegram",
				botUserName: options.botUsername,
				event: "connector.stopping",
				payload: { pid: process.pid },
				ts: new Date().toISOString(),
			},
			loggerAdapter,
		);
		await telegram.stopPolling().catch(() => undefined);
		await bot.shutdown().catch(() => undefined);
		client.close();
		this.removeStateFile(statePath);
		loggerAdapter.core.log("Telegram connector stopped", {
			transport: "telegram",
			pid: process.pid,
		});
		return 0;
	}
}

export const telegramConnector: ConnectCommandDefinition =
	new TelegramConnector();

export const __test__ = {
	createTelegramSlashCommandHandler,
	fetchTelegramBotUsername,
	readTelegramBotId,
	resolveTelegramBotUsername,
	resolveTelegramParticipant,
	findBindingForThread: (
		bindings: ConnectorBindingStore<TelegramThreadState>,
		thread: Pick<Thread<TelegramThreadState>, "id" | "channelId" | "isDM"> & {
			participantKey?: string;
		},
	) => findBindingForThread(bindings, thread),
};
