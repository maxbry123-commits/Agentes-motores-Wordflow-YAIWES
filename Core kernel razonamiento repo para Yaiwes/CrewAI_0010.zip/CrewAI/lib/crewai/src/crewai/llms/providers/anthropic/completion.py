from __future__ import annotations

import json
import logging
import os
from typing import Any, Final, Literal, Protocol, TypeGuard, TypedDict, cast

from pydantic import BaseModel, PrivateAttr, model_validator

from crewai.events.types.llm_events import LLMCallType
from crewai.hooks.dispatch import HookAborted
from crewai.llms.base_llm import (
    BaseLLM,
    JsonResponseFormat,
    LLMCallBlockedError,
    llm_call_context,
)
from crewai.llms.hooks.base import BaseInterceptor
from crewai.llms.hooks.transport import AsyncHTTPTransport, HTTPTransport
from crewai.llms.providers.utils.common import safe_tool_conversion
from crewai.types.usage_metrics import _coerce_int
from crewai.utilities.agent_utils import is_context_length_exceeded
from crewai.utilities.exceptions.context_window_exceeding_exception import (
    LLMContextLengthExceededError,
)
from crewai.utilities.pydantic_schema_utils import (
    sanitize_tool_params_for_anthropic_strict,
)
from crewai.utilities.types import LLMMessage


try:
    from anthropic import Anthropic, AsyncAnthropic, transform_schema
    from anthropic.types import (
        Message,
        TextBlock,
        ThinkingBlock,
        ToolUseBlock,
    )
    from anthropic.types.beta import BetaMessage, BetaTextBlock, BetaToolUseBlock
    import httpx
except ImportError:
    raise ImportError(
        'Anthropic native provider not available, to install: uv add "crewai[anthropic]"'
    ) from None


TOOL_SEARCH_TOOL_TYPES: Final[tuple[str, ...]] = (
    "tool_search_tool_regex_20251119",
    "tool_search_tool_bm25_20251119",
)

ANTHROPIC_FILES_API_BETA: Final = "files-api-2025-04-14"
ANTHROPIC_STRUCTURED_OUTPUTS_BETA: Final = "structured-outputs-2025-11-13"
# Anthropic requires max_tokens. Offered models all accept at least 32000.
# Longest prefix wins. Unknown IDs use 32000 so they stay in-range.
_MAX_OUTPUT_TOKENS_BY_PREFIX: Final[tuple[tuple[str, int], ...]] = (
    ("claude-fable-5", 128000),
    ("claude-opus-5", 128000),
    ("claude-sonnet-5", 128000),
    ("claude-opus-4-8", 128000),
    ("claude-opus-4-7", 128000),
    ("claude-opus-4-6", 128000),
    ("claude-sonnet-4-6", 128000),
    ("claude-haiku-4-5", 64000),
    ("claude-sonnet-4-5", 64000),
    ("claude-opus-4-5", 64000),
)
_DEFAULT_MODEL_MAX_TOKENS: Final[int] = 32000
DEFAULT_MODEL: Final[str] = "claude-sonnet-4-6"


def _default_max_tokens_for_model(model: str) -> int:
    """Return the model's documented Messages API max output tokens."""
    name = model.rsplit("/", 1)[-1].lower()
    for prefix, limit in _MAX_OUTPUT_TOKENS_BY_PREFIX:
        if name.startswith(prefix):
            return limit
    return _DEFAULT_MODEL_MAX_TOKENS


NATIVE_STRUCTURED_OUTPUT_MODELS: Final[
    tuple[
        Literal["claude-sonnet-4-5"],
        Literal["claude-sonnet-4.5"],
        Literal["claude-opus-4-5"],
        Literal["claude-opus-4.5"],
        Literal["claude-haiku-4-5"],
        Literal["claude-haiku-4.5"],
    ]
] = (
    "claude-sonnet-4-5",
    "claude-sonnet-4.5",
    "claude-opus-4-5",
    "claude-opus-4.5",
    "claude-haiku-4-5",
    "claude-haiku-4.5",
)


def _supports_native_structured_outputs(model: str) -> bool:
    """Check if the model supports native structured outputs.

    Native structured outputs are only available for Claude 4.5 models
    (Sonnet 4.5, Opus 4.5, Haiku 4.5).
    Other models require the tool-based fallback approach.

    Args:
        model: The model name/identifier.

    Returns:
        True if the model supports native structured outputs.
    """
    model_lower = model.lower()
    return any(prefix in model_lower for prefix in NATIVE_STRUCTURED_OUTPUT_MODELS)


def _is_pydantic_model_class(obj: Any) -> TypeGuard[type[BaseModel]]:
    """Check if an object is a Pydantic model class.

    This distinguishes between Pydantic model classes that support structured
    outputs (have model_json_schema) and plain dicts like {"type": "json_object"}.

    Args:
        obj: The object to check.

    Returns:
        True if obj is a Pydantic model class.
    """
    return isinstance(obj, type) and issubclass(obj, BaseModel)


def _contains_file_id_reference(messages: list[dict[str, Any]]) -> bool:
    """Check if any message content contains a file_id reference.

    Anthropic's Files API is in beta and requires a special header when
    file_id references are used in content blocks.

    Args:
        messages: List of message dicts to check.

    Returns:
        True if any content block contains a file_id reference.
    """
    for message in messages:
        content = message.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    source = block.get("source", {})
                    if isinstance(source, dict) and source.get("type") == "file":
                        return True
    return False


class _ToolUseDictBlock(TypedDict):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, Any]


class _ToolUseObjectBlock(Protocol):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, object]


_AnthropicToolUseBlock = (
    ToolUseBlock | BetaToolUseBlock | _ToolUseDictBlock | _ToolUseObjectBlock
)


def _is_tool_use_block(block: Any) -> TypeGuard[_AnthropicToolUseBlock]:
    """Return true for complete Anthropic tool-use blocks across SDK shapes.

    New/preview Anthropic models can return content blocks whose concrete SDK
    class is not one of the imported ``ToolUseBlock`` aliases. The stable API
    contract used by execution, streaming, and follow-up paths is ``type``,
    ``id``, ``name``, and ``input``, so validate that full shape before treating
    a block as tool-use.
    """
    if isinstance(block, dict):
        return (
            block.get("type") == "tool_use"
            and isinstance(block.get("id"), str)
            and isinstance(block.get("name"), str)
            and isinstance(block.get("input"), dict)
        )

    return (
        getattr(block, "type", None) == "tool_use"
        and isinstance(getattr(block, "id", None), str)
        and isinstance(getattr(block, "name", None), str)
        and isinstance(getattr(block, "input", None), dict)
    )


def _tool_use_blocks(blocks: list[Any]) -> list[_AnthropicToolUseBlock]:
    return [block for block in blocks if _is_tool_use_block(block)]


def _tool_use_id(block: _AnthropicToolUseBlock) -> str:
    return block["id"] if isinstance(block, dict) else block.id


def _tool_use_name(block: _AnthropicToolUseBlock) -> str:
    return block["name"] if isinstance(block, dict) else block.name


def _tool_use_input(block: _AnthropicToolUseBlock) -> dict[str, Any]:
    return (
        block["input"] if isinstance(block, dict) else cast(dict[str, Any], block.input)
    )


class AnthropicThinkingConfig(BaseModel):
    type: Literal["enabled", "disabled"]
    budget_tokens: int | None = None


class AnthropicToolSearchConfig(BaseModel):
    """Configuration for Anthropic's server-side tool search.

    When enabled, tools marked with defer_loading=True are not loaded into
    context immediately. Instead, Claude uses the tool search tool to
    dynamically discover and load relevant tools on-demand.

    Attributes:
        type: The tool search variant to use.
            - "regex": Claude constructs regex patterns to search tool names/descriptions.
            - "bm25": Claude uses natural language queries to search tools.
    """

    type: Literal["regex", "bm25"] = "bm25"


class AnthropicCompletion(BaseLLM):
    """Anthropic native completion implementation.

    This class provides direct integration with the Anthropic Python SDK,
    offering native tool use, streaming support, and proper message formatting.
    """

    llm_type: Literal["anthropic"] = "anthropic"
    model: str = DEFAULT_MODEL
    timeout: float | None = None
    max_retries: int = 2
    max_tokens: int = _DEFAULT_MODEL_MAX_TOKENS
    top_p: float | None = None
    stream: bool = False
    client_params: dict[str, Any] | None = None
    interceptor: BaseInterceptor[httpx.Request, httpx.Response] | None = None
    thinking: AnthropicThinkingConfig | None = None
    response_format: JsonResponseFormat | type[BaseModel] | None = None
    tool_search: AnthropicToolSearchConfig | None = None
    is_claude_3: bool = False
    supports_tools: bool = True

    _client: Any = PrivateAttr(default=None)
    _async_client: Any = PrivateAttr(default=None)
    _previous_thinking_blocks: list[Any] = PrivateAttr(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _normalize_anthropic_fields(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data
        # Anthropic uses stop_sequences; normalize from stop kwarg
        popped = data.pop("stop_sequences", None)
        seqs = popped if popped is not None else (data.get("stop") or [])
        if isinstance(seqs, str):
            seqs = [seqs]
        data["stop"] = seqs
        if not data.get("model"):
            data["model"] = DEFAULT_MODEL
        data["is_claude_3"] = "claude-3" in data.get("model", "").lower()
        if data.get("max_tokens") is None:
            data["max_tokens"] = _default_max_tokens_for_model(data["model"])
        # Normalize tool_search
        ts = data.get("tool_search")
        if ts is True:
            data["tool_search"] = AnthropicToolSearchConfig()
        elif ts is not None and not isinstance(ts, AnthropicToolSearchConfig):
            data["tool_search"] = None
        return data

    @model_validator(mode="after")
    def _init_clients(self) -> AnthropicCompletion:
        """Eagerly build clients when the API key is available, otherwise
        defer so ``LLM(model="anthropic/...")`` can be constructed at module
        import time even before deployment env vars are set.
        """
        try:
            self._client = self._build_sync_client()
            self._async_client = self._build_async_client()
        except ValueError:
            pass
        return self

    def _build_sync_client(self) -> Any:
        return Anthropic(**self._get_client_params())

    def _build_async_client(self) -> Any:
        # Skip the sync httpx.Client that `_get_client_params` would
        # otherwise construct under `interceptor`; we attach an async one
        # below and would leak the sync one if both were built.
        async_client_params = self._get_client_params(include_http_client=False)
        if self.interceptor:
            async_transport = AsyncHTTPTransport(interceptor=self.interceptor)
            async_client_params["http_client"] = httpx.AsyncClient(
                transport=async_transport
            )
        return AsyncAnthropic(**async_client_params)

    def _get_sync_client(self) -> Any:
        if self._client is None:
            self._client = self._build_sync_client()
        return self._client

    def _get_async_client(self) -> Any:
        if self._async_client is None:
            self._async_client = self._build_async_client()
        return self._async_client

    def to_config_dict(self) -> dict[str, Any]:
        """Extend base config with Anthropic-specific fields."""
        config = super().to_config_dict()
        if self.max_tokens != _default_max_tokens_for_model(self.model):
            config["max_tokens"] = self.max_tokens
        if self.max_retries != 2:  # non-default
            config["max_retries"] = self.max_retries
        if self.top_p is not None:
            config["top_p"] = self.top_p
        if self.timeout is not None:
            config["timeout"] = self.timeout
        return config

    def _get_client_params(self, include_http_client: bool = True) -> dict[str, Any]:
        """Get client parameters.

        Args:
            include_http_client: When True (default) and an interceptor is
                set, attach a sync ``httpx.Client``. The async builder
                passes ``False`` so it can attach its own async client
                without leaking a sync one.
        """

        if self.api_key is None:
            self.api_key = os.getenv("ANTHROPIC_API_KEY")
            if self.api_key is None:
                raise ValueError("ANTHROPIC_API_KEY is required")

        client_params = {
            "api_key": self.api_key,
            "base_url": self.base_url,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
        }

        if include_http_client and self.interceptor:
            transport = HTTPTransport(interceptor=self.interceptor)
            http_client = httpx.Client(transport=transport)
            client_params["http_client"] = http_client  # type: ignore[assignment]

        if self.client_params:
            client_params.update(self.client_params)

        return client_params

    def call(
        self,
        messages: str | list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: type[BaseModel] | None = None,
    ) -> str | Any:
        """Call Anthropic messages API.

        Args:
            messages: Input messages for the chat completion
            tools: List of tool/function definitions
            callbacks: Callback functions (not used in native implementation)
            available_functions: Available functions for tool calling
            from_task: Task that initiated the call
            from_agent: Agent that initiated the call

        Returns:
            Chat completion response or tool call result
        """
        with llm_call_context():
            try:
                self._emit_call_started_event(
                    messages=messages,
                    tools=tools,
                    callbacks=callbacks,
                    available_functions=available_functions,
                    from_task=from_task,
                    from_agent=from_agent,
                )

                formatted_messages, system_message = (
                    self._format_messages_for_anthropic(messages)
                )

                self._invoke_before_llm_call_hooks(formatted_messages, from_agent)

                completion_params = self._prepare_completion_params(
                    formatted_messages, system_message, tools, available_functions
                )

                effective_response_model = response_model or self.response_format

                if self._effective_stream():
                    return self._handle_streaming_completion(
                        completion_params,
                        available_functions,
                        from_task,
                        from_agent,
                        effective_response_model,
                    )

                return self._handle_completion(
                    completion_params,
                    available_functions,
                    from_task,
                    from_agent,
                    effective_response_model,
                )

            except (HookAborted, LLMCallBlockedError) as e:
                self._emit_call_denied_event(e, from_task, from_agent)
                raise
            except Exception as e:
                error_msg = f"Anthropic API call failed: {e!s}"
                logging.error(error_msg)
                self._emit_call_failed_event(
                    error=error_msg, from_task=from_task, from_agent=from_agent
                )
                raise

    async def acall(
        self,
        messages: str | list[LLMMessage],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: type[BaseModel] | None = None,
    ) -> str | Any:
        """Async call to Anthropic messages API.

        Args:
            messages: Input messages for the chat completion
            tools: List of tool/function definitions
            callbacks: Callback functions (not used in native implementation)
            available_functions: Available functions for tool calling
            from_task: Task that initiated the call
            from_agent: Agent that initiated the call
            response_model: Optional response model.

        Returns:
            Chat completion response or tool call result
        """
        with llm_call_context():
            try:
                self._emit_call_started_event(
                    messages=messages,
                    tools=tools,
                    callbacks=callbacks,
                    available_functions=available_functions,
                    from_task=from_task,
                    from_agent=from_agent,
                )

                formatted_messages, system_message = (
                    self._format_messages_for_anthropic(messages)
                )

                self._invoke_before_llm_call_hooks(formatted_messages, from_agent)

                completion_params = self._prepare_completion_params(
                    formatted_messages, system_message, tools, available_functions
                )

                effective_response_model = response_model or self.response_format

                if self._effective_stream():
                    return await self._ahandle_streaming_completion(
                        completion_params,
                        available_functions,
                        from_task,
                        from_agent,
                        effective_response_model,
                    )

                return await self._ahandle_completion(
                    completion_params,
                    available_functions,
                    from_task,
                    from_agent,
                    effective_response_model,
                )

            except (HookAborted, LLMCallBlockedError) as e:
                self._emit_call_denied_event(e, from_task, from_agent)
                raise
            except Exception as e:
                error_msg = f"Anthropic API call failed: {e!s}"
                logging.error(error_msg)
                self._emit_call_failed_event(
                    error=error_msg, from_task=from_task, from_agent=from_agent
                )
                raise

    def _prepare_completion_params(
        self,
        messages: list[LLMMessage],
        system_message: str | list[dict[str, Any]] | None = None,
        tools: list[dict[str, Any]] | None = None,
        available_functions: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Prepare parameters for Anthropic messages API.

        Args:
            messages: Formatted messages for Anthropic
            system_message: Extracted system message
            tools: Tool definitions
            available_functions: Available functions for tool calling. When provided
                with a single tool, tool_choice is automatically set to force tool use.

        Returns:
            Parameters dictionary for Anthropic API
        """
        params = {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            "stream": self._effective_stream(),
        }

        if system_message:
            params["system"] = system_message

        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.stop_sequences:
            params["stop_sequences"] = self.stop_sequences

        if tools and self.supports_tools:
            converted_tools = self._convert_tools_for_interference(tools)

            # When tool_search is enabled and there are 2+ regular tools,
            # inject the search tool and mark regular tools with defer_loading.
            # With only 1 tool there's nothing to search — skip tool search
            # entirely so the normal forced tool_choice optimisation still works.
            regular_tools = [
                t
                for t in converted_tools
                if t.get("type", "") not in TOOL_SEARCH_TOOL_TYPES
            ]
            if self.tool_search is not None and len(regular_tools) >= 2:
                converted_tools = self._apply_tool_search(converted_tools)

            params["tools"] = converted_tools

            if available_functions and len(regular_tools) == 1:
                tool_name = regular_tools[0].get("name")
                if tool_name and tool_name in available_functions:
                    params["tool_choice"] = {"type": "tool", "name": tool_name}

        if self.thinking:
            if isinstance(self.thinking, AnthropicThinkingConfig):
                params["thinking"] = self.thinking.model_dump()
            else:
                params["thinking"] = self.thinking

        return params

    def _convert_tools_for_interference(
        self, tools: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Convert CrewAI tool format to Anthropic tool use format."""
        anthropic_tools = []

        for tool in tools:
            tool_type = tool.get("type", "")
            if tool_type in TOOL_SEARCH_TOOL_TYPES:
                anthropic_tools.append(tool)
                continue

            if "input_schema" in tool and "name" in tool and "description" in tool:
                anthropic_tools.append(tool)
                continue

            try:
                name, description, parameters = safe_tool_conversion(tool, "Anthropic")
            except (KeyError, ValueError) as e:
                logging.error(f"Error converting tool to Anthropic format: {e}")
                raise e

            anthropic_tool: dict[str, Any] = {
                "name": name,
                "description": description,
            }

            func_info = tool.get("function", {})
            strict_enabled = bool(func_info.get("strict"))

            if parameters and isinstance(parameters, dict):
                anthropic_tool["input_schema"] = (
                    sanitize_tool_params_for_anthropic_strict(parameters)
                    if strict_enabled
                    else parameters
                )
            else:
                anthropic_tool["input_schema"] = {
                    "type": "object",
                    "properties": {},
                    "required": [],
                }

            if strict_enabled:
                anthropic_tool["strict"] = True

            anthropic_tools.append(anthropic_tool)

        return anthropic_tools

    def _apply_tool_search(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Inject tool search tool and mark regular tools with defer_loading.

        When tool_search is enabled, this method:
        1. Adds the appropriate tool search tool definition (regex or bm25)
        2. Marks all regular tools with defer_loading=True so they are only
           loaded when Claude discovers them via search

        Args:
            tools: Converted tool definitions in Anthropic format.

        Returns:
            Updated tools list with tool search tool prepended and
            regular tools marked as deferred.
        """
        if self.tool_search is None:
            return tools

        has_search_tool = any(
            t.get("type", "") in TOOL_SEARCH_TOOL_TYPES for t in tools
        )

        result: list[dict[str, Any]] = []

        if not has_search_tool:
            type_map = {
                "regex": "tool_search_tool_regex_20251119",
                "bm25": "tool_search_tool_bm25_20251119",
            }
            tool_type = type_map[self.tool_search.type]
            tool_name = f"tool_search_tool_{self.tool_search.type}"
            result.append({"type": tool_type, "name": tool_name})

        for tool in tools:
            if tool.get("type", "") in TOOL_SEARCH_TOOL_TYPES:
                result.append(tool)
                continue

            if "defer_loading" not in tool:
                tool = {**tool, "defer_loading": True}
            result.append(tool)

        return result

    def _extract_thinking_block(
        self, content_block: Any
    ) -> ThinkingBlock | dict[str, Any] | None:
        """Extract and format thinking block from content block.

        Args:
            content_block: Content block from Anthropic response

        Returns:
            Dictionary with thinking block data including signature, or None if not a thinking block
        """
        block_type = (
            content_block.get("type")
            if isinstance(content_block, dict)
            else getattr(content_block, "type", None)
        )
        if block_type == "thinking":
            thinking = (
                content_block.get("thinking")
                if isinstance(content_block, dict)
                else content_block.thinking
            )
            thinking_block = {
                "type": "thinking",
                "thinking": thinking,
            }
            signature = (
                content_block.get("signature")
                if isinstance(content_block, dict)
                else getattr(content_block, "signature", None)
            )
            if signature:
                thinking_block["signature"] = signature
            return thinking_block
        if block_type == "redacted_thinking":
            redacted_block = {"type": "redacted_thinking"}
            if isinstance(content_block, dict):
                if "thinking" in content_block:
                    redacted_block["thinking"] = content_block["thinking"]
                if "signature" in content_block:
                    redacted_block["signature"] = content_block["signature"]
            else:
                if hasattr(content_block, "thinking"):
                    redacted_block["thinking"] = content_block.thinking
                if hasattr(content_block, "signature"):
                    redacted_block["signature"] = content_block.signature
            return redacted_block
        return None

    @staticmethod
    def _convert_image_blocks(content: Any) -> Any:
        """Convert OpenAI-style image_url blocks to Anthropic image blocks.

        Upstream code (e.g. StepExecutor) uses the standard ``image_url``
        format with a ``data:`` URI.  Anthropic rejects that — it requires
        ``{"type": "image", "source": {"type": "base64", ...}}``.

        Non-list content and blocks that are not ``image_url`` are passed
        through unchanged.
        """
        if not isinstance(content, list):
            return content

        converted: list[dict[str, Any]] = []
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "image_url":
                converted.append(block)
                continue

            image_info = block.get("image_url", {})
            url = image_info.get("url", "") if isinstance(image_info, dict) else ""
            if url.startswith("data:") and ";base64," in url:
                # Parse  data:<media_type>;base64,<data>
                header, b64_data = url.split(";base64,", 1)
                media_type = (
                    header.split("data:", 1)[1] if "data:" in header else "image/png"
                )
                converted.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": b64_data,
                        },
                    }
                )
            else:
                # Non-data URI — pass through as-is (Anthropic supports url source)
                converted.append(block)

        return converted

    def _format_messages_for_anthropic(
        self, messages: str | list[LLMMessage]
    ) -> tuple[list[LLMMessage], str | list[dict[str, Any]] | None]:
        """Format messages for Anthropic API.

        Anthropic has specific requirements:
        - System messages are separate from conversation messages
        - Messages must alternate between user and assistant
        - First message must be from user
        - Tool results must be in user messages with tool_result content blocks
        - When thinking is enabled, assistant messages must start with thinking blocks

        Args:
            messages: Input messages

        Returns:
            Tuple of (formatted_messages, system_message). `system_message` is
            a list of content blocks (with cache_control stamped) when any
            system message in the input carried a cache_breakpoint flag;
            otherwise a plain string for backwards compatibility.
        """
        from crewai.llms.cache import CACHE_BREAKPOINT_KEY

        # Read cache_breakpoint flags from raw input BEFORE super strips them.
        # We track the CONTENT of marked user/assistant messages so we can
        # locate the corresponding block in formatted_messages — Anthropic
        # rewrites tool results into user messages, so positional indices
        # do not survive the conversion. We must stamp the original stable
        # message (typically the initial task prompt), not whatever happens
        # to be the trailing user-role block after tool_result expansion.
        cache_system = False
        cache_match_contents: list[str] = []
        if not isinstance(messages, str):
            for m in messages:
                if not (isinstance(m, dict) and m.get(CACHE_BREAKPOINT_KEY)):
                    continue
                role = m.get("role")
                if role == "system":
                    cache_system = True
                    continue
                if role != "user":
                    # Only user messages survive Anthropic's role-coalescing
                    # in a stable, addressable position. Markers on assistant
                    # or tool messages have no reliable stamp target after
                    # tool_result expansion, so we ignore them.
                    continue
                raw_content = m.get("content")
                if isinstance(raw_content, str) and raw_content:
                    cache_match_contents.append(raw_content)
                    continue
                if isinstance(raw_content, list):
                    # Pull text from a single-text-block list so callers that
                    # pre-format content blocks still match cleanly.
                    text_blocks = [
                        b.get("text")
                        for b in raw_content
                        if isinstance(b, dict) and b.get("type") == "text"
                    ]
                    if len(text_blocks) == 1 and isinstance(text_blocks[0], str):
                        cache_match_contents.append(text_blocks[0])

        base_formatted = super()._format_messages(messages)

        formatted_messages: list[LLMMessage] = []
        system_message: str | None = None
        pending_tool_results: list[dict[str, Any]] = []

        for message in base_formatted:
            role = message.get("role")
            content = message.get("content", "")

            if role == "system":
                if system_message:
                    system_message += f"\n\n{content}"
                else:
                    system_message = cast(str, content)
            elif role == "tool":
                tool_call_id = message.get("tool_call_id", "")
                if not tool_call_id:
                    raise ValueError("Tool message missing required tool_call_id")
                tool_content = self._convert_image_blocks(content) if content else ""
                tool_result = {
                    "type": "tool_result",
                    "tool_use_id": tool_call_id,
                    "content": tool_content,
                }
                pending_tool_results.append(tool_result)
            elif role == "assistant":
                if pending_tool_results:
                    formatted_messages.append(
                        {"role": "user", "content": pending_tool_results}
                    )
                    pending_tool_results = []

                tool_calls = message.get("tool_calls", [])
                if tool_calls:
                    assistant_content: list[dict[str, Any]] = []
                    for tc in tool_calls:
                        if isinstance(tc, dict):
                            func = tc.get("function", {})
                            tool_use = {
                                "type": "tool_use",
                                "id": tc.get("id", ""),
                                "name": func.get("name", ""),
                                "input": json.loads(func.get("arguments", "{}"))
                                if isinstance(func.get("arguments"), str)
                                else func.get("arguments", {}),
                            }
                            assistant_content.append(tool_use)
                    if assistant_content:
                        formatted_messages.append(
                            {"role": "assistant", "content": assistant_content}
                        )
                elif isinstance(content, list):
                    formatted_messages.append({"role": "assistant", "content": content})
                elif self.thinking and self._previous_thinking_blocks:
                    structured_content = cast(
                        list[dict[str, Any]],
                        [
                            *self._previous_thinking_blocks,
                            {"type": "text", "text": content if content else ""},
                        ],
                    )
                    formatted_messages.append(
                        LLMMessage(role="assistant", content=structured_content)
                    )
                else:
                    content_str = content if content is not None else ""
                    formatted_messages.append(
                        LLMMessage(role="assistant", content=content_str)
                    )
            else:
                if pending_tool_results:
                    formatted_messages.append(
                        {"role": "user", "content": pending_tool_results}
                    )
                    pending_tool_results = []

                role_str = role if role is not None else "user"
                if isinstance(content, list):
                    formatted_messages.append(
                        {
                            "role": role_str,
                            "content": self._convert_image_blocks(content),
                        }
                    )
                else:
                    content_str = content if content is not None else ""
                    formatted_messages.append(
                        LLMMessage(role=role_str, content=content_str)
                    )

        if pending_tool_results:
            formatted_messages.append({"role": "user", "content": pending_tool_results})

        # Anthropic requires the first message to come from "user"
        if not formatted_messages:
            formatted_messages.append({"role": "user", "content": "Hello"})
        elif formatted_messages[0]["role"] != "user":
            formatted_messages.insert(0, {"role": "user", "content": "Hello"})

        # Stamp cache_control on the message(s) whose original content was
        # marked. We scan formatted_messages in order and stamp the first
        # match per marked content — Anthropic permits up to 4 cache
        # breakpoints per request, which is more than enough for our usage.
        # Matching by content (rather than position) handles the ReAct
        # case where tool_result blocks get expanded into trailing user
        # messages: the stable initial-task prompt still maps cleanly.
        for needle in cache_match_contents:
            for fm in formatted_messages:
                if fm.get("role") != "user":
                    continue
                content = fm.get("content")
                if isinstance(content, str) and content == needle:
                    self._stamp_cache_control_on_message(fm)
                    break
                if isinstance(content, list):
                    fm_texts: list[str] = [
                        b.get("text", "")
                        for b in content
                        if isinstance(b, dict) and b.get("type") == "text"
                    ]
                    if len(fm_texts) == 1 and fm_texts[0] == needle:
                        self._stamp_cache_control_on_message(fm)
                        break

        # Convert system to content-block form when caching is requested.
        system_payload: str | list[dict[str, Any]] | None = system_message
        if system_message and cache_system:
            system_payload = [
                {
                    "type": "text",
                    "text": system_message,
                    "cache_control": {"type": "ephemeral"},
                }
            ]

        return formatted_messages, system_payload

    @staticmethod
    def _stamp_cache_control_on_message(message: LLMMessage) -> None:
        """Stamp cache_control on the last content block of an Anthropic message."""
        msg = cast(dict[str, Any], message)
        content = msg.get("content")
        if isinstance(content, str):
            msg["content"] = [
                {
                    "type": "text",
                    "text": content,
                    "cache_control": {"type": "ephemeral"},
                }
            ]
            return
        if isinstance(content, list) and content:
            last = content[-1]
            if isinstance(last, dict):
                last["cache_control"] = {"type": "ephemeral"}

    def _handle_completion(
        self,
        params: dict[str, Any],
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: JsonResponseFormat | type[BaseModel] | None = None,
    ) -> str | Any:
        """Handle non-streaming message completion."""
        uses_file_api = _contains_file_id_reference(params.get("messages", []))
        betas: list[str] = []
        use_native_structured_output = False

        if uses_file_api:
            betas.append(ANTHROPIC_FILES_API_BETA)

        extra_body: dict[str, Any] | None = None
        if _is_pydantic_model_class(response_model):
            schema = transform_schema(response_model.model_json_schema())
            if _supports_native_structured_outputs(self.model):
                use_native_structured_output = True
                betas.append(ANTHROPIC_STRUCTURED_OUTPUTS_BETA)
                extra_body = {
                    "output_format": {
                        "type": "json_schema",
                        "schema": schema,
                    }
                }
            else:
                structured_tool = {
                    "name": "structured_output",
                    "description": "Output the structured response",
                    "input_schema": schema,
                }
                params["tools"] = [structured_tool]
                params["tool_choice"] = {"type": "tool", "name": "structured_output"}

        try:
            if betas:
                params["betas"] = betas
                response = self._get_sync_client().beta.messages.create(
                    **params, extra_body=extra_body
                )
            else:
                response = self._get_sync_client().messages.create(**params)

        except Exception as e:
            if is_context_length_exceeded(e):
                logging.error(f"Context window exceeded: {e}")
                raise LLMContextLengthExceededError(str(e)) from e
            raise e from e

        usage = self._extract_anthropic_token_usage(response)
        self._track_token_usage_internal(usage)

        finish_reason, response_id = self._extract_finish_reason_and_id(response)

        if _is_pydantic_model_class(response_model) and response.content:
            if use_native_structured_output:
                for block in response.content:
                    if isinstance(block, (TextBlock, BetaTextBlock)):
                        structured_data = response_model.model_validate_json(block.text)
                        self._emit_call_completed_event(
                            response=structured_data.model_dump_json(),
                            call_type=LLMCallType.LLM_CALL,
                            from_task=from_task,
                            from_agent=from_agent,
                            messages=params["messages"],
                            usage=usage,
                            finish_reason=finish_reason,
                            response_id=response_id,
                        )
                        return structured_data
            else:
                for block in response.content:
                    if (
                        _is_tool_use_block(block)
                        and _tool_use_name(block) == "structured_output"
                    ):
                        structured_data = response_model.model_validate(
                            _tool_use_input(block)
                        )
                        self._emit_call_completed_event(
                            response=structured_data.model_dump_json(),
                            call_type=LLMCallType.LLM_CALL,
                            from_task=from_task,
                            from_agent=from_agent,
                            messages=params["messages"],
                            usage=usage,
                            finish_reason=finish_reason,
                            response_id=response_id,
                        )
                        return structured_data

        # Check if Claude wants to use tools
        if response.content:
            tool_uses = _tool_use_blocks(list(response.content))

            if tool_uses:
                # Without available_functions, return tool calls so the executor can
                # manage execution with proper message history and post-tool reasoning prompts
                if not available_functions:
                    self._emit_call_completed_event(
                        response=list(tool_uses),
                        call_type=LLMCallType.TOOL_CALL,
                        from_task=from_task,
                        from_agent=from_agent,
                        messages=params["messages"],
                        usage=usage,
                        finish_reason=finish_reason,
                        response_id=response_id,
                    )
                    return list(tool_uses)

                result = self._execute_first_tool(
                    tool_uses, available_functions, from_task, from_agent
                )
                if result is not None:
                    return result

        content = ""
        thinking_blocks: list[ThinkingBlock] = []

        if response.content:
            for content_block in response.content:
                if hasattr(content_block, "text"):
                    content += content_block.text
                else:
                    thinking_block = self._extract_thinking_block(content_block)
                    if thinking_block:
                        thinking_blocks.append(cast(ThinkingBlock, thinking_block))

        if thinking_blocks:
            self._previous_thinking_blocks = thinking_blocks

        content = self._apply_stop_words(content)
        self._emit_call_completed_event(
            response=content,
            call_type=LLMCallType.LLM_CALL,
            from_task=from_task,
            from_agent=from_agent,
            messages=params["messages"],
            usage=usage,
            finish_reason=finish_reason,
            response_id=response_id,
        )

        if usage.get("total_tokens", 0) > 0:
            logging.info(f"Anthropic API usage: {usage}")

        return self._invoke_after_llm_call_hooks(
            params["messages"], content, from_agent
        )

    def _handle_streaming_completion(
        self,
        params: dict[str, Any],
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: JsonResponseFormat | type[BaseModel] | None = None,
    ) -> str | Any:
        """Handle streaming message completion."""
        betas: list[str] = []
        use_native_structured_output = False

        extra_body: dict[str, Any] | None = None
        if _is_pydantic_model_class(response_model):
            schema = transform_schema(response_model.model_json_schema())
            if _supports_native_structured_outputs(self.model):
                use_native_structured_output = True
                betas.append(ANTHROPIC_STRUCTURED_OUTPUTS_BETA)
                extra_body = {
                    "output_format": {
                        "type": "json_schema",
                        "schema": schema,
                    }
                }
            else:
                structured_tool = {
                    "name": "structured_output",
                    "description": "Output the structured response",
                    "input_schema": schema,
                }
                params["tools"] = [structured_tool]
                params["tool_choice"] = {"type": "tool", "name": "structured_output"}

        full_response = ""

        # Remove 'stream' parameter as messages.stream() doesn't accept it
        # (the SDK sets it internally)
        stream_params = {k: v for k, v in params.items() if k != "stream"}

        if betas:
            stream_params["betas"] = betas

        current_tool_calls: dict[int, dict[str, Any]] = {}

        stream_context = (
            self._get_sync_client().beta.messages.stream(
                **stream_params, extra_body=extra_body
            )
            if betas
            else self._get_sync_client().messages.stream(**stream_params)
        )
        with stream_context as stream:
            response_id = None
            for event in stream:
                if hasattr(event, "message") and hasattr(event.message, "id"):
                    response_id = event.message.id

                if hasattr(event, "delta") and hasattr(event.delta, "text"):
                    text_delta = event.delta.text
                    full_response += text_delta
                    self._emit_stream_chunk_event(
                        chunk=text_delta,
                        from_task=from_task,
                        from_agent=from_agent,
                        response_id=response_id,
                    )

                if event.type == "content_block_start":
                    block = event.content_block
                    if _is_tool_use_block(block):
                        block_index = event.index
                        tool_use_id = _tool_use_id(block)
                        tool_name = _tool_use_name(block)
                        current_tool_calls[block_index] = {
                            "id": tool_use_id,
                            "name": tool_name,
                            "arguments": "",
                            "index": block_index,
                        }
                        self._emit_stream_chunk_event(
                            chunk="",
                            from_task=from_task,
                            from_agent=from_agent,
                            tool_call={
                                "id": tool_use_id,
                                "function": {
                                    "name": tool_name,
                                    "arguments": "",
                                },
                                "type": "function",
                                "index": block_index,
                            },
                            call_type=LLMCallType.TOOL_CALL,
                            response_id=response_id,
                        )
                elif event.type == "content_block_delta":
                    if event.delta.type == "input_json_delta":
                        block_index = event.index
                        partial_json = event.delta.partial_json
                        if block_index in current_tool_calls and partial_json:
                            current_tool_calls[block_index]["arguments"] += partial_json
                            self._emit_stream_chunk_event(
                                chunk=partial_json,
                                from_task=from_task,
                                from_agent=from_agent,
                                tool_call={
                                    "id": current_tool_calls[block_index]["id"],
                                    "function": {
                                        "name": current_tool_calls[block_index]["name"],
                                        "arguments": current_tool_calls[block_index][
                                            "arguments"
                                        ],
                                    },
                                    "type": "function",
                                    "index": block_index,
                                },
                                call_type=LLMCallType.TOOL_CALL,
                                response_id=response_id,
                            )

            final_message = stream.get_final_message()

        thinking_blocks: list[ThinkingBlock] = []
        if final_message.content:
            for content_block in final_message.content:
                thinking_block = self._extract_thinking_block(content_block)
                if thinking_block:
                    thinking_blocks.append(cast(ThinkingBlock, thinking_block))

        if thinking_blocks:
            self._previous_thinking_blocks = thinking_blocks

        usage = self._extract_anthropic_token_usage(final_message)
        self._track_token_usage_internal(usage)

        finish_reason, final_response_id = self._extract_finish_reason_and_id(
            final_message
        )

        if _is_pydantic_model_class(response_model):
            if use_native_structured_output:
                structured_data = response_model.model_validate_json(full_response)
                self._emit_call_completed_event(
                    response=structured_data.model_dump_json(),
                    call_type=LLMCallType.LLM_CALL,
                    from_task=from_task,
                    from_agent=from_agent,
                    messages=params["messages"],
                    usage=usage,
                    finish_reason=finish_reason,
                    response_id=final_response_id,
                )
                return structured_data
            for block in final_message.content:
                if (
                    _is_tool_use_block(block)
                    and _tool_use_name(block) == "structured_output"
                ):
                    structured_data = response_model.model_validate(
                        _tool_use_input(block)
                    )
                    self._emit_call_completed_event(
                        response=structured_data.model_dump_json(),
                        call_type=LLMCallType.LLM_CALL,
                        from_task=from_task,
                        from_agent=from_agent,
                        messages=params["messages"],
                        usage=usage,
                        finish_reason=finish_reason,
                        response_id=final_response_id,
                    )
                    return structured_data

        if final_message.content:
            tool_uses = _tool_use_blocks(list(final_message.content))

            if tool_uses:
                if not available_functions:
                    return list(tool_uses)

                result = self._execute_first_tool(
                    tool_uses, available_functions, from_task, from_agent
                )
                if result is not None:
                    return result

        full_response = self._apply_stop_words(full_response)

        self._emit_call_completed_event(
            response=full_response,
            call_type=LLMCallType.LLM_CALL,
            from_task=from_task,
            from_agent=from_agent,
            messages=params["messages"],
            usage=usage,
            finish_reason=finish_reason,
            response_id=final_response_id,
        )

        return self._invoke_after_llm_call_hooks(
            params["messages"], full_response, from_agent
        )

    def _execute_tools_and_collect_results(
        self,
        tool_uses: list[_AnthropicToolUseBlock],
        available_functions: dict[str, Any],
        from_task: Any | None = None,
        from_agent: Any | None = None,
    ) -> list[dict[str, Any]]:
        """Execute tools and collect results in Anthropic format.

        Args:
            tool_uses: List of tool use blocks from Claude's response (regular or beta API)
            available_functions: Available functions for tool calling
            from_task: Task that initiated the call
            from_agent: Agent that initiated the call

        Returns:
            List of tool result dictionaries in Anthropic format
        """
        tool_results = []

        for tool_use in tool_uses:
            function_name = _tool_use_name(tool_use)
            function_args = _tool_use_input(tool_use)

            result = self._handle_tool_execution(
                function_name=function_name,
                function_args=function_args,
                available_functions=available_functions,
                from_task=from_task,
                from_agent=from_agent,
            )

            tool_result = {
                "type": "tool_result",
                "tool_use_id": _tool_use_id(tool_use),
                "content": str(result)
                if result is not None
                else "Tool execution completed",
            }
            tool_results.append(tool_result)

        return tool_results

    def _execute_first_tool(
        self,
        tool_uses: list[_AnthropicToolUseBlock],
        available_functions: dict[str, Any],
        from_task: Any | None = None,
        from_agent: Any | None = None,
    ) -> Any | None:
        """Execute the first tool from the tool_uses list and return its result.

        This is used when available_functions is provided, to directly execute
        the tool and return its result (matching OpenAI behavior for use cases
        like reasoning_handler).

        Args:
            tool_uses: List of tool use blocks from Claude's response
            available_functions: Available functions for tool calling
            from_task: Task that initiated the call
            from_agent: Agent that initiated the call

        Returns:
            The result of the first tool execution, or None if execution failed
        """
        tool_use = tool_uses[0]
        function_name = _tool_use_name(tool_use)
        function_args = _tool_use_input(tool_use)

        return self._handle_tool_execution(
            function_name=function_name,
            function_args=function_args,
            available_functions=available_functions,
            from_task=from_task,
            from_agent=from_agent,
        )

    # TODO: we drop this
    def _handle_tool_use_conversation(
        self,
        initial_response: Message | BetaMessage,
        tool_uses: list[_AnthropicToolUseBlock],
        params: dict[str, Any],
        available_functions: dict[str, Any],
        from_task: Any | None = None,
        from_agent: Any | None = None,
    ) -> str:
        """Handle the complete tool use conversation flow.

        This implements the proper Anthropic tool use pattern:
        1. Claude requests tool use
        2. We execute the tools
        3. We send tool results back to Claude
        4. Claude processes results and generates final response
        """
        tool_results = self._execute_tools_and_collect_results(
            tool_uses, available_functions, from_task, from_agent
        )

        follow_up_params = params.copy()

        assistant_content: list[
            ThinkingBlock | ToolUseBlock | TextBlock | dict[str, Any]
        ] = []
        for block in initial_response.content:
            thinking_block = self._extract_thinking_block(block)
            if thinking_block:
                assistant_content.append(thinking_block)
            elif _is_tool_use_block(block):
                assistant_content.append(
                    {
                        "type": "tool_use",
                        "id": _tool_use_id(block),
                        "name": _tool_use_name(block),
                        "input": _tool_use_input(block),
                    }
                )
            elif hasattr(block, "text"):
                assistant_content.append({"type": "text", "text": block.text})

        assistant_message = {"role": "assistant", "content": assistant_content}

        user_message = {"role": "user", "content": tool_results}

        follow_up_params["messages"] = params["messages"] + [
            assistant_message,
            user_message,
        ]

        try:
            final_response: Message = self._get_sync_client().messages.create(
                **follow_up_params
            )

            follow_up_usage = self._extract_anthropic_token_usage(final_response)
            self._track_token_usage_internal(follow_up_usage)

            final_content = ""
            thinking_blocks: list[ThinkingBlock] = []

            if final_response.content:
                for content_block in final_response.content:
                    if hasattr(content_block, "text"):
                        final_content += content_block.text
                    else:
                        thinking_block = self._extract_thinking_block(content_block)
                        if thinking_block:
                            thinking_blocks.append(cast(ThinkingBlock, thinking_block))

            if thinking_blocks:
                self._previous_thinking_blocks = thinking_blocks

            final_content = self._apply_stop_words(final_content)

            finish_reason, final_response_id = self._extract_finish_reason_and_id(
                final_response
            )

            self._emit_call_completed_event(
                response=final_content,
                call_type=LLMCallType.LLM_CALL,
                from_task=from_task,
                from_agent=from_agent,
                messages=follow_up_params["messages"],
                usage=follow_up_usage,
                finish_reason=finish_reason,
                response_id=final_response_id,
            )

            total_usage = {
                "input_tokens": follow_up_usage.get("input_tokens", 0),
                "output_tokens": follow_up_usage.get("output_tokens", 0),
                "total_tokens": follow_up_usage.get("total_tokens", 0),
            }

            if total_usage.get("total_tokens", 0) > 0:
                logging.info(f"Anthropic API tool conversation usage: {total_usage}")

            return final_content

        except Exception as e:
            if is_context_length_exceeded(e):
                logging.error(f"Context window exceeded in tool follow-up: {e}")
                raise LLMContextLengthExceededError(str(e)) from e

            logging.error(f"Tool follow-up conversation failed: {e}")
            # Fallback to first tool result when follow-up fails
            if tool_results:
                return cast(str, tool_results[0]["content"])
            raise e

    async def _ahandle_completion(
        self,
        params: dict[str, Any],
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: JsonResponseFormat | type[BaseModel] | None = None,
    ) -> str | Any:
        """Handle non-streaming async message completion."""
        uses_file_api = _contains_file_id_reference(params.get("messages", []))
        betas: list[str] = []
        use_native_structured_output = False

        if uses_file_api:
            betas.append(ANTHROPIC_FILES_API_BETA)

        extra_body: dict[str, Any] | None = None
        if _is_pydantic_model_class(response_model):
            schema = transform_schema(response_model.model_json_schema())
            if _supports_native_structured_outputs(self.model):
                use_native_structured_output = True
                betas.append(ANTHROPIC_STRUCTURED_OUTPUTS_BETA)
                extra_body = {
                    "output_format": {
                        "type": "json_schema",
                        "schema": schema,
                    }
                }
            else:
                structured_tool = {
                    "name": "structured_output",
                    "description": "Output the structured response",
                    "input_schema": schema,
                }
                params["tools"] = [structured_tool]
                params["tool_choice"] = {"type": "tool", "name": "structured_output"}

        try:
            if betas:
                params["betas"] = betas
                response = await self._get_async_client().beta.messages.create(
                    **params, extra_body=extra_body
                )
            else:
                response = await self._get_async_client().messages.create(**params)

        except Exception as e:
            if is_context_length_exceeded(e):
                logging.error(f"Context window exceeded: {e}")
                raise LLMContextLengthExceededError(str(e)) from e
            raise e from e

        usage = self._extract_anthropic_token_usage(response)
        self._track_token_usage_internal(usage)

        finish_reason, response_id = self._extract_finish_reason_and_id(response)

        if _is_pydantic_model_class(response_model) and response.content:
            if use_native_structured_output:
                for block in response.content:
                    if isinstance(block, (TextBlock, BetaTextBlock)):
                        structured_data = response_model.model_validate_json(block.text)
                        self._emit_call_completed_event(
                            response=structured_data.model_dump_json(),
                            call_type=LLMCallType.LLM_CALL,
                            from_task=from_task,
                            from_agent=from_agent,
                            messages=params["messages"],
                            usage=usage,
                            finish_reason=finish_reason,
                            response_id=response_id,
                        )
                        return structured_data
            else:
                for block in response.content:
                    if (
                        _is_tool_use_block(block)
                        and _tool_use_name(block) == "structured_output"
                    ):
                        structured_data = response_model.model_validate(
                            _tool_use_input(block)
                        )
                        self._emit_call_completed_event(
                            response=structured_data.model_dump_json(),
                            call_type=LLMCallType.LLM_CALL,
                            from_task=from_task,
                            from_agent=from_agent,
                            messages=params["messages"],
                            usage=usage,
                            finish_reason=finish_reason,
                            response_id=response_id,
                        )
                        return structured_data

        # Handle Anthropic tool-use blocks across stable, beta, and preview SDK shapes.
        if response.content:
            tool_uses = _tool_use_blocks(list(response.content))

            if tool_uses:
                if not available_functions:
                    self._emit_call_completed_event(
                        response=list(tool_uses),
                        call_type=LLMCallType.TOOL_CALL,
                        from_task=from_task,
                        from_agent=from_agent,
                        messages=params["messages"],
                        usage=usage,
                        finish_reason=finish_reason,
                        response_id=response_id,
                    )
                    return list(tool_uses)

                result = self._execute_first_tool(
                    tool_uses, available_functions, from_task, from_agent
                )
                if result is not None:
                    return result

        content = ""
        if response.content:
            for content_block in response.content:
                if hasattr(content_block, "text"):
                    content += content_block.text

        content = self._apply_stop_words(content)

        self._emit_call_completed_event(
            response=content,
            call_type=LLMCallType.LLM_CALL,
            from_task=from_task,
            from_agent=from_agent,
            messages=params["messages"],
            usage=usage,
            finish_reason=finish_reason,
            response_id=response_id,
        )

        if usage.get("total_tokens", 0) > 0:
            logging.info(f"Anthropic API usage: {usage}")

        return content

    async def _ahandle_streaming_completion(
        self,
        params: dict[str, Any],
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: JsonResponseFormat | type[BaseModel] | None = None,
    ) -> str | Any:
        """Handle async streaming message completion."""
        betas: list[str] = []
        use_native_structured_output = False

        extra_body: dict[str, Any] | None = None
        if _is_pydantic_model_class(response_model):
            schema = transform_schema(response_model.model_json_schema())
            if _supports_native_structured_outputs(self.model):
                use_native_structured_output = True
                betas.append(ANTHROPIC_STRUCTURED_OUTPUTS_BETA)
                extra_body = {
                    "output_format": {
                        "type": "json_schema",
                        "schema": schema,
                    }
                }
            else:
                structured_tool = {
                    "name": "structured_output",
                    "description": "Output the structured response",
                    "input_schema": schema,
                }
                params["tools"] = [structured_tool]
                params["tool_choice"] = {"type": "tool", "name": "structured_output"}

        full_response = ""

        stream_params = {k: v for k, v in params.items() if k != "stream"}

        if betas:
            stream_params["betas"] = betas

        current_tool_calls: dict[int, dict[str, Any]] = {}

        stream_context = (
            self._get_async_client().beta.messages.stream(
                **stream_params, extra_body=extra_body
            )
            if betas
            else self._get_async_client().messages.stream(**stream_params)
        )
        async with stream_context as stream:
            response_id = None
            async for event in stream:
                if hasattr(event, "message") and hasattr(event.message, "id"):
                    response_id = event.message.id

                if hasattr(event, "delta") and hasattr(event.delta, "text"):
                    text_delta = event.delta.text
                    full_response += text_delta
                    self._emit_stream_chunk_event(
                        chunk=text_delta,
                        from_task=from_task,
                        from_agent=from_agent,
                        response_id=response_id,
                    )

                if event.type == "content_block_start":
                    block = event.content_block
                    if _is_tool_use_block(block):
                        block_index = event.index
                        tool_use_id = _tool_use_id(block)
                        tool_name = _tool_use_name(block)
                        current_tool_calls[block_index] = {
                            "id": tool_use_id,
                            "name": tool_name,
                            "arguments": "",
                            "index": block_index,
                        }
                        self._emit_stream_chunk_event(
                            chunk="",
                            from_task=from_task,
                            from_agent=from_agent,
                            tool_call={
                                "id": tool_use_id,
                                "function": {
                                    "name": tool_name,
                                    "arguments": "",
                                },
                                "type": "function",
                                "index": block_index,
                            },
                            call_type=LLMCallType.TOOL_CALL,
                            response_id=response_id,
                        )
                elif event.type == "content_block_delta":
                    if event.delta.type == "input_json_delta":
                        block_index = event.index
                        partial_json = event.delta.partial_json
                        if block_index in current_tool_calls and partial_json:
                            current_tool_calls[block_index]["arguments"] += partial_json
                            self._emit_stream_chunk_event(
                                chunk=partial_json,
                                from_task=from_task,
                                from_agent=from_agent,
                                tool_call={
                                    "id": current_tool_calls[block_index]["id"],
                                    "function": {
                                        "name": current_tool_calls[block_index]["name"],
                                        "arguments": current_tool_calls[block_index][
                                            "arguments"
                                        ],
                                    },
                                    "type": "function",
                                    "index": block_index,
                                },
                                call_type=LLMCallType.TOOL_CALL,
                                response_id=response_id,
                            )

            final_message = await stream.get_final_message()

        usage = self._extract_anthropic_token_usage(final_message)
        self._track_token_usage_internal(usage)

        finish_reason, final_response_id = self._extract_finish_reason_and_id(
            final_message
        )

        if _is_pydantic_model_class(response_model):
            if use_native_structured_output:
                structured_data = response_model.model_validate_json(full_response)
                self._emit_call_completed_event(
                    response=structured_data.model_dump_json(),
                    call_type=LLMCallType.LLM_CALL,
                    from_task=from_task,
                    from_agent=from_agent,
                    messages=params["messages"],
                    usage=usage,
                    finish_reason=finish_reason,
                    response_id=final_response_id,
                )
                return structured_data
            for block in final_message.content:
                if (
                    _is_tool_use_block(block)
                    and _tool_use_name(block) == "structured_output"
                ):
                    structured_data = response_model.model_validate(
                        _tool_use_input(block)
                    )
                    self._emit_call_completed_event(
                        response=structured_data.model_dump_json(),
                        call_type=LLMCallType.LLM_CALL,
                        from_task=from_task,
                        from_agent=from_agent,
                        messages=params["messages"],
                        usage=usage,
                        finish_reason=finish_reason,
                        response_id=final_response_id,
                    )
                    return structured_data

        if final_message.content:
            tool_uses = _tool_use_blocks(list(final_message.content))

            if tool_uses:
                if not available_functions:
                    return list(tool_uses)

                result = self._execute_first_tool(
                    tool_uses, available_functions, from_task, from_agent
                )
                if result is not None:
                    return result

        full_response = self._apply_stop_words(full_response)

        self._emit_call_completed_event(
            response=full_response,
            call_type=LLMCallType.LLM_CALL,
            from_task=from_task,
            from_agent=from_agent,
            messages=params["messages"],
            usage=usage,
            finish_reason=finish_reason,
            response_id=final_response_id,
        )

        return full_response

    async def _ahandle_tool_use_conversation(
        self,
        initial_response: Message | BetaMessage,
        tool_uses: list[_AnthropicToolUseBlock],
        params: dict[str, Any],
        available_functions: dict[str, Any],
        from_task: Any | None = None,
        from_agent: Any | None = None,
    ) -> str:
        """Handle the complete async tool use conversation flow.

        This implements the proper Anthropic tool use pattern:
        1. Claude requests tool use
        2. We execute the tools
        3. We send tool results back to Claude
        4. Claude processes results and generates final response
        """
        tool_results = self._execute_tools_and_collect_results(
            tool_uses, available_functions, from_task, from_agent
        )

        follow_up_params = params.copy()

        assistant_message = {"role": "assistant", "content": initial_response.content}

        user_message = {"role": "user", "content": tool_results}

        follow_up_params["messages"] = params["messages"] + [
            assistant_message,
            user_message,
        ]

        try:
            final_response: Message = await self._get_async_client().messages.create(
                **follow_up_params
            )

            follow_up_usage = self._extract_anthropic_token_usage(final_response)
            self._track_token_usage_internal(follow_up_usage)

            final_content = ""
            if final_response.content:
                for content_block in final_response.content:
                    if hasattr(content_block, "text"):
                        final_content += content_block.text

            final_content = self._apply_stop_words(final_content)

            finish_reason, final_response_id = self._extract_finish_reason_and_id(
                final_response
            )

            self._emit_call_completed_event(
                response=final_content,
                call_type=LLMCallType.LLM_CALL,
                from_task=from_task,
                from_agent=from_agent,
                messages=follow_up_params["messages"],
                usage=follow_up_usage,
                finish_reason=finish_reason,
                response_id=final_response_id,
            )

            total_usage = {
                "input_tokens": follow_up_usage.get("input_tokens", 0),
                "output_tokens": follow_up_usage.get("output_tokens", 0),
                "total_tokens": follow_up_usage.get("total_tokens", 0),
            }

            if total_usage.get("total_tokens", 0) > 0:
                logging.info(f"Anthropic API tool conversation usage: {total_usage}")

            return final_content

        except Exception as e:
            if is_context_length_exceeded(e):
                logging.error(f"Context window exceeded in tool follow-up: {e}")
                raise LLMContextLengthExceededError(str(e)) from e

            logging.error(f"Tool follow-up conversation failed: {e}")
            if tool_results:
                return cast(str, tool_results[0]["content"])
            raise e

    def supports_function_calling(self) -> bool:
        """Check if the model supports function calling."""
        return self.supports_tools

    def supports_stop_words(self) -> bool:
        """Check if the model supports stop words."""
        return True  # All Claude models support stop sequences

    def get_context_window_size(self) -> int:
        """Get the context window size for the model."""
        from crewai.llm import CONTEXT_WINDOW_USAGE_RATIO

        # Current offered models. Unknown and retired IDs fall back to 200k.
        context_windows = {
            "claude-fable-5": 1000000,
            "claude-mythos-5": 1000000,
            "claude-opus-5": 1000000,
            "claude-sonnet-5": 1000000,
            "claude-opus-4-8": 1000000,
            "claude-opus-4-7": 1000000,
            "claude-opus-4-6": 1000000,
            "claude-sonnet-4-6": 1000000,
            "claude-opus-4-5": 200000,
            "claude-sonnet-4-5": 200000,
            "claude-haiku-4-5": 200000,
        }

        for model_prefix, size in context_windows.items():
            if self.model.startswith(model_prefix):
                return int(size * CONTEXT_WINDOW_USAGE_RATIO)

        return int(200000 * CONTEXT_WINDOW_USAGE_RATIO)

    @staticmethod
    def _extract_finish_reason_and_id(
        message: Any,
    ) -> tuple[str | None, str | None]:
        """Extract raw finish_reason and response_id from an Anthropic
        ``Message`` / ``BetaMessage``. Anthropic exposes ``stop_reason`` (e.g.
        ``"end_turn"``, ``"max_tokens"``, ``"tool_use"``); we forward it raw
        and let downstream telemetry map to the OTel GenAI enum.
        """
        return (
            getattr(message, "stop_reason", None),
            getattr(message, "id", None),
        )

    @staticmethod
    def _extract_anthropic_token_usage(
        response: Message | BetaMessage,
    ) -> dict[str, Any]:
        """Extract token usage and response metadata from Anthropic response."""
        if hasattr(response, "usage") and response.usage:
            usage = response.usage
            input_tokens = _coerce_int(getattr(usage, "input_tokens", 0))
            output_tokens = _coerce_int(getattr(usage, "output_tokens", 0))
            cache_read_tokens = _coerce_int(
                getattr(usage, "cache_read_input_tokens", 0)
            )
            cache_creation_tokens = _coerce_int(
                getattr(usage, "cache_creation_input_tokens", 0)
            )
            input_tokens = input_tokens + cache_read_tokens + cache_creation_tokens
            result: dict[str, Any] = {
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
                "cached_prompt_tokens": cache_read_tokens,
                "cache_creation_tokens": cache_creation_tokens,
            }
            return result
        return {"total_tokens": 0}

    def supports_multimodal(self) -> bool:
        """Check if the model supports multimodal inputs.

        All Claude 3+ models support vision and PDFs.

        Returns:
            True if the model supports images and PDFs.
        """
        model_lower = self.model.lower()
        return (
            "claude-3" in model_lower
            or "claude-4" in model_lower
            or "claude-sonnet-4" in model_lower
            or "claude-opus-4" in model_lower
            or "claude-haiku-4" in model_lower
        )

    def get_file_uploader(self) -> Any:
        """Get an Anthropic file uploader using this LLM's clients.

        Returns:
            AnthropicFileUploader instance with pre-configured sync and async clients.
        """
        try:
            from crewai_files.uploaders.anthropic import AnthropicFileUploader

            return AnthropicFileUploader(
                client=self._get_sync_client(),
                async_client=self._get_async_client(),
            )
        except ImportError:
            return None
