# ========= Copyright 2023-2026 @ CAMEL-AI.org. All Rights Reserved. =========
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ========= Copyright 2023-2026 @ CAMEL-AI.org. All Rights Reserved. =========

import pytest

from camel.configs import MinimaxConfig
from camel.models import MinimaxModel
from camel.types import ModelType


@pytest.mark.model_backend
class TestMinimaxModel:
    @pytest.mark.parametrize(
        "model_type",
        [
            ModelType.MINIMAX_M3,
            ModelType.MINIMAX_M2_7,
            ModelType.MINIMAX_M2_7_HIGHSPEED,
            ModelType.MINIMAX_M2_5,
            ModelType.MINIMAX_M2_1,
            ModelType.MINIMAX_M2_1_LIGHTNING,
            ModelType.MINIMAX_M2,
        ],
    )
    def test_minimax_model_create(self, model_type: ModelType, monkeypatch):
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        model = MinimaxModel(model_type)
        assert model.model_type == model_type

    def test_minimax_m3_model_create_with_config(self, monkeypatch):
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        config_dict = MinimaxConfig(
            temperature=0.5,
            top_p=1.0,
            max_tokens=100,
        ).as_dict()

        model = MinimaxModel(
            model_type=ModelType.MINIMAX_M3,
            model_config_dict=config_dict,
        )

        assert model.model_type == ModelType.MINIMAX_M3
        assert model.model_config_dict == config_dict

    def test_minimax_m3_model_api_keys_required(self):
        # Test that the api_keys_required decorator is applied
        assert hasattr(MinimaxModel.__init__, "__wrapped__")

    def test_minimax_m3_model_default_url(self, monkeypatch):
        # Test default URL when no environment variable is set
        monkeypatch.delenv("MINIMAX_API_BASE_URL", raising=False)
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")

        model = MinimaxModel(ModelType.MINIMAX_M3)
        assert model._url == "https://api.minimaxi.com/v1"

    def test_minimax_m3_model_custom_url(self, monkeypatch):
        # Test custom URL from environment variable
        custom_url = "https://custom.minimax.endpoint/v1"
        monkeypatch.setenv("MINIMAX_API_BASE_URL", custom_url)
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")

        model = MinimaxModel(ModelType.MINIMAX_M3)
        assert model._url == custom_url

    def test_minimax_m3_model_extends_openai_compatible(self, monkeypatch):
        # Test that MinimaxModel inherits from OpenAICompatibleModel
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        from camel.models.openai_compatible_model import OpenAICompatibleModel

        model = MinimaxModel(ModelType.MINIMAX_M3)
        assert isinstance(model, OpenAICompatibleModel)

    def test_minimax_m3_model_token_counter(self, monkeypatch):
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        model = MinimaxModel(ModelType.MINIMAX_M3)
        # Should use the default OpenAI token counter
        assert model.token_counter is not None
        assert hasattr(model.token_counter, "count_tokens_from_messages")

    @pytest.mark.parametrize(
        "model_type",
        [
            ModelType.MINIMAX_M3,
            ModelType.MINIMAX_M2_7,
            ModelType.MINIMAX_M2_7_HIGHSPEED,
            ModelType.MINIMAX_M2_5,
            ModelType.MINIMAX_M2_1,
            ModelType.MINIMAX_M2_1_LIGHTNING,
            ModelType.MINIMAX_M2,
        ],
    )
    def test_minimax_model_types_available(
        self, model_type: ModelType, monkeypatch
    ):
        # Test that all defined Minimax model types are recognized
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        assert model_type.is_minimax
        model = MinimaxModel(model_type)
        assert isinstance(model.model_type, ModelType)

    @pytest.mark.parametrize(
        ("model_type", "token_limit"),
        [
            (ModelType.MINIMAX_M3, 1_000_000),
            (ModelType.MINIMAX_M2_7, 204_800),
            (ModelType.MINIMAX_M2_7_HIGHSPEED, 204_800),
            (ModelType.MINIMAX_M2_5, 204_800),
            (ModelType.MINIMAX_M2_1, 204_800),
            (ModelType.MINIMAX_M2_1_LIGHTNING, 204_800),
            (ModelType.MINIMAX_M2, 204_800),
        ],
    )
    def test_minimax_model_token_limits(
        self, model_type: ModelType, token_limit: int
    ):
        assert model_type.token_limit == token_limit

    def test_minimax_model_interleaved_thinking_config(self, monkeypatch):
        # Test interleaved thinking configuration
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")
        config_dict = MinimaxConfig(
            interleaved_thinking=True,
        ).as_dict()

        model = MinimaxModel(
            model_type=ModelType.MINIMAX_M3,
            model_config_dict=config_dict,
        )

        assert model._is_thinking_enabled() is True
        # Verify reasoning_split is added to extra_body
        request_config = model._prepare_request_config()
        assert (
            request_config.get("extra_body", {}).get("reasoning_split") is True
        )
        assert "interleaved_thinking" not in request_config

    def test_minimax_model_interleaved_thinking_disabled(self, monkeypatch):
        # Test that interleaved thinking is disabled by default
        monkeypatch.setenv("MINIMAX_API_KEY", "test_key")

        model = MinimaxModel(model_type=ModelType.MINIMAX_M3)

        assert model._is_thinking_enabled() is False
        request_config = model._prepare_request_config()
        assert (
            "extra_body" not in request_config
            or "reasoning_split" not in request_config.get("extra_body", {})
        )
