package ai.openclaw.app.ui.chat

import ai.openclaw.app.MainViewModel
import ai.openclaw.app.chat.ChatSessionEntry
import ai.openclaw.app.ui.mobileAccent
import ai.openclaw.app.ui.mobileAccentBorderStrong
import ai.openclaw.app.ui.mobileBorderStrong
import ai.openclaw.app.ui.mobileCallout
import ai.openclaw.app.ui.mobileCaption1
import ai.openclaw.app.ui.mobileCaption2
import ai.openclaw.app.ui.mobileCardSurface
import ai.openclaw.app.ui.mobileDanger
import ai.openclaw.app.ui.mobileDangerSoft
import ai.openclaw.app.ui.mobileText
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Returns a pending assistant prompt only when chat can accept it immediately. */
internal fun resolvePendingAssistantAutoSend(
  pendingPrompt: String?,
  healthOk: Boolean,
  pendingRunCount: Int,
): String? {
  val prompt = pendingPrompt?.trim()?.ifEmpty { null } ?: return null
  if (!healthOk || pendingRunCount > 0) return null
  return prompt
}

/** Chooses the session key to load for initial chat hydration, if any. */
internal fun resolveInitialChatLoadSessionKey(
  sessionKey: String,
  mainSessionKey: String,
): String? {
  val current = sessionKey.trim()
  val main = mainSessionKey.trim().ifEmpty { "main" }
  if (current.isNotEmpty() && current != "main" && current != main) return null
  return main
}

/** Main Android chat sheet content: session picker, message list, and composer. */
@Composable
fun ChatSheetContent(viewModel: MainViewModel) {
  val messages by viewModel.chatMessages.collectAsState()
  val historyLoading by viewModel.chatHistoryLoading.collectAsState()
  val errorText by viewModel.chatError.collectAsState()
  val pendingRunCount by viewModel.pendingRunCount.collectAsState()
  val healthOk by viewModel.chatHealthOk.collectAsState()
  val sessionKey by viewModel.chatSessionKey.collectAsState()
  val mainSessionKey by viewModel.mainSessionKey.collectAsState()
  val thinkingLevel by viewModel.chatThinkingLevel.collectAsState()
  val selectedModelRef by viewModel.chatSelectedModelRef.collectAsState()
  // Gate from the controller's agent-scoped catalog — the same source the send gate reads —
  // so the visible control can never disagree with what sends actually carry.
  val modelCatalog by viewModel.chatModelCatalog.collectAsState()
  val thinkingSupported = thinkingSupportedForSelection(selectedModelRef, modelCatalog)
  val streamingAssistantText by viewModel.chatStreamingAssistantText.collectAsState()
  val pendingToolCalls by viewModel.chatPendingToolCalls.collectAsState()
  val sessions by viewModel.chatSessions.collectAsState()
  val chatCommands by viewModel.chatCommands.collectAsState()
  val chatDraft by viewModel.chatDraft.collectAsState()
  val pendingAssistantAutoSend by viewModel.pendingAssistantAutoSend.collectAsState()
  val assistantAutoSendInFlight by viewModel.assistantAutoSendInFlight.collectAsState()
  val outboxItems by viewModel.chatOutboxItems.collectAsState()
  val messageSpeechState by viewModel.chatMessageSpeech.collectAsState()
  val gatewayConnectionDisplay by viewModel.gatewayConnectionDisplay.collectAsState()
  val gatewayOffline = !gatewayConnectionDisplay.isConnected
  val micEnabled by viewModel.micEnabled.collectAsState()
  val micIsListening by viewModel.micIsListening.collectAsState()
  val micCooldown by viewModel.micCooldown.collectAsState()
  val talkModeEnabled by viewModel.talkModeEnabled.collectAsState()
  val talkModeListening by viewModel.talkModeListening.collectAsState()

  DisposableEffect(viewModel) {
    onDispose(viewModel::stopChatMessageSpeech)
  }

  LaunchedEffect(Unit) {
    val loadSessionKey = resolveInitialChatLoadSessionKey(sessionKey, mainSessionKey)
    if (loadSessionKey != null) {
      viewModel.loadChat(loadSessionKey)
    }
    viewModel.refreshChatCommands()
  }

  LaunchedEffect(pendingAssistantAutoSend, assistantAutoSendInFlight, healthOk, pendingRunCount, thinkingLevel) {
    // Assistant-launch prompts should wait for a healthy idle chat so they do
    // not race an already-running turn.
    if (!healthOk) return@LaunchedEffect
    val prompt =
      resolvePendingAssistantAutoSend(
        pendingPrompt = pendingAssistantAutoSend,
        healthOk = healthOk,
        pendingRunCount = pendingRunCount,
      ) ?: return@LaunchedEffect
    viewModel.dispatchPendingAssistantAutoSend(
      pendingPrompt = prompt,
      thinking = thinkingLevel,
    )
  }

  val context = LocalContext.current
  val resolver = context.contentResolver
  val scope = rememberCoroutineScope()

  val attachments = remember { mutableStateListOf<PendingAttachment>() }
  val micCaptureActive = micEnabled || micIsListening || micCooldown || talkModeEnabled || talkModeListening
  val voiceNoteRecorder =
    rememberVoiceNoteRecorderController(
      viewModel = viewModel,
      onFinished = attachments::add,
    )
  val voiceNoteState by voiceNoteRecorder.state.collectAsState()
  val voiceNoteElapsedMs by voiceNoteRecorder.elapsedMs.collectAsState()

  val pickImages =
    rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
      if (uris.isNullOrEmpty()) return@rememberLauncherForActivityResult
      scope.launch(Dispatchers.IO) {
        // Bound both count and encoded size before attachments enter Compose
        // state; sending uses these already-compressed payloads directly.
        val next =
          uris.take(8).mapNotNull { uri ->
            try {
              loadSizedImageAttachment(resolver, uri)
            } catch (_: Throwable) {
              null
            }
          }
        withContext(Dispatchers.Main) {
          attachments.addAll(next)
        }
      }
    }

  Column(
    modifier =
      Modifier
        .fillMaxSize()
        .padding(horizontal = 20.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    ChatThreadSelector(
      sessionKey = sessionKey,
      sessions = sessions,
      mainSessionKey = mainSessionKey,
      onSelectSession = { key -> viewModel.switchChatSession(key) },
    )

    if (!errorText.isNullOrBlank()) {
      ChatErrorRail(errorText = errorText!!)
    }

    ChatMessageListCard(
      sessionKey = sessionKey,
      messages = messages,
      historyLoading = historyLoading,
      pendingRunCount = pendingRunCount,
      pendingToolCalls = pendingToolCalls,
      streamingAssistantText = streamingAssistantText,
      healthOk = healthOk,
      gatewayOffline = gatewayOffline,
      modifier = Modifier.weight(1f, fill = true),
      outboxItems =
        outboxItemsForSession(
          items = outboxItems,
          sessionKey = sessionKey,
          mainSessionKey = mainSessionKey,
        ),
      onRetryOutbox = viewModel::retryChatOutboxCommand,
      onDeleteOutbox = viewModel::deleteChatOutboxCommand,
      onReplyMessage = viewModel::setChatReplyDraft,
      speechState = messageSpeechState,
      onToggleListen = viewModel::toggleChatMessageSpeech,
    )

    Row(modifier = Modifier.fillMaxWidth().imePadding()) {
      ChatComposer(
        draftText = chatDraft,
        healthOk = healthOk,
        thinkingLevel = thinkingLevel,
        thinkingSupported = thinkingSupported,
        pendingRunCount = pendingRunCount,
        commands = chatCommands,
        attachments = attachments,
        onDraftApplied = viewModel::clearChatDraft,
        onPickImages = { pickImages.launch("image/*") },
        onRemoveAttachment = { id -> attachments.removeAll { it.id == id } },
        voiceNoteState = voiceNoteState,
        voiceNoteElapsedMs = voiceNoteElapsedMs,
        recordVoiceNoteEnabled = pendingRunCount == 0 && !micCaptureActive,
        onStartVoiceNote = { scope.launch { voiceNoteRecorder.start() } },
        onCancelVoiceNote = voiceNoteRecorder::cancel,
        onFinishVoiceNote = voiceNoteRecorder::finish,
        onSetThinkingLevel = { level -> viewModel.setChatThinkingLevel(level) },
        onRefresh = {
          viewModel.refreshChat()
          viewModel.refreshChatSessions(limit = 200)
          viewModel.refreshChatCommands()
        },
        onAbort = { viewModel.abortChat() },
        onSend = { text ->
          val outgoing = attachments.map(PendingAttachment::toOutgoingAttachment)
          val pendingAttachments = attachments.toList()
          attachments.clear()
          val accepted = viewModel.sendChatAwaitAcceptance(message = text, thinking = thinkingLevel, attachments = outgoing)
          if (!accepted && attachments.isEmpty()) {
            // Refused sends must not silently drop selected attachments either.
            attachments.addAll(pendingAttachments)
          }
          accepted
        },
      )
    }
  }
}

@Composable
private fun ChatThreadSelector(
  sessionKey: String,
  sessions: List<ChatSessionEntry>,
  mainSessionKey: String,
  onSelectSession: (String) -> Unit,
) {
  val sessionOptions =
    remember(sessionKey, sessions, mainSessionKey) {
      resolveSessionChoices(sessionKey, sessions, mainSessionKey = mainSessionKey)
    }

  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    for (entry in sessionOptions) {
      val active = entry.key == sessionKey
      Surface(
        onClick = { onSelectSession(entry.key) },
        shape = RoundedCornerShape(14.dp),
        color = if (active) mobileAccent else mobileCardSurface,
        border = BorderStroke(1.dp, if (active) mobileAccentBorderStrong else mobileBorderStrong),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp,
      ) {
        Text(
          text = friendlySessionName(entry.displayName ?: entry.key),
          style = mobileCaption1.copy(fontWeight = if (active) FontWeight.Bold else FontWeight.SemiBold),
          color = if (active) Color.White else mobileText,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
        )
      }
    }
  }
}

@Composable
private fun ChatErrorRail(errorText: String) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    color = mobileDangerSoft,
    shape = RoundedCornerShape(12.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, mobileDanger),
  ) {
    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Text(
        text = "CHAT ERROR",
        style = mobileCaption2.copy(letterSpacing = 0.6.sp),
        color = mobileDanger,
      )
      Text(text = errorText, style = mobileCallout, color = mobileText)
    }
  }
}
